# Admin Tool API Environment Variables

This document is a work in progress.   

| Secret? | Env Specific? | Area | Variable | Description | Default Value |
| ---- | ---- | ---- | ---- | ----- | ----- |  
| Yes  | Yes  |      | APP_SECRETKEY | IHR SenzingB50 call secret key |  |
|      | Yes  |      | APP_SENZING50 | IHR SenzingB50 Service URL |  |
|      | Yes  |      | APP_SENZINGAPI | Not in Use |  |
|      | Yes  |      | APP_B50MONGOHOST | Mongo DB Host for Member Individual Actor/ B50 Transcribed Document |  |
|      | Yes  |      | APP_B50MONGOPORT | Mongo DB Port for Member Individual Actor/ B50 Transcribed Document |  |
| Yes  | Yes  |      | APP_B50MONGOUSER | Mongo DB User for Member Individual Actor/ B50 Transcribed Document |  |
| Yes  | Yes  |      | APP_B50MONGOPASSWORD | Mongo DB Password for Member Individual Actor/ B50 Transcribed Document |  |
|      |      |      | APP_SECONDARYDBENABLED | Whether Secondary DB enabled for Member Individual Actor/ VIP Transcribed Document |  |
|      | Yes  |      | APP_B50MONGOHOST2ND | Secondary Mongo DB Host for Member Individual Actor/ VIP Transcribed Document |  |
|      | Yes  |      | APP_B50MONGOPORT2ND | Secondary Mongo DB Port for Member Individual Actor/ VIP Transcribed Document |  |
| Yes  | Yes  |      | APP_B50MONGOUSER2ND | Secondary Mongo DB User for Member Individual Actor/ VIP Transcribed Document |  |
| Yes  | Yes  |      | APP_B50MONGOPASSWORD2ND | Secondary Mongo DB Password for Member Individual Actor/ VIP Transcribed Document |  |
|      | Yes  |      | APP_B50MONGOSBRHOST | Mongo DB Host for Provider, VIP SBR Relationship Master Document |  |
|      | Yes  |      | APP_B50MONGOSBRPORT | Mongo DB Port for Provider, VIP SBR Relationship Master Document |  |
| Yes  | Yes  |      | APP_B50MONGOSBRUSER | Mongo DB User for Provider, VIP SBR Relationship Master Document |  |
| Yes  | Yes  |      | APP_B50MONGOSBRPASSWORD | Mongo DB Password for Provider, VIP SBR Relationship Master Document |  |
|      | Yes  |      | APP_CURRENTMONGOHOST | Not in Use |  |
|      | Yes  |      | APP_CURRENTMONGOPORT | Not in Use |  |
| Yes  | Yes  |      | APP_CURRENTMOGOUSER | Not in Use |  |
| Yes  | Yes  |      | APP_CURRENTMONGOPASSWORD | Not in Use |  |
|      | Yes  |      | APP_SUMMARY | Not in Use |  |
|      | Yes  |      | APP_STATS | Not in Use |  |
|      | Yes  |      | APP_HELIUMSTATS | Not in Use |  |
|      | Yes  |      | APP_ACTORSERVICE | Not in Use |  |
|      | Yes  |      | APP_LDAPPROVIDERURL | Ldap Provider URL for authentication service |  |
|      | Yes  |      | APP_LDAPSEARCHGROUPDN | Ldap/AD Admin Group for full access | ol_dev_admin |
|      | Yes  |      | APP_LDAPSEARCHDEVGROUP | Ldap/AD Admin Group for developer access : Not in Use | ol_dev_dev_support |
|      | Yes  |      | APP_LDAPSEARCHDSTGROUP | Ldap/AD Group for tier-1 access | ol_dev_support_t1 |
|      | Yes  |      | APP_LDAPSEARCHONTGROUP | Ldap/AD Group for Ontology Browser access | ol_dev_ont |
|      | Yes  |      | APP_LDAPSEARCHPRGROUP | Ldap/AD Group for Packet Refile access : Not in Use | ol_dev_pr |
|      |      |      | APP_PACKETSENABLED | Not in Use |  |
|      | Yes  |      | APP_ONTSUMMARYURL | Ont Summary DB URL for Provider Speciality Code |  |
| Yes  | Yes  |      | APP_ONTSUMMARYUSER | Ont Summary DB User for Provider Speciality Code |  |
| Yes  | Yes  |      | APP_ONTSUMMARYPASSWORD | Ont Summary DB Password for Provider Speciality Code |  |
|      | Yes  |      | SPRING_DATASOURCE_URL | ihrtools postgres DB URL used for DDSConfig |  |
| Yes  | Yes  |      | SPRING_DATASOURCE_USERNAME | ihrtools postgres DB User used for DDSConfig |  |
| Yes  | Yes  |      | SPRING_DATASOURCE_PASSWORD | ihrtools postgres DB Password used for DDSConfig |  |
|      | Yes  |      | SPRING_DATASOURCE_PLATFORM | Ont Summary and ihrtools DB platform | postgresql |
|      | Yes  |      | SPRING_DATASOURCE_DRIVERCLASSNAME | Ont Summary DB and ihrtools Driver class | org.postgresql.Driver |
