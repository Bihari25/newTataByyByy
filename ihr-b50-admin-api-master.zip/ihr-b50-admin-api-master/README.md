# ihr-b50-spot-checker
ihr-b50-spot-checker

Build and Run the docker locally to test

Update the docker-compose-local-build.yml file with necessary environment variables then run:

docker-compose -f docker-compose-local-build.yml up -d --build

API URL: http://localhost:8080
Local Swagger URL: http://localhost:8080/swagger-ui.html