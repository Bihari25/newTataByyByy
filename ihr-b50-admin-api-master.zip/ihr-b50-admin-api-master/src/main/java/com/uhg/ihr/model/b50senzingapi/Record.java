package com.uhg.ihr.model.b50senzingapi;

import com.fasterxml.jackson.annotation.*;
import org.apache.commons.lang3.builder.EqualsBuilder;
import org.apache.commons.lang3.builder.HashCodeBuilder;
import org.apache.commons.lang3.builder.ToStringBuilder;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
        "dataSource",
        "recordId",
        "addressData",
        "attributeData",
        "identifierData",
        "nameData",
        "phoneData",
        "relationshipData",
        "otherData",
        "originalSourceData"
})
public class Record {

    @JsonProperty("dataSource")
    private String dataSource;
    @JsonProperty("recordId")
    private String recordId;
    @JsonProperty("addressData")
    private List<String> addressData = new ArrayList<String>();
    @JsonProperty("attributeData")
    private List<String> attributeData = new ArrayList<String>();
    @JsonProperty("identifierData")
    private List<String> identifierData = new ArrayList<String>();
    @JsonProperty("nameData")
    private List<String> nameData = new ArrayList<String>();
    @JsonProperty("phoneData")
    private List<Object> phoneData = new ArrayList<Object>();
    @JsonProperty("relationshipData")
    private List<Object> relationshipData = new ArrayList<Object>();
    @JsonProperty("otherData")
    private List<String> otherData = new ArrayList<String>();
    @JsonProperty("originalSourceData")
    private OriginalSourceData originalSourceData;
    @JsonIgnore
    private Map<String, Object> additionalProperties = new HashMap<String, Object>();

    @JsonProperty("dataSource")
    public String getDataSource() {
        return dataSource;
    }

    @JsonProperty("dataSource")
    public void setDataSource(String dataSource) {
        this.dataSource = dataSource;
    }

    @JsonProperty("recordId")
    public String getRecordId() {
        return recordId;
    }

    @JsonProperty("recordId")
    public void setRecordId(String recordId) {
        this.recordId = recordId;
    }

    @JsonProperty("addressData")
    public List<String> getAddressData() {
        return addressData;
    }

    @JsonProperty("addressData")
    public void setAddressData(List<String> addressData) {
        this.addressData = addressData;
    }

    @JsonProperty("attributeData")
    public List<String> getAttributeData() {
        return attributeData;
    }

    @JsonProperty("attributeData")
    public void setAttributeData(List<String> attributeData) {
        this.attributeData = attributeData;
    }

    @JsonProperty("identifierData")
    public List<String> getIdentifierData() {
        return identifierData;
    }

    @JsonProperty("identifierData")
    public void setIdentifierData(List<String> identifierData) {
        this.identifierData = identifierData;
    }

    @JsonProperty("nameData")
    public List<String> getNameData() {
        return nameData;
    }

    @JsonProperty("nameData")
    public void setNameData(List<String> nameData) {
        this.nameData = nameData;
    }

    @JsonProperty("phoneData")
    public List<Object> getPhoneData() {
        return phoneData;
    }

    @JsonProperty("phoneData")
    public void setPhoneData(List<Object> phoneData) {
        this.phoneData = phoneData;
    }

    @JsonProperty("relationshipData")
    public List<Object> getRelationshipData() {
        return relationshipData;
    }

    @JsonProperty("relationshipData")
    public void setRelationshipData(List<Object> relationshipData) {
        this.relationshipData = relationshipData;
    }

    @JsonProperty("otherData")
    public List<String> getOtherData() {
        return otherData;
    }

    @JsonProperty("otherData")
    public void setOtherData(List<String> otherData) {
        this.otherData = otherData;
    }

    @JsonProperty("originalSourceData")
    public OriginalSourceData getOriginalSourceData() {
        return originalSourceData;
    }

    @JsonProperty("originalSourceData")
    public void setOriginalSourceData(OriginalSourceData originalSourceData) {
        this.originalSourceData = originalSourceData;
    }

    @Override
    public String toString() {
        return ToStringBuilder.reflectionToString(this);
    }

    @JsonAnyGetter
    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    @JsonAnySetter
    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

    @Override
    public int hashCode() {
        return new HashCodeBuilder().append(dataSource).append(recordId).append(addressData).append(attributeData).append(identifierData).append(nameData).append(phoneData).append(relationshipData).append(otherData).append(originalSourceData).append(additionalProperties).toHashCode();
    }

    @Override
    public boolean equals(Object other) {
        if (other == this) {
            return true;
        }
        if ((other instanceof Record) == false) {
            return false;
        }
        Record rhs = ((Record) other);
        return new EqualsBuilder().append(dataSource, rhs.dataSource).append(recordId, rhs.recordId).append(addressData, rhs.addressData).append(attributeData, rhs.attributeData).append(identifierData, rhs.identifierData).append(nameData, rhs.nameData).append(phoneData, rhs.phoneData).append(relationshipData, rhs.relationshipData).append(otherData, rhs.otherData).append(originalSourceData, rhs.originalSourceData).append(additionalProperties, rhs.additionalProperties).isEquals();
    }

}
