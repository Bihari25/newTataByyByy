package com.uhg.ihr.model;

import com.fasterxml.jackson.annotation.JsonInclude;

import java.io.Serializable;

@JsonInclude(JsonInclude.Include.NON_NULL)
public class ParsedName implements Serializable {
    private String first;
    private String middle;
    private String last;

    public String getFirst() {
        return first;
    }

    public void setFirst(String first) {
        this.first = first.toUpperCase();
    }

    public String getMiddle() {
        return middle;
    }

    public void setMiddle(String middle) {
        this.middle = middle.toUpperCase();
    }

    public String getLast() {
        return last;
    }

    public void setLast(String last) {
        this.last = last.toUpperCase();
    }
}
