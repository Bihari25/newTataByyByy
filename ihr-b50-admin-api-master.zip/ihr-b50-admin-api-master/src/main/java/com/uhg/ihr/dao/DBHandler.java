package com.uhg.ihr.dao;

import com.uhg.ihr.model.PacketRequest;
import com.uhg.ihr.model.PacketResponse;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.namedparam.MapSqlParameterSource;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;
import org.springframework.jdbc.core.namedparam.SqlParameterSource;
import org.springframework.stereotype.Repository;

import java.sql.*;
import java.time.LocalDate;
import java.util.List;

import static com.uhg.ihr.utils.IHRUtils.*;

@Repository
public class DBHandler {

    private Logger LOGGER = LoggerFactory.getLogger(DBHandler.class);

    @Autowired
    @Qualifier("ihrtoolsJdbcTemplate")
    private JdbcTemplate ihrtoolsJdbcTemplate;

    @Autowired
    @Qualifier("ihrtoolsNamedParameterJdbcTemplate")
    private NamedParameterJdbcTemplate ihrtoolsNamedParameterJdbcTemplate;

    @Autowired
    @Qualifier("ontsummaryJdbcTemplate")
    private JdbcTemplate ontsummaryJdbcTemplate;

    public DBHandler(){}

    public String fetchPayloadByUUID(String uuid){
        SqlParameterSource namedParams = new MapSqlParameterSource().addValue("uu_id",uuid);
        return ihrtoolsNamedParameterJdbcTemplate.queryForObject(" select pkt.payload from tools.ihr_packets pkt where pkt.uuid = :uu_id " +
                "order by last_updated_dt desc limit 1", namedParams,String.class);
    }

    public int requestPacket(PacketRequest packetRequest) {
        LocalDate localDate = LocalDate.now();

        return ihrtoolsJdbcTemplate.update("insert into tools.ihr_audit_packets ( user_id, actorid, last_updated_dt, refer_id, batch_id, status, batch_start_dt, batch_end_dt) " + "values (?,?,?,?,?,?,?,?)",
                packetRequest.getUserId(), packetRequest.getActorId(), localDate, 0, " ",packetRequest.getStatus(),  localDate, localDate);
    }

    public int openRequests(String userid,String status) {
        MapSqlParameterSource source = new MapSqlParameterSource();
        SqlParameterSource namedParams = source.addValue("user_id",userid);
        if(status!=null){
            namedParams = source.addValue("status",status);
        }
        return  ihrtoolsNamedParameterJdbcTemplate.queryForObject( (status!=null ? "select count(*) as count from tools.ihr_audit_packets where user_id in ( :user_id )  and status =  :status "
                            : "select count(*) as count from tools.ihr_audit_packets where user_id in ( :user_id ) ")
                ,namedParams ,Integer.class);
    }

    public int deleteRequest(String userid,String actorid) {
        SqlParameterSource namedParams = new MapSqlParameterSource().addValue("user_id",userid).addValue("actor_id",actorid);
        return  ihrtoolsNamedParameterJdbcTemplate.update(
                "delete from tools.ihr_audit_packets where user_id in ( :user_id )  and actorid in  ( :actor_id ) ",namedParams);
    }

    public List<PacketRequest> auditpacket(String userid) {
        MapSqlParameterSource parameters = new MapSqlParameterSource();
        parameters.addValue("user_id", userid);
        return ihrtoolsNamedParameterJdbcTemplate.query("select * from tools.ihr_audit_packets where user_id IN ( :user_id )", parameters, (resultSet, i) -> {
            return getOpenRequests(resultSet);
        });
    }

    public List<PacketResponse> getPackets(String userid, String actorid) {

        SqlParameterSource namedParams = new MapSqlParameterSource().addValue("actor_id",actorid);
        return ihrtoolsNamedParameterJdbcTemplate.query("select pkt.actorid, file_name, interface_type, topic_source, uuid, pkt.last_updated_dt, status, user_id, status " +
                " from tools.ihr_packets pkt left outer join tools.ihr_audit_packets req on req.actorid = pkt.actorid where pkt.actorid = :actor_id ", namedParams, (resultSet, i) -> {
            return getEnrichedMessages(resultSet);
        });
    }

    private PacketRequest getOpenRequests(ResultSet resultSet) {
        PacketRequest packets = new PacketRequest();

        try {
            packets.setUserId(resultSet.getString("user_id"));
            packets.setActorId(resultSet.getString("actorid"));
            packets.setStatus(resultSet.getString("status"));
            packets.setUpdateDate(resultSet.getString("last_updated_dt"));

        } catch (SQLException e) {
            LOGGER.error(e.getMessage());
        }
        return packets;
    }

    private PacketResponse getEnrichedMessages(ResultSet resultSet) {
        PacketResponse packets = new PacketResponse();

        try {
            packets.setActorid(resultSet.getString("actorid"));
            packets.setFile_name(resultSet.getString("file_name"));
            packets.setInterface_type(resultSet.getString("interface_type"));
            packets.setTopic_source(resultSet.getString("topic_source"));
            packets.setUuid(resultSet.getString("uuid"));
            packets.setLast_updated_dt(resultSet.getString("last_updated_dt"));
            if(packets.getLast_updated_dt()!=null){
                packets.setLast_updated_dt(packets.getLast_updated_dt().substring(0,packets.getLast_updated_dt().indexOf(".")));
            }
            packets.setStatus(resultSet.getString("status"));
            packets.setUserid(resultSet.getString("user_id"));

            packets.setStatus(resultSet.getString("status"));
        } catch (SQLException e) {
            LOGGER.error(e.getMessage());
        }
        return packets;
    }

    public String ontLookupForSpeciality(String code) {
        String retVal = null;
        ResultSet rs = null;
        try (
                Connection conn = ontsummaryJdbcTemplate.getDataSource().getConnection();
                PreparedStatement stmt = conn.prepareStatement("SELECT term FROM ihr.chx_ontology_summary_foreign_key_term where foreign_key = ? and locale='LOC611' and vocabulary_chid = 'QLR3113' ")
        ) {
            stmt.setString(1, code);
            rs = stmt.executeQuery();
            if (rs != null && rs.next()) {
                retVal = rs.getString("term");
                if (rs.next())
                    LOGGER.warn("More than one speciality term found for code - " + code + ", but taking only one - " + retVal);
            }
        } catch (SQLException ex) {
            LOGGER.error("Unable to get speciality for code - " + code + ", due to error - " + ex.getMessage());
            retVal = code;
        } finally {
            safeClose(rs);
        }
        return retVal;
    }

    public void refreshDDSConfig() {
        try (
                Connection conn = ihrtoolsJdbcTemplate.getDataSource().getConnection();
                Statement stmt = conn.createStatement();
                ResultSet rs = stmt.executeQuery("select host,line from tools.dds_config ") // where line = 'gold'
        ) {
            String line;
            while (rs != null && rs.next()) {
                line = rs.getString("line");
                if ("gold".equalsIgnoreCase(line)) {
                    GOLD_DDS_HOST = rs.getString("host");
                    LOGGER.info("Refreshed DDS config - GOLD_HOST : " + GOLD_DDS_HOST);
                } else if ("vip".equalsIgnoreCase(line)) {
                    VIP_DDS_HOST = rs.getString("host");
                    LOGGER.info("Refreshed DDS config - VIP_HOST : " + VIP_DDS_HOST);
                } else if ("smb".equalsIgnoreCase(line)) {
                    SMB_DDS_HOST = rs.getString("host");
                    LOGGER.info("Refreshed DDS config - SMB_HOST : " + SMB_DDS_HOST);
                } else if ("five01".equalsIgnoreCase(line)) {
                    FIVE_LINE_01_HOST = rs.getString("host");
                    LOGGER.info("Refreshed DDS config - FIVE01_HOST : " + FIVE_LINE_01_HOST);
                } else if ("five02".equalsIgnoreCase(line)) {
                    FIVE_LINE_02_HOST = rs.getString("host");
                    LOGGER.info("Refreshed DDS config - FIVE02_HOST : " + FIVE_LINE_02_HOST);
                } else if ("five03".equalsIgnoreCase(line)) {
                    FIVE_LINE_03_HOST = rs.getString("host");
                    LOGGER.info("Refreshed DDS config - FIVE03_HOST : " + FIVE_LINE_03_HOST);
                } else if ("five04".equalsIgnoreCase(line)) {
                    FIVE_LINE_04_HOST = rs.getString("host");
                    LOGGER.info("Refreshed DDS config - FIVE04_HOST : " + FIVE_LINE_04_HOST);
                } else if ("five05".equalsIgnoreCase(line)) {
                    FIVE_LINE_05_HOST = rs.getString("host");
                    LOGGER.info("Refreshed DDS config - FIVE05_HOST : " + FIVE_LINE_05_HOST);
                }
            }
        } catch (SQLException ex) {
            LOGGER.error("Unable to refresh DDS config ...");
            LOGGER.error(ex.getMessage());
        }
    }

    private void safeClose(ResultSet rs) {
        if (rs != null) {
            try {
                rs.close();
            } catch (SQLException e) {
                LOGGER.error(e.getMessage());
            }
        }
    }
}
