package com.uhg.ihr.model;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.stereotype.Component;

@NoArgsConstructor
@AllArgsConstructor
@Data
@Component
@ConfigurationProperties("app")
public class AppProperties {

    private String semzingb50;
    private int ttl;
    private String secretkey;
    private String senzingapi;
    private String issuer;
    private String tokentpe;
    private String subject;

    private String b50mongohost;
    private String b50mongoport;
    private String b50mongouser;
    private String b50mongopassword;
    private String b50mongodb;
    private String b50mongodbconnstr;
    private String b50mongocollection;
    private String b50mongoline;

    private boolean secondaryDBEnabled;

    private String b50mongohost2nd;
    private String b50mongoport2nd;
    private String b50mongouser2nd;
    private String b50mongopassword2nd;
    private String b50mongodb2nd;
    private String b50mongodbconnstr2nd;
    private String b50mongocollname2nd;
    private String b50mongoline2nd;

    private String currentmongohost;
    private String currentmongoport;
    private String currentmogouser;
    private String currentmongopassword;
    private String currentmongodb;
    private String currentmongocollection;

    private String b50mongosbrhost;
    private String b50mongosbrport;
    private String b50mongosbruser;
    private String b50mongosbrpassword;
    private String b50mongosbrdb;
    private String b50mongosbrcollection;
    private String b50mongosbrcollection2nd;

    private String b50mongoprovdb;
    private String b50mongoprovcoll;

    private String summary;
    private String ldapctxfactory;
    private String ldapproviderurl;
    private String ldapsecurityauth;
    private String ldapsearchdn;
    private String ldapsearchgroupdn;
    private String ldapsearchdstgroup;
    private String ldapsearchdevgroup;
    private String ldapsearchontgroup;
    private String ldapsearchprgroup;
    private String b50mongodbvip;

    private boolean packetsEnabled;

    private String mongoPrUser;
    private String mongoPrPwd;
    private String mongoPrHost;
    private String mongoPrPort;
    private String mongoPrConnectionString;
    private String mongoPrTargetDbName;
    private String mongoPrSourceDbName;
    private String mongoPrSourceTargetCollectionNames;
    private String mongoPrFiveLineTargetCollectionPrefix;
    private String mongoPrFiveLineTargetCollectionSuffix;

    private String serviceNowUrl;
    private String serviceNowAuth;
    private String serviceNowGroupName;
    private String serviceNowGroupID;
    private String sbrRelMstrTblNames;
    private String sbrMstrTblNames;
    private String b50TranTblName;

    private String actDelCollectionName;
    private String delActrMongoDbName;
    private String delActAuditCollName;

    private String delSbrRelMstrTblNames;
    private String delSbrMstrTblNames;
    private String delB50TranTblName;



}