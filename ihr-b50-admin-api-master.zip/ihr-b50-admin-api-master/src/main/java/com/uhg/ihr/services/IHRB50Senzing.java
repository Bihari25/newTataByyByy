package com.uhg.ihr.services;


import com.uhg.ihr.model.AppProperties;
import com.uhg.ihr.utils.JWTHelper;

//import org.apache.http.client.methods.CloseableHttpResponse;
//import org.apache.http.client.methods.HttpPost;
//import org.apache.http.entity.StringEntity;
//import org.apache.http.impl.client.CloseableHttpClient;
//
//import org.apache.http.impl.client.HttpClientBuilder;
//
//import org.apache.http.util.EntityUtils;
//import org.json.JSONException;
//import org.json.JSONObject;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import javax.net.ssl.*;
import java.io.*;
import java.net.*;
import java.nio.charset.StandardCharsets;
import java.security.KeyManagementException;
import java.security.KeyStore;
import java.security.NoSuchAlgorithmException;


@Component
public class IHRB50Senzing {

    @Autowired
    AppProperties appProperties;

    @Autowired
    JWTHelper jwtHelper;

    private final TrustManagerFactory trustManagerFactory;
    private static final String KEYSTORE_PATH = "configs/optum-root-ca.jks";
    private static final Logger LOGGER = LoggerFactory.getLogger(IHRB50Senzing.class);
    private static final String PASWD = "ty^7Uajn*9";

    private IHRB50Senzing() {
        InputStream is = null;
        try {
            // Create a TrustManager that trusts the CAs in our KeyStore
            this.trustManagerFactory = TrustManagerFactory.getInstance(TrustManagerFactory.getDefaultAlgorithm());
            KeyStore ks = KeyStore.getInstance(KeyStore.getDefaultType());
            File file = new File(KEYSTORE_PATH);
            if (!file.exists()) {
                LOGGER.error("could not find keystore at {}", KEYSTORE_PATH);
            } else {
                is = new FileInputStream(file);
                LOGGER.info("using keystore at {}", file.getAbsolutePath());
            }
            ks.load(is, PASWD.toCharArray());
            trustManagerFactory.init(ks);
        } catch (Exception e) {
            throw new RuntimeException("unable to initialize the trustManagerFactory", e);
        } finally {
            safeClose(is);
        }
    }

    /*public String getPacket(String chid, String userid) throws MalformedURLException {


        JSONObject json = new JSONObject();
        json.put("userId", userid);
        json.put("actorId", chid);
        json.put("status", "Submitted");

        CloseableHttpClient client = HttpClientBuilder.create().build();
        HttpPost httpPost = new HttpPost("http://apsrp04818:8081/findpacket");
        String responseJSON = null;
        try {
            StringEntity entity = new StringEntity(json.toString());
            httpPost.setEntity(entity);

            // set your POST request headers to accept json contents
            httpPost.setHeader("Accept", "application/json");
            httpPost.setHeader("Content-type", "application/json");

            try {
                // your closeablehttp response
                CloseableHttpResponse response = client.execute(httpPost);

                // take the response body as a json formatted string
                responseJSON = EntityUtils.toString(response.getEntity());

            } catch (IOException e) {
                LOGGER.error(e.getMessage());
            } catch (JSONException e) {

                LOGGER.error(e.getMessage());
            }

        } catch (UnsupportedEncodingException e) {
            LOGGER.error(e.getMessage());
        }

        return responseJSON;

    }*/


    /*public String viewPacket(String chid, String userid) throws MalformedURLException {
        String responseJSON = null;


        JSONObject json = new JSONObject();
        json.put("userId", userid);
        json.put("actorId", chid);
        // json.put("status", "submitted");

        CloseableHttpClient client = HttpClientBuilder.create().build();
        HttpPost httpPost = new HttpPost("http://apsrp04818:8081/viewpacket");
        String jsonOutput = null;
        try {
            StringEntity entity = new StringEntity(json.toString());
            httpPost.setEntity(entity);

            // set your POST request headers to accept json contents
            httpPost.setHeader("Accept", "application/json");
            httpPost.setHeader("Content-type", "application/json");

            try {
                // your closeablehttp response
                CloseableHttpResponse response = client.execute(httpPost);

                // take the response body as a json formatted string
                responseJSON = EntityUtils.toString(response.getEntity());

            } catch (IOException e) {
                LOGGER.error(e.getMessage());
            } catch (JSONException e) {

                LOGGER.error(e.getMessage());
            }

        } catch (UnsupportedEncodingException e) {
            LOGGER.error(e.getMessage());
        }

        return responseJSON;

    }*/


    /*public String auditRequest(String userid) throws MalformedURLException {
        String responseJSON = null;


        JSONObject json = new JSONObject();
        json.put("userId", userid);

        CloseableHttpClient client = HttpClientBuilder.create().build();
        HttpPost httpPost = new HttpPost("http://apsrp04818:8081/auditpacket");

        try {
            StringEntity entity = new StringEntity(json.toString());
            httpPost.setEntity(entity);

            // set your POST request headers to accept json contents
            httpPost.setHeader("Accept", "application/json");
            httpPost.setHeader("Content-type", "application/json");

            try {
                // your closeablehttp response
                CloseableHttpResponse response = client.execute(httpPost);

                // take the response body as a json formatted string
                responseJSON = EntityUtils.toString(response.getEntity());

            } catch (IOException e) {
                LOGGER.error(e.getMessage());
            } catch (JSONException e) {

                LOGGER.error(e.getMessage());
            }

        } catch (UnsupportedEncodingException e) {
            LOGGER.error(e.getMessage());
        }

        return responseJSON;

    }*/


    /*public String deletePacket(String chid, String userid) throws MalformedURLException {
        String responseJSON = null;


        JSONObject json = new JSONObject();
        json.put("userId", userid);
        json.put("actorId", chid);
        // json.put("status", "submitted");

        CloseableHttpClient client = HttpClientBuilder.create().build();
        HttpPost httpPost = new HttpPost("http://apsrp04818:8081/deletepacket");

        try {
            StringEntity entity = new StringEntity(json.toString());
            httpPost.setEntity(entity);

            // set your POST request headers to accept json contents
            httpPost.setHeader("Accept", "application/json");
            httpPost.setHeader("Content-type", "application/json");

            try {
                // your closeablehttp response
                CloseableHttpResponse response = client.execute(httpPost);

                // take the response body as a json formatted string
                responseJSON = EntityUtils.toString(response.getEntity());

            } catch (IOException e) {
                LOGGER.error(e.getMessage());
            } catch (JSONException e) {

                LOGGER.error(e.getMessage());
            }

        } catch (UnsupportedEncodingException e) {
            LOGGER.error(e.getMessage());
        }

        return responseJSON;

    }*/


    public String getB50SenzingAPI(String request) {
        StringBuffer response = new StringBuffer();

        try {
            SSLContext sc = SSLContext.getInstance("SSL");
            sc.init(null, trustManagerFactory.getTrustManagers(), new java.security.SecureRandom());
            HttpsURLConnection.setDefaultSSLSocketFactory(sc.getSocketFactory());

            HostnameVerifier allHostsValid = new HostnameVerifier() {
                public boolean verify(String hostname, SSLSession session) {
                    return true;
                }
            };
            HttpsURLConnection.setDefaultHostnameVerifier(allHostsValid);
        } catch (NoSuchAlgorithmException | KeyManagementException e) {
            LOGGER.error(e.getMessage());
        }


        OutputStreamWriter osw = null;
        OutputStream os = null;
        BufferedReader in = null;
        try {
            URL url = new URL(appProperties.getSemzingb50());
            HttpURLConnection conn = (HttpURLConnection) url.openConnection();
            conn.setRequestProperty("Authorization", "Bearer " + jwtHelper.createJWT(appProperties.getTokentpe(), appProperties.getIssuer(), appProperties.getSubject(), appProperties.getTtl(), appProperties.getSecretkey()));
            conn.setRequestProperty("Content-Type", "application/json");
            conn.setRequestMethod("POST");
            conn.setDoOutput(true);
            os = conn.getOutputStream();
            osw = new OutputStreamWriter(os, StandardCharsets.UTF_8);
            osw.write(request);
            osw.flush();
            conn.connect();
            in = new BufferedReader(new InputStreamReader(conn.getInputStream()));
            String output;

            while ((output = in.readLine()) != null) {
                response.append(output);
            }

        } catch (IOException e) {
            LOGGER.error(e.getMessage());
        } finally {
            safeClose(osw);
            safeClose(os);
            safeClose(in);
        }

        return response.toString();
    }

    /*public String getSummary() {
        StringBuffer response = new StringBuffer();
        //  URL url = new URL("http://apsrp04818:8081/summary");
        String output = null;
        String response1 = null;
        BufferedReader br = null;
        try {


            URL url = new URL(appProperties.getSummary());
            HttpURLConnection conn = (HttpURLConnection) url.openConnection();
            conn.setRequestMethod("GET");
            conn.setRequestProperty("Accept", "application/json");

            if (conn.getResponseCode() != 200) {
                throw new RuntimeException("Failed : HTTP error code : "
                        + conn.getResponseCode());
            }

            br = new BufferedReader(new InputStreamReader(
                    (conn.getInputStream())));


            while ((output = br.readLine()) != null) {
                response1 = output;

            }

            conn.disconnect();

        } catch (MalformedURLException e) {

            LOGGER.error(e.getMessage());

        } catch (IOException e) {

            LOGGER.error(e.getMessage());

        } finally {
            safeClose(br);
        }
        return response1;
    }*/

    private void safeClose(Closeable closeable) {
        if (closeable != null) {
            try {
                closeable.close();
            } catch (IOException e) {
                LOGGER.error(e.getMessage());
            }
        }
    }


    /*public String getAcor(String source, String chid) {
        StringBuffer response = new StringBuffer();
        String output = null;
        String response1 = null;
        try {
            // source=b51&actor=ACT139212293
            String queryparameter = "source=" + source + "&actor=" + chid;
            URL url = new URL(appProperties.getActorservice() + queryparameter);
            HttpURLConnection conn = (HttpURLConnection) url.openConnection();
            conn.setRequestMethod("GET");
            conn.setRequestProperty("Accept", "application/json");
            if (conn.getResponseCode() != 200) {
                throw new RuntimeException("Failed : HTTP error code : "
                        + conn.getResponseCode());
            }
            BufferedReader br = new BufferedReader(new InputStreamReader(
                    (conn.getInputStream())));
            while ((output = br.readLine()) != null) {
                response1 = output;
            }
            conn.disconnect();
        } catch (MalformedURLException e) {
            LOGGER.error(e.getMessage());
        } catch (IOException e) {
            LOGGER.error(e.getMessage());
        }
        return response1;
    }*/

    /*public String getstats(String population) {
        StringBuffer response = new StringBuffer();
        String output = null;
        String response1 = null;
        String stats = null;
        try {

            if ("gold".equalsIgnoreCase(population)) {
                stats = appProperties.getStats();
            } else {
                stats = appProperties.getHeliumstats();

            }

            URL url = new URL(stats);
            HttpURLConnection conn = (HttpURLConnection) url.openConnection();
            conn.setRequestMethod("GET");
            conn.setRequestProperty("Accept", "application/json");

            if (conn.getResponseCode() != 200) {
                throw new RuntimeException("Failed : HTTP error code : "
                        + conn.getResponseCode());
            }

            BufferedReader br = new BufferedReader(new InputStreamReader(
                    (conn.getInputStream())));


            while ((output = br.readLine()) != null) {
                response1 = output;

            }

            conn.disconnect();

        } catch (MalformedURLException e) {

            LOGGER.error(e.getMessage());

        } catch (IOException e) {

            LOGGER.error(e.getStackTrace().toString());

        }
        return response1;
    }*/


}




