package com.uhg.ihr.model;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class TicketInfo {

    boolean success = false;
    private String number;
    private String assignment_group_value;
    private String state;
    private String status;

}

