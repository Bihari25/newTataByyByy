package com.uhg.ihr.model;

import java.util.List;

public class PacketViewerResponse {

    List<PacketResponse> packets;
    boolean canRequestPackets;

    public List<PacketResponse> getPackets() { return packets; }

    public void setPackets(List<PacketResponse> packets) { this.packets = packets; }

    public boolean isCanRequestPackets() { return canRequestPackets; }

    public void setCanRequestPackets(boolean canRequestPackets) { this.canRequestPackets = canRequestPackets; }
}
