package com.uhg.ihr.model;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class SenzingResult {

    String fullName;
    String chid;
    String dob;
    String senzingMatchKey;
    String identifiers;
    String gender;
    Integer senzingMatchLevel;
    String address;
    String actorType;
}
