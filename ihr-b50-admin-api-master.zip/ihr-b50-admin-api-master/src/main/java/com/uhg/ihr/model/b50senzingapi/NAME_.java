package com.uhg.ihr.model.b50senzingapi;

import com.fasterxml.jackson.annotation.*;
import org.apache.commons.lang3.builder.EqualsBuilder;
import org.apache.commons.lang3.builder.HashCodeBuilder;
import org.apache.commons.lang3.builder.ToStringBuilder;

import java.util.HashMap;
import java.util.Map;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
        "NAME_LAST",
        "NAME_MIDDLE",
        "NAME_FIRST"
})
public class NAME_ {

    @JsonProperty("NAME_LAST")
    private String nAMELAST;
    @JsonProperty("NAME_MIDDLE")
    private String nAMEMIDDLE;
    @JsonProperty("NAME_FIRST")
    private String nAMEFIRST;
    @JsonIgnore
    private Map<String, Object> additionalProperties = new HashMap<String, Object>();

    @JsonProperty("NAME_LAST")
    public String getNAMELAST() {
        return nAMELAST;
    }

    @JsonProperty("NAME_LAST")
    public void setNAMELAST(String nAMELAST) {
        this.nAMELAST = nAMELAST;
    }

    @JsonProperty("NAME_MIDDLE")
    public String getNAMEMIDDLE() {
        return nAMEMIDDLE;
    }

    @JsonProperty("NAME_MIDDLE")
    public void setNAMEMIDDLE(String nAMEMIDDLE) {
        this.nAMEMIDDLE = nAMEMIDDLE;
    }

    @JsonProperty("NAME_FIRST")
    public String getNAMEFIRST() {
        return nAMEFIRST;
    }

    @JsonProperty("NAME_FIRST")
    public void setNAMEFIRST(String nAMEFIRST) {
        this.nAMEFIRST = nAMEFIRST;
    }

    @Override
    public String toString() {
        return ToStringBuilder.reflectionToString(this);
    }

    @JsonAnyGetter
    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    @JsonAnySetter
    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

    @Override
    public int hashCode() {
        return new HashCodeBuilder().append(nAMELAST).append(nAMEMIDDLE).append(nAMEFIRST).append(additionalProperties).toHashCode();
    }

    @Override
    public boolean equals(Object other) {
        if (other == this) {
            return true;
        }
        if ((other instanceof NAME_) == false) {
            return false;
        }
        NAME_ rhs = ((NAME_) other);
        return new EqualsBuilder().append(nAMELAST, rhs.nAMELAST).append(nAMEMIDDLE, rhs.nAMEMIDDLE).append(nAMEFIRST, rhs.nAMEFIRST).append(additionalProperties, rhs.additionalProperties).isEquals();
    }

}
