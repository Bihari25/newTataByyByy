package com.uhg.ihr.services;

import com.uhg.ihr.dao.IHRCollections;
import com.uhg.ihr.model.AppProperties;
import com.uhg.ihr.model.PacketRefileResponse;
import com.uhg.ihr.model.PacketResponse;
import com.uhg.ihr.model.UserAuditInfo;
import org.bson.Document;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Component
public class IHRMongoCounts {

    private static Logger LOGGER = LoggerFactory.getLogger(IHRMongoCounts.class);

    public static String DB_MAP_PAYLOAD = "payload";
    public static String DB_MAP_LINE = "line";
    public static String DB_MAP_NODOC = "nodoc";
    private static Map<String, String> kafkaMongoSourceTargetCollectionNamesMap = new HashMap<>();

    @Autowired
    AppProperties appProperties;

    @Autowired
    IHRCollections collections;

    public String getRelationshipDocument(String b50line, String chid) {
        Document relSbrdoc = null;
        if (b50line.equalsIgnoreCase(appProperties.getB50mongoline())) {
            relSbrdoc = collections.getDocumentFromMongo(appProperties.getB50mongosbruser(), appProperties.getB50mongosbrpassword(), appProperties.getB50mongosbrhost(),
                    appProperties.getB50mongosbrport(), "", appProperties.getB50mongosbrdb(), checkIf5line(appProperties.getB50mongosbrcollection(), chid), chid);
        } else if (b50line.equalsIgnoreCase(appProperties.getB50mongoline2nd())) {
            relSbrdoc = collections.getDocumentFromMongo(appProperties.getB50mongosbruser(), appProperties.getB50mongosbrpassword(), appProperties.getB50mongosbrhost(),
                    appProperties.getB50mongosbrport(), "", appProperties.getB50mongosbrdb(), checkIf5line(appProperties.getB50mongosbrcollection2nd(), chid), chid);
        } else {
            LOGGER.error(" -unable to fetch relationSBR document for given line - " + b50line + " and chid - " + chid);
        }

        if (relSbrdoc == null) {
            LOGGER.error(" -got empty/null relationship document for chid - " + chid + ", in line-" + b50line);
            return "{\"msg\":\"no rel sbr document for this user - " + chid + "\"}";
        } else {
            return relSbrdoc.toJson();
        }
    }

    private String checkIf5line(String collectionName, String chid) {
        if ("5line".equalsIgnoreCase(collectionName)) {
            String fiveline = collections.get5lineFromChid(chid);
            return "ihr_" + fiveline + "_sbr_rel_mstr";
        } else {
            return collectionName;
        }
    }

    public String getProviderDemographicsDocument(String chid) {
        Document providerDoc = null;
        providerDoc = collections.getDocumentFromMongo(appProperties.getB50mongosbruser(), appProperties.getB50mongosbrpassword(), appProperties.getB50mongosbrhost(),
                appProperties.getB50mongosbrport(), "", appProperties.getB50mongoprovdb(), appProperties.getB50mongoprovcoll(), chid);

        if (providerDoc == null) {
            LOGGER.info(" - no provider document found for user - " + chid);
            return  null;//"{\"msg\":\"no provider document found for user - " + chid + "\"}";
        } else {
            return providerDoc.toJson();
        }
    }


    public HashMap getMap(String chid) {

        HashMap map = new HashMap();

        Document document;

        String jsonString;
        document = collections.getDocumentFromMongo(appProperties.getB50mongouser(), appProperties.getB50mongopassword(), appProperties.getB50mongohost(),
                appProperties.getB50mongoport(), appProperties.getB50mongodbconnstr(), appProperties.getB50mongodb(), appProperties.getB50mongocollection(), chid);
        if (document == null && appProperties.isSecondaryDBEnabled()) {
            LOGGER.info(" - Trying to fetch from secondary DB.");
            document = collections.getDocumentFromMongo(appProperties.getB50mongouser2nd(), appProperties.getB50mongopassword2nd(), appProperties.getB50mongohost2nd(),
                    appProperties.getB50mongoport2nd(), appProperties.getB50mongodbconnstr2nd(), appProperties.getB50mongodb2nd(), appProperties.getB50mongocollname2nd(), chid);
            if (document != null) {
                map.put(IHRMongoCounts.DB_MAP_LINE, appProperties.getB50mongoline2nd());
            }

        } else {
            map.put(IHRMongoCounts.DB_MAP_LINE, appProperties.getB50mongoline());
        }

        if (document == null) {
            LOGGER.info(" - Got empty transcriber document for chid - " + chid);
            jsonString = "{\"msg\":\"no document for this user - " + chid + "\"}";
            map.put(IHRMongoCounts.DB_MAP_NODOC, true);
        } else {
            jsonString = document.toJson();
        }

        map.put(IHRMongoCounts.DB_MAP_PAYLOAD, jsonString);

        return map;
    }

    public List<PacketResponse> getPacketResponseListFromMongo(String actorChid) {
        if (kafkaMongoSourceTargetCollectionNamesMap.isEmpty()) {
            String kafkaMongoSourceTargetCollectionNames = appProperties.getMongoPrSourceTargetCollectionNames();
            kafkaMongoSourceTargetCollectionNamesMap = new HashMap();
            Arrays.stream(kafkaMongoSourceTargetCollectionNames.split(","))
                    .forEach(kafkaMongoSourceTargetCollectionName -> {
                        String[] kafkaMongoSourceTargetCollectionNameArray = kafkaMongoSourceTargetCollectionName.split("~");
                        kafkaMongoSourceTargetCollectionNamesMap.put(kafkaMongoSourceTargetCollectionNameArray[0], kafkaMongoSourceTargetCollectionNameArray[1]);
                    });
        }
        List<PacketResponse> packetResponseList = new ArrayList<>();
        for (String kafkaMongoSourceCollectionName : kafkaMongoSourceTargetCollectionNamesMap.keySet()) {
            packetResponseList.addAll(collections.getPacketResponseListFromMongo(appProperties.getMongoPrUser(), appProperties.getMongoPrPwd(), appProperties.getMongoPrHost(),
                    appProperties.getMongoPrPort(), appProperties.getMongoPrConnectionString(), appProperties.getMongoPrSourceDbName(), kafkaMongoSourceCollectionName, actorChid));
        }

        if (packetResponseList.isEmpty()) {
            LOGGER.error("Got empty packet list for actor chid - " + actorChid);
        }
        return packetResponseList;
    }

    public List<PacketRefileResponse> packetRefile(String actorId, String[] uuids, String[] collNames) {
        List<PacketRefileResponse> refileResponses = collections.packetRefile(appProperties.getMongoPrUser(), appProperties.getMongoPrPwd(), appProperties.getMongoPrHost(),
                appProperties.getMongoPrPort(), appProperties.getMongoPrConnectionString(), appProperties.getMongoPrSourceDbName(), actorId, uuids, collNames);

        if (refileResponses.isEmpty()) {
            LOGGER.error(" Got empty refile message for uuids "+uuids);
        }
        return refileResponses;
    }

    public String getPayloadOfPacketByUUID(String sourceCollName, String actorId, String uuid) {
        Document packet = null;
        packet = collections.getPayloadOfPacketByUUID(
                appProperties.getMongoPrUser(),
                appProperties.getMongoPrPwd(),
                appProperties.getMongoPrHost(),
                appProperties.getMongoPrPort(),
                appProperties.getMongoPrConnectionString(),
                appProperties.getMongoPrSourceDbName(),
                sourceCollName,
                actorId,
                uuid);

        if (packet == null) {
            LOGGER.error(" -got empty/null packet document for uuid - " + uuid);
            return null;
        } else {
            return packet.toJson();
        }
    }

    public UserAuditInfo delActrIdAndCopyDoc(String chid, UserAuditInfo userAuditInfo) {

        return collections.delActrIdAndCopyDoc(
                appProperties.getB50mongouser(),
                appProperties.getB50mongopassword(),
                appProperties.getB50mongohost(),
                appProperties.getB50mongoport(),
                appProperties.getB50mongodbconnstr(),
                appProperties.getB50mongodb(),
                appProperties.getB50mongosbrhost(),
                appProperties.getB50mongosbrport(),
                appProperties.getB50mongodbconnstr(),
                appProperties.getB50mongosbrdb(),
                appProperties.getB50TranTblName(),
                appProperties.getSbrMstrTblNames(),
                appProperties.getSbrRelMstrTblNames(),
                chid,
                userAuditInfo
        );
    }
}
