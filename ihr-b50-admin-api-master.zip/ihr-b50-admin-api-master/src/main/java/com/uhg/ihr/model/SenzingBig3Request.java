package com.uhg.ihr.model;


import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.springframework.stereotype.Component;

@Component
@JsonInclude(JsonInclude.Include.NON_NULL)
@Data
@AllArgsConstructor
@NoArgsConstructor
public class SenzingBig3Request {

    @JsonProperty("NAME_FIRST")
    private String firstName;
    @JsonProperty("NAME_LAST")
    private String lastname;
    @JsonProperty("DATE_OF_BIRTH")
    private String dob;
    @JsonProperty("subscriber_id")
    private String subscriberId;
    @JsonProperty("subscriber_id_pad")
    private String subscriberIdPad;
    @JsonProperty("search_id")
    private String searchID;

}

