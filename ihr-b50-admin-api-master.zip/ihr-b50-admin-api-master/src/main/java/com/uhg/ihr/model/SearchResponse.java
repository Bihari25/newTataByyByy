package com.uhg.ihr.model;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;
import java.util.List;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class SearchResponse implements Serializable {

	private static final long serialVersionUID = 1L;
	private String payload;
	private String ddsViewer;
	private String fullName;
    private ParsedName parsedName;
    private List<KeyValuePair<String,String>> partialIdentifiers;
    private String dob;
	private String line;
	private String actorId;
	private String actorType;
	private boolean isParital;
	private List<SenzingResult> partialResults;
	private String relationshipDocument;
	private String providerSpecialities;

}