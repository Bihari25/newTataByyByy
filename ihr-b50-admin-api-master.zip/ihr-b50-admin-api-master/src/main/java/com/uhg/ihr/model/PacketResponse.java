package com.uhg.ihr.model;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@AllArgsConstructor
@NoArgsConstructor
@Data
public class PacketResponse {

    private String id;
    private String actorid;
    private String file_name;
    private String interface_type;
    private String uuid;
    private  String topic_source;
    private String last_updated_dt;
    private  String userid;
    private  String status;
    private String sourceCollName;
    private String refileCount;
    private String refileType;
}
