package com.uhg.ihr.model.b50senzingapi;

import com.fasterxml.jackson.annotation.*;
import org.apache.commons.lang3.builder.EqualsBuilder;
import org.apache.commons.lang3.builder.HashCodeBuilder;
import org.apache.commons.lang3.builder.ToStringBuilder;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
        "CORRELATION_ID",
        "Global_Actor_ID",
        "NAMES",
        "GENDER",
        "DATE_OF_BIRTH",
        "SUBSCRIBER_RELATIONSHIP_TYPE",
        "IDENTIFIERS",
        "PHONES",
        "ADDRESSES",
        "DATA_SOURCE",
        "ENTITY_TYPE",
        "DSRC_ACTION",
        "LENS_CODE",
        "RECORD_ID"
})
public class OriginalSourceData {

    @JsonProperty("CORRELATION_ID")
    private String cORRELATIONID;
    @JsonProperty("Global_Actor_ID")
    private String globalActorID;
    @JsonProperty("NAMES")
    private List<NAME_> nAMES = new ArrayList<NAME_>();
    @JsonProperty("GENDER")
    private String gENDER;
    @JsonProperty("DATE_OF_BIRTH")
    private String dATEOFBIRTH;
    @JsonProperty("SUBSCRIBER_RELATIONSHIP_TYPE")
    private String sUBSCRIBERRELATIONSHIPTYPE;
    @JsonProperty("IDENTIFIERS")
    private List<IDENTIFIER> iDENTIFIERS = new ArrayList<IDENTIFIER>();
    @JsonProperty("PHONES")
    private List<PHONE> pHONES = new ArrayList<PHONE>();
    @JsonProperty("ADDRESSES")
    private List<ADDRESS_> aDDRESSES = new ArrayList<ADDRESS_>();
    @JsonProperty("DATA_SOURCE")
    private String dATASOURCE;
    @JsonProperty("ENTITY_TYPE")
    private String eNTITYTYPE;
    @JsonProperty("DSRC_ACTION")
    private String dSRCACTION;
    @JsonProperty("LENS_CODE")
    private String lENSCODE;
    @JsonProperty("RECORD_ID")
    private String rECORDID;
    @JsonIgnore
    private Map<String, Object> additionalProperties = new HashMap<String, Object>();

    @JsonProperty("CORRELATION_ID")
    public String getCORRELATIONID() {
        return cORRELATIONID;
    }

    @JsonProperty("CORRELATION_ID")
    public void setCORRELATIONID(String cORRELATIONID) {
        this.cORRELATIONID = cORRELATIONID;
    }

    @JsonProperty("Global_Actor_ID")
    public String getGlobalActorID() {
        return globalActorID;
    }

    @JsonProperty("Global_Actor_ID")
    public void setGlobalActorID(String globalActorID) {
        this.globalActorID = globalActorID;
    }

    @JsonProperty("NAMES")
    public List<NAME_> getNAMES() {
        return nAMES;
    }

    @JsonProperty("NAMES")
    public void setNAMES(List<NAME_> nAMES) {
        this.nAMES = nAMES;
    }

    @JsonProperty("GENDER")
    public String getGENDER() {
        return gENDER;
    }

    @JsonProperty("GENDER")
    public void setGENDER(String gENDER) {
        this.gENDER = gENDER;
    }

    @JsonProperty("DATE_OF_BIRTH")
    public String getDATEOFBIRTH() {
        return dATEOFBIRTH;
    }

    @JsonProperty("DATE_OF_BIRTH")
    public void setDATEOFBIRTH(String dATEOFBIRTH) {
        this.dATEOFBIRTH = dATEOFBIRTH;
    }

    @JsonProperty("SUBSCRIBER_RELATIONSHIP_TYPE")
    public String getSUBSCRIBERRELATIONSHIPTYPE() {
        return sUBSCRIBERRELATIONSHIPTYPE;
    }

    @JsonProperty("SUBSCRIBER_RELATIONSHIP_TYPE")
    public void setSUBSCRIBERRELATIONSHIPTYPE(String sUBSCRIBERRELATIONSHIPTYPE) {
        this.sUBSCRIBERRELATIONSHIPTYPE = sUBSCRIBERRELATIONSHIPTYPE;
    }

    @JsonProperty("IDENTIFIERS")
    public List<IDENTIFIER> getIDENTIFIERS() {
        return iDENTIFIERS;
    }

    @JsonProperty("IDENTIFIERS")
    public void setIDENTIFIERS(List<IDENTIFIER> iDENTIFIERS) {
        this.iDENTIFIERS = iDENTIFIERS;
    }

    @JsonProperty("PHONES")
    public List<PHONE> getPHONES() {
        return pHONES;
    }

    @JsonProperty("PHONES")
    public void setPHONES(List<PHONE> pHONES) {
        this.pHONES = pHONES;
    }

    @JsonProperty("ADDRESSES")
    public List<ADDRESS_> getADDRESSES() {
        return aDDRESSES;
    }

    @JsonProperty("ADDRESSES")
    public void setADDRESSES(List<ADDRESS_> aDDRESSES) {
        this.aDDRESSES = aDDRESSES;
    }

    @JsonProperty("DATA_SOURCE")
    public String getDATASOURCE() {
        return dATASOURCE;
    }

    @JsonProperty("DATA_SOURCE")
    public void setDATASOURCE(String dATASOURCE) {
        this.dATASOURCE = dATASOURCE;
    }

    @JsonProperty("ENTITY_TYPE")
    public String getENTITYTYPE() {
        return eNTITYTYPE;
    }

    @JsonProperty("ENTITY_TYPE")
    public void setENTITYTYPE(String eNTITYTYPE) {
        this.eNTITYTYPE = eNTITYTYPE;
    }

    @JsonProperty("DSRC_ACTION")
    public String getDSRCACTION() {
        return dSRCACTION;
    }

    @JsonProperty("DSRC_ACTION")
    public void setDSRCACTION(String dSRCACTION) {
        this.dSRCACTION = dSRCACTION;
    }

    @JsonProperty("LENS_CODE")
    public String getLENSCODE() {
        return lENSCODE;
    }

    @JsonProperty("LENS_CODE")
    public void setLENSCODE(String lENSCODE) {
        this.lENSCODE = lENSCODE;
    }

    @JsonProperty("RECORD_ID")
    public String getRECORDID() {
        return rECORDID;
    }

    @JsonProperty("RECORD_ID")
    public void setRECORDID(String rECORDID) {
        this.rECORDID = rECORDID;
    }

    @Override
    public String toString() {
        return ToStringBuilder.reflectionToString(this);
    }

    @JsonAnyGetter
    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    @JsonAnySetter
    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

    @Override
    public int hashCode() {
        return new HashCodeBuilder().append(cORRELATIONID).append(globalActorID).append(nAMES).append(gENDER).append(dATEOFBIRTH).append(sUBSCRIBERRELATIONSHIPTYPE).append(iDENTIFIERS).append(pHONES).append(aDDRESSES).append(dATASOURCE).append(eNTITYTYPE).append(dSRCACTION).append(lENSCODE).append(rECORDID).append(additionalProperties).toHashCode();
    }

    @Override
    public boolean equals(Object other) {
        if (other == this) {
            return true;
        }
        if ((other instanceof OriginalSourceData) == false) {
            return false;
        }
        OriginalSourceData rhs = ((OriginalSourceData) other);
        return new EqualsBuilder().append(cORRELATIONID, rhs.cORRELATIONID).append(globalActorID, rhs.globalActorID).append(nAMES, rhs.nAMES).append(gENDER, rhs.gENDER).append(dATEOFBIRTH, rhs.dATEOFBIRTH).append(sUBSCRIBERRELATIONSHIPTYPE, rhs.sUBSCRIBERRELATIONSHIPTYPE).append(iDENTIFIERS, rhs.iDENTIFIERS).append(pHONES, rhs.pHONES).append(aDDRESSES, rhs.aDDRESSES).append(dATASOURCE, rhs.dATASOURCE).append(eNTITYTYPE, rhs.eNTITYTYPE).append(dSRCACTION, rhs.dSRCACTION).append(lENSCODE, rhs.lENSCODE).append(rECORDID, rhs.rECORDID).append(additionalProperties, rhs.additionalProperties).isEquals();
    }

}
