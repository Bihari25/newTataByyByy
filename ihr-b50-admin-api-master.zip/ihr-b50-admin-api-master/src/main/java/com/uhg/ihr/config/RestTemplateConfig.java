package com.uhg.ihr.config;
import org.apache.http.client.HttpClient;
import org.apache.http.conn.ssl.SSLConnectionSocketFactory;
import org.apache.http.impl.client.HttpClients;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.client.HttpComponentsClientHttpRequestFactory;
import org.springframework.web.client.RestTemplate;
import javax.net.ssl.SSLContext;
import javax.net.ssl.TrustManagerFactory;
import java.io.*;
import java.security.KeyManagementException;
import java.security.KeyStore;
import java.security.NoSuchAlgorithmException;

@Configuration
public class RestTemplateConfig {

    private TrustManagerFactory trustManagerFactory;
    private static final String KEYSTORE_PATH = "configs/optum-root-ca.jks";
    private static final Logger LOGGER = LoggerFactory.getLogger(RestTemplateConfig.class);
    private static final String PASWD = "ty^7Uajn*9";

    @Bean
    RestTemplate restTemplate() throws NoSuchAlgorithmException, KeyManagementException {
        InputStream is = null;
        try {
            // Create a TrustManager that trusts the CAs in our KeyStore
            this.trustManagerFactory = TrustManagerFactory.getInstance(TrustManagerFactory.getDefaultAlgorithm());
            KeyStore ks = KeyStore.getInstance(KeyStore.getDefaultType());
            File file = new File(KEYSTORE_PATH);
            if (!file.exists()) {
                LOGGER.error("could not find keystore at {}", KEYSTORE_PATH);
            } else {
                is = new FileInputStream(file);
                LOGGER.info("using keystore at {}", file.getAbsolutePath());
            }
            ks.load(is, PASWD.toCharArray());
            trustManagerFactory.init(ks);
        } catch (Exception e) {
            throw new RuntimeException("unable to initialize the trustManagerFactory", e);
        } finally {
            safeClose(is);
        }
        SSLContext sslContext = SSLContext.getInstance("SSL");
        sslContext.init(null, trustManagerFactory.getTrustManagers(), new java.security.SecureRandom());
        SSLConnectionSocketFactory socketFactory = new SSLConnectionSocketFactory(sslContext);
        HttpClient httpClient = HttpClients.custom()
                .setSSLSocketFactory(socketFactory)
                .build();
        HttpComponentsClientHttpRequestFactory factory =
                new HttpComponentsClientHttpRequestFactory(httpClient);
        return new RestTemplate(factory);
    }

    private void safeClose(Closeable closeable) {
        if (closeable != null) {
            try {
                closeable.close();
            } catch (IOException e) {
                LOGGER.error(e.getMessage());
            }
        }
    }
}