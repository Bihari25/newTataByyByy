package com.uhg.ihr.services;

import com.uhg.ihr.model.AppProperties;
import com.uhg.ihr.model.TicketInfo;
import org.apache.commons.codec.binary.Base64;
import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpEntity;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpMethod;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Component;
import org.springframework.web.client.RestTemplate;

import java.net.URI;
import java.nio.charset.Charset;
import java.sql.Timestamp;
import java.text.ParseException;
import java.util.Calendar;

@Component
public class ServiceNowRequest {
    private static final String ACCEPT_TYPE = "application/json";
    private final Logger logger = LoggerFactory.getLogger(getClass());
    @Autowired
   private RestTemplate restTemplate;

    @Autowired
   private AppProperties appProperties;

    public TicketInfo validateTicketOnSubmit(String serviceTicketNumber) throws ParseException, JSONException {
        TicketInfo info = null;
        if (serviceTicketNumber.startsWith("CHG")) {
            info = validateChngTicketNumber(serviceTicketNumber, String.valueOf(new Timestamp(Calendar.getInstance().getTime().getTime())));
        } else if (serviceTicketNumber.startsWith("INC")) {
            info = validateIncTicketNumber(serviceTicketNumber);
        }

        return info;
    }

    private TicketInfo validateChngTicketNumber(String chngCtrlNbr, String schdDtTime) throws ParseException {
        TicketInfo ticketInfo = new TicketInfo();

        StringBuilder qryString = new StringBuilder();
        qryString.append("change_request?sysparm_query=number%3D").append(chngCtrlNbr)
                .append("&sysparm_fields=state%2Cassignment_group&sysparm_limit=1");

        logger.info("Requested Url: " + qryString);
        String changeRequestDtlsResponce = getServiceNowRequestDtls(qryString);

        JSONObject jobj = new JSONObject(changeRequestDtlsResponce);
        JSONArray jarry = jobj.getJSONArray("result");

        if (jarry.length() == 1) {
            JSONObject resultJson = jarry.getJSONObject(0);
            ticketInfo.setSuccess(true);
            ticketInfo.setNumber(chngCtrlNbr);
            ticketInfo.setState(resultJson.getString("state"));
            ticketInfo.setAssignment_group_value(jarry.getJSONObject(0).getJSONObject("assignment_group").getString("value"));
            ticketInfo.setStatus(getChngStatus(resultJson.getString("state")));
        }
        return ticketInfo;
    }

    private String getChngStatus(String state) {
        switch (state) {
            case "-1":
                return "Draft";
            case "0":
                return "To Be Approved";
            case "1":
                return "Open/ Approved to Implement";
            case "2":
                return "Work In Progress";
            case "6":
                return "Awaiting Closure";
            case "7":
                return "Closed/ Closed Skipped";
            case "8":
                return "Cancelled";
            case "-5":
                return "Pending";
            case "3":
                return "Closed Complete";
            case "4":
                return "Closed Incomplete";
            default:
                return "ticket state value not found";
        }
    }

    private TicketInfo validateIncTicketNumber(String serviceTicketNumber) {
        logger.info("Start: Validating Incident Number: " + serviceTicketNumber);
        TicketInfo ticketInfo = new TicketInfo();
        StringBuilder qryString = new StringBuilder();
        qryString.append("incident?sysparm_query=number%3D").append(serviceTicketNumber)
                .append("&sysparm_fields=state%2Cassignment_group&sysparm_limit=1");

        logger.info("Requested Url: " + qryString);
        String requestDtlsResponce = getServiceNowRequestDtls(qryString);
        logger.info("responce  " + requestDtlsResponce);

        try {
            JSONObject jsonObject = new JSONObject(requestDtlsResponce);
            JSONArray jsonArray = jsonObject.getJSONArray("result");

            if (jsonArray.length() == 1) {
                JSONObject resultJson = jsonArray.getJSONObject(0);
                ticketInfo.setNumber(serviceTicketNumber);
                ticketInfo.setState(resultJson.getString("state"));
                ticketInfo.setAssignment_group_value(jsonArray.getJSONObject(0).getJSONObject("assignment_group").getString("value"));
                ticketInfo.setSuccess(true);
                ticketInfo.setStatus(getIncStatus(resultJson.getString("state")));
            }
        } catch(Exception e) {
            logger.error("Unable to Parse Service Now json object responce  " + e.getMessage());
            throw new RuntimeException("Unable to Parse Service Now json object responce " + e.getStackTrace());
        }

        return ticketInfo;
    }

    private String getIncStatus(String state) {
        switch (state) {
            case "1":
                return "Open/ To Be Worked";
            case "2":
                return "Work In Progress";
            case "3":
                return "Restored/ Closed Complete";
            case "6":
                return "Pending Closure";
            case "7":
                return "Closed/ Closed Skipped";
            case "4":
                return "Waiting - Client/ Closed Incomplete";
            case "5":
                return "Waiting - IT";
            case "8":
                return "Cancelled";
            case "-5":
                return "Pending";
            default:
                return "ticket state value not found";
        }
    }

    private String getServiceNowRequestDtls(StringBuilder qryString) {
        String reqEntityBody = null;
        try {
            StringBuilder requestURL = new StringBuilder(appProperties.getServiceNowUrl());
            requestURL.append(qryString);
            logger.info("Requesting full Url: " + requestURL);

            URI requestURI = null;
            requestURI = new URI(requestURL.toString());

            String auth = appProperties.getServiceNowAuth();
            byte[] encodedAuth = Base64.encodeBase64(auth.getBytes(Charset.forName("US-ASCII")));
            String authHeader = "Basic " + new String(encodedAuth,"US-ASCII");

            HttpHeaders headers = new HttpHeaders();
            headers.set("Authorization", authHeader);
            headers.set("Accept", ACCEPT_TYPE);

            HttpEntity<String> entity = new HttpEntity<>("parameters", headers);

            ResponseEntity<String> rEntity = restTemplate.exchange(requestURI, HttpMethod.GET, entity, String.class);

            reqEntityBody = rEntity.getBody();

        } catch(Exception e) {
            logger.error("Exception Occured While fetching Change ticket/Incident Details -> " + e.getMessage());
            throw new InternalError("Unable to fetch Change ticket/Incident details "+e.getMessage());
        }
        return reqEntityBody;
    }

}