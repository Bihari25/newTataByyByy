package com.uhg.ihr.model.b50senzingapi;

import com.fasterxml.jackson.annotation.*;
import org.apache.commons.lang3.builder.EqualsBuilder;
import org.apache.commons.lang3.builder.HashCodeBuilder;
import org.apache.commons.lang3.builder.ToStringBuilder;

import java.util.HashMap;
import java.util.Map;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
        "ADDR_LINE1",
        "ADDR_POSTAL_CODE",
        "ADDR_COUNTRY",
        "ADDR_STATE",
        "ADDR_CITY",
        "ADDR_TYPE"
})
public class ADDRESS_ {

    @JsonProperty("ADDR_LINE1")
    private String aDDRLINE1;
    @JsonProperty("ADDR_POSTAL_CODE")
    private String aDDRPOSTALCODE;
    @JsonProperty("ADDR_COUNTRY")
    private String aDDRCOUNTRY;
    @JsonProperty("ADDR_STATE")
    private String aDDRSTATE;
    @JsonProperty("ADDR_CITY")
    private String aDDRCITY;
    @JsonProperty("ADDR_TYPE")
    private String aDDRTYPE;
    @JsonIgnore
    private Map<String, Object> additionalProperties = new HashMap<String, Object>();

    @JsonProperty("ADDR_LINE1")
    public String getADDRLINE1() {
        return aDDRLINE1;
    }

    @JsonProperty("ADDR_LINE1")
    public void setADDRLINE1(String aDDRLINE1) {
        this.aDDRLINE1 = aDDRLINE1;
    }

    @JsonProperty("ADDR_POSTAL_CODE")
    public String getADDRPOSTALCODE() {
        return aDDRPOSTALCODE;
    }

    @JsonProperty("ADDR_POSTAL_CODE")
    public void setADDRPOSTALCODE(String aDDRPOSTALCODE) {
        this.aDDRPOSTALCODE = aDDRPOSTALCODE;
    }

    @JsonProperty("ADDR_COUNTRY")
    public String getADDRCOUNTRY() {
        return aDDRCOUNTRY;
    }

    @JsonProperty("ADDR_COUNTRY")
    public void setADDRCOUNTRY(String aDDRCOUNTRY) {
        this.aDDRCOUNTRY = aDDRCOUNTRY;
    }

    @JsonProperty("ADDR_STATE")
    public String getADDRSTATE() {
        return aDDRSTATE;
    }

    @JsonProperty("ADDR_STATE")
    public void setADDRSTATE(String aDDRSTATE) {
        this.aDDRSTATE = aDDRSTATE;
    }

    @JsonProperty("ADDR_CITY")
    public String getADDRCITY() {
        return aDDRCITY;
    }

    @JsonProperty("ADDR_CITY")
    public void setADDRCITY(String aDDRCITY) {
        this.aDDRCITY = aDDRCITY;
    }

    @JsonProperty("ADDR_TYPE")
    public String getADDRTYPE() {
        return aDDRTYPE;
    }

    @JsonProperty("ADDR_TYPE")
    public void setADDRTYPE(String aDDRTYPE) {
        this.aDDRTYPE = aDDRTYPE;
    }

    @Override
    public String toString() {
        return ToStringBuilder.reflectionToString(this);
    }

    @JsonAnyGetter
    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    @JsonAnySetter
    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

    @Override
    public int hashCode() {
        return new HashCodeBuilder().append(aDDRLINE1).append(aDDRPOSTALCODE).append(aDDRCOUNTRY).append(aDDRSTATE).append(aDDRCITY).append(aDDRTYPE).append(additionalProperties).toHashCode();
    }

    @Override
    public boolean equals(Object other) {
        if (other == this) {
            return true;
        }
        if ((other instanceof ADDRESS_) == false) {
            return false;
        }
        ADDRESS_ rhs = ((ADDRESS_) other);
        return new EqualsBuilder().append(aDDRLINE1, rhs.aDDRLINE1).append(aDDRPOSTALCODE, rhs.aDDRPOSTALCODE).append(aDDRCOUNTRY, rhs.aDDRCOUNTRY).append(aDDRSTATE, rhs.aDDRSTATE).append(aDDRCITY, rhs.aDDRCITY).append(aDDRTYPE, rhs.aDDRTYPE).append(additionalProperties, rhs.additionalProperties).isEquals();
    }

}
