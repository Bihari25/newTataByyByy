package com.uhg.ihr.model;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@AllArgsConstructor
@NoArgsConstructor
public class Big3Request {

    String firstName;
    String lastName;
    String searchId;
    String birthday;

}
