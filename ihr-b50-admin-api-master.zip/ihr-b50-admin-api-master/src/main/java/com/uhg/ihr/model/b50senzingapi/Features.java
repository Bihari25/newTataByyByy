package com.uhg.ihr.model.b50senzingapi;

import com.fasterxml.jackson.annotation.*;
import org.apache.commons.lang3.builder.EqualsBuilder;
import org.apache.commons.lang3.builder.HashCodeBuilder;
import org.apache.commons.lang3.builder.ToStringBuilder;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
        "ADDRESS",
        "CARDHOLDER_ID",
        "DOB",
        "GENDER",
        "GLOBAL_ACTOR_ID",
        "MEDICARE_BENF_ID",
        "MEDICARE_NUMBER",
        "NAME",
        "SSN",
        "SUBSCRIBER_ID"
})
public class Features {

    @JsonProperty("ADDRESS")
    private List<ADDRESS> aDDRESS = new ArrayList<ADDRESS>();
    @JsonProperty("CARDHOLDER_ID")
    private List<CARDHOLDERID> cARDHOLDERID = new ArrayList<CARDHOLDERID>();
    @JsonProperty("DOB")
    private List<DOB> dOB = new ArrayList<DOB>();
    @JsonProperty("GENDER")
    private List<GENDER> gENDER = new ArrayList<GENDER>();
    @JsonProperty("GLOBAL_ACTOR_ID")
    private List<GLOBALACTORID> gLOBALACTORID = new ArrayList<GLOBALACTORID>();
    @JsonProperty("MEDICARE_BENF_ID")
    private List<MEDICAREBENFID> mEDICAREBENFID = new ArrayList<MEDICAREBENFID>();
    @JsonProperty("MEDICARE_NUMBER")
    private List<MEDICARENUMBER> mEDICARENUMBER = new ArrayList<MEDICARENUMBER>();
    @JsonProperty("NAME")
    private List<NAME> nAME = new ArrayList<NAME>();
    @JsonProperty("SSN")
    private List<SSN> sSN = new ArrayList<SSN>();
    @JsonProperty("SUBSCRIBER_ID")
    private List<SUBSCRIBERID> sUBSCRIBERID = new ArrayList<SUBSCRIBERID>();
    @JsonIgnore
    private Map<String, Object> additionalProperties = new HashMap<String, Object>();

    @JsonProperty("ADDRESS")
    public List<ADDRESS> getADDRESS() {
        return aDDRESS;
    }

    @JsonProperty("ADDRESS")
    public void setADDRESS(List<ADDRESS> aDDRESS) {
        this.aDDRESS = aDDRESS;
    }

    @JsonProperty("CARDHOLDER_ID")
    public List<CARDHOLDERID> getCARDHOLDERID() {
        return cARDHOLDERID;
    }

    @JsonProperty("CARDHOLDER_ID")
    public void setCARDHOLDERID(List<CARDHOLDERID> cARDHOLDERID) {
        this.cARDHOLDERID = cARDHOLDERID;
    }

    @JsonProperty("DOB")
    public List<DOB> getDOB() {
        return dOB;
    }

    @JsonProperty("DOB")
    public void setDOB(List<DOB> dOB) {
        this.dOB = dOB;
    }

    @JsonProperty("GENDER")
    public List<GENDER> getGENDER() {
        return gENDER;
    }

    @JsonProperty("GENDER")
    public void setGENDER(List<GENDER> gENDER) {
        this.gENDER = gENDER;
    }

    @JsonProperty("GLOBAL_ACTOR_ID")
    public List<GLOBALACTORID> getGLOBALACTORID() {
        return gLOBALACTORID;
    }

    @JsonProperty("GLOBAL_ACTOR_ID")
    public void setGLOBALACTORID(List<GLOBALACTORID> gLOBALACTORID) {
        this.gLOBALACTORID = gLOBALACTORID;
    }

    @JsonProperty("MEDICARE_BENF_ID")
    public List<MEDICAREBENFID> getMEDICAREBENFID() {
        return mEDICAREBENFID;
    }

    @JsonProperty("MEDICARE_BENF_ID")
    public void setMEDICAREBENFID(List<MEDICAREBENFID> mEDICAREBENFID) {
        this.mEDICAREBENFID = mEDICAREBENFID;
    }

    @JsonProperty("MEDICARE_NUMBER")
    public List<MEDICARENUMBER> getMEDICARENUMBER() {
        return mEDICARENUMBER;
    }

    @JsonProperty("MEDICARE_NUMBER")
    public void setMEDICARENUMBER(List<MEDICARENUMBER> mEDICARENUMBER) {
        this.mEDICARENUMBER = mEDICARENUMBER;
    }

    @JsonProperty("NAME")
    public List<NAME> getNAME() {
        return nAME;
    }

    @JsonProperty("NAME")
    public void setNAME(List<NAME> nAME) {
        this.nAME = nAME;
    }

    @JsonProperty("SSN")
    public List<SSN> getSSN() {
        return sSN;
    }

    @JsonProperty("SSN")
    public void setSSN(List<SSN> sSN) {
        this.sSN = sSN;
    }

    @JsonProperty("SUBSCRIBER_ID")
    public List<SUBSCRIBERID> getSUBSCRIBERID() {
        return sUBSCRIBERID;
    }

    @JsonProperty("SUBSCRIBER_ID")
    public void setSUBSCRIBERID(List<SUBSCRIBERID> sUBSCRIBERID) {
        this.sUBSCRIBERID = sUBSCRIBERID;
    }

    @Override
    public String toString() {
        return ToStringBuilder.reflectionToString(this);
    }

    @JsonAnyGetter
    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    @JsonAnySetter
    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

    @Override
    public int hashCode() {
        return new HashCodeBuilder().append(aDDRESS).append(cARDHOLDERID).append(dOB).append(gENDER).append(gLOBALACTORID).append(mEDICAREBENFID).append(mEDICARENUMBER).append(nAME).append(sSN).append(sUBSCRIBERID).append(additionalProperties).toHashCode();
    }

    @Override
    public boolean equals(Object other) {
        if (other == this) {
            return true;
        }
        if ((other instanceof Features) == false) {
            return false;
        }
        Features rhs = ((Features) other);
        return new EqualsBuilder().append(aDDRESS, rhs.aDDRESS).append(cARDHOLDERID, rhs.cARDHOLDERID).append(dOB, rhs.dOB).append(gENDER, rhs.gENDER).append(gLOBALACTORID, rhs.gLOBALACTORID).append(mEDICAREBENFID, rhs.mEDICAREBENFID).append(mEDICARENUMBER, rhs.mEDICARENUMBER).append(nAME, rhs.nAME).append(sSN, rhs.sSN).append(sUBSCRIBERID, rhs.sUBSCRIBERID).append(additionalProperties, rhs.additionalProperties).isEquals();
    }

}
