package com.uhg.ihr.services;

import com.uhg.ihr.dao.DBHandler;
import com.uhg.ihr.model.PacketRequest;
import com.uhg.ihr.model.PacketResponse;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.List;

@Component
public class PacketService {

    @Autowired
    DBHandler dbHandler;

    @Autowired
    IHRMongoCounts ihrMongoCounts;

    public String addPacketSearchRequest(String chid, String userid) {

        int count = dbHandler.openRequests(userid,"Submitted");
        if (count < 20) {
            PacketRequest packetRequest = new PacketRequest();
            packetRequest.setActorId(chid);
            packetRequest.setUserId(userid);
            packetRequest.setStatus("Submitted");

            if (dbHandler.requestPacket(packetRequest) == 1) {
                return "Request Submitted Successfully";
            } else {
                return "internal server error";
            }

        } else {
            return "You have more than 20 open requests, please try after sometime";
        }
    }


    public List<PacketResponse> viewPacket(String chid, String userid) {
        return dbHandler.getPackets(userid, chid);
    }

    public List<PacketResponse> viewPacketForRefile(String chid, String userid) {
        return ihrMongoCounts.getPacketResponseListFromMongo(chid);
    }


    public List<PacketRequest> auditRequest(String userid) {
        List<PacketRequest> packetRequestList = dbHandler.auditpacket(userid);
        return packetRequestList;
    }

    public int numOfOpeRequests(String userId){
        return dbHandler.openRequests(userId,null);
    }


    public int deletePacket(String chid, String userid) {
        return dbHandler.deleteRequest(userid, chid);
    }

    public String getPayloadOfPacketByUUID(String uuid) {
        return dbHandler.fetchPayloadByUUID(uuid);
    }

    public String getPayloadOfPacketByUUID(String sourceCollName, String actorId, String uuid) {
        return ihrMongoCounts.getPayloadOfPacketByUUID(sourceCollName, actorId, uuid);
    }

}
