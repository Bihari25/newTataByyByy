package com.uhg.ihr.utils;

import io.jsonwebtoken.JwtBuilder;
import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.SignatureAlgorithm;
import io.jsonwebtoken.security.Keys;
import org.springframework.stereotype.Component;

import java.nio.charset.StandardCharsets;
import java.util.ArrayList;
import java.util.Date;

@Component
public class JWTHelper {

    public String createJWT(String tockenType, String issuer, String subject, long ttlMillis, String key) {
        long nowMillis = System.currentTimeMillis();
        Date now = new Date(nowMillis);
        ArrayList roles = new ArrayList();
        JwtBuilder builder = Jwts.builder().setHeaderParam("typ", tockenType).setIssuer(issuer).setSubject(subject)
                .setExpiration(new Date(ttlMillis)).setIssuedAt(new Date(System.currentTimeMillis()))
                .claim("rol", roles).signWith(Keys.hmacShaKeyFor(key.getBytes(StandardCharsets.US_ASCII)),
                        SignatureAlgorithm.HS512);
        if (ttlMillis >= 0) {
            long expMillis = nowMillis + ttlMillis;
            Date exp = new Date(expMillis);
            builder.setExpiration(exp);
        }
        //  System.out.println("Token: " + builder.compact());
        return builder.compact();
    }

}
