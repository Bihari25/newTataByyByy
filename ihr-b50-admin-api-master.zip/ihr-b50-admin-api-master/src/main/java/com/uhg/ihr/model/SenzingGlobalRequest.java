package com.uhg.ihr.model;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import org.springframework.stereotype.Component;

@Component
@JsonInclude(JsonInclude.Include.NON_NULL)
public class SenzingGlobalRequest {


    @JsonProperty("GLOBAL_ACTOR_ID")
    private String globalid;


    @JsonProperty("GLOBAL_ACTOR_ID")

    public String getGlobalid() {
        return globalid;
    }

    @JsonProperty("GLOBAL_ACTOR_ID")

    public void setGlobalid(String globalid) {
        this.globalid = globalid;
    }
}
