package com.uhg.ihr.model.auth;

import java.io.Serializable;

public class LoginRequest implements Serializable {

    private String username;
    private String password;

    // need default constructor for JSON Parsing
    public LoginRequest() { }

    public LoginRequest(String username, String password) {
        this.setUsername(username);
        this.setPassword(password);
    }

    public String getUsername() {
        return this.username;
    }

    private final void setUsername(String username) {
        this.username = username;
    }

    public String getPassword() {
        return this.password;
    }

    private final void setPassword(String password) {
        this.password = password;
    }
}
