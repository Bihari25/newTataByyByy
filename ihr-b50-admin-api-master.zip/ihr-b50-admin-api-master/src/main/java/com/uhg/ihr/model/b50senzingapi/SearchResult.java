package com.uhg.ihr.model.b50senzingapi;

import com.fasterxml.jackson.annotation.*;
import org.apache.commons.lang3.builder.EqualsBuilder;
import org.apache.commons.lang3.builder.HashCodeBuilder;
import org.apache.commons.lang3.builder.ToStringBuilder;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
        "entityId",
        "entityName",
        "bestName",
        "recordSummaries",
        "addressData",
        "attributeData",
        "identifierData",
        "nameData",
        "phoneData",
        "relationshipData",
        "otherData",
        "features",
        "records",
        "matchLevel",
        "fullNameScore",
        "matchScore",
        "ambiguous",
        "matchKey",
        "resolutionRuleCode",
        "refScore",
        "partial",
        "resultType"
})
public class SearchResult {

    @JsonProperty("entityId")
    private Integer entityId;
    @JsonProperty("entityName")
    private String entityName;
    @JsonProperty("bestName")
    private Object bestName;
    @JsonProperty("recordSummaries")
    private List<RecordSummary> recordSummaries = new ArrayList<RecordSummary>();
    @JsonProperty("addressData")
    private List<String> addressData = new ArrayList<String>();
    @JsonProperty("attributeData")
    private List<String> attributeData = new ArrayList<String>();
    @JsonProperty("identifierData")
    private List<String> identifierData = new ArrayList<String>();
    @JsonProperty("nameData")
    private List<String> nameData = new ArrayList<String>();
    @JsonProperty("phoneData")
    private List<Object> phoneData = new ArrayList<Object>();
    @JsonProperty("relationshipData")
    private List<Object> relationshipData = new ArrayList<Object>();
    @JsonProperty("otherData")
    private List<Object> otherData = new ArrayList<Object>();
    @JsonProperty("features")
    private Features features;
    @JsonProperty("records")
    private List<Record> records = new ArrayList<Record>();
    @JsonProperty("matchLevel")
    private Integer matchLevel;
    @JsonProperty("fullNameScore")
    private Integer fullNameScore;
    @JsonProperty("matchScore")
    private Integer matchScore;
    @JsonProperty("ambiguous")
    private Boolean ambiguous;
    @JsonProperty("matchKey")
    private String matchKey;
    @JsonProperty("resolutionRuleCode")
    private String resolutionRuleCode;
    @JsonProperty("refScore")
    private Integer refScore;
    @JsonProperty("partial")
    private Boolean partial;
    @JsonProperty("resultType")
    private String resultType;
    @JsonIgnore
    private Map<String, Object> additionalProperties = new HashMap<String, Object>();

    @JsonProperty("entityId")
    public Integer getEntityId() {
        return entityId;
    }

    @JsonProperty("entityId")
    public void setEntityId(Integer entityId) {
        this.entityId = entityId;
    }

    @JsonProperty("entityName")
    public String getEntityName() {
        return entityName;
    }

    @JsonProperty("entityName")
    public void setEntityName(String entityName) {
        this.entityName = entityName;
    }

    @JsonProperty("bestName")
    public Object getBestName() {
        return bestName;
    }

    @JsonProperty("bestName")
    public void setBestName(Object bestName) {
        this.bestName = bestName;
    }

    @JsonProperty("recordSummaries")
    public List<RecordSummary> getRecordSummaries() {
        return recordSummaries;
    }

    @JsonProperty("recordSummaries")
    public void setRecordSummaries(List<RecordSummary> recordSummaries) {
        this.recordSummaries = recordSummaries;
    }

    @JsonProperty("addressData")
    public List<String> getAddressData() {
        return addressData;
    }

    @JsonProperty("addressData")
    public void setAddressData(List<String> addressData) {
        this.addressData = addressData;
    }

    @JsonProperty("attributeData")
    public List<String> getAttributeData() {
        return attributeData;
    }

    @JsonProperty("attributeData")
    public void setAttributeData(List<String> attributeData) {
        this.attributeData = attributeData;
    }

    @JsonProperty("identifierData")
    public List<String> getIdentifierData() {
        return identifierData;
    }

    @JsonProperty("identifierData")
    public void setIdentifierData(List<String> identifierData) {
        this.identifierData = identifierData;
    }

    @JsonProperty("nameData")
    public List<String> getNameData() {
        return nameData;
    }

    @JsonProperty("nameData")
    public void setNameData(List<String> nameData) {
        this.nameData = nameData;
    }

    @JsonProperty("phoneData")
    public List<Object> getPhoneData() {
        return phoneData;
    }

    @JsonProperty("phoneData")
    public void setPhoneData(List<Object> phoneData) {
        this.phoneData = phoneData;
    }

    @JsonProperty("relationshipData")
    public List<Object> getRelationshipData() {
        return relationshipData;
    }

    @JsonProperty("relationshipData")
    public void setRelationshipData(List<Object> relationshipData) {
        this.relationshipData = relationshipData;
    }

    @JsonProperty("otherData")
    public List<Object> getOtherData() {
        return otherData;
    }

    @JsonProperty("otherData")
    public void setOtherData(List<Object> otherData) {
        this.otherData = otherData;
    }

    @JsonProperty("features")
    public Features getFeatures() {
        return features;
    }

    @JsonProperty("features")
    public void setFeatures(Features features) {
        this.features = features;
    }

    @JsonProperty("records")
    public List<Record> getRecords() {
        return records;
    }

    @JsonProperty("records")
    public void setRecords(List<Record> records) {
        this.records = records;
    }

    @JsonProperty("matchLevel")
    public Integer getMatchLevel() {
        return matchLevel;
    }

    @JsonProperty("matchLevel")
    public void setMatchLevel(Integer matchLevel) {
        this.matchLevel = matchLevel;
    }

    @JsonProperty("fullNameScore")
    public Integer getFullNameScore() {
        return fullNameScore;
    }

    @JsonProperty("fullNameScore")
    public void setFullNameScore(Integer fullNameScore) {
        this.fullNameScore = fullNameScore;
    }

    @JsonProperty("matchScore")
    public Integer getMatchScore() {
        return matchScore;
    }

    @JsonProperty("matchScore")
    public void setMatchScore(Integer matchScore) {
        this.matchScore = matchScore;
    }

    @JsonProperty("ambiguous")
    public Boolean getAmbiguous() {
        return ambiguous;
    }

    @JsonProperty("ambiguous")
    public void setAmbiguous(Boolean ambiguous) {
        this.ambiguous = ambiguous;
    }

    @JsonProperty("matchKey")
    public String getMatchKey() {
        return matchKey;
    }

    @JsonProperty("matchKey")
    public void setMatchKey(String matchKey) {
        this.matchKey = matchKey;
    }

    @JsonProperty("resolutionRuleCode")
    public String getResolutionRuleCode() {
        return resolutionRuleCode;
    }

    @JsonProperty("resolutionRuleCode")
    public void setResolutionRuleCode(String resolutionRuleCode) {
        this.resolutionRuleCode = resolutionRuleCode;
    }

    @JsonProperty("refScore")
    public Integer getRefScore() {
        return refScore;
    }

    @JsonProperty("refScore")
    public void setRefScore(Integer refScore) {
        this.refScore = refScore;
    }

    @JsonProperty("partial")
    public Boolean getPartial() {
        return partial;
    }

    @JsonProperty("partial")
    public void setPartial(Boolean partial) {
        this.partial = partial;
    }

    @JsonProperty("resultType")
    public String getResultType() {
        return resultType;
    }

    @JsonProperty("resultType")
    public void setResultType(String resultType) {
        this.resultType = resultType;
    }

    @Override
    public String toString() {
        return ToStringBuilder.reflectionToString(this);
    }

    @JsonAnyGetter
    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    @JsonAnySetter
    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

    @Override
    public int hashCode() {
        return new HashCodeBuilder().append(entityId).append(entityName).append(bestName).append(recordSummaries).append(addressData).append(attributeData).append(identifierData).append(nameData).append(phoneData).append(relationshipData).append(otherData).append(features).append(records).append(matchLevel).append(fullNameScore).append(matchScore).append(ambiguous).append(matchKey).append(resolutionRuleCode).append(refScore).append(partial).append(resultType).append(additionalProperties).toHashCode();
    }

    @Override
    public boolean equals(Object other) {
        if (other == this) {
            return true;
        }
        if ((other instanceof SearchResult) == false) {
            return false;
        }
        SearchResult rhs = ((SearchResult) other);
        return new EqualsBuilder().append(entityId, rhs.entityId).append(entityName, rhs.entityName).append(bestName, rhs.bestName).append(recordSummaries, rhs.recordSummaries).append(addressData, rhs.addressData).append(attributeData, rhs.attributeData).append(identifierData, rhs.identifierData).append(nameData, rhs.nameData).append(phoneData, rhs.phoneData).append(relationshipData, rhs.relationshipData).append(otherData, rhs.otherData).append(features, rhs.features).append(records, rhs.records).append(matchLevel, rhs.matchLevel).append(fullNameScore, rhs.fullNameScore).append(matchScore, rhs.matchScore).append(ambiguous, rhs.ambiguous).append(matchKey, rhs.matchKey).append(resolutionRuleCode, rhs.resolutionRuleCode).append(refScore, rhs.refScore).append(partial, rhs.partial).append(resultType, rhs.resultType).append(additionalProperties, rhs.additionalProperties).isEquals();
    }

}
