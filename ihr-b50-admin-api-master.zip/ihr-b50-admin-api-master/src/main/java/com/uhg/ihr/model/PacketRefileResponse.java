package com.uhg.ihr.model;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;


@AllArgsConstructor
@NoArgsConstructor
@Data
public class PacketRefileResponse {

    private String uuid;
    private String status;
    private String message;


}
