package com.uhg.ihr.config;

import javax.sql.DataSource;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.boot.jdbc.DataSourceBuilder;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.jdbc.core.JdbcTemplate;
import org.springframework.jdbc.core.namedparam.NamedParameterJdbcTemplate;

@Configuration
public class MultipleDBConfig {

    @Bean(name = "ihrtoolsDb")
    @ConfigurationProperties(prefix = "spring.datasource")
    public DataSource ihrtoolsDataSource() {
        return DataSourceBuilder.create().build();
    }

    @Bean(name = "ihrtoolsJdbcTemplate")
    public JdbcTemplate ihrtoolsJdbcTemplate(@Qualifier("ihrtoolsDb") DataSource dsIhrtools) {
        return new JdbcTemplate(dsIhrtools);
    }

    @Bean(name = "ihrtoolsNamedParameterJdbcTemplate")
    public NamedParameterJdbcTemplate ihrtoolsNamedParameterJdbcTemplate(@Qualifier("ihrtoolsDb") DataSource dsIhrtools) {
        return new NamedParameterJdbcTemplate(dsIhrtools);
    }

    @Bean(name = "ontsummaryDb")
    @ConfigurationProperties(prefix = "app.ontsummary")
    public DataSource ontsummaryDataSource() {
        return  DataSourceBuilder.create().build();
    }

    @Bean(name = "ontsummaryJdbcTemplate")
    public JdbcTemplate ontsummaryJdbcTemplate(@Qualifier("ontsummaryDb")
                                                     DataSource dsOntsummary) {
        return new JdbcTemplate(dsOntsummary);
    }
}
