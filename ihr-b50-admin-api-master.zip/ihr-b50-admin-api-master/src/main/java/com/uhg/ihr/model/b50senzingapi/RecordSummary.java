package com.uhg.ihr.model.b50senzingapi;

import com.fasterxml.jackson.annotation.*;
import org.apache.commons.lang3.builder.EqualsBuilder;
import org.apache.commons.lang3.builder.HashCodeBuilder;
import org.apache.commons.lang3.builder.ToStringBuilder;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
        "dataSource",
        "recordCount",
        "topRecordIds"
})
public class RecordSummary {

    @JsonProperty("dataSource")
    private String dataSource;
    @JsonProperty("recordCount")
    private Integer recordCount;
    @JsonProperty("topRecordIds")
    private List<String> topRecordIds = new ArrayList<String>();
    @JsonIgnore
    private Map<String, Object> additionalProperties = new HashMap<String, Object>();

    @JsonProperty("dataSource")
    public String getDataSource() {
        return dataSource;
    }

    @JsonProperty("dataSource")
    public void setDataSource(String dataSource) {
        this.dataSource = dataSource;
    }

    @JsonProperty("recordCount")
    public Integer getRecordCount() {
        return recordCount;
    }

    @JsonProperty("recordCount")
    public void setRecordCount(Integer recordCount) {
        this.recordCount = recordCount;
    }

    @JsonProperty("topRecordIds")
    public List<String> getTopRecordIds() {
        return topRecordIds;
    }

    @JsonProperty("topRecordIds")
    public void setTopRecordIds(List<String> topRecordIds) {
        this.topRecordIds = topRecordIds;
    }

    @Override
    public String toString() {
        return ToStringBuilder.reflectionToString(this);
    }

    @JsonAnyGetter
    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    @JsonAnySetter
    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

    @Override
    public int hashCode() {
        return new HashCodeBuilder().append(dataSource).append(recordCount).append(topRecordIds).append(additionalProperties).toHashCode();
    }

    @Override
    public boolean equals(Object other) {
        if (other == this) {
            return true;
        }
        if ((other instanceof RecordSummary) == false) {
            return false;
        }
        RecordSummary rhs = ((RecordSummary) other);
        return new EqualsBuilder().append(dataSource, rhs.dataSource).append(recordCount, rhs.recordCount).append(topRecordIds, rhs.topRecordIds).append(additionalProperties, rhs.additionalProperties).isEquals();
    }

}
