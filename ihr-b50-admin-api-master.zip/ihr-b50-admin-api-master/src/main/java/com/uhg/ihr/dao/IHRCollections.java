package com.uhg.ihr.dao;
import com.mongodb.MongoClient;
import com.mongodb.MongoClientSettings;
import com.mongodb.MongoClientURI;
import com.mongodb.MongoWriteException;
import com.mongodb.client.FindIterable;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoCursor;
import com.mongodb.client.MongoDatabase;
import com.mongodb.client.model.Filters;
import com.mongodb.client.model.Projections;
import com.mongodb.client.model.Updates;
import com.mongodb.client.result.UpdateResult;
import com.uhg.ihr.model.AppProperties;
import com.uhg.ihr.model.AuditInfo;
import com.uhg.ihr.model.PacketRefileResponse;
import com.uhg.ihr.model.PacketResponse;
import com.uhg.ihr.model.UserAuditInfo;
import org.bson.Document;
import org.bson.codecs.configuration.CodecRegistries;
import org.bson.conversions.Bson;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;
import java.io.UnsupportedEncodingException;
import java.net.URLEncoder;
import java.text.SimpleDateFormat;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.*;
import java.util.concurrent.atomic.AtomicReference;
import org.bson.codecs.configuration.CodecRegistry;
import org.bson.codecs.pojo.PojoCodecProvider;

@Component
public class IHRCollections {

    private static Logger LOGGER = LoggerFactory.getLogger(IHRCollections.class);
    private static Map<String, String> kafkaMongoSourceTargetCollectionNamesMap = new HashMap<>();

    @Autowired
    AppProperties appProperties;


    public String get5lineFromChid(String b50Chid) {
        String sbrColName = null;
        if (b50Chid != null && b50Chid.length() > 3) {
            int lineI = Integer.parseInt(b50Chid.substring(0, 3));
            if (lineI >= 100 && lineI <= 299)
                sbrColName = "five01";
            else if (lineI <= 399)
                sbrColName = "five02";
            else if (lineI <= 599)
                sbrColName = "five03";
            else if (lineI <= 799)
                sbrColName = "five04";
            else if (lineI <= 999)
                sbrColName = "five05";
            else
                LOGGER.error("Unable to find line (within 5lines) for chid - " + b50Chid);
        }
        return sbrColName;
    }

    public Document getDocumentFromMongo(String user, String pwd, String host, String port, String connectionString, String dbName, String collName, String chid) {

        MongoCollection<Document> coll = null;
        MongoClient mongo_client = null;
        Document document = null;

        String jdbcurl = "mongodb://" + encode(user) + ":" + encode(pwd) + "@" + host + ":" + port + "/?" + connectionString + "connectTimeoutMS=3000&maxIdleTimeMS=3000";

        MongoClientURI uri = new MongoClientURI(jdbcurl);
        mongo_client = new MongoClient(uri);
        MongoDatabase db = mongo_client.getDatabase(dbName);
        coll = db.getCollection(collName);

        FindIterable<Document> fi = coll.find(Filters.eq("_id", chid));

        MongoCursor<Document> cursor = fi.iterator();
        try {
            while (cursor.hasNext()) {
                document = cursor.next();
            }
        } finally {
            cursor.close();
        }

        return document;
    }

    private String encode(String input) {
        String response = null;
        try {
            response = URLEncoder.encode(input, "UTF-8");
        } catch(UnsupportedEncodingException e) {
            LOGGER.error(e.getMessage());
            response = input;
        }
        return response;
    }

    public List<PacketResponse> getPacketResponseListFromMongo(String user, String pwd, String host, String port, String connectionString, String dbName, String sourceCollName, String chid) {

        MongoCollection<Document> sourceColl = null;
        MongoClient mongo_client = null;
        Document document = null;
        List<Document> listOfDocuments = new ArrayList<>();
        List<PacketResponse> listOfPacketResponse = new ArrayList<>();
        String jdbcurl = "mongodb://" + encode(user) + ":" + encode(pwd) + "@" + host + ":" + port + "/?" + connectionString + "connectTimeoutMS=3000&maxIdleTimeMS=3000";

        MongoClientURI uri = new MongoClientURI(jdbcurl);
        mongo_client = new MongoClient(uri);
        MongoDatabase db = mongo_client.getDatabase(dbName);
        sourceColl = db.getCollection(sourceCollName);

        FindIterable<Document> fi =
                sourceColl
                        .find(Filters.eq("ACTORIDS.actorId", chid))
                        .projection(Projections.include("_id", "uuid","interfaceType", "refileCount", "refileType", "updateTimestamp"));
        MongoCursor<Document> cursor = fi.iterator();
        try {
            while (cursor.hasNext()) {
                document = cursor.next();
                listOfDocuments.add(document);

            }
        } finally {
            cursor.close();
        }

        filterLatestPackets(listOfDocuments).stream().forEach(document1 -> {
            listOfPacketResponse.add(getEnrichedMessages(document1, sourceCollName));
        });

        return listOfPacketResponse;
    }

    private PacketResponse getEnrichedMessages(Document packet, String sourceCollName) {
        PacketResponse packets = new PacketResponse();

        packets.setId(packet.getString("_id"));

//        String actorId = "";
//        for (Object actor : ((List) packet.get("ACTORIDS")) ){
//            Document actorDoc = (Document) actor;
//            if ("PATIENT".equals(actorDoc.getString("actorIdType")))
//                actorId = actorDoc.getString("actorId");
//        }
//        packets.setActorid(actorId);

//        packets.setFile_name(packet.getString("fileName"));

        packets.setInterface_type(packet.getString("interfaceType"));

        packets.setUuid(packet.getString("uuid"));

        packets.setLast_updated_dt(packet.getString("updateTimestamp"));

        packets.setSourceCollName(sourceCollName);

        packets.setRefileCount(packet.getString("refileCount"));

        packets.setRefileType(packet.getString("refileType"));

        return packets;
    }

    private List<Document> filterLatestPackets(List<Document> packetList) {
        Map<String, Document> filteredPackets = new HashMap<>();
        // get the latest packet for each uuid based on updateTimestamp
        for (Document packet: packetList){
            String uuid = packet.getString("uuid");
            Document existingPacket = filteredPackets.get(uuid);
            DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");
            if(existingPacket != null) {
                if (LocalDateTime.parse(packet.getString("updateTimestamp"), formatter).isAfter(LocalDateTime.parse(existingPacket.getString("updateTimestamp"), formatter)))
                    filteredPackets.put(uuid, packet);
            } else {
                filteredPackets.put(uuid, packet);
            }
        }
        return new ArrayList<>(filteredPackets.values());
    }

    private Bson sourcePacketUpdates(Document packet) {
        // Replace updateTimestamp with the time of refile
        String refileCountString = packet.getString("refileCount");
        int refileCount = refileCountString.isEmpty() ? 0 : Integer.parseInt(refileCountString);
        return Updates.combine(
                Updates.set("refileType", "AdminTool"),
                Updates.set("refileCount",  String.valueOf(refileCount + 1))
        );
    }

    private Document transformTargetPacketForInsert(Document packet) {
        // Replace updateTimestamp with the time of refile
        SimpleDateFormat formatter= new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        packet.put("updateTimestamp", formatter.format(new Date(System.currentTimeMillis())));
        return packet;
    }

    private Bson targetPacketUpdates(Document packet) {
        // Replace updateTimestamp with the time of refile
        SimpleDateFormat formatter= new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        return Updates.set("updateTimestamp", formatter.format(new Date(System.currentTimeMillis())));
    }

    private Document getTargetFieldsForUpdate(Document packet) {
        // Replace updateTimestamp with the time of refile
        SimpleDateFormat formatter= new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
        packet.put("updateTimestamp", formatter.format(new Date(System.currentTimeMillis())));
        return packet;
    }

    public List<PacketRefileResponse> packetRefile(String user, String pwd, String host, String port, String connectionString, String dbName, String actorId, String[] uuids, String[] collNames) {
        if (kafkaMongoSourceTargetCollectionNamesMap.isEmpty()) {
            String kafkaMongoSourceTargetCollectionNames = appProperties.getMongoPrSourceTargetCollectionNames();
            kafkaMongoSourceTargetCollectionNamesMap = new HashMap();
            Arrays.stream(kafkaMongoSourceTargetCollectionNames.split(","))
                    .forEach(kafkaMongoSourceTargetCollectionName -> {
                        String[] kafkaMongoSourceTargetCollectionNameArray = kafkaMongoSourceTargetCollectionName.split("~");
                        kafkaMongoSourceTargetCollectionNamesMap.put(kafkaMongoSourceTargetCollectionNameArray[0], kafkaMongoSourceTargetCollectionNameArray[1]);
                    });
        }

        List<Document> listOfDocuments = new ArrayList<>();

        String jdbcurl = "mongodb://" + encode(user) + ":" + encode(pwd) + "@" + host + ":" + port + "/?" + connectionString + "connectTimeoutMS=3000&maxIdleTimeMS=3000";

        MongoClientURI uri = new MongoClientURI(jdbcurl);
        MongoClient mongoClient = new MongoClient(uri);
        MongoDatabase kafkaToMongoDb = mongoClient.getDatabase(dbName);
        MongoDatabase mongoToKafkaDb = mongoClient.getDatabase(appProperties.getMongoPrTargetDbName());

        Set<String> collNamesSet = new HashSet();
        Arrays.stream(collNames).forEach(coll -> collNamesSet.add(coll));
        Map<String, List<String>> collForUuids = new HashMap<>();
        collNamesSet.forEach(collName -> {
            List<String> uuidsList = new ArrayList<>();
            for(int i=0 ; i < uuids.length; i++) {
                if(collName.equals(collNames[i])){
                    uuidsList.add(uuids[i]);
                }
            }
            collForUuids.put(collName, uuidsList);
        });

        List<PacketRefileResponse> refileResponses =new ArrayList<>();

        collForUuids.forEach(
                (collName, uuidList) -> {
                    MongoCollection<Document> kafkaToMongoColl = kafkaToMongoDb.getCollection(collName);
                    MongoCollection<Document> mongoToKafkaColl =
                            ("5line".equalsIgnoreCase(kafkaMongoSourceTargetCollectionNamesMap.get(collName)))
                                    ? mongoToKafkaDb.getCollection
                                    (
                                            appProperties.getMongoPrFiveLineTargetCollectionPrefix()
                                                    + get5lineFromChid(actorId).toUpperCase()
                                                    + appProperties.getMongoPrFiveLineTargetCollectionSuffix()
                                    )
                                    : mongoToKafkaDb.getCollection(kafkaMongoSourceTargetCollectionNamesMap.get(collName));

        FindIterable<Document> fi = kafkaToMongoColl.find(
                Filters.and(
                        Filters.eq("ACTORIDS.actorId", actorId),
                                    Filters.in("uuid", uuidList.toArray())
                )
        );
        MongoCursor<Document> cursor = fi.iterator();
        try {
            while (cursor.hasNext()) {
                            Document document = cursor.next();
                listOfDocuments.add(document);
            }
        } finally {
            cursor.close();
        }

        if(!listOfDocuments.isEmpty()){
            //save document into another mongodb/ staged for refiling
            filterLatestPackets(listOfDocuments).stream().forEach(doc -> {
                try {
                                mongoToKafkaColl.insertOne(transformTargetPacketForInsert(doc));
                                UpdateResult kafkaToMongoCollUpdateResult = kafkaToMongoColl.updateOne(Filters.eq("_id", doc.getString("_id")), sourcePacketUpdates(doc));
                    refileResponses.add(new PacketRefileResponse(doc.getString("uuid"), "Success", "refiled"));
                } catch(MongoWriteException mwe) {
                                try {
                                    UpdateResult mongoToKafkaCollUpdateResult = mongoToKafkaColl.updateOne(Filters.eq("_id", doc.getString("_id")), targetPacketUpdates(doc));
                                    UpdateResult kafkaToMongoCollUpdateResult = kafkaToMongoColl.updateOne(Filters.eq("_id", doc.getString("_id")), sourcePacketUpdates(doc));
                                    refileResponses.add(new PacketRefileResponse(doc.getString("uuid"), "Success", "refiled"));
                                } catch (MongoWriteException mwe1) {
                                    refileResponses.add(new PacketRefileResponse(doc.getString("uuid"), "Failed", mwe1.getMessage()));
                                }
                }
            });
        }
                }
        );

        return refileResponses;
    }

    public Document getPayloadOfPacketByUUID(String user, String pwd, String host, String port, String connectionString, String dbName, String collName, String actorId, String uuid) {

        MongoCollection<Document> coll = null;
        MongoClient mongo_client = null;
        List<Document> listOfDocuments = new ArrayList<>();
        Document document = null;
        String jdbcurl = "mongodb://" + encode(user) + ":" + encode(pwd) + "@" + host + ":" + port + "/?" + connectionString + "connectTimeoutMS=3000&maxIdleTimeMS=3000";

        MongoClientURI uri = new MongoClientURI(jdbcurl);
        mongo_client = new MongoClient(uri);
        MongoDatabase db = mongo_client.getDatabase(dbName);
        coll = db.getCollection(collName);

        FindIterable<Document> fi = coll.find(
                Filters.and(
                        Filters.eq("ACTORIDS.actorId", actorId),
                        Filters.eq("uuid", uuid)
                ));

        MongoCursor<Document> cursor = fi.iterator();
        try {
            while (cursor.hasNext()) {
                listOfDocuments.add(cursor.next());
            }
        } finally {
            cursor.close();
        }
        return filterLatestPackets(listOfDocuments).get(0);
    }


    public UserAuditInfo delActrIdAndCopyDoc(
            String user,
            String pwd,
            String hostTranscribed,
            String portTranscribed,
            String connectionStringTranscribed,
            String dbNameTranscribed,
            String hostSbr,
            String portSbr,
            String connectionStringSbr,
            String dbNameSbr,
            String collNameTranscribed,
            String collNameSbrMstr,
            String collNameSbrRelMstr,
            String chid,
            UserAuditInfo userAuditInfo
    ) {
        Document document;
        List<AuditInfo> listAuditInfo = new ArrayList<>();
        MongoCollection<Document> collInput;
        MongoClient mongoClientTranscribed = new MongoClient(
                new MongoClientURI(
                        "mongodb://" + encode(user) + ":" + encode(pwd) + "@" + hostTranscribed + ":" + portTranscribed + "/?" + connectionStringTranscribed + "connectTimeoutMS=3000&maxIdleTimeMS=3000"
                )
        );
        MongoDatabase dbTranscribed = mongoClientTranscribed.getDatabase(dbNameTranscribed);

        MongoClient mongoClientSbr = new MongoClient(
                new MongoClientURI(
                        "mongodb://" + encode(user) + ":" + encode(pwd) + "@" + hostSbr + ":" + portSbr + "/?" + connectionStringSbr + "connectTimeoutMS=3000&maxIdleTimeMS=3000"
                )
        );
        MongoDatabase dbSbr = mongoClientSbr.getDatabase(dbNameSbr);

        //Transcribed collection delete start
        collInput = dbTranscribed.getCollection(collNameTranscribed);
        FindIterable<Document> fiTranscribed = collInput.find(Filters.eq("_id", chid));

        MongoCursor<Document> cursorTranscribed = fiTranscribed.iterator();
        try {
            while (cursorTranscribed.hasNext()) {
                document = cursorTranscribed.next();
                copyDocument(mongoClientSbr, document, collNameTranscribed);
                collInput.deleteOne(document);
                listAuditInfo.add(new AuditInfo(collNameTranscribed, chid, 1));
            }
        } finally {
            cursorTranscribed.close();
        }
        //Transcribed collection delete end

        //split collection sbrMstr
        for (String collectionName : collNameSbrMstr.split(",")) {
            collInput = dbSbr.getCollection(collectionName);
            FindIterable<Document> fiSbrMstr = collInput.find(Filters.eq("_id", chid));
            MongoCursor<Document> cursorSbrMstr = fiSbrMstr.iterator();
            try {
                while (cursorSbrMstr.hasNext()) {
                    document = cursorSbrMstr.next();
                    copyDocument(mongoClientSbr, document, collectionName);
                    collInput.deleteOne(document);
                    listAuditInfo.add(new AuditInfo(collectionName, chid, 1));
                }
            } finally {
                cursorSbrMstr.close();
            }
        }

        //split collection sbrRelMstr
        for (String collectionName : collNameSbrRelMstr.split(",")) {
            collInput = dbSbr.getCollection(collectionName);
            FindIterable<Document> fiSbrRelMstr = collInput.find(Filters.eq("_id", chid));

            MongoCursor<Document> cursorSbrRelMstr = fiSbrRelMstr.iterator();
            try {
                while (cursorSbrRelMstr.hasNext()) {
                    document = cursorSbrRelMstr.next();
                    copyDocument(mongoClientSbr, document, collectionName);
                    collInput.deleteOne(document);
                    listAuditInfo.add(new AuditInfo(collectionName, chid, 1));
                }
            } finally {
                cursorSbrRelMstr.close();
            }
        }
        userAuditInfo.setAuditCollInfo(listAuditInfo);

        userAuditInfo.setEnddate(new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(Calendar.getInstance().getTime()));
        auditLogSave(mongoClientSbr, userAuditInfo);
        return userAuditInfo;
    }

    private void copyDocument(MongoClient mongoClientSbr, Document document, String collectionName) {

        MongoDatabase dbBackup = mongoClientSbr.getDatabase(appProperties.getDelActrMongoDbName());
        AtomicReference<MongoCollection<Document>> coll = new AtomicReference<>();

        String sbrRelMstr = appProperties.getSbrRelMstrTblNames();
        String sbrMstr =  appProperties.getSbrMstrTblNames();
        String b50Tran = appProperties.getB50TranTblName();

        String[] sbrRelMstrArr = sbrRelMstr.split(",");
        String[] sbrMstrArr = sbrMstr.split(",");

        if (collectionName.equals(b50Tran)) {
            coll.set(dbBackup.getCollection(appProperties.getDelB50TranTblName()));
            coll.get().insertOne(document);
        }
        Arrays.stream(sbrMstrArr).filter(sbrMstrMatch -> sbrMstrMatch.equals(collectionName)).forEach(matchedCollection -> {
            coll.set(dbBackup.getCollection(appProperties.getDelSbrMstrTblNames()));
            coll.get().insertOne(document);
        });
        Arrays.stream(sbrRelMstrArr).filter(sbrRelMstrMatch -> sbrRelMstrMatch.equals(collectionName)).forEach(matchedCollection -> {
            coll.set(dbBackup.getCollection(appProperties.getDelSbrRelMstrTblNames()));
            coll.get().insertOne(document);
        });

    }
   private void auditLogSave(MongoClient mongoClientSbr, UserAuditInfo userAuditInfo) {

       CodecRegistry pojoCodecRegistry = CodecRegistries.fromRegistries(MongoClientSettings.getDefaultCodecRegistry(),
               CodecRegistries.fromProviders(PojoCodecProvider.builder().automatic(true).build()));

       MongoDatabase db = mongoClientSbr.getDatabase(appProperties.getDelActrMongoDbName());

       MongoDatabase mongoDatabase = db.withCodecRegistry(pojoCodecRegistry);
       MongoCollection<UserAuditInfo> collection = mongoDatabase.getCollection(appProperties.getDelActAuditCollName(),UserAuditInfo.class);
       collection.insertOne(userAuditInfo);
    }
}
