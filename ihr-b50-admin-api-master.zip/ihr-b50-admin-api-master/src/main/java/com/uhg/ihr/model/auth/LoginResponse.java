package com.uhg.ihr.model.auth;

public class LoginResponse {

    private String jwttoken;
    private String userName;
    private String displayName;
    private String error;
    private boolean authenticated;
    private boolean hasDst;
    private boolean dev;
    private boolean adm;
    private boolean ont;
    private boolean pr;

    public LoginResponse() {}

    public LoginResponse(String jwttoken) { this.jwttoken = jwttoken; }

    public String getJwttoken() { return jwttoken; }

    public void setJwttoken(String jwttoken) { this.jwttoken = jwttoken; }

    public String getUserName() { return userName; }

    public void setUserName(String userName) { this.userName = userName; }

    public String getDisplayName() { return displayName; }

    public void setDisplayName(String displayName) { this.displayName = displayName; }

    public String getError() { return error; }

    public void setError(String error) { this.error = error; }

    public boolean isHasDst() { return hasDst; }

    public void setHasDst(boolean hasDst) { this.hasDst = hasDst; }

    public boolean isDev() {
        return dev;
    }

    public void setDev(boolean dev) {
        this.dev = dev;
    }

    public boolean isAdm() {
        return adm;
    }

    public void setAdm(boolean adm) {
        this.adm = adm;
    }

    public boolean isOnt() {
        return ont;
    }

    public void setOnt(boolean ont) {
        this.ont = ont;
    }

    public boolean isPr() {
        return pr;
    }

    public void setPr(boolean pr) {
        this.pr = pr;
    }

    public boolean isAuthenticated() { return authenticated;}

    public void setAuthenticated(boolean authenticated) { this.authenticated = authenticated;}

}