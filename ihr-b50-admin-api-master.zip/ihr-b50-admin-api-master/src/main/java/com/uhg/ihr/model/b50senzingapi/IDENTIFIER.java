package com.uhg.ihr.model.b50senzingapi;

import com.fasterxml.jackson.annotation.*;
import org.apache.commons.lang3.builder.EqualsBuilder;
import org.apache.commons.lang3.builder.HashCodeBuilder;
import org.apache.commons.lang3.builder.ToStringBuilder;

import java.util.HashMap;
import java.util.Map;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
        "MEDICARE_BENF_ID",
        "MEDICARE_NUMBER",
        "CARDHOLDER_ID",
        "UHCCDB_FAMILY_ID",
        "GPS_CID",
        "SUBSCRIBER_ID",
        "UHCINS_MEMBER_ID",
        "SSN_NUMBER",
        "MEDICAID_NUMBER",
        "CDB_CONSUMER_ID",
        "ALT_MEMBER_ID",
        "HICN",
        "Masterindividualid"
})
public class IDENTIFIER {

    @JsonProperty("MEDICARE_BENF_ID")
    private String mEDICAREBENFID;
    @JsonProperty("MEDICARE_NUMBER")
    private String mEDICARENUMBER;
    @JsonProperty("CARDHOLDER_ID")
    private String cARDHOLDERID;
    @JsonProperty("UHCCDB_FAMILY_ID")
    private String uHCCDBFAMILYID;
    @JsonProperty("GPS_CID")
    private String gPSCID;
    @JsonProperty("SUBSCRIBER_ID")
    private String sUBSCRIBERID;
    @JsonProperty("UHCINS_MEMBER_ID")
    private String uHCINSMEMBERID;
    @JsonProperty("SSN_NUMBER")
    private String sSNNUMBER;
    @JsonProperty("MEDICAID_NUMBER")
    private String mEDICAIDNUMBER;
    @JsonProperty("CDB_CONSUMER_ID")
    private String cDBCONSUMERID;
    @JsonProperty("ALT_MEMBER_ID")
    private String aLTMEMBERID;
    @JsonProperty("HICN")
    private String hICN;
    @JsonProperty("Masterindividualid")
    private String masterindividualid;
    @JsonIgnore
    private Map<String, Object> additionalProperties = new HashMap<String, Object>();

    @JsonProperty("MEDICARE_BENF_ID")
    public String getMEDICAREBENFID() {
        return mEDICAREBENFID;
    }

    @JsonProperty("MEDICARE_BENF_ID")
    public void setMEDICAREBENFID(String mEDICAREBENFID) {
        this.mEDICAREBENFID = mEDICAREBENFID;
    }

    @JsonProperty("MEDICARE_NUMBER")
    public String getMEDICARENUMBER() {
        return mEDICARENUMBER;
    }

    @JsonProperty("MEDICARE_NUMBER")
    public void setMEDICARENUMBER(String mEDICARENUMBER) {
        this.mEDICARENUMBER = mEDICARENUMBER;
    }

    @JsonProperty("CARDHOLDER_ID")
    public String getCARDHOLDERID() {
        return cARDHOLDERID;
    }

    @JsonProperty("CARDHOLDER_ID")
    public void setCARDHOLDERID(String cARDHOLDERID) {
        this.cARDHOLDERID = cARDHOLDERID;
    }

    @JsonProperty("UHCCDB_FAMILY_ID")
    public String getUHCCDBFAMILYID() {
        return uHCCDBFAMILYID;
    }

    @JsonProperty("UHCCDB_FAMILY_ID")
    public void setUHCCDBFAMILYID(String uHCCDBFAMILYID) {
        this.uHCCDBFAMILYID = uHCCDBFAMILYID;
    }

    @JsonProperty("GPS_CID")
    public String getGPSCID() {
        return gPSCID;
    }

    @JsonProperty("GPS_CID")
    public void setGPSCID(String gPSCID) {
        this.gPSCID = gPSCID;
    }

    @JsonProperty("SUBSCRIBER_ID")
    public String getSUBSCRIBERID() {
        return sUBSCRIBERID;
    }

    @JsonProperty("SUBSCRIBER_ID")
    public void setSUBSCRIBERID(String sUBSCRIBERID) {
        this.sUBSCRIBERID = sUBSCRIBERID;
    }

    @JsonProperty("UHCINS_MEMBER_ID")
    public String getUHCINSMEMBERID() {
        return uHCINSMEMBERID;
    }

    @JsonProperty("UHCINS_MEMBER_ID")
    public void setUHCINSMEMBERID(String uHCINSMEMBERID) {
        this.uHCINSMEMBERID = uHCINSMEMBERID;
    }

    @JsonProperty("SSN_NUMBER")
    public String getSSNNUMBER() {
        return sSNNUMBER;
    }

    @JsonProperty("SSN_NUMBER")
    public void setSSNNUMBER(String sSNNUMBER) {
        this.sSNNUMBER = sSNNUMBER;
    }

    @JsonProperty("MEDICAID_NUMBER")
    public String getMEDICAIDNUMBER() {
        return mEDICAIDNUMBER;
    }

    @JsonProperty("MEDICAID_NUMBER")
    public void setMEDICAIDNUMBER(String mEDICAIDNUMBER) {
        this.mEDICAIDNUMBER = mEDICAIDNUMBER;
    }

    @JsonProperty("CDB_CONSUMER_ID")
    public String getCDBCONSUMERID() {
        return cDBCONSUMERID;
    }

    @JsonProperty("CDB_CONSUMER_ID")
    public void setCDBCONSUMERID(String cDBCONSUMERID) {
        this.cDBCONSUMERID = cDBCONSUMERID;
    }

    @JsonProperty("ALT_MEMBER_ID")
    public String getALTMEMBERID() {
        return aLTMEMBERID;
    }

    @JsonProperty("ALT_MEMBER_ID")
    public void setALTMEMBERID(String aLTMEMBERID) {
        this.aLTMEMBERID = aLTMEMBERID;
    }

    @JsonProperty("HICN")
    public String getHICN() {
        return hICN;
    }

    @JsonProperty("HICN")
    public void setHICN(String hICN) {
        this.hICN = hICN;
    }

    @JsonProperty("Masterindividualid")
    public String getMasterindividualid() {
        return masterindividualid;
    }

    @JsonProperty("Masterindividualid")
    public void setMasterindividualid(String masterindividualid) {
        this.masterindividualid = masterindividualid;
    }

    @Override
    public String toString() {
        return ToStringBuilder.reflectionToString(this);
    }

    @JsonAnyGetter
    public Map<String, Object> getAdditionalProperties() {
        return this.additionalProperties;
    }

    @JsonAnySetter
    public void setAdditionalProperty(String name, Object value) {
        this.additionalProperties.put(name, value);
    }

    @Override
    public int hashCode() {
        return new HashCodeBuilder().append(mEDICAREBENFID).append(mEDICARENUMBER).append(cARDHOLDERID).append(uHCCDBFAMILYID).append(gPSCID).append(sUBSCRIBERID).append(uHCINSMEMBERID).append(sSNNUMBER).append(mEDICAIDNUMBER).append(cDBCONSUMERID).append(aLTMEMBERID).append(hICN).append(masterindividualid).append(additionalProperties).toHashCode();
    }

    @Override
    public boolean equals(Object other) {
        if (other == this) {
            return true;
        }
        if ((other instanceof IDENTIFIER) == false) {
            return false;
        }
        IDENTIFIER rhs = ((IDENTIFIER) other);
        return new EqualsBuilder().append(mEDICAREBENFID, rhs.mEDICAREBENFID).append(mEDICARENUMBER, rhs.mEDICARENUMBER).append(cARDHOLDERID, rhs.cARDHOLDERID).append(uHCCDBFAMILYID, rhs.uHCCDBFAMILYID).append(gPSCID, rhs.gPSCID).append(sUBSCRIBERID, rhs.sUBSCRIBERID).append(uHCINSMEMBERID, rhs.uHCINSMEMBERID).append(sSNNUMBER, rhs.sSNNUMBER).append(mEDICAIDNUMBER, rhs.mEDICAIDNUMBER).append(cDBCONSUMERID, rhs.cDBCONSUMERID).append(aLTMEMBERID, rhs.aLTMEMBERID).append(hICN, rhs.hICN).append(masterindividualid, rhs.masterindividualid).append(additionalProperties, rhs.additionalProperties).isEquals();
    }

}
