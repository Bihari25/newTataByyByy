package com.uhg.ihr.security;


import com.uhg.ihr.model.AppProperties;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.ldap.filter.EqualsFilter;
import org.springframework.security.authentication.*;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.AuthenticationException;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.authority.SimpleGrantedAuthority;
import org.springframework.stereotype.Component;

import javax.naming.Context;
import javax.naming.NamingEnumeration;
import javax.naming.NamingException;
import javax.naming.directory.*;
import java.util.ArrayList;
import java.util.Enumeration;
import java.util.Hashtable;
import java.util.List;

@Component
public class LdapUtil{


    @Autowired
    AppProperties appProperties;

    private static Logger LOGGER = LoggerFactory.getLogger(LdapUtil.class);

    private final static String ROLE_ADM = "ROLE_ADM"; //admin
    private final static String ROLE_DST = "ROLE_DST"; //tier1
    private final static String ROLE_DEV = "ROLE_DEV"; //tier2
    private final static String ROLE_ONT = "ROLE_ONT"; //Ontology Browser
    private final static String ROLE_PR = "ROLE_PR"; //Packet Refile
    public final static SimpleGrantedAuthority ADM = new SimpleGrantedAuthority(ROLE_ADM);
    public final static SimpleGrantedAuthority DST = new SimpleGrantedAuthority(ROLE_DST);
    public final static SimpleGrantedAuthority DEV = new SimpleGrantedAuthority(ROLE_DEV);
    public final static SimpleGrantedAuthority ONT = new SimpleGrantedAuthority(ROLE_ONT);
    public final static SimpleGrantedAuthority PR = new SimpleGrantedAuthority(ROLE_PR);
    private final static String LDAP_GRP_ATTRIBUTE = "memberOf";
    private final static String LDAP_NAME_ATTRIBUTE = "displayname";

    public Authentication ldapAuthentication(String userName,String password)
            throws AuthenticationException {

        try {
            StringBuilder fullName = new StringBuilder();
            List<GrantedAuthority> authorities = new ArrayList<>();
            if (isLdapRegistred(userName, password , authorities, fullName)) {
                LOGGER.info("User "+userName+" Logged in.");
                UsernamePasswordAuthenticationToken upd = new UsernamePasswordAuthenticationToken( userName, password, authorities);
                upd.setDetails(fullName.toString());
                return upd;
            } else {
                throw new BadCredentialsException("Invalid credentials");
            }
        }catch(InsufficientAuthenticationException ex){
            LOGGER.error(ex.getMessage());
            throw ex;
        }catch (NamingException ex) {
            LOGGER.error("Unable to authenticate user - "+userName);
            LOGGER.error(ex.getMessage());
            throw new AuthenticationServiceException(ex.toString());
        }
    }

    boolean isLdapRegistred(String username, String password, List<GrantedAuthority> authorities, StringBuilder name) throws NamingException, AuthenticationException {
        boolean validLdap = false;
        boolean isAdm = false;
        boolean isDst = false;
        boolean isDev = false;
        boolean isOnt = false;
        boolean isPR = false;

        try {

            Hashtable<String, String> env = new Hashtable<String, String>();
            env.put(Context.INITIAL_CONTEXT_FACTORY, appProperties.getLdapctxfactory());
            env.put(Context.PROVIDER_URL, appProperties.getLdapproviderurl());
            env.put(Context.SECURITY_AUTHENTICATION, appProperties.getLdapsecurityauth());
            env.put(Context.SECURITY_PRINCIPAL, "MS\\" + username);
            env.put(Context.SECURITY_CREDENTIALS, password);

            DirContext ctx = new InitialDirContext(env);
            validLdap = ctx != null;
            if(validLdap){
                SearchControls constraints = new SearchControls();
                constraints.setSearchScope(SearchControls.SUBTREE_SCOPE);
                NamingEnumeration<?> results = ctx.search(appProperties.getLdapsearchdn(), (new EqualsFilter("cn", username)).encode(), constraints);
                String admLdapUserGrp = "CN="+appProperties.getLdapsearchgroupdn()+",CN=Users,DC=ms,DC=ds,DC=uhc,DC=com";
                String dstLdapUserGrp = "CN="+appProperties.getLdapsearchdstgroup()+",CN=Users,DC=ms,DC=ds,DC=uhc,DC=com";
                String devLdapUserGrp = "CN="+appProperties.getLdapsearchdevgroup()+",CN=Users,DC=ms,DC=ds,DC=uhc,DC=com";
                String ontLdapUserGrp = "CN="+appProperties.getLdapsearchontgroup()+",CN=Users,DC=ms,DC=ds,DC=uhc,DC=com";
                String prLdapUserGrp = "CN="+appProperties.getLdapsearchprgroup()+",CN=Users,DC=ms,DC=ds,DC=uhc,DC=com";
                // *** Really only one expected
                while (results.hasMore()) {
                    SearchResult si = (SearchResult) results.next();

                    // Show members of group
                    Attributes attrs = si.getAttributes();
                    if (attrs == null) {
                        LOGGER.info("No attributes for group");
                        continue;
                    }

                    for (NamingEnumeration ae = attrs.getAll(); ae.hasMoreElements();) {
                        Attribute attr = (Attribute) ae.next();
                        String id = attr.getID();
                        if(id!=null&& LDAP_GRP_ATTRIBUTE.equalsIgnoreCase(id)){
                            Enumeration vals = attr.getAll();
                            while (vals.hasMoreElements()) {
                                Object valueEntry = vals.nextElement();
                                if (valueEntry.equals(admLdapUserGrp)) {
                                    authorities.add(ADM);
                                    isAdm = true;
                                }else if(valueEntry.equals(dstLdapUserGrp)){
                                    authorities.add(DST);
                                    isDst = true;
                                }else if(valueEntry.equals(devLdapUserGrp)){
                                    authorities.add(DEV);
                                    isDev = true;
                                }else if(valueEntry.equals(ontLdapUserGrp)){
                                    authorities.add(ONT);
                                    isOnt = true;
                                }else if(valueEntry.equals(prLdapUserGrp)){
                                    authorities.add(PR);
                                    isPR = true;
                                }
                            }
                        }else if(id!=null && LDAP_NAME_ATTRIBUTE.equalsIgnoreCase(id)){
                             name.append(attr.get());
                        }else{
                            continue;
                        }
                    }
                }
            }
            if (ctx != null)
                ctx.close();
            if(validLdap && !(isAdm || isDst || isDev || isOnt || isPR))
                throw new InsufficientAuthenticationException("User is not Authorized to access this application, please request for one of the following AD groups - \n"
                        +"'"+appProperties.getLdapsearchgroupdn()+"' or \n"
                        +"'"+appProperties.getLdapsearchdstgroup()+"' or \n"
                        +"'"+appProperties.getLdapsearchdevgroup()+"' or \n"
                        +"'"+appProperties.getLdapsearchontgroup()+"' or \n"
                        +"'"+appProperties.getLdapsearchprgroup()+"'");
            return validLdap;
        }catch(javax.naming.AuthenticationException aex){
            return false;
        }catch (NamingException e) {
            throw e;
        }
    }
}
