package com.uhg.ihr.model;

import lombok.AllArgsConstructor;
import lombok.Data;

@Data
@AllArgsConstructor
public class AuditInfo {
    private String collectionName;
    private String actorId;
    private Integer recordCount;
}
