package com.uhg.ihr.controller;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.uhg.ihr.dao.DBHandler;
import com.uhg.ihr.model.*;
import com.uhg.ihr.model.auth.LoginRequest;
import com.uhg.ihr.model.auth.LoginResponse;
import com.uhg.ihr.security.LdapUtil;
import com.uhg.ihr.services.IHRB50Senzing;
import com.uhg.ihr.services.IHRMongoCounts;
import com.uhg.ihr.services.PacketService;
import com.uhg.ihr.services.ServiceNowRequest;
import com.uhg.ihr.utils.IHRUtils;
import com.uhg.ihr.utils.JwtTokenUtil;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import org.apache.commons.lang3.tuple.Pair;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.dao.DataAccessException;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.authentication.BadCredentialsException;
import org.springframework.security.authentication.InsufficientAuthenticationException;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.AuthenticationException;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import javax.validation.constraints.NotNull;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import static com.uhg.ihr.services.IHRMongoCounts.DB_MAP_LINE;
import static com.uhg.ihr.services.IHRMongoCounts.DB_MAP_NODOC;
import static com.uhg.ihr.services.IHRMongoCounts.DB_MAP_PAYLOAD;

@CrossOrigin(origins = "*", allowedHeaders = "*")
@RestController
@RequestMapping(value = "/ihr-admin/api/v1")
@Validated
@Api(tags= "Admin API Clients")
public class ReactApiController {

    private static final Logger LOG = LoggerFactory.getLogger(ReactApiController.class);

    private static final String RTNVALUE = " Welcome to React-Admin API ";
    private static final String SERVICENOW_INPROGRESS_STATE= "2";


    @Autowired
    SenzingGlobalRequest senzingGlobalRequest;

    @Autowired
    SenzingBig3Request senzingBig3Request;

    @Autowired
    IHRB50Senzing ihrb50Senzing;

    @Autowired
    IHRMongoCounts ihrMongoCounts;

    @Autowired
    DBHandler dbHandler;
    @Autowired
    PacketService packetService;
    @Autowired
    private JwtTokenUtil jwtTokenUtil;
    @Autowired
    private LdapUtil ldapUtil;

    @Autowired
    private ServiceNowRequest serviceNowRequest;

    @Autowired
    private  AppProperties appProperties;

    public static boolean isProvider(String b50Chid) {

        if (b50Chid == null || b50Chid.trim().length() < 7) {
            return false;
        }
        if ('P' == b50Chid.charAt(6))
            return true;
        else
            return false;
    }

    @ApiOperation(value = " Admin API services JWT token request.")
    @RequestMapping(value = "/authenticate", method = RequestMethod.POST)
    public ResponseEntity<?> createAuthenticationToken(@RequestBody LoginRequest authenticationRequest) {
        LoginResponse response = new LoginResponse();
        try {
            Authentication authentication = authenticate(authenticationRequest.getUsername(), authenticationRequest.getPassword());
            response.setJwttoken(jwtTokenUtil.generateToken(authentication));
            response.setUserName(authentication.getName());
            response.setDisplayName((authentication.getDetails() != null ? authentication.getDetails().toString() : "Guest"));
            response.setHasDst(IHRUtils.hasDst(authentication));
            response.setAdm(IHRUtils.isAdm(authentication));
            response.setDev(IHRUtils.isDev(authentication));
            response.setOnt(IHRUtils.isOnt(authentication));
            response.setPr(IHRUtils.isPr(authentication));
            response.setAuthenticated(Boolean.TRUE);
            return ResponseEntity.ok(response);
        } catch(BadCredentialsException ex) {
            LOG.error("Unable to authenticate user - " + authenticationRequest.getUsername() + ". Due to - " + ex.getMessage());
            response.setError("Invalid credentials, please check and try again.");
            response.setAuthenticated(false);
            return new ResponseEntity<>(response, HttpStatus.NOT_FOUND);
        } catch(InsufficientAuthenticationException ex) {
            LOG.error("Unable to authenticate user - " + authenticationRequest.getUsername() + ". Due to - " + ex.getMessage());
            response.setError(ex.getMessage());
            response.setAuthenticated(false);
            return new ResponseEntity<>(response, HttpStatus.UNAUTHORIZED);
        }
    }

    private Authentication authenticate(String username, String password) throws AuthenticationException {
        return ldapUtil.ldapAuthentication(username, password);
    }

    @ApiOperation(value = " Admin Api Services ", response = String.class)
    @GetMapping(value = "/test")
    public @ResponseBody
    ResponseEntity<String> adminApiStarted() {
        LOG.info(" Test ");
        return new ResponseEntity<>(RTNVALUE, HttpStatus.OK);
    }

    @ApiOperation(value = " Chid search Services ", response = SearchResponse.class)
    @GetMapping(value = "/chid/{chidId}", produces = {"application/json"})
    public @ResponseBody
    ResponseEntity<?> getB50JsonByChid(@PathVariable("chidId") String chidId, Authentication authentication) {

        LOG.info(" getB50JsonByChid " + chidId);
        boolean isDst = IHRUtils.hasDst(authentication);

        senzingGlobalRequest.setGlobalid(chidId);
        Map<String, Object> rtn = new LinkedHashMap<>();
        SearchResponse chidResponse = new SearchResponse();
        ObjectMapper Obj = new ObjectMapper();
        try {
            String jsonStr = Obj.writeValueAsString(senzingGlobalRequest);
            String b50SenzingResponse = ihrb50Senzing.getB50SenzingAPI(jsonStr);
            Map<String, Object> sensingInfo = IHRUtils.parseSensingResponse(b50SenzingResponse, isDst);
            String b50Chid = (String) sensingInfo.get(IHRUtils.SM_CHID);
            String nameFromSensing = (String) sensingInfo.get(IHRUtils.SM_NAME);
            String dobFromSensing = (String) sensingInfo.get(IHRUtils.SM_DOB);

            if (b50Chid == null || b50Chid.trim().length() < 1) {
                LOG.error(" - Unable to match chid - " + chidId + ", in senzing.");
                return new ResponseEntity<>("{\"error\":\"No Match Found in Senzing.\", \"status\":\"404\"}", HttpStatus.OK);
            }

			chidResponse.setFullName(nameFromSensing);
			chidResponse.setDob(dobFromSensing);
            chidResponse.setParsedName((ParsedName) sensingInfo.get(IHRUtils.SM_PARSED_NAME));
            chidResponse.setPartialIdentifiers((List<KeyValuePair<String,String>>) sensingInfo.get(IHRUtils.SM_PARTIAL_IDENTIFIERS));

            // we will check if identifier b50 actor id is for member or provider,
            chidResponse.setActorId(b50Chid);
            if (isProvider(b50Chid)) {
                LOG.info(" - Searched for a provider per chid - " + b50Chid);

                chidResponse.setActorType(IHRUtils.ACTOR_TYPE_PROVIDER);
                String provider_json = ihrMongoCounts.getProviderDemographicsDocument(b50Chid);
                chidResponse.setPayload(provider_json);
                chidResponse.setProviderSpecialities(IHRUtils.fetchSpecialitiesWithCodes(provider_json, dbHandler));

                return new ResponseEntity<>(chidResponse, HttpStatus.OK);
            }
            LOG.info(" - Searched for member per chid - " + b50Chid);
            chidResponse.setActorType(IHRUtils.ACTOR_TYPE_MEMBER);
            // B50 Transcriber
            HashMap<? extends Object, ? extends Object> b50Map = ihrMongoCounts.getMap(b50Chid);

            boolean isDocFoundInDB = (b50Map.containsKey(DB_MAP_NODOC) && Boolean.TRUE.equals(b50Map.get(DB_MAP_NODOC))) ? false : true;

            if (!isDocFoundInDB) {
                LOG.error(" - unable to find document for chid - " + b50Chid);
                return new ResponseEntity<>("{\"error\":\"No Document Found.\", \"status\":\"404\"}", HttpStatus.OK);
            }

            String payload = (String) b50Map.get(DB_MAP_PAYLOAD);
            chidResponse.setPayload(payload);

            if (!isDst) {
                String b50Line = (b50Map.get(DB_MAP_LINE) == null || b50Map.get(DB_MAP_LINE).toString().trim().length() < 1) ? "" : b50Map.get(DB_MAP_LINE).toString();
                chidResponse.setLine(b50Line);
                chidResponse.setRelationshipDocument(ihrMongoCounts.getRelationshipDocument(b50Line, b50Chid));
                handleDDSlogic(b50Line, b50Chid, chidResponse);
            }

            return new ResponseEntity<>(chidResponse, HttpStatus.OK);
        } catch(JsonProcessingException e) {
            LOG.error(e.getMessage());
            return new ResponseEntity<>("Error in parseSensingResponse", HttpStatus.OK);
        }
    }

    private void handleDDSlogic(String b50Line, String b50Chid, SearchResponse response) {
        if (IHRUtils.GOLD_DDS_HOST == null || IHRUtils.VIP_DDS_HOST == null || IHRUtils.SMB_DDS_HOST == null) {
            //this.refreshDDsConfig();
            dbHandler.refreshDDSConfig();
        }
        if ("gold".equalsIgnoreCase(b50Line)) { //it goldvcx
            response.setDdsViewer(IHRUtils.GOLD_DDS_HOST + "/dds_display/" + b50Chid + "/datatree?show_implicit=false#");
        } else if ("vip".equalsIgnoreCase(b50Line)) {//if its  vip
            response.setDdsViewer(IHRUtils.VIP_DDS_HOST + "/dds_display/" + b50Chid + "/datatree?show_implicit=false#");
        } else if ("smb".equalsIgnoreCase(b50Line)) {//it's SMB
            response.setDdsViewer(IHRUtils.SMB_DDS_HOST + "/dds_display/" + b50Chid + "/datatree?show_implicit=false#");
        } else if ("full".equalsIgnoreCase(b50Line)) {
            int first3 = Integer.parseInt(b50Chid.substring(0, 3));
            String host = null;
            if (first3 >= 100 && first3 <= 299)
                host = IHRUtils.FIVE_LINE_01_HOST;
            else if (first3 <= 399)
                host = IHRUtils.FIVE_LINE_02_HOST;
            else if (first3 <= 599)
                host = IHRUtils.FIVE_LINE_03_HOST;
            else if (first3 <= 799)
                host = IHRUtils.FIVE_LINE_04_HOST;
            else if (first3 <= 999)
                host = IHRUtils.FIVE_LINE_05_HOST;
            else
                LOG.error("Unable to find 5-line for chid - " + b50Chid);
            if (host != null)
                response.setDdsViewer(host + "/dds_display/" + b50Chid + "/datatree?show_implicit=false#");
            else
                response.setDdsViewer("No DDS URL for B50 line - " + b50Line);
        } else {
            LOG.error("No DDS URL for B50 line - " + b50Line + ", no DDS configured..");
        }
    }

    @GetMapping(value = "/refreshDDS")
    @ResponseBody
    public String refreshDDsConfig() {
        dbHandler.refreshDDSConfig();
        return "DDS configs refreshed with DB values.";
    }

    @ApiOperation(value = " Big3 search Services ", response = SearchResponse.class)
    @PostMapping(value = "/big3", produces = {"application/json"}, consumes = {"application/json"})
    public @ResponseBody
    ResponseEntity<?> getB50JsonByBig3(@RequestBody Big3Request request, Authentication authentication) {

        LOG.info("Got a big3 Search Request.");

        senzingBig3Request.setFirstName(request.getFirstName());
        senzingBig3Request.setLastname(request.getLastName());
        senzingBig3Request.setDob(request.getBirthday());
        senzingBig3Request.setSearchID(request.getSearchId());

        SearchResponse big3Response = new SearchResponse();
        boolean isDst = IHRUtils.hasDst(authentication);
        try {
            String jsonStr = new ObjectMapper().writeValueAsString(senzingBig3Request);
            String b50SenzingResponse = ihrb50Senzing.getB50SenzingAPI(jsonStr);
            Map<String, Object> sensingInfo = IHRUtils.parseSensingResponse(b50SenzingResponse, isDst);

            boolean matchFound = (Boolean) sensingInfo.get(IHRUtils.SM_MATCH);
            List<SenzingResult> possibleMatches = (List<SenzingResult>) sensingInfo.get(IHRUtils.SM_POSSIBLE_MATCHES);
            String senzingError = (String) sensingInfo.get(IHRUtils.SM_ERROR);
            if (!matchFound && possibleMatches != null && !possibleMatches.isEmpty()) {
                LOG.info(" - found possible matche(s) from senzing, displaying back to user.");
                big3Response.setParital(true);
                big3Response.setPartialResults(possibleMatches);
                return new ResponseEntity<>(big3Response, HttpStatus.OK);
            } else if (!matchFound && senzingError != null) {
                LOG.error("More partial results came.. need to refine search criteria..");
                return new ResponseEntity<>("{\"error\":\"" + senzingError + "\", \"status\":\"404\"}", HttpStatus.OK);
            }
            String b50Chid = (String) sensingInfo.get(IHRUtils.SM_CHID);
            String nameFromSensing = (String) sensingInfo.get(IHRUtils.SM_NAME);
            String dobFromSensing = (String) sensingInfo.get(IHRUtils.SM_DOB);

            if (b50Chid == null || b50Chid.trim().length() < 1) {
                LOG.error(" - Got no match(s) from senzing.");
                return new ResponseEntity<>("{\"error\":\"No Match Found in Senzing.\", \"status\":\"404\"}", HttpStatus.OK);
            }

            big3Response.setActorId(b50Chid);
            big3Response.setFullName(nameFromSensing);
            big3Response.setDob(dobFromSensing);
            LOG.info(" - got chid - " + b50Chid + ", for user's big3 request..");

            if (isProvider(b50Chid)) {
                LOG.info(" - Searched for a provider per chid - " + b50Chid);

                big3Response.setActorType(IHRUtils.ACTOR_TYPE_PROVIDER);
                String provider_json = ihrMongoCounts.getProviderDemographicsDocument(b50Chid);
                big3Response.setPayload(provider_json);
                big3Response.setProviderSpecialities(IHRUtils.fetchSpecialitiesWithCodes(provider_json, dbHandler));

                return new ResponseEntity<>(big3Response, HttpStatus.OK);
            }
            LOG.info(" - Searched for member per chid - " + b50Chid);
            big3Response.setActorType(IHRUtils.ACTOR_TYPE_MEMBER);
            // B50 Transcriber
            HashMap<? extends Object, ? extends Object> b50Map = ihrMongoCounts.getMap(b50Chid);

            boolean isDocFoundInDB = (b50Map.containsKey(DB_MAP_NODOC) && Boolean.TRUE.equals(b50Map.get(DB_MAP_NODOC))) ? false : true;

            if (!isDocFoundInDB) {
                LOG.error(" - unable to find document for chid - " + b50Chid);
                return new ResponseEntity<>("{\"error\":\"No Document Found.\" , \"status\":\"404\"}", HttpStatus.OK);
            }

            String payload = (String) b50Map.get(DB_MAP_PAYLOAD);
            big3Response.setPayload(payload);

            if (!isDst) {
                String b50Line = (b50Map.get(DB_MAP_LINE) == null || b50Map.get(DB_MAP_LINE).toString().trim().length() < 1) ? "" : b50Map.get(DB_MAP_LINE).toString();
                big3Response.setLine(b50Line);
                big3Response.setRelationshipDocument(ihrMongoCounts.getRelationshipDocument(b50Line, b50Chid));
                handleDDSlogic(b50Line, b50Chid, big3Response);
            }

            return new ResponseEntity<>(big3Response, HttpStatus.OK);
        } catch(JsonProcessingException e) {
            LOG.error(e.getMessage());
            return new ResponseEntity<>("Error in parseSensingResponse", HttpStatus.OK);
        }
    }

    @GetMapping(value = "/pv/packets/payload/{uuid}", produces = {"application/json"})
    public @ResponseBody
    ResponseEntity<?> fetchPacketPayload(@PathVariable String uuid, Authentication authentication) {

        String payload;
        LOG.info(" - Trying to fetch payload of packet with uuid - " + uuid +
                (authentication != null && authentication.getPrincipal() != null ? ", by user - " + authentication.getPrincipal().toString() : ""));
        if (uuid != null && uuid.trim().length() > 0) {
            payload = packetService.getPayloadOfPacketByUUID(uuid);
        } else {
            LOG.error(" - Got fetchPayload request with empty or null uuid.");
            payload = "{'msg':'Unable to fetch Payload empty or null UUID - " + uuid + "'}";
        }

        return ResponseEntity.ok(payload);
    }

    @GetMapping(value = "/pr/packets/payload/{collName}/{actorId}/{uuid}", produces = {"application/json"})
    public @ResponseBody
    ResponseEntity<?> fetchPacketPayload(@PathVariable String collName, @PathVariable String actorId, @PathVariable String uuid, Authentication authentication) {

        String payload;
        LOG.info(" - Trying to fetch payload of packet with uuid - " + uuid +
                (authentication != null && authentication.getPrincipal() != null ? ", by user - " + authentication.getPrincipal().toString() : ""));
        if (uuid != null && uuid.trim().length() > 0) {
            payload = packetService.getPayloadOfPacketByUUID(collName, actorId, uuid);
        } else {
            LOG.error(" - Got fetchPayload request with empty or null uuid.");
            payload = "{'msg':'Unable to fetch Payload empty or null UUID - " + uuid + "'}";
        }

        return ResponseEntity.ok(payload);
    }

    @GetMapping(value = "/pv/packets/{actorId}", produces = {"application/json"})
    public @ResponseBody
    ResponseEntity<?> packetViewer(@PathVariable String actorId, Authentication authentication) {
        PacketViewerResponse response = new PacketViewerResponse();
        LOG.info(" - Got a request for packets for actor - " + actorId + ", by user - " + authentication.getName());
        try {
            response.setPackets(packetService.viewPacket(actorId, authentication.getPrincipal().toString()));
            int numOfReqs = packetService.numOfOpeRequests(authentication.getName());
            if (numOfReqs >= 20)
                response.setCanRequestPackets(false);
            else
                response.setCanRequestPackets(true);
        } catch(DataAccessException ex) {
            LOG.error("Unable to fetch packet viwer response for actor - " + actorId + ", due to - " + ex.getMessage());
            return new ResponseEntity<>(response, HttpStatus.INTERNAL_SERVER_ERROR);
        }
        return ResponseEntity.ok(response);
    }


    @GetMapping(value = "/pr/packets/{actorId}", produces = {"application/json"})
    public @ResponseBody
    ResponseEntity<?> packetViewerForRefile(@PathVariable String actorId, Authentication authentication) {
        PacketViewerResponse response = new PacketViewerResponse();
        LOG.info(" - Got a request for packets for actor - " + actorId + ", by user - " + authentication.getName());
        try {
            response.setPackets(packetService.viewPacketForRefile(actorId, authentication.getPrincipal().toString()));
//            int numOfReqs = packetService.numOfOpeRequests(authentication.getName());
//            if (numOfReqs >= 20)
            response.setCanRequestPackets(false);
//            else
//                response.setCanRequestPackets(true);
        } catch(DataAccessException ex) {
            LOG.error("Unable to fetch packet viwer response for actor - " + actorId + ", due to - " + ex.getMessage());
            return new ResponseEntity<>(response, HttpStatus.INTERNAL_SERVER_ERROR);
        }
        return ResponseEntity.ok(response);
    }

    @GetMapping(value = "/pv/packetRequest", produces = {"application/json"})
    public @ResponseBody
    ResponseEntity<?> addNewPacketSearchRequest(Authentication authentication) {
        LOG.info(" - Got a request for open PacketSearch requests for User - " + authentication.getName());
        List<PacketRequest> auditList = packetService.auditRequest(authentication.getName());
        return ResponseEntity.ok(auditList);
    }

    @DeleteMapping("/pv/packetRequest/{actorId}")
    public @ResponseBody
    ResponseEntity<Integer> deleteExistingPacketRequest(@PathVariable String actorId, Authentication authentication) {
        LOG.info(" - Got a delete request for User - " + authentication.getName() + " and actor - " + actorId);
        int resp = packetService.deletePacket(actorId, authentication.getPrincipal().toString());
        return ResponseEntity.ok(resp);
    }

    @PutMapping("/pv/packetRequest/{actorId}")
    public @ResponseBody
    ResponseEntity<?> getPacketRequestOfcurrentUser(@PathVariable String actorId, Authentication authentication) {
        LOG.info(" - Got a new packetSearch request for actor - " + actorId + ", by user - " + authentication.getName());
        String resp = packetService.addPacketSearchRequest(actorId, authentication.getPrincipal().toString());
        return ResponseEntity.ok(resp);
    }

    @PostMapping(value = "/pr/packetRefile", produces = {"application/json"})
    public @ResponseBody
    ResponseEntity<?> packetRefile(@RequestParam String actorId, @RequestParam String[] uuids, @RequestParam String[] collNames, Authentication authentication) {

        List<PacketRefileResponse> refileResponses = ihrMongoCounts.packetRefile(actorId, uuids, collNames);
        return ResponseEntity.ok(refileResponses);
    }

    @ApiOperation(value = " Actor Deletion request ")
    @DeleteMapping(value = "/chiddelete/{chidId}/{incidNo}", produces = {"application/json"})
    public @ResponseBody
    ResponseEntity<?> actorDeletionRequest(@NotNull @PathVariable("chidId") String chidId, @NotNull @PathVariable("incidNo") String incidNo, Authentication authentication) {
        LOG.info(" - Got a delete request for User - " + authentication.getName() + " and actor - " + chidId);
        try {
            if (!(incidNo.startsWith("CHG") || incidNo.startsWith("INC"))) {
                LOG.error(" - Invalid Ticket number found - " + incidNo);
                return new ResponseEntity<>("Invalid Incident/Change Ticket number found " + incidNo, HttpStatus.NOT_FOUND);
            }
            UserAuditInfo userAuditInfo = null;
            TicketInfo ticketInfo = null;
            //Audit log
            userAuditInfo = new UserAuditInfo();
            userAuditInfo.setStartdate(new SimpleDateFormat("yyyy-MM-dd HH:mm:ss").format(Calendar.getInstance().getTime()));
            userAuditInfo.setUserId(authentication.getName());
            //call service now integration
            ticketInfo = serviceNowRequest.validateTicketOnSubmit(incidNo);
            userAuditInfo.setTicketInfo(ticketInfo);

            if (!ticketInfo.isSuccess()) {
                return new ResponseEntity<>("Ticket information not found in service now " + incidNo, HttpStatus.NOT_FOUND);
            }
            if (SERVICENOW_INPROGRESS_STATE.equals(ticketInfo.getState()) ) {
                 if(appProperties.getServiceNowGroupID().equals(ticketInfo.getAssignment_group_value())){
                     userAuditInfo = ihrMongoCounts.delActrIdAndCopyDoc(chidId, userAuditInfo);
                     if (userAuditInfo.getAuditCollInfo().size() > 0) {
                         return new ResponseEntity<>(userAuditInfo, HttpStatus.OK);
                     } else {
                         return new ResponseEntity<>("Actor id not Found", HttpStatus.NOT_FOUND);
                     }
                 }
                 else {
                     return new ResponseEntity<>("Ticket Assignment Group should be \"" + appProperties.getServiceNowGroupName()+"\"", HttpStatus.EXPECTATION_FAILED);
                 }
            } else {
                if(appProperties.getServiceNowGroupID().equals(ticketInfo.getAssignment_group_value())){
                    return new ResponseEntity<>("Ticket Status should be \"Work In Progress\". Current Status: \"" + userAuditInfo.getTicketInfo().getStatus()+"\"", HttpStatus.EXPECTATION_FAILED);
                }
                else {
                    return new ResponseEntity<>("Ticket Assignment Group should be \"" + appProperties.getServiceNowGroupName()+"\"" + " and status should be \"Work In Progress\". Current Status: \"" + userAuditInfo.getTicketInfo().getStatus()+"\"", HttpStatus.EXPECTATION_FAILED);
                }
            }
        } catch(ParseException ex) {
            LOG.error(ex.getMessage());
            return new ResponseEntity<>("Error parsing Service-now response", HttpStatus.EXPECTATION_FAILED);
        }
    }
}
