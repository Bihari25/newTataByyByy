package com.uhg.ihr.utils;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.uhg.ihr.dao.DBHandler;
import com.uhg.ihr.model.KeyValuePair;
import com.uhg.ihr.model.ParsedName;
import com.uhg.ihr.model.SenzingResult;
import com.uhg.ihr.model.b50senzingapi.B50Senzing;
import com.uhg.ihr.model.b50senzingapi.Data;
import com.uhg.ihr.model.b50senzingapi.NAME_;
import com.uhg.ihr.model.b50senzingapi.SearchResult;
import com.uhg.ihr.security.LdapUtil;
import org.apache.commons.lang3.tuple.Pair;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.security.core.Authentication;
import org.springframework.stereotype.Controller;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.util.*;
import java.util.stream.Collectors;

@Controller
public class IHRUtils {

    private static Logger LOGGER = LoggerFactory.getLogger(IHRUtils.class);

    public static String GOLD_DDS_HOST;
    public static String VIP_DDS_HOST;
    public static String SMB_DDS_HOST;
    public static String FIVE_LINE_01_HOST;
    public static String FIVE_LINE_02_HOST;
    public static String FIVE_LINE_03_HOST;
    public static String FIVE_LINE_04_HOST;
    public static String FIVE_LINE_05_HOST;

    private static String RESULT_MATCH = "MATCH";
    private static DateTimeFormatter FORMATTER = DateTimeFormatter.ofPattern("MM/dd/yyyy");

    public static String SM_CHID = "actorChid";
    public static String SM_NAME = "fullName";
    public static String SM_PARSED_NAME = "parsedName";
    public static String SM_PARTIAL_IDENTIFIERS = "partialIdentifiers";
    public static String SM_DOB = "dob";
    public static String SM_MATCH = "match_found";
    public static String SM_POSSIBLE_MATCHES = "possible_matches";
    public static String SM_ERROR = "senzing_match_error";
    public static String ACTOR_TYPE_PROVIDER = "provider";
    public static String ACTOR_TYPE_MEMBER = "member";

    private static Integer MAX_POSSIBLE_RESULTS = 10;
    private static ObjectMapper OM = new ObjectMapper();

    public static Map<String, Object> parseSensingResponse(String result, boolean isDst) {
        Map<String, Object> map = new HashMap<>();

        try {
            B50Senzing senzingResponse = OM.readValue(result,
                    B50Senzing.class);
            Data data = senzingResponse.getData();

            List<SearchResult> searchResults = data.getSearchResults();
            boolean matchFound = false;
            String dob;
            List<SenzingResult> possibleMatches = new ArrayList<>();
            SenzingResult senzingResult;
            for (SearchResult searchResult : searchResults) {
                if (!RESULT_MATCH.equalsIgnoreCase(searchResult.getResultType())) {
                    if (!matchFound && (searchResult.getMatchLevel() == 2 || searchResult.getMatchLevel() == 3)) {
                        if (possibleMatches.size() > MAX_POSSIBLE_RESULTS) {
                            LOGGER.error(" - Got more than max (" + MAX_POSSIBLE_RESULTS + ") possible results with current user criteria, user need to refine.");
                            map.put(SM_ERROR, "Got more than " + MAX_POSSIBLE_RESULTS + " for given search criteria, please add more criteria and search again.");
                            possibleMatches = null;
                            matchFound = false;
                            break;
                        }
                        senzingResult = new SenzingResult();
                        senzingResult.setChid(fetchChid(searchResult));
                        senzingResult.setFullName(searchResult.getEntityName());
                        dob = fetchDob(searchResult);
                        senzingResult.setDob(dob != null ? FORMATTER.format(LocalDate.parse(dob)) : dob);
                        senzingResult.setGender(fetchGender(searchResult));
                        List<String> identifiers = searchResult.getIdentifierData();
                        if (identifiers != null && !identifiers.isEmpty()) {
                            identifiers.removeIf(s -> (!s.contains("SUBSCRIBER_ID") && !s.contains("ALT_MEMBER_ID") && !s.contains("CDB_CONSUMER_ID") && !s.contains("MEDICARE_BENF_ID") && !s.contains("NPI:")));
                            senzingResult.setIdentifiers((identifiers != null ? prettyPrintIds(identifiers) : ""));
                        }
                        senzingResult.setSenzingMatchLevel(searchResult.getMatchLevel());
                        senzingResult.setActorType(getActorType(senzingResult.getChid()));
                        senzingResult.setAddress(fetchPermnentAddress(searchResult));
                        if (!isDst) {
                            senzingResult.setSenzingMatchKey(searchResult.getMatchKey());
                        }
                        possibleMatches.add(senzingResult);
                    }
                } else if (!matchFound) {
                    matchFound = true;
                    map.put(SM_CHID, fetchChid(searchResult));
                    map.put(SM_NAME, searchResult.getEntityName());
                    map.put(SM_PARSED_NAME, getBestParsedName(searchResult));
                    map.put(SM_PARTIAL_IDENTIFIERS, getPartialIdentifiers(searchResult));
                    dob = fetchDob(searchResult);
                    map.put(SM_DOB, dob != null ? FORMATTER.format(LocalDate.parse(dob)) : dob);
                }
            }
            map.put(SM_MATCH, matchFound);
            if (!matchFound) {
                if (possibleMatches != null) {
                    Comparator<SenzingResult> comparatorByScore = Comparator.comparing(SenzingResult::getSenzingMatchLevel);
                    possibleMatches.sort(comparatorByScore);
                }
                map.put(SM_POSSIBLE_MATCHES, possibleMatches);
            } else {
                possibleMatches.clear();
                possibleMatches = null;
            }
        } catch (JsonProcessingException e) {
            map.put(SM_MATCH, false);
            LOGGER.error("Unable to parse sensing response ... ");
            LOGGER.error(e.getMessage());
        }

        return map;
    }

    private static String fetchPermnentAddress(SearchResult searchResult) {
        String retVal = "";
        List<String> addresses = searchResult.getAddressData();
        if (addresses != null) {
            retVal = addresses.stream().filter(e -> e != null && e.toUpperCase().contains("PERMANENT:")).limit(1).map(e -> e.replaceAll("PERMANENT:", "").trim()).collect(Collectors.joining());
            if (retVal == null || retVal.trim().length() < 1) {
                retVal = addresses.stream().filter(e -> e != null && e.toUpperCase().contains("BUSSINESS:")).limit(1).map(e -> e.replaceAll("BUSSINESS:", "").trim()).collect(Collectors.joining());
            }
        }
        return retVal;
    }

    private static String getActorType(String actorId) {
        String actorType = null;
        if (actorId == null || actorId.trim().length() < 7) {
            actorType = "NA";
        } else {
            switch (actorId.charAt(6)) {
                case 'P':
                    actorType = "Provider";
                    break;
                case 'I':
                    actorType = "Member";
                    break;
                case 'O':
                    actorType = "Organization";
                    break;
                default:
                    actorType = "NA";
                    break;
            }
        }
        return actorType;
    }

    private static String prettyPrintIds(List<String> identifierData) {
        return identifierData.toString().replaceAll("\\]|\\[| ", "").replaceAll(",", ", ");
    }

    private static String fetchDob(SearchResult searchResult) {
        String retVal = null;
        if (searchResult.getFeatures() != null
                && searchResult.getFeatures().getDOB() != null
                && searchResult.getFeatures().getDOB().size() > 0
        ) {
            retVal = searchResult.getFeatures().getDOB().get(0).getPrimaryValue();
        } else {
            LOGGER.error("Unable to fetch DOB from senzingResponse - no value @ features->DOB->[0]->primaryValue, for entity - " + searchResult.getEntityId());
        }
        return retVal;
    }

    private static String fetchChid(SearchResult searchResult) {
        String retVal = null;
        if (searchResult.getRecordSummaries() != null
                && searchResult.getRecordSummaries().size() > 0
                && searchResult.getRecordSummaries().get(0).getTopRecordIds() != null
                && searchResult.getRecordSummaries().get(0).getTopRecordIds().size() > 0
        ) {
            retVal = searchResult.getRecordSummaries().get(0).getTopRecordIds().get(0);
        } else {
            LOGGER.error("Unable to fetch DOB from senzingResponse - no value @ recordSummaries->[0]->topRecordIds->[0], for entity - " + searchResult.getEntityId());
        }
        return retVal;
    }

    private static String fetchGender(SearchResult searchResult) {
        String retVal = null;
        if (searchResult.getFeatures() != null
                && searchResult.getFeatures().getGENDER() != null
                && searchResult.getFeatures().getGENDER().size() > 0) {
            retVal = searchResult.getFeatures().getGENDER().get(0).getPrimaryValue();
        } else {
            LOGGER.error("Unable to fetch Gender from senzingResponse - no value @ features->Gender->0->primaryValue, for enitiy - " + searchResult.getEntityId());
        }
        return retVal;
    }

    public static boolean hasDst(Authentication authentication) {
        if (authentication != null && !authentication.getAuthorities().isEmpty()) {
            return authentication.getAuthorities().contains(LdapUtil.DST);
        } else
            return false;
    }

    public static boolean isAdm(Authentication authentication) {
        if (authentication != null && !authentication.getAuthorities().isEmpty()) {
            return authentication.getAuthorities().contains(LdapUtil.ADM);
        } else
            return false;
    }

    public static boolean isDev(Authentication authentication) {
        if (authentication != null && !authentication.getAuthorities().isEmpty()) {
            return authentication.getAuthorities().contains(LdapUtil.DEV);
        } else
            return false;
    }

    public static boolean isOnt(Authentication authentication) {
        if (authentication != null && !authentication.getAuthorities().isEmpty()) {
            return authentication.getAuthorities().contains(LdapUtil.ONT);
        } else
            return false;
    }

    public static boolean isPr(Authentication authentication) {
        if (authentication != null && !authentication.getAuthorities().isEmpty()) {
            return authentication.getAuthorities().contains(LdapUtil.PR);
        } else
            return false;
    }

    public static String fetchSpecialitiesWithCodes(String raw_provider_json, DBHandler dbHandler) {
        String retValue = null;
        if (raw_provider_json != null) {
            String b50Chid = null;
            try {
                JsonNode root = OM.readValue(raw_provider_json, JsonNode.class);
                b50Chid = root.get("_id").asText();
                JsonNode spls = root.get("speciality");
                StringBuilder splalites = new StringBuilder();
                String code;
                String value;
                if (spls != null && spls.size() > 0) {
                    String seperator = "";
                    for (JsonNode spl : spls) {
                        code = spl.asText();
                        value = dbHandler.ontLookupForSpeciality(code);
                        if (value != null && !value.equalsIgnoreCase(code)) {
                            splalites.append(seperator + value + "[" + code + "]");
                        } else {
                            splalites.append(seperator + code);
                        }
                        seperator = ",";
                    }
                    retValue = splalites.toString();
                }
            } catch (JsonProcessingException ex) {
                LOGGER.error(" - Unable to lookup specialities for provider - " + b50Chid + ", Due to error - " + ex.getMessage());
            }
        }
        return retValue;
    }

    public static ParsedName getBestParsedName(SearchResult searchResult) {
        String entityName = searchResult.getEntityName();
        ArrayList<List<NAME_>> names = new ArrayList<>();
        searchResult.getRecords().forEach(record -> names.add(record.getOriginalSourceData().getNAMES()));
        ParsedName parsedName = new ParsedName();
        //Match record names against entity name to find exact match
        for (List<NAME_> recordNames : names) {
            for (NAME_ name : recordNames) {
                StringBuilder builder = new StringBuilder();
                //Build the name
                builder.append(name.getNAMEFIRST());
                if (name.getNAMEMIDDLE() != null && !name.getNAMEMIDDLE().isEmpty()) {
                    builder.append(" ").append(name.getNAMEMIDDLE());
                }
                if (name.getNAMELAST() != null && !name.getNAMELAST().isEmpty()) {
                    builder.append(" ").append(name.getNAMELAST());
                }

                if (entityName.equalsIgnoreCase(builder.toString())) {
                    parsedName.setFirst(name.getNAMEFIRST());
                    parsedName.setLast(name.getNAMELAST());
                    return parsedName;
                }
            }
        }

        //Best effort name parsing when no record names match entity name
        String[] nameParts = entityName.split(" ");
        switch (nameParts.length) {
            case 1: {
                parsedName.setFirst(nameParts[0]);
                break;
            }
            case 2: {
                parsedName.setFirst(nameParts[0]);
                parsedName.setLast(nameParts[1]);
                break;
            }
            case 3: {
                parsedName.setFirst(nameParts[0]);
                parsedName.setLast(nameParts[2]);
                break;
            }
            //Assumes last name is the biggest
            default: {
                StringBuilder lastNameBuilder = new StringBuilder();
                lastNameBuilder.append(nameParts[2]);
                for (int i = 3; i < nameParts.length; ++i) {
                    lastNameBuilder.append(" ").append(nameParts[i]);
                }
                parsedName.setFirst(nameParts[0]);
                parsedName.setLast(lastNameBuilder.toString());
            }
        }
        return parsedName;
    }

    public static List<KeyValuePair<String, String>> getPartialIdentifiers(SearchResult searchResult) {
        List<KeyValuePair<String, String>> parsedIdentifiers = new ArrayList<>();
        for (String identifier : searchResult.getIdentifierData()) {
            String[] splitIdentifier = identifier.split(":");
            splitIdentifier[0] = splitIdentifier[0].trim();
            splitIdentifier[1] = splitIdentifier[1].trim();
            switch (splitIdentifier[0]) {
                case "SUBSCRIBER_ID": {
                    addPartialIdentifier("SUBSCRIBER_ID", splitIdentifier[1], parsedIdentifiers);
                    break;
                }
                case "MEMBER_ID": {
                    addPartialIdentifier("MEMBER_ID", splitIdentifier[1], parsedIdentifiers);
                    break;
                }
                case "MBI": {
                    addPartialIdentifier("MBI", splitIdentifier[1], parsedIdentifiers);
                    break;
                }
            }
        }
        return parsedIdentifiers;
    }

    public static void addPartialIdentifier(String identifierId, String identifierValue, List<KeyValuePair<String, String>> parsedIdentifiers) {
        if (identifierValue.charAt(0) == '0') {
            parsedIdentifiers.add(new KeyValuePair<>(identifierId, trimLeadingZeroes(identifierValue)));
        }
        parsedIdentifiers.add(new KeyValuePair<>(identifierId, identifierValue));
    }

    public static String trimLeadingZeroes(String identifier) {
        if (identifier.charAt(0) == '0') {
            int index = 0;
            while (identifier.charAt(index) == '0') {
                ++index;
            }
            return identifier.substring(index);
        } else {
            return identifier;
        }
    }

}