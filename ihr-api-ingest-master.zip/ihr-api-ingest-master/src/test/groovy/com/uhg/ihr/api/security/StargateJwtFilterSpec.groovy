package com.uhg.ihr.api.security

import com.uhg.ihr.api.fhir.BaseFhirSpecification
import com.uhg.ihr.centrihealth.api.security.StargateJwtFilter
import io.micronaut.http.HttpRequest
import io.micronaut.http.HttpResponse
import io.micronaut.http.client.HttpClient
import io.micronaut.http.client.RxHttpClient
import io.micronaut.http.filter.ServerFilterChain
import io.micronaut.security.authentication.AuthenticationException
import org.reactivestreams.Publisher
import spock.lang.Unroll

@Unroll
class StargateJwtFilterSpec extends BaseFhirSpecification {

    static String BAD_TOKEN = "Bearer eyJ0eXAiOiJKV1QiLCJhbGciOiJSUzI1NiJ9.ew0KICJpc3MiOiJsYXllcjctand0LXRlc3QtaXNzdWVyIiwNCiAiYXVkIjoibGF5ZXI3LWp3dC10ZXN0LWF1ZGllbmNlIiwNCiAiaWF0IjoiMTUzMzgyNjQ0NiIsDQogImV4cCI6IjE1MzM4MjY0NTYiLA0KICJzdWIiOiJvb2IiLA0KICJlbmZvcmNlQXBpTGV2ZWxBdXRob3JpemF0aW9uIjoiZmFsc2UiLA0KDQogImNvbnRleHQiOiB7DQogICJ1c2VyIjp7DQogICAibmFtZSI6Imw3eHg0NDI3NDFlZDAzMTI0OWJjOTVmOGQzNzY2YjY0YzkxYSINCiAgICwiY2xpZW50X2lkIjoibDd4eDQ0Mjc0MWVkMDMxMjQ5YmM5NWY4ZDM3NjZiNjRjOTFhIg0KICAgfSwNCiAgImNsaWVudCI6ew0KICAgIm5hbWUiOiJteUFwcCIsDQogICAiYXV0aE1ldGhvZCI6Im9hdXRoIg0KICAgLCJhcHBOYW1lIjogIm15QXBwIiwiYXBwUGxhdGZvcm0iOiAibW9iaWxlIg0KICB9DQogfQ0KfQ.X73D6HZQxKQ8FhoLe-PN5hbzaQVGg8YY-AkoGE4YEx-KSCVDi1GRVobRI8ytlFneltAw3KIuXYDKh8OL9bAr40rblTjiXBwfD8ZKxt2swMG61o5HzROafhlEVrknSh9CB_VkKj-UuBuWpgQAMSd32DL47zaXPMmjkpgzIfZKpqS11moNcKawU2_Xhr6HNFjRUMVe1QAN0sYI8M42RqYTj2dbWvZbOZHBkWn1iYdm9JeF-OL-4Jv46JlOLl8vzZbMqFz74APNuHB_LN3bjee7YPqetB4y0HbpNhpFo9YN9ptfjhKCYdJ-Cfwjomn0hGGiEt7vKq-VdaJdoihFmSPfTg"
    static String MAGIC_TOKEN = StargateJwtFilter.MAGIC_TOKEN
    static String EXPIRED_TOKEN = "eyJ4NWMiOlsiTUlJR3REQ0NCSnlnQXdJQkFnSVRhZ0FCd0ZxbWc1ckY0akNDbndBQUFBSEFXakFOQmdrcWhraUc5dzBCQVFzRkFEQnBNUXN3Q1FZRFZRUUdFd0pWVXpFU01CQUdBMVVFQ0JNSlRXbHVibVZ6YjNSaE1SUXdFZ1lEVlFRSEV3dE5hVzV1WldGd2IyeHBjekVPTUF3R0ExVUVDaE1GVDNCMGRXMHhJREFlQmdOVkJBTVRGMDl3ZEhWdFNXNTBaWEp1WVd4SmMzTjFhVzVuUTBFeU1CNFhEVEl3TURneE1USXpNREkwTmxvWERUSXhNRGd4TVRJek1ESTBObG93Z1p3eEN6QUpCZ05WQkFZVEFsVlRNUkl3RUFZRFZRUUlFd2xOYVc1dVpYTnZkR0V4RVRBUEJnTlZCQWNUQ0ZCc2VXMXZkWFJvTVNBd0hnWURWUVFLRXhkVmJtbDBaV1JJWldGc2RHZ2dSM0p2ZFhBZ1NXNWpMakVkTUJzR0ExVUVDeE1VUkdGMFlTQkZlSFJsY201aGJHbDZZWFJwYjI0eEpUQWpCZ05WQkFNVEhHZGhkR1YzWVhrdGMzUmhaMlV0WTI5eVpTNXZjSFIxYlM1amIyMHdnZ0VpTUEwR0NTcUdTSWIzRFFFQkFRVUFBNElCRHdBd2dnRUtBb0lCQVFDTzFRUm9ReFBGS2R4TGY5VVdUaGNEQTFFaDlqMzZTUGR0S3hmQUxXUVFaVlB1clZwdFcxODV2MnB5QzBaTVRZNkhkcE5ySW5SeFI1a09xZHpwVTN3Mk1ndk5QdmRsT0tfWEhMbnBEbFFKYUg1YzZvQmI3cnc5RGVXSlNsRG8zd2Q5LXZzRW1GQXBhSkN2bjRGdUpWaFU1UUJ4bmJRSnJkWXQyTDVQbHBqaVFaQklEVnVlTFV4V2dRWHZjMDhGcVByOFNkWFBwdF9fekN3YmgwSmIyWTV4UF93VkdHTXVMLWxDMXlKYVNvVXRLX0t1RVlzN3ZScUdwYTBtWFZmVmJlVUxCNHRNQzVOQy1jZTk3djNzRENBSEF1TW04a2pDRjJqSGpNSS16QTJQaWxWM0Y1R0ttT20zMS1lazl2Xzg5SU5mMjhQdXhzQVBta1JhWjZFUzJrb1pBZ01CQUFHamdnSWZNSUlDR3pDQmdRWURWUjBSQkhvd2VJSWdaMkYwWlhkaGVTMXpkR0ZuWlMxamIzSmxMV1ZzY2k1dmNIUjFiUzVqYjIyQ0lHZGhkR1YzWVhrdGMzUmhaMlV0WTI5eVpTMWpkR011YjNCMGRXMHVZMjl0Z2h4bllYUmxkMkY1TFhOMFlXZGxMV052Y21VdWIzQjBkVzB1WTI5dGdoUmtZWFJoTFhOMFlXZGxMbTl3ZEhWdExtTnZiVEFkQmdOVkhRNEVGZ1FVNlIyYU56NEczX1BDZWdRUk0yUkZuMF91azhnd0h3WURWUjBqQkJnd0ZvQVVkMjZ1dUxpd0M5VjZHQXpKX0VKZmNIQ1hrU2d3UmdZRFZSMGZCRDh3UFRBN29EbWdONFkxYUhSMGNEb3ZMMjlqYzNBdWIzQjBkVzB1WTI5dEwzQnJhUzlQY0hSMWJVbHVkR1Z5Ym1Gc1NYTnpkV2x1WjBOQk1pNWpjbXd3ZVFZSUt3WUJCUVVIQVFFRWJUQnJNRUVHQ0NzR0FRVUZCekFDaGpWb2RIUndPaTh2YjJOemNDNXZjSFIxYlM1amIyMHZjR3RwTDA5d2RIVnRTVzUwWlhKdVlXeEpjM04xYVc1blEwRXlMbU55ZERBbUJnZ3JCZ0VGQlFjd0FZWWFhSFIwY0RvdkwyOWpjM0F1YjNCMGRXMHVZMjl0TDI5amMzQXdDd1lEVlIwUEJBUURBZ1N3TUQwR0NTc0dBUVFCZ2pjVkJ3UXdNQzRHSmlzR0FRUUJnamNWQ0lXRjdncUI2dklHaHZtVEZicWZEb0xFOFg2QldvYmJzbjJIcDhBT0FnRmtBZ0VzTUIwR0ExVWRKUVFXTUJRR0NDc0dBUVVGQndNQkJnZ3JCZ0VGQlFjREFqQW5CZ2tyQmdFRUFZSTNGUW9FR2pBWU1Bb0dDQ3NHQVFVRkJ3TUJNQW9HQ0NzR0FRVUZCd01DTUEwR0NTcUdTSWIzRFFFQkN3VUFBNElDQVFBUFdzc2ZpMDIwRkt2dmFyRUFiYnRVYzdIRE1GandDMy13YkdpOUpzeFZ4TVBsTUpIbzRQZmZFODZRaE53QjhMRUxqRlMxUWJyT2NMcW8xekpnYXRueGwxV00wQTU1eHBsazkzS0lTM0U2Sm8ta1p5aHIxZVdyN0kxcnBPUW1JNGhZT25OWkkxTFk5WnJ5N2FUcnlEUG1IdjVOOEFnek10N1N3emQzOHF3TUMtRi1DX3lkSjMwSXlaOWQ1aHJYd3R5ZllCRjZsb3RBN3RfUGVpamh4VUpZY1hTOE5YTGVDdUw5a1U5bnVSbzdvb1hEY3ZQaWFBWlZwTVN1Z21zUUNySmpuV19LbU01Y1M2ajZjNlcyQ040OFZ6R3hfWFBYUGhvWmQ2ZC1Tei1NMWJfWjNBX0dYdEhldWpmd3Y0b1c5UFB0bVd2QkpJVnhmN0UzWmJma0N4Y3NvT0tNd0phYXdicjlaS0YyQ09Rb1JjQ0I3ZzVfQ29MNFgzMG9SdkxyQURISHpkNjlCYjM1X0JmZlFoSGlJU25yUks4UmY3RU9ndEx2UnhaOFBENy1ZMVloeHZ6aUlNdzB2WGxJdW5laC1OcU9Ydk9ZT0VKU3BxQmItLTF5aWhtbTNpbTFNaDF6a3lObmdrakdBY2dLQWItcFdHMXgxdnhsX2hKU1ZNRmVoTENrQ21UQkJVVFVKVnZNODI0dVAtZFduYzZsbWVrMk1hMDNtcVV4empYWU5DVlZJXzZwLW1vdVlnMVdPRHRiVXpnd3NLN2NvVFlzR2hMVHRPUXRuZVNNMlNIVzBSUWxIb0JUQjlZQUZCMkZqa3ppbURPVEFTRElLY2ZWbWpiclpQWE9kYWlWejVCa0FqWjVyZUJYZ1JCOVF4ejRWdnU1aXBoeWdZQ25WQmgtZWciXSwiYWxnIjoiUlMyNTYiLCJ0eXAiOiJKV1QifQ.eyJhdWQiOiJqd3R2YWxpZGF0aW9uIiwiaWF0IjoxNjAyNTMwNTk5LCJpc3MiOiJTdGFyZ2F0ZVN0YWdlQ29yZSIsImp0aSI6ImNmZGIxNDc2LTc4OGEtNDIwOS04MGJlLTVlMDFjY2U4NDQ5YyIsInBheWxvYWRoYXNoIjoiIiwiZXhwIjoxNjAyNTMwNjU5fQ.U4bamkPU8VSEREXOBFP3osXOqS844lczY2l3x0NgypAQAxs4mjJId6yKatKyhJRFLezNOWGRwKo_pvog5K7Rn5IrLPWyTZtK4L6q33Kaga2kzvme5d_zMAUBcx0x95t5KpF28Hn3fDPxZAY5LM9e5bWMrjpY7ZHJr8-oaVKuTWSlmOiI_qNCGG68mq3eF5sX3GGmLlRYOIVVuwKLZUQwB8hfcAnsgvT-iNQkvvDCCQeas0sRP3j-CjhpkmvwDIUf2O1E6bSSlTXmrHa6UFV0QWTBaAcQ5rzLdrvjRNZDyv_lRmUH72dGSdBUN5hzNUfX5dUCTKxeQFrz5Eak-1-_qA"

    def "it initializes leeway #desc"() {
        given:
        StargateJwtFilter sjf = new StargateJwtFilter(leewayIn, "")

        expect:
        sjf.getLeeway() == leewayOut

        where:
        desc   | leewayIn || leewayOut
        "null" | null     || 1
        "-5"   | -5       || 1
        "0"    | 0        || 0
        "1"    | 1        || 1
        "60"   | 60       || 60
        "119"  | 119      || 119
        "131"  | 130      || 120
    }

    def "it filters bad tokens #desc"() {
        when:
        ServerFilterChain sfc = Mock(ServerFilterChain)
        HttpRequest req = baseRequest()
        req.headers.remove("JWT")
        req.headers.add(headerName, headerValue)

        def jwtFilter = new StargateJwtFilter(1, "")

        then:
        Publisher response = jwtFilter.doFilterOnce(req, sfc)
        AuthenticationException hi = (AuthenticationException) response["error"]
        hi.getMessage().contains(exceptionMessage as CharSequence)

        where:
        desc                    | headerName | headerValue   || exceptionMessage
        "no JWT header"         | "NOJWT"    | "no value"    || "JWT header not found"
        "bad JWT token"         | "JWT"      | "dadas"       || "unable to decode JWT and x5c claim"
        "no bearer, token only" | "JWT"      | BAD_TOKEN     || "unable to decode JWT and x5c claim"
        "bearer but no token"   | "JWT"      | "Bearer "     || "JWT token not found"
        "magic token fail"      | "JWT"      | MAGIC_TOKEN   || "unable to decode JWT and x5c claim"
        //TODO: Fix expired token test. Static token is no longer valid
//        "expired good token"    | "JWT"      | EXPIRED_TOKEN || "The Token has expired on Mon Oct 12"
    }

    def "it allows magic token and status reqs #desc"() {
        given:
        ServerFilterChain sfc = Mock(ServerFilterChain)
        HttpRequest req = HttpRequest.POST(path, "")
        req.headers.add("JWT", headerValue)
        def jwtFilter = new StargateJwtFilter(1, "dev")

        when:
        jwtFilter.doFilterOnce(req, sfc)

        then:
        1 * sfc.proceed(_)

        where:
        desc           | path           | headerValue
        "/status"      | "/status"      | "no value"
        "/info"        | "/info"        | "no value"
        "/prometheus"  | "/prometheus"  | "no value"
        "/health"      | "/health"      | "no value"
        "/needs_token" | "/needs_token" | MAGIC_TOKEN
    }

    def "Check Stargate Token"() {
        given:
        ServerFilterChain sfc = Mock(ServerFilterChain)

        // get an actual stage stargate token
        def tokenRequest = HttpRequest.GET("https://gateway-stage-core.optum.com/jwt/validation")
        HttpClient httpClient = RxHttpClient.create(new URL("https://gateway-stage-core.optum.com/jwt/validation"))
        HttpResponse<String> rsp = httpClient.toBlocking().exchange(tokenRequest, String.class)

        // build a request using that token
        HttpRequest req = HttpRequest.POST("/needs_token", "")
        req.headers.add("JWT", rsp.getBody().get())
        def jwtFilter = new StargateJwtFilter(1, "")

        when:
        jwtFilter.doFilterOnce(req, sfc)

        then:
        1 * sfc.proceed(_)
    }
}