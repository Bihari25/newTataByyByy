package com.uhg.ihr.api.model

import com.uhg.ihr.api.fhir.BaseFhirSpecification
import com.uhg.ihr.centrihealth.api.model.CoverageDecorator
import com.uhg.ihr.centrihealth.api.model.FhirMapper
import com.uhg.ihr.centrihealth.senzing.model.SenzingRequest
import org.hl7.fhir.r4.model.Bundle
import spock.lang.Unroll

@Unroll
class CoverageDecoratorSpec extends BaseFhirSpecification {

    def "Test buildSenzingRequest #desc"() {

        given:
        def resourceBundle = getResourceBundle(fileName)
        def decorator = new CoverageDecorator()
        def senzingRequest = new SenzingRequest()

        when:
        for (Bundle.BundleEntryComponent entity : resourceBundle.getEntry()) {
            senzingRequest = decorator.buildSenzingRequest(entity, senzingRequest)
        }

        then:
        search_id == senzingRequest.getSearchId()

        where:
        desc           | fileName                 | search_id
        "Happy Path"   | "ingest_medication.json" | "00000251082177"
        "Unhappy Path" | "coverage_missing.json"  | null
    }
}