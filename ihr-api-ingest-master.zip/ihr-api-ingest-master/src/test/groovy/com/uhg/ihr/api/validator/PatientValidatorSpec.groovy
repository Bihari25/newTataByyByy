package com.uhg.ihr.api.validator

import com.uhg.ihr.api.fhir.BaseFhirSpecification
import com.uhg.ihr.centrihealth.api.exception.IhrBadRequestException
import com.uhg.ihr.centrihealth.api.util.ResponseErrorMessages
import com.uhg.ihr.centrihealth.api.validator.PatientValidator
import org.hl7.fhir.r4.model.Bundle
import org.hl7.fhir.r4.model.Patient
import spock.lang.Shared
import spock.lang.Unroll

class PatientValidatorSpec extends BaseFhirSpecification {

    @Unroll
    def "Patient test cases #desc"() {

        given:
        Bundle resourceBundle = getResourceBundle("medicationStatement.json")

        when:
        def isValid = false
        def validationMessage = null

        for (Bundle.BundleEntryComponent entity : resourceBundle.getEntry()) {
            if (entity.getResource() instanceof Patient) {
                try {
                    Patient patient = (Patient) entity.getResource()
                    if (condition == "dobIsNull") {
                        patient.setBirthDate(null)
                    } else if (condition == "familyIsNull") {
                        patient.getNameFirstRep().setFamily("")
                    } else if (condition == "givenIsNull") {
                        patient.getNameFirstRep().setGiven(null)
                    }

                    PatientValidator.of().validate(patient, fhirAttributesWrapper)
                    isValid = true
                }
                catch (IhrBadRequestException | Exception ee) {
                    validationMessage = ee.getMessage()
                    isValid = false
                }
            }
        }

        then:
        isValid == expected
        validationMessage == errorMessage

        where:
        desc            | condition      || errorMessage            || expected
        "HappyPath"     | ""             || null                    || true
        "DOB is null"   | "dobIsNull"    || ResponseErrorMessages.INVALID_BIRTHDAY_FORMAT || false
        "Family IsNull" | "familyIsNull" || ResponseErrorMessages.PATIENT_NAME_MISSING    || false
        "Given Is Null" | "givenIsNull"  || ResponseErrorMessages.PATIENT_NAME_MISSING    || false
    }

}
