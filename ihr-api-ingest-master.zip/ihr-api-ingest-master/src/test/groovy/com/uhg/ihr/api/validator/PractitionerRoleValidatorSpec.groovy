package com.uhg.ihr.api.validator

import com.uhg.ihr.api.fhir.BaseFhirSpecification
import com.uhg.ihr.centrihealth.api.exception.IhrBadRequestException
import com.uhg.ihr.centrihealth.api.validator.PractitionerRoleInfoCodeEnum
import com.uhg.ihr.centrihealth.api.validator.PractitionerRoleValidator
import spock.lang.Unroll

@Unroll
class PractitionerRoleValidatorSpec extends BaseFhirSpecification {

    def "Test validate #desc"() {
        given:
        def exception = false
        def role = buildPractitionerRole(codeText)
        def message

        when:
        try {
            PractitionerRoleValidator.of().validate(role, null)
        } catch (IhrBadRequestException ibre) {
            exception = true
            message = ibre.getMessage() //FIXME: need to test this
        }
        then:
        exception == failed

        where:
        desc                  | codeText                                          || failed
        "Happy Path"          | PractitionerRoleInfoCodeEnum.FACITLITY_STAFF.code || false
        "Incorrect code text" | "caregver"                                        || true
        "code null"           | null                                              || true

    }

}
