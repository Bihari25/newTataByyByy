package com.uhg.ihr.api.model

import com.uhg.ihr.api.fhir.BaseFhirSpecification
import com.uhg.ihr.centrihealth.api.model.PractitionerDecorator
import com.uhg.ihr.centrihealth.senzing.model.SenzingRequest
import org.hl7.fhir.r4.model.Bundle

class PractitionerDecoratorSpec extends BaseFhirSpecification {

    def "Test buildSenzingRequest #desc"() {

        given:
        def resourceBundle = getResourceBundle(fileName)
        def decorator = new PractitionerDecorator()
        def senzingRequest = new SenzingRequest()

        when:
        for (Bundle.BundleEntryComponent entity : resourceBundle.getEntry()) {
            senzingRequest = decorator.buildSenzingRequest(entity, senzingRequest)
        }

        then:
        empId == senzingRequest.getEmpId()

        where:
        desc           | fileName                        | empId
        "Happy Path"   | "ihr-api-ingest_new_edits.json" | "NMOON1000"
        "Unhappy Path" | "patient_missing.json"          | null
    }
}
