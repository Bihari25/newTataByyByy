package com.uhg.ihr.api.model

import com.fasterxml.jackson.databind.JsonNode
import com.google.common.collect.ImmutableList
import com.uhg.ihr.api.fhir.BaseFhirSpecification
import com.uhg.ihr.api.util.JsonUtils
import com.uhg.ihr.centrihealth.api.client.B50SenzingClient
import com.uhg.ihr.centrihealth.api.service.SenzingService
import com.uhg.ihr.centrihealth.api.util.AppUtils
import com.uhg.ihr.centrihealth.senzing.model.SenzingLookup
import com.uhg.ihr.centrihealth.senzing.model.SenzingRequest
import io.reactivex.Maybe
import spock.lang.Unroll

@Unroll
class SenzingServiceSpec extends BaseFhirSpecification {

    public static final String TOKEN = "Bearer eyJhbGciOiJSUzUxMiJ9.eyJyb2xlIjoidXNlciIsImNyZWF0ZWQiOjE1MjI4NDk5OTE3OTcsInVzZXJuYW1lIjoiY2xvdWRzZGsifQ.dzfwWRugsnhPHB0RNT9lZHnX7gvNfGks_ivTc_dQ6-ejM6B1-Chx3WrwBE8drdy4ZbvkVTlHkHRSu3nBZi3Aw0wmN5N7UPUI0wP2KhAHGQS4-LOXgD58ioX9ep3k6hZQqy-oJor5Q3wZS8HJKMMY8izIROtJ5z-z5Y2RRw3ONnQLL5JR40hF9d5mFKA8Y1giEP32qg259MVbdkHNkI0ceq8hrXJ7w_OD4-JPteNhM9EeyNOmzjrKSEG-tkYrWI7g5xgvgMuO8iHFym4WhkDT6FNfcK2xs8QfCbJCZqV28xSIjbrm0El0L7kRzJbsKBxQ7FNJ35iaX18DpQMpu6usUQ"

    def "Test owner chid scenarios #desc"() {

        given:
        def apiResponse = AppUtils.readResource(input)
        JsonNode dataNode = MAPPER.readValue(apiResponse, JsonNode.class)
        def dataJson = dataNode.get("data").get("searchResults").get(resultPosition - 1)
        Map<String, Object> resultData = MAPPER.readValue(dataJson.toString(), HashMap.class)

        when:
        def result = SenzingService.getOwnerChid(resultData)

        then:
        result == expectedIhr

        where:
        desc             | input                       | resultPosition || expectedIhr
        "first of 1-1"   | "senzing-match-1-1-r2.json" | 1              || "ACT1"
        "first of 1-1"   | "senzing-match-1-1-r2.json" | 2              || "ACT2"
        "first of 1-2"   | "senzing-match-1-2.json"    | 1              || "ACT1"
        "second of 1-2"  | "senzing-match-1-2.json"    | 2              || "ACT2"
        "first of 2-2"   | "senzing-match-2-2.json"    | 1              || "ACT1"
        "second of 2-2"  | "senzing-match-2-2.json"    | 2              || "ACT2"
        "first of 3"     | "senzing-match-3-1-r2.json" | 1              || "232ACTI109731247973826560"
        "second of 3"    | "senzing-match-3-1-r2.json" | 2              || "886ACTI175222969147838465"
        "first of 1-2-3" | "senzing-match-1-2-3.json"  | 1              || "ACT1"
        "third of 1-2-3" | "senzing-match-1-2-3.json"  | 3              || "ACT3"
    }

    def "filterIhrId finds the correct act chid"() {
        given:
        SenzingService senzingService = new SenzingService()
        B50SenzingClient mockSenzingClient = Mock(B50SenzingClient)
        senzingService.b50SenzingClient = mockSenzingClient
        def sampleRequestJson = AppUtils.readResource("senzing-request.json")
        def senzingRequest = JsonUtils.deserializeJson(SenzingRequest.class, sampleRequestJson)
        def sampleResponseJson = AppUtils.readResource("senzing-response-api.json")
        def senzingResponse = JsonUtils.deserializeJson(LinkedHashMap.class, sampleResponseJson)
        def expectedApiResponse = Maybe.just(senzingResponse)

        when:
        String result = senzingService.b50filterIhrId(TOKEN, senzingRequest, "corrId").blockingGet()

        then:
        1 * mockSenzingClient.fetchEntities(_, _, _, _) >> { expectedApiResponse }
        result == "ACT33716240"
    }

    def "searchIhrId scenario: #desc"() {
        given:
        def apiResponse = AppUtils.readResource(input)
        def senzingResponse = JsonUtils.deserializeJson(LinkedHashMap.class, apiResponse)

        when:
        def result = SenzingService.searchIhrId(senzingResponse, "corrId")

        then:
        result == expectedIhr

        where:
        desc                   | input                                     || expectedIhr
        "Single Search Result" | "senzing-response-api.json"               || "ACT33716240"
        "Multi Search Result"  | "senzing-multi-results-response-api.json" || "ACT33716240"
    }

    def "searchIhrId more: #desc"() {

        given:
        def apiResponse = AppUtils.readResource(input)
        def senzingResponse = JsonUtils.deserializeJson(LinkedHashMap.class, apiResponse)

        when:
        def result
        def exception = false

        try {
            result = SenzingService.searchIhrId(senzingResponse, "corrId")
        } catch (Exception e) {
            result = e.getMessage()
            exception = true
        }

        then:
        exception == expectException
        result.contains(resultString)

        // 2 records, both match level 2 = fail
        // 2 records, both match level 1 = fail
        // 2 records, first 1, second 2 = succeed
        // 3 records, first 2, second 3, third 1 = succeed
        where:
        desc                    | input                       || expectException | resultString
        "2 level 2s"            | "senzing-match-2-2.json"    || true            | "Unable to find"
        "2 level 1s"            | "senzing-match-1-1-r2.json" || true            | "multiple ihr identifiers: [ACT1, ACT2]"
        "1 level 1 multi first" | "senzing-match-1-2.json"    || false           | "ACT1"
        "1 level 1 multi last"  | "senzing-match-1-2-3.json"  || false           | "ACT3"
    }

    def "getIdFromList #desc"() {
        when:
        def result
        def exception = false

        try {
            result = SenzingService.getIdFromList(input)
        }
        catch (Exception e) {
            result = e.getMessage()
            exception = true
        }

        then:
        exception == expectException
        result.contains(resultString)

        where:
        desc       | input                                 || expectException | resultString
        "null"     | null                                  || true            | "Unable to find"
        "empty"    | new ArrayList()                       || true            | "Unable to find"
        "single"   | ImmutableList.of("hello-id")          || false           | "hello-id"
        "multiple" | ImmutableList.of("hello-id", "uh-oh") || true            | "[hello-id, uh-oh]"
    }

    def "getLogDataFromResult scenario: #desc"() {
        given:
        def apiResponse = AppUtils.readResource(input)
        def senzingResponse = JsonUtils.deserializeJson(LinkedHashMap.class, apiResponse)
        def dataJson = (LinkedHashMap<String, Object>) senzingResponse.get(SenzingLookup.DATA)
        def searchResults = (List<LinkedHashMap<String, Object>>) dataJson.get(SenzingLookup.RESULTS)

        when:
        def result = SenzingService.getLogDataFromResult(searchResults[0])

        then:
        result == expectedIhr

        where:
        desc                   | input                                     || expectedIhr
        "Single Search Result" | "senzing-response-api.json"               || "ACT33716240:1:+NAME+DOB+GENDER+MEDICARE_BENF_ID"
        "Multi Search Result"  | "senzing-multi-results-response-api.json" || "ACT33716240:1:+NAME+DOB+GENDER+MEDICARE_BENF_ID"
        "error"                | "senzing-log-error.json"                  || "unknown"
    }

    def "validateSenzingResponse scenario: #desc"() {
        given:
        def exception = false
        def apiResponse = AppUtils.readResource(input)
        def senzingResponse = JsonUtils.deserializeJson(LinkedHashMap.class, apiResponse)
        def dataJson = (LinkedHashMap<String, Object>) senzingResponse.get(SenzingLookup.DATA)

        when:
        try {
            SenzingService.validateSenzingResponse(dataJson)
        }
        catch (Exception e) {
            exception = true
        }

        then:
        exception == expectException

        where:
        desc                    | input                                     | expectException
        "Single Search Result"  | "senzing-response-api.json"               | false
        "Multi Search Result"   | "senzing-multi-results-response-api.json" | false
        "Search result missing" | "senzing-null-data.json"                  | true
        "Search results null"   | "senzing-null-searchresults.json"         | true

    }

}