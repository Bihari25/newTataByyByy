package com.uhg.ihr.centrihealth.senzing.model

import spock.lang.Specification

class SenzingPropertiesSpec extends Specification {

    SenzingProperties sampleSenzingProperties = new SenzingProperties(subject: "tTest", duration: 3000, secretKey: "AbcXyv838!", roles: ["dev", "qa"], audience: "test-aud")

    def "SenzingProperties: getters/setter"() {
        when:
        SenzingProperties senzingProperties = sampleSenzingProperties
        then:
        senzingProperties.getRoles().size() == 2
        senzingProperties.getRoles()[0] == "dev"
        senzingProperties.getDuration() == 3000
        senzingProperties.getSubject() == "tTest"
        senzingProperties.getSecretKey() == "AbcXyv838!"
        senzingProperties.getAudience() == "test-aud"
    }

    def "SenzingProperties: toString"() {
        when:
        SenzingProperties senzingProperties = sampleSenzingProperties
        def result = senzingProperties.toString()
        println("result "+result)
        println("toString "+senzingProperties.toString())

        then:
        result.contains("SenzingProperties(subject=tTest, duration=3000, secretKey=AbcXyv838!, roles=[dev, qa], audience=test-aud)")

    }
}
