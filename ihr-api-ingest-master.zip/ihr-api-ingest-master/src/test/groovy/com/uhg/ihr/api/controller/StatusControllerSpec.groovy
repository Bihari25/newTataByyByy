package com.uhg.ihr.api.controller

import io.micronaut.context.annotation.Property
import io.micronaut.http.HttpRequest
import io.micronaut.http.HttpResponse
import io.micronaut.http.client.RxHttpClient
import io.micronaut.http.client.annotation.Client
import io.micronaut.test.extensions.spock.annotation.MicronautTest
import spock.lang.Ignore
import spock.lang.Specification

import javax.inject.Inject

@MicronautTest
@Property(name = "ness.enabled", value = "false")
class StatusControllerSpec extends Specification {

    @Inject
    @Client(id = '/')
    RxHttpClient httpClient

    def "it returns 200 on the status endpoint"() {
        when:
        HttpRequest req = HttpRequest.GET("/status")

        then:
        HttpResponse<String> rsp = httpClient.toBlocking().exchange(req, String.class)
        200 == rsp.getStatus().code
    }

}
