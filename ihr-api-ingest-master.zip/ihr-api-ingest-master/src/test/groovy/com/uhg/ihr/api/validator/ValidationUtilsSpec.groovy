package com.uhg.ihr.api.validator

import com.uhg.ihr.api.fhir.BaseFhirSpecification
import com.uhg.ihr.api.util.TestData
import com.uhg.ihr.centrihealth.api.exception.IhrBadRequestException
import com.uhg.ihr.centrihealth.api.util.ResponseErrorMessages
import com.uhg.ihr.centrihealth.api.validator.ValidationUtils
import org.hl7.fhir.r4.model.*
import spock.lang.Unroll

import java.text.SimpleDateFormat
import java.time.ZoneId
import java.time.ZonedDateTime

@Unroll
class ValidationUtilsSpec extends BaseFhirSpecification {

    void "Happy path - DateTimeType has any timestamp"() {
        given:
        def dateAndTimestamp = new DateTimeType(testValue)

        when:
        def isit = ValidationUtils.hasNoTimestamp(dateAndTimestamp)

        then:
        isit == expected

        where:
        testValue                   || expected
        "1945-10-10"                || true
        "2019-06-19T21:09:29"       || true
        "2019-06-19T21:09:29Z"      || false
        "2019-06-19T21:09:29+00:00" || false
    }

    void "Happy path - InstantType has any timestamp"() {
        given:
        def dateAndTimestamp = new InstantType(testValue)

        when:
        def isit = ValidationUtils.hasNoTimestamp(dateAndTimestamp)

        then:
        isit == expected

        where:
        testValue                   || expected
        "2019-06-19T21:09:29"       || true
        "2019-06-19T21:09:29+03:00" || false
        "2019-06-19T21:09:29Z"      || false
        "2019-06-19T21:09:29+00:00" || false
    }

    void "DateType has any timestamp desc#"() {
        given:
        def dateAndTimestamp = new DateType(testValue)

        when:
        def isit = ValidationUtils.isDateOnly(dateAndTimestamp)

        then:
        isit == expected

        where:
        desc | testValue    || expected
        "1"  | ""           || false
        "2"  | "2019-06-19" || true

    }

    def "it matches dates with hyphens"() {
        when:
        def expected = ValidationUtils.isDatePatternHyphen(value)

        then:
        expected == result

        where:
        desc        | value                      || result
        "null"      | null                       || false
        "hyphen"    | "2019-06-19"               || true
        "slash"     | "2019/06/19"               || false
        "Timestamp" | "2015-02-07T13:28:17.249Z" || false

    }

    def "it matches dates with slashes"() {
        when:
        def expected = ValidationUtils.isDatePatternSlash(value)

        then:
        expected == result

        where:
        desc        | value                      || result
        "null"      | null                       || false
        "hyphen"    | "2019-06-19"               || false
        "slash"     | "2019/06/19"               || true
        "Timestamp" | "2015-02-07T13:28:17.249Z" || false
    }

    def "it determines if it's date or dateTime"() {
        when:
        def expected = ValidationUtils.isDateTime(value)

        then:
        expected == result

        where:
        desc         | value                       || result
        "null"       | null                        || false
        "hyphen"     | "2019-06-19"                || false
        "slash"      | "2019/06/19"                || false
        "Timestamp1" | "2015-02-07T13:28:17.249Z"  || true
        "Timestamp2" | "2017-01-01T00:00:00.000Z"  || true
        "Timestamp3" | "2015-02-07T13:28:17.249Z"  || true
        "Timestamp4" | "2019-06-19T21:09:29Z"      || true
        "Timestamp5" | "2019-06-19T21:09:29+00:30" || true
    }

    def "validate todate #desc"() {

        when:
        def date = toDate(value)
        ZonedDateTime zdt = date.toInstant().atZone(ZoneId.of(zoneId))

        then:
        zdt.getYear() == year
        zdt.getMonthValue() == month
        zdt.getDayOfMonth() == day
        zdt.getHour() == hours
        zdt.getMinute() == minutes
        zdt.getSecond() == seconds
        zdt.getNano() == nanos
        zdt.getZone().id == zoneId

        where:
        desc | value                           || year | month | day | hours | minutes | seconds | nanos     | zoneId
        "1"  | "2015-02-07T13:28:17.239+02:00" || 2015 | 2     | 7   | 11    | 28      | 17      | 239000000 | "UTC"
        "2"  | "2019/06/19"                    || 2019 | 6     | 19  | 0     | 0       | 0       | 0         | "UTC"
        "3"  | "2019-06-19"                    || 2019 | 6     | 19  | 0     | 0       | 0       | 0         | "UTC"
        "4"  | "2015-02-07T13:28:17-05:00"     || 2015 | 2     | 7   | 18    | 28      | 17      | 0         | "UTC"
        "5"  | "2017-01-01T00:00:00Z"          || 2017 | 1     | 1   | 0     | 0       | 0       | 0         | "UTC"
        "6"  | "2017-01-01T00:00:00.000Z"      || 2017 | 1     | 1   | 0     | 0       | 0       | 0         | "UTC"
        "7"  | "2015-02-07T13:28:17.249Z"      || 2015 | 2     | 7   | 13    | 28      | 17      | 249000000 | "UTC"
        "8"  | "2019-06-19T21:09:29Z"          || 2019 | 6     | 19  | 21    | 9       | 29      | 0         | "UTC"
        "9"  | "2019-06-19T21:09:29+00:30"     || 2019 | 6     | 19  | 20    | 39      | 29      | 0         | "UTC"
        "10" | "2019-06-19"                    || 2019 | 6     | 18  | 19    | 0       | 0       | 0         | "America/Chicago"
    }

    def "test invalid dates #desc"() {

        when:
        def date = toDate(value)

        then:
        date == null

        where:
        desc | value
        "1"  | "2019"
        "2"  | "2019-06"
        "3"  | "0019-06-19"
        "4"  | "2019-13-19"
        "5"  | "3019-13-19"
        "6"  | "2019-06-32"
        "7"  | "2019-06-19T21:09:29"
        "8"  | null
    }

    void "Validate identifier desc#"() {

        given:
        def identifierList = [buildIdentifier(recordKey, recordKeyValue)] as List<Identifier>
        when:
        def exceptionMessage = ""
        try {
            ValidationUtils.validateIdentifier(identifierList, false)
        } catch (IhrBadRequestException ibre) {
            exceptionMessage = ibre.getMessage()
        }

        then:
        exceptionMessage == expected

        where:
        desc        | recordKey     | recordKeyValue                                                 || expected
        "HappyPath" | "recordKey"   | "o*}Dci^Vj2DS9mggDvEzepfVVqzx{ZEsiUvmmn<+gbH%HEjP.xoJ0P2h8Y(h" || ""
        "02"        | "NoRecordKey" | "o*}Dci^Vj2DS9mggDvEzepfVVqzx{ZEsiUvmmn<+gbH%HEjP.xoJ0P2h8Y(h" || ResponseErrorMessages.INVALID_IDENTIFIER_KEY
        "03"        | ""            | "o*}Dci^Vj2DS9mggDvEzepfVVqzx{ZEsiUvmmn<+gbH%HEjP.xoJ0P2h8Y(h" || ResponseErrorMessages.INVALID_IDENTIFIER_KEY
        "04"        | null          | "o*}Dci^Vj2DS9mggDvEzepfVVqzx{ZEsiUvmmn<+gbH%HEjP.xoJ0P2h8Y(h" || ResponseErrorMessages.INVALID_IDENTIFIER_KEY
        "08"        | "recordKey"   | ""                                                             || ResponseErrorMessages.INVALID_RECORD_KEY
        "09"        | "recordKey"   | null                                                           || ResponseErrorMessages.INVALID_RECORD_KEY


    }

    void "Validate patientNotes"() {

        given:
        def authorReference = ResourceType.Patient.toString() + "/" + TestData.PATIENT_ID
        SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss'Z'")
        Date dateAndTimestamp = formatter.parse("2019-06-19T21:09:29Z")
        def extensions = [buildExtension(ValidationUtils.NOTE_TYPE_URL, "ClinicalNote1")] as List<Extension>
        def patientNotes = [buildPatientNote(authorReference, text, dateAndTimestamp, extensions)] as List<Annotation>

        when:
        def exceptionMessage = ""
        try {
            ValidationUtils.isValidNote(patientNotes)
        } catch (IhrBadRequestException ibre) {
            exceptionMessage = ibre.getMessage()
        }

        then:
        exceptionMessage == expected

        where:
        text                                        | author || expected
        "This medication is working"                | true   || ""
        "12345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234" +
                "567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890" +
                "123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456" +
                "789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012" +
                "345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678" +
                "901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234" +
                "567890123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890" +
                "123456789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456" +
                "789012345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012" +
                "345678901234567890123456789012345678901234567890123456789012345678901234567890123456789012345678" +
                "901234567890123456789012345678901" | true   || ResponseErrorMessages.INVALID_NOTE_TEXT
    }

    void "Validate multiple patientNotes"() {

        given:
        def authorReference = author ? ResourceType.Patient.toString() + "/" + TestData.PATIENT_ID : ""
        def patientNotes = [buildPatientNote(authorReference, text, null, null),
                            buildPatientNote(authorReference, text, null, null)] as List<Annotation>

        when:
        def exceptionMessage = ""
        try {
            ValidationUtils.isValidNote(patientNotes)
        } catch (IhrBadRequestException ibre) {
            exceptionMessage = ibre.getMessage()
        }

        then:
        exceptionMessage == expected

        where:
        text                         | author || expected
        ""                           | true   || ResponseErrorMessages.INVALID_NOTE_COUNT
        "This medication is working" | true   || ResponseErrorMessages.INVALID_NOTE_COUNT
        "This medication is working" | false  || ResponseErrorMessages.INVALID_NOTE_COUNT
    }

    void "Invalid actionFlag"() {
        given:
        def actionFlag = [buildActionFlag(code, display), buildActionFlag(code, display)] as List<Coding>
        when:
        def exceptionMessage = ""
        try {
            ValidationUtils.validateActionFlag(actionFlag)
        } catch (IhrBadRequestException ibre) {
            exceptionMessage = ibre.getMessage()
        }
        then:
        exceptionMessage == expected
        where:
        code         | display  || expected
        "actionFlag" | "Upsert" || ResponseErrorMessages.INVALID_ACTION_FLAG_ITEMS
        "ActionFlag" | "Upsert" || ResponseErrorMessages.INVALID_ACTION_FLAG
        ""           | "Delete" || ResponseErrorMessages.INVALID_ACTION_FLAG
        "actionFlag" | "delete" || ResponseErrorMessages.INVALID_ACTION_FLAG
    }

    void "Valid actionFlag"() {
        given:
        def actionFlag = [buildActionFlag(code, display)] as List<Coding>
        when:
        def exceptionMessage = ""
        try {
            ValidationUtils.validateActionFlag(actionFlag)
        } catch (IhrBadRequestException ibre) {
            exceptionMessage = ibre.getMessage()
        }
        then:
        exceptionMessage == expected
        where:
        code         | display  || expected
        "actionFlag" | "Upsert" || ""
        "actionFlag" | "Delete" || ""
    }

    void "Validate LastUpdatedate"() {
        given:
        def lastUpdated = [buildLastUpdated(date)] as InstantType
        when:
        def exceptionMessage = ""
        try {
            ValidationUtils.validateLastUpdatedDate(lastUpdated)
        } catch (IhrBadRequestException ibre) {
            exceptionMessage = ibre.getMessage()
        }
        then:
        exceptionMessage == expected
        where:
        date                            || expected
        "2019-06-10T05:30:00.000+05:30" || ""
        "2019-06-10T05:30:00.000"       || ResponseErrorMessages.INVALID_DATE_FORMAT
        ""                              || ResponseErrorMessages.INVALID_LAST_UPDATED_DATE_FORMAT
        "2019-10-24T21:09:29"           || ResponseErrorMessages.INVALID_DATE_FORMAT

    }

    void "Validate isRequiredIdentifierExists #desc"() {

        def result
        given:
        def identifierList = [buildIdentifier(identifierText, identifierValue)] as List<Identifier>

        when:
        result = ValidationUtils.isRequiredIdentifierExists(identifierList, requiredKey)

        then:
        result == expected

        where:
        desc             | identifierText | identifierValue  | requiredKey    | expected
        "Happy Path 1"   | "recordKey"    | "recordKeyValue" | "recordKey"    | true
        "Happy Path 2"   | "reviewerMSID" | "msid"           | "reviewerMSID" | true
        "UnHappy Path 1" | "reviewerMSID" | "msid"           | "recordKey"    | false
        "UnHappy Path 2" | "recordKey"    | "recordKeyValue" | "reviewerMSID" | false
    }

    void "Validate getReviewerId #desc"() {

        def result
        given:
        def identifierList = [buildIdentifier(identifierText, identifierValue)] as List<Identifier>

        when:
        result = ValidationUtils.getEmployeeId(identifierList)

        then:
        result == expected

        where:
        desc           | identifierText | identifierValue | expected
        "Happy Path 1" | "employeeId"   | "msid"          | "msid"
        "UnHappy Path" | "reviewerID"   | "msid"          | null
    }

    void "Validate validateCoding #desc"() {

        given:
        def result = ""
        def codingList = [buildCoding(system, code)] as List<Coding>
        def codeableConcept = new CodeableConcept()
        codeableConcept.setCoding codingList

        when:
        if (condition == "codeable") {
            codeableConcept = null
        }
        try {
            ValidationUtils.validateCoding(codeableConcept)
        } catch (IhrBadRequestException ibre) {
            result = ibre.getMessage()
        }

        then:
        result == expected

        where:
        desc             | system   | code   | condition  | expected
        "Happy Path 1"   | "system" | "code" | ""         | ""
        "Happy Path 2"   | ""       | "code" | ""         | ResponseErrorMessages.CODE_OR_SYSTEM_MISSING
        "UnHappy Path 1" | ""       | ""     | ""         | ResponseErrorMessages.CODE_OR_SYSTEM_MISSING
        "UnHappy Path 1" | ""       | ""     | "codeable" | ResponseErrorMessages.MISSING_CODEABLECONCEPT
    }

    void "Validate validateCodableDisplayCoding #desc"() {

        given:
        def result = ""
        def codingList = [buildDisplayCoding(system, display)] as List<Coding>
        def codeableConcept = new CodeableConcept()
        codeableConcept.setCoding codingList

        when:
        if (condition == "codeable") {
            codeableConcept = null
        }
        try {
            ValidationUtils.validateCodableDisplayCoding(codeableConcept)
        } catch (IhrBadRequestException ibre) {
            result = ibre.getMessage()
        }

        then:
        result == expected

        where:
        desc                       | system   | display   | condition  || expected
        "Happy Path 1"             | "system" | "display" | ""         || ""
        "system missing "          | ""       | "display" | ""         || ResponseErrorMessages.DISPLAY_OR_SYSTEM_MISSING
        "display  missing"         | "system" | ""        | ""         || ResponseErrorMessages.DISPLAY_OR_SYSTEM_MISSING
        "codeable concept missing" | ""       | ""        | "codeable" || ResponseErrorMessages.MISSING_CODEABLECONCEPT
    }

    void "Validate author reference #desc"() {

        when:
        def authorReference = author ? ResourceType.Practitioner.toString() + "/" + TestData.PRACTITIONER_ID : ""
        def note = null
        if (noteType.equals("patient")) {
            note = buildPatientNote(authorReference, desc, null, null)
        } else {
            note = buildClinicalNote(authorReference, desc, null, null)
        }

        then:
        def result = ValidationUtils.isValidAuthorReference(note)
        result == expected

        where:
        desc               | author | noteType   || expected
        "valid patient"    | true   | "patient"  || true
        "invalid patient"  | false  | "patient"  || false
        "valid clinical"   | true   | "clinical" || true
        "invalid clinical" | false  | "clinical" || false
    }

    void "Validate clinical notes #desc"() {

        given:
        def authorReference = ResourceType.Practitioner.toString() + "/" + TestData.PRACTITIONER_ID
        SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss'Z'")
        Date dateAndTimestamp = desc.equals("invalidDate") ? null : formatter.parse("2019-06-19T21:09:29Z")
        def extensions = [buildExtension(url, valueString)] as List<Extension>
        def clinicalNote = [buildClinicalNote(authorReference, desc, dateAndTimestamp, extensions)] as List<Annotation>

        when:
        def exceptionMessage = ""
        try {
            ValidationUtils.isValidNote(clinicalNote)
        } catch (IhrBadRequestException ibre) {
            exceptionMessage = ibre.getMessage()
        }

        then:
        exceptionMessage == expected

        where:
        desc           | url                           | valueString                   || expected
        "goodOne"      | ValidationUtils.NOTE_TYPE_URL | ValidationUtils.CLINICAL_NOTE || ""
        ""             | ValidationUtils.NOTE_TYPE_URL | ValidationUtils.CLINICAL_NOTE || ResponseErrorMessages.INVALID_NOTE_TEXT
        "invalidDate"  | ValidationUtils.NOTE_TYPE_URL | ValidationUtils.CLINICAL_NOTE || ResponseErrorMessages.INVALID_NOTE_TIME
        "invalidUrl"   | "invalid"                     | ValidationUtils.CLINICAL_NOTE || ResponseErrorMessages.INVALID_CLINICAL_NOTE
        "nullUrl"      | null                          | ValidationUtils.CLINICAL_NOTE || ResponseErrorMessages.INVALID_CLINICAL_NOTE
        "invalidValue" | ValidationUtils.NOTE_TYPE_URL | "invalid"                     || ResponseErrorMessages.INVALID_PRACTITIONER
        "nullValue"    | ValidationUtils.NOTE_TYPE_URL | null                          || ResponseErrorMessages.INVALID_CLINICAL_NOTE
    }

    void "Validate patient notes #desc"() {

        given:
        def authorReference = ResourceType.Patient.toString() + "/" + TestData.PATIENT_ID
        SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss'Z'")
        Date dateAndTimestamp = desc.equals("invalidDate") ? null : formatter.parse("2019-06-19T21:09:29Z")
        def extensions = [buildExtension(url, valueString)] as List<Extension>
        def patientNote = [buildPatientNote(authorReference, desc, dateAndTimestamp, extensions)] as List<Annotation>

        when:
        def exceptionMessage = ""
        try {
            ValidationUtils.isValidNote(patientNote)
        } catch (IhrBadRequestException ibre) {
            exceptionMessage = ibre.getMessage()
        }

        then:
        exceptionMessage == expected

        where:
        desc                 | url                           | valueString                   || expected
        "goodOne"            | ValidationUtils.NOTE_TYPE_URL | "patientNotes"                || ""
        ""                   | ValidationUtils.NOTE_TYPE_URL | "otherNotes"                  || ResponseErrorMessages.INVALID_NOTE_TEXT
        "invalidDate"        | ValidationUtils.NOTE_TYPE_URL | "patientNotes"                || ResponseErrorMessages.INVALID_NOTE_TIME
        "invalidUrl"         | "invalid"                     | "patientNotes"                || ResponseErrorMessages.INVALID_CLINICAL_NOTE
        "nullUrl"            | null                          | "patientNotes"                || ResponseErrorMessages.INVALID_CLINICAL_NOTE
        "null extValue"      | ValidationUtils.NOTE_TYPE_URL | null                          || ResponseErrorMessages.INVALID_CLINICAL_NOTE
        "ClinicalNote value" | ValidationUtils.NOTE_TYPE_URL | ValidationUtils.CLINICAL_NOTE || ResponseErrorMessages.INVALID_PRACTITIONER
    }

    def "Test validateEmployeeId #desc"() {

        given:
        Bundle resourceBundle = getResourceBundle(filename)
        def exceptionMessage = ""

        when:
        for (Bundle.BundleEntryComponent entity : resourceBundle.getEntry()) {
            if (entity.getResource() instanceof MedicationStatement) {
                try {
                    MedicationStatement medicationStatement = (MedicationStatement) entity.getResource()
                    ValidationUtils.validateEmployeeId(medicationStatement.getIdentifier(), fhirAttributesWrapper)
                } catch (IhrBadRequestException ibre) {
                    exceptionMessage = ibre.getMessage()
                }
            }
        }

        then:
        exceptionMessage == expected

        where:
        desc           | filename                   | expected
        "Happy Path"   | "multi-medication.json"    | ""
        "UnHappy Path" | "mismatch-reviewerId.json" | ResponseErrorMessages.EMPLOYEE_IDS_MISMATCH
    }

    void "Validate validateRecordKey desc#"() {

        given:
        def identifierList = [buildIdentifier(recordKey, recordKeyValue)] as List<Identifier>
        when:
        def exceptionMessage = ""
        try {
            ValidationUtils.validateRecordKey(identifierList)
        } catch (IhrBadRequestException ibre) {
            exceptionMessage = ibre.getMessage()
        }

        then:
        exceptionMessage == expected

        where:
        desc         | recordKey     | recordKeyValue || expected
        "HappyPath"  | "recordKey"   | "EX1234"       || ""
        "Scenario_1" | "NoRecordKey" | "EX1234"       || ResponseErrorMessages.INVALID_IDENTIFIER_KEY
        "Scenario_2" | ""            | "EX1234"       || ResponseErrorMessages.INVALID_IDENTIFIER_KEY
        "Scenario_3" | null          | "EX1234"       || ResponseErrorMessages.INVALID_IDENTIFIER_KEY
        "Scenario_4" | "recordKey"   | ""             || ResponseErrorMessages.INVALID_RECORD_KEY
        "Scenario_5" | "recordKey"   | null           || ResponseErrorMessages.INVALID_RECORD_KEY
    }

}
