package com.uhg.ihr.api.model

import com.uhg.ihr.api.fhir.BaseFhirSpecification
import com.uhg.ihr.centrihealth.api.model.CoverageDecorator
import com.uhg.ihr.centrihealth.api.model.MedicationStatementDecorator
import com.uhg.ihr.centrihealth.senzing.model.SenzingRequest
import org.hl7.fhir.r4.model.Bundle

class MedicationStatementDecoratorSpec extends BaseFhirSpecification {

   /* def "Test buildSenzingRequest #desc"() {

        given:
        def resourceBundle = getResourceBundle(fileName)
        def decorator = new MedicationStatementDecorator()
        def senzingRequest = new SenzingRequest()

        when:
        for (Bundle.BundleEntryComponent entity : resourceBundle.getEntry()) {
            senzingRequest = decorator.buildSenzingRequest(entity, senzingRequest)
        }

        then:
        msId == senzingRequest.getMsId()

        where:
        desc           | fileName                 | msId
        "Happy Path"   | "ingest_medication.json" | "NMOON1"
        "Unhappy Path" | "patient_missing.json"  | null
    }*/
}
