package com.uhg.ihr.api.util

import com.uhg.ihr.api.fhir.BaseFhirSpecification
import com.uhg.ihr.centrihealth.api.model.FhirAttributesWrapper
import io.micronaut.http.HttpRequest
import org.hl7.fhir.r4.model.Bundle
import org.hl7.fhir.r4.model.CodeableConcept
import org.hl7.fhir.r4.model.Coverage
import org.hl7.fhir.r4.model.HumanName
import org.hl7.fhir.r4.model.Medication
import org.hl7.fhir.r4.model.MedicationStatement
import org.hl7.fhir.r4.model.Meta
import org.hl7.fhir.r4.model.Patient
import org.hl7.fhir.r4.model.Practitioner
import org.hl7.fhir.r4.model.PractitionerRole
import org.hl7.fhir.r4.model.Provenance
import org.hl7.fhir.r4.model.Reference
import org.hl7.fhir.r4.model.RelatedPerson

/**
 * TestData class acts like test harness for sample data for Unit and Integration test cases.
 *
 * @author Ihr-Api Engineering Team
 * @CopyRight (C) All rights reserved to UHG Inc. It's Illegal to reproduce this code.
 */
class TestData extends BaseFhirSpecification {

    public static final String TOKEN = "Bearer eyJhbGciOiJSUzUxMiJ9.eyJyb2xlIjoidXNlciIsImNyZWF0ZWQiOjE1MjI4NDk5OTE3OTcsInVzZXJuYW1lIjoiY2xvdWRzZGsifQ.dzfwWRugsnhPHB0RNT9lZHnX7gvNfGks_ivTc_dQ6-ejM6B1-Chx3WrwBE8drdy4ZbvkVTlHkHRSu3nBZi3Aw0wmN5N7UPUI0wP2KhAHGQS4-LOXgD58ioX9ep3k6hZQqy-oJor5Q3wZS8HJKMMY8izIROtJ5z-z5Y2RRw3ONnQLL5JR40hF9d5mFKA8Y1giEP32qg259MVbdkHNkI0ceq8hrXJ7w_OD4-JPteNhM9EeyNOmzjrKSEG-tkYrWI7g5xgvgMuO8iHFym4WhkDT6FNfcK2xs8QfCbJCZqV28xSIjbrm0El0L7kRzJbsKBxQ7FNJ35iaX18DpQMpu6usUQ"
    public static final String CORRELATION_HEADER = "optum-cid-ext"
    public static final String CORRELATION_ID = "abcdefg1234567"
    public static final String CONSUMER_USER_NAME_HEADER = "X-Consumer-Username"
    public static final String CONSUMER_USER_NAME = "abc.def"
    public static final String MEDICATION_ID = "62e10f3c-ba06-4b5f-a624-6d2c2d8ef834"
    public static final String PATIENT_ID = "74b2befb-2cc8-4de6-8325-458e0c47fcfd"
    public static final String PRACTITIONER_ID = "74b2befb-2cc8-4de6-8325-458e0c47fcfe"
    public static final String PRACTITIONER_ROLE_ID = "bbbbbbbb-2cc8-4de6-8325-458e0c47fcfe"
    public static final String REVIEWER_ID = "NMOON1"

    static HttpRequest<?> baseRequest() {
        return HttpRequest.POST("/individual-health-records/v1.0/read", "")
                .header(CORRELATION_HEADER, CORRELATION_ID)
                .header(CONSUMER_USER_NAME_HEADER, CONSUMER_USER_NAME)
                .header("JWT", TOKEN)
    }

    static Patient buildPatientResource() {
        return (Patient) new Patient()
                .addName(new HumanName().setFamily("Mouse").addGiven("Minnie"))
                .setBirthDate(toDate("1991/01/01"))
                .setId(PATIENT_ID)
    }

    static defaultCoverage() {
        return new Coverage()
                .addIdentifier(buildIdentifier("searchId", "00000251082177"))
                .addIdentifier(buildIdentifier("correlationId", "hsadhSDASd68767_kerna_edge"))
                .setId(getCodeUUID())

    }

    static buildPractitionerResource() {
        Practitioner practitioner = new Practitioner().addName(new HumanName().setText("Author/name"))
        practitioner.setId(PRACTITIONER_ID)
        practitioner.addIdentifier().setType(new CodeableConcept().setText("NPI")).setValue("1234567890")
        return practitioner
    }

    static defaultMedicationStatement() {
        MedicationStatement ms = buildMedicationStatement()
                .addIdentifier(defaultRecordKey()).addIdentifier(defaultEmployeeId())
                .setDateAsserted(toDate("2019-10-24T19:03:05+05:30"))
                .setSubject(new Reference("Patient/" + PATIENT_ID))
                .setMedication(new Reference("Medication/" + MEDICATION_ID))
                .setInformationSource(new Reference("PractitionerRole/" + PRACTITIONER_ROLE_ID))
                .setInformationSourceTarget()

        ms.getMedicationReference().setResource(defaultMedication())
        ms.getInformationSource().setResource(defaultPractitionerRole())
        ms.setMeta(defaultMeta())
        return ms
    }

    static Bundle defaultBundle() {
        Patient patient = buildPatientResource()
        Coverage coverage = defaultCoverage()
        MedicationStatement msOne = defaultMedicationStatement()
        MedicationStatement msTwo = defaultMedicationStatement()
        Medication medication = (Medication) msOne.getMedicationReference().getResource()
        PractitionerRole role = (PractitionerRole) msOne.getInformationSource().getResource()
        Practitioner practitioner = buildPractitionerResource()
        Provenance provenance = buildProvenance()
        provenance.addTarget(new Reference(msOne).setReference("MedicationStatement/" + msOne.getId()))
        provenance.addTarget(new Reference(msTwo).setReference("MedicationStatement/" + msTwo.getId()))
        provenance.addAgent().setWho(new Reference(practitioner).setReference("Practitioner/" + practitioner.getId()))
        def bundle = buildBundle()
        bundle.addEntry().setResource(patient)
        bundle.addEntry().setResource(coverage)
        bundle.addEntry().setResource(msOne)
        bundle.addEntry().setResource(msTwo)
        bundle.addEntry().setResource(medication)
        bundle.addEntry().setResource(role)
        bundle.addEntry().setResource(practitioner)
        bundle.addEntry().setResource(provenance)
        return bundle

    }

    static defaultMeta() {
        return new Meta()
                .addTag(buildActionFlag("actionFlag", "Upsert"))
                .setLastUpdated(new Date())
    }

    static defaultRecordKey() {
        return buildIdentifier("recordKey", "o*}Dci^Vj2DS9mggDvEzepfVVqzx{ZEsiUvmmn<+gbH%HEjP.xoJ0P2h8Y(h")
    }

    static defaultEmployeeId() {
        return buildIdentifier("employeeId", REVIEWER_ID)
    }

    static defaultPractitionerRole() {
        return buildPractitionerRole("Medical Director").setId(PRACTITIONER_ROLE_ID)
    }

    static defaultPractitioner() {
        return buildPractitionerRole("Medical Director").setId(PRACTITIONER_ROLE_ID)
    }

    static defaultFhirAttributesWrapper() {
        Set<String> authorIds = Set.of(PRACTITIONER_ROLE_ID, REVIEWER_ID)
        return FhirAttributesWrapper.builder()
                .employeeId(authorIds)
                .build()
    }

    static Medication defaultMedication() {
        return buildMedication(MEDICATION_ID).setCode(buildCodeableConcept("http://hl7.org/fhir/sid/ndc", "52817019100"))
    }

    static defaultRelatedPerson() {
        return new RelatedPerson()
                .addRelationship(new CodeableConcept().setText("Caregiver"))
                .setId(getCodeUUID())
    }
}