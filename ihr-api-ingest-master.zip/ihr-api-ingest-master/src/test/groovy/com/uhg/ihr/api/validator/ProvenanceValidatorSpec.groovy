package com.uhg.ihr.api.validator

import com.uhg.ihr.api.fhir.BaseFhirSpecification
import com.uhg.ihr.centrihealth.api.util.ResponseErrorMessages
import com.uhg.ihr.centrihealth.api.validator.ProvenanceValidator
import org.hl7.fhir.r4.model.Practitioner
import org.hl7.fhir.r4.model.Provenance
import org.hl7.fhir.r4.model.Reference
import spock.lang.Unroll

@Unroll
class ProvenanceValidatorSpec extends BaseFhirSpecification {

    static final String RELATIONSHIP_TEXT = "Health Care Proxy"
    def dob = toDate("1985/03/21")
    static final validator = ProvenanceValidator.of()
    def message = ""

    def "Validate Target #desc"() {

        given:
        def provenance = buildProvenance()

        when:
        try {
            provenance.addTarget(new Reference().setReference(refValue).setResource(target) as Reference)

            if (setTargetNull) {
                provenance.setTarget(null)
            }
            validator.validateTarget(provenance)

        }
        catch (Exception ex) {
            message = ex.getMessage()
            println(message)
        }

        then:
        message == errorMessage

        where:
        desc                                      | target                     | refValue                          | setTargetNull || errorMessage
        "Happy Path MedicationStatement resource" | buildMedicationStatement() | "MedicationStatement/12345"       | false         || ""
        "Happy Path Allergy resource"             | buildAllergyIntolerance()  | "AllergyIntolerance/1234567"      | false         || ""
        "Resource is Null"                        | null                       | "MedicationStatement/" + "123532" | false         || ResponseErrorMessages.INVALID_TARGET_REFERENCE
        "Target is Null"                          | null                       | null                              | true          || ResponseErrorMessages.TARGET_REQUIRED

    }

    def "Validate Recorded #desc"() {

        given:
        Provenance provenance = new Provenance()
        provenance.setRecorded(toDateFromUtc(recordedDate))
        def exception = false

        when:
        try {
            validator.validateRecorded(provenance)
        }
        catch (Exception ex) {
            exception = true
        }

        then:
        exception == failed


        where:
        desc           | recordedDate                    || failed
        "Date is null" | ""                              || true
        "Success "     | "2019-10-24T13:33:05.000+00:00" || false
    }

    def "Validate AgentWho #desc"() {

        given:
        def provenance = buildProvenance()
        def errorMsg = ""

        when:
        try {
            provenance.addAgent(new Provenance.ProvenanceAgentComponent().setWho(new Reference().setReference(refValue).setResource(target) as Reference))
            validator.validateAgentWho(provenance.getAgent(), null)

        }
        catch (Exception ex) {
            errorMsg = ex.getMessage()
        }

        then:
        errorMsg == errorMessage

        where:
        desc                         | target                                                | refValue                    || errorMessage
        " Happy path Agent refernce" | buildPractitionerWithEmpId("employeeId", "123456789") | "Practitioner/1234567"      || ""
        "invalid Agent refernce"     | buildMedicationStatement()                            | "MedicationStatement/12345" || ResponseErrorMessages.INVALID_AGENT_WHO_REFERENCE
        "Agent refernce null"        | null                                                  | null                        || ResponseErrorMessages.AGENT_WHO_REFERENCE_EXCEPTION
    }

    static Practitioner buildPractitionerWithEmpId(String text, String value) {
        def pract = new Practitioner()
        pract.setId(getCodeUUID())
        pract.addIdentifier(buildIdentifier(text, value))
        return pract
    }
}
