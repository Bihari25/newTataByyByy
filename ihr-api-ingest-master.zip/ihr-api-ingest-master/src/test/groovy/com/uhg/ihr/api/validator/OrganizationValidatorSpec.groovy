package com.uhg.ihr.api.validator

import com.uhg.ihr.api.fhir.BaseFhirSpecification
import com.uhg.ihr.centrihealth.api.exception.IhrBadRequestException
import com.uhg.ihr.centrihealth.api.util.Constant
import com.uhg.ihr.centrihealth.api.validator.OrganizationValidator

class OrganizationValidatorSpec extends BaseFhirSpecification {

    def "Test validate"() {
        given:
        def exception = false
        def org = buildOrganization(identifierText, identifierValue, addIdentifier, count)
        when:
        try {
            OrganizationValidator.of().validate(org, null)
        } catch (IhrBadRequestException ibre) {
            exception = true
        }
        then:
        exception == failed

        where:
        desc                | identifierText | identifierValue | addIdentifier | count || failed
        "Happy Path"        | Constant.NPI   | "12345"         | true          | 1     || false
        "Incorrect text"    | "npi"          | "12345"         | true          | 1     || true
        "Incorrect value"   | Constant.NPI   | " "             | true          | 1     || true
        "Add 2 identifier " | Constant.NPI   | "12345"         | true          | 2     || true
    }
}
