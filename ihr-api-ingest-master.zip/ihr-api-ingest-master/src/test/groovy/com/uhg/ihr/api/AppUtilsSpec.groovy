package com.uhg.ihr.api

import spock.lang.Specification
import spock.lang.Unroll

@Unroll
class AppUtilsSpec extends Specification {

    def "AppUtils::todayDate"() {
        when:
        def result = true

        then:
        result
    }
}
