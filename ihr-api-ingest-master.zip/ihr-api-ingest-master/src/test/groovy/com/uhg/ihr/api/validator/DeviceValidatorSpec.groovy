package com.uhg.ihr.api.validator

import com.uhg.ihr.api.fhir.BaseFhirSpecification
import com.uhg.ihr.centrihealth.api.exception.IhrBadRequestException
import com.uhg.ihr.centrihealth.api.util.ResponseErrorMessages
import com.uhg.ihr.centrihealth.api.validator.HealthDeviceValidator
import com.uhg.ihr.centrihealth.api.validator.ValidationUtils
import org.hl7.fhir.r4.model.Bundle
import org.hl7.fhir.r4.model.CodeableConcept
import org.hl7.fhir.r4.model.Device
import org.hl7.fhir.r4.model.Identifier

class DeviceValidatorSpec extends BaseFhirSpecification {
    def "Valid Device test cases #description"() {

        given:
        Bundle resourceBundle = getResourceBundle(fileName)

        when:
        def isValid = false
        def validationMessage = null

        for (Bundle.BundleEntryComponent entity : resourceBundle.getEntry()) {
            if (entity.getResource() instanceof Device) {

                try {
                    Device device = (Device) entity.getResource()
                    HealthDeviceValidator.of().validate(device, fhirAttributesWrapper)
                    isValid = true
                }
                catch (IhrBadRequestException | Exception ee) {
                    validationMessage = ee.getMessage()
                    isValid = false
                }
            }
        }

        then:
        isValid == expected
        validationMessage == errorMessage

        where:
        description | fileName      || errorMessage || expected
        "HappyPath" | "device.json" || null         || true
    }

    def "Invalid Device test cases #description"() {

        given:
        Bundle resourceBundle = getResourceBundle("device.json")

        when:
        def isValid = false
        def validationMessage = null

        for (Bundle.BundleEntryComponent entity : resourceBundle.getEntry()) {
            if (entity.getResource() instanceof Device) {

                try {
                    Device device = (Device) entity.getResource()
                    if (scenario == "referenceId") {
                        device.addIdentifier(new Identifier().setType(new CodeableConcept().setText("reference")))
                    }
                    HealthDeviceValidator.of().validate(device, fhirAttributesWrapper)
                    isValid = true
                }
                catch (IhrBadRequestException | Exception ee) {
                    validationMessage = ee.getMessage()
                    isValid = false
                }
            }
        }

        then:
        isValid == expected
        validationMessage == errorMessage

        where:
        description   | scenario      || errorMessage                           || expected
        "ReferenceId" | "referenceId" || ResponseErrorMessages.INVALID_IDENTIFIER_KEY || false
    }
}
