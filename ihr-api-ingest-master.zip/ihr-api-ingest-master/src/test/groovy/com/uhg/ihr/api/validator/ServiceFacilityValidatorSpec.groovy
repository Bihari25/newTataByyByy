package com.uhg.ihr.api.validator

import com.uhg.ihr.api.fhir.BaseFhirSpecification
import com.uhg.ihr.centrihealth.api.exception.IhrBadRequestException
import com.uhg.ihr.centrihealth.api.util.ResponseErrorMessages
import com.uhg.ihr.centrihealth.api.validator.ServiceFacilityProviderValidator
import com.uhg.ihr.centrihealth.api.validator.ValidationUtils
import org.hl7.fhir.instance.model.api.IBaseResource
import org.hl7.fhir.r4.model.Bundle
import org.hl7.fhir.r4.model.CareTeam
import org.hl7.fhir.r4.model.CodeableConcept
import org.hl7.fhir.r4.model.Coding
import org.hl7.fhir.r4.model.Meta
import org.hl7.fhir.r4.model.Organization
import spock.lang.Unroll

@Unroll
class ServiceFacilityValidatorSpec extends BaseFhirSpecification {

    def "Valid ServiceFacilityProvider test cases 1 #description"() {

        given:
        Bundle resourceBundle = getResourceBundle(fileName)
        when:
        def isValid = false
        def validationMessage = null

        for (Bundle.BundleEntryComponent entity : resourceBundle.getEntry()) {
            if (entity.getResource() instanceof CareTeam) {
                try {
                    CareTeam sfp = (CareTeam) entity.getResource()
                    isValid = ServiceFacilityProviderValidator.isServiceFacilityProvider(sfp)
                }
                catch (IhrBadRequestException | Exception ee) {
                    validationMessage = ee.getMessage()
                    isValid = false
                }
            }
        }

        then:
        isValid == expected
        validationMessage == errorMessage
        where:
        description | fileName       || errorMessage || expected
        "HappyPath" | "serviceFacility.json" || null         || true
    }

    def "Invalid SFP test cases 2 #description"() {

        given:
        Bundle resourceBundle = getResourceBundle("serviceFacility.json")

        when:
        def isValid = false
        def validationMessage = null

        for (Bundle.BundleEntryComponent entity : resourceBundle.getEntry()) {
            if (entity.getResource() instanceof CareTeam) {
                try {
                    CareTeam sfp = (CareTeam) entity.getResource()
                    for (CareTeam.CareTeamParticipantComponent participant : sfp.getParticipant()) {
                        IBaseResource resource = participant.getMember().getResource()
                        if (resource instanceof Organization) {
                            Organization organization = (Organization) resource
                            if (scenario == "recordKey") {
                                organization.addIdentifier().setType(new CodeableConcept().setText("recordKey-Test"))
                            }
                            if (scenario == "actionTag") {
                                organization.setMeta(new Meta().addTag(new Coding().setDisplay("add").setCode("actionFlag")))
                            }
                        }
                    }
                    isValid = ServiceFacilityProviderValidator.isServiceFacilityProvider(sfp)
                }
                catch (IhrBadRequestException | Exception ee) {
                    validationMessage = ee.getMessage()
                    isValid = false
                }
            }
        }

        then:
        isValid == expected
        validationMessage == errorMessage

        where:
        description                   | scenario    || errorMessage                           || expected
        "validate recordKey scenario" | "recordKey" || ResponseErrorMessages.INVALID_IDENTIFIER_KEY || false
        "validate actionTag scenario" | "actionTag" || ResponseErrorMessages.INVALID_ACTION_FLAG    || false

    }
}
