package com.uhg.ihr.api.validator

import com.uhg.ihr.api.fhir.BaseFhirSpecification
import com.uhg.ihr.api.util.TestData
import com.uhg.ihr.centrihealth.api.exception.IhrBadRequestException
import com.uhg.ihr.centrihealth.api.util.ResponseErrorMessages
import com.uhg.ihr.centrihealth.api.validator.*
import org.hl7.fhir.r4.model.*
import spock.lang.Unroll

import java.text.SimpleDateFormat

class ConditionValidatorSpec extends BaseFhirSpecification {

    def "Valid Condition test cases #description"() {

        given:
        Bundle resourceBundle = getResourceBundle("condition.json")

        when:
        def isValid = false
        def validationMessage = null

        for (Bundle.BundleEntryComponent entity : resourceBundle.getEntry()) {
            if (entity.getResource() instanceof Condition) {

                try {
                    Condition condition = (Condition) entity.getResource()
                    ConditionValidator.of().validate(condition, fhirAttributesWrapper)
                    isValid = true
                }
                catch (IhrBadRequestException | Exception ee) {
                    validationMessage = ee.getMessage()
                    isValid = false
                }
            }
        }

        then:
        isValid == expected
        validationMessage == errorMessage
        where:
        description | fileName         || errorMessage || expected
        "HappyPath" | "condition.json" || null         || true
    }

    def "Validate recordKey or conditionCode with #desc"() {
        given:
        Condition condition = new Condition().setSubject(new Reference().setResource(buildPatient()) as Reference)
        if (recordKeyExists) {
            if (validRecordKey) {
                condition.addIdentifier(buildIdentifier("recordKey", "o*}Dci^Vj2DS9mggDvEzepfVVqzx{ZEsiUvmmn<+gbH%HEjP.xoJ0P2h8Y(h"))
            } else {
                condition.addIdentifier(buildIdentifier("recordKey", "o*}Dci^Vj2DS9mggDvEzepfVVqzx{ZEsiUvmmn<+gbH%HEjP.xoJ0P2h8Y(h@%"))
            }
        }
        if (conditionCodeExists) {
            if (validConditionCode) {
                condition.setCode(buildCodeableConcept("http://snomed.info/sct", "6369005"))
            } else {
                condition.setCode(buildCodeableConcept("missing-coding"))
            }
        }
        def errorMsg = ""
        def valid = false

        when:
        try {
            ConditionValidator.validateRecordKeyConditionCode(condition)
            valid = true
        } catch (Exception e) {
            if (e instanceof IhrBadRequestException) {
                errorMsg = e.getMessage()
            } else {
                errorMsg = e.class.getName()
            }
        }

        then:
        errorMsg == expectedMsg
        valid == expectedValid

        where:
        desc                                     | recordKeyExists | validRecordKey | conditionCodeExists | validConditionCode | expectedMsg                                                 | expectedValid
        "valid both"                             | true            | true           | true                | true               | ""                                                          | true
        "valid recordKey"                        | true            | true           | false               | false              | ""                                                          | true
        "valid allergyCode"                      | false           | false          | true                | true               | ""                                                          | true
        "invalid recordKey"                      | true            | false          | false               | false              | ResponseErrorMessages.UNABLE_TO_DECODE_RECORD_MSG           | false
        "invalid conditionCode"                  | false           | false          | true                | false              | ResponseErrorMessages.MISSING_CODEABLECONCEPT               | false
        "invalid recordKey, valid conditionCode" | true            | false          | true                | true               | ResponseErrorMessages.UNABLE_TO_DECODE_RECORD_MSG           | false
        "valid recordKey, invalid conditionCode" | true            | true           | true                | false              | ""                                                          | true
        "no recordKey or conditionCode"          | false           | false          | false               | false              | ResponseErrorMessages.RECORD_KEY_OR_CONDITION_CODE_REQUIRED | false
    }

    @Unroll
    def "Test condition subject  #desc"() {
        given:
        def condition = buildCondition()

        def exception = false
        def errorMessage = ""

        when:
        try {
            condition.setSubject(new Reference(resource).setReference(referenceValue))

            ConditionValidator.validateSubjectReference(condition, fhirAttributesWrapper);

        } catch (IhrBadRequestException ibre) {
            exception = true
            errorMessage = ibre.getMessage()
        }

        then:
        exception == failed
        errorMessage == errMessage

        where:
        desc                | resource          | referenceValue                   || failed | errMessage
        "Happy Path"        | buildPatient()    | "Patient/" + resource.getId()    || false  | ""
        "null reference"    | ""                | ""                               || false  | ""
        "invalid reference" | buildMedication() | "Medication/" + resource.getId() || true   | ResponseErrorMessages.INVALID_PATIENT_REFERENCE

    }

    def "Validate Condition Onset PeriodDate with #desc "() {
        given:
        Condition condition = new Condition()

        if (PeriodDate) {
            condition.setOnset(new Period().setStart(toDateFromUtc(startDate)).setEnd(toDateFromUtc(endDate)))
        }
        def errorMsg = ""
        def valid = false

        when:
        try {
            ConditionValidator.validateOnsetPeriodDate(condition)
            valid = true
        } catch (Exception e) {
            valid = false
            errorMsg = e.getMessage()
        }

        then:
        valid == expectedValid
        errorMsg == expectedMsg

        where:
        desc             | PeriodDate | startDate              | endDate                | expectedMsg | expectedValid
        "valid period"   | true       | "2011-07-15T19:04:54Z" | "2015-04-15T19:04:54Z" | ""          | true
        "period is null" | true       | ""                     | ""                     | ""          | true

    }

    def "Validate condition Recorder reference with #desc"() {

        given:
        Condition condition = new Condition().setRecorder(new Reference().setResource(recorder) as Reference)

        def errorMsg = ""
        def isValid = true

        when:
        try {
            ConditionValidator.validateRecorder(condition)
        }
        catch (Exception e) {
            errorMsg = e.getMessage()
            isValid = false

        }

        then:
        isValid == expected
        errorMsg == expectedMsg

        where:
        desc                                   | recorder                                                                                       | expected | expectedMsg
        "valid recorder"                       | (Resource) buildPractitionerWithEmpId("employeeId", "123456789")                               | true     | ""
        "invalid recorder"                     | (Resource) buildPractitionerRole(PractitionerRoleInfoCodeEnum.PRIMARY_CARE_PROVIDER.getCode()) | false    | ResponseErrorMessages.INVALID_PRACTITIONER_REFERENCE_COND
        "invalid refernce Practitioner empId " | (Resource) buildPractitionerWithEmpId("", "")                                                  | false    | ResponseErrorMessages.INVALID_PRACTITIONER_REFERENCE_ID_COND
    }

    def "Validate condition actionFlag with #desc"() {

        given:
        def codingList = [buildActionFlag(code, display)] as List<Coding>
        Condition condition = new Condition()
                .setMeta(new Meta()
                        .setLastUpdated(toDateFromUtc(lastUpdatedDate))
                        .setTag(codingList))

        def errorMsg = ""
        def isValid = true

        when:
        try {
            ValidationUtils.validateActionFlag(condition.getMeta().getTag())
        }
        catch (Exception e) {
            errorMsg = e.getMessage()
            isValid = false

        }

        then:
        isValid == expected
        errorMsg == expectedMsg

        where:
        desc                              | code                | display  | lastUpdatedDate                 | expected | expectedMsg
        "Happy Path"                      | "actionFlag"        | "Upsert" |  "2021-09-20T14:45:05.000+00:00" | true     | ""
        "invalid  Action Flag in display" | "actionFlag"        | "upsert" |"2021-10-20T14:45:05.000+00:00" | false    | ResponseErrorMessages.INVALID_ACTION_FLAG
        "invalid  Action Flag in code"    | "actionFlagInvalid" | "upsert" |  "2021-11-20T14:45:05.000+00:00" | false    | ResponseErrorMessages.INVALID_ACTION_FLAG
    }


    void "Validate condition LastUpdatedate"() {
        given:
        Condition condition = new Condition()
                .setMeta(new Meta()
                        .setLastUpdated(toDateFromUtc(lastUpdatedDate)))

        when:

        def exceptionMessage = ""
        try {
            ValidationUtils.validateLastUpdatedDate(condition.getMeta().getLastUpdatedElement())
        } catch (IhrBadRequestException ibre) {
            exceptionMessage = ibre.getMessage()
        }

        then:

        exceptionMessage == expected
        where:

        desc                                    | lastUpdatedDate                 || expected
        "Happy Path"                            | "2019-06-10T05:30:00.000+05:30" || ""
        "invalid last updated Date format"      | "2019-06-10T05:30:00.000"       || ResponseErrorMessages.INVALID_LAST_UPDATED_DATE_FORMAT
        "Empty updated Date"                    | ""                              || ResponseErrorMessages.INVALID_LAST_UPDATED_DATE_FORMAT
        "invalid last updated Date Time format" | "2019-10-24T21:09:29"           || ResponseErrorMessages.INVALID_LAST_UPDATED_DATE_FORMAT

    }

    void "Validate clinical notes #desc"() {

        given:
        def authorReference = ResourceType.Practitioner.toString() + "/" + TestData.PRACTITIONER_ID
        SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss'Z'")
        Date dateAndTimestamp = desc.equals("invalidDate") ? null : formatter.parse("2019-06-19T21:09:29Z")
        def extensions = [buildExtension(url, valueString)] as List<Extension>
        def clinicalNote = [buildClinicalNote(authorReference, desc, dateAndTimestamp, extensions)] as List<Annotation>

        when:
        def exceptionMessage = ""
        try {
            ValidationUtils.isValidNote(clinicalNote)
        } catch (IhrBadRequestException ibre) {
            exceptionMessage = ibre.getMessage()
        }

        then:
        exceptionMessage == expected

        where:
        desc           | url                           | valueString                   || expected
        "goodOne"      | ValidationUtils.NOTE_TYPE_URL | ValidationUtils.CLINICAL_NOTE || ""
        ""             | ValidationUtils.NOTE_TYPE_URL | ValidationUtils.CLINICAL_NOTE || ResponseErrorMessages.INVALID_NOTE_TEXT
        "invalidDate"  | ValidationUtils.NOTE_TYPE_URL | ValidationUtils.CLINICAL_NOTE || ResponseErrorMessages.INVALID_NOTE_TIME
        "invalidUrl"   | "invalid"                     | ValidationUtils.CLINICAL_NOTE || ResponseErrorMessages.INVALID_CLINICAL_NOTE
        "nullUrl"      | null                          | ValidationUtils.CLINICAL_NOTE || ResponseErrorMessages.INVALID_CLINICAL_NOTE
        "invalidValue" | ValidationUtils.NOTE_TYPE_URL | "invalid"                     || ResponseErrorMessages.INVALID_PRACTITIONER
        "nullValue"    | ValidationUtils.NOTE_TYPE_URL | null                          || ResponseErrorMessages.INVALID_CLINICAL_NOTE
    }

    def "Validate validateAsserter with #desc"() {

        given:
        Condition condition = new Condition().setAsserter(new Reference().setResource(asserter) as Reference)
        def isValid = true

        when:
        try {
            ConditionValidator.validateAsserter(condition, fhirAttributesWrapper)
        }
        catch (Exception e) {
            isValid = false
        }

        then:
        isValid == expected

        where:
        desc                         | asserter                                                                                       | expected
        "PractitionerRole"           | (Resource) buildPractitionerRole(PractitionerRoleInfoCodeEnum.PRIMARY_CARE_PROVIDER.getCode()) | true
        "RelatedPerson"              | (Resource) buildRelatedPerson(RelatedPersonInfoCodeEnum.CAREGIVER.getCode())                   | true
        "Patient"                    | (Resource) buildPatient()                                                                      | true
        "invalid RelatedPerson code" | (Resource) buildRelatedPerson("bad-code")                                                      | false
        "invalid asserter"           | (Resource) buildPractitioner()                                                                 | false

    }

    static buildCondition() {
        def condition = new Condition()
        condition.setId(getCodeUUID())
        return condition
    }

    static Practitioner buildPractitionerWithEmpId(String text, String value) {
        def pract = new Practitioner()
        pract.addIdentifier(buildIdentifier(text, value))
        return pract
    }
}
