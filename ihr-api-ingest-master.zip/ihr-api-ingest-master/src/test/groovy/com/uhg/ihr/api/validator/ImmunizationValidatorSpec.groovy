package com.uhg.ihr.api.validator

import com.uhg.ihr.api.fhir.BaseFhirSpecification
import com.uhg.ihr.centrihealth.api.exception.IhrBadRequestException
import com.uhg.ihr.centrihealth.api.model.FhirAttributesWrapper
import com.uhg.ihr.centrihealth.api.util.ResponseErrorMessages
import com.uhg.ihr.centrihealth.api.validator.ImmunizationsValidator
import com.uhg.ihr.centrihealth.api.validator.ValidationUtils
import org.hl7.fhir.r4.model.*

import java.time.Instant

class ImmunizationValidatorSpec extends BaseFhirSpecification {

    def "Valid Immunization test cases #description"() {

        given:
        Bundle resourceBundle = getResourceBundle("Immunization.json")

        when:
        def isValid = false
        def validationMessage = null

        for (Bundle.BundleEntryComponent entity : resourceBundle.getEntry()) {
            if (entity.getResource() instanceof Immunization) {

                try {
                    Immunization immunization = (Immunization) entity.getResource()
                    ImmunizationsValidator.of().validate(immunization, fhirAttributesWrapper)
                    isValid = true
                }
                catch (IhrBadRequestException | Exception ee) {
                    validationMessage = ee.getMessage()
                    isValid = false
                }
            }
        }

        then:
        isValid == expected
        validationMessage == errorMessage
        where:
        description | fileName            || errorMessage || expected
        "HappyPath" | "Immunization.json" || null         || true
    }

    def "Validate Immunization actionFlag with #desc"() {

        given:
        def codingList = [buildActionFlag(code, display)] as List<Coding>
        Immunization immunization = new Immunization()
                .setMeta(new Meta()
                        .setLastUpdated(toDateFromUtc(lastUpdatedDate))
                        .setTag(codingList))

        def errorMsg = ""
        def isValid = true

        when:
        try {
            ValidationUtils.validateActionFlag(immunization.getMeta().getTag())
        }
        catch (Exception e) {
            errorMsg = e.getMessage()
            isValid = false

        }

        then:
        isValid == expected
        errorMsg == expectedMsg

        where:
        desc                              | code                | display  | lastUpdatedDate                 | expected | expectedMsg
        "Happy Path"                      | "actionFlag"        | "Upsert" | "2021-09-20T14:45:05.000+00:00" | true     | ""
        "invalid  Action Flag in display" | "actionFlag"        | "upsert" | "2021-10-20T14:45:05.000+00:00" | false    | ResponseErrorMessages.INVALID_ACTION_FLAG
        "invalid  Action Flag in code"    | "actionFlagInvalid" | "upsert" | "2021-11-20T14:45:05.000+00:00" | false    | ResponseErrorMessages.INVALID_ACTION_FLAG
    }

    def "Validate patient with #desc "() {
        given:
        Immunization immunization = new Immunization()
        if (patientExists) {
            if (isPatient) {
                immunization.setPatient(new Reference().setResource(buildPatient()) as Reference)
            } else {
                immunization.setPatient(new Reference().setResource(buildRelatedPerson()) as Reference)
            }
        }
        def errorMsg = ""
        def valid = false

        when:
        try {
            ImmunizationsValidator.validatePatient(immunization, new FhirAttributesWrapper())
            valid = true
        } catch (Exception e) {
            errorMsg = e.getMessage()
        }

        then:
        valid == expectedValid
        errorMsg == expectedMsg

        where:
        desc                   | patientExists | isPatient | expectedMsg                                        | expectedValid
        "valid patient"        | true          | true      | ""                                                 | true
        "non-patient resource" | true          | false     | ResponseErrorMessages.INVALID_PATIENT_REFERENCE    | false
        "missing patient"      | false         | false     | ResponseErrorMessages.PATIENT_RESOURCE_MISSING_IMM | false
    }

    def "Validate occurrenceDateTime with #desc"() {
        given:
        Immunization immunization = new Immunization()
        if (occurrenceDateExists) {
            immunization.setOccurrence(new DateTimeType(toDateFromUtc("2020-06-06T05:08:33Z")))
        }
        def errorMsg = ""
        def valid = false

        when:
        try {
            ImmunizationsValidator.validateOccurrenceDateTime(immunization);
            valid = true
        } catch (Exception e) {
            errorMsg = e.getMessage()
        }

        then:
        valid == expectedValid
        errorMsg == expectedMsg

        where:
        desc                         | occurrenceDateExists | expectedMsg                                     | expectedValid
        "valid occurrenceDateTime"   | true                 | ""                                              | true
        "missing occurrenceDateTime" | false                | ResponseErrorMessages.REQUIRED_OCCURRENCE_FIELD | false
    }


    def "Validate recordedDate with #desc"() {
        given:
        Immunization immunization = new Immunization()
        if (recordDateExists) {
            immunization.setRecorded(Date.from(Instant.parse("2019-01-02T03:04:44Z")))
        }
        def errorMsg = ""
        def valid = false

        when:
        try {
            ImmunizationsValidator.validateRecorded(immunization);
            valid = true
        } catch (Exception e) {
            errorMsg = e.getMessage()
        }

        then:
        valid == expectedValid
        errorMsg == expectedMsg

        where:
        desc                   | recordDateExists | expectedMsg | expectedValid
        "valid recordedDate"   | true             | ""          | true
        "missing recordedDate" | false            | ""          | true
    }

    void "Validate immunization LastUpdatedate"() {
        given:
        Immunization immunization = new Immunization()
                .setMeta(new Meta()
                        .setLastUpdated(toDateFromUtc(lastUpdatedDate)))

        when:

        def exceptionMessage = ""
        try {
            ValidationUtils.validateLastUpdatedDate(immunization.getMeta().getLastUpdatedElement())
        } catch (IhrBadRequestException ibre) {
            exceptionMessage = ibre.getMessage()
        }

        then:

        exceptionMessage == expected
        where:

        desc                                    | lastUpdatedDate                 || expected
        "Happy Path"                            | "2019-06-10T05:30:00.000+05:30" || ""
        "invalid last updated Date format"      | "2019-06-10T05:30:00.000"       || ResponseErrorMessages.INVALID_LAST_UPDATED_DATE_FORMAT
        "Empty updated Date"                    | ""                              || ResponseErrorMessages.INVALID_LAST_UPDATED_DATE_FORMAT
        "invalid last updated Date Time format" | "2019-10-24T21:09:29"           || ResponseErrorMessages.INVALID_LAST_UPDATED_DATE_FORMAT

    }

    void "Validate immunization reason Code #desc"() {

        given:
        def result = ""
        Immunization immunization = new Immunization()
        def codingList = [buildCoding(system, code)] as List<Coding>
        def codeableConcept = new CodeableConcept()
        codeableConcept.setCoding(codingList)

        immunization.setReasonCode(codeableConcept as List<CodeableConcept>)

        when:
        if (condition == "codeable") {
            codeableConcept = null
        }
        try {
            ImmunizationsValidator.validateReasonCode(immunization);
        } catch (IhrBadRequestException ibre) {
            result = ibre.getMessage()
        }

        then:
        result == expected

        where:
        desc                      | system   | code   | condition  | expected
        "Happy Path 1"            | "system" | "code" | ""         | ""
        "Happy Path 2"            | ""       | "code" | ""         | ResponseErrorMessages.CODE_OR_SYSTEM_MISSING
        "code or system missing " | ""       | ""     | ""         | ""
        "empty reason code"       | ""       | ""     | "codeable" | ""
    }


    def "Validate recordKey or VaccineCode with #desc"() {
        given:
        Immunization immunization = new Immunization()
        if (recordKeyExists) {
            if (validRecordKey) {
                immunization.addIdentifier(buildIdentifier("recordKey", "o*}Dci^Vj2DS9mggDvEzepfVVqzx{ZEsiUvmmn<+gbH%HEjP.xoJ0P2h8Y(h"))
            } else {
                immunization.addIdentifier(buildIdentifier("recordKey", "o*}Dci^Vj2DS9mggDvEzepfVVqzx{ZEsiUvmmn<+gbH%HEjP.xoJ0P2h8Y(h@%"))
            }
        }
        if (vaccineCodeExists) {
            if (validVaccineCode) {
                immunization.setVaccineCode(buildCodeableConcept("http://snomed.info/sct", "6369005"))
            } else {
                immunization.setVaccineCode(buildCodeableConcept("missing-coding"))
            }
        }
        def errorMsg = ""
        def valid = false

        when:
        try {
            ImmunizationsValidator.validateRecordKeyOrVaccineMedCode(immunization)
            valid = true
        } catch (Exception e) {
            if (e instanceof IhrBadRequestException) {
                errorMsg = e.getMessage()
            } else {
                errorMsg = e.class.getName()
            }
        }

        then:
        errorMsg == expectedMsg
        valid == expectedValid

        where:
        desc                                   | recordKeyExists | validRecordKey | vaccineCodeExists | validVaccineCode | expectedMsg                                                            | expectedValid
        "valid both"                           | true            | true           | true              | true             | ""                                                                     | true
        "valid recordKey"                      | true            | true           | false             | false            | ""                                                                     | true
        "valid vaccine vaccineCode"            | false           | false          | true              | true             | ""                                                                     | true
        "invalid recordKey"                    | true            | false          | false             | false            | ResponseErrorMessages.UNABLE_TO_DECODE_RECORD_MSG                      | false
        "invalid code"                         | false           | false          | true              | false            | ResponseErrorMessages.MISSING_CODEABLECONCEPT                          | false
        "invalid recordKey, valid vaccineCode" | true            | false          | true              | true             | ResponseErrorMessages.UNABLE_TO_DECODE_RECORD_MSG                      | false
        "valid recordKey, invalid vaccineCode" | true            | true           | true              | false            | ""                                                                     | true
        "no recordKey or vaccineCode"          | false           | false          | false             | false            | ResponseErrorMessages.RECORD_KEY_OR_IMMUNIZATION_VACCINE_CODE_REQUIRED | false
    }


    def "Validate  VaccineCode with 999 code  #desc"() {
        given:
        Immunization immunization = new Immunization()

        if (hasCode999) {
            immunization.setVaccineCode(buildCodeableConcept(system, code))
            immunization.setReasonCode(buildCodeableConcept("http://snomed.info/sct", "6369005") as List<CodeableConcept>)
        } else {
            immunization.setVaccineCode(buildCodeableConcept(system, code))
        }

        def errorMsg = ""
        def valid = false

        when:
        try {
            ImmunizationsValidator.validateRecordKeyOrVaccineMedCode(immunization)
            valid = true
        } catch (Exception e) {
            if (e instanceof IhrBadRequestException) {
                errorMsg = e.getMessage()
            } else {
                errorMsg = e.class.getName()
            }
        }

        then:
        errorMsg == expectedMsg
        valid == expectedValid

        where:
        desc                                          | hasCode999 | system                        | code   | expectedMsg                               | expectedValid
        "vaccine code is 999"                         | true       | "http://hl7.org/fhir/sid/cvx" | "999"  | ""                                        | true
        " different vaccine code"                     | false      | "http://hl7.org/fhir/sid/cvx" | "6353" | ""                                        | true
        " different vaccine code with no reason Code" | false      | "http://hl7.org/fhir/sid/cvx" | "999"  | ResponseErrorMessages.INVALID_REASON_CODE | false
    }

}
