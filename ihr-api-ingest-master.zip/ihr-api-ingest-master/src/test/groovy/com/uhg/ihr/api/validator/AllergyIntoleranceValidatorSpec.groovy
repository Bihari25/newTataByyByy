package com.uhg.ihr.api.validator

import ca.uhn.fhir.parser.DataFormatException
import com.uhg.ihr.api.fhir.BaseFhirSpecification
import com.uhg.ihr.centrihealth.api.exception.IhrBadRequestException
import com.uhg.ihr.centrihealth.api.model.FhirAttributesWrapper
import com.uhg.ihr.centrihealth.api.util.ResponseErrorMessages
import com.uhg.ihr.centrihealth.api.validator.ActionFlag
import com.uhg.ihr.centrihealth.api.validator.AllergyIntoleranceValidator
import com.uhg.ihr.centrihealth.api.validator.PractitionerRoleInfoCodeEnum
import com.uhg.ihr.centrihealth.api.validator.RelatedPersonInfoCodeEnum
import org.hl7.fhir.r4.model.*
import spock.lang.Unroll

import java.time.Instant

@Unroll
class AllergyIntoleranceValidatorSpec extends BaseFhirSpecification {

    def "Main validate() with #description"() {

        given:
        def errorMsg = ""

        when:
        try {
            Bundle resourceBundle = getResourceBundle(file)
            AllergyIntolerance allergyIntolerance = getResourceFromBundle(resourceBundle, ResourceType.AllergyIntolerance) as AllergyIntolerance
            AllergyIntoleranceValidator.of().validate(allergyIntolerance, new FhirAttributesWrapper())
        } catch (Exception e) {
            if (e instanceof IhrBadRequestException) {
                errorMsg = e.getMessage()
            } else {
                errorMsg = e.class.getName()
            }
        }

        then:
        errorMsg == expectedMsg

        where:
        description                 | file                                          | expectedMsg
        "valid fields"              | "allergyIntolerance_standard.json"            | ""
        "valid minimum fields"      | "allergyIntolerance_minimumRequired.json"     | ""
        "invalid DELETE actionFlag" | "allergyIntolerance_invalid_actionFlag.json"  | ""
        "invalid LastUpdated"       | "allergyIntolerance_invalid_lastUpdated.json" | DataFormatException.class.getName()
        "missing actionFlag"        | "allergyIntolerance_missing_actionFlag.json"  | ResponseErrorMessages.INVALID_ACTION_FLAG
        "missing LastUpdated"       | "allergyIntolerance_missing_lastUpdated.json" | ResponseErrorMessages.INVALID_LAST_UPDATED_DATE_FORMAT
    }

    def "Validate recordKey or allergyCode with Type with #desc"() {
        given:
        AllergyIntolerance allergyIntolerance = new AllergyIntolerance().setPatient(new Reference().setResource(buildPatient()) as Reference)
        if (recordKeyExists) {
            if (validRecordKey) {
                allergyIntolerance.addIdentifier(buildIdentifier("recordKey", "o*}Dci^Vj2DS9mggDvEzepfVVqzx{ZEsiUvmmn<+gbH%HEjP.xoJ0P2h8Y(h"))
            } else {
                allergyIntolerance.addIdentifier(buildIdentifier("recordKey", "o*}Dci^Vj2DS9mggDvEzepfVVqzx{ZEsiUvmmn<+gbH%HEjP.xoJ0P2h8Y(h__"))
            }
        }
        if (allergyCodeExists) {
            if (validAllergyCode) {
                allergyIntolerance.setCode(buildCodeableConcept("http://snomed.info/sct", "6369005"))
                if (validAllergyType) {
                    allergyIntolerance.setType(AllergyIntolerance.AllergyIntoleranceType.ALLERGY)
                }
            } else {
                allergyIntolerance.setCode(buildCodeableConcept("missing-coding"))
            }
        }
        def errorMsg = ""
        def valid = false

        when:
        try {
            AllergyIntoleranceValidator.validateRecordKeyAllergyCode(allergyIntolerance)
            valid = true
        } catch (Exception e) {
            if (e instanceof IhrBadRequestException) {
                errorMsg = e.getMessage()
            } else {
                errorMsg = e.class.getName()
            }
        }

        then:
        errorMsg == expectedMsg
        valid == expectedValid

        where:
        desc                                       | recordKeyExists | validRecordKey | allergyCodeExists | validAllergyCode | validAllergyType | expectedMsg                                               | expectedValid
        "valid both"                               | true            | true           | true              | true             | true             | ""                                                        | true
        "valid recordKey"                          | true            | true           | false             | false            | false            | ""                                                        | true
        "valid allergyCode with type"              | false           | false          | true              | true             | true             | ""                                                        | true
        "invalid recordKey"                        | true            | false          | false             | false            | false            | ResponseErrorMessages.UNABLE_TO_DECODE_RECORD_MSG         | false
        "invalid allergyCode"                      | false           | false          | true              | false            | false            | ResponseErrorMessages.MISSING_CODEABLECONCEPT             | false
        "invalid recordKey, valid allergyCode"     | true            | false          | true              | true             | true             | ResponseErrorMessages.UNABLE_TO_DECODE_RECORD_MSG         | false
        "valid recordKey, invalid allergyCode"     | true            | true           | true              | false            | false            | ""                                                        | true
        "no recordKey or allergyCode"              | false           | false          | false             | false            | false            | ResponseErrorMessages.RECORD_KEY_OR_ALLERGY_CODE_REQUIRED | false
        "valid allergyCode with null allergy type" | false           | false          | true              | true             | false            | ResponseErrorMessages.TYPE_AND_ALLERGY_CODE_REQUIRED      | false
    }

    def "Validate recordedDate with #desc"() {
        given:
        AllergyIntolerance allergyIntolerance = new AllergyIntolerance()
        if (recordDateExists) {
            allergyIntolerance.setRecordedDate(Date.from(Instant.parse("2019-01-02T03:04:44Z")))
        }
        def errorMsg = ""
        def valid = false

        when:
        try {
            AllergyIntoleranceValidator.validateRecordedDate(allergyIntolerance)
            valid = true
        } catch (Exception e) {
            errorMsg = e.getMessage()
        }

        then:
        valid == expectedValid
        errorMsg == expectedMsg

        where:
        desc                   | recordDateExists | expectedMsg | expectedValid
        "valid recordedDate"   | true             | ""          | true
        "missing recordedDate" | false            | ""          | true
    }

    def "Validate validateAsserter with #desc"() {

        given:
        AllergyIntolerance allergyIntolerance = new AllergyIntolerance().setAsserter(new Reference().setResource(asserter) as Reference)
        def isValid = true

        when:
        try {
            AllergyIntoleranceValidator.validateAsserter(allergyIntolerance, fhirAttributesWrapper)
        }
        catch (Exception e) {
            isValid = false
        }

        then:
        isValid == expected

        where:
        desc                         | asserter                                                                                       | expected
        "PractitionerRole"           | (Resource) buildPractitionerRole(PractitionerRoleInfoCodeEnum.PRIMARY_CARE_PROVIDER.getCode()) | true
        "RelatedPerson"              | (Resource) buildRelatedPerson(RelatedPersonInfoCodeEnum.CAREGIVER.getCode())                   | true
        "Patient"                    | (Resource) buildPatient()                                                                      | true
        "invalid RelatedPerson code" | (Resource) buildRelatedPerson("bad-code")                                                      | false
        "invalid asserter"           | (Resource) buildPractitioner()                                                                 | false

    }

    def "Validate patient with #desc "() {
        given:
        AllergyIntolerance allergyIntolerance = new AllergyIntolerance()
        if (patientExists) {
            if (isPatient) {
                allergyIntolerance.setPatient(new Reference().setResource(buildPatient()) as Reference)
            } else {
                allergyIntolerance.setPatient(new Reference().setResource(buildRelatedPerson()) as Reference)
            }
        }
        def errorMsg = ""
        def valid = false

        when:
        try {
            AllergyIntoleranceValidator.validatePatient(allergyIntolerance, new FhirAttributesWrapper())
            valid = true
        } catch (Exception e) {
            errorMsg = e.getMessage()
        }

        then:
        valid == expectedValid
        errorMsg == expectedMsg

        where:
        desc                   | patientExists | isPatient | expectedMsg                                     | expectedValid
        "valid patient"        | true          | true      | ""                                              | true
        "non-patient resource" | true          | false     | ResponseErrorMessages.INVALID_PATIENT_REFERENCE | false
        "missing patient"      | false         | false     | ResponseErrorMessages.PATIENT_RESOURCE_MISSING_ALLERGY  | false
    }

    def "Validate validateAllergyReaction #desc"() {

        def errorMsg = ""

        given:
        def intolerance = new AllergyIntolerance()
        CodeableConcept manifestation = new CodeableConcept()
        if (hasCode) {
            intolerance.setCode(new CodeableConcept().setText(allergy))
        }
        if (hasReaction) {
            AllergyIntolerance.AllergyIntoleranceReactionComponent reaction = intolerance.addReaction()
            if (hasManifestation) {
                if (invalidManifestationCode) {
                    manifestation.setCoding([buildCoding("", "")] as List<Coding>)
                } else {
                    manifestation.setCoding([buildCoding("http://snomed.info/sct", "xyz")] as List<Coding>)
                }
                manifestation.setText(text)
                reaction.addManifestation(manifestation)
            }
        }
        try {
            AllergyIntoleranceValidator.validateAllergyManifestation(intolerance)
        } catch (IhrBadRequestException ee) {
            errorMsg = ee.getMessage()
        }

        expect:
        errorMsg == expected

        where:
        desc                            | hasCode | hasReaction | hasManifestation | invalidManifestationCode | text                      | allergy || expected
        "Success"                       | true    | true        | true             | false                    | "Chemotherapy Medication" | "cold"  || ""
        "Success-No Reaction & Allergy" | true    | false       | false            | false                    | "Chemotherapy Medication" | ""      || ""
        "Success-No Code"               | false   | true        | true             | false                    | "Chemotherapy Medication" | ""      || ""
        "Success-No Code & Reaction"    | false   | false       | false            | false                    | "Chemotherapy Medication" | ""      || ""
        "Failure-No Manifestation"      | true    | true        | false            | false                    | ""                        | ""      || ResponseErrorMessages.MANIFESTATION_CODE_MISSING
        "Failure-No Manifestation code" | true    | true        | true             | true                     | ""                        | ""      || ResponseErrorMessages.CODE_OR_SYSTEM_MISSING

    }

    def "Validate AllergyType with #desc "() {
        given:
        AllergyIntolerance allergyIntolerance = new AllergyIntolerance()

        if (hasTypeAndCode) {
            allergyIntolerance.setType(type)
            allergyIntolerance.setCode(buildCodeableConcept("http://snomed.info/sct", "6369005"))
        }
        def errorMsg = ""
        def valid = false

        when:
        try {
            AllergyIntoleranceValidator.validateAllergyType(allergyIntolerance)
            valid = true
        } catch (Exception e) {
            errorMsg = e.getMessage()
        }

        then:
        valid == expectedValid
        errorMsg == expectedMsg

        where:
        desc                                   | hasTypeAndCode | type                                              | expectedMsg                                          | expectedValid
        "valid Allergy type with Allergy code" | true           | AllergyIntolerance.AllergyIntoleranceType.ALLERGY | ""                                                   | true
        "no  Allergy type and code"            | false          | ""                                                | ResponseErrorMessages.TYPE_AND_ALLERGY_CODE_REQUIRED | false

    }

    def "Validate  Onset PeriodDate with #desc "() {
        given:
        AllergyIntolerance allergyIntolerance = new AllergyIntolerance()

        if (PeriodDate) {
            allergyIntolerance.setOnset(new Period().setStart(toDateFromUtc(startDate)).setEnd(toDateFromUtc(endDate)))
        }
        def errorMsg = ""
        def valid = false

        when:
        try {
            AllergyIntoleranceValidator.validateOnsetPeriodDate(allergyIntolerance)
            valid = true
        } catch (Exception e) {
            errorMsg = e.getMessage()
        }

        then:
        valid == expectedValid
        errorMsg == expectedMsg

        where:
        desc              | PeriodDate | startDate              | endDate                | expectedMsg | expectedValid
        "valid period"    | true       | "2011-07-15T19:04:54Z" | "2011-07-15T19:04:54Z" | ""          | true
        "in valid period" | true       | ""                     | ""                     | ""          | true

    }

    def "Validate validateRecordes with #desc"() {

        given:
        AllergyIntolerance allergyIntolerance = new AllergyIntolerance().setRecorder(new Reference().setResource(recorder) as Reference)

        def errorMsg = ""
        def isValid = true


        when:
        try {
            AllergyIntoleranceValidator.validateRecorder(allergyIntolerance)
        }
        catch (Exception e) {
            errorMsg = e.getMessage()
            isValid = false

        }

        then:
        isValid == expected
        errorMsg == expectedMsg

        where:
        desc                                   | recorder                                                                                       | expected | expectedMsg
        "valid recorder"                       | (Resource) buildPractitionerWithEmpId("employeeId", "123456789")                               | true     | ""
        "invalid recorder"                     | (Resource) buildPractitionerRole(PractitionerRoleInfoCodeEnum.PRIMARY_CARE_PROVIDER.getCode()) | false    | ResponseErrorMessages.INVALID_PRACTITIONER_REFERENCE_ALLERGY
        "invalid refernce Practitioner empId " | (Resource) buildPractitionerWithEmpId("", "")                                                  | false    | ResponseErrorMessages.INVALID_PRACTITIONER_REFERENCE_ID_ALLERGY
    }

    static Practitioner buildPractitionerWithEmpId(String text, String value) {
        def pract = new Practitioner()
        pract.addIdentifier(buildIdentifier(text, value))
        return pract
    }
}