package com.uhg.ihr.centrihealth.senzing.model

import spock.lang.Specification

class SenzingLookupSpec extends Specification {

    def "SenzingLookup fields set"() {
        when:
        true

        then:
        SenzingLookup.DATA == "data"
        SenzingLookup.RESULTS == "searchResults"
        SenzingLookup.MATCH_LEVEL == "matchLevel"
        SenzingLookup.MATCH_KEY == "matchKey"
        SenzingLookup.IDENTIFIER_DATA == "identifierData"
        SenzingLookup.RECORD_SUMMARIES == "recordSummaries"
        SenzingLookup.RECORD_COUNT == "recordCount"
    }
}
