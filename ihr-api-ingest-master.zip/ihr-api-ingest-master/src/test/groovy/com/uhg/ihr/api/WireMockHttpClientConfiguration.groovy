package com.uhg.ihr.api


import io.micronaut.http.client.HttpClientConfiguration
import io.micronaut.runtime.ApplicationConfiguration
import java.time.Duration
import javax.inject.Singleton

@Singleton
class WireMockHttpClientConfiguration extends HttpClientConfiguration {

    WireMockHttpClientConfiguration(ApplicationConfiguration applicationConfiguration) {
        super(applicationConfiguration)
        this.setReadTimeout(Duration.ofSeconds(60))
    }

    @Override
    ConnectionPoolConfiguration getConnectionPoolConfiguration() {
        return new ConnectionPoolConfiguration()
    }
}
