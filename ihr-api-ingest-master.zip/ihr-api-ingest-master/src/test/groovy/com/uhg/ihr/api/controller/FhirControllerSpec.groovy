package com.uhg.ihr.api.controller

import com.fasterxml.jackson.databind.ObjectMapper
import com.fasterxml.jackson.databind.node.ObjectNode
import com.uhg.ihr.api.WireMockBaseTest
import com.uhg.ihr.centrihealth.api.controller.FhirController
import com.uhg.ihr.centrihealth.api.output.translator.OutputProducer
import io.micronaut.context.annotation.Requires
import io.micronaut.core.util.StringUtils
import io.micronaut.http.HttpRequest
import io.micronaut.http.HttpResponse
import io.micronaut.http.HttpStatus
import io.micronaut.http.MediaType
import io.micronaut.http.MutableHttpResponse
import io.micronaut.http.client.exceptions.HttpClientResponseException
import io.micronaut.test.annotation.MockBean
import io.micronaut.test.extensions.spock.annotation.MicronautTest
import spock.lang.Shared
import spock.lang.Unroll

import javax.inject.Inject

@MicronautTest
@Requires(property = "micronaut.security.stargate.enabled", notEquals = StringUtils.FALSE)
@Unroll
class FhirControllerSpec extends WireMockBaseTest {

    @MockBean(OutputProducer)
    OutputProducer mockProducer() {
        Mock(OutputProducer)
    }


    @Shared
    static final ObjectMapper MAPPER = new ObjectMapper()

    @Inject
    OutputProducer producer

    @Shared
    @Inject
    FhirController controller

    def "it 401 on accept type"() {
        when:
        HttpRequest req = baseFhirRequest().accept(MediaType.of("application/fhir+json"))

        then:
        def exceptionThrown = false
        try {
            httpClient.toBlocking().exchange(req, String.class)
        } catch (HttpClientResponseException hcre) {
            assert hcre.getMessage().contains('Unauthorized')
            assert 401 == hcre.getResponse().getStatus().code
            exceptionThrown = true
        }
        exceptionThrown
    }

    //TODO: Figure out how to stub for producer testing
//    def "Translator #desc response"() {
//        given:
//        Maybe<MutableHttpResponse<Object>> translatorResponse = Maybe.just(SimpleHttpResponseFactory.INSTANCE.status(HttpStatus.valueOf(status)))
//        String payload = TranslatorPayloadUtils.getBundleJsonString(new HashMap<ActorIdType, String>(), new Bundle())
//        producer.sendPayload("","") >> translatorResponse
//
//        when:
//        MutableHttpResponse<ObjectNode> response = controller.sendTranslatorRequest(new HashMap<ActorIdType, String>(), new Bundle(), "testing-id").blockingGet()
//
//        then:
//        1 * producer.sendPayload(_, _)
//        response.getStatus().getCode() == expectedCode
//
//        where:
//        desc         | status | message                   | expectedCode
//        "good"       | 200    | "Completed"               | 202
//        "unexpected" | 305    | "Something weird went on" | 500
//    }

    def "Handle Translator Http #desc error"() {
        given:
        HttpResponse<Object> errorStatus = HttpResponse.status(HttpStatus.valueOf(status))
        if (message != null) {
            if (message.equals("NA")) {
                errorStatus.body(message)
            } else {
                errorStatus.body(buildTranslatorResponseBody(status, message))
            }
        }
        Throwable error = new HttpClientResponseException("Error", errorStatus)

        when:
        MutableHttpResponse<ObjectNode> response = controller.handleTranslatorError(error, "testing-id")
        String responseMsg = response.getBody().get().get("message").asText()

        then:
        response.getStatus().getCode() == expectedStatus
        responseMsg == expectedMessage

        where:
        desc               | status | message           | expectedStatus | expectedMessage
        "400 w/ message"   | 400    | "Missing item"    | 400            | "Error"
        "400 w/o message"  | 400    | null              | 400            | "Error"
        "404 w/ message"   | 404    | "Can't find user" | 404            | "Error"
        "400 not JSON msg" | 400    | "NA"              | 400            | "Error"
        "401 unauthorized" | 401    | "Unauthorized"    | 401            | "Error"
        "403 forbidden"    | 403    | "Forbidden"       | 403            | "Error"
        "500 server"       | 500    | "Something broke" | 500            | "Error"
    }

    static String buildTranslatorResponseBody(int status, String message) {
        ObjectNode body = MAPPER.createObjectNode()
        body.put("httpStatus", status)
        body.put("message", message)
        body.put("timestamp", "2021-09-29T20:20:20Z")
        body.put("corrId", "testing-id")
        return MAPPER.writeValueAsString(body)
    }

}