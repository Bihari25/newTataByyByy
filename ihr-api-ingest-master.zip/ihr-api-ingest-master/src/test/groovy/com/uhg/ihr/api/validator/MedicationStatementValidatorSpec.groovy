package com.uhg.ihr.api.validator

import com.uhg.ihr.api.fhir.BaseFhirSpecification
import com.uhg.ihr.centrihealth.api.exception.IhrBadRequestException
import com.uhg.ihr.centrihealth.api.model.FhirAttributesWrapper
import com.uhg.ihr.centrihealth.api.util.ResponseErrorMessages
import com.uhg.ihr.centrihealth.api.validator.MedicationStatementValidator
import com.uhg.ihr.centrihealth.api.validator.MedicationStmtExtensionEnum
import com.uhg.ihr.centrihealth.api.validator.ValidationUtils
import org.hl7.fhir.r4.model.*
import spock.lang.Shared
import spock.lang.Unroll

@Unroll
class MedicationStatementValidatorSpec extends BaseFhirSpecification {

    @Shared
    String MEDICATION_CODE_SYSTEM = "http://hl7.org/fhir/sid/ndc"

    @Shared
    MedicationStatementValidator validator = MedicationStatementValidator.of()

    Bundle statementBundle = getResourceBundle("medicationStatement.json")

    def "Medication statement test cases #description"() {

        given:
        def isValid = false
        def validationMessage = null

        when:

        for (Bundle.BundleEntryComponent entity : statementBundle.getEntry()) {
            if (entity.getResource() instanceof MedicationStatement) {

                try {
                    MedicationStatement medicationStatement = (MedicationStatement) entity.getResource()
                    if (setIncorrectTag) {
                        medicationStatement.getMeta().getTag().get(0).setDisplay(null)
                    }
                    MedicationStatementValidator.of().validate(medicationStatement, fhirAttributesWrapper)
                    isValid = true
                }
                catch (IhrBadRequestException | Exception ee) {
                    validationMessage = ee.getMessage()
                    isValid = false
                }
            }
        }

        then:
        isValid == expected
        validationMessage == errorMessage

        where:
        description         | setIncorrectTag || errorMessage                        || expected
        "HappyPath"         | false           || null                                || true
        "DisplayTagMissing" | true            || ResponseErrorMessages.INVALID_ACTION_FLAG || false
    }

    @Unroll
    void "Validate isDataAuthorIdentifierRequired #desc"() {

        def result = ""
        given:
        def identifierList = [buildIdentifier(identifierText, identifierValue)] as List<Identifier>
        //Asserted Date
        def assertedDateExists = ValidationUtils.hasValidateDateTimeType(buildAssertedDate(date))
        //Check for review ms id
        boolean dataAuthorIdentifierExists = ValidationUtils.isRequiredIdentifierExists(identifierList, "dataAuthorIdentifier")

        when:
        try {
            MedicationStatementValidator.isDataAuthorIdentifierRequired(assertedDateExists, dataAuthorIdentifierExists)
        } catch (IhrBadRequestException ibre) {
            result = ibre.getMessage()
        }

        then:
        result == expected

        where:
        desc     | identifierText         | identifierValue | date                            || expected
        "Test 1" | "dataAuthorIdentifier" | "msid"          | "2019-10-24T13:33:05.000+00:00" || ""
        "Test 2" | "dataAuthorIdentifier" | "msid"          | ""                              || ""
        "Test 3" | "dataAuthorIdentifier" | ""              | "2019-10-24T13:33:05.000+00:00" || ResponseErrorMessages.REQUIRED_DATA_AUTHOR_IDENTIFIER
        "Test 4" | ""                     | "msid"          | "2019-10-24T13:33:05.000+00:00" || ResponseErrorMessages.REQUIRED_DATA_AUTHOR_IDENTIFIER
    }

    @Unroll
    void "Validate validateMedication #desc"() {

        def result = ""
        given:
        def codingList = [buildCoding(system, code)] as List<Coding>
        def codeableConcept = new CodeableConcept()
        codeableConcept.setCoding codingList

        def identifierList = [buildIdentifier(identifierText, identifierValue)] as List<Identifier>
        if (condition == "codeable") {
            codeableConcept = null
        }
        def medication = new Medication().setCode(codeableConcept)
        //Check for record key
        boolean recordKeyExists = ValidationUtils.isRequiredIdentifierExists(identifierList, "recordKey")

        when:
        try {
            MedicationStatementValidator.validateMedication(medication, recordKeyExists)
        } catch (IhrBadRequestException ibre) {
            result = ibre.getMessage()
        }

        then:
        result == expected

        where:
        desc     | identifierText | identifierValue | condition  | system                 | code  || expected
        "Test 1" | "recordKey"    | "value"         | ""         | MEDICATION_CODE_SYSTEM | "123" || ""
        "Test 2" | "recordKey"    | ""              | ""         | ""                     | "123" || ResponseErrorMessages.CODE_OR_SYSTEM_MISSING
        "Test 3" | "recordKey"    | ""              | ""         | MEDICATION_CODE_SYSTEM | ""    || ResponseErrorMessages.CODE_OR_SYSTEM_MISSING
        "Test 4" | "recordKey"    | ""              | "codeable" | ""                     | ""    || ResponseErrorMessages.CONCEPT_CODE_REQUIRED
        "Test 5" | "recordKey"    | "value"         | ""         | ""                     | ""    || ""
        "Test 6" | "recordKey"    | "value"         | ""         | MEDICATION_CODE_SYSTEM | ""    || ResponseErrorMessages.CODE_OR_SYSTEM_MISSING
        "Test 7" | "recordKey"    | "value"         | ""         | "xyx"                  | "123" || ResponseErrorMessages.MISSING_MEDICATION_CODE
        "Test 8" | "recordKey"    | "value"         | "codeable" | "xyx"                  | "123" || ""
    }

    @Unroll
    void "Validate validateMedicationIdentifier #desc"() {

        def result = ""
        given:
        def medication = new Medication()
        medication.addIdentifier(buildIdentifier(identifierText, identifierValue))

        when:
        try {
            MedicationStatementValidator.validateMedication(medication, false)
        } catch (IhrBadRequestException ibre) {
            result = ibre.getMessage()
        }

        then:
        result == expected

        where:
        desc                   | identifierText | identifierValue | expected
        "Incorrect identifier" | "recordKey"    | "value"         | ResponseErrorMessages.INVALID_IDENTIFIER
        "Happy Path"           | "conceptChid"  | "conceptChid"   | ""
        "Null values"          | null           | null            | ResponseErrorMessages.CONCEPT_CODE_REQUIRED
    }

    @Unroll
    void "Validate validateMedicationReference #desc"() {
        def error = false
        given:
        def statement = new MedicationStatement()
        statement.setMedication(null)
        try {
            MedicationStatementValidator.validateMedicationReference(statement, false)
        } catch (IhrBadRequestException) {
            error = true
        }

        expect:
        error
    }

    @Unroll
    void "Test isActionFlagUpsert #desc"() {
        def result = false
        given:
        def codingList = [buildActionFlag(code, display)] as List<Coding>

        when:
        result = MedicationStatementValidator.of().isActionFlagUpsert(codingList)

        then:
        result == expected

        where:
        desc             | code         | display  || expected
        "Happy Path"     | "actionFlag" | "Upsert" || true
        "UnHappy Path 1" | "actionFlag" | "Delete" || false
        "UnHappy Path 2" | "actonFlag"  | "Upsert" || false
        "UnHappy Path 3" | ""           | "Upsert" || false
    }

    @Unroll
    void "Test isUrlValidForMedicationExtension #desc"() {
        def result = true
        def message = ""
        given:
        def statement = buildMedicationStatement()
        List<Extension> extensionList = new ArrayList()

        if (ihraderenceDateExites) {
            extensionList.add(buildExtension(MedicationStatementValidator.TAKEN_AS_ORDERED_URL, date))
            extensionList.add(buildExtension(url, date))
            statement.setExtension(extensionList as List<Extension>)
        } else {
            statement.addExtension(buildExtension(url, date))
        }

        when:
        try {
            MedicationStatementValidator.validateExtension(statement.getExtension(), MedicationStmtExtensionEnum.EXTENSIONS_URLS);
        }
        catch (IhrBadRequestException ex) {
            result = false
            message = ex.getMessage()
        }

        then:
        result == expected
        message == errorMsg

        where:
        desc                                       | url                                                      | ihraderenceDateExites | date                   || expected | errorMsg
        "Happy Path with extension"                | MedicationStatementValidator.IHR_HOLD_DATE_URL           | false                 | "2021-10-12T19:39:34Z" || true     | ""
        "Happy Path with no url in extension"      | ""                                                       | false                 | ""                     || false    | ResponseErrorMessages.MISSING_URL_IN_EXTENSION
        "ihr Adherance date with takenAsOrder url" | MedicationStatementValidator.IHR_ADHERENCE_STOP_DATE_URL | true                  | "2021-10-12T19:39:34Z" || true     | ""
        "invalid extension url"                    | "invalid url"                                            | false                 | "2021-10-12T19:39:34Z" || false    | ResponseErrorMessages.INVALID_URL_EXTENSION + " " + url
        "invalid extension value"                  | MedicationStatementValidator.IHR_HOLD_DATE_URL           | false                 | ""                     || false    | ResponseErrorMessages.INVALID_EXTENSION_VALUE

    }

    @Unroll
    void "Test medicationStatusReason #desc"() {
        def success = true
        def message = ""
        given:
        def concept = new CodeableConcept()
        def coding = buildCoding(system, code)
        concept.addCoding(coding)
        if (addCode) {
            concept.addCoding(coding)
        }

        when:
        try {
            MedicationStatementValidator.medicationStatusReason(concept)
        }
        catch (IhrBadRequestException ibre) {
            success = false
            message = ibre.getMessage()
        }

        then:
        success == pass
        message == errMsg

        where:
        desc            | system                                         | addCode | code  || pass  | errMsg
        "Happy Path 1"  | "http://snomed.info/sct"                       | false   | "xyz" || true  | ""
        "Multiple Code" | MedicationStatementValidator.IHR_HOLD_DATE_URL | true    | "xyz" || false | ResponseErrorMessages.STATUS_REASON_CODING_ERROR
        "System Null"   | null                                           | true    | "xyz" || false | ResponseErrorMessages.MISSING_STATUS_REASON_SYSTEM
    }

    @Unroll
    void "Test MeidcationStatement validation #desc"() {
        given:
        def result = true
        Bundle resourceBundle = getResourceBundle(fileName)
        def wrapper = FhirAttributesWrapper.builder().employeeId(new HashSet<>()).build()

        when:
        for (Bundle.BundleEntryComponent entity : resourceBundle.getEntry()) {
            if (entity.getResource() instanceof MedicationStatement) {
                try {
                    MedicationStatementValidator.of().validate((MedicationStatement) entity.getResource(), wrapper)
                }
                catch (IhrBadRequestException ibre) {
                    result = false
                }
            }
        }

        then:
        result == expected

        where:
        desc                          | fileName     | expected
        "Happy Path 1"                | "ngpd.json"  | true
        "Only Upsert Flag is allowed" | "ngpd1.json" | false

    }


    @Unroll
    def "Test validateMedicationReference #desc"() {
        given:
        def statement = buildMedicationStatement()
        def medication = buildMedication()
        def exception = false
        def errorMessage = ""

        when:
        try {
            statement.setMedication(new Reference(medication).setReference(referenceValue))
            statement.getMedicationReference().setResource(resource)
            statement.getMedicationReference().setReference(referenceValue)
            if (null != statement.getMedicationReference().getResource() && seCodeAndIdentifier) {
                ((Medication) statement.getMedicationReference().getResource()).addIdentifier(buildIdentifier(identifierText, "08908909"))
                ((Medication) statement.getMedicationReference().getResource()).setCode(new CodeableConcept(buildCoding(codeText, "235234")))
            }
            MedicationStatementValidator.validateMedicationReference(statement, recordKey)
        } catch (IhrBadRequestException ibre) {
            exception = true
            errorMessage = ibre.getMessage()
        }

        then:
        exception == failed
        errorMessage == errMessage

        where:
        desc                                  | recordKey | resource          | referenceValue                   | seCodeAndIdentifier | codeText               | identifierText || failed | errMessage
        "Happy Path"                          | false     | buildMedication() | "Medication/" + resource.getId() | true                | MEDICATION_CODE_SYSTEM | "conceptChid"  || false  | ""
        "Null resource"                       | false     | null              | "Medication/" + "123532"         | false               | MEDICATION_CODE_SYSTEM | "conceptChid"  || true   | ResponseErrorMessages.INVALID_MEDICATION_REFERENCE
        "Null resource and invalid reference" | false     | null              | null                             | false               | MEDICATION_CODE_SYSTEM | "conceptChid"  || true   | ResponseErrorMessages.MEDICATION_REQUIRED
        "Missing Code and Identifier"         | false     | buildMedication() | "Medication/" + resource.getId() | false               | MEDICATION_CODE_SYSTEM | "conceptChid"  || true   | ResponseErrorMessages.CONCEPT_CODE_REQUIRED
        "Invalid Identifier"                  | false     | buildMedication() | "Medication/" + resource.getId() | true                | MEDICATION_CODE_SYSTEM | "conceptChi"   || true   | ResponseErrorMessages.INVALID_IDENTIFIER
        "Invalid Code"                        | false     | buildMedication() | "Medication/" + resource.getId() | true                | "codesytem"            | "conceptChid"  || true   | ResponseErrorMessages.MISSING_MEDICATION_CODE

    }

    def "Validate  validateDoseAndRateQuantity  #desc"() {

        given:
        def text = "test doseAndRateQuantity"
        MedicationStatement ms = buildDosage(text, value, unit)

        when:
        def isValid = false
        def validationMessage = null

        try {
            MedicationStatementValidator.validateDoseAndRateQuantity(ms.getDosage().get(0).getDoseAndRate());
            isValid = true
        }
        catch (IhrBadRequestException | Exception ee) {
            validationMessage = ee.getMessage()
            isValid = false
        }

        then:
        isValid == expected
        validationMessage == errorMessage

        where:
        desc                                     | value | unit  || errorMessage                                       || expected
        "Happy path "                            | 1     | "TAB" || null                                               || true
        "invalid dQV value ,dQU present "        | 1.2   | "tab" || null                                               || true
        "dQV value  present ,invalid dQU "       | 1     | " "   || null                                               || true
        "dQV not present ,dQU present"           | null  | "mg"  || ResponseErrorMessages.DOSE_QUANTITY_VALUE_REQUIRED || false
        "passes - dQV present ,dQU not present " | 1     | null  || null                                               || true
    }


    @Unroll
    def "Test validateInformationSourceReference  #desc"() {
        given:
        def statement = buildMedicationStatement()

        def exception = false
        def errorMessage = ""

        when:
        try {
            statement.setInformationSource(new Reference(resource).setReference(referenceValue))
            MedicationStatementValidator.validateInformationSource(statement, fhirAttributesWrapper);

        } catch (IhrBadRequestException ibre) {
            exception = true
            errorMessage = ibre.getMessage()
        }

        then:
        exception == failed
        errorMessage == errMessage

        where:
        desc                | resource          | referenceValue                   || failed | errMessage
        "Happy Path"        | buildPatient()    | "Patient/" + resource.getId()    || false  | ""
        "null reference"    | ""                | ""                               || false  | ""
        "invalid reference" | buildMedication() | "Medication/" + resource.getId() || true   | ResponseErrorMessages.INVALID_INFORMATIONSOURCE_REFERENCE

    }

}

