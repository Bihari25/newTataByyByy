package com.uhg.ihr.centrihealth.api.exception;

import io.micronaut.context.annotation.Requires;
import io.micronaut.http.HttpRequest;
import io.micronaut.http.HttpResponse;
import io.micronaut.http.HttpStatus;
import io.micronaut.http.annotation.Produces;
import io.micronaut.http.server.exceptions.ExceptionHandler;

import javax.inject.Singleton;

@Produces
@Singleton
@Requires(classes = {IhrNotAcceptableException.class, ExceptionHandler.class})
public class IhrNotAcceptableExceptionHandler implements ExceptionHandler<IhrNotAcceptableException, HttpResponse> {

    @Override
    public HttpResponse handle(HttpRequest request, IhrNotAcceptableException exception) {
        return HttpResponse.status(HttpStatus.NOT_ACCEPTABLE, exception.getMessage()).body(ErrorHelper.handleError(request, exception));
    }
}
