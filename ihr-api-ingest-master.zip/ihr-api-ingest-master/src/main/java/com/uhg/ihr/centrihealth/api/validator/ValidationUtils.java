package com.uhg.ihr.centrihealth.api.validator;

import com.uhg.ihr.centrihealth.api.exception.IhrBadRequestException;
import com.uhg.ihr.centrihealth.api.model.FhirAttributesWrapper;
import com.uhg.ihr.centrihealth.api.util.Constant;
import com.uhg.ihr.centrihealth.api.util.ResponseErrorMessages;
import com.uhg.ihr.centrihealth.api.util.Z85;
import io.micronaut.core.util.CollectionUtils;
import io.micronaut.core.util.StringUtils;
import lombok.NoArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.time.DateUtils;
import org.hl7.fhir.r4.model.*;

import java.time.LocalDate;
import java.time.ZoneOffset;
import java.time.ZonedDateTime;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;
import java.util.Date;
import java.util.List;
import java.util.Locale;
import java.util.regex.Pattern;

@Slf4j
@NoArgsConstructor
public class ValidationUtils {

    private static final int PATIENT_NOTE_LIMIT = 1000;
    public static final String DATE_PATTERNS = "yyyy-MM-dd";
    private static final String NOTE_TYPE_URL = "https://new-wiki.optum.com/display/IHRI/ihrNoteType";
    private static final String CLINICAL_NOTE = "Clinical Note";
    private static int DATE_TIME_LENGTH = 10;
    private static String DATE_REGEX_SLASH = "((?:19|20)\\d\\d)/(0?[1-9]|1[012])/([12][0-9]|3[01]|0?[1-9])";
    private static String DATE_REGEX_HYPHEN = "^20[0-2][0-9]-((0[1-9])|(1[0-2]))-(0[1-9]|[1-2][0-9]|3[0-1])$";
    private static String PRINTABLE_RECORD_KEY_REGEX = "\\p{Print}+";
    private static Pattern DATE_PATTERN_SLASH = Pattern.compile(DATE_REGEX_SLASH);
    private static Pattern DATE_PATTERN_HYPHEN = Pattern.compile(DATE_REGEX_HYPHEN);
    private static Pattern PRINTABLE_RECORD_KEY_PATTERN = Pattern.compile(PRINTABLE_RECORD_KEY_REGEX);
    private static DateTimeFormatter FORMATTER = DateTimeFormatter.ofPattern("yyyy/MM/dd", Locale.US);
    private static DateTimeFormatter FORMATTER_HYPHEN = DateTimeFormatter.ofPattern("yyyy-MM-dd", Locale.US);

    protected static boolean hasNoTimestamp(Type type) {
        boolean hasNoTimestamp = false;
        if (type == null) {
            return true;
        }
        try {
            if (type instanceof InstantType) {
                InstantType instantType = (InstantType) type;
                if (instantType.getTimeZone() == null && !instantType.isTimeZoneZulu()) {
                    hasNoTimestamp = true;
                }
            } else if (type instanceof DateTimeType) {
                DateTimeType dateTimeType = (DateTimeType) type;
                if (dateTimeType.getTimeZone() == null && !dateTimeType.isTimeZoneZulu()) {
                    hasNoTimestamp = true;
                }
            } else {
                DateType dateTimeType = (DateType) type;
                if (dateTimeType.getTimeZone() == null && !dateTimeType.isTimeZoneZulu()) {
                    hasNoTimestamp = true;
                }
            }
        } catch (Exception ex) {
            log.warn(ex.getMessage());
            return true;
        }
        return hasNoTimestamp;
    }

    protected static boolean isDateOnly(DateType dateType) {
        if (dateType == null) {
            return false;
        }
        try {
            DateUtils.parseDateStrictly(dateType.asStringValue(), DATE_PATTERNS);
        } catch (Exception ex) {
            log.warn(ex.getMessage());
            return false;
        }
        return true;
    }

    protected static void validateIdentifier(List<Identifier> identifiers) {
        validateIdentifier(identifiers, false);
    }

    protected static void validateIdentifier(List<Identifier> identifiers, boolean noteExists) {
        boolean recordKeyExists = false;
        if (CollectionUtils.isNotEmpty(identifiers)) {
            for (Identifier identifier : identifiers) {
                if (!IdentifierEnum.ENUM_VALUES.contains(identifier.getType().getText())) {
                    throw new IhrBadRequestException(ResponseErrorMessages.INVALID_IDENTIFIER_KEY);
                }
                if (IdentifierEnum.RECORD_KEY.getValue().equals(identifier.getType().getText())) {
                    recordKeyExists = true;
                    if (!isIdentifierValid(identifier)) {
                        throw new IhrBadRequestException(ResponseErrorMessages.INVALID_RECORD_KEY);
                    }
                    //decode record key
                    decodeRecordKey(identifier);
                }
            }
        }
    }

    private static void decodeRecordKey(Identifier identifier) {
        try {
            byte[] decodedBytes = Z85.decode(identifier.getValue());
            String decodedRecordKey = new String(decodedBytes);
            if (!PRINTABLE_RECORD_KEY_PATTERN.matcher(decodedRecordKey).matches()) {
                throw new RuntimeException("Decoded record key contains unprintable characters.");
            }
        } catch (Exception e) {
            throw new IhrBadRequestException(ResponseErrorMessages.UNABLE_TO_DECODE_RECORD_MSG);
        }
    }

    public static boolean isIdentifierValid(Identifier identifier) {
        return (identifier.getType().getText() != null
                && !StringUtils.isEmpty(identifier.getValue()));
    }

    protected static void isValidNote(List<Annotation> notes) {
        if (CollectionUtils.isEmpty(notes)) {
            return;
        }
        if (notes.size() > 1) {
            throw new IhrBadRequestException(ResponseErrorMessages.INVALID_NOTE_COUNT);
        }
        if (!isValidNoteText(notes.get(0))) {
            throw new IhrBadRequestException(ResponseErrorMessages.INVALID_NOTE_TEXT);
        }
        if (!isValidAuthorReference(notes.get(0))) {
            throw new IhrBadRequestException(ResponseErrorMessages.INVALID_AUTHOR_REFERENCE);
        }
        if (!hasValidateDateTimeType(notes.get(0).getTimeElement())) {
            throw new IhrBadRequestException(ResponseErrorMessages.INVALID_NOTE_TIME);
        }
        if (!(isValidClinicalNote(notes.get(0)) || isValidPatientNote(notes.get(0)))) {
            throw new IhrBadRequestException(ResponseErrorMessages.INVALID_CLINICAL_NOTE);
        }
    }

    protected static boolean isValidNoteText(Annotation annotation) {
        return StringUtils.isNotEmpty(annotation.getText())
                && annotation.getText().length() <= PATIENT_NOTE_LIMIT;
    }

    private static boolean isValidAuthorReference(Annotation annotation) {
        return annotation.getAuthorReference().getResource() != null
                && annotation.getAuthorReference().getResource().getIdElement() != null
                && StringUtils.isNotEmpty(annotation.getAuthorReference().getReferenceElement().getResourceType());
    }

    protected static boolean isValidClinicalNote(Annotation annotation) {
        return hasValidClinicalExtension(annotation)
                && hasValidPractitionerIdentifier(annotation);
    }

    protected static boolean hasValidClinicalExtension(Annotation annotation) {
        return annotation.getExtension().size() == 1
                && hasExtension(annotation)
                && NOTE_TYPE_URL.equals(annotation.getExtension().get(0).getUrl())
                && CLINICAL_NOTE.equals(annotation.getExtension().get(0).getValue().toString());
    }

    protected static boolean hasExtension(Annotation annotation) {
        return annotation.getExtension().get(0).hasUrl()
                && annotation.getExtension().get(0).hasValue();
    }

    protected static boolean isValidPatientNote(Annotation annotation) {
        return hasValidPatientExtension(annotation)
                && hasValidPatientReference(annotation);
    }

    protected static boolean hasValidPatientExtension(Annotation annotation) {
        return annotation.getExtension().size() == 1
                && hasExtension(annotation)
                && NOTE_TYPE_URL.equals(annotation.getExtension().get(0).getUrl())
                && !CLINICAL_NOTE.equals(annotation.getExtension().get(0).getValue().toString());
    }

    public static boolean hasValidateDateTimeType(DateTimeType dateAsserted) {
        return dateAsserted != null && !hasNoTimestamp(dateAsserted);
    }

    protected static boolean hasValidPractitionerIdentifier(Annotation annotation) {
        if (annotation.getAuthorReference().getResource() instanceof Practitioner) {
            return true;
        } else {
            throw new IhrBadRequestException(ResponseErrorMessages.INVALID_PRACTITIONER);
        }
    }

    protected static boolean hasValidPatientReference(Annotation annotation) {
        if ((annotation.getAuthorReference().getResource() instanceof Patient
                || annotation.getAuthorReference().getResource() instanceof RelatedPerson)) {
            return true;
        } else {
            throw new IhrBadRequestException(ResponseErrorMessages.INVALID_PRACTITIONER);
        }
    }

        protected static void validateActionFlag(List<Coding> tag) {
        if (tag.isEmpty() || !tag.stream().allMatch(e -> ActionFlag.ENUM_VALUES.contains(e.getDisplay()) && Constant.ACTION_FLAG.equals(e.getCode()))) {
            throw new IhrBadRequestException(ResponseErrorMessages.INVALID_ACTION_FLAG);
        }
        if (tag.size() > 1) {
            throw new IhrBadRequestException(ResponseErrorMessages.INVALID_ACTION_FLAG_ITEMS);
        }

    }

    protected static void validateLastUpdatedDate(InstantType lastUpdated) {
        if (lastUpdated == null || lastUpdated.isEmpty()) {
            throw new IhrBadRequestException(ResponseErrorMessages.INVALID_LAST_UPDATED_DATE_FORMAT);
        }else if(hasNoTimestamp(lastUpdated)){
            throw new IhrBadRequestException(ResponseErrorMessages.INVALID_DATE_FORMAT);
        }
    }

    public static boolean isRequiredIdentifierExists(List<Identifier> identifiers, String text) {
        for (Identifier identifier : identifiers) {
            if (null != identifier.getType().getText()
                    && identifier.getType().getText().equals(text)
                    && null != identifier.getValue()
                    && StringUtils.isNotEmpty(identifier.getValue().trim())) {
                return true;
            }
        }
        return false;
    }

    public static void validateCoding(CodeableConcept concept) {
        if (null == concept || CollectionUtils.isEmpty(concept.getCoding())) {
            throw new IhrBadRequestException(ResponseErrorMessages.MISSING_CODEABLECONCEPT);
        } else {
            for (Coding coding : concept.getCoding()) {
                if (StringUtils.isEmpty(coding.getSystem()) || StringUtils.isEmpty(coding.getCode())) {
                    throw new IhrBadRequestException(ResponseErrorMessages.CODE_OR_SYSTEM_MISSING);
                }
            }
        }
    }


    public static void validateCodableDisplayCoding(CodeableConcept concept) {
        if (null != concept) {
            for (Coding coding : concept.getCoding()) {
                if (null == coding.getSystem() || null == coding.getDisplay()) {
                    throw new IhrBadRequestException(ResponseErrorMessages.DISPLAY_OR_SYSTEM_MISSING);
                }
            }
        } else {
            throw new IhrBadRequestException(ResponseErrorMessages.MISSING_CODEABLECONCEPT);
        }
    }

    public static String getEmployeeId(List<Identifier> identifiers) {

        for (Identifier identifier : identifiers) {
            if (identifier.getType().getText().equals(IdentifierEnum.EMPLOYEE_ID.getValue())) {
                return identifier.getValue();
            }
        }
        return null;
    }

    public static String getNpiId(List<Identifier> identifiers) {
        for (Identifier identifier : identifiers) {
            if (identifier.getType().getText().equals("NPI")) {
                return identifier.getValue();
            }
        }
        return null;
    }

    public static void validateEmployeeId(List<Identifier> identifiers, FhirAttributesWrapper fhirAttributesWrapper) {
        boolean employeeIdExists = ValidationUtils.isRequiredIdentifierExists(identifiers,
                IdentifierEnum.EMPLOYEE_ID.getValue());
        if (employeeIdExists) {
            String msId = ValidationUtils.getEmployeeId(identifiers);
            if (fhirAttributesWrapper.getEmployeeId().isEmpty()) {
                fhirAttributesWrapper.getEmployeeId().add(msId);
            } else if (!fhirAttributesWrapper.getEmployeeId().contains(msId)) {
                throw new IhrBadRequestException(ResponseErrorMessages.EMPLOYEE_IDS_MISMATCH);
            }
        }
    }

    public static boolean validateLoneIdentifier(List<Identifier> identifiers, String text) {
        boolean isValid = false;
        if (CollectionUtils.isNotEmpty(identifiers) && identifiers.size() == 1) {
            isValid = isRequiredIdentifierExists(identifiers, text);
        }
        return isValid;
    }

    protected static void validateRecordKey(List<Identifier> identifiers) {
        for (Identifier identifier : identifiers) {
            if (!IdentifierEnum.ENUM_VALUES.contains(identifier.getType().getText())) {
                throw new IhrBadRequestException(ResponseErrorMessages.INVALID_IDENTIFIER_KEY);
            }
            if (IdentifierEnum.RECORD_KEY.getValue().equals(identifier.getType().getText())) {
                if (!isIdentifierValid(identifier)) {
                    throw new IhrBadRequestException(ResponseErrorMessages.INVALID_RECORD_KEY);
                }
            }
        }
    }

    static Date toDate(String date) {
        try {
            if (isDateTime(date)) {
                return Date.from(ZonedDateTime.parse(date).toInstant());
            } else if (isDatePatternSlash(date)) {
                LocalDate ld = LocalDate.parse(date, FORMATTER);
                return Date.from(ld.atStartOfDay(ZoneOffset.UTC).toInstant());
            } else if (isDatePatternHyphen(date)) {
                LocalDate ld = LocalDate.parse(date, FORMATTER_HYPHEN);
                return Date.from(ld.atStartOfDay(ZoneOffset.UTC).toInstant());
            } else {
                return null;
            }
        } catch (DateTimeParseException de) {
            return null;
        }
    }

    public static boolean isDatePatternSlash(String date) {
        return date != null && DATE_PATTERN_SLASH.matcher(date).matches();
    }

    public static boolean isDatePatternHyphen(String date) {
        return date != null && DATE_PATTERN_HYPHEN.matcher(date).matches();
    }

    public static boolean isDateTime(String dateTime) {
        return dateTime != null && dateTime.length() > DATE_TIME_LENGTH;
    }
}
