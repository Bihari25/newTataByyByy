package com.uhg.ihr.centrihealth.api.controller;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ObjectNode;
import com.uhg.ihr.centrihealth.api.exception.HttpResponseException;
import com.uhg.ihr.centrihealth.api.exception.IhrFhirParseException;
import com.uhg.ihr.centrihealth.api.exception.IhrNotFoundException;
import com.uhg.ihr.centrihealth.api.logging.LoggingFilter;
import com.uhg.ihr.centrihealth.api.model.ActorIdType;
import com.uhg.ihr.centrihealth.api.model.FhirMapper;
import com.uhg.ihr.centrihealth.api.output.kafka.KafkaProducer;
import com.uhg.ihr.centrihealth.api.output.translator.OutputProducer;
import com.uhg.ihr.centrihealth.api.security.SenzingTokenHelper;
import com.uhg.ihr.centrihealth.api.service.SenzingService;
import com.uhg.ihr.centrihealth.api.util.ResponseErrorMessages;
import com.uhg.ihr.centrihealth.api.util.TranslatorPayloadUtils;
import com.uhg.ihr.centrihealth.api.validator.FhirValidator;
import com.uhg.ihr.centrihealth.senzing.model.SenzingProperties;
import com.uhg.ihr.centrihealth.senzing.model.SenzingRequest;
import io.micronaut.context.annotation.Context;
import io.micronaut.http.HttpHeaders;
import io.micronaut.http.HttpRequest;
import io.micronaut.http.HttpResponse;
import io.micronaut.http.HttpStatus;
import io.micronaut.http.MediaType;
import io.micronaut.http.MutableHttpResponse;
import io.micronaut.http.annotation.Body;
import io.micronaut.http.annotation.Controller;
import io.micronaut.http.annotation.Put;
import io.micronaut.http.client.exceptions.HttpClientResponseException;
import io.micronaut.http.simple.SimpleHttpResponseFactory;
import io.micronaut.security.annotation.Secured;
import io.micronaut.security.rules.SecurityRule;
import io.micronaut.validation.Validated;
import io.reactivex.Maybe;
import lombok.extern.slf4j.Slf4j;
import org.hl7.fhir.r4.model.Bundle;

import javax.inject.Inject;
import java.sql.Timestamp;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

@Slf4j
@Validated
@Context
@Controller("/bundles/v1")
@Secured(SecurityRule.IS_ANONYMOUS) //TODO: figure how how to move stargateJwtFilter to the new auth model
public class FhirController {
    private static final String CONTENT_MEDIA_TYPE = MediaType.APPLICATION_JSON + ";charset=utf-8";
    private static final String RESPONSE_HEADER = "X-UHG-Media-Type";
    private static final String SENZING = "senzing";
    private static final String SENZING_MSID = "senzingMsid";
    public static final String OPTUM_CID_EXT = "optum-cid-ext";
    private static final SimpleDateFormat timestampFormat = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss.SSSXXX");
    private static final String ERROR_500_MSG = "Issue with backend, please contact support";
    private final SenzingProperties senzingProperties;
    private final ObjectMapper mapper;

    @Inject
    private SenzingService senzingService;

    @Inject
    private OutputProducer producer;

    @Inject
    private KafkaProducer kafkaProducer;

    public FhirController(final SenzingProperties senzingProperties) {

        this.senzingProperties = senzingProperties;
        this.mapper = new ObjectMapper();
        log.info("initialized the API controller with SENZING_SUBJECT set to {}", senzingProperties.getSubject());
        if ("FIXME".equals(senzingProperties.getSecretKey())) {
            log.error("senzing secret key is not set");
        }
    }

    @Put(produces = CONTENT_MEDIA_TYPE, consumes = CONTENT_MEDIA_TYPE)
    public Maybe<MutableHttpResponse<?>> readBundle(final HttpRequest<String> request, @Body String bundleJsonString) {

        try {
            LoggingFilter.setBundleId(request);
            Bundle fhirBundle = FhirValidator.parseAndValidateBundle(bundleJsonString);
            SenzingRequest senzingRequest = FhirMapper.buildSenzingRequest(fhirBundle);
            LoggingFilter.logSenzingRequest(request, senzingRequest);
            String senzingToken = SenzingTokenHelper.generateToken(senzingProperties.getSubject(), null, senzingProperties.getAudience(),
                    new Date(), senzingProperties.getDuration(), senzingProperties.getRoles(), senzingProperties.getSecretKey());

            return getEmpIDAndSenzingMatch(request, senzingRequest, senzingToken)
                    .flatMap(ids -> sendTranslatorRequest(ids, fhirBundle, request.getHeaders().get(OPTUM_CID_EXT)))
                    .map(i -> i
                            .header(RESPONSE_HEADER, CONTENT_MEDIA_TYPE)
                            .header(HttpHeaders.CONTENT_TYPE, CONTENT_MEDIA_TYPE));

        } catch (Exception e) {
            LoggingFilter.logFail(request, "bundles", e.getMessage());

            if (e instanceof HttpResponseException) {
                HttpResponseException hrp = (HttpResponseException) e;
                throw new HttpResponseException(hrp.getStatusCode(), hrp.getMessage());
            }
            throw new IhrFhirParseException("unable to parse bundle " + bundleJsonString, e.getMessage());
        }
    }

    public Maybe<Map<ActorIdType, String>> getSenzingMatch(final HttpRequest<String> request, final SenzingRequest senzingRequest, final String token, final Map<ActorIdType, String> actorIdMap) {
        return senzingService.b50filterIhrId(token, senzingRequest, request.getHeaders().get(OPTUM_CID_EXT))
                .doOnSubscribe(sub -> LoggingFilter.logStart(request, SENZING))
                .flatMap(ihrIdResponse -> {
                    actorIdMap.put(ActorIdType.PATIENT, ihrIdResponse);
                    LoggingFilter.logSuccess(request, SENZING);
                    return Maybe.just(actorIdMap);
                })
                .onErrorResumeNext(e -> {
                    LoggingFilter.logFail(request, SENZING, e.getMessage());
                    return Maybe.error(new IhrNotFoundException(ResponseErrorMessages.PATIENT_NOT_FOUND_IN_SENZING));
                });
    }

    public Maybe<Map<ActorIdType, String>> getEmpIDAndSenzingMatch(final HttpRequest<String> request, final SenzingRequest senzingRequest, final String token) {
        Map<ActorIdType, String> actorIdMap = new HashMap<>();

        if (null == senzingRequest.getEmpId()) {
            return getSenzingMatch(request, SenzingRequest.buildRequestWithSearchId(senzingRequest), token, actorIdMap);
        }

        return senzingService.b50filterIhrId(token, SenzingRequest.buildRequestWithEmpId(senzingRequest), request.getHeaders().get(OPTUM_CID_EXT))
                .doOnSubscribe(sub -> LoggingFilter.logStart(request, SENZING_MSID))
                .onErrorResumeNext(e -> {
                    LoggingFilter.logFail(request, SENZING_MSID, e.getMessage());
                    return Maybe.error(new IhrNotFoundException(ResponseErrorMessages.PRACTITIONER_NOT_FOUND_IN_SENZING));
                })
                .flatMap(ihrIdResponse -> {
                    actorIdMap.put(ActorIdType.AUTHOR, ihrIdResponse);
                    LoggingFilter.logSuccess(request, SENZING_MSID);
                    return getSenzingMatch(request, SenzingRequest.buildRequestWithSearchId(senzingRequest), token, actorIdMap);
                });
    }

    public Maybe<MutableHttpResponse<ObjectNode>> sendTranslatorRequest(Map<ActorIdType, String> map, Bundle fhirBundle, String optumCidExt) {
        try {
            String jsonMessage = TranslatorPayloadUtils.getBundleJsonString(map, fhirBundle);
                   kafkaProducer.send(map.get(ActorIdType.PATIENT), jsonMessage);
            return producer.sendPayload(jsonMessage, jsonMessage)
                    .map(response -> {
                        if (response.getStatus().getCode() >= 200 && response.getStatus().getCode() < 300) {
                            MutableHttpResponse<ObjectNode> clientResponse = SimpleHttpResponseFactory.INSTANCE.status(HttpStatus.ACCEPTED);
                            return clientResponse;
                        } else {
                            log.error("Unexpected response of '{}' from Translator API, message: {}", response.getStatus().getCode(), response.getStatus().getReason());
                            throw new HttpClientResponseException("Unexpected Translator Response", response);
                        }
                    })
                    .onErrorReturn(error -> handleTranslatorError(error, optumCidExt));
        } catch (Exception jpe) {
            return Maybe.just(handleTranslatorError(jpe, optumCidExt));
        }
    }

    public MutableHttpResponse<ObjectNode> handleTranslatorError(Throwable error, String optumCidExt) {
        ObjectNode replyBody = mapper.createObjectNode();
        replyBody.put("timestamp", timestampFormat.format(new Timestamp((new Date()).getTime())));
        if (error instanceof HttpClientResponseException) {
            replyBody.put("message", error.getMessage());
            replyBody.put("statusCode", ((HttpClientResponseException) error).getStatus().getCode());
            log.error("Error from Translator for optum-cid-ext '{}': {} - {}", optumCidExt, ((HttpClientResponseException) error).getStatus().getCode(), error.getMessage());
        } else {
            String message = error == null ? "null" : error.getMessage();
            log.error("Translator API exception: {}", message);
            replyBody.put("message", error.getMessage());
            replyBody.put("statusCode", ((HttpClientResponseException) error).getStatus().getCode());
        }
        return HttpResponse.serverError(replyBody).status(((HttpClientResponseException) error).getStatus().getCode());
    }

}
