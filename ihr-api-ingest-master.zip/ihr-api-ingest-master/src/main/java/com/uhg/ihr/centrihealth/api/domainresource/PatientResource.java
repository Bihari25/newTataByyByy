package com.uhg.ihr.centrihealth.api.domainresource;

import lombok.Getter;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.hl7.fhir.r4.model.Annotation;
import org.hl7.fhir.r4.model.Identifier;
import org.hl7.fhir.r4.model.Patient;

import java.util.List;

@Slf4j
@Getter
@RequiredArgsConstructor(staticName = "of")
public class PatientResource implements IhrResource<Patient> {

    final Patient patient;

    @Override
    public Patient getDomainResource() {
        return patient;
    }

    @Override
    public List<Annotation> getNote() {
        return null;
    }

    @Override
    public Patient setNote(List<Annotation> notes) {
        return null;
    }

    @Override
    public List<Identifier> getIdentifiers() {
        return patient.getIdentifier();
    }

    @Override
    public Patient addIdentifier(Identifier identifier) {
        return patient.addIdentifier(identifier);
    }

}