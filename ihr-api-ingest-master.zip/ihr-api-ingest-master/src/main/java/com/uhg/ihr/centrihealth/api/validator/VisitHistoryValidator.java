package com.uhg.ihr.centrihealth.api.validator;


import com.uhg.ihr.centrihealth.api.model.FhirAttributesWrapper;
import lombok.NoArgsConstructor;
import org.hl7.fhir.r4.model.Encounter;
import org.hl7.fhir.r4.model.Resource;

@NoArgsConstructor(staticName = "of")
public class VisitHistoryValidator implements IhrResourceValidator {

    public void validate(Resource resource, FhirAttributesWrapper fhirAttributesWrapper) {
        if (resource instanceof Encounter) {
           validate((Encounter) resource, null);
        }
    }

    private void validate(final Encounter encounter, final FhirAttributesWrapper fhirAttributesWrapper) {

        //validate action flag
        ValidationUtils.validateActionFlag(encounter.getMeta().getTag());
        //validate last updated date
        ValidationUtils.validateLastUpdatedDate(encounter.getMeta().getLastUpdatedElement());
        // validate Identifiers (record key and RefId)
        boolean noteExists = false;
        ValidationUtils.validateIdentifier(encounter.getIdentifier(), noteExists);
    }
}