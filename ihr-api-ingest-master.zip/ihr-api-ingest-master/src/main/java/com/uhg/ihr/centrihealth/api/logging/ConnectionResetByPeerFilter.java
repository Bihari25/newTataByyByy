package com.uhg.ihr.centrihealth.api.logging;

import ch.qos.logback.classic.spi.ILoggingEvent;
import ch.qos.logback.core.filter.Filter;
import ch.qos.logback.core.spi.FilterReply;

public class ConnectionResetByPeerFilter extends Filter<ILoggingEvent> {
    @Override
    public FilterReply decide(ILoggingEvent event) {
        if (event.getLoggerName().contains("io.micronaut.http.server.netty.RoutingInBoundHandler") &&
                event.getMessage().contains("Micronaut Server Error - No request state present. Cause: Connection reset by peer")) {
            return FilterReply.DENY;
        } else {
            return FilterReply.NEUTRAL;
            //If the value returned is NEUTRAL , then the next filter in the list is consulted. If there are no further filters to consult, then the logging event is processed normally. If the returned value is ACCEPT , then the logging event is processed immediately skipping the invocation of the remaining filters.
        }
    }
}
