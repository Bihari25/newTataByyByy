package com.uhg.ihr.centrihealth.api.domainresource;

import lombok.Getter;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.hl7.fhir.r4.model.Annotation;
import org.hl7.fhir.r4.model.Coverage;
import org.hl7.fhir.r4.model.Identifier;

import java.util.List;

@Slf4j
@Getter
@RequiredArgsConstructor(staticName = "of")
public class CoverageResource implements IhrResource<Coverage> {

    final Coverage coverage;

    @Override
    public Coverage getDomainResource() {
        return coverage;
    }

    @Override
    public List<Annotation> getNote() {
        throw new UnsupportedOperationException();
    }

    @Override
    public Coverage setNote(List<Annotation> notes) {
        throw new UnsupportedOperationException();
    }

    @Override
    public List<Identifier> getIdentifiers() {
        return coverage.getIdentifier();
    }

    @Override
    public Coverage addIdentifier(Identifier identifier) {
        return coverage.addIdentifier(identifier);
    }

}