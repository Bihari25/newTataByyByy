package com.uhg.ihr.centrihealth.api.exception;

import lombok.RequiredArgsConstructor;

@RequiredArgsConstructor
public class IhrException extends RuntimeException {
    public IhrException(String message) {
        super(message);
    }

    public IhrException(String message, Exception e) {
        super(message, e);
    }
}