package com.uhg.ihr.centrihealth.api.security;

public class StargateJwtException extends RuntimeException {

    public StargateJwtException(String message) {
        super(message);
    }

}
