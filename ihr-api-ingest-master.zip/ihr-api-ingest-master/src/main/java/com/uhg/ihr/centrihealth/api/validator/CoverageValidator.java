package com.uhg.ihr.centrihealth.api.validator;

import com.uhg.ihr.centrihealth.api.exception.IhrBadRequestException;
import com.uhg.ihr.centrihealth.api.model.FhirAttributesWrapper;
import com.uhg.ihr.centrihealth.api.util.ResponseErrorMessages;
import io.micronaut.core.util.CollectionUtils;
import lombok.NoArgsConstructor;
import org.hl7.fhir.r4.model.Coverage;
import org.hl7.fhir.r4.model.Identifier;
import org.hl7.fhir.r4.model.Resource;

import java.util.List;
import java.util.Set;

@NoArgsConstructor(staticName = "of")
public class CoverageValidator implements IhrReferenceValidator {

    public void validate(Resource resource, FhirAttributesWrapper fhirAttributesWrapper) {
        if (resource instanceof Coverage) {
            validate((Coverage) resource, null);
        }
    }

    private static void validate(final Coverage coverage, final FhirAttributesWrapper fhirAttributesWrapper) {
        List<Identifier> identifiers = coverage.getIdentifier();
        if (CollectionUtils.isEmpty(identifiers)) {
            throw new IhrBadRequestException(ResponseErrorMessages.REQUIRED_IDENTIFIER);
        }
        boolean searchIdAvailable = false;
        for (Identifier identifier : identifiers) {
            if (!CoverageEnum.COVERAGE_ENUMS.contains(identifier.getType().getText())) {
                throw new IhrBadRequestException(ResponseErrorMessages.INVALID_IDENTIFIER_KEY_FOR_COVERAGE);

            }
            if (!ValidationUtils.isIdentifierValid(identifier)) {
                throw new IhrBadRequestException(ResponseErrorMessages.MISSING_IDENTIFIER_VALUE);
            }
            if (identifier.getType().getText().equalsIgnoreCase(CoverageEnum.SEARCH_ID.getValue())) {
                searchIdAvailable = true;
            }
        }
        if (!searchIdAvailable) {
            throw new IhrBadRequestException(ResponseErrorMessages.MISSING_SEARCH_ID);
        }
    }

    @Override
    public void setReferenceIds(Set<String> resourceIds, Resource resource) {
        if (resource instanceof Coverage) {
            resourceIds.add(resource.getId());
        }
    }
}
