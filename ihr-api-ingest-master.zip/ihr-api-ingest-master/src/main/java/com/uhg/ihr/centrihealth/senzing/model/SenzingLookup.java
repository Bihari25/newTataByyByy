package com.uhg.ihr.centrihealth.senzing.model;

import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * SenzingLookup  class used to hold look up keys from yml/yaml file to read senzing response
 * and cherry pick the values.
 *
 * @author ihr extract engineering team.
 * @CopyRight (C) All rights reserved to UHG Inc. It's Illegal to reproduce this code.
 */
@Data
@NoArgsConstructor
public class SenzingLookup {
    public static final String PREFIX = "senzing-lookup-keys.";
    public static final int INDICATOR_LEVEL_1 = 1;
    public static final int INDICATOR_LEVEL_2 = 2;
    public static final String LOG_RESULTS = "logResults";
    public static final String FILTERED_IHR_IDS = "filteredIhrIds";

    public static final String B50CHID = "b50Chid";
    public static final String DATA = "data";
    public static final String RESULTS = "searchResults";
    public static final String MATCH_LEVEL = "matchLevel";
    public static final String MATCH_KEY = "matchKey";
    public static final String IDENTIFIER_DATA = "identifierData";
    public static final String RECORD_SUMMARIES = "recordSummaries";
    public static final String RECORD_COUNT = "recordCount";
    public static final String RECORDS = "records";

}