package com.uhg.ihr.centrihealth.api.domainresource;

import lombok.Value;
import org.hl7.fhir.r4.model.AllergyIntolerance;
import org.hl7.fhir.r4.model.Bundle;
import org.hl7.fhir.r4.model.Resource;

import java.util.Set;

@Value(staticConstructor = "of")
public class AllergyIntoleranceResourceMapper implements IhrResourceMapper<AllergyIntolerance> {

    public IhrResource<?> createDomainResource(final Bundle.BundleEntryComponent entity) {

        if (!(entity.getResource() instanceof AllergyIntolerance)) {
            return AllergyIntoleranceResource.of(null);
        }
        AllergyIntoleranceResource newResource = AllergyIntoleranceResource.of(new AllergyIntolerance());
        AllergyIntoleranceResource oldResource = AllergyIntoleranceResource.of((AllergyIntolerance) entity.getResource());

        newResource.getDomainResource().setId(oldResource.getDomainResource().getId());

        if (null != oldResource.getAllergyIntolerance().getPatient()) {
            newResource.getDomainResource().setPatient(oldResource.getAllergyIntolerance().getPatient());
        }
        if (null != oldResource.getDomainResource().getAsserter()) {
            newResource.getDomainResource().setAsserter(oldResource.getAllergyIntolerance().getAsserter());
        }
        if (null != oldResource.getAllergyIntolerance().getRecorder()) {
            newResource.getDomainResource().setRecorder(oldResource.getAllergyIntolerance().getRecorder());
        }
        if (null != oldResource.getDomainResource().getRecordedDateElement()) {
            newResource.getDomainResource().setRecordedDateElement(oldResource.getDomainResource().getRecordedDateElement());
        }
        if (null != oldResource.getAllergyIntolerance().getType()) {
            newResource.getDomainResource().setType(oldResource.getDomainResource().getType());
        }
        if (null != oldResource.getAllergyIntolerance().getCode()) {
            newResource.getDomainResource().setCode(oldResource.getDomainResource().getCode());
        }
        if (null != oldResource.getDomainResource().getReaction()) {
            newResource.getDomainResource().setReaction(oldResource.getDomainResource().getReaction());
        }
        if (null != oldResource.getAllergyIntolerance().getOnsetPeriod()) {
            newResource.getDomainResource().setOnset(oldResource.getDomainResource().getOnsetPeriod());
        }

        return IhrResourceMapper.buildIhrResource(oldResource, newResource);
    }

}
