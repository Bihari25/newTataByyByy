package com.uhg.ihr.centrihealth.api.output.translator;

import io.micronaut.http.HttpResponse;
import io.reactivex.Maybe;

public interface OutputProducer {

    Maybe<HttpResponse<String>> sendPayload(String optumCidExt, String payload);
}
