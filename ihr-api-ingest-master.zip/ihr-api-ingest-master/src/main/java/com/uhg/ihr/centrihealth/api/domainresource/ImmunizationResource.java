package com.uhg.ihr.centrihealth.api.domainresource;

import lombok.Getter;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.hl7.fhir.r4.model.Annotation;
import org.hl7.fhir.r4.model.Identifier;
import org.hl7.fhir.r4.model.Immunization;

import java.util.List;

@Slf4j
@Getter
@RequiredArgsConstructor(staticName = "of")
public class ImmunizationResource implements IhrResource<Immunization> {

    final Immunization immunization;

    @Override
    public Immunization getDomainResource() {
        return immunization;
    }

    @Override
    public List<Annotation> getNote() {
        return immunization.getNote();
    }

    @Override
    public Immunization setNote(List<Annotation> notes) {
        return immunization.setNote(notes);
    }

    @Override
    public List<Identifier> getIdentifiers() {
        return immunization.getIdentifier();
    }

    @Override
    public Immunization addIdentifier(Identifier identifier) {
        return immunization.addIdentifier(identifier);
    }
}