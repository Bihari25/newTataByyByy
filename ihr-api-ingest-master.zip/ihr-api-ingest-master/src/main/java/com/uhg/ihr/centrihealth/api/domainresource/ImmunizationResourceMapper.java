package com.uhg.ihr.centrihealth.api.domainresource;

import lombok.Value;
import org.hl7.fhir.r4.model.Bundle;
import org.hl7.fhir.r4.model.Immunization;

@Value(staticConstructor = "of")
public class ImmunizationResourceMapper implements IhrResourceMapper<Immunization> {

    public IhrResource<?> createDomainResource(final Bundle.BundleEntryComponent entity) {

        if (!(entity.getResource() instanceof Immunization)) {
            return ImmunizationResource.of(null);
        }
        ImmunizationResource newResource = ImmunizationResource.of(new Immunization());
        ImmunizationResource oldResource = ImmunizationResource.of((Immunization) entity.getResource());
        newResource.getDomainResource().setId(oldResource.getDomainResource().getId());

        if (null != oldResource.getDomainResource().getPatient()) {
            newResource.getDomainResource().setPatient(oldResource.getDomainResource().getPatient());
        }

        if (null != oldResource.getDomainResource().getVaccineCode()) {
            newResource.getDomainResource().setVaccineCode(oldResource.getDomainResource().getVaccineCode());
        }

        if (null != oldResource.getDomainResource().getReasonCode()) {
            newResource.getDomainResource().setReasonCode(oldResource.getDomainResource().getReasonCode());
        }

        if (null != oldResource.getDomainResource().getLotNumber()) {
            newResource.getDomainResource().setLotNumber(oldResource.getDomainResource().getLotNumber());
        }
        if (null != oldResource.getDomainResource().getOccurrence()) {
            newResource.getDomainResource().setOccurrence(oldResource.getDomainResource().getOccurrence());
        }
        if (null != oldResource.getDomainResource().getRecorded()) {
            newResource.getDomainResource().setRecorded(oldResource.getDomainResource().getRecorded());
        }
        if (null != oldResource.getDomainResource().getProtocolApplied()) {
            newResource.getDomainResource().setProtocolApplied(oldResource.getDomainResource().getProtocolApplied());
        }

        return IhrResourceMapper.buildIhrResource(oldResource, newResource);
    }
}
