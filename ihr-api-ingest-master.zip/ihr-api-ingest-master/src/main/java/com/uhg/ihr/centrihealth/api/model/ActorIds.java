package com.uhg.ihr.centrihealth.api.model;

import com.fasterxml.jackson.annotation.JsonAlias;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class ActorIds {
   /* @JsonProperty
    private String resourceUri;
*/
   @JsonProperty
    private String actorId;

    @JsonProperty
    private String actorIdType;

    @JsonProperty
    private String resourceUri;
}
