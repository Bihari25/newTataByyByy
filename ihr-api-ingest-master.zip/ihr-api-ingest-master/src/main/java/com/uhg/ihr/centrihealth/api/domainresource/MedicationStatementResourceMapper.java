package com.uhg.ihr.centrihealth.api.domainresource;

import lombok.Value;
import org.hl7.fhir.r4.model.Bundle;
import org.hl7.fhir.r4.model.MedicationStatement;

@Value(staticConstructor = "of")
public class MedicationStatementResourceMapper implements IhrResourceMapper<MedicationStatement> {

    public IhrResource<?> createDomainResource(final Bundle.BundleEntryComponent entity) {

        if (!(entity.getResource() instanceof MedicationStatement)) {
            return MedicationStatementResource.of(null);
        }
        MedicationStatementResource newResource = MedicationStatementResource.of(new MedicationStatement());
        MedicationStatementResource oldResource = MedicationStatementResource.of((MedicationStatement) entity.getResource());
        if (null != oldResource.getMedicationStatement().getMedicationReference()) {
            newResource.getDomainResource().setMedication(oldResource.getMedicationStatement().getMedicationReference());
        }
        if (null != oldResource.getMedicationStatement().getSubject()) {
            newResource.getDomainResource().setSubject(oldResource.getMedicationStatement().getSubject());
        }
        if (null != oldResource.getMedicationStatement().getInformationSource()) {
            newResource.getDomainResource().setInformationSource(oldResource.getMedicationStatement().getInformationSource());
        }
        newResource.getDomainResource().setId(oldResource.getDomainResource().getId());
        if (null != oldResource.getDomainResource().getDateAsserted()) {
            newResource.getDomainResource().setDateAsserted(oldResource.getDomainResource().getDateAsserted());
        }
        if (null != oldResource.getDomainResource().getEffectivePeriod()) {
            newResource.getDomainResource().setEffective(oldResource.getDomainResource().getEffectivePeriod());
        }
        if (null != oldResource.getDomainResource().getExtension()) {
            newResource.getDomainResource().setExtension(oldResource.getDomainResource().getExtension());
        }
        if (null != oldResource.getDomainResource().getStatus()) {
            newResource.getDomainResource().setStatus(oldResource.getDomainResource().getStatus());
        }
        if (null != oldResource.getDomainResource().getStatusReason()) {
            newResource.getDomainResource().setStatusReason(oldResource.getDomainResource().getStatusReason());
        }
        if (null != oldResource.getDomainResource().getDosage()) {
            newResource.getDomainResource().setDosage(oldResource.getDomainResource().getDosage());
        }
        if (null != oldResource.getDomainResource().getReasonCode()) {
            newResource.getDomainResource().setReasonCode(oldResource.getDomainResource().getReasonCode());
        }
        return IhrResourceMapper.buildIhrResource(oldResource, newResource);
    }
}
