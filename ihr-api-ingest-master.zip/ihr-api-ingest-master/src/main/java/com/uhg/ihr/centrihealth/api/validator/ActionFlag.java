package com.uhg.ihr.centrihealth.api.validator;

import java.util.Arrays;
import java.util.Set;
import java.util.stream.Collectors;

public enum ActionFlag {

    UPSERT("Upsert"),
    DELETE("Delete");

    ActionFlag(String value) {
        this.value = value;
    }

    private String value;
    public String getValue() {
        return value;
    }

    protected static final Set<String> ENUM_VALUES = Arrays.stream(ActionFlag.values())
            .map(ActionFlag::getValue)
            .collect(Collectors.toSet());
}
