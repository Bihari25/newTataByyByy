package com.uhg.ihr.centrihealth.api.domainresource;

import lombok.Value;
import org.hl7.fhir.r4.model.Bundle;
import org.hl7.fhir.r4.model.Coverage;

@Value(staticConstructor = "of")
public class CoverageResourceMapper implements IhrResourceMapper<Coverage> {

    public IhrResource<?> createDomainResource(final Bundle.BundleEntryComponent entity) {

        if (!(entity.getResource() instanceof Coverage)) {
            return CoverageResource.of(null);
        }
        CoverageResource newResource = CoverageResource.of(new Coverage());
        CoverageResource oldResource = CoverageResource.of((Coverage) entity.getResource());
        newResource.getDomainResource().setId(oldResource.getDomainResource().getId());
        newResource.getDomainResource().setIdentifier(oldResource.getDomainResource().getIdentifier());
        return newResource;
    }
}
