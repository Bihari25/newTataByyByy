 package com.uhg.ihr.centrihealth.api.model;

import com.uhg.ihr.centrihealth.api.validator.ValidationUtils;
import com.uhg.ihr.centrihealth.senzing.model.SenzingRequest;
import lombok.NoArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.hl7.fhir.r4.model.Bundle;
import org.hl7.fhir.r4.model.MedicationStatement;

@Slf4j
@NoArgsConstructor(staticName = "of")
public class MedicationStatementDecorator implements SenzingRequestDecorator<MedicationStatement> {
    @Override
    public SenzingRequest buildSenzingRequest(final Bundle.BundleEntryComponent entity, final SenzingRequest senzingRequest) {
        if (entity.getResource() instanceof MedicationStatement) {
            MedicationStatement statement = (MedicationStatement) entity.getResource();
           // String msId = ValidationUtils.getEmployeeId(statement.getIdentifier());
            //senzingRequest.setMsId(msId);
        }
        return senzingRequest;
    }
}