package com.uhg.ihr.centrihealth.api.validator;

import com.uhg.ihr.centrihealth.api.model.FhirAttributesWrapper;
import org.hl7.fhir.r4.model.Resource;

public interface IhrResourceValidator {

    void validate(Resource resource, FhirAttributesWrapper fhirAttributesWrapper);

}
