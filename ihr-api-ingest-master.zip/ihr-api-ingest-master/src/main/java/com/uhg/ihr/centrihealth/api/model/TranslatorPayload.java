package com.uhg.ihr.centrihealth.api.model;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.databind.annotation.JsonSerialize;
import io.vavr.API;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

import java.util.List;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@ToString
public class TranslatorPayload {

    private static final String API_INGEST = "API_INGEST";

    @JsonProperty
    private String uuid;

    @JsonProperty
    @Builder.Default
    private String interfaceType = API_INGEST;

    @JsonProperty
    private String payload;

    @JsonProperty
    private String createTimestamp;

    @JsonProperty
    private String updateTimestamp;

    @JsonProperty("ACTORIDS")
    private List<ActorIds> ACTORIDS;

    @JsonProperty
    @Builder.Default
    private String fileName = API_INGEST;

    @JsonProperty
    @Builder.Default
    private String refileCount = "";

    @JsonProperty
    @Builder.Default
    private String refileType = "";

    @JsonProperty
    @Builder.Default
    private String manualRefileCount = "";

    @JsonProperty
    @Builder.Default
    private String translatorPrgm = API_INGEST;
}