package com.uhg.ihr.centrihealth.api.rest;

import com.google.common.collect.ImmutableMap;
import com.uhg.ihr.centrihealth.api.util.AppUtils;
import io.micronaut.context.annotation.Requires;
import io.micronaut.context.env.MapPropertySource;
import io.micronaut.context.env.PropertySource;
import io.micronaut.core.async.SupplierUtil;
import io.micronaut.core.util.StringUtils;
import io.micronaut.management.endpoint.info.InfoEndpoint;
import io.micronaut.management.endpoint.info.InfoSource;
import io.micronaut.runtime.context.scope.Refreshable;
import io.reactivex.Flowable;
import lombok.extern.slf4j.Slf4j;
import org.reactivestreams.Publisher;

import java.io.InputStream;
import java.util.Collections;
import java.util.function.Supplier;
import java.util.jar.Attributes;
import java.util.jar.Manifest;

@Slf4j
@Refreshable
@Requires(beans = InfoEndpoint.class)
@Requires(property = "endpoints.info.enabled", notEquals = StringUtils.FALSE)
public class ManifestInfoSource implements InfoSource {

    private final Supplier<MapPropertySource> supplier;

    public ManifestInfoSource() {
        this.supplier = SupplierUtil.memoized(this::retrieveManifestInfo);
    }

    @Override
    public Publisher<PropertySource> getSource() {
        return Flowable.just(supplier.get());
    }

    private MapPropertySource retrieveManifestInfo() {
        try (InputStream is = AppUtils.readResourceAsStream("META-INF/MANIFEST.MF")) {
            Manifest manifest = new Manifest(is);
            Attributes attrs = manifest.getMainAttributes();
            return new MapPropertySource("manifest", ImmutableMap.of("MainAttributes", attrs));
        } catch (Exception e) {
            return new MapPropertySource("manifest", Collections.emptyMap());
        }
    }
}