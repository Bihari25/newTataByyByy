package com.uhg.ihr.centrihealth.api.validator;

import com.uhg.ihr.centrihealth.api.exception.IhrBadRequestException;
import com.uhg.ihr.centrihealth.api.model.FhirAttributesWrapper;
import com.uhg.ihr.centrihealth.api.util.ResponseErrorMessages;
import io.micronaut.core.util.CollectionUtils;
import io.micronaut.core.util.StringUtils;
import lombok.NoArgsConstructor;
import org.hl7.fhir.r4.model.Patient;
import org.hl7.fhir.r4.model.Resource;

import java.util.Set;

@NoArgsConstructor(staticName = "of")
public class PatientValidator implements IhrReferenceValidator{



    public void validate(Resource resource, FhirAttributesWrapper fhirAttributesWrapper) {
        if (resource instanceof Patient) {
            validate((Patient) resource, null);
        }
    }

    private void validate(final Patient patient, final FhirAttributesWrapper fhirAttributesWrapper) {
        if (!ValidationUtils.isDateOnly(patient.getBirthDateElement())) {
            throw new IhrBadRequestException(ResponseErrorMessages.INVALID_BIRTHDAY_FORMAT);
        }
        if (!(CollectionUtils.isNotEmpty(patient.getName()) &&
                StringUtils.isNotEmpty(patient.getName().get(0).getFamily()) &&
                CollectionUtils.isNotEmpty(patient.getName().get(0).getGiven()) &&
                StringUtils.isNotEmpty(patient.getName().get(0).getGiven().get(0).toString()))) {
            throw new IhrBadRequestException(ResponseErrorMessages.PATIENT_NAME_MISSING);
        }
    }


    @Override
    public void setReferenceIds(Set<String> resourceIds, Resource resource) {
        if (resource instanceof Patient) {
            resourceIds.add(resource.getId());
        }
    }
}
