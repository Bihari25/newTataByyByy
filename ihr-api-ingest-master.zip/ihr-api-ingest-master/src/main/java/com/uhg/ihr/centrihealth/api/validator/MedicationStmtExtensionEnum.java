package com.uhg.ihr.centrihealth.api.validator;

import lombok.Getter;
import java.util.Arrays;
import java.util.Set;
import java.util.stream.Collectors;

@Getter
public enum MedicationStmtExtensionEnum {

    IHR_HOLD_DATE("https://new-wiki.optum.com/display/IHRI/ihrHoldDate"),
    IHR_RESTART_DATE("https://new-wiki.optum.com/display/IHRI/ihrRestartDate"),
    IHR_ADHERENCE_STOP_DATE("https://new-wiki.optum.com/display/IHRI/ihrAdherenceStopDate"),
    TAKEN_AS_ORDERED("https://new-wiki.optum.com/display/IHRI/takenAsOrdered");

    protected static final Set<String> EXTENSIONS_URLS = Arrays.stream(MedicationStmtExtensionEnum.values())
            .map(MedicationStmtExtensionEnum::getExtensionUrl).collect(Collectors.toSet());

    private String extensionUrl;

    MedicationStmtExtensionEnum(String extensionUrl) {
        this.extensionUrl = extensionUrl;
    }
}