package com.uhg.ihr.centrihealth.api.util;

import com.google.common.io.CharStreams;
import com.uhg.ihr.centrihealth.api.exception.IhrBadRequestException;
import com.uhg.ihr.centrihealth.api.exception.IhrException;
import io.micronaut.core.io.ResourceResolver;
import io.micronaut.core.io.scan.ClassPathResourceLoader;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;

import java.io.InputStream;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.text.SimpleDateFormat;
import java.time.format.DateTimeParseException;
import java.util.Date;
import java.util.Optional;
import java.util.jar.Attributes;
import java.util.jar.Manifest;

public class AppUtils {

    /**
     * Method to get the build version from Manifest.MF file.
     *
     * @return String
     */
    public static String getBuildVersionFromManifestInfo() {
        String buildVersion;
        try (InputStream is = readResourceAsStream("META-INF/MANIFEST.MF")) {
            /* Validate build version is present; if not set default value. */
            Manifest manifest = new Manifest(is);
            Attributes attrs = manifest.getMainAttributes();
            buildVersion = StringUtils.isNotBlank(attrs.getValue("Build-Version")) ? attrs.getValue("Build-Version") : "0.0.1";
        } catch (Exception ex) {
            buildVersion = "0.0.1";
        }

        return buildVersion;
    }

    public static InputStream readResourceAsStream(String resourcePath) {
        Optional<ClassPathResourceLoader> loader = new ResourceResolver().getLoader(ClassPathResourceLoader.class);
        if (!loader.isPresent()) {
            throw new IhrException("unable to resolve resource loader");
        }
        return loader.get().getResourceAsStream("classpath:" + resourcePath)
                .orElseThrow(() -> new RuntimeException("unable to read resource"));
    }

    public static String readResource(String resourcePath) {
        InputStream is = readResourceAsStream(resourcePath);

        try (InputStreamReader reader = new InputStreamReader(is, StandardCharsets.UTF_8)) {
            return CharStreams.toString(reader);
        } catch (Exception e) {
            throw new IhrException("unable to read resource", e);
        }
    }

    public static String toDateString(Date date) {
        try {
            String DATE_PATTERN_SIMPLE = "yyyy/MM/dd";
            SimpleDateFormat simpleDateFormat = new SimpleDateFormat(DATE_PATTERN_SIMPLE);
            return simpleDateFormat.format(date);
        } catch (DateTimeParseException de) {
            throw new IhrBadRequestException(de.getMessage());
        }
    }
}
