package com.uhg.ihr.centrihealth.api.domainresource;

import lombok.Value;
import org.hl7.fhir.r4.model.Bundle;
import org.hl7.fhir.r4.model.Medication;

@Value(staticConstructor = "of")
public class MedicationResourceMapper implements IhrResourceMapper<Medication> {

    public IhrResource<?> createDomainResource(final Bundle.BundleEntryComponent entity) {

        if (!(entity.getResource() instanceof Medication)) {
            return MedicationResource.of(null);
        }
        MedicationResource newResource = MedicationResource.of(new Medication());
        MedicationResource oldResource = MedicationResource.of((Medication) entity.getResource());
        newResource.getDomainResource().setCode(oldResource.getDomainResource().getCode());
        newResource.getDomainResource().setId(oldResource.getDomainResource().getId());
        newResource.getDomainResource().setIdentifier(oldResource.getDomainResource().getIdentifier());
        return newResource;
    }
}
