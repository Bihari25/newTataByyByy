package com.uhg.ihr.centrihealth.api.util;

import lombok.extern.slf4j.Slf4j;

import java.util.regex.Pattern;

@Slf4j
public class ResponseErrorMessages {
    //FHIR
    public static final String FHIR_SCHEMA_ERROR="FHIR01: Schema error. ";
    public static final String BUNDLE_ERROR = "FHIR02: Resource empty or missing in post body";
    public static final String INVALID_BUNDLE_TYPE = "FHIR03: Resource bundle type should be \"transaction\"";
    public static final String MISSING_BUNDLE_TYPE = "FHIR06: Missing resource bundle type";
    public static final String INVALID_BUNDLE_ID = "FHIR04: Invalid bundle id";
    public static final String DUPLICATE_RESOURCE_IDS = "FHIR05: Duplicate resource ids";
   

    //GLOBAL
    public static final String INVALID_RESOURCE = "GLOB01: Invalid resource. Allowed resource types are: ";
    public static final String MANDATORY_RESOURCE = "GLOB02: Missing required resource: [Patient, Coverage, Provenance]";
    public static final String CODE_OR_SYSTEM_MISSING = "GLOB03: Missing code or system in coding structure";
    public static final String INVALID_RESOURCE_ID = "GLOB04: Missing or invalid resource id";
    public static final String INVALID_IDENTIFIER_KEY = "GLOB05: Identifier type text incorrect; use [recordKey, employeeId]";
    public static final String INVALID_PATIENT_REFERENCE = "GLOB06: Missing or invalid patient reference [Patient Resource, Resource type or id]";
    public static final String PATIENT_NOT_FOUND_IN_SENZING= "GLOB07: Patient IHR identifier not found in allowed actor database";
    public static final String MISSING_CODEABLECONCEPT = "GLOB08: A required codeable concept is missing from the message";
    public static final String DISPLAY_OR_SYSTEM_MISSING = "GLOB09: Missing display or system in coding structure";
    public static final String EMPLOYEE_IDS_MISMATCH = "GLOB10: Practitioner employee Id not found in allowed actor database";
    public static final String PRACTITIONER_NOT_FOUND_IN_SENZING= "GLOB11: Practitioner IHR identifier not found in allowed actor database";
    public static final String INVALID_ACTION_FLAG = "GLOB12: Missing or invalid action flag (meta.tag) code or display value [Upsert, Delete]";
    public static final String INVALID_ACTION_FLAG_ITEMS = "GLOB14: Multiple action flags submitted; only one allowed";
    public static final String INVALID_LAST_UPDATED_DATE_FORMAT = "GLOB15: Missing lastUpdated value";
    public static final String INVALID_DATE_FORMAT = "GLOB16: Invalid datetime format";
    public static final String INVALID_RECORD_KEY = "GLOB17: Missing or invalid recordKey required for edit";
    public static final String INVALID_NOTE_TIME = "GLOB18: Missing or invalid format note time";
    public static final String UNABLE_TO_DECODE_RECORD_MSG = "GLOB19: Record key unable to be decoded, possible extra characters";
    public static final String INVALID_NOTE_COUNT = "GLOB20: Multiple notes submitted on a medication; only one allowed";
    public static final String INVALID_AUTHOR_REFERENCE = "GLOB21: Invalid note author reference; missing or unmatched type or id";
    public static final String INVALID_NOTE_TEXT = "GLOB22: Missing note text";
    public static final String INVALID_CLINICAL_NOTE = "GLOB23: Missing or invalid note extension url or valueString";
    public static final String INVALID_PRACTITIONER = "GLOB24: Invalid authorReference in note based on ihrNoteType";

    //COVERAGE
    public static final String REQUIRED_IDENTIFIER = "COV01: Identifier structure is missing in Coverage";
    public static final String MISSING_IDENTIFIER_VALUE = "COV02: Missing identifier value in Coverage resource";
    public static final String MISSING_SEARCH_ID = "COV03: Missing identifier in Coverage resource";
    public static final String INVALID_IDENTIFIER_KEY_FOR_COVERAGE = "COV04: Identifier.type.text missing or invalid type used; use [searchId, correlationId]";

    //PATIENT
    public static final String INVALID_BIRTHDAY_FORMAT = "PATIENT01: Invalid date format";
    public static final String PATIENT_NAME_MISSING = "PATIENT02: Missing patient name element [Family, Given]";

    //MEDICATION
    public static final String MEDICATION_REQUIRED = "MED01: Missing recordKey (edit) or Medication vocab/vocab code (add)";
    public static final String CONCEPT_CODE_REQUIRED = "MED02: Missing Medication vocabulary code and vocabulary code system";
    public static final String MISSING_STATUS_REASON_SYSTEM = "MED03: Missing statusReason coding system";
    public static final String STATUS_REASON_CODING_ERROR = "MED04: Multiple status codes provided; only one allowed";
    public static final String REQUIRED_DATA_AUTHOR_IDENTIFIER = "dataAuthorIdentifier is required as date asserted is present";
    public static final String MISSING_MEDICATION_CODE = "MED05: Invalid URL value in medication coding system";
    public static final String UPSERT_ACTION_FLAG_ERROR = "MED06: Action flag value \"upsert\" required for adding or editing medications";
    public static final String INVALID_IDENTIFIER = "MED07: Invalid identifier in medication resource";
    public static final String INVALID_MEDICATION_REFERENCE = "MED08: Missing or invalid medication reference in MedicationStatement";
    public static final String INVALID_INFORMATIONSOURCE_REFERENCE = "MED09: Missing or invalid informationSource reference [Resource type or id]";
    public static final String DOSE_QUANTITY_VALUE_REQUIRED = "MED10: Missing doseQuantity value";
    public static final String MISSING_URL_IN_EXTENSION = "MED11: Missing extension URL";
    public static final String INVALID_URL_EXTENSION = "MED12: Invalid extension URL";
    public static final String INVALID_EXTENSION_VALUE = "MED13: Missing extension value";

    //PRACTITIONER
    public static final String IDENTIFIER_EXCEPTION = "PRACT01: Missing practitioner identifier [EmployeeID]";
    public static final String CODEABLE_EXCEPTION = "PRACT02: Missing or invalid practitioner role code";
    public static final String EMPLOYEE_ID_LENGTH_MISMATCH = "PRACT03: EmployeeId  must be 9 digit Characters";

    //PROVENANCE
    public static final String INVALID_TARGET_REFERENCE = "PROV01: Invalid target reference/resource";
    public static final String TARGET_REQUIRED = "PROV02: Missing target reference";
    public static final String RECORDED_REQUIRED = "PROV03: Missing recorded date";
    public static final String AGENT_REQUIRED = "PROV04: Missing agent structure";
    public static final String AGENT_TYPE_EXCEPTION = "PROV05: Missing or invalid agent type [system / code / display]";
    public static final String AGENT_WHO_REFERENCE_EXCEPTION = "PROV06: Missing or invalid agent who reference";
    public static final String DUPLICATE_REFERENCES_ERROR = "PROV07: references count exceeded in Provenance target";
    public static final String MISSING_RESOURCES_ERROR = "PROV08: Not all resources available in Provenance target";
    public static final String INVALID_AGENT_WHO_REFERENCE = "PROV09: Invalid Agent Who Reference or Resource";

    //CONDITIONS
    public static final String INVALID_RECORDED_DATE_COND = "COND01: Invalid recordedDate date time format";
    public static final String INVALID_PRACTITIONER_REFERENCE_COND = "COND02: Recorder reference should be a practitioner reference";
    public static final String INVALID_ASSERTER_REFERENCE_COND = "COND03: Invalid asserter or asserter reference";
    public static final String RECORD_KEY_OR_CONDITION_CODE_REQUIRED = "COND04: A recordKey [edit] or condition system and code [add] must be provided";
    public static final String INVALID_PRACTITIONER_REFERENCE_ID_COND = "COND05: Invalid recorder reference; expect practitioner reference";
    public static final String MISSING_INFORMATION_TEXT_COND = "COND06: Asserter code is missing or invalid";
    public static final String INVALID_PERIOD_COND = "COND07: Invalid dateTime format onsetPeriod start or end date";

    //AllergyIntolerance
    public static final String INVALID_PRACTITIONER_REFERENCE_ID_ALLERGY = "ALRGY01:  Invalid practitioner identifier structure or value [EmployeeID]";
    public static final String INVALID_PRACTITIONER_REFERENCE_ALLERGY = "ALRGY02: Recorder reference should be a practitioner reference";
    public static final String INVALID_PERIOD_ALLERGY = "ALRGY03: Invalid dateTime format onsetPeriod start or end date";
    public static final String INVALID_RECORDED_DATE_ALLERGY = "ALRGY04: Invalid recordedDate date time format";
    public static final String INVALID_ASSERTER_REFERENCE_ALLERGY = "ALRGY05: Invalid asserter or asserter reference";
    public static final String MISSING_INFORMATION_TEXT_ALLERGY = "ALRGY06: Asserter code is missing or invalid";
    public static final String PATIENT_RESOURCE_MISSING_ALLERGY = "ALRGY07: Missing patient reference in allergyIntolerance resouce";
    public static final String RECORD_KEY_OR_ALLERGY_CODE_REQUIRED = "ALRGY08: A recordKey [edit] or allergyIntolerance system and code [add] must be provided";
    public static final String TYPE_AND_ALLERGY_CODE_REQUIRED = "ALRGY09: Missing allergy type value [allergy, intolerance]";
    public static final String MANIFESTATION_CODE_MISSING = "ALRGY10: If allergyIntolerance.reaction is used, manifestation code is required";

    //IMMUNIZATION
    public static final String RECORD_KEY_OR_IMMUNIZATION_VACCINE_CODE_REQUIRED = "IMM03: A recordKey [edit] or vaccineCode system and code [add] must be provided";
    public static final String INVALID_OCCURRENCE_DATE_TIME = "IMM05: Invalid occurenceDateTime format";
    public static final String REQUIRED_OCCURRENCE_FIELD = "IMM06: Missing occurrenceDateTime [required field]";
    public static final String INVALID_REASON_CODE ="IMM07: Where vaccineCode value '999' provided, reasonCode is required";
    public static final String INVALID_POSITIVE_NUMBER ="IMM08: Dose number requires positive integer";
    public static final String INVALID_RECORDED_DATE_IMM = "IMM01: Invalid recorded date format";
    public static final String PATIENT_RESOURCE_MISSING_IMM = "IMM02: Missing patient reference in immunization resource";

}