package com.uhg.ihr.centrihealth.api.domainresource;

import lombok.Getter;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.hl7.fhir.r4.model.Annotation;
import org.hl7.fhir.r4.model.Identifier;
import org.hl7.fhir.r4.model.MedicationStatement;

import java.util.List;

@Slf4j
@Getter
@RequiredArgsConstructor(staticName = "of")
public class MedicationStatementResource implements IhrResource<MedicationStatement> {

    final MedicationStatement medicationStatement;

    @Override
    public MedicationStatement getDomainResource() {
        return medicationStatement;
    }

    @Override
    public List<Annotation> getNote() {
        return medicationStatement.getNote();
    }

    @Override
    public MedicationStatement setNote(List<Annotation> notes) {
        return medicationStatement.setNote(notes);
    }

    @Override
    public List<Identifier> getIdentifiers() {
        return medicationStatement.getIdentifier();
    }

    @Override
    public MedicationStatement addIdentifier(Identifier identifier) {
        return medicationStatement.addIdentifier(identifier);
    }
}