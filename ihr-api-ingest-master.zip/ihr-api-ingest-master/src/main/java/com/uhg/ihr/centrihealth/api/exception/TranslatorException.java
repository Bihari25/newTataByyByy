package com.uhg.ihr.centrihealth.api.exception;

import lombok.RequiredArgsConstructor;

@RequiredArgsConstructor
public class TranslatorException extends RuntimeException {
    public TranslatorException(String message) {
        super(message);
    }
}