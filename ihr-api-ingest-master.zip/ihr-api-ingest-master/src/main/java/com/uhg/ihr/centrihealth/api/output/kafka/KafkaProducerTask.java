package com.uhg.ihr.centrihealth.api.output.kafka;

import io.micronaut.configuration.kafka.annotation.KafkaKey;
import io.micronaut.context.annotation.Requirements;
import io.micronaut.context.annotation.Requires;
import io.micronaut.context.annotation.Value;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.extern.slf4j.Slf4j;

import javax.inject.Inject;
import javax.inject.Singleton;
import java.util.ArrayList;
import java.util.List;

@Slf4j
@Requirements({
        @Requires(property = "kafka.producers.enriched.enabled", value = "true")
})
@Singleton
public class KafkaProducerTask implements KafkaProducer {

    private static final String messageBufferMutex = "1";

    private List<KafkaBufferMessage> messageBuffer;
    private int maxBufferMessages;
    private long sleepTime;
    private Thread kafkaThread;
    private KafkaProducerClient producer;

    @Inject
    public KafkaProducerTask(KafkaProducerClient producer,
                             @Value("${kafka.producers.enriched.manager.max.messages}") int kafkaLoggerMaxBufferMsgs,
                             @Value("${kafka.producers.enriched.manager.sleep.ms}") long sleepTime) {
        this.producer = producer;
        this.messageBuffer = new ArrayList<>();
        this.maxBufferMessages = kafkaLoggerMaxBufferMsgs;
        this.sleepTime = sleepTime;
        this.kafkaThread = new Thread(new KafkaSendLoop());
        this.kafkaThread.start();
    }

    private class KafkaSendLoop implements Runnable {

        @Override
        public void run() {
            while(true) {
                boolean bufferEmpty = true;
                List<KafkaBufferMessage> processList = null;
                synchronized (messageBufferMutex) {
                    bufferEmpty = messageBuffer.isEmpty();

                    if (!bufferEmpty) {
                        processList = messageBuffer;
                        messageBuffer = new ArrayList<>();
                    }
                }

                if (bufferEmpty) {
                    try {
                        Thread.sleep(sleepTime);
                    } catch (InterruptedException ignored) {
                        //Ignored
                    }
                } else {
                    if (processList != null) {
                        try {
                            processList
                                    .forEach(message -> producer.send(message.key, message.payload));
                        } catch (Exception e) {
                            log.error("Failed to send payload messages to kafka due to error: " + e.getMessage());
                        }
                    }
                }
            }
        }

    }

    @Data
    @AllArgsConstructor
    private class KafkaBufferMessage {
        private String key;
        private String payload;
    }

    public void send(@KafkaKey String key, String payload) {
        synchronized (messageBufferMutex) {
            if (messageBuffer.size() < maxBufferMessages) {
                this.messageBuffer.add(new KafkaBufferMessage(key, payload));
            } else {
                log.warn("Kafka message buffer full, could not add payload for key: " + key);
            }
        }
    }
}
