package com.uhg.ihr.centrihealth.api.validator;

import lombok.Getter;

import java.util.Arrays;
import java.util.Set;
import java.util.stream.Collectors;

@Getter
public enum PractitionerRoleInfoCodeEnum {

    //Facility Staff, Medical Director, Myself, Pharmacist, Prescriber, Primary Care Provider:
    FACITLITY_STAFF("Facility Staff"),
    MEDICAL_DIRECTOR("Medical Director"),
    MYSELF("Myself"),
    PHARMACIST("Pharmacist"),
    PRESCRIBER("Prescriber"),
    PRIMARY_CARE_PROVIDER("Primary Care Provider");

    private String code;

    PractitionerRoleInfoCodeEnum(String code){
        this.code = code;
    }

    protected static final Set<String> PRACTITIONER_ROLE_CODES = Arrays.stream(PractitionerRoleInfoCodeEnum.values())
            .map(PractitionerRoleInfoCodeEnum::getCode).collect(Collectors.toSet());


}
