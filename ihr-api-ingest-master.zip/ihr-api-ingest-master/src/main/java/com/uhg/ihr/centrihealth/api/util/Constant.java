package com.uhg.ihr.centrihealth.api.util;

import lombok.extern.slf4j.Slf4j;

@Slf4j
public class Constant {

    public static final String CORRELATION_ID = "correlationId";
    public static final String SEARCH_ID = "searchId";
    public static final String TRANSACTION = "transaction";
    public static final String ACTION_FLAG = "actionFlag";
    public static final String CONCEPT_CHID = "conceptChid";
    public static final String NPI = "NPI";
    public static final String employeeId = "employeeId";
}