package com.uhg.ihr.centrihealth.api.validator;

import com.uhg.ihr.centrihealth.api.exception.IhrBadRequestException;
import com.uhg.ihr.centrihealth.api.model.FhirAttributesWrapper;
import io.micronaut.core.util.CollectionUtils;
import io.micronaut.core.util.StringUtils;
import lombok.NoArgsConstructor;
import org.hl7.fhir.r4.model.CodeableConcept;
import org.hl7.fhir.r4.model.RelatedPerson;
import org.hl7.fhir.r4.model.Resource;

import java.util.List;

@NoArgsConstructor(staticName = "of")
public class RelatedPersonValidator implements IhrResourceValidator {

    private static final String INVALID_BIRTHDAY_FORMAT = "Invalid birthday format for Related Person";
    private static final String NAME_MISSING = "Name is missing for Related Person";
    private static final String RELATED_PERSON_EXCEPTION = "Either relationship or Name and DOB should be available";
    private static final String RELATIONSHIP_EXCEPTION = "Relationship missing or incorrect for RelatiedPerson";


    @Override
    public void validate(Resource resource, FhirAttributesWrapper fhirAttributesWrapper) {
        if (resource instanceof RelatedPerson) {
            validateRelationshipAndBig5((RelatedPerson) resource);
        }
    }

    /**
     * To check either relationship or ( Name and Big5 ) should be available for RelatedPerson
     * @param relatedPerson
     */
    private void validateRelationshipAndBig5(final RelatedPerson relatedPerson) {
        boolean nameAndDobExists = validateNameAndDOB(relatedPerson);
        boolean relationshipExists = validateRelationship(relatedPerson);
        if (!(nameAndDobExists || relationshipExists)) {
            throw new IhrBadRequestException(RELATED_PERSON_EXCEPTION);
        }
    }

    private boolean validateRelationship(final RelatedPerson relatedPerson) {
        List<CodeableConcept> codes = relatedPerson.getRelationship();
        boolean relationshipExists = false;
        if (CollectionUtils.isNotEmpty(codes) && codes.size() > 0) {
            if (!codes.stream().allMatch(code -> StringUtils.isNotEmpty(code.getText())
                    && RelatedPersonInfoCodeEnum.RELATED_PERSON_CODES.contains(code.getText()))) {
                throw new IhrBadRequestException(RELATIONSHIP_EXCEPTION);
            }
            relationshipExists = true;
        }
        return relationshipExists;
    }

    private boolean validateNameAndDOB(final RelatedPerson relatedPerson) {
        boolean dobExists = false;
        boolean nameExists = false;
        if (null != relatedPerson.getBirthDate() && null != relatedPerson.getBirthDateElement()) {
            if (!ValidationUtils.isDateOnly(relatedPerson.getBirthDateElement())) {
                throw new IhrBadRequestException(INVALID_BIRTHDAY_FORMAT);

            }
            dobExists = true;
        }
        if (CollectionUtils.isNotEmpty(relatedPerson.getName()) && relatedPerson.getName().size() > 0) {
            if (!(StringUtils.isNotEmpty(relatedPerson.getName().get(0).getFamily()) &&
                    CollectionUtils.isNotEmpty(relatedPerson.getName().get(0).getGiven()) &&
                    StringUtils.isNotEmpty(relatedPerson.getName().get(0).getGiven().get(0).toString()))) {
                throw new IhrBadRequestException(NAME_MISSING);
            }
            nameExists = true;
        }
        return nameExists && dobExists ;
    }
}
