package com.uhg.ihr.centrihealth.api.exception;

import io.micronaut.context.annotation.Requires;
import io.micronaut.http.HttpRequest;
import io.micronaut.http.HttpResponse;
import io.micronaut.http.HttpStatus;
import io.micronaut.http.annotation.Produces;
import io.micronaut.http.server.exceptions.ExceptionHandler;

import javax.inject.Singleton;

@Produces
@Singleton
@Requires(classes = {TranslatorException.class, ExceptionHandler.class})
public class TranslatorExceptionHandler implements ExceptionHandler<TranslatorException, HttpResponse>{

    @Override
    public HttpResponse handle(HttpRequest request, TranslatorException exception) {
        return HttpResponse.status(HttpStatus.INTERNAL_SERVER_ERROR, exception.getMessage()).body(ErrorHelper.handleError(request, exception));
    }

}


