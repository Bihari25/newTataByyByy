package com.uhg.ihr.centrihealth.api.validator;

import com.uhg.ihr.centrihealth.api.exception.IhrBadRequestException;
import com.uhg.ihr.centrihealth.api.model.FhirAttributesWrapper;
import com.uhg.ihr.centrihealth.api.util.ResponseErrorMessages;
import io.micronaut.core.util.CollectionUtils;
import lombok.NoArgsConstructor;
import org.hl7.fhir.r4.model.CodeableConcept;
import org.hl7.fhir.r4.model.Condition;
import org.hl7.fhir.r4.model.Patient;
import org.hl7.fhir.r4.model.Practitioner;
import org.hl7.fhir.r4.model.PractitionerRole;
import org.hl7.fhir.r4.model.RelatedPerson;
import org.hl7.fhir.r4.model.Resource;
import org.hl7.fhir.r4.model.ResourceType;
import java.util.List;
import java.util.Set;

@NoArgsConstructor(staticName = "of")
public class ConditionValidator implements IhrResourceValidator {


    public void validate(Resource resource, FhirAttributesWrapper fhirAttributesWrapper) {
        if (resource instanceof Condition) {
            validate((Condition) resource, null);
        }
    }
    /*
     * Key fields in Condition are recordKey and code, one or the other must be present otherwise validation
     * should fail.
     */
    private  void validate(final Condition condition, final FhirAttributesWrapper fhirAttributesWrapper) {

        //required - upsert action flag
        ValidationUtils.validateActionFlag(condition.getMeta().getTag());

        //required - last updated
        ValidationUtils.validateLastUpdatedDate(condition.getMeta().getLastUpdatedElement());

        //required - record key or allergy code
        validateRecordKeyConditionCode(condition);

        //optional - subject
        validateSubjectReference(condition, fhirAttributesWrapper);

        //optional - onsetPeriod date
        validateOnsetPeriodDate(condition);

        //optional - asserter
        validateAsserter(condition, fhirAttributesWrapper);

        // optional- notes
        ValidationUtils.isValidNote(condition.getNote());

        // optional- recorder
        validateRecorder(condition);

        //optional- recordedDate
        validateRecordedDate(condition);
    }

    private static void validateRecordedDate(Condition condition) {
        if (condition.hasRecordedDate()) {
            boolean recordedDate = condition.getRecordedDate() != null &&
                    null == ValidationUtils.toDate(condition.getRecordedDateElement().asStringValue());
            if (recordedDate) {
                throw new IhrBadRequestException(ResponseErrorMessages.INVALID_RECORDED_DATE_COND);
            }
        }
    }

    public static void validateRecorder(Condition condition) {
        if (condition.hasRecorder()) {
            if (condition.getRecorder().getResource() instanceof Practitioner) {
                Practitioner practitioner = (Practitioner) condition.getRecorder().getResource();
                boolean isEmployeeIdExists = ValidationUtils.isRequiredIdentifierExists(practitioner.getIdentifier(), IdentifierEnum.EMPLOYEE_ID.getValue());
                if (!isEmployeeIdExists) {
                    throw new IhrBadRequestException(ResponseErrorMessages.INVALID_PRACTITIONER_REFERENCE_ID_COND);
                }
            } else {
                throw new IhrBadRequestException(ResponseErrorMessages.INVALID_PRACTITIONER_REFERENCE_COND);
            }
        }
    }

    private static void validateAsserter(Condition condition, FhirAttributesWrapper fhirAttributesWrapper) {
        if (condition.hasAsserter() && null != condition.getAsserter().getResource()) {
            Resource resource = (Resource) condition.getAsserter().getResource();
            boolean isRelatedPerson = resource.getResourceType().toString().equalsIgnoreCase(ResourceType.RelatedPerson.toString())
                    && CollectionUtils.isNotEmpty(((RelatedPerson) resource).getRelationship());
            boolean isPractitioner = resource.getResourceType().toString().equalsIgnoreCase(ResourceType.PractitionerRole.toString())
                    && CollectionUtils.isNotEmpty(((PractitionerRole) resource).getCode());
            boolean isPatient = resource.getResourceType().toString().equalsIgnoreCase(ResourceType.Patient.toString());

            if (!isRelatedPerson && !isPractitioner && !isPatient) {
                throw new IhrBadRequestException(ResponseErrorMessages.INVALID_ASSERTER_REFERENCE_COND);
            } else {
                if (isRelatedPerson) {
                    validateAsserterCode(((RelatedPerson) resource).getRelationship(), RelatedPersonInfoCodeEnum.RELATED_PERSON_CODES);
                } else if (isPractitioner) {
                    validateAsserterCode(((PractitionerRole) resource).getCode(), PractitionerRoleInfoCodeEnum.PRACTITIONER_ROLE_CODES);
                } else {
                    PatientValidator.of().validate(resource, fhirAttributesWrapper);
                }
            }
        }
    }

    public static void validateAsserterCode(List<CodeableConcept> concepts, Set<String> codes) {
        if (!(CollectionUtils.isNotEmpty(concepts) && (concepts.stream().allMatch(concept ->
                codes.contains(concept.getText()))))) {
            throw new IhrBadRequestException(ResponseErrorMessages.MISSING_INFORMATION_TEXT_COND);
        }
    }

    private static void validateOnsetPeriodDate(Condition condition) {
        if (condition.hasOnsetPeriod()) {
            boolean onsetStartIsInvalid = condition.getOnsetPeriod().getStart() != null &&
                    null == ValidationUtils.toDate(condition.getOnsetPeriod().getStartElement().asStringValue());
            boolean onsetEndIsInvalid = condition.getOnsetPeriod().getEnd() != null &&
                    null == ValidationUtils.toDate(condition.getOnsetPeriod().getEndElement().asStringValue());
            if (onsetStartIsInvalid || onsetEndIsInvalid) {
                throw new IhrBadRequestException(ResponseErrorMessages.INVALID_PERIOD_COND);
            }
        }
    }

    private static void validateSubjectReference(Condition condition, FhirAttributesWrapper fhirAttributesWrapper) {
        if (condition.getSubject().hasReference()) {
            if (condition.getSubject().getResource() instanceof Patient) {
                Patient patient = (Patient) condition.getSubject().getResource();
                PatientValidator.of().validate(patient, fhirAttributesWrapper);
            } else {
                throw new IhrBadRequestException(ResponseErrorMessages.INVALID_PATIENT_REFERENCE);
            }
        }
    }

    public static void validateRecordKeyConditionCode(Condition condition) {
        boolean recordKeyExists = ValidationUtils.isRequiredIdentifierExists(condition.getIdentifier(), IdentifierEnum.RECORD_KEY.getValue());
        if (recordKeyExists) {
            ValidationUtils.validateIdentifier(condition.getIdentifier());
        } else if (condition.hasCode()) {
            ValidationUtils.validateCoding(condition.getCode());
        } else {
            throw new IhrBadRequestException(ResponseErrorMessages.RECORD_KEY_OR_CONDITION_CODE_REQUIRED);
        }
    }
}