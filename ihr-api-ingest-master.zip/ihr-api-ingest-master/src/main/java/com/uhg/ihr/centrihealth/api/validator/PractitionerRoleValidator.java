package com.uhg.ihr.centrihealth.api.validator;

import com.uhg.ihr.centrihealth.api.exception.IhrBadRequestException;
import com.uhg.ihr.centrihealth.api.model.FhirAttributesWrapper;
import com.uhg.ihr.centrihealth.api.util.ResponseErrorMessages;
import io.micronaut.core.util.CollectionUtils;
import lombok.NoArgsConstructor;
import org.hl7.fhir.r4.model.CodeableConcept;
import org.hl7.fhir.r4.model.PractitionerRole;
import org.hl7.fhir.r4.model.Resource;

import java.util.List;

@NoArgsConstructor(staticName = "of")
public class PractitionerRoleValidator implements IhrResourceValidator {

    @Override
    public void validate(Resource resource, FhirAttributesWrapper fhirAttributesWrapper) {
        if (resource instanceof PractitionerRole) {
            validateCode((PractitionerRole) resource);
        }
    }

    private void validateCode(final PractitionerRole practitionerRole) {
        List<CodeableConcept> codes = practitionerRole.getCode();
        if (!(CollectionUtils.isNotEmpty(codes) && codes.stream().allMatch(code ->
                PractitionerRoleInfoCodeEnum.PRACTITIONER_ROLE_CODES.contains(code.getText())))) {
            throw new IhrBadRequestException(ResponseErrorMessages.CODEABLE_EXCEPTION);
        }
    }
}
