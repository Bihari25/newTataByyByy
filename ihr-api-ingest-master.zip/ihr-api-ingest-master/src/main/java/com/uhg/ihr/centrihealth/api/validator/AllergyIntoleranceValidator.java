package com.uhg.ihr.centrihealth.api.validator;

import com.uhg.ihr.centrihealth.api.exception.IhrBadRequestException;
import com.uhg.ihr.centrihealth.api.model.FhirAttributesWrapper;
import com.uhg.ihr.centrihealth.api.util.ResponseErrorMessages;
import io.micronaut.core.util.CollectionUtils;
import lombok.NoArgsConstructor;
import org.hl7.fhir.r4.model.*;
import org.hl7.fhir.r4.model.codesystems.AllergyIntoleranceType;

import java.util.List;
import java.util.Set;

@NoArgsConstructor(staticName = "of")
public class AllergyIntoleranceValidator implements IhrReferenceValidator {

    public void validate(Resource resource, FhirAttributesWrapper fhirAttributesWrapper) {
        if (resource instanceof AllergyIntolerance) {
            validate((AllergyIntolerance) resource, null);
        }
    }

    /*
     * Key fields in AllergyIntollerance are recordKey and allergy Code with allergy type , one or the other must be present otherwise validation
     * should fail.
     */
    public void validate(final AllergyIntolerance allergyIntolerance, final FhirAttributesWrapper fhirAttributesWrapper) {
        //required - upsert action flag
        ValidationUtils.validateActionFlag(allergyIntolerance.getMeta().getTag());

        //required - last updated
        ValidationUtils.validateLastUpdatedDate(allergyIntolerance.getMeta().getLastUpdatedElement());

        //required - record key or allergy code with Type
        validateRecordKeyAllergyCode(allergyIntolerance);

        //optional - recorded date
        validateRecordedDate(allergyIntolerance);

        //optional - asserter
        validateAsserter(allergyIntolerance, fhirAttributesWrapper);

        //required - patient
        validatePatient(allergyIntolerance, fhirAttributesWrapper);

        //optional - recorder
        validateRecorder(allergyIntolerance);

        //required if reaction exists - reaction manifestation
        validateAllergyManifestation(allergyIntolerance);

        //optional - onsetPeriod date
        validateOnsetPeriodDate(allergyIntolerance);
    }

    public static void validateRecordKeyAllergyCode(AllergyIntolerance allergyIntolerance) {
        boolean recordKeyExists = ValidationUtils.isRequiredIdentifierExists(allergyIntolerance.getIdentifier(), IdentifierEnum.RECORD_KEY.getValue());
        if (recordKeyExists) {
            ValidationUtils.validateIdentifier(allergyIntolerance.getIdentifier());
        } else if (allergyIntolerance.hasCode()) {
            ValidationUtils.validateCoding(allergyIntolerance.getCode());
            validateAllergyType(allergyIntolerance);
        } else {
            throw new IhrBadRequestException(ResponseErrorMessages.RECORD_KEY_OR_ALLERGY_CODE_REQUIRED);
        }
    }

    public static void validateRecordedDate(AllergyIntolerance allergyIntolerance) {
        if (allergyIntolerance.getRecordedDate() != null
                && null == ValidationUtils.toDate(allergyIntolerance.getRecordedDateElement().asStringValue())) {
            throw new IhrBadRequestException(ResponseErrorMessages.INVALID_RECORDED_DATE_ALLERGY);
        }
    }

    public static void validateAllergyManifestation(AllergyIntolerance allergyIntolerance) {
        if (CollectionUtils.isNotEmpty(allergyIntolerance.getReaction())) {
            for (AllergyIntolerance.AllergyIntoleranceReactionComponent reactionComponent : allergyIntolerance.getReaction()) {
                if (CollectionUtils.isEmpty(reactionComponent.getManifestation())) {
                    throw new IhrBadRequestException(ResponseErrorMessages.MANIFESTATION_CODE_MISSING);
                }
                for (CodeableConcept manifestation : reactionComponent.getManifestation()) {
                    ValidationUtils.validateCoding(manifestation);
                }
            }
        }
    }


    public static void validateAsserter(AllergyIntolerance allergyIntolerance, FhirAttributesWrapper fhirAttributesWrapper) {
        if (allergyIntolerance.hasAsserter() && null != allergyIntolerance.getAsserter().getResource()) {
            Resource resource = (Resource) allergyIntolerance.getAsserter().getResource();
            boolean isRelatedPerson = resource.getResourceType().toString().equalsIgnoreCase(ResourceType.RelatedPerson.toString())
                    && CollectionUtils.isNotEmpty(((RelatedPerson) resource).getRelationship());
            boolean isPractitioner = resource.getResourceType().toString().equalsIgnoreCase(ResourceType.PractitionerRole.toString())
                    && CollectionUtils.isNotEmpty(((PractitionerRole) resource).getCode());
            boolean isPatient = resource.getResourceType().toString().equalsIgnoreCase(ResourceType.Patient.toString());

            if (!isRelatedPerson && !isPractitioner && !isPatient) {
                throw new IhrBadRequestException(ResponseErrorMessages.INVALID_ASSERTER_REFERENCE_ALLERGY);
            } else {
                if (isRelatedPerson) {
                    validateAsserterCode(((RelatedPerson) resource).getRelationship(), RelatedPersonInfoCodeEnum.RELATED_PERSON_CODES);
                } else if (isPractitioner) {
                    validateAsserterCode(((PractitionerRole) resource).getCode(), PractitionerRoleInfoCodeEnum.PRACTITIONER_ROLE_CODES);
                } else {
                    PatientValidator.of().validate(resource, fhirAttributesWrapper);
                }
            }
        }
    }

    public static void validateAsserterCode(List<CodeableConcept> concepts, Set<String> codes) {
        if (!(CollectionUtils.isNotEmpty(concepts) && (concepts.stream().allMatch(concept ->
                codes.contains(concept.getText()))))) {
            throw new IhrBadRequestException(ResponseErrorMessages.MISSING_INFORMATION_TEXT_ALLERGY);
        }
    }

    public static void validatePatient(AllergyIntolerance allergyIntolerance, FhirAttributesWrapper fhirAttributesWrapper) {
        if (allergyIntolerance.hasPatient()) {
            if (allergyIntolerance.getPatient().getResource() instanceof Patient) {
                Patient patient = (Patient) allergyIntolerance.getPatient().getResource();
                PatientValidator.of().validate(patient, fhirAttributesWrapper);
            } else {
                throw new IhrBadRequestException(ResponseErrorMessages.INVALID_PATIENT_REFERENCE);
            }
        } else {
            throw new IhrBadRequestException(ResponseErrorMessages.PATIENT_RESOURCE_MISSING_ALLERGY);
        }
    }

    public static void validateRecorder(AllergyIntolerance allergyIntolerance) {
        if (allergyIntolerance.hasRecorder()) {
            if (allergyIntolerance.getRecorder().getResource() instanceof Practitioner) {
                Practitioner practitioner = (Practitioner) allergyIntolerance.getRecorder().getResource();
                boolean isEmployeeIdExists = ValidationUtils.isRequiredIdentifierExists(practitioner.getIdentifier(), IdentifierEnum.EMPLOYEE_ID.getValue());
                if (!isEmployeeIdExists) {
                    throw new IhrBadRequestException(ResponseErrorMessages.INVALID_PRACTITIONER_REFERENCE_ID_ALLERGY);
                }
            } else {
                throw new IhrBadRequestException(ResponseErrorMessages.INVALID_PRACTITIONER_REFERENCE_ALLERGY);
            }
        }
    }

    public static void validateAllergyType(AllergyIntolerance allergyIntolerance) {
        if (allergyIntolerance.hasType()) {
            AllergyIntoleranceType.fromCode(allergyIntolerance.getType().toString().toLowerCase());
        } else {
            throw new IhrBadRequestException(ResponseErrorMessages.TYPE_AND_ALLERGY_CODE_REQUIRED);
        }
    }

    public static void validateOnsetPeriodDate(AllergyIntolerance allergyIntolerance) {
        if (null != allergyIntolerance.getOnsetPeriod()) {
            boolean onsetStartIsInvalid = allergyIntolerance.getOnsetPeriod().getStart() != null &&
                    null == ValidationUtils.toDate(allergyIntolerance.getOnsetPeriod().getStartElement().asStringValue());
            boolean onsetEndIsInvalid = allergyIntolerance.getOnsetPeriod().getEnd() != null &&
                    null == ValidationUtils.toDate(allergyIntolerance.getOnsetPeriod().getEndElement().asStringValue());
            if (onsetStartIsInvalid || onsetEndIsInvalid) {
                throw new IhrBadRequestException(ResponseErrorMessages.INVALID_PERIOD_ALLERGY);
            }
        }
    }

    @Override
    public void setReferenceIds(Set<String> resourceIds, Resource resource) {
        AllergyIntolerance statement = (AllergyIntolerance) resource;
        resourceIds.add(statement.getId());
        if (null != statement.getPatient().getResource()) {
            resourceIds.add(statement.getPatient().getReference());
        }
        if (null != statement.getRecorder().getResource()) {
            resourceIds.add(statement.getRecorder().getReference());
        }
        if (null != statement.getAsserter().getResource()) {
            resourceIds.add(statement.getAsserter().getReference());
        }
    }
}