package com.uhg.ihr.centrihealth.api.validator;

import ca.uhn.fhir.parser.DataFormatException;
import com.google.common.collect.ImmutableMap;
import com.uhg.ihr.centrihealth.api.exception.HttpResponseException;
import com.uhg.ihr.centrihealth.api.exception.IhrBadRequestException;
import com.uhg.ihr.centrihealth.api.model.FhirAttributesWrapper;
import com.uhg.ihr.centrihealth.api.model.FhirMapper;
import com.uhg.ihr.centrihealth.api.util.Constant;
import com.uhg.ihr.centrihealth.api.util.ResponseErrorMessages;
import io.micronaut.core.util.StringUtils;
import io.micronaut.http.HttpStatus;
import lombok.NoArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.hl7.fhir.instance.model.api.IBaseResource;
import org.hl7.fhir.r4.model.Bundle;
import org.hl7.fhir.r4.model.Coverage;
import org.hl7.fhir.r4.model.Patient;
import org.hl7.fhir.r4.model.Provenance;
import org.hl7.fhir.r4.model.Reference;
import org.hl7.fhir.r4.model.Resource;
import org.hl7.fhir.r4.model.ResourceType;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Map;
import java.util.Set;
import java.util.regex.Pattern;
import java.util.stream.Collectors;

@Slf4j
@NoArgsConstructor
public class FhirValidator {

    public static final Pattern RESOURCE_ID_PATTERN = Pattern.compile("[A-Za-z0-9\\-\\.]{1,64}");
    public static final Map<ResourceType, IhrResourceValidator> validatorMap = ImmutableMap.<ResourceType, IhrResourceValidator>builder()
            .put(ResourceType.Patient, PatientValidator.of())
            .put(ResourceType.Coverage, CoverageValidator.of())
            .put(ResourceType.Condition, ConditionValidator.of())
            .put(ResourceType.MedicationStatement, MedicationStatementValidator.of())
            .put(ResourceType.AllergyIntolerance, AllergyIntoleranceValidator.of())
            .put(ResourceType.Observation, ObservationValidator.of())
            .put(ResourceType.Device, HealthDeviceValidator.of())
            .put(ResourceType.CareTeam, CareTeamValidator.of())
            .put(ResourceType.Immunization, ImmunizationsValidator.of())
            .put(ResourceType.Procedure, ProcedureHistoryValidator.of())
            .put(ResourceType.Encounter, VisitHistoryValidator.of())
            .put(ResourceType.Provenance, ProvenanceValidator.of())
            .build();

    public static Bundle parseAndValidateBundle(String message) {
        IBaseResource resource;
        int count = 0;
        Provenance provenance = null;
        try {
            resource = FhirMapper.FHIR_CONTEXT.newJsonParser().parseResource(message);
            if (resource == null || resource.isEmpty()) {
                throw new IhrBadRequestException(ResponseErrorMessages.BUNDLE_ERROR);
            }
            Bundle resourceBundle = (Bundle) resource;
            isMandatoryResourceAvailable(resourceBundle);
            isRequiredResourceAvailable(resourceBundle);
            isResourceIdUnique(resourceBundle);

            if (resourceBundle.getType() == null) {
                throw new HttpResponseException(HttpStatus.UNPROCESSABLE_ENTITY.getCode(), ResponseErrorMessages.MISSING_BUNDLE_TYPE);
            } else if (!Constant.TRANSACTION.equalsIgnoreCase(resourceBundle.getType().getDisplay())) {
                throw new HttpResponseException(HttpStatus.UNPROCESSABLE_ENTITY.getCode(), ResponseErrorMessages.INVALID_BUNDLE_TYPE);
            }

            // This wrapper would hold employeeId
            FhirAttributesWrapper fhirAttributesWrapper = FhirAttributesWrapper.builder().employeeId(new HashSet<>()).build();

            for (Bundle.BundleEntryComponent entity : resourceBundle.getEntry()) {
                Resource entry = entity.getResource();
                IhrResourceValidator validator = validatorMap.get(entry.getResourceType());

                if (validator == null) {
                    log.debug("no validator for resource type {}", entry.getResourceType());
                } else {
                    validator.validate(entry, fhirAttributesWrapper);
                }
                if (entity.getResource() instanceof Provenance) {
                    provenance = (Provenance) entity.getResource();
                }
                if (FhirMapper.ALLOWED_RESOURCE_TYPES.contains(entity.getResource().getResourceType())) {
                    count++;
                }
            }
            //check the list of target for Provenance , it should have reference of allowed resource types present in request
            if (null != provenance) {
                validateTargetForProvenance(provenance, count);
            }
        } catch (HttpResponseException hrp) {
            throw new HttpResponseException(hrp.getStatusCode(), hrp.getMessage());
        } catch (Exception ibre) {
            if (ibre instanceof DataFormatException) {
                throw new IhrBadRequestException(ResponseErrorMessages.FHIR_SCHEMA_ERROR+ibre.getMessage());
            }
            throw new IhrBadRequestException(ibre.getMessage());
        }
        return (Bundle) resource;
    }

    public static void isMandatoryResourceAvailable(Bundle resourceBundle) {
        boolean patientAvailable = false;
        boolean coverageAvailable = false;
        boolean provenanceAvailable = false;
        for (Bundle.BundleEntryComponent entity : resourceBundle.getEntry()) {
            if (entity.getResource() instanceof Patient) {
                patientAvailable = true;
            }
            if (entity.getResource() instanceof Coverage) {
                coverageAvailable = true;
            }
            if (entity.getResource() instanceof Provenance) {
                provenanceAvailable = true;
            }
        }
        if (!(patientAvailable && coverageAvailable && provenanceAvailable)) {
            throw new IhrBadRequestException(ResponseErrorMessages.MANDATORY_RESOURCE);
        }
    }

    public static void isResourceIdUnique(Bundle resourceBundle) {
        Map<String, String> ids = new HashMap<>();
        for (Bundle.BundleEntryComponent entity : resourceBundle.getEntry()) {
            if (StringUtils.isNotEmpty(entity.getResource().getId())) {
                String id = ids.putIfAbsent(entity.getResource().getIdElement().getIdPart(), entity.getResource().getId());

                if (id != null) {
                    throw new IhrBadRequestException(ResponseErrorMessages.DUPLICATE_RESOURCE_IDS);
                }
            }
        }
    }

    /**
     * This method will check for the presence of ingestable resources and resource-id in the request bundle
     */
    public static void isRequiredResourceAvailable(Bundle resourceBundle) {
        boolean isResourceAvailable = false;
        if (resourceBundle.getId() == null || isInValidResourceId(resourceBundle.getId())) {
            throw new IhrBadRequestException(ResponseErrorMessages.INVALID_BUNDLE_ID);
        }

        for (Bundle.BundleEntryComponent entity : resourceBundle.getEntry()) {
            if (StringUtils.isEmpty(entity.getResource().getId())
                    || isInValidResourceId(entity.getResource().getIdElement().getIdPart())) {
                throw new IhrBadRequestException(ResponseErrorMessages.INVALID_RESOURCE_ID + " : " + entity.getResource().getResourceType());
            }
            if (FhirMapper.ALLOWED_RESOURCE_TYPES.contains(entity.getResource().getResourceType())) {
                isResourceAvailable = true;
            }

        }
        if (!isResourceAvailable) {
            throw new IhrBadRequestException(ResponseErrorMessages.INVALID_RESOURCE + FhirMapper.ALLOWED_RESOURCE_TYPES);
        }
    }

    private static void validateTargetForProvenance(final Provenance provenance, final int count) {
        if (provenance.getTarget().size() > count) {
            throw new IhrBadRequestException(ResponseErrorMessages.DUPLICATE_REFERENCES_ERROR);
        }
        if (provenance.getTarget().size() < count) {
            throw new IhrBadRequestException(ResponseErrorMessages.MISSING_RESOURCES_ERROR);
        }

        Set<String> referenceIds = provenance.getTarget().stream().map(Reference::getReference).collect(Collectors.toSet());
        if (referenceIds.size() != provenance.getTarget().size()) {
            throw new IhrBadRequestException(ResponseErrorMessages.MISSING_RESOURCES_ERROR);
        }
    }

    public static boolean isInValidResourceId(String id) {
        return !RESOURCE_ID_PATTERN.matcher(id).matches();
    }

}
