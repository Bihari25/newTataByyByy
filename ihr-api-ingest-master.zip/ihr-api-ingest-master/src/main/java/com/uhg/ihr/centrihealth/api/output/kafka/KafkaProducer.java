package com.uhg.ihr.centrihealth.api.output.kafka;

public interface KafkaProducer {

    void send(String key, String payload);
}
