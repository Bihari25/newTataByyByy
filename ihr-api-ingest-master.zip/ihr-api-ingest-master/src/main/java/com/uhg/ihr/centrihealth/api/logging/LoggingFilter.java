package com.uhg.ihr.centrihealth.api.logging;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ObjectNode;
import com.google.common.collect.ImmutableSet;
import com.optum.eis.event.model.logClass;
import com.optum.eis.event.model.outcome;
import com.optum.eis.event.model.severity;
import com.optum.eis.kraken.core.NessLog;
import com.optum.eis.kraken.core.constants.RequiredFieldsConstants;
import com.optum.eis.kraken.kafka.producers.NessKafkaProducer;
import com.uhg.ihr.centrihealth.api.exception.HttpResponseException;
import com.uhg.ihr.centrihealth.api.exception.IhrBadRequestException;
import com.uhg.ihr.centrihealth.api.exception.IhrFhirParseException;
import com.uhg.ihr.centrihealth.api.exception.IhrNotAcceptableException;
import com.uhg.ihr.centrihealth.api.exception.IhrNotFoundException;
import com.uhg.ihr.centrihealth.api.security.Encryptor;
import com.uhg.ihr.centrihealth.api.util.AppUtils;
import com.uhg.ihr.centrihealth.senzing.model.SenzingRequest;
import io.micronaut.context.annotation.Context;
import io.micronaut.context.annotation.Property;
import io.micronaut.http.HttpHeaders;
import io.micronaut.http.HttpRequest;
import io.micronaut.http.HttpStatus;
import io.micronaut.http.MutableHttpResponse;
import io.micronaut.http.annotation.Filter;
import io.micronaut.http.filter.OncePerRequestHttpServerFilter;
import io.micronaut.http.filter.ServerFilterChain;
import io.micronaut.security.authentication.AuthenticationException;
import io.reactivex.Flowable;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.apache.kafka.common.config.SslConfigs;
import org.reactivestreams.Publisher;
import org.slf4j.MDC;

import javax.inject.Inject;
import javax.validation.ConstraintViolationException;
import java.io.IOException;
import java.io.InputStream;
import java.net.InetAddress;
import java.time.Duration;
import java.time.Instant;
import java.time.ZonedDateTime;
import java.time.format.DateTimeFormatter;
import java.util.Collections;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Properties;
import java.util.Set;

@Slf4j
@Context
@Filter("/**")
public class LoggingFilter extends OncePerRequestHttpServerFilter {

    public static final String LOG_MAP = "logMap";
    public static final String LOG_NESS = "logNess";
    private static final String TOTAL = "total";
    private static final String REQUEST_ID_MDC_KEY = "requestId";
    private static final String UNKNOWN_ERROR = "Unknown Error";
    public static final String X_CONSUMER_HEADER = "X-Consumer-Username";
    public static final String OPTUM_CID_EXT = "optum-cid-ext";
    public static final String BUNDLE_ID = "bundle-id";

    private static final Map<String, String> ENVIRONMENTALS = new HashMap<>();
    private static final Set<String> ENV_VARS = ImmutableSet.of("CLUSTER", "DATACENTER", "ENVIRONMENT");
    private static final ObjectMapper MAPPER = new ObjectMapper();
    private static Properties configProps = new Properties();

    public static boolean nessEnabled;
    private static NessKafkaProducer nessKafkaProducer;
    private static boolean nessInitialized = false;
    private final static String TICKET_VAL = "truststore.ticket";
    private static final String NESS_CONFIG_PATH = "config.properties";

    public static final String API_INGEST_VERSION = "API_INGEST_VERSION";
    private static final String HTTP_STATUS = "httpStatus";
    public static final String START = "_start";
    private static Encryptor encryptor;

    private static final DateTimeFormatter FORMATTER = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss.SSS");

    @Inject
    public LoggingFilter(@Property(name = "ness.enabled") boolean nessEnabled, final Encryptor encryptor) {
        ENV_VARS.forEach(env -> ENVIRONMENTALS.put(env, System.getenv(env)));
        LoggingFilter.nessEnabled = nessEnabled;
        LoggingFilter.encryptor = encryptor;

        ENVIRONMENTALS.put(API_INGEST_VERSION, AppUtils.getBuildVersionFromManifestInfo());
        ENVIRONMENTALS.put("APPLICATION_NAME", "ihr-api-ingest");

        log.info("Api Ingest Version: {}", ENVIRONMENTALS.get(API_INGEST_VERSION));

        try {
            ENVIRONMENTALS.put("host", InetAddress.getLocalHost().getHostName());
        } catch (Exception e) {
            log.warn("unable to resolve hostname, hostname won't be present in the logs.");
        }

        if (nessEnabled) {
            log.info("NESS_ENABLED/ness.enabled is true, initializing ness publisher");

            try {
                log.info("loading ness truststore at: {}", NESS_CONFIG_PATH);
                InputStream inputStream = AppUtils.readResourceAsStream(NESS_CONFIG_PATH);
                nessKafkaProducer = getNessKafkaProducer(inputStream);
                nessInitialized = true;
            } catch (Exception ex) {
                log.error("failed loading ness config file: {}, error: {}", NESS_CONFIG_PATH, ex.getMessage());
            }
        } else {
            log.info("NESS_ENABLED/ness.enabled is false, not initializing ness publisher. Will NOT be logging to ness.");
        }
    }

    public static NessKafkaProducer getNessKafkaProducer(InputStream inputStream) throws IOException {

        configProps.load(inputStream);
        configProps.setProperty(SslConfigs.SSL_KEY_PASSWORD_CONFIG, configProps.getProperty(TICKET_VAL));
        configProps.setProperty(SslConfigs.SSL_KEYSTORE_PASSWORD_CONFIG, configProps.getProperty(TICKET_VAL));
        configProps.setProperty(SslConfigs.SSL_TRUSTSTORE_PASSWORD_CONFIG, configProps.getProperty(TICKET_VAL));
        log.info("reading config properties, applicationName {}", configProps.getProperty(RequiredFieldsConstants.APPLICATION_NAME));

        return new NessKafkaProducer.NessKafkaProducerBuilder()
                .setKafkaProperties(configProps)
                .setKafkaTopic(configProps.getProperty("topic"))
                .setKafkaProperty(SslConfigs.SSL_ENDPOINT_IDENTIFICATION_ALGORITHM_CONFIG, "https")
                .buildNessProducer();
    }

    private static String logMapToString(final HttpRequest<?> req) {
        try {
            return MAPPER.writeValueAsString(req.getAttribute(LOG_MAP).orElse(Collections.emptyMap()));
        } catch (Exception e) {
            return String.format("error parsing logMap: %s", e.getMessage());
        }
    }

    @Override
    protected Publisher<MutableHttpResponse<?>> doFilterOnce(HttpRequest<?> request, ServerFilterChain chain) {

        initializeLogMap(request);
        initializeNessLogMap(request);
        String requestId = request.getHeaders().get(OPTUM_CID_EXT);
        MDC.put(REQUEST_ID_MDC_KEY, requestId);
        return Flowable.fromPublisher(chain.proceed(request))
                .doOnNext(res -> log(request, res, null))
                .doOnError(e -> log(request, null, e))
                .doFinally(MDC::clear);
    }

    public static void setBundleId(HttpRequest<String> req) {
        if (req.getBody().isPresent() && req.getAttribute(LOG_MAP).isPresent()) {
            Map logMap = (Map) req.getAttribute(LOG_MAP).get();
            try {
                ObjectNode bundle = (ObjectNode) MAPPER.readTree(req.getBody().get());
                if (bundle.has("resourceType") && bundle.get("resourceType").asText().equals("Bundle") &&
                        bundle.has("id")) {
                    logMap.put(BUNDLE_ID, bundle.get("id").asText());
                }
            } catch (JsonProcessingException e) {
                log.error("Could not extract bundle id from body for optum-cid-ext: " + logMap.get(OPTUM_CID_EXT));
            }
        }
    }
    public static void setHeaderId(HttpRequest<String> req) {
        if (req.getBody().isPresent() && req.getAttribute(LOG_MAP).isPresent()) {
            Map logMap = (Map) req.getAttribute(LOG_MAP).get();
            HttpHeaders headers = req.getHeaders();
            for (Map.Entry<String, List<String>> header : headers.asMap().entrySet()) {
                logMap.put("request Header --> "+header.getKey(), header.getValue());
            }
        }
    }

    public void log(final HttpRequest<?> req, final MutableHttpResponse<?> res, final Throwable error) {
        if (error != null) {
            LoggingFilter.addAttribute(req, "error", error.getMessage());
            addErrorHttpStatus(req, error);
        } else {
            LoggingFilter.addAttribute(req, HTTP_STATUS, HttpStatus.ACCEPTED.getCode());
        }

        ZonedDateTime zdt = null;
        if (nessInitialized && nessEnabled) {
            Instant start = Instant.now();
            zdt = ZonedDateTime.now();
            publishNessLog(req, res, error);
            LoggingFilter.addAttribute(req, "nessMs", Duration.between(start, zdt).toMillis());
        } else {
            zdt = ZonedDateTime.now();
        }

        //these two lines should be last so we can capture the entire duration, even including ness processing
        LoggingFilter.setDuration(req, TOTAL);
        LoggingFilter.addAttribute(req, "requestEnd", zdt.format(FORMATTER));
        log.info(logMapToString(req));
    }

    public static void addErrorHttpStatus(final HttpRequest<?> req, final Throwable error) {
        if (error instanceof IhrNotFoundException) {
            LoggingFilter.addAttribute(req, HTTP_STATUS, HttpStatus.NOT_FOUND.getCode());
        } else if (error instanceof IhrBadRequestException || error instanceof ConstraintViolationException
                || error instanceof IhrFhirParseException || error instanceof HttpResponseException) {
            LoggingFilter.addAttribute(req, HTTP_STATUS, HttpStatus.BAD_REQUEST.getCode());
        } else if (error instanceof IhrNotAcceptableException) {
            LoggingFilter.addAttribute(req, HTTP_STATUS, HttpStatus.NOT_ACCEPTABLE.getCode());
        } else if (error instanceof AuthenticationException) {
            LoggingFilter.addAttribute(req, HTTP_STATUS, HttpStatus.UNAUTHORIZED.getCode());
        } else {
            LoggingFilter.addAttribute(req, HTTP_STATUS, HttpStatus.INTERNAL_SERVER_ERROR.getCode());
        }
    }

    private void initializeNessLogMap(final HttpRequest<?> request) {
        if (nessEnabled) {
            Map<String, Object> nessMap = request.getAttribute(LoggingFilter.LOG_NESS, Map.class).orElse(new HashMap<>());
            nessMap.put("receivedTime", Instant.now().toEpochMilli());
            request.setAttribute(LoggingFilter.LOG_NESS, nessMap);
        }
    }

    private void initializeLogMap(final HttpRequest<?> req) {

        Map<String, Object> logMap = new LinkedHashMap<>(ENVIRONMENTALS);
        logMap.put("requestStart", ZonedDateTime.now().format(FORMATTER));
        logMap.put(TOTAL + START, Instant.now());
        logMap.put("path", req.getPath());
        logMap.put(X_CONSUMER_HEADER, req.getHeaders().get(X_CONSUMER_HEADER));
        logMap.put("Accept", req.getHeaders().get("Accept"));
        logMap.put(OPTUM_CID_EXT, req.getHeaders().get(OPTUM_CID_EXT));
        req.setAttribute(LOG_MAP, logMap);
    }

    public static void logSenzingRequest(final HttpRequest<?> request, final SenzingRequest senzingRequest) {

        Map<String, Object> logMap = request.getAttribute(LoggingFilter.LOG_MAP, Map.class).orElse(new HashMap<>());
        try {
            logMap.put("senzingRequest", encryptor.encrypt(MAPPER.writeValueAsString(senzingRequest)));
            logMap.put("searchId", senzingRequest.getSearchId());
        } catch (Exception e) {
            log.error("Json mapper error {}", e.getMessage());
        }
    }

    @Override
    public int getOrder() { //we want this to be earlier than most filters, which default to 0
        return -1;
    }

    public void publishNessLog(final HttpRequest<?> request, final MutableHttpResponse<?> res, final Throwable error) {
        try {
            Map<String, Object> nessMap = request.getAttribute(LoggingFilter.LOG_NESS, Map.class).orElse(new HashMap<>());
            Map<String, Object> logMap = request.getAttribute(LoggingFilter.LOG_MAP, Map.class).orElse(new HashMap<>());
            Long receivedTime = (Long) nessMap.get("receivedTime");
            boolean success = false;
            String message = "";
            String correlationId = logMap.get(OPTUM_CID_EXT) != null ? logMap.get(OPTUM_CID_EXT).toString() : "";
            if (res != null && res.getStatus().getCode() == 202) {
                success = true;
                message = "HR API Ingest request processed successfully for correlation id: " + correlationId
                        + "IHR API Ingest resource accessed successfully for correlation id: " + correlationId;
            } else {
                message = "IHR API Ingest request failed for correlation id: " + correlationId
                        + "IHR API Ingest resource accessed failed for correlation id: " + correlationId;
            }

            NessLog nessLog = new NessLog.NessLogBuilder()
                    .setMsg(message)
                    .setOutcome(success ? outcome.SUCCESS : outcome.FAILURE)
                    .setStart(receivedTime)
                    .setEnd(Instant.now().toEpochMilli())
                    .setRequestRequest(request.getPath())
                    .setRequestUserAgent(request.getRemoteAddress() == null ? "" : request.getRemoteAddress().getHostName())
                    .setRequestOptumCIDExt(logMap.get(OPTUM_CID_EXT) == null ? "" : logMap.get(OPTUM_CID_EXT).toString())
                    .setRequestMethod(request.getMethod().name())
                    .setRequestIn(request.getContentLength())
                    .setRequestOut(success ? res.getBody().toString().length() : 0)
                    .setAct(request.getMethod().name())
                    .setLogClass(logClass.SECURITY_SUCCESS)
                    .setReason(getReason(res, error))
                    .setSeverity(severity.INFO)
                    .setDeviceVendor(configProps.getProperty(RequiredFieldsConstants.DEVICE_VENDOR))
                    .setDeviceProduct(configProps.getProperty(RequiredFieldsConstants.DEVICE_PRODUCT))
                    .setDeviceVersion(ENVIRONMENTALS.get(API_INGEST_VERSION))
                    .setApplicationName(configProps.getProperty(RequiredFieldsConstants.APPLICATION_NAME))
                    .setApplicationAskId(configProps.getProperty(RequiredFieldsConstants.APPLICATION_ASK_ID))
                    .buildLog();

            log.debug("Published logEvent: {}", nessLog.getLog());
            nessKafkaProducer.publishNessLogs(nessLog);
        } catch (Exception ex) {
            log.warn("publish to ness failed {}", ex.getMessage());
        }
    }

    private String getReason(final MutableHttpResponse<?> res, final Throwable error) {
        if (error != null && StringUtils.isNotEmpty(error.getMessage())) {
            return error.getMessage();
        } else if (StringUtils.isNotEmpty(res.getStatus())) {
            return res.getStatus().getReason();
        } else {
            return UNKNOWN_ERROR;
        }
    }

    @SuppressWarnings("unchecked")
    public static void addAttribute(final HttpRequest<?> request, final String key, final Object value) {
        Map<String, Object> map = request.getAttribute(LoggingFilter.LOG_MAP, Map.class).orElse(new HashMap<>());
        map.put(key, value);
        request.setAttribute(LoggingFilter.LOG_MAP, map);
    }

    public static void logStart(final HttpRequest<?> request, final String method) {
        addAttribute(request, method + START, Instant.now());
    }

    @SuppressWarnings("unchecked")
    public static void logSuccess(final HttpRequest<?> request, final String method) {
        setDuration(request, method);
        Map<String, Object> map = request.getAttribute(LoggingFilter.LOG_MAP, Map.class).orElse(new HashMap<>());
        map.put(method + "Status", "success");
        request.setAttribute(LoggingFilter.LOG_MAP, map);
    }

    @SuppressWarnings("unchecked")
    public static void logFail(final HttpRequest<?> request, final String method, final String reason) {
        setDuration(request, method);
        Map<String, Object> map = request.getAttribute(LoggingFilter.LOG_MAP, Map.class).orElse(new HashMap<>());
        map.put(method + "Status", "failure");
        map.put(method + "Reason", reason);
        request.setAttribute(LoggingFilter.LOG_MAP, map);
    }

    @SuppressWarnings("unchecked")
    public static void setDuration(final HttpRequest<?> request, final String method) {
        Map<String, Object> map = request.getAttribute(LoggingFilter.LOG_MAP, Map.class).orElse(new HashMap<>());
        Instant start = (Instant) map.get(method + START);
        if (start == null) {
            log.error("tried to get start time for {} and failed", method + START);
            map.put("logError", "tried to get start time for " + method + "_start and failed");
        } else {
            map.put(method + "Ms", Duration.between(start, Instant.now()).toMillis());
            map.remove(method + START);
        }
        request.setAttribute(LoggingFilter.LOG_MAP, map);
    }

}