package com.uhg.ihr.centrihealth.api.exception;

import lombok.RequiredArgsConstructor;

@RequiredArgsConstructor
public class IhrFhirParseException  extends RuntimeException{
    public IhrFhirParseException(String message) {
        super(message);
    }

    public IhrFhirParseException(String unable_to_parse_bundle, String message) {
        super(message);
    }
}
