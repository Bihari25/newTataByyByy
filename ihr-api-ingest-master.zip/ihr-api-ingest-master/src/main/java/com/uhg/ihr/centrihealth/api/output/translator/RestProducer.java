package com.uhg.ihr.centrihealth.api.output.translator;

import io.micronaut.context.annotation.Requirements;
import io.micronaut.context.annotation.Requires;
import io.micronaut.http.HttpHeaders;
import io.micronaut.http.HttpResponse;
import io.micronaut.http.MediaType;
import io.micronaut.http.annotation.Body;
import io.micronaut.http.annotation.Header;
import io.micronaut.http.annotation.Post;
import io.micronaut.http.client.annotation.Client;
import io.micronaut.retry.annotation.Retryable;
import io.reactivex.Maybe;

import javax.validation.constraints.NotNull;

@Client(id = "translator")
@Retryable
@Requirements({
        @Requires(property = "micronaut.http.services.translator.enabled", value = "true"),
})
public interface RestProducer extends OutputProducer {

    //TODO: Update the POST resource to point to the correct resource
    @Post("/translate")
    @Header(name = HttpHeaders.CONTENT_TYPE, value = MediaType.APPLICATION_JSON)
    Maybe<HttpResponse<String>> sendPayload(final @Header("optum-cid-ext") String optumCidExt,
                                            final @Body @NotNull String payload);
}
