package com.uhg.ihr.centrihealth.api.util;

import java.nio.ByteBuffer;
import java.util.Arrays;

//  Z85 codec, taken from 0MQ RFC project, implements RFC32 Z85 encoding
public class Z85 {
    //  Maps base 256 to base 85
    private static final String encoder = "0123456789" + "abcdefghij" + "klmnopqrst" + "uvwxyzABCD" + "EFGHIJKLMN"
            + "OPQRSTUVWX" + "YZ.-:+=^!/" + "*?&<>()[]{" + "}@%$#";
    //  Maps base 85 to base 256
    //  We chop off lower 32 and higher 128 ranges
    private static final byte[] decoder = {0x00, 0x44, 0x00, 0x54, 0x53, 0x52, 0x48, 0x00, 0x4B, 0x4C, 0x46, 0x41,
            0x00, 0x3F, 0x3E, 0x45, 0x00, 0x01, 0x02, 0x03, 0x04, 0x05, 0x06, 0x07, 0x08, 0x09, 0x40, 0x00, 0x49, 0x42,
            0x4A, 0x47, 0x51, 0x24, 0x25, 0x26, 0x27, 0x28, 0x29, 0x2A, 0x2B, 0x2C, 0x2D, 0x2E, 0x2F, 0x30, 0x31, 0x32,
            0x33, 0x34, 0x35, 0x36, 0x37, 0x38, 0x39, 0x3A, 0x3B, 0x3C, 0x3D, 0x4D, 0x00, 0x4E, 0x43, 0x00, 0x00, 0x0A,
            0x0B, 0x0C, 0x0D, 0x0E, 0x0F, 0x10, 0x11, 0x12, 0x13, 0x14, 0x15, 0x16, 0x17, 0x18, 0x19, 0x1A, 0x1B, 0x1C,
            0x1D, 0x1E, 0x1F, 0x20, 0x21, 0x22, 0x23, 0x4F, 0x00, 0x50, 0x00, 0x00};

    private Z85() {
    }

    //  --------------------------------------------------------------------------
    //  Encode a binary frame as a string; destination string MUST be at least
    //  size * 5 / 4 bytes long plus 1 byte for the null terminator. Returns
    //  dest. Size must be a multiple of 4.
    //  Returns NULL and sets errno = EINVAL for invalid input.

    public static String encode(byte[] data, int size) {
        byte[] paddedData;
        int padding = 0;

        if (size % 4 != 0) {
            //Pad byte array with null values
            byte[] nullValue = "\0".getBytes();
            padding = 4 - size % 4;
            paddedData = Arrays.copyOf(data, padding + size);
            for (int i = size; i < paddedData.length; ++i) {
                paddedData[i] = nullValue[0];
                ++size;
            }
        } else {
            paddedData = data;
        }

        StringBuilder builder = new StringBuilder();
        int byteNbr = 0;
        long value = 0;
        while (byteNbr < size) {
            //  Accumulate value in base 256 (binary)
            int d = paddedData[byteNbr++] & 0xff;
            value = value * 256 + d;
            if (byteNbr % 4 == 0) {
                //  Output value in base 85
                int divisor = 85 * 85 * 85 * 85;
                while (divisor != 0) {
                    int index = (int) (value / divisor % 85);
                    builder.append(encoder.charAt(index));
                    divisor /= 85;
                }
                value = 0;
            }
        }
        assert (builder.length() == size * 5 / 4);

        if (padding > 0) {
            //Remove padding as padded characters are null data
            return builder.substring(0, builder.length() - padding);
        } else {
            return builder.toString();
        }
    }

    //  --------------------------------------------------------------------------
    //  Decode an encoded string into a binary frame; dest must be at least
    //  strlen (string) * 4 / 5 bytes long. Returns dest. strlen (string)
    //  must be a multiple of 5.
    //  Returns NULL and sets errno = EINVAL for invalid input.

    public static byte[] decode(String string) {
        if (string.length() % 5 == 1) {
            throw new RuntimeException("string to decode is an illegal length");
        }

        // Z85 encodes four bytes of input into five, padding out input with zeros until
        // it's a multiple of four.  To make sure the intermediate buffer is big enough, it must
        // be four fifths of the smallest multiple of five greater than or equal to stringLen.
        // `padding` is the difference between `stringLen` and the next multiple of five.
        int stringLen = string.length();
        int padding = stringLen % 5 == 0 ? 0 : 5 - stringLen % 5;
        int bufLen = (stringLen + padding) * 4 / 5;
        ByteBuffer buf = ByteBuffer.allocate(bufLen);

        int byteNbr = 0;
        int charNbr = 0;
        long value = 0;
        while (charNbr < stringLen) {
            // Check that the character is valid.  '0' is the only character
            // that validly decodes to 0, which is at index 16.  All other
            // invalid characters will fail with an index out of bounds exception.
            int decoderIndex = string.charAt(charNbr) - 32;
            byte decodedChar = decoder[decoderIndex];
            if (decodedChar == 0 && decoderIndex != 16) {
                throw new RuntimeException("Illegal character at index: " + charNbr);
            }
            charNbr += 1;
            // Accumulate value in base 85
            value = value * 85 + decodedChar;
            if (charNbr % 5 == 0) {
                //  Output value in base 256
                int divisor = 256 * 256 * 256;
                while (divisor != 0) {
                    buf.put(byteNbr++, (byte) ((value / divisor) % 256));
                    divisor /= 256;
                }
                value = 0;
            } else if (charNbr == stringLen) {
                //Process remaining characters
                while (charNbr % 5 != 0) {
                    value = value * 85 + 84;
                    charNbr++;
                }
                int divisor = 256 * 256 * 256;
                while (divisor != 0) {
                    buf.put(byteNbr++, (byte) ((value / divisor) % 256));
                    divisor /= 256;
                }
                value = 0;
            }
        }
        byte[] decodedBytes = buf.array();

        // A `padding` number of bytes can be removed, as those are known to not contain
        // valid data.
        decodedBytes = Arrays.copyOf(decodedBytes, decodedBytes.length - padding);

        //Remove null values
        byte[] nullValue = "\0".getBytes();
        int size;
        while ((size = decodedBytes.length) > 0 && decodedBytes[size - 1] == nullValue[0]) {
            decodedBytes = Arrays.copyOf(decodedBytes, size - 1);
        }

        return decodedBytes;
    }
}