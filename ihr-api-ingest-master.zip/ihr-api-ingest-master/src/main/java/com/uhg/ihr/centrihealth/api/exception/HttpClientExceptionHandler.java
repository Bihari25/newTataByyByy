package com.uhg.ihr.centrihealth.api.exception;

import io.micronaut.context.annotation.Requires;
import io.micronaut.http.HttpRequest;
import io.micronaut.http.HttpResponse;
import io.micronaut.http.annotation.Produces;
import io.micronaut.http.client.exceptions.HttpClientException;
import io.micronaut.http.hateoas.JsonError;
import io.micronaut.http.hateoas.Link;
import io.micronaut.http.server.exceptions.ExceptionHandler;
import lombok.extern.slf4j.Slf4j;

import javax.inject.Singleton;

@Slf4j
@Produces
@Singleton
@Requires(classes = {HttpClientException.class, ExceptionHandler.class})
public class HttpClientExceptionHandler implements ExceptionHandler<HttpClientException, HttpResponse> {

    @Override
    public HttpResponse handle(HttpRequest request, HttpClientException exception) {
        log.error("there was an error handling this request {}", exception.getMessage());
        return HttpResponse.serverError(new JsonError("there was an error handling this request")
                .link(Link.SELF, Link.of(request.getUri())));
    }
}
