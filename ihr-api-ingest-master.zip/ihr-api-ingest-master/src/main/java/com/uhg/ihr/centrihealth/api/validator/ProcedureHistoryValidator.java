package com.uhg.ihr.centrihealth.api.validator;

import com.uhg.ihr.centrihealth.api.model.FhirAttributesWrapper;
import lombok.NoArgsConstructor;
import org.hl7.fhir.r4.model.Procedure;
import org.hl7.fhir.r4.model.Resource;

@NoArgsConstructor(staticName = "of")
public class ProcedureHistoryValidator implements IhrResourceValidator {

    public void validate(Resource resource, FhirAttributesWrapper fhirAttributesWrapper) {
        if (resource instanceof Procedure) {
            validate((Procedure) resource, null);
        }
    }

    private void validate(final Procedure procedure, final FhirAttributesWrapper fhirAttributesWrapper) {

        //validate action flag
        ValidationUtils.validateActionFlag(procedure.getMeta().getTag());
        //validate last updated date
        ValidationUtils.validateLastUpdatedDate(procedure.getMeta().getLastUpdatedElement());
        // validate patient Note
        boolean noteExists = procedure.getNote().size() > 0;
        // validate Identifiers (record key and RefId)
        ValidationUtils.validateIdentifier(procedure.getIdentifier(), noteExists);
        //validate notes
        ValidationUtils.isValidNote(procedure.getNote());
    }
}
