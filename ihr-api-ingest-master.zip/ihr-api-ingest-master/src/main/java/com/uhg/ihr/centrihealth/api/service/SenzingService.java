package com.uhg.ihr.centrihealth.api.service;

import com.google.common.collect.ImmutableMap;
import com.google.common.collect.Iterables;
import com.uhg.ihr.centrihealth.api.client.B50SenzingClient;
import com.uhg.ihr.centrihealth.api.exception.IhrNotFoundException;
import com.uhg.ihr.centrihealth.senzing.model.SenzingLookup;
import com.uhg.ihr.centrihealth.senzing.model.SenzingRequest;
import io.micronaut.core.util.CollectionUtils;
import io.micronaut.http.client.exceptions.HttpClientResponseException;
import io.reactivex.Maybe;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections4.MapUtils;
import org.apache.commons.lang3.StringUtils;

import javax.inject.Inject;
import javax.inject.Singleton;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 * SenzingService class used to consume senzing api call to get the ihr id information.
 *
 * @author ihr extract engineering team.
 */
@Slf4j
@Singleton
public class SenzingService {

    protected static final String CHID_KEY = "GLOBAL_ACTOR_ID";
    private static final String RECORD_ID = "recordId";
    private static final String FORCE_MINIMAL = "minimal";

    @Inject
    private B50SenzingClient b50SenzingClient;

    /**
     * Method to search and filter for ihrId from api response.
     *
     * @param senzingApiResponse
     * @param correlationId
     * @return String
     */
    @SuppressWarnings("unchecked")
    public static String searchIhrId(final Map<String, Object> senzingApiResponse, final String correlationId) {

        /* Navigate through JSON response tree to cherry pick the values.*/
        Map<String, Object> dataJson = (Map<String, Object>) senzingApiResponse.get(SenzingLookup.DATA);
        List<Map<String, Object>> searchResults = validateSenzingResponse(dataJson);

        /* Validate if filtered IhrIds are available at indicator level = 1 or else indicator level = 2 as a fallback. */
        ImmutableMap<String, List<String>> filteredResults = filterResults(searchResults);

        /* Log all search results information.*/
        log.info("correlationId '{}' senzing call found possible {} identifiers: {}",
                correlationId, CollectionUtils.isNotEmpty(searchResults) ? searchResults.size() : 0, filteredResults.get(SenzingLookup.LOG_RESULTS));

        return getIdFromList(filteredResults.get(SenzingLookup.FILTERED_IHR_IDS));
    }

    /**
     * Method get ihr id from list.
     *
     * @param ihrIds
     * @return String
     */
    public static String getIdFromList(List<String> ihrIds) {
        if (CollectionUtils.isEmpty(ihrIds)) {
            throw new IhrNotFoundException("Unable to find ihr identifier (IhrId) from senzing response for given member");
        }

        if (ihrIds.size() > 1) {
            throw new IhrNotFoundException("Found multiple ihr identifiers: " + ihrIds);
        }

        return Iterables.getOnlyElement(ihrIds);
    }

    /**
     * Method to get all logs from results.
     *
     * @param result
     * @return String
     */
    @SuppressWarnings("unchecked")
    public static String getLogDataFromResult(Map<String, Object> result) {
        try {
            return String.format("%s:%s:%s",
                    getOwnerChid(result),
                    result.get(SenzingLookup.MATCH_LEVEL),
                    result.get("matchKey"));
        } catch (Exception e) {
            log.warn("unable to parse log entry for senzing response");
            return "unknown";
        }
    }

    /**
     * Method to filter results from senzing response for IhrIds and log statements.
     *
     * @param searchResults
     * @return ImmutableMap
     */
    private static ImmutableMap<String, List<String>> filterResults(List<Map<String, Object>> searchResults) {

        List<String> foundIhrIds = new ArrayList<>();
        List<String> logResults = new ArrayList<>();

        /* Iterate over each search results data to get match level indicator and owner chid value.
         log : ACTCHID, MatchLevel, matchkey (matchKey -> +PNAME+DOB+SUBSCRIBER_ID) */
        for (Map<String, Object> resultData : searchResults) {

            /* Cherry pick and validate match level indicator. */
            Integer matchLevelIndicator = (Integer) resultData.get(SenzingLookup.MATCH_LEVEL);
            if (matchLevelIndicator == SenzingLookup.INDICATOR_LEVEL_1) {
                /* Further filter for owner chid value which will be iHr id.*/
                String chid = getOwnerChid(resultData);

                // Collect searched ihrIds.
                if (StringUtils.isNotBlank(chid)) {
                    foundIhrIds.add(chid);
                }
            }

            logResults.add(getLogDataFromResult(resultData));
        }

        /* Hold the result filtered IhrIds and Log results. */
        return ImmutableMap.of(SenzingLookup.LOG_RESULTS, logResults, SenzingLookup.FILTERED_IHR_IDS, foundIhrIds);
    }

    public static String getOwnerChid(Map<String, Object> resultData) {
        List<Map<String, String>> records = (List<Map<String, String>>) resultData.get(SenzingLookup.RECORDS);
        String chid = CollectionUtils.isEmpty(records) ? ""
                : records.stream().filter(record -> record.get(RECORD_ID) != null).findFirst().orElse(new HashMap<>()).get(RECORD_ID);
        if (StringUtils.isEmpty(chid)) {
            List<String> identifierData = (List<String>) resultData.get(SenzingLookup.IDENTIFIER_DATA);
            chid = CollectionUtils.isEmpty(identifierData) ? ""
                    : StringUtils.substringAfter(identifierData.stream()
                    .filter(data -> data.startsWith(CHID_KEY)).findFirst().orElse(""), ":").trim();
        }
        return chid;
    }

    /**
     * Method to validate senzing response.     *
     * @param senzingDataJson
     * @return List<Map<String, Object>>
     */
    @SuppressWarnings("unchecked")
    private static List<Map<String, Object>> validateSenzingResponse(Map<String, Object> senzingDataJson) {
        /* Validate senzing response is empty or not. */
        if (MapUtils.isNotEmpty(senzingDataJson)) {
            List<Map<String, Object>> searchResults = (List<Map<String, Object>>) senzingDataJson.get(SenzingLookup.RESULTS);

            /* If search results in senzing response is empty throw 404 exception. */
            if (CollectionUtils.isEmpty(searchResults)) {
                throw new IhrNotFoundException("Unable to find ihr identifier (IhrId) because senzing response search results are empty");
            } else {
                return searchResults;
            }
        } else {
            throw new IhrNotFoundException("Unable to find ihr identifier (IhrId) because senzing response data is empty");
        }
    }

    /**
     * Method to fetch ihr id data from b50 senzing end point.
     *
     * @param token          the JWT token for calling senzing
     * @param senzingRequest a senzingRequest object
     * @param correlationId
     * @return Maybe
     */
    public Maybe<String> b50filterIhrId(final String token, final SenzingRequest senzingRequest, final String correlationId) {
        /* Collect and hold the collection name and api consumer to compute chid keys. */
        return b50SenzingClient.fetchEntities(token, correlationId, FORCE_MINIMAL, senzingRequest)
                .doOnError(ex -> {
                            if (ex instanceof HttpClientResponseException) {
                                HttpClientResponseException hcre = (HttpClientResponseException) ex;
                                log.error("error with the b50 senzing service. status code: {}, message: {}", hcre.getStatus(), ex.getMessage());
                            } else {
                                log.error("could not hit the b50 senzing service {}", ex.getMessage());
                            }
                        }
                )
                .defaultIfEmpty(new LinkedHashMap<>())
                .map(response -> searchIhrId(response, correlationId));
    }

}


