package com.uhg.ihr.centrihealth.api.validator;

import org.hl7.fhir.r4.model.Resource;

import java.util.Set;

public interface IhrReferenceValidator extends IhrResourceValidator {

    void setReferenceIds(Set<String> resourceIds, Resource resource);

}
