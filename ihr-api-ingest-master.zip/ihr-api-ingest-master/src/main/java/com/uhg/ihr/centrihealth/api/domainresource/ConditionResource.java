package com.uhg.ihr.centrihealth.api.domainresource;

import lombok.Getter;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.hl7.fhir.r4.model.Annotation;
import org.hl7.fhir.r4.model.Condition;
import org.hl7.fhir.r4.model.Identifier;

import java.util.List;

@Slf4j
@Getter
@RequiredArgsConstructor(staticName = "of")
public class ConditionResource implements IhrResource<Condition> {

    final Condition condition;

    @Override
    public Condition getDomainResource() {
        return condition;
    }

    @Override
    public List<Annotation> getNote() {
        return condition.getNote();
    }

    @Override
    public Condition setNote(List<Annotation> notes) {
        return condition.setNote(notes);
    }

    @Override
    public List<Identifier> getIdentifiers() {
        return condition.getIdentifier();
    }

    @Override
    public Condition addIdentifier(Identifier identifier) {
        return condition.addIdentifier(identifier);
    }
}
