package com.uhg.ihr.centrihealth.api.validator;

import com.uhg.ihr.centrihealth.api.exception.IhrBadRequestException;
import lombok.NoArgsConstructor;
import org.hl7.fhir.instance.model.api.IBaseResource;
import org.hl7.fhir.r4.model.CareTeam;
import org.hl7.fhir.r4.model.Organization;

@NoArgsConstructor
public class ServiceFacilityProviderValidator {
    private static final String INVALID_PATIENT_NOTE = "Can't process patient note";
    public static boolean isServiceFacilityProvider(CareTeam sfp) {
        boolean isSFP = false;
        for (CareTeam.CareTeamParticipantComponent participant : sfp.getParticipant()) {
            IBaseResource resource = participant.getMember().getResource();
            if (resource instanceof Organization) {
                Organization organization = (Organization) resource;
                if (organization.getIdElement() == resource.getIdElement()) {
                    //validate action flag
                    ValidationUtils.validateActionFlag(organization.getMeta().getTag());
                    //validate last updated date
                    ValidationUtils.validateLastUpdatedDate(organization.getMeta().getLastUpdatedElement());
                    // validate patient note
                    if (!sfp.getNote().isEmpty() || sfp.getNote() != null && sfp.getNote().size() > 0) {
                        throw new IhrBadRequestException(INVALID_PATIENT_NOTE);
                    }
                    // validate Identifiers (record key and RefId)
                    boolean noteExists = sfp.getNote().size() > 0;
                    ValidationUtils.validateIdentifier(organization.getIdentifier(), noteExists);
                    isSFP = true;
                }
            }
        }
        return isSFP;
    }
}
