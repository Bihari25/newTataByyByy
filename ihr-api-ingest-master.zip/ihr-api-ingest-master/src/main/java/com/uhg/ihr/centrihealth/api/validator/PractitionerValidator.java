package com.uhg.ihr.centrihealth.api.validator;

import com.google.common.collect.ImmutableSet;
import com.uhg.ihr.centrihealth.api.exception.IhrBadRequestException;
import com.uhg.ihr.centrihealth.api.model.FhirAttributesWrapper;
import com.uhg.ihr.centrihealth.api.util.Constant;
import com.uhg.ihr.centrihealth.api.util.ResponseErrorMessages;
import lombok.NoArgsConstructor;
import org.hl7.fhir.r4.model.Identifier;
import org.hl7.fhir.r4.model.Practitioner;
import org.hl7.fhir.r4.model.Resource;

import java.util.List;
import java.util.Set;

@NoArgsConstructor(staticName = "of")
public class PractitionerValidator implements IhrResourceValidator {

    public static final Set<String> IDENTIFIERS = ImmutableSet.of(Constant.employeeId, Constant.NPI);

    @Override
    public void validate(Resource resource, FhirAttributesWrapper fhirAttributesWrapper) {
        if (resource instanceof Practitioner) {
            validateIdentifier((Practitioner) resource);
        }
    }

    /**
     * To check either employeeId or NPI should be available for Practitioner
     * @param practitioner
     */
    private void validateIdentifier(final Practitioner practitioner) {

        boolean identifierExists = false;
        List<Identifier> identifiers = practitioner.getIdentifier();

        for (String text : IDENTIFIERS) {
            if (ValidationUtils.isRequiredIdentifierExists(identifiers, text)) {
                identifierExists = true;
            }
        }
        if (!identifierExists) {
            throw new IhrBadRequestException(ResponseErrorMessages.IDENTIFIER_EXCEPTION);
        }
    }

}
