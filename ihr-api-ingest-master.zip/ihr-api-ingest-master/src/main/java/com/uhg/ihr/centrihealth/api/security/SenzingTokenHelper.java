package com.uhg.ihr.centrihealth.api.security;

import com.auth0.jwt.JWT;
import com.auth0.jwt.algorithms.Algorithm;
import com.google.common.collect.ImmutableMap;
import lombok.extern.slf4j.Slf4j;

import java.nio.charset.StandardCharsets;
import java.util.Date;
import java.util.List;
import java.util.Map;

/**
 * SenzingTokenHelper class used to generate senzing token during runtime.
 *
 * @author ihr extract engineering team.
 * @CopyRight (C) All rights reserved to UHG Inc. It's Illegal to reproduce this code.
 */
@Slf4j
public class SenzingTokenHelper {
    private static final String TOKEN_TYPE = "JWT";
    private static final String HEADER_TYPE = "typ";
    private static final String DEFAULT_AUD = "secure-app";
    private static final String DEFAULT_ISS = "ihr-senzing-api-gateway";
    private static final String DEFAULT_SUBJECT = "ihr-api";
    private static final String TOKEN_BEARER = "Bearer ";
    public static final Map<String, Object> HEADER_CLAIMS = ImmutableMap.of(HEADER_TYPE, TOKEN_TYPE);

    /**
     * Method to generate senzing token.
     *
     * @param sub
     * @param iss
     * @param aud
     * @param iat
     * @param duration
     * @param roles
     * @param signingKey
     * @return String
     */
    public static String generateToken(String sub, String iss, String aud, Date iat, long duration,
                                       List<String> roles, String signingKey) {

        return TOKEN_BEARER.concat(JWT.create()
                .withSubject(sub != null ? sub : DEFAULT_SUBJECT)
                .withIssuer(iss != null ? iss : DEFAULT_ISS)
                .withHeader(HEADER_CLAIMS)
                .withAudience(aud != null ? aud : DEFAULT_AUD)
                .withClaim("rol", roles)
                .withIssuedAt(iat)
                .withExpiresAt(new Date(iat.getTime() + duration))
                .sign(Algorithm.HMAC512(signingKey.getBytes(StandardCharsets.US_ASCII))));
    }

}