package com.uhg.ihr.centrihealth.api.validator;

import com.google.common.collect.ImmutableMap;
import com.uhg.ihr.centrihealth.api.exception.IhrBadRequestException;
import com.uhg.ihr.centrihealth.api.model.FhirAttributesWrapper;
import com.uhg.ihr.centrihealth.api.model.FhirMapper;
import com.uhg.ihr.centrihealth.api.util.ResponseErrorMessages;
import io.micronaut.core.util.CollectionUtils;
import io.micronaut.core.util.StringUtils;
import lombok.NoArgsConstructor;
import org.hl7.fhir.r4.model.Coding;
import org.hl7.fhir.r4.model.Provenance;
import org.hl7.fhir.r4.model.Reference;
import org.hl7.fhir.r4.model.Resource;
import org.hl7.fhir.r4.model.ResourceType;
import org.hl7.fhir.r4.model.codesystems.ProvenanceAgentType;

import java.util.List;
import java.util.Map;
import java.util.Set;

@NoArgsConstructor(staticName = "of")
public class ProvenanceValidator implements IhrReferenceValidator {

    public static final String AGENT_TYPE_SYSTEM_URL = "http://terminology.hl7.org/CodeSystem/provenance-participant-type";

    //TODO: As per FHIR , Device is to be supported , not added since Device is yet to be implemented
    public static final Map<ResourceType, IhrResourceValidator> AGENT_WHO_RESOURCE_MAPPERS = ImmutableMap.<ResourceType, IhrResourceValidator>builder()
            .put(ResourceType.Patient, PatientValidator.of())
            .put(ResourceType.RelatedPerson, RelatedPersonValidator.of())
            .put(ResourceType.Practitioner, PractitionerValidator.of())
            .put(ResourceType.Organization, OrganizationValidator.of())
            .build();

    private static final Set<ResourceType> AGENT_WHO_MAPPABLE_TYPES = AGENT_WHO_RESOURCE_MAPPERS.keySet();

    @Override
    public void validate(Resource resource, FhirAttributesWrapper fhirAttributesWrapper) {
        if (resource instanceof Provenance) {
            validate((Provenance) resource, null);
        }
    }

    private void validate(final Provenance provenance, final FhirAttributesWrapper fhirAttributesWrapper) {
        //validate Target
        validateTarget(provenance);
        //validate recorded
        validateRecorded(provenance);
        //validate agent
        validateAgent(provenance, fhirAttributesWrapper);
    }

    private void validateRecorded(Provenance provenance) {
        if (null == provenance.getRecorded()) {
            throw new IhrBadRequestException(ResponseErrorMessages.RECORDED_REQUIRED);
        }
    }

    private void validateAgent(final Provenance provenance, FhirAttributesWrapper fhirAttributesWrapper) {
        if (CollectionUtils.isEmpty(provenance.getAgent())) {
            throw new IhrBadRequestException(ResponseErrorMessages.AGENT_REQUIRED);
        } else if (CollectionUtils.isNotEmpty(provenance.getAgent())) {
            validateAgentType(provenance.getAgent());
            validateAgentWho(provenance.getAgent(), fhirAttributesWrapper);
        }
    }

    private void validateAgentType(List<Provenance.ProvenanceAgentComponent> agents) {
        for (Provenance.ProvenanceAgentComponent agent : agents) {
            if (null != agent.getType()) {
                List<Coding> codings = agent.getType().getCoding();
                if (codings.size() > 0) {
                    if (!(codings.stream().allMatch(coding ->
                            StringUtils.isNotEmpty(coding.getSystem()) && coding.getSystem().equalsIgnoreCase(AGENT_TYPE_SYSTEM_URL)
                                    && StringUtils.isNotEmpty(coding.getCode()) && null != ProvenanceAgentType.fromCode(coding.getCode())
                                    && StringUtils.isNotEmpty(coding.getDisplay()) && coding.getCode().equals(coding.getDisplay().toLowerCase())
                                    && StringUtils.capitalize(coding.getCode()).equals(coding.getDisplay())))) {
                        throw new IhrBadRequestException(ResponseErrorMessages.AGENT_TYPE_EXCEPTION);
                    }
                }
            }
        }
    }

    private void validateAgentWho(final List<Provenance.ProvenanceAgentComponent> agents, FhirAttributesWrapper fhirAttributesWrapper) {
        for (Provenance.ProvenanceAgentComponent agent : agents) {
            if (null != agent.getWho() && null != agent.getWho().getResource()) {
                validateWhoReference(agent.getWho());
                IhrResourceValidator validator = AGENT_WHO_RESOURCE_MAPPERS.get(ResourceType.valueOf(
                        agent.getWho().getReferenceElement().getResourceType()));
                if (null == validator) {
                    throw new IhrBadRequestException(ResponseErrorMessages.AGENT_WHO_REFERENCE_EXCEPTION);
                } else {
                    validator.validate((Resource) agent.getWho().getResource(), fhirAttributesWrapper);
                }
            } else {
                throw new IhrBadRequestException(ResponseErrorMessages.AGENT_WHO_REFERENCE_EXCEPTION);
            }
        }
    }

    private void validateWhoReference(Reference reference) {
        if (!(null != reference && null != reference.getReference()
                && null != reference.getResource().getIdElement()
                && StringUtils.isNotEmpty(reference.getReferenceElement().getResourceType())
                && AGENT_WHO_MAPPABLE_TYPES.contains
                (ResourceType.valueOf(reference.getReferenceElement().getResourceType())))) {
            throw new IhrBadRequestException(ResponseErrorMessages.INVALID_AGENT_WHO_REFERENCE);
        }
    }

    //The resources supported is ALLOWED_RESOURCE_TYPES, this is incremental
    private void validateTarget(Provenance provenance) {
        if (CollectionUtils.isNotEmpty(provenance.getTarget())) {
            if (!(provenance.getTarget().stream().allMatch(t -> null != t.getResource()
                    && null != t.getResource().getIdElement()
                    && StringUtils.isNotEmpty(t.getReferenceElement().getResourceType())
                    && FhirMapper.ALLOWED_RESOURCE_TYPES.contains
                    (ResourceType.valueOf(t.getReferenceElement().getResourceType()))))) {
                throw new IhrBadRequestException(ResponseErrorMessages.INVALID_TARGET_REFERENCE);
            }
        }
        else {
            throw new IhrBadRequestException(ResponseErrorMessages.TARGET_REQUIRED);
        }
    }

    @Override
    public void setReferenceIds(Set<String> resourceIds, Resource resource) {
        if (resource instanceof Provenance) {
            Provenance provenance = (Provenance) resource;
            resourceIds.add(resource.getId());
            if (CollectionUtils.isNotEmpty(provenance.getTarget()) && provenance.getTarget().size() > 0) {
                for (Reference reference : provenance.getTarget()) {
                    resourceIds.add(reference.getReference());
                }
            }
            if (CollectionUtils.isNotEmpty(provenance.getAgent()) && provenance.getAgent().size() > 0) {
                List<Provenance.ProvenanceAgentComponent> agentComponents = provenance.getAgent();
                for (Provenance.ProvenanceAgentComponent component : agentComponents) {
                    if (null != component.getWho()) {
                        resourceIds.add(component.getWho().getReference());
                    }
                }
            }
        }
    }
}