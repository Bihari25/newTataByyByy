package com.uhg.ihr.centrihealth.api.logging;

import ch.qos.logback.classic.spi.ILoggingEvent;
import ch.qos.logback.core.filter.Filter;
import ch.qos.logback.core.spi.FilterReply;

public class HealthCheckFilter extends Filter<ILoggingEvent> {

    public static final String HEALTH_PATH = "\"path\":\"/health\"";
    public static final String INFO_PATH = "\"path\":\"/info\"";
    public static final String PROMETHEUS_PATH = "\"path\":\"/prometheus\"";
    public static final String STATUS_PATH = "\"path\":\"/status\"";
    public static final String LOGGING_FILTER = "LoggingFilter";

    @Override
    public FilterReply decide(ILoggingEvent event) {
        if (event.getLoggerName().contains(LOGGING_FILTER) &&
                (event.getMessage().contains(HEALTH_PATH) ||
                        event.getMessage().contains(INFO_PATH) ||
                        event.getMessage().contains(PROMETHEUS_PATH) ||
                        event.getMessage().contains(STATUS_PATH))) {
            return FilterReply.DENY;
        } else {
            return FilterReply.ACCEPT;
        }
    }
}
