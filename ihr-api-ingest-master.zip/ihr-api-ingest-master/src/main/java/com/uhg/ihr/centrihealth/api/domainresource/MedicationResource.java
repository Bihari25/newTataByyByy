package com.uhg.ihr.centrihealth.api.domainresource;

import lombok.Getter;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.hl7.fhir.r4.model.Annotation;
import org.hl7.fhir.r4.model.Identifier;
import org.hl7.fhir.r4.model.Medication;

import java.util.List;

@Slf4j
@Getter
@RequiredArgsConstructor(staticName = "of")
public class MedicationResource implements IhrResource<Medication> {

    final Medication medication;

    @Override
    public Medication getDomainResource() {
        return medication;
    }

    @Override
    public List<Annotation> getNote() {
        return null;
    }

    @Override
    public Medication setNote(List<Annotation> notes) {
        return null;
    }

    @Override
    public List<Identifier> getIdentifiers() {
        return medication.getIdentifier();
    }

    @Override
    public Medication addIdentifier(Identifier identifier) {
        return medication.addIdentifier(identifier);
    }

}