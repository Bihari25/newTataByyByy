package com.uhg.ihr.centrihealth.api.validator;

import java.util.Arrays;
import java.util.Set;
import java.util.stream.Collectors;

public enum CoverageEnum {

    SEARCH_ID("searchId"),
    CORRELATION_ID("correlationId"),
    ACTOR_ID("actorId");

    CoverageEnum(String value) {
        this.value = value;
    }

    private String value;
    public String getValue() {
        return value;
    }

    protected static final Set<String> COVERAGE_ENUMS = Arrays.stream(CoverageEnum.values())
            .map(CoverageEnum::getValue)
            .collect(Collectors.toSet());
}
