package com.uhg.ihr.centrihealth.api.rest;

import com.google.common.collect.ImmutableList;
import io.micronaut.context.annotation.Requires;
import io.micronaut.context.env.MapPropertySource;
import io.micronaut.context.env.PropertySource;
import io.micronaut.core.async.SupplierUtil;
import io.micronaut.core.util.StringUtils;
import io.micronaut.management.endpoint.info.InfoEndpoint;
import io.micronaut.management.endpoint.info.InfoSource;
import io.micronaut.runtime.context.scope.Refreshable;
import io.reactivex.Flowable;
import lombok.extern.slf4j.Slf4j;
import org.reactivestreams.Publisher;

import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.function.Supplier;
import java.util.stream.Collectors;

@Slf4j
@Refreshable
@Requires(beans = InfoEndpoint.class)
@Requires(property = "endpoints.info.enabled", notEquals = StringUtils.FALSE)
public class EnvironmentInfoSource implements InfoSource {
    private static final List<String> ENV_VARS = ImmutableList.of("CLUSTER", "DATACENTER", "ENVIRONMENT");

    private final Supplier<MapPropertySource> supplier;

    public EnvironmentInfoSource() {
        this.supplier = SupplierUtil.memoized(this::retrieveEnvironmentInfo);
    }

    private static String defaultEnv(String env) {
        return Objects.toString(System.getenv(env), "unknown");
    }

    @Override
    public Publisher<PropertySource> getSource() {
        return Flowable.just(supplier.get());
    }

    private MapPropertySource retrieveEnvironmentInfo() {
        Map<String, String> vars = ENV_VARS.stream().collect(Collectors.toMap(var -> var, EnvironmentInfoSource::defaultEnv));
        try {
            return new MapPropertySource("env", vars);
        } catch (Exception e) {
            return new MapPropertySource("env", Collections.emptyMap());
        }
    }

}
