package com.uhg.ihr.centrihealth.senzing.model;

import com.fasterxml.jackson.annotation.JsonAutoDetect;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.google.common.collect.ImmutableList;
import com.google.common.collect.ImmutableMap;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.apache.commons.lang3.StringUtils;

import java.util.List;
import java.util.Map;

/**
 * SenzingRequest class used as request contract to consume senzing api.
 *
 * @author ihr extract engineering team.
 */
@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
@JsonAutoDetect(fieldVisibility = JsonAutoDetect.Visibility.ANY)
@JsonInclude(JsonInclude.Include.NON_NULL)
public class SenzingRequest {

    public static final String PADDED_ID_KEY = "paddedId";
    public static final String UNPADDED_ID_KEY = "unpaddedId";

    @JsonProperty("name_first")
    private String nameFirst;

    @JsonProperty("name_last")
    private String nameLast;

    @JsonProperty("date_of_birth")
    private String dateOfBirth;

    @JsonProperty("search_id")
    private String searchId;

    @JsonProperty("clinician_empl_id")
    private String empId;

    @JsonProperty("IDENTIFIERS")
    private List<Map<String, String>> identifiers;

    public static List<Map<String, String>> buildIdentifiers(String searchId) {
        Map<String, String> paddedIds = computePaddedIds(searchId);
        return ImmutableList.of(
                ImmutableMap.of("SEARCH_ID", paddedIds.get(PADDED_ID_KEY)),
                ImmutableMap.of("SEARCH_ID", paddedIds.get(UNPADDED_ID_KEY))
        );
    }

    /**
     * Method to compute and padd subscriber id based on search id.
     */
    public static Map<String, String> computePaddedIds(String searchId) {
        String subscriberId;
        String subscriberPadId;

        // Validate is search id value  starting with zero or not.
        boolean isStartsWithZero = StringUtils.startsWith(searchId, "0");

        // Compute and populate with subscriber id's based search id is starting with zero or not.
        if (isStartsWithZero) {
            subscriberId = StringUtils.stripStart(searchId, "0");
            subscriberPadId = searchId;
        } else {
            String computedSubscriberId = StringUtils.isNotBlank(searchId) ? StringUtils.leftPad(searchId, 11, "0") : searchId;
            subscriberId = searchId;
            subscriberPadId = computedSubscriberId;
        }

        // Hold the computed subscriber ids results
        return ImmutableMap.of(UNPADDED_ID_KEY, subscriberId, PADDED_ID_KEY, subscriberPadId);
    }

    public static SenzingRequest buildRequestWithPatientData(final String dob, final String firstName, final String lastName,
                                                             final SenzingRequest senzingRequest) {
        senzingRequest.setNameFirst(firstName);
        senzingRequest.setNameLast(lastName);
        senzingRequest.setDateOfBirth(dob);
        return senzingRequest;
    }

    public static SenzingRequest buildRequestWithSearchId(SenzingRequest request) {
        return SenzingRequest.builder().nameFirst(request.getNameFirst())
                .nameLast(request.getNameLast())
                .dateOfBirth(request.getDateOfBirth())
                .identifiers(buildIdentifiers(request.getSearchId())).build();
    }

    public static SenzingRequest buildRequestWithEmpId(SenzingRequest request) {
        return SenzingRequest.builder().empId(request.getEmpId()).build();
    }

}