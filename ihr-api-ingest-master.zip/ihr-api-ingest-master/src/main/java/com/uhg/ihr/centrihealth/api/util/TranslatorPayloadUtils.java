package com.uhg.ihr.centrihealth.api.util;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.uhg.ihr.centrihealth.api.exception.IhrBadRequestException;
import com.uhg.ihr.centrihealth.api.model.ActorIdType;
import com.uhg.ihr.centrihealth.api.model.ActorIds;
import com.uhg.ihr.centrihealth.api.model.FhirMapper;
import com.uhg.ihr.centrihealth.api.model.TranslatorPayload;
import lombok.NoArgsConstructor;
import org.hl7.fhir.r4.model.Bundle;

import java.time.ZoneId;
import java.time.ZonedDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.Map;

@NoArgsConstructor
public class TranslatorPayloadUtils {

    public static final DateTimeFormatter FORMATTER = DateTimeFormatter.ofPattern("yyyy-MM-dd'T'HH:mm:ss,SSSXXX", Locale.US);
    public static final String API_INGEST = "API_INGEST";
    public static final ObjectMapper MAPPER = new ObjectMapper();

    public static String getBundleJsonString(Map<ActorIdType, String> map, Bundle fhirBundle) {

        List<ActorIds> actorIdsList = getActorIdsList(map);
        try {
            String nodeAsString = FhirMapper.createIngestBundleJson(fhirBundle, actorIdsList);
            List<ActorIds> actorIds = FhirMapper.buildTranslatorActorIds(fhirBundle, map);
            TranslatorPayload payload = buildTranslatorPayload(nodeAsString, fhirBundle.getId(), actorIds);
            return MAPPER.writeValueAsString(payload);
        } catch (JsonProcessingException jpex) {
            throw new IhrBadRequestException("unable parse bundle request");
        } catch (Exception ex) {
            throw new IhrBadRequestException(ex.getMessage());
        }
    }

    public static String formatDateAsString() {
        ZonedDateTime zonedDateTimeNow = ZonedDateTime.now(ZoneId.systemDefault());
        return zonedDateTimeNow.format(FORMATTER);
    }

    public static List<ActorIds> getActorIdsList(Map<ActorIdType, String> actorIdMap) {
        List<ActorIds> actorIds = new ArrayList<>();
        for (Map.Entry<ActorIdType, String> entry : actorIdMap.entrySet()) {
            ActorIds actorId = ActorIds.builder().actorIdType(entry.getKey().toString()).actorId(entry.getValue()).build();
            actorIds.add(actorId);
        }
        return actorIds;
    }

    public static TranslatorPayload buildTranslatorPayload(String nodeAsString, String fhirBundleId, List<ActorIds> actorIds) {

        String timestamp = formatDateAsString();
        return TranslatorPayload.builder()
                .uuid(fhirBundleId)
                .payload(nodeAsString)
                .createTimestamp(timestamp)
                .updateTimestamp(timestamp)
                .ACTORIDS(actorIds)
                .build();
    }
}
