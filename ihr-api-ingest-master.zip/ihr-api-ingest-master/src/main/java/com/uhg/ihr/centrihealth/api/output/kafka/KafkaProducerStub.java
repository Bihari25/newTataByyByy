package com.uhg.ihr.centrihealth.api.output.kafka;

import io.micronaut.context.annotation.Secondary;
import lombok.extern.slf4j.Slf4j;

import javax.inject.Singleton;

@Singleton
@Secondary
@Slf4j
public class KafkaProducerStub implements KafkaProducer {

    @Override
    public void send(String key, String payload) {
        log.debug("Kafka Key: " + key + "    Payload: " + payload);
    }
}
