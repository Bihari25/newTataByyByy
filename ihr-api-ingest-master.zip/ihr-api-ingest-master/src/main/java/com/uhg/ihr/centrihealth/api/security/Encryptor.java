package com.uhg.ihr.centrihealth.api.security;

import com.uhg.ihr.centrihealth.api.util.AppUtils;
import io.micronaut.context.annotation.Context;
import io.micronaut.context.annotation.Property;
import lombok.extern.slf4j.Slf4j;

import javax.crypto.Cipher;
import javax.crypto.KeyGenerator;
import javax.crypto.SecretKey;
import javax.crypto.spec.IvParameterSpec;
import javax.crypto.spec.SecretKeySpec;
import java.security.KeyFactory;
import java.security.PrivateKey;
import java.security.PublicKey;
import java.security.spec.PKCS8EncodedKeySpec;
import java.security.spec.X509EncodedKeySpec;
import java.util.Base64;

@Slf4j
@Context
public class Encryptor {

    private static final String AES = "AES";
    private static final String AES_PADDING = "AES/CBC/PKCS5PADDING";
    private static final String RSA = "RSA";
    private static final String RSA_PADDING = "RSA/ECB/OAEPWithSHA-1AndMGF1Padding";

    private static Cipher aesCipherPadding;
    private static Cipher rsaCipherKeyMode;
    private static byte[] encryptedSecKey;
    private static byte[] iv;

    /**
     * Expects public and private keys in the following formats:
     * ```openssl genrsa -des3 -out private.pem 2048```
     * ```openssl rsa -in private.pem -outform PEM -pubout -out public_key.pem```
     * ```openssl pkcs8 -topk8 -inform PEM -in private.pem -out private_key.pem -nocrypt```
     *
     * set the PUBLIC_KEY environment variable to the output, but without newlines and spaces
     */

    public Encryptor(@Property(name = "rsa-keys.publicKey") final String publicKeyFile) {
        this(publicKeyFile, null);
    }

    public Encryptor(@Property(name = "rsa-keys.publicKey") final String publicKeyFile, @Property(name = "rsa-keys.privateKey") String privateKeyFile) {
        log.info("Initializing log encryption");
        try {
            if (publicKeyFile == null) {
                log.error("could not find the public key for encryption");
                throw new RuntimeException("could not find the public key for encryption");
            }

            PublicKey publicKey = getPublicKey(publicKeyFile);
            KeyGenerator generator = KeyGenerator.getInstance(AES);
            generator.init(256); // The AES key size in number of bits
            SecretKey secKey = generator.generateKey();

            rsaCipherKeyMode = Cipher.getInstance(RSA_PADDING);
            rsaCipherKeyMode.init(Cipher.PUBLIC_KEY, publicKey);
            encryptedSecKey = rsaCipherKeyMode.doFinal(secKey.getEncoded());

            aesCipherPadding = Cipher.getInstance(AES_PADDING);
            aesCipherPadding.init(Cipher.ENCRYPT_MODE, secKey);
            iv = aesCipherPadding.getIV();

            if (privateKeyFile != null) {
                log.warn("Private key enabled. This should not be active in any environment");
                PrivateKey privateKey = getPrivateKey(privateKeyFile);
                rsaCipherKeyMode.init(Cipher.PRIVATE_KEY, privateKey);
            }
        } catch (Exception e) {
            log.error("Error instantiating Encryptor: {}", e.getMessage());
            throw new RuntimeException("FATAL: could not instantiate encryptor", e);
        }
        log.info("Log encryption initialized");
    }

    private static byte[] getKeyBytes(String filename) {
        // if 'filename' is long, assume it is the public key. otherwise, assume it is a resource path.
        if (filename.length() < 30) {
            log.warn("loading key from file {}, this is probably incorrect and should be fixed by generating an "
                    + "RSA public/private pair and setting PUBLIC_KEY as the newline/space free public key." +
                    " See README.md for help.", filename);
        }
        String key = filename.length() > 128 ? filename : AppUtils.readResource(filename);
        String stripped = key.replaceAll(System.lineSeparator(), "")
                .replace("-----BEGIN PRIVATE KEY-----", "")
                .replace("-----END PRIVATE KEY-----", "")
                .replace("-----BEGIN PUBLIC KEY-----", "")
                .replace("-----END PUBLIC KEY-----", "")
                .replace(" ", "");

        return stripped.getBytes();
    }

    private static PrivateKey getPrivateKey(String filename) throws Exception {
        byte[] keyBytes = getKeyBytes(filename);
        PKCS8EncodedKeySpec spec = new PKCS8EncodedKeySpec(Base64.getDecoder().decode(keyBytes));
        KeyFactory kf = KeyFactory.getInstance(RSA);
        return kf.generatePrivate(spec);
    }

    private static PublicKey getPublicKey(String filename) throws Exception {
        byte[] keyBytes = getKeyBytes(filename);
        X509EncodedKeySpec spec = new X509EncodedKeySpec(Base64.getDecoder().decode(keyBytes));
        KeyFactory kf = KeyFactory.getInstance(RSA);
        return kf.generatePublic(spec);
    }

    public Encrypted encrypt(String plainText) {
        try {
            byte[] byteCipherText = aesCipherPadding.doFinal(plainText.getBytes());
            return Encrypted.builder().encryptedMessage(byteCipherText).encryptedKey(encryptedSecKey).iv(iv).build();
        } catch (Exception e) {
            log.error("Error encrypting data: {}", e.getMessage());
            throw new RuntimeException("Error encrypting data", e);
        }
    }

    public String decrypt(Encrypted encrypted) {
        try {
            byte[] decryptedKey = rsaCipherKeyMode.doFinal(encrypted.getEncryptedKey());
            SecretKey originalKey = new SecretKeySpec(decryptedKey, 0, decryptedKey.length, AES);
            aesCipherPadding.init(Cipher.DECRYPT_MODE, originalKey, new IvParameterSpec(encrypted.getIv()));
            byte[] bytePlainText = aesCipherPadding.doFinal(encrypted.getEncryptedMessage());
            return new String(bytePlainText);
        } catch (Exception e) {
            log.error("Error decrypting data: {}", e.getMessage());
            throw new RuntimeException("Error decrypting data", e);
        }
    }
}
