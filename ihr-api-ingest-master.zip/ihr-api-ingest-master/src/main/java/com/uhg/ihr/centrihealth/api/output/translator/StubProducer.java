package com.uhg.ihr.centrihealth.api.output.translator;

import io.micronaut.context.annotation.Primary;
import io.micronaut.context.annotation.Requirements;
import io.micronaut.context.annotation.Requires;
import io.micronaut.context.annotation.Secondary;
import io.micronaut.http.HttpResponse;
import io.reactivex.Maybe;
import lombok.extern.slf4j.Slf4j;

import javax.inject.Singleton;

@Slf4j
@Singleton
@Secondary
public class StubProducer implements OutputProducer {

    public Maybe<HttpResponse<String>> sendPayload(String optumCidExt, String payload) {
        log.info("output Produced: " + payload);
        return Maybe.just(HttpResponse.ok());
    }
}
