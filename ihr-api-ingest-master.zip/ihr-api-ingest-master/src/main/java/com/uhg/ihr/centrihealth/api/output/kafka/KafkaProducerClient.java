package com.uhg.ihr.centrihealth.api.output.kafka;

import io.micronaut.configuration.kafka.annotation.KafkaClient;
import io.micronaut.configuration.kafka.annotation.KafkaKey;
import io.micronaut.configuration.kafka.annotation.Topic;
import io.micronaut.context.annotation.Requirements;
import io.micronaut.context.annotation.Requires;

@KafkaClient("enriched")
public interface KafkaProducerClient {

    @Topic("${kafka.producers.enriched.topic}")
    void send(@KafkaKey String key, String payload);
}
