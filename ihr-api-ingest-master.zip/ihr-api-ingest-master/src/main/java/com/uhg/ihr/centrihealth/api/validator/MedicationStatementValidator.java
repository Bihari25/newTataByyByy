package com.uhg.ihr.centrihealth.api.validator;

import com.google.common.collect.ImmutableMap;
import com.uhg.ihr.centrihealth.api.exception.IhrBadRequestException;
import com.uhg.ihr.centrihealth.api.model.FhirAttributesWrapper;
import com.uhg.ihr.centrihealth.api.util.Constant;
import com.uhg.ihr.centrihealth.api.util.ResponseErrorMessages;
import io.micronaut.core.util.CollectionUtils;
import io.micronaut.core.util.StringUtils;
import lombok.NoArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.hl7.fhir.r4.model.*;

import java.util.List;
import java.util.Map;
import java.util.Set;

@NoArgsConstructor(staticName = "of")
@Slf4j
public class MedicationStatementValidator implements IhrReferenceValidator {

    public static final String IHR_HOLD_DATE_URL = "https://new-wiki.optum.com/display/IHRI/ihrHoldDate";
    public static final String IHR_ADHERENCE_STOP_DATE_URL = "https://new-wiki.optum.com/display/IHRI/ihrAdherenceStopDate";
    public static final String TAKEN_AS_ORDERED_URL = "https://new-wiki.optum.com/display/IHRI/takenAsOrdered";
    private static final String MEDICATION_CODE_SYSTEM = "http://hl7.org/fhir/sid/ndc";

    private static final Map<ResourceType, IhrResourceValidator> informationSourceMap = ImmutableMap.<ResourceType, IhrResourceValidator>builder()
            .put(ResourceType.Patient, PatientValidator.of())
            .put(ResourceType.RelatedPerson, RelatedPersonValidator.of())
            .put(ResourceType.PractitionerRole, PractitionerRoleValidator.of())
            .build();

    public void validate(Resource resource, FhirAttributesWrapper fhirAttributesWrapper) {
        if (resource instanceof MedicationStatement) {
            validate((MedicationStatement) resource, fhirAttributesWrapper);
        }
    }

    private void validate(final MedicationStatement medicationStatement, final FhirAttributesWrapper fhirAttributesWrapper) {

        //action flag
        ValidationUtils.validateActionFlag(medicationStatement.getMeta().getTag());
        //last updated date
        ValidationUtils.validateLastUpdatedDate(medicationStatement.getMeta().getLastUpdatedElement());
        // validate identifiers
        ValidationUtils.validateIdentifier(medicationStatement.getIdentifier(), false);
        //Check for record key exits or not
        boolean recordKeyExists = ValidationUtils.isRequiredIdentifierExists(medicationStatement.getIdentifier(),
                IdentifierEnum.RECORD_KEY.getValue());
        //validate information source need to check
        validateInformationSource(medicationStatement, fhirAttributesWrapper);
         //validate medicationreference
        validateMedicationReference(medicationStatement, recordKeyExists);
        //validate subject
        validateSubjectReference(medicationStatement,fhirAttributesWrapper);
        // validate notes
        ValidationUtils.isValidNote(medicationStatement.getNote());

        //optional- Validate Extension
        if (medicationStatement.hasExtension()) {
            validateExtension(medicationStatement.getExtension(),MedicationStmtExtensionEnum.EXTENSIONS_URLS);
        }
        //validate status reason
        if (CollectionUtils.isNotEmpty(medicationStatement.getStatusReason())
                && CollectionUtils.isNotEmpty(medicationStatement.getStatusReason().get(0).getCoding())) {
            medicationStatusReason(medicationStatement.getStatusReason().get(0));

        }
        //check action flag
        if (!isActionFlagUpsert(medicationStatement.getMeta().getTag())) {
            throw new IhrBadRequestException(ResponseErrorMessages.UPSERT_ACTION_FLAG_ERROR);
        }

        // reasonCode
        if (CollectionUtils.isNotEmpty(medicationStatement.getReasonCode())) {
            for (CodeableConcept codeableConcept : medicationStatement.getReasonCode()) {
                ValidationUtils.validateCoding(codeableConcept);
            }
        }
        // dosage
        validateDosage(medicationStatement.getDosage());

    }

    private void validateSubjectReference(MedicationStatement medicationStatement, FhirAttributesWrapper fhirAttributesWrapper) {
        if (null != medicationStatement.getSubject() && null != medicationStatement.getSubject().getResource()) {
            if (medicationStatement.getSubject().getResource() instanceof Patient) {
                Patient patient = (Patient) medicationStatement.getSubject().getResource();
                PatientValidator.of().validate(patient, fhirAttributesWrapper);
            } else {
                throw new IhrBadRequestException(ResponseErrorMessages.INVALID_PATIENT_REFERENCE);
            }
        }
    }


    public static void validateDosage(List<Dosage> dosages) {
        if (CollectionUtils.isNotEmpty(dosages)) {
            for (Dosage dosage : dosages) {
                if (dosage.hasRoute() && dosage.getRoute().hasCoding()) {
                    ValidationUtils.validateCoding(dosage.getRoute());
                }
                if ( dosage.hasDoseAndRate()) {
                    validateDoseAndRateQuantity(dosage.getDoseAndRate());
                }
                if ( dosage.hasTiming() && dosage.getTiming().hasCode()) {
                    ValidationUtils.validateCoding(dosage.getTiming().getCode());
                }
            }
        }
    }

    private static void validateDoseAndRateQuantity(List<Dosage.DosageDoseAndRateComponent> doseAndRate) {
        for (Dosage.DosageDoseAndRateComponent doseAndRateComponent : doseAndRate) {

            if (doseAndRateComponent.hasDoseQuantity()
                     && doseAndRateComponent.getDoseQuantity().hasUnit() && !doseAndRateComponent.getDoseQuantity().hasValue()) {
                throw new IhrBadRequestException(ResponseErrorMessages.DOSE_QUANTITY_VALUE_REQUIRED);
            }
        }
    }

    private static void validateInformationSource(final MedicationStatement medicationStatement, FhirAttributesWrapper fhirAttributesWrapper) {
        validateInformationSourceReference(medicationStatement, fhirAttributesWrapper);
    }

    private static void validateInformationSourceReference(final MedicationStatement statement, final FhirAttributesWrapper fhirAttributesWrapper) {

        if (statement.hasInformationSource()
                && null != statement.getInformationSource().getResource() && statement.getInformationSource().hasReferenceElement()
                && statement.getInformationSource().getReferenceElement().hasResourceType()) {
            IhrResourceValidator validator = informationSourceMap.get(ResourceType.valueOf
                    (statement.getInformationSource().getReferenceElement().getResourceType()));

            if (validator == null) {
                throw new IhrBadRequestException(ResponseErrorMessages.INVALID_INFORMATIONSOURCE_REFERENCE);
            } else {
                validator.validate((Resource) statement.getInformationSource().getResource(), fhirAttributesWrapper);
            }
        }
    }



    public static void isDataAuthorIdentifierRequired(boolean assertedDateExists, boolean dataAuthorIdentifierExists) {
        if (assertedDateExists && !dataAuthorIdentifierExists) {
            throw new IhrBadRequestException(ResponseErrorMessages.REQUIRED_DATA_AUTHOR_IDENTIFIER);
        }
    }

    public static void validateMedication(final Medication medication, final boolean recordKeyExists) {
        if (!recordKeyExists && !medication.hasCode() && !medication.hasIdentifier()) {
            throw new IhrBadRequestException(ResponseErrorMessages.CONCEPT_CODE_REQUIRED);
        }
        if (medication.hasCode()) {
            CodeableConcept concept = medication.getCode();
            ValidationUtils.validateCoding(concept);
            validateSystemForMedication(concept);
        }
        if (medication.hasIdentifier()) {
            List<Identifier> identifiers = medication.getIdentifier();
            if (!(CollectionUtils.isNotEmpty(identifiers) && (identifiers.stream().allMatch(identifier ->
                    ValidationUtils.isIdentifierValid(identifier) &&
                            identifier.getType().getText().equals(Constant.CONCEPT_CHID))))) {
                throw new IhrBadRequestException(ResponseErrorMessages.INVALID_IDENTIFIER);
            }
        }
    }

    private static void validateSystemForMedication(CodeableConcept concept) {
        List<Coding> codings = concept.getCoding();
        if (!(CollectionUtils.isNotEmpty(codings) && (codings.stream().allMatch(coding ->
                coding.getSystem().equals(MEDICATION_CODE_SYSTEM))))) {
            throw new IhrBadRequestException(ResponseErrorMessages.MISSING_MEDICATION_CODE);
        }
    }


    public static void validateExtension(List<Extension> extensions, Set<String> extensionsUrl) {

        extensions.forEach(extension -> {
            if (!extension.hasUrl()) {
                throw new IhrBadRequestException(ResponseErrorMessages.MISSING_URL_IN_EXTENSION);
            } else if (!extensionsUrl.contains(extension.getUrl())) {
                throw new IhrBadRequestException(ResponseErrorMessages.INVALID_URL_EXTENSION + " " + extension.getUrl());

            } else if (!extension.hasValue()) {
                throw new IhrBadRequestException(ResponseErrorMessages.INVALID_EXTENSION_VALUE);
            }
        });
    }


    public static boolean isActionFlagUpsert(List<Coding> tag) {
        if (CollectionUtils.isNotEmpty(tag) && tag.stream().allMatch(e -> ActionFlag.UPSERT.getValue().equals(e.getDisplay())
                && Constant.ACTION_FLAG.equals(e.getCode()))) {
            return true;
        }
        return false;
    }

    public static void medicationStatusReason(CodeableConcept concept) {
        try {
            ValidationUtils.validateCoding(concept);
        } catch (IhrBadRequestException e) {
            if (e.getMessage().equals(ResponseErrorMessages.CODE_OR_SYSTEM_MISSING)) {
                throw new IhrBadRequestException(ResponseErrorMessages.MISSING_STATUS_REASON_SYSTEM);
            } else
                throw e;
        }
        List<Coding> codings = concept.getCoding();
        if (codings.size() > 1) {
            throw new IhrBadRequestException(ResponseErrorMessages.STATUS_REASON_CODING_ERROR);
        }
    }

    public static void validateMedicationReference(MedicationStatement medicationStatement, boolean recordKeyExists) {
        if (StringUtils.isNotEmpty(medicationStatement.getMedicationReference().getReference())) {
            if(null == medicationStatement.getMedicationReference().getResource()) {
                throw new IhrBadRequestException(ResponseErrorMessages.INVALID_MEDICATION_REFERENCE);
            }
        }
        if(!recordKeyExists && null == medicationStatement.getMedicationReference().getResource() ){
            throw new IhrBadRequestException(ResponseErrorMessages.MEDICATION_REQUIRED);
        }
        if (null != medicationStatement.getMedicationReference().getResource() ){
            Medication medication = (Medication) medicationStatement.getMedicationReference().getResource();
            validateMedication(medication, recordKeyExists);
        }
    }

    @Override
    public void setReferenceIds(Set<String> resourceIds, Resource resource) {
        MedicationStatement statement = (MedicationStatement) resource;
        resourceIds.add(statement.getId());
        if (null != statement.getSubject().getResource()) {
            resourceIds.add(statement.getSubject().getReference());
        }
        if (null != statement.getMedicationReference().getResource()) {
            resourceIds.add(statement.getMedicationReference().getReference());
        }
        if (null != statement.getInformationSource().getResource()) {
            resourceIds.add(statement.getInformationSource().getReference());
        }
        if (CollectionUtils.isNotEmpty(statement.getNote())
                && null != statement.getNote().get(0).getAuthorReference().getResource()) {
            resourceIds.add(statement.getNote().get(0).getAuthorReference().getReference());
        }
    }
}
