package com.uhg.ihr.centrihealth.api.validator;

import com.uhg.ihr.centrihealth.api.exception.IhrBadRequestException;
import com.uhg.ihr.centrihealth.api.model.FhirAttributesWrapper;
import com.uhg.ihr.centrihealth.api.util.ResponseErrorMessages;
import lombok.NoArgsConstructor;
import org.hl7.fhir.r4.model.Immunization;
import org.hl7.fhir.r4.model.Patient;
import org.hl7.fhir.r4.model.Resource;

@NoArgsConstructor(staticName = "of")
public class ImmunizationsValidator implements IhrResourceValidator {

    private static final String CODE_VALUE ="999";
    private static final String REGX_MATCH ="^\\d*[1-9]\\d*$";

    public void validate(Resource resource, FhirAttributesWrapper fhirAttributesWrapper) {
        if (resource instanceof Immunization) {
            validate((Immunization) resource, null);
        }
    }

    private void validate(final Immunization immunization, final FhirAttributesWrapper fhirAttributesWrapper) {

        //required - upsert action flag
        ValidationUtils.validateActionFlag(immunization.getMeta().getTag());

        //required - last updated
        ValidationUtils.validateLastUpdatedDate(immunization.getMeta().getLastUpdatedElement());

        //optional - patient
        validatePatient(immunization, fhirAttributesWrapper);

        /*  required - record key or vaccine Medication code
          pair is required .if vaccine code is 999
          then we expect a PRC (reasonCode)
        */
        validateRecordKeyOrVaccineMedCode(immunization);

        // optional-  ReasonCode
        validateReasonCode(immunization);

        //  required- occurrenceDateTime
        validateOccurrenceDateTime(immunization);

        //optional- recordedDate
        validateRecorded(immunization);

        //optional - doseNumber
        validateDoseNumber(immunization);

    }

    public static void validateDoseNumber(Immunization immunization) {

        if (immunization.hasProtocolApplied()) {
            immunization.getProtocolApplied().forEach(value -> {
                if (value.hasDoseNumber()) {
                    if (!String.valueOf(value.getDoseNumberPositiveIntType().getValue()).matches(REGX_MATCH)) {
                        throw new IhrBadRequestException(ResponseErrorMessages.INVALID_POSITIVE_NUMBER);
                    }
                }
            });
        }
    }

    public static void validateRecorded(Immunization immunization) {
        if (immunization.hasRecorded()) {
            boolean recorded = immunization.getRecorded() != null &&
                    null == ValidationUtils.toDate(immunization.getRecordedElement().asStringValue());
            if (recorded) {
                throw new IhrBadRequestException(ResponseErrorMessages.INVALID_RECORDED_DATE_IMM);
            }
        }
    }

    public static void validateOccurrenceDateTime(Immunization immunization) {
        if (immunization.hasOccurrenceDateTimeType()) {
            boolean occurrenceDate = immunization.getOccurrenceDateTimeType() != null &&
                    null == ValidationUtils.toDate(immunization.getOccurrenceDateTimeType().asStringValue());
            if (occurrenceDate) {
                throw new IhrBadRequestException(ResponseErrorMessages.INVALID_OCCURRENCE_DATE_TIME);
            }
        } else {
            throw new IhrBadRequestException(ResponseErrorMessages.REQUIRED_OCCURRENCE_FIELD);
        }
    }


    public static void validateReasonCode(Immunization immunization) {
        if (immunization.hasReasonCode()) {
            immunization.getReasonCode()
                    .stream().forEach(reasonCode -> ValidationUtils.validateCoding(reasonCode));
        }
    }

    public static void validateRecordKeyOrVaccineMedCode(Immunization immunization) {
        boolean recordKeyExists = ValidationUtils
                .isRequiredIdentifierExists(immunization.getIdentifier(), IdentifierEnum.RECORD_KEY.getValue());
        if (recordKeyExists) {
            ValidationUtils.validateIdentifier(immunization.getIdentifier());
        } else if (immunization.hasVaccineCode()) {
            ValidationUtils.validateCoding(immunization.getVaccineCode());
            boolean hasCode999 = immunization.getVaccineCode().getCoding().stream().anyMatch(coding -> coding.getCode().equals(CODE_VALUE));
            if (hasCode999 & !immunization.hasReasonCode()) {
                throw new IhrBadRequestException(ResponseErrorMessages.INVALID_REASON_CODE);
            }
        } else {
            throw new IhrBadRequestException(ResponseErrorMessages.RECORD_KEY_OR_IMMUNIZATION_VACCINE_CODE_REQUIRED);
        }
    }

    public static void validatePatient(Immunization immunization, FhirAttributesWrapper fhirAttributesWrapper) {
        if (immunization.hasPatient()) {
            if (immunization.getPatient().getResource() instanceof Patient) {
                Patient patient = (Patient) immunization.getPatient().getResource();
                PatientValidator.of().validate(patient, fhirAttributesWrapper);
            } else {
                throw new IhrBadRequestException(ResponseErrorMessages.INVALID_PATIENT_REFERENCE);
            }
        } else {
            throw new IhrBadRequestException(ResponseErrorMessages.PATIENT_RESOURCE_MISSING_IMM);
        }
    }
}