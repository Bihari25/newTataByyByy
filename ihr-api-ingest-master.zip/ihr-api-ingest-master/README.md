IHR API
=============

To run, configure the following environment variables:

| Variable | Description | Default |
| --- | --- | --- |
| LOG_LEVEL | logging level | INFO |
| II_URL | the location of the ii API service (deprecated) | localhost:9082 This is where the docker container (see api-docker-compose) will bind. |
| DATA_URL | the location of the data API service. (deprecated) not needed for 2.0/mongo | localhost:9081 This is where the docker container (see api-docker-compose) will bind. |
| ENVIRONMENT | needs to be set if you want to enable local requests that bypass the stargate filter | none |
| SENZING_ENABLED | whether to call senzing or not (deprecated) | true |
| SENZING_URL | the location of the senzing service | localhost |
| SENZING_KEY | the secret used to generate valid senzing tokens | none |



if startup is slow on a mac, add your hostname to /etc/hosts. see https://stackoverflow.com/questions/39636792/jvm-takes-a-long-time-to-resolve-ip-address-for-localhost/39698914#39698914

```
hostname
LAMU02Y40GDJG5J.uhc.com.

/etc/hosts
127.0.0.1	localhost LAMU02Y40GDJG5J.uhc.com
::1		localhost LAMU02Y40GDJG5J.uhc.com
```


Branch Naming Convention
-------------
  feature-JIRA-NUMBER (standard development for features)

  hotfix-JIRA-NUMBER (fix for production)

  wip-JIRA-NUMBER (experimental or long-term)

Jenkins
-------------
  This is being deprecated. Please refer to https://new-wiki.optum.com/display/IHRI/NEW+PIPELINE+FLOW

  https://jenkins.optum.com/ihr/job/ihr-api-ingest/job/ihr-api-pipeline/
  The job triggers automatically from a webhook in github. This goes from build through deployment to dev and is based on Jenkinsfile.

  JenkinsfileDeploy is the basis for all deploy jobs for the various environments related to this project.
