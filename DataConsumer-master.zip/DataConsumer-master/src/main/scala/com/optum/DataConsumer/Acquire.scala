package com.optum.DataConsumer

import org.apache.spark.SparkConf
import org.apache.spark.sql.DataFrame
import org.apache.spark.sql.SQLContext._
import org.apache.spark.SparkContext
import org.apache.spark.rdd.RDD.rddToPairRDDFunctions
//import com.mapr.db.spark._
import org.apache.spark.sql.types._
//import com.fasterxml.jackson.annotation.{JsonIgnoreProperties, JsonProperty}
import org.apache.hadoop.hbase._
import org.apache.hadoop.hbase.client._
import org.apache.spark.sql._
import org.apache.spark.sql.datasources.hbase._
import org.apache.hadoop.hbase.spark.datasources._
import org.apache.hadoop.hbase.spark.datasources.HBaseScanPartition
import org.apache.spark.sql.datasources.hbase.HBaseTableCatalog
import org.apache.hadoop.hbase.spark
import org.apache.hadoop.hbase.spark.datasources.HBaseSparkConf
//import org.apache.spark.sql.execution.datasources.hbase._
//import org.apache.spark.sql.execution.datasources._
//import org.apache.spark.sql.datasources.hbase._
import org.apache.hadoop.hbase.spark.HBaseContext
import org.apache.spark.SparkContext
import org.apache.hadoop.hbase.{TableName, HBaseConfiguration}
import org.apache.hadoop.hbase.util.Bytes
import org.apache.hadoop.hbase.client.Delete
import org.apache.spark.SparkConf
import org.apache.spark.sql.functions._
import org.apache.spark.sql.functions.udf

import org.apache.spark.sql.hive.HiveContext
import org.json4s._
import org.json4s.JsonDSL._
import org.json4s.jackson.JsonMethods._
import scala.io.Source
import scala.reflect.io._
import scala.collection.mutable.ListBuffer
import java.time.{Instant, ZoneId, ZonedDateTime}
import org.apache.hadoop.security.alias.CredentialProviderFactory

object Acquire {
  val usage =
    """
    Usage:
    export SPARK_CONF_DIR=path to spark conf dir which has hive connection details
    spark-submit --class com.optum.Acquire --executor-memory value --num-executors value --queue give_queue_name location_of_DataConsumer-SNAPSHOT.jar 'Location_of_Json_file.json' -runtype ['FULL' or 'INCR'] -param ParamName='param value' ...
  """

  def main(args: Array[String]) = {

    //Check Args
    if (args.length == 0) {
      println(usage)
      System.exit(1)
    }

    var params = new ListBuffer[String]()

    //Iterate through the args and get the params to substitute with the value
    for (List(left,right) <- args.toList.sliding(2) if (left.equals("-param"))) {
      params.append(right.toString)
    }

    var LoadType = ""

    for (List(left,right) <- args.toList.sliding(2) if (left.equals("-runtype"))) {
       LoadType = right.toString
    }

    // Create SparkSession
    val spark = SparkSession
      .builder()
      .appName("DataConsumer")
      //.master("yarn")
      .enableHiveSupport()
      .getOrCreate()

    def withCatalog(cat: String, startTS: String, endTS: String): DataFrame = {
      spark.sqlContext
        .read
        .options(Map(HBaseTableCatalog.tableCatalog->cat,
          HBaseSparkConf.MIN_TIMESTAMP -> startTS,
          HBaseSparkConf.MAX_TIMESTAMP -> endTS))
        .format("org.apache.hadoop.hbase.spark")
        .load()
    }

    // Read Json Config file
    val gConfig = new GlobalCfg
    var jsonQuery = ""
    var jsonQueryFinal = ""

    try {
      println("Load Type : "+ LoadType)
      println("Reading cfg file : " + args(0))
      jsonQuery = gConfig.getJsonQueries(args(0))

      //Replace the param values
      for ( eachParam <- params) {
        var arr = eachParam.split("==")
        println("Replacing : "+ arr(0) + " with " + arr(1))
        jsonQuery=jsonQuery.replace(arr(0),arr(1))
      }

      jsonQueryFinal = jsonQuery.replaceAll("\\s+", " ").mkString
      println("\n\nJson Query : " + jsonQueryFinal + "\n")

    } catch {
      case e: Exception => {
        println("Exception in getJsonQueries. Properties files is not in valid Json Format")
        e.printStackTrace()
        System.exit(2)
      }
    } finally {}

    implicit val jsonDefaultFormats = DefaultFormats

    //Get parsed Json Object
    val jsonObj = parse(jsonQueryFinal, true)

    // Get AcquireConf Object
    val obAcquire = jsonObj.extract[gConfig.AcquireConf]

    try {
      // Iterate though the acquisition_info  and create Temporary spark tables in sqlContext
      for (tbl <- obAcquire.acquisition_info) {
        println("Creating Temp table for Alias: " + tbl.alias)

        if(tbl.Type == "RDBMS") {

        val query = s"SELECT ${tbl.columnsToAcquire} FROM ${tbl.srcDBNmSrcTblNm} ${tbl.filterCondition}"
        val finalQuery = s"(${query} ) ${tbl.alias}"

        var myDF = spark.read.format("jdbc")
          .option("url", tbl.Url)
          .option("driver", tbl.Driver)
          .option("dbtable", finalQuery)
          .option("user", tbl.UserName)
          .option("password", getCredentialSecret(tbl.CredentialStore, tbl.CredentialAlias,spark))
          .load()


          myDF.createOrReplaceTempView(tbl.alias)

        }

        if(tbl.Type == "Hive") {
          var myDF = spark.sql("select " + tbl.columnsToAcquire + " from " + tbl.srcDBNmSrcTblNm + " " + tbl.alias + " " + tbl.filterCondition)
          myDF.createOrReplaceTempView(tbl.alias)
        }

        if(tbl.Type == "Hbase") {
          var colshm = tbl.columnsToAcquire.split(",")
          var table = s"""{ "table":{"namespace":"default", "name":"""" + tbl.srcDBNmSrcTblNm +""""},
                "rowkey":"key",
                "columns":{
                "key":{"cf":"rowkey", "col":"key", "type":"string"},
                """

          for (item <- colshm) {
            var cols = """""""+item.split(" ")(0).split(":")(1).toString + """":{"cf":""""+item.split(" ")(0).split(":")(0).toString+"""", "col":""""+item.split(" ")(0).split(":")(1).toString + """", "type":""""+item.split(" ")(1) + """"},"""
            table += cols
          }
          var newCatlog = table.dropRight(1)
          newCatlog += """ }}"""

          var Catalog = newCatlog.replaceAll("\\s+", " ").mkString
          println("\n\nHBase Catalog : " + Catalog + "\n")

          var startTS =""
          var endTS =""

          if(tbl.startTS.length() > 0){
            startTS=tbl.startTS
          }else{
            startTS="0"
          }
          if(tbl.endTS.length() > 0){
            endTS=tbl.endTS
          }else{
            endTS=System.currentTimeMillis().toString
          }

          var myDF4 = withCatalog(Catalog,startTS.toString(),endTS.toString())

         /* var myDF4 = spark.sqlContext.read.format("org.apache.hadoop.hbase.spark").options(Map("hbase.columns.mapping" ->
            tbl.columnsToAcquire,
            "hbase.table" -> tbl.srcDBNmSrcTblNm)).load() */

          myDF4.createOrReplaceTempView(tbl.alias+"_tmp")
          var myDF5 = myDF4.sqlContext.sql("select * from " + tbl.alias + "_tmp "+ tbl.alias + " " + tbl.filterCondition)
          myDF5.createOrReplaceTempView(tbl.alias)
        }

      }

      // Iterate though the file_info  and create Temporary spark tables in sqlContext
      for (fle <- obAcquire.file_info) {
        println("Creating Temp table for Alias: " + fle.alias)

        if(fle.Type == "File") {
          if (fle.ReadFile.length() > 0 && fle.ReadFileFormat.length() > 0 ) {
            println("Creating Temp table for File with Schema: " + fle.alias)

            if (fle.ReadFileFormat != "delimiter") {
              // Get the data from tbl.ReadFile which is in tbl.ReadFileFormat format
              if(fle.Header.length > 0) {
                var myDF5 = spark.sqlContext.read.format(fle.ReadFileFormat).option("header", fle.Header).option("inferSchema", fle.InferSchema).load(fle.ReadFile)
                // Create a TempTable with FileAlias name
                if (fle.alias.length() > 0) {
                  myDF5.createOrReplaceTempView(fle.alias+"_tmp")
                  myDF5.sqlContext.sql("select * from " + fle.alias + "_tmp "+ fle.alias + " " + fle.filterCondition)
                  myDF5.createOrReplaceTempView(fle.alias)
                }
              }else {
                var myDF5 = spark.sqlContext.read.format(fle.ReadFileFormat).load(fle.ReadFile)
                // Create a TempTable with FileAlias name
                if (fle.alias.length() > 0) {
                  myDF5.createOrReplaceTempView(fle.alias+"_tmp")
                  myDF5.sqlContext.sql("select * from " + fle.alias + "_tmp "+ fle.alias + " " + fle.filterCondition)
                  myDF5.createOrReplaceTempView(fle.alias)
                }
              }
            }
            else {
              // Get the data from tbl.ReadFile which is in tbl.ReadFileFormat format
              if(fle.Header.length > 0) {
                var myDF5 = spark.sqlContext.read.option("delimiter", fle.Delimiter).option("header", fle.Header).option("inferSchema", fle.InferSchema).csv(fle.ReadFile)
                // Create a TempTable with FileAlias name
                if (fle.alias.length() > 0) {
                  myDF5.createOrReplaceTempView(fle.alias+"_tmp")
                  myDF5.sqlContext.sql("select * from " + fle.alias + "_tmp "+ fle.alias + " " + fle.filterCondition)
                  myDF5.createOrReplaceTempView(fle.alias)
                }
              }else {
                var myDF5 = spark.sqlContext.read.option("delimiter", fle.Delimiter).csv(fle.ReadFile)
                // Create a TempTable with FileAlias name
                if (fle.alias.length() > 0) {
                  myDF5.createOrReplaceTempView(fle.alias+"_tmp")
                  myDF5.sqlContext.sql("select * from " + fle.alias + "_tmp "+ fle.alias + " " + fle.filterCondition)
                  myDF5.createOrReplaceTempView(fle.alias)
                }
              }
            }


          }
        }

      }

      // Iterate though the processing_info  and create Temporary spark tables in sqlContext
      for (process <- obAcquire.processing_info) {

        if (process.Query.length() > 0) {
          println("Creating Temp table for QueryAlias: " + process.QueryAlias)
          var myDF2 = spark.sql(process.Query)

          if (process.QueryAlias.length() > 0)
            myDF2.createOrReplaceTempView(process.QueryAlias)

          if (process.QueryOutputFormat.length() > 0 && process.QueryOutputSaveLocation.length() > 0) {
            if (process.QueryOutputFormat != "delimiter" && process.QueryOutputFormat != "Hbase") {
              // Save the processed myDF to obAcquire.QueryOutputSaveLocation in process.QueryOutputFormat format
              myDF2.write.mode(SaveMode.Overwrite).format(process.QueryOutputFormat).save(process.QueryOutputSaveLocation)
            }
            else if (process.QueryOutputFormat == "Hbase") {
              // Save the processed myDF to obAcquire.QueryOutputSaveLocation in process.QueryOutputFormat format

              var colshm = process.Delimiter.split(",")
              var table = s"""{ "table":{"namespace":"default", "name":"""" + process.QueryOutputSaveLocation+""""},
                "rowkey":"key",
                "columns":{
                "key":{"cf":"rowkey", "col":"key", "type":"string"},
                """

              for (item <- colshm) {
                var cols = """""""+item.split(" ")(0).split(":")(1).toString + """":{"cf":""""+item.split(" ")(0).split(":")(0).toString+"""", "col":""""+item.split(" ")(0).split(":")(1).toString + """", "type":""""+item.split(" ")(1) + """"},"""
                table += cols
              }
              var newCatlog = table.dropRight(1)
              newCatlog += """ }}"""

              var Catalog = newCatlog.replaceAll("\\s+", " ").mkString
              println("\n\nHBase Output Catalog : " + Catalog + "\n")

              //myDF2.write.mode(SaveMode.Overwrite).format(process.QueryOutputFormat).save(process.QueryOutputSaveLocation)
              myDF2.na.fill("").write.options(Map(HBaseTableCatalog.tableCatalog -> Catalog)).format("org.apache.hadoop.hbase.spark").save()
              //myDF2.write.options(Map(HBaseTableCatalog.tableCatalog -> Catalog)).format("org.apache.spark.sql.datasources.hbase").save()

            }
            else if(process.Delimiter.length() > 0){
              // Save the processed myDF to obAcquire.QueryOutputSaveLocation in process.QueryOutputFormat format
              myDF2.write.mode(SaveMode.Overwrite).option("delimiter", process.Delimiter).csv(process.QueryOutputSaveLocation)
            }
          }
        }

        if (process.ReadFile.length() > 0 && process.ReadFileFormat.length() > 0 && (scala.reflect.io.File(scala.reflect.io.Path("/mapr/" + process.ReadFile)).exists == true)) {
          println("Creating Temp table for File with Schema: " + process.FileAlias)

          // Get the data from process.ReadFile which is in process.ReadFileFormat format
          var myDF3 = spark.sqlContext.read.format(process.ReadFileFormat).load(process.ReadFile)

          // Create a TempTable with FileAlias name
          if (process.FileAlias.length() > 0) {
            myDF3.createOrReplaceTempView(process.FileAlias)
          }
        }

      }

      // Iterate though the reconcile_info  and create Temporary spark tables in sqlContext
      for (process <- obAcquire.reconcile_info) {

        if (LoadType == "FULL" && process.EnabledOnFullLoad == "true") {
          if (process.ReadFile.length() > 0 && process.ReadFileFormat.length() > 0 && (scala.reflect.io.File(scala.reflect.io.Path("/mapr/" + process.ReadFile)).exists == true)) {
            println("Creating Temp table for File with Schema: " + process.FileAlias)

            // Get the data from process.ReadFile which is in process.ReadFileFormat format
            var myDF3 = spark.sqlContext.read.format(process.ReadFileFormat).load(process.ReadFile)

            // Create a TempTable with FileAlias name
            if (process.FileAlias.length() > 0) {
              myDF3.createOrReplaceTempView(process.FileAlias)
            }
          }

          if (process.Query.length() > 0) {
            println("Creating Temp table for QueryAlias: " + process.QueryAlias)
            var myDF2 = spark.sql(process.Query)

            if (process.QueryAlias.length() > 0)
              myDF2.createOrReplaceTempView(process.QueryAlias)

            if (process.QueryOutputFormat.length() > 0 && process.QueryOutputSaveLocation.length() > 0) {
              if (process.QueryOutputFormat != "delimiter" && process.QueryOutputFormat != "Hbase") {
                // Save the processed myDF to obAcquire.QueryOutputSaveLocation in process.QueryOutputFormat format
                myDF2.write.mode(SaveMode.Overwrite).format(process.QueryOutputFormat).save(process.QueryOutputSaveLocation)
              }else if (process.QueryOutputFormat == "Hbase") {
                // Save the processed myDF to obAcquire.QueryOutputSaveLocation in process.QueryOutputFormat format

                var colshm = process.Delimiter.split(",")
                var table = s"""{ "table":{"namespace":"default", "name":"""" + process.QueryOutputSaveLocation+"""","tableCoder":"PrimitiveType"},
                "rowkey":"key",
                "columns":{
                "key":{"cf":"rowkey", "col":"key", "type":"string"},
                """

                for (item <- colshm) {
                  var cols = """""""+item.split(" ")(0).split(":")(1).toString + """":{"cf":""""+item.split(" ")(0).split(":")(0).toString+"""", "col":""""+item.split(" ")(0).split(":")(1).toString + """", "type":""""+item.split(" ")(1) + """"},"""
                  table += cols
                }
                var newCatlog = table.dropRight(1)
                newCatlog += """ }}"""

                var Catalog = newCatlog.replaceAll("\\s+", " ").mkString
                println("\n\nHBase Output Catalog : " + Catalog + "\n")

                //myDF2.write.mode(SaveMode.Overwrite).format(process.QueryOutputFormat).save(process.QueryOutputSaveLocation)
                myDF2.na.fill("").write.options(Map(HBaseTableCatalog.tableCatalog -> Catalog)).mode("append").format("org.apache.hadoop.hbase.spark").save()
              }else if(process.Delimiter.length() > 0){
                myDF2.write.mode(SaveMode.Overwrite).option("delimiter", process.Delimiter).csv(process.QueryOutputSaveLocation)
              }
            }
          }
        }
        else if (LoadType == "INCR" && process.EnabledOnFullLoad == "false") {
          if (process.ReadFile.length() > 0 && process.ReadFileFormat.length() > 0 && (scala.reflect.io.File(scala.reflect.io.Path("/mapr/" + process.ReadFile)).exists == true)) {
            println("Creating Temp table for File with Schema: " + process.FileAlias)

            // Get the data from process.ReadFile which is in process.ReadFileFormat format
            var myDF3 = spark.sqlContext.read.format(process.ReadFileFormat).load(process.ReadFile)

            // Create a TempTable with FileAlias name
            if (process.FileAlias.length() > 0) {
              myDF3.createOrReplaceTempView(process.FileAlias)
            }
          }

          if (process.Query.length() > 0) {
            println("Creating Temp table for QueryAlias: " + process.QueryAlias)
            var myDF2 = spark.sql(process.Query)

            if (process.QueryAlias.length() > 0)
              myDF2.createOrReplaceTempView(process.QueryAlias)

            if (process.QueryOutputFormat.length() > 0 && process.QueryOutputSaveLocation.length() > 0) {
              if (process.QueryOutputFormat != "delimiter" && process.QueryOutputFormat != "Hbase") {
                // Save the processed myDF to obAcquire.QueryOutputSaveLocation in process.QueryOutputFormat format
                myDF2.write.mode(SaveMode.Overwrite).format(process.QueryOutputFormat).save(process.QueryOutputSaveLocation)
              }else if (process.QueryOutputFormat == "Hbase") {
                // Save the processed myDF to obAcquire.QueryOutputSaveLocation in process.QueryOutputFormat format

                var colshm = process.Delimiter.split(",")
                var table = s"""{ "table":{"namespace":"default", "name":"""" + process.QueryOutputSaveLocation+""""},
                "rowkey":"key",
                "columns":{
                "key":{"cf":"rowkey", "col":"key", "type":"string"},
                """

                for (item <- colshm) {
                  var cols = """""""+item.split(" ")(0).split(":")(1).toString + """":{"cf":""""+item.split(" ")(0).split(":")(0).toString+"""", "col":""""+item.split(" ")(0).split(":")(1).toString + """", "type":""""+item.split(" ")(1) + """"},"""
                  table += cols
                }
                var newCatlog = table.dropRight(1)
                newCatlog += """ }}"""

                var Catalog = newCatlog.replaceAll("\\s+", " ").mkString
                println("\n\nHBase Output Catalog : " + Catalog + "\n")

                //myDF2.write.mode(SaveMode.Overwrite).format(process.QueryOutputFormat).save(process.QueryOutputSaveLocation)
                myDF2.na.fill("").write.options(Map(HBaseTableCatalog.tableCatalog -> Catalog)).format("org.apache.hadoop.hbase.spark").save()
              }else if(process.Delimiter.length() > 0){
                myDF2.write.mode(SaveMode.Overwrite).option("delimiter", process.Delimiter).csv(process.QueryOutputSaveLocation)
              }
            }
          }
        }


      }

      // Iterate though the hbasedelte_info , create Temporary spark dataframes and delete the data from hbase in sqlContext
      for (tbl <- obAcquire.hbasedelete_info) {
        println("Creating Temp table for Alias: " + tbl.alias)

        if(tbl.alias.length() > 0) {

          var colshm = tbl.columnsToRefer.split(",")
          var table =
            s"""{ "table":{"namespace":"default", "name":"""" + tbl.srcDBNmSrcTblNm +
              """"},
                      "rowkey":"key",
                      "columns":{
                      "key":{"cf":"rowkey", "col":"key", "type":"string"},
                      """

          for (item <- colshm) {
            var cols = """"""" + item.split(" ")(0).split(":")(1).toString + """":{"cf":"""" + item.split(" ")(0).split(":")(0).toString +"""", "col":"""" + item.split(" ")(0).split(":")(1).toString + """", "type":"""" + item.split(" ")(1) + """"},"""
            table += cols
          }
          var newCatlog = table.dropRight(1)
          newCatlog += """ }}"""

          var Catalog = newCatlog.replaceAll("\\s+", " ").mkString
          println("\n\nHBase Catalog : " + Catalog + "\n")

          var startTS = ""
          var endTS = ""

          if (tbl.startTS.length() > 0) {
            startTS = tbl.startTS
          } else {
            startTS = "0"
          }
          if (tbl.endTS.length() > 0) {
            endTS = tbl.endTS
          } else {
            endTS = System.currentTimeMillis().toString
          }

          var myDF5 = withCatalog(Catalog, startTS.toString(), endTS.toString())

          /* var myDF4 = spark.sqlContext.read.format("org.apache.hadoop.hbase.spark").options(Map("hbase.columns.mapping" ->
           tbl.columnsToAcquire,
           "hbase.table" -> tbl.srcDBNmSrcTblNm)).load() */

          myDF5.createOrReplaceTempView(tbl.alias + "_tmp")
          var myDF6_key = myDF5.sqlContext.sql("select key from " + tbl.alias + "_tmp " + tbl.alias + " " + tbl.filterCondition)
          myDF6_key.createOrReplaceTempView(tbl.alias)

          //var myDF6_count = myDF5.sqlContext.sql("select count(*) from " + tbl.alias + "_tmp " + tbl.alias + " " + tbl.filterCondition)
          var RecCount = myDF6_key.count.toInt

          if (RecCount > 0) {
            val sparkConf = new SparkConf()

            //val sc = new SparkContext(sparkConf)
            val sc = spark.sparkContext

            val conf = HBaseConfiguration.create()

            var ar = myDF6_key.rdd.map { r =>
              //val array = r.toSeq.toArray
              val array = Bytes.toBytes(r.mkString).toArray
              //val array = Array.emptyByteArray
              //array.copyToArray(Bytes.toBytes(r.toString())) // r.toSeq.toArray
              array.map(_.asInstanceOf[Byte])
            }

            println("Deleting records for Alias: " + tbl.alias + " Records :" + RecCount)
            println("Few Sample record for Alias: " + tbl.alias + " Records :" + myDF6_key.show(5))
            println("Byte Value record for Alias: " + tbl.alias + " Records :" + ar.take(5))

            val hbaseContext = new HBaseContext(sc, conf)
            hbaseContext.bulkDelete[Array[Byte]](ar,
              TableName.valueOf(tbl.srcDBNmSrcTblNm),
              putRecord => new Delete(putRecord), RecCount
            )

            println("Done Deleting records ")
          }

        }

      }

      // Iterate though the rdbms_store  and store in rdbms
      for (store <- obAcquire.database_info) {

        if (store.Query.length() > 0) {
          println("Creating Temp table for QueryAlias: " + store.QueryAlias)
          var myDF2 = spark.sql(store.Query)

          if (store.QueryAlias.length() > 0)
            myDF2.createOrReplaceTempView(store.QueryAlias)

          if (store.Url.length() > 0 && store.Driver.length() > 0 && store.UserName.length() > 0 && store.CredentialStore.length() > 0 && store.CredentialAlias.length() > 0 && store.TableName.length() > 0) {

            //Store into sql server
            val prop = new java.util.Properties
            prop.setProperty("driver", store.Driver)
            prop.setProperty("user", store.UserName)
            prop.setProperty("password", getCredentialSecret(store.CredentialStore, store.CredentialAlias, spark))

            if (store.SaveMode.length() >0 && store.SaveMode.toString().toLowerCase() == "append") {
              myDF2.write.mode(SaveMode.Append).jdbc(store.Url, store.TableName, prop)
            }
            else if (store.SaveMode.length() >0 && store.SaveMode.toString().toLowerCase() == "overwrite") {
              myDF2.write.mode(SaveMode.Overwrite).jdbc(store.Url, store.TableName, prop)
            }
            else
              {
                myDF2.write.mode(SaveMode.Append).jdbc(store.Url, store.TableName, prop)
              }
          }
        }
      }




    } catch {
      case e: Exception => {
        println("Exception in Processing Queries")
        e.printStackTrace()
        System.exit(3)
      }
    } finally {}

  }

  def getCredentialSecret(aCredentialStore: String, aCredentialAlias: String, spark: SparkSession): String = {
    val config = spark.sparkContext.hadoopConfiguration
    config.set(CredentialProviderFactory.CREDENTIAL_PROVIDER_PATH, aCredentialStore)
    String.valueOf(config.getPassword(aCredentialAlias))

  }


}
