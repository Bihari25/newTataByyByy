package com.optum.DataConsumer

import scala.io.Source
import scala.reflect.io._

class GlobalCfg {

  case class Acquisition_info(Type: String,
                              Driver : String,
                              Url : String,
                              UserName : String,
                              CredentialStore: String,
                              CredentialAlias: String,
                              srcDBNmSrcTblNm: String,
                              columnsToAcquire: String,
                              filterCondition: String,
                              startTS: String,
                              endTS: String,
                              alias: String)

  case class File_info(       Type: String,
                              ReadFile: String,
                              ReadFileFormat : String,
                              Delimiter: String,
                              Header: String,
                              InferSchema: String,
                              filterCondition: String,
                              alias: String)

  case class Processing_info(Query: String,
                             QueryAlias: String,
                             QueryOutputFormat: String,
                             Delimiter: String,
                             QueryOutputSaveLocation: String,
                             ReadFile: String,
                             ReadFileFormat: String,
                             FileAlias: String
                            )

  case class Reconcile_info(
                             ReadFile: String,
                             ReadFileFormat: String,
                             FileAlias: String,
                             Query: String,
                             QueryAlias: String,
                             QueryOutputFormat: String,
                             Delimiter: String,
                             QueryOutputSaveLocation: String,
                             EnabledOnFullLoad: String
                           )

  case class HBaseDelete_info(
                               srcDBNmSrcTblNm: String,
                               columnsToRefer: String,
                               filterCondition: String,
                               startTS: String,
                               endTS: String,
                               alias: String
                           )

  case class Database_info(
                            Query: String,
                            QueryAlias: String,
                            SaveMode: String,
                            Driver: String,
                            Url: String,
                            UserName: String,
                            CredentialStore: String,
                            CredentialAlias: String,
                            TableName: String
                          )

  case class AcquireConf(acquisition_info: List[Acquisition_info],file_info: List[File_info], processing_info: List[Processing_info], reconcile_info: List[Reconcile_info], hbasedelete_info: List[HBaseDelete_info],database_info:List[Database_info])

  def getJsonQueries(jsonCfg: String): String = {

    if (scala.reflect.io.File(scala.reflect.io.Path(jsonCfg)).exists == true)
      Source.fromFile(jsonCfg).getLines.mkString
    else "Error : Json File not present - " + jsonCfg

  }
}
