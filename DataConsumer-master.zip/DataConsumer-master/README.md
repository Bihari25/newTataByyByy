
# Data Consumer

Data Consumer is a flexible and configurable framework to consume data from datalake. This framework is reusable across applications which needs data from datalake , perform some business logic on it and deliver the same to downstream applications.

Data Consumer uses json configuration in which user can document all required queries to join, filter and pull data from DL snapshots. Data Consumer creates spark sql dataframes for each queries and executes them on yarn resource manager. Queue information can be provided while excuting the data consumer.

The data that is pulled can be further joined with either orc/parquet files and results can be stored in either orc or parquet file format. This is also done through the json configuration.

## Json Structure
Below image explains the configurable json structure and it's main components.

![alt text](Json_Structure.png)

## Sample Json File
Below image shows how a sample json looks like. Sample json file is made available in github (sample.json) which you can modify for your project requirement and try out a POC.

> Note : $ParamName are dynamic variables/values which are passed from outside the code. This will be replaced with passed values.

[this subtext](sample.json)

![alt text](Sample_Json.PNG)

## Data Flow
Below image explains the data flow from Datalake to an application using Data Consumer framework.

![alt text](Data_Flow.PNG)

### Technology Stack
+ Scala
+ Spark SQL 
+ Data Lake (Hadoop echo system)
+ Json

### Prerequisites

+ Scala
+ Spark
+ Edge Node to run Data Consumer and store data
+ Java IDE (Eclipse or IntelliJ IDEA)


### Usage example
Once the json configuration file is prepared with the details for execution, you can run Data Consumer with below command.

> export SPARK_CONF_DIR=path to spark conf dir which has hive connection details

> spark-submit --class com.optum.Acquire --executor-memory value --num-executors value --queue give_queue_name location_of_DataConsumer-SNAPSHOT.jar 'Location_of_Json_file.json' -runtype ['FULL' or 'INCR'] -param ParamName='param value' ...


## General DataConsumer Inquiries

Users can add themselves to the open flow titled [DataConsumer Framework Comments and Feedback][feedbackflow] in
Flowdock to post comments, questions, or give general feedback about the tool.

[feedbackflow]: https://www.flowdock.com/app/uhg/dataconsumer-framework-comments-and-feedback

## Contributors

* **Sandeep Kale**

## Contributing
Please refer to [Contribution Guidelines](CONTRIBUTING.md) for guidance on contributing to this project.
There is also a [pull request template](PULL_REQUEST_TEMPLATE) in this repo for guiding contributors through the pull request process.

## Maintainers (Authors)

- [Sandeep Kale](mailto:sandeep.kale@optum.com)

## Version History
> 1.0


## Acknowledgements

I would like to Thank Sumeer, James, Aparna, Shilpa, Gaurav and entire CCM Tenant team for feedback and supporting this framework.
