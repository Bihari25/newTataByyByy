package hive.test

import java.sql.Connection
import java.sql.ResultSet
import java.sql.DriverManager
import org.apache.spark.sql.SparkSession
import scala.collection.mutable.MutableList


object Hive_JDBC {
  System.setProperty("hadoop.home.dir", """C:\opt\mapr\hadoop\hadoop-2.7.0\""")
  case class StatsRec (
                        name: String,
                        surname: String
                      )
  def main(args: Array[String]) {
    //BasicConfigurator.configure()
    val spark = SparkSession
      .builder()
      .appName("HiveJDBC")
      .master("local")
      .getOrCreate()
    Class.forName("org.apache.hive.jdbc.HiveDriver")
    val conn: Connection = DriverManager.getConnection("jdbc:hive2://dbsls0324:10227/tomk", "tkrol1", """""")
    val res: ResultSet = conn.createStatement.executeQuery("select * from employees")
    val fetchedRes = MutableList[StatsRec]()
    while(res.next()) {
      var rec = StatsRec(res.getString("name"), res.getString("surname"))
      fetchedRes += rec
    }
    conn.close()

    import spark.implicits._

    val ds = fetchedRes.toDS()
    ds.show()
  }
}
