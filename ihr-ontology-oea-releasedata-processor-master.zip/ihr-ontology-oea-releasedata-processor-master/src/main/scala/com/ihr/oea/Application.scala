package com.ihr.oea

import org.apache.log4j.Logger
import org.apache.spark.sql.SparkSession
import com.ihr.oea.dataloader.QuestConsolidateData
import com.ihr.oea.common.GlobalConstants
import com.ihr.oea.common.GlobalContext
import com.ihr.oea.common.OESConfiguration
import com.ihr.oea.dataloader.LoincReleaseDataLoader
import com.ihr.oea.dataloader.QuestReleaseDataLoader
import com.ihr.oea.dataloader.SnomedReleaseDataLoader
import com.ihr.oea.dataloader.LabCorpReleaseDataLoader
import com.ihr.oea.dataloader.FDBReleaseDataLoader
import com.ihr.oea.dataloader.RxNormReleaseDataLoader

object Application {
  val log = Logger.getLogger(getClass.getName)
  def main(args: Array[String]) {
    if (args.length != 0) {
      try {
        log.info("Parameter recevied from sparkLuancher ::: ")
        args.foreach(println(_))
        val codeSetType = args(0).trim();
        val releaseId = args(1).trim();
        val releaseFile = args(2).trim()
        val oesConfiguration = new OESConfiguration
        oesConfiguration.readConfigFile();
        log.info("Starting OES Spark Data Loader for  release Id : " + releaseId)
        val globalContext = new GlobalContext
        val spark: SparkSession = globalContext.createSparkSession(oesConfiguration,codeSetType)
        if (codeSetType.equalsIgnoreCase(GlobalConstants.SNOMED)) {
          val releaseType = args(3).trim()
          val edition = args(4).trim()
          val snomedDataLoader = new SnomedReleaseDataLoader
          snomedDataLoader.loadSnomedReleaseFileData(spark, releaseId, releaseFile, releaseType, edition, oesConfiguration)
        } else if (codeSetType.equalsIgnoreCase(GlobalConstants.LOINC)) {
          val version = args(3).trim()
          val releaseDate = args(4).trim()
          val loincDataLoader = new LoincReleaseDataLoader
          loincDataLoader.loadLonicReleaseFileData(spark, releaseId, releaseFile, version, releaseDate, oesConfiguration)
        } else if (codeSetType.equalsIgnoreCase(GlobalConstants.QUEST)) {
          val releaseDate = args(4).trim()
          val questConsolidateData = new QuestConsolidateData
					questConsolidateData.consolidateQuestReleaseFileData(spark, releaseId, releaseFile, oesConfiguration)
          val questDataLoader = new QuestReleaseDataLoader
          questDataLoader.loadQuestReleaseFileData(spark, releaseId, releaseFile, releaseDate, oesConfiguration)
        }else if (codeSetType.equalsIgnoreCase(GlobalConstants.LABCORP)) {
          val releaseDate = args(4).trim()
          val labCorpReleaseDataLoader =new LabCorpReleaseDataLoader
          labCorpReleaseDataLoader.loadLabCorpReleaseFileData(spark, releaseId, releaseFile, releaseDate, oesConfiguration)
        }else if (codeSetType.equalsIgnoreCase(GlobalConstants.FDB)) {
          val releaseDate = args(4).trim()
          val fdbReleaseDataLoader =new FDBReleaseDataLoader
          fdbReleaseDataLoader.loadFDBReleaseFileData(spark, releaseId, releaseFile, releaseDate, oesConfiguration)
        }else if (codeSetType.equalsIgnoreCase(GlobalConstants.RXNORM)) {
          val releaseDate = args(4).trim()
          val rxNormReleaseDataLoader =new RxNormReleaseDataLoader
          rxNormReleaseDataLoader.loadRxNormReleaseFileData(spark, releaseId, releaseFile, releaseDate, oesConfiguration)
        }
        spark.stop()
        log.info("Completed OES Data Loader for release Id : " + releaseId)
      } catch {
        case e: Exception => log.error(s"Exception while processing dataloader :" + e.getMessage)
      }
    } else {
      log.info("No arguments found to dataloder from spark launcher.please check...")
      System.exit(1);
    }
  }
}
