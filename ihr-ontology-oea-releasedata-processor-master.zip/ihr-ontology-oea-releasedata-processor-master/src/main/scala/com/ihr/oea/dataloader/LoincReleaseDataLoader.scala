package com.ihr.oea.dataloader

import org.apache.log4j.Logger
import org.apache.spark.sql.SparkSession
import org.apache.spark.sql.functions._
import org.apache.spark.sql.functions.udf

import com.ihr.oea.common.DataLoaderUtil
import com.ihr.oea.common.GlobalConstants
import com.ihr.oea.common.OESConfiguration
import com.ihr.oea.common.SparkSQLConstants

class LoincReleaseDataLoader {
  val log = Logger.getLogger(getClass.getName)
  
	def loadLonicReleaseFileData(spark:SparkSession, releaseId:String, fileName:String, version:String,releaseDate:String, oesConfiguration:OESConfiguration) {
	  try{
	    log.info("Starting Loinc data loader  for releaseId :"+releaseId)
	    val util = new DataLoaderUtil
      val activeProfile = oesConfiguration.PROFILE
    	val releaseFolder = util.buildReleaseFolderPath(releaseId, fileName, oesConfiguration)
    	var loincFileName =  releaseFolder + GlobalConstants.LOINC_FILE_NAME
    	if(!activeProfile.equalsIgnoreCase(GlobalConstants.LOCAL_PROFILE)){
    	  loincFileName = loincFileName.substring(5)
    	}
      
      log.info("Loinc file path  : "+loincFileName)
      val getLoincFSN = udf((component:String, property:String, timeAspct:String, 
          system:String, scaleTyp:String, methodTyp:String)=>{
          var result = GlobalConstants.EMPTY_STRING
          var com = component; var prop = property; var time = timeAspct; var sys = system; var scale = scaleTyp;
          if(null == com || com.isEmpty())
            com = GlobalConstants.-
          if(null == prop || prop.isEmpty())
            prop = GlobalConstants.-
          if(null == time || time.isEmpty())
            time = GlobalConstants.-
          if(null == sys || sys.isEmpty())
            sys = GlobalConstants.-
          if(null == scale || scale.isEmpty())
            scale = GlobalConstants.-
          if(null== methodTyp || methodTyp.trim().isEmpty()){
            result = com.trim() + GlobalConstants.SEMI_COLON + prop.trim() + GlobalConstants.SEMI_COLON + 
                    time.trim() + GlobalConstants.SEMI_COLON + sys.trim() + GlobalConstants.SEMI_COLON + scale.trim()
          }
          else{
            result = com.trim() + GlobalConstants.SEMI_COLON + prop.trim() + GlobalConstants.SEMI_COLON + 
                    time.trim() + GlobalConstants.SEMI_COLON + sys.trim() + GlobalConstants.SEMI_COLON + scale.trim() + 
                    GlobalConstants.SEMI_COLON + methodTyp.trim()
          }
          if(result.startsWith(GlobalConstants.COLON_PATTERN))
            result = result.replaceFirst(GlobalConstants.COLON_PATTERN, GlobalConstants.EMPTY_STRING)
        
          if(result.endsWith(GlobalConstants.REVERSE_COLON_PATTERN))  
            result = result.substring(0, (result.length()-2))
        result 
      })
     
      log.info("Reading Loinc file for releaseId : "+releaseId)
      
    	val loincFullDF = util.loadCSVData(loincFileName, spark)
    
    	.filter(col(SparkSQLConstants.ORDER_OBS) === GlobalConstants.OBSERVATION || 
    	        col(SparkSQLConstants.ORDER_OBS) === GlobalConstants.ORDER ||
    	        col(SparkSQLConstants.ORDER_OBS) === GlobalConstants.BOTH)
    	.withColumn(SparkSQLConstants.PREFERRED_TERM, col(SparkSQLConstants.LONG_COMMON_NAME))
    	.withColumn(SparkSQLConstants.CONCEPT_ID, col(SparkSQLConstants.LOINC_NUM))
    	.withColumn(SparkSQLConstants.FSN, getLoincFSN(col(SparkSQLConstants.COMPONENT),col(SparkSQLConstants.PROPERTY),
    	                                               col(SparkSQLConstants.TIME_ASPCT),col(SparkSQLConstants.SYSTEM),
    	                                               col(SparkSQLConstants.SCALE_TYP),col(SparkSQLConstants.METHOD_TYP)))
    	                             
    	.select(
    	    SparkSQLConstants.CONCEPT_ID,
    	    SparkSQLConstants.PREFERRED_TERM,
    	    SparkSQLConstants.FSN,
    	    SparkSQLConstants.ORDER_OBS,
    	    SparkSQLConstants.CLASS,
    	    SparkSQLConstants.VERSIONLASTCHANGED,
    	    SparkSQLConstants.CHNG_TYPE,
    	    SparkSQLConstants.STATUS,
    	    SparkSQLConstants.SHORTNAME,
    	    SparkSQLConstants.VERSIONFIRSTRELEASED
    	    )
    	 .withColumn(SparkSQLConstants.LANGUAGE_CODE, lit(GlobalConstants.ENGLISH_CODE))
    	 .withColumn(SparkSQLConstants.RELEASE_ID, lit(releaseId))
    	 .withColumn(SparkSQLConstants.EFFECTIVE_TIME,when(col(SparkSQLConstants.VERSIONFIRSTRELEASED)===version,
    	     releaseDate).otherwise(null))
    	 .withColumn(SparkSQLConstants.REVISED_DATE, when(col(SparkSQLConstants.VERSIONLASTCHANGED)===version && 
    	         (col(SparkSQLConstants.CHNG_TYPE)===GlobalConstants.CHNG_MIN || col(SparkSQLConstants.CHNG_TYPE)===GlobalConstants.CHNG_MAJ),
    	         releaseDate).otherwise(null))
    	 .withColumn(SparkSQLConstants.RETIRED_DATE,when(col(SparkSQLConstants.VERSIONLASTCHANGED)===version && col(SparkSQLConstants.CHNG_TYPE)===GlobalConstants.CHNG_DEL,
    	     releaseDate).otherwise(null))
    	 
    	var loincObserveDF = 	loincFullDF.filter(col(SparkSQLConstants.ORDER_OBS) === GlobalConstants.OBSERVATION).cache()
    	var loincOrderDF = 	loincFullDF.filter(col(SparkSQLConstants.ORDER_OBS) === GlobalConstants.ORDER).cache()
    	var loincBothDF = 	loincFullDF.filter(col(SparkSQLConstants.ORDER_OBS) === GlobalConstants.BOTH).cache()
    	
    	loincObserveDF = loincObserveDF.union(loincBothDF)
    	.withColumn(SparkSQLConstants.TAXONOMY_FSN, lit(GlobalConstants.OBSERVATION)).cache()
    	
    	loincOrderDF = loincOrderDF.union(loincBothDF)
    	.withColumn(SparkSQLConstants.TAXONOMY_FSN, lit(GlobalConstants.ORDER)).cache()
    	 log.info("Generating final dataframe for releaseId :"+releaseId)
    	val loincFinalDF = loincObserveDF.union(loincOrderDF)
    	                    .withColumnRenamed(SparkSQLConstants.ORDER_OBS,SparkSQLConstants.ORDER_OBS_DB)
    	                    .withColumnRenamed(SparkSQLConstants.CLASS,SparkSQLConstants.CLASS_NAME)
    	                    .withColumnRenamed(SparkSQLConstants.VERSIONLASTCHANGED,SparkSQLConstants.VERSIONLASTCHANGED_DB)
    	                    .withColumnRenamed(SparkSQLConstants.CHNG_TYPE,SparkSQLConstants.CHNG_TYPE_DB)
    	                    .withColumnRenamed(SparkSQLConstants.STATUS,SparkSQLConstants.STATUS_DB)
    	                    .withColumnRenamed(SparkSQLConstants.SHORTNAME,SparkSQLConstants.SHORTNAME_DB)
    	                    .withColumnRenamed(SparkSQLConstants.VERSIONFIRSTRELEASED,SparkSQLConstants.VERSIONFIRSTRELEASED_DB)
    	
    	log.info("saving Loinc release data into mongoDB for releaseId : "+releaseId)
    	// write to mongoDB
    	util.saveReleaseConcepts(loincFinalDF, oesConfiguration)
      log.info("successfully saved  Loinc release data into mongoDB for releaseId : "+releaseId)
	  }catch{
	    	case e: Exception => log.error(s"Exception while running the data loader for release Id : "+releaseId)
	    	log.error(e.printStackTrace())
				throw e
		}
	}
}