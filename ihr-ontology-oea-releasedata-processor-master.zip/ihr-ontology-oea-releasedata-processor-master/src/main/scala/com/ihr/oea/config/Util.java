package com.ihr.oea.config;

import java.io.File;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.List;

import org.apache.poi.ss.usermodel.Workbook;
import org.apache.poi.ss.usermodel.WorkbookFactory;

public class Util {
	
	 public static String  NONQLS ="NONQLS.xlsx";
	 
	public static String getFileByName(String fileName, List<String> list) {
		String result = null;
		for (String name : list) {
			if(name.contains(fileName)) {
				result = name;
				break;
			}
		}
		return result;
	}
	public static List<String> readSheetNames(String fileName) {

		List<String> sheetNames = new ArrayList<>();

		File file = new File("/mapr" + fileName);
		Workbook wb;
		try {
			wb = WorkbookFactory.create(file);
			for (int i = 0; i < wb.getNumberOfSheets(); i++) {
				sheetNames.add(wb.getSheetName(i));
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		return sheetNames;
	}
	
	public static String getQuestFileByName(String fileName, List<String> list) {
		String result = null;
		for (String name : list) {
			String questFile = getQuestFileByName(name);
			if(questFile.equals(fileName)) {
				result = name;
				break;
			}
		}
		return result;
	}
	
	public static String getQuestFileByName( String name) {
		
			Path path = Paths.get(name);
			Path fName = path.getFileName(); 
		return fName.toString();
	}
	
	public static String removeExtension(String fileName) {
		if(fileName.equalsIgnoreCase(NONQLS)){
			fileName = NONQLS;
        }
		int last = fileName.lastIndexOf(".");
		return last >= 1 ? fileName.substring(0, last) : fileName;
	}

}