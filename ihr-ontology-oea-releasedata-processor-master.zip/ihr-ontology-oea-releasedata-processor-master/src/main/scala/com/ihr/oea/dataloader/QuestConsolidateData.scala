package com.ihr.oea.dataloader

import java.nio.file.FileSystems
import java.nio.file.Files
import java.util.ArrayList
import java.io.File
import scala.collection.JavaConverters.asScalaIteratorConverter
import scala.collection.mutable.WrappedArray
import org.apache.log4j.Logger
import org.apache.spark.sql.SparkSession
import org.apache.spark.sql.functions.lit
import org.apache.spark.sql.DataFrame
import com.ihr.oea.common.GlobalConstants
import com.ihr.oea.common.OESConfiguration
import com.ihr.oea.common.SparkSQLConstants
import com.ihr.oea.config.Util
import org.apache.spark.sql._ 
import com.mongodb.spark._
import com.mongodb.spark.config._ 
import org.apache.hadoop.fs._
import org.apache.hadoop.fs._
import org.apache.hadoop.fs.FileUtil
import org.apache.hadoop.fs.FileSystem;
import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.Path;
import org.apache.spark.sql.types.StructType
import org.apache.spark.sql.types.StringType
import org.apache.spark.sql.types.StructField

class QuestConsolidateData {
  
  val log = Logger.getLogger(getClass.getName)
  
  def consolidateQuestReleaseFileData(spark:SparkSession,   releaseId:String, fileName:String, oesConfiguration:OESConfiguration) {
    
    log.info("Starting Quest data loader  for releaseId :"+fileName)
     try{
       val schema = StructType(
      Array(
        StructField(SparkSQLConstants.LAB_CODE, StringType, true),
        StructField(SparkSQLConstants.TEST_CD, StringType, true),
        StructField(SparkSQLConstants.TEST_NAME, StringType, true),
        StructField( SparkSQLConstants.CPT, StringType, true),
        StructField(SparkSQLConstants.ANALYTE_CODE, StringType, true),
        StructField(SparkSQLConstants.STANDARD_RESULT_CODE, StringType, true),
        StructField(SparkSQLConstants.STANDARD_RESULT_CODE_NAME, StringType, true),
        StructField(SparkSQLConstants.LOINC_NUMBER, StringType, true),
        StructField(SparkSQLConstants.REGENSTRIEF_COMPONENT_NAMES, StringType, true),
        StructField(SparkSQLConstants.TYPE, StringType, true))) 
        
				val activeProfile = oesConfiguration.PROFILE
				val releaseFolder = oesConfiguration.RELEASE_BASE_PATH + releaseId.trim() + GlobalConstants.FORWARD_SLASH + 
				GlobalConstants.UNZIP_FOLDER + GlobalConstants.FORWARD_SLASH + fileName + GlobalConstants.FORWARD_SLASH ;
			val configuration = new Configuration();  
		      val fs = FileSystem.get(configuration);
			var headerFlag = true;
				log.info("releaseFolder  :"+releaseFolder )				
				val dir = FileSystems.getDefault.getPath(releaseFolder)
				val list = Files.walk(dir).iterator().asScala.filter(Files.isRegularFile(_)).toList
				val javaList = new ArrayList[String]
						for(file <- list) {
							var fileName :String = file.toFile().getAbsolutePath.toString()
							println(fileName);
									if(activeProfile.equalsIgnoreCase(GlobalConstants.LOCAL_PROFILE)){
										javaList.add(fileName)
									}else{
											val requiredFileName : String =	fileName.substring(5)
													javaList.add(requiredFileName)
										}
						}
		val questFiles= javaList.toArray();
		val dstPath = GlobalConstants.MAPRFS+releaseFolder.substring(5)
		val srcCSVPath =  oesConfiguration.RELEASE_BASE_PATH + releaseId.trim() + GlobalConstants.FORWARD_SLASH + 
				GlobalConstants.UNZIP_FOLDER + GlobalConstants.FORWARD_SLASH
		var csvFilePath = GlobalConstants.MAPRFS+srcCSVPath.substring(5)+GlobalConstants.CONSOLIDATE
		
		for(questFileName <- questFiles) {
      	          val fname :String = questFileName.toString()
    							val questType = Util.getQuestFileByName(fname);
      	          
      	         val sheetNames = Util.readSheetNames(fname).toArray();
      	         
    			 for(sheetName <- sheetNames) {
    							val sName :String = sheetName.toString()
    					
    					    if(!sName.equals(GlobalConstants.SQL)){
    							val df =   spark.read
                      .format(GlobalConstants.SPARK_EXCEL_IMPORT)
                      .option(GlobalConstants.LOCATION, fname)
                      .option(GlobalConstants.USE_HEADER, GlobalConstants.TRUE)
                      .option(GlobalConstants.TREAT_EMPTY,  GlobalConstants.TRUE)
                      .option(GlobalConstants.INFER_SCHEMA,  GlobalConstants.FALSE)
                      .option(GlobalConstants.ADD_COLOR_COL, GlobalConstants.FALSE)
                      .option(GlobalConstants.SHEET_NAME, sName)
                      .option(GlobalConstants.ENCODING, GlobalConstants.UTF_8)
                      .option(GlobalConstants.CHARSET,GlobalConstants.UTF_8)
                      .schema(schema)
                      .load(fname)
               
            df.createOrReplaceTempView("dframe")
            val typeVal = Util.removeExtension(questType) 
            val dataFrame  = df.withColumn(GlobalConstants.TYPE,lit(typeVal))
            val dframeCol = dataFrame.select(GlobalConstants.STAR)
            if(headerFlag){
            		val header = dframeCol.schema.fieldNames.reduceLeft(_+GlobalConstants.COMMA+_)
                val f = fs.create(new Path(csvFilePath+GlobalConstants.DOT_CSV_FORMAT + GlobalConstants.FORWARD_SLASH+GlobalConstants.HEADER))
                f.write(header.getBytes)
                val newline = GlobalConstants.NEXT_LINE.getBytes(GlobalConstants.UTF_8);
                f.write(newline)
                f.close()              
                headerFlag = false
            }
			     val filePath = new File(csvFilePath)
    			      if(filePath.exists() && filePath.isDirectory)
	          		{
      				 dframeCol.write.option(GlobalConstants.HEADER,GlobalConstants.FALSE) .option(GlobalConstants.FILE_TYPE, GlobalConstants.CSV_FORMAT) .mode(GlobalConstants.APPENED_MODE).option(GlobalConstants.IGNORE_LEADING_SPACES,GlobalConstants.FALSE).option(GlobalConstants.IGNORE_TRAILING_SPACES,GlobalConstants.FALSE).option(GlobalConstants.SEPARATOR,GlobalConstants.COMMA)
              				.csv(csvFilePath+GlobalConstants.DOT_CSV_FORMAT)
    			      }else{
    			       dframeCol.write.option(GlobalConstants.HEADER,GlobalConstants.FALSE) .option(GlobalConstants.FILE_TYPE, GlobalConstants.CSV_FORMAT) .mode(GlobalConstants.APPENED_MODE).option(GlobalConstants.IGNORE_LEADING_SPACES,GlobalConstants.FALSE).option(GlobalConstants.IGNORE_TRAILING_SPACES,GlobalConstants.FALSE).option(GlobalConstants.SEPARATOR,GlobalConstants.COMMA)
              				.csv(csvFilePath+GlobalConstants.DOT_CSV_FORMAT)
    			          }
    						}
    			 }
       }
		      
     		  FileUtil.copyMerge(fs, new Path(csvFilePath+GlobalConstants.DOT_CSV_FORMAT), fs, new Path(dstPath), false, configuration, GlobalConstants.EMPTY_STRING)
		 		
  		
  }catch{
	    	case e: Exception => log.error(s"Exception while running the data loader for release Id : "+releaseId)
	    	log.error(e)
				throw e
		}
  }


 }    
