package com.ihr.oea.common

import java.util.Properties
import org.apache.log4j.Logger

class OESConfiguration {
  val log = Logger.getLogger(getClass.getName)
  var MONGO_URL = GlobalConstants.EMPTY_STRING
	var TRANSITIVE_CLOSURE_FILE = GlobalConstants.EMPTY_STRING
	var DATABASE_NAME = GlobalConstants.EMPTY_STRING
	var PROFILE = GlobalConstants.EMPTY_STRING
	var RELEASE_BASE_PATH = GlobalConstants.EMPTY_STRING

  def readConfigFile(){
	  try{
  			val instream = this.getClass.getClassLoader.getResourceAsStream(GlobalConstants.APPLICATION_CONF_FILE)
  			val prop = new Properties
  			prop.load(instream)
  			MONGO_URL = prop.getProperty(GlobalConstants.MONGO_URL_PROPERTY).trim()
   			TRANSITIVE_CLOSURE_FILE = prop.getProperty(GlobalConstants.TRANSTIVE_CLOSURE_FILE_PROPERTY).trim()
  			DATABASE_NAME = prop.getProperty(GlobalConstants.DATABASE_NAME_PROPERTY).trim()
  			PROFILE = prop.getProperty(GlobalConstants.PROFILE_PROPERTY).trim()
  			RELEASE_BASE_PATH = prop.getProperty(GlobalConstants.RELEASE_BASE_PATH_PROPERTY).trim()
  	}
   catch {
    case e: Exception => log.error(s"Exception while reading configuration file : \n" + e)
		throw e
    }
  }
}