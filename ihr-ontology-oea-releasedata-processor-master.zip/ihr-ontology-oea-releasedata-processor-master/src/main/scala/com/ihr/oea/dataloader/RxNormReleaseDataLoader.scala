package com.ihr.oea.dataloader

import org.apache.log4j.Logger
import org.apache.spark.sql.SparkSession
import org.apache.spark.sql.functions._
import org.apache.spark.sql.functions.col
import org.apache.spark.sql.functions.udf
import java.nio.file.FileSystems
import java.nio.file.Files
import java.io.File
import org.apache.hadoop.fs._
import org.apache.hadoop.fs._
import org.apache.hadoop.fs.FileUtil
import org.apache.hadoop.fs.FileSystem;
import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.Path;
import com.ihr.oea.common.DataLoaderUtil
import com.ihr.oea.common.GlobalConstants
import com.ihr.oea.common.OESConfiguration
import com.ihr.oea.common.SparkSQLConstants
import org.apache.spark.sql.expressions.Window
import org.apache.spark.sql.functions.udf
import org.apache.spark.sql.types.StringType
import org.apache.spark.sql.types.StructField
import org.apache.spark.sql.types.StructType

class RxNormReleaseDataLoader {
  val log = Logger.getLogger(getClass.getName)
  


  def loadRxNormReleaseFileData(spark: SparkSession, releaseId: String, fileName: String, releaseDate: String, oesConfiguration: OESConfiguration) {
    try {
      log.info("Starting RxNorm data loader  for releaseId :" + releaseId)
      
  def buildRxNConsoSchema(): StructType = {
    val rxNConsoSchema = StructType(
      Array(
         StructField(SparkSQLConstants.RXCUI, StringType, true),
          StructField(SparkSQLConstants.LAT, StringType, true),
          StructField(SparkSQLConstants.TS, StringType, true),
          StructField(SparkSQLConstants.LUI, StringType, true),
          StructField(SparkSQLConstants.STT, StringType, true),
          StructField(SparkSQLConstants.SUI, StringType, true),
          StructField(SparkSQLConstants.ISPREF, StringType, true),
          StructField(SparkSQLConstants.RXAUI, StringType, true),
          StructField(SparkSQLConstants.SAUI, StringType, true),
          StructField(SparkSQLConstants.SCUI, StringType, true),
          StructField(SparkSQLConstants.SDU, StringType, true),          
          StructField(SparkSQLConstants.SAB, StringType, true),
          StructField(SparkSQLConstants.TTY, StringType, true),
          StructField(SparkSQLConstants.CODE, StringType, true),
          StructField(SparkSQLConstants.STR, StringType, true),
          StructField(SparkSQLConstants.SRL, StringType, true),
          StructField(SparkSQLConstants.SUPPRESS, StringType, true),
          StructField(SparkSQLConstants.CVF, StringType, true),
          StructField(SparkSQLConstants.DUMMY, StringType, true)))
          
          rxNConsoSchema
  }
      
  def buildRxNSatSchema(): StructType = {
    val rxNSatSchema = StructType(
      Array(
         StructField(SparkSQLConstants.RXCUI, StringType, true),
         StructField(SparkSQLConstants.LUI, StringType, true),
         StructField(SparkSQLConstants.SUI, StringType, true),
         StructField(SparkSQLConstants.RXAUI, StringType, true),
         StructField(SparkSQLConstants.STYPE, StringType, true),
         StructField(SparkSQLConstants.CODE, StringType, true),
         StructField(SparkSQLConstants.ATUI, StringType, true),
         StructField(SparkSQLConstants.SATUI, StringType, true),
         StructField(SparkSQLConstants.ATN, StringType, true),
         StructField(SparkSQLConstants.SAB, StringType, true), 
         StructField(SparkSQLConstants.ATV, StringType, true), 
          StructField(SparkSQLConstants.SUPPRESS, StringType, true),
          StructField(SparkSQLConstants.CVF, StringType, true),
          StructField(SparkSQLConstants.DUMMY, StringType, true)))
       rxNSatSchema
  }
  
   spark.sql(GlobalConstants.CASESENSITIVE)
      spark.conf.set(GlobalConstants.BROADCASTTIMEOUT, 36000)
      spark.conf.set(GlobalConstants.WHOLESTAGE, false)
      spark.conf.set(GlobalConstants.OFFHEAP_ENABLED, true)
      spark.conf.set(GlobalConstants.OFFHEAP_SIZE, GlobalConstants.FORTY_G)
      
      val util = new DataLoaderUtil
      val configuration = new Configuration();
      val fs = FileSystem.get(configuration);
      val activeProfile = oesConfiguration.PROFILE
      val releaseFolder = util.buildRxNormReleaseFolderPath(releaseId, fileName, oesConfiguration)
      var rxnConso = releaseFolder + GlobalConstants.RXNCONSO_RRF 
      var rxnSat = releaseFolder + GlobalConstants.RXNSAT_RRF 
	  if (!activeProfile.equalsIgnoreCase(GlobalConstants.LOCAL_PROFILE)) {
        rxnConso = rxnConso.substring(5)
        rxnSat = rxnSat.substring(5)
      }
      log.info("Starting RxNorm data loader  for rxnorm conso file reading :" + rxnConso)
      val RXNCONSO = util.loadFDBTXTData(rxnConso, GlobalConstants.PIPE, spark,buildRxNConsoSchema())
      
      RXNCONSO.createOrReplaceTempView(SparkSQLConstants.RXNCONSO) 
      val rxnormfilter1 = spark.sql(SparkSQLConstants.RXNORM_LEVEL1)
      rxnormfilter1.createOrReplaceTempView(SparkSQLConstants.RXNCONSO_F1)
      
      val rxnormfilter2 = spark.sql(SparkSQLConstants.RXNORM_LEVEL2)
      rxnormfilter2.createOrReplaceTempView(SparkSQLConstants.RXNCONSO_F2)
      
      val rxnormfilter3 = spark.sql(SparkSQLConstants.RXNORM_LEVEL3)
      rxnormfilter3.createOrReplaceTempView(SparkSQLConstants.RXNCONSO_F3)
      
      val rxconsofinal = spark.sql(SparkSQLConstants.RXNORM_FINAL)
                          
      log.info("Starting RxNorm data loader  for rxnorm sat file reading :" + rxnSat)
      val RXNSAT = util.loadFDBTXTData(rxnSat, GlobalConstants.PIPE, spark,buildRxNSatSchema())
       RXNSAT.createOrReplaceTempView(SparkSQLConstants.RXNSAT) 
       
       val rxnsatfinal = spark.sql(SparkSQLConstants.RXNSAT_FINAL)  
       val rxnormfinaldf = rxconsofinal.join(rxnsatfinal, rxnsatfinal(SparkSQLConstants.RXCUI) === rxconsofinal(SparkSQLConstants.RXCUI), "left")
        .withColumn(SparkSQLConstants.RELEASE_ID, lit(releaseId))
        .withColumn(SparkSQLConstants.EFFECTIVE_TIME, lit(releaseDate))
	.withColumn(SparkSQLConstants.CONCEPT_ID, rxconsofinal(SparkSQLConstants.RXCUI))
	.withColumn(SparkSQLConstants.TAXONOMY_FSN, lit(SparkSQLConstants.RXNORM))
        

      log.info("Generated processed rxNorm data for releaseId :" + releaseId)
      // write to mongoDB
      util.saveReleaseConcepts(rxnormfinaldf, oesConfiguration)
     
      
      log.info("saving RxNorm processed release data into mongoDB for releaseId : " + releaseId)
      
    } catch {
      case e: Exception =>
        log.error(s"Exception while running the RxNorm data loader for release Id : " + e.printStackTrace())
        log.error(e.printStackTrace())
        throw e
    }
  }
}
