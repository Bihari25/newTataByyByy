package com.optum.hive.avro

import java.io.{BufferedWriter, File, FileWriter}

import org.apache.spark.sql.{SaveMode, SparkSession}

object GetAvroSchema {

  def main(args: Array[String]): Unit = {
    val spark = SparkSession.builder().appName("GetAvroSchemaFromHive").master("yarn").config("hive.metastore.uris", "thrift://dbsls0306.uhc.com:11555").enableHiveSupport().getOrCreate()

    val df = spark.sql("select * from ocd_cdf_dev.provider limit 10")

    val outputpath = "/datalake/optum/optuminsight/d_ocd/dev/developer/ckoneru/providerAvro"
    df.write.mode(SaveMode.Overwrite).option("header","true").format("com.databricks.spark.avro").save(outputpath)
    val files = new File("/mapr"+outputpath)
    val children = files.list

    var filename = ""
    for (file <- children) {
      if (!file.contains("SUCCESS")) {
        import org.apache.avro.file.DataFileReader
        import org.apache.avro.generic.GenericDatumReader
        import org.apache.avro.generic.GenericRecord
        import org.apache.avro.io.DatumReader
        val datumReader = new GenericDatumReader[GenericRecord]
        val dataFileReader = new DataFileReader(new File("/mapr"+outputpath + "/" + file), datumReader)
        val schema = dataFileReader.getSchema
        System.out.println(schema.toString)
        writeFile("/mapr/datalake/optum/optuminsight/d_ocd/dev/developer/ckoneru/providerAvro/provider-schema.avsc"
          ,schema.toString)
      }
    }
  }

  def writeFile(filename: String, s: String): Unit = {
    val file = new File(filename)
    val bw = new BufferedWriter(new FileWriter(file))
    bw.write(s)
    bw.close()
  }

}
