package com.optum.reuse.scala.udf

import com.optum.reuse.util.{EncryptionUtil, Loggable}
import javax.crypto.Cipher
import org.apache.commons.codec.binary.Base64
import javax.crypto.spec.IvParameterSpec
import org.apache.spark.sql.api.java.UDF2


class EncryptUDF extends Loggable with UDF2[String, String, String]{
  def call(key: String, value: String): String = {
    val cipher: Cipher = Cipher.getInstance("AES/CBC/PKCS5Padding")
    cipher.init(Cipher.ENCRYPT_MODE, EncryptionUtil.keyToSpec(key), new IvParameterSpec(new Array[Byte](16)))
    Base64.encodeBase64String(cipher.doFinal(value.getBytes("UTF-8")))
  }

}

