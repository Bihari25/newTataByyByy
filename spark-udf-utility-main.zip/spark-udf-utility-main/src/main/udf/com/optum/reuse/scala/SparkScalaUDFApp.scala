package com.optum.reuse.scala

import java.lang.reflect.ParameterizedType

import com.optum.reuse.UDFDriver
import com.optum.reuse.exception.{
  InvalidInputException,
  InvalidReturnDataTypeException,
  InvalidUserDefinedFunctionException,
  UDFRegistrationException
}
import com.optum.reuse.util.Loggable
import org.apache.log4j.Level
import org.apache.spark.sql.SparkSession
import org.apache.spark.sql.api.java._
import org.apache.spark.sql.types._

import scala.util.{Success, Try}

case class SparkScalaUDFApp()
    extends Loggable
    with Serializable
    with UDFDriver {

  /**
    * Generic method that resolves the UDF to be used
    * and auto initializes the DataType
    * @param spark
    * @param fqClassPath
    * @return
    */
  def registerScalaUDF(
      spark: SparkSession,
      fqClassPath: String
  ): SparkSession = {
    val clazz = Class.forName(fqClassPath)

    val functionName: Try[String] = Try {
      clazz.getCanonicalName.split("\\.").last
    }

    if (functionName.isFailure) {
      throw new InvalidUserDefinedFunctionException(
        "Function name is not valid."
      )
    }

    val definedInterfaces = clazz.getAnnotatedInterfaces

    val rType: Try[DataType] = Try {
      definedInterfaces.toList
        .map(a => {
          if (a.getType.getTypeName.contains("UDF")) {
            val typeName = a.getType.getTypeName
            val returnType = typeName
              .substring(typeName.indexOf("<") + 1, typeName.indexOf(">"))
              .split(",")
              .last
              .split("\\.")
              .last
            applyValueTypeConversion(returnType)
          }
        })
        .last
        .asInstanceOf[DataType]
    }

    if (rType.isFailure) {
      throw new InvalidReturnDataTypeException("Invalid return type on UDF.")
    }

    val udfInterfaces = clazz.getGenericInterfaces
      .filter(_.isInstanceOf[ParameterizedType])
      .map(_.asInstanceOf[ParameterizedType])
      .filter(e =>
        e.getRawType.isInstanceOf[Class[_]] && e.getRawType
          .asInstanceOf[Class[_]]
          .getCanonicalName
          .startsWith("org.apache.spark.sql.api.java.UDF")
      )
    if (udfInterfaces.length == 0) {
      throw new UDFRegistrationException("No interfaces defined in the UDF.")
    } else if (udfInterfaces.size > 1) {
      throw new UDFRegistrationException(
        "UDF has multiple interfaces defined. It should only have one interface."
      )
    } else {
      try {

        val udf = clazz.newInstance()
        udfInterfaces(0).getActualTypeArguments.length match {
          case 1 =>
            spark.udf.register(
              functionName.get,
              udf.asInstanceOf[UDF0[_]],
              rType.get
            )
          case 2 =>
            spark.udf.register(
              functionName.get,
              udf.asInstanceOf[UDF1[_, _]],
              rType.get
            )
          case 3 =>
            spark.udf.register(
              functionName.get,
              udf.asInstanceOf[UDF2[_, _, _]],
              rType.get
            )
          case 4 =>
            spark.udf.register(
              functionName.get,
              udf.asInstanceOf[UDF3[_, _, _, _]],
              rType.get
            )
          case 5 =>
            spark.udf.register(
              functionName.get,
              udf.asInstanceOf[UDF4[_, _, _, _, _]],
              rType.get
            )
          case 6 =>
            spark.udf.register(
              functionName.get,
              udf.asInstanceOf[UDF5[_, _, _, _, _, _]],
              rType.get
            )
          case 7 =>
            spark.udf.register(
              functionName.get,
              udf.asInstanceOf[UDF6[_, _, _, _, _, _, _]],
              rType.get
            )
          case 8 =>
            spark.udf.register(
              functionName.get,
              udf.asInstanceOf[UDF7[_, _, _, _, _, _, _, _]],
              rType.get
            )
          case 9 =>
            spark.udf.register(
              functionName.get,
              udf.asInstanceOf[UDF8[_, _, _, _, _, _, _, _, _]],
              rType.get
            )
          case 10 =>
            spark.udf.register(
              functionName.get,
              udf.asInstanceOf[UDF9[_, _, _, _, _, _, _, _, _, _]],
              rType.get
            )
          case 11 =>
            spark.udf.register(
              functionName.get,
              udf.asInstanceOf[UDF10[_, _, _, _, _, _, _, _, _, _, _]],
              rType.get
            )
          case 12 =>
            spark.udf.register(
              functionName.get,
              udf.asInstanceOf[UDF11[_, _, _, _, _, _, _, _, _, _, _, _]],
              rType.get
            )
          case 13 =>
            spark.udf.register(
              functionName.get,
              udf.asInstanceOf[UDF12[_, _, _, _, _, _, _, _, _, _, _, _, _]],
              rType.get
            )
          case 14 =>
            spark.udf.register(
              functionName.get,
              udf.asInstanceOf[UDF13[_, _, _, _, _, _, _, _, _, _, _, _, _, _]],
              rType.get
            )
          case 15 =>
            spark.udf.register(
              functionName.get,
              udf.asInstanceOf[
                UDF14[_, _, _, _, _, _, _, _, _, _, _, _, _, _, _]
              ],
              rType.get
            )
          case 16 =>
            spark.udf.register(
              functionName.get,
              udf.asInstanceOf[
                UDF15[_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _]
              ],
              rType.get
            )
          case 17 =>
            spark.udf.register(
              functionName.get,
              udf.asInstanceOf[
                UDF16[_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _]
              ],
              rType.get
            )
          case 18 =>
            spark.udf.register(
              functionName.get,
              udf.asInstanceOf[
                UDF17[_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _]
              ],
              rType.get
            )
          case 19 =>
            spark.udf.register(
              functionName.get,
              udf.asInstanceOf[
                UDF18[_, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _, _]
              ],
              rType.get
            )
          case 20 =>
            spark.udf.register(
              functionName.get,
              udf.asInstanceOf[UDF19[
                _,
                _,
                _,
                _,
                _,
                _,
                _,
                _,
                _,
                _,
                _,
                _,
                _,
                _,
                _,
                _,
                _,
                _,
                _,
                _
              ]],
              rType.get
            )
          case 21 =>
            spark.udf.register(
              functionName.get,
              udf.asInstanceOf[UDF20[
                _,
                _,
                _,
                _,
                _,
                _,
                _,
                _,
                _,
                _,
                _,
                _,
                _,
                _,
                _,
                _,
                _,
                _,
                _,
                _,
                _
              ]],
              rType.get
            )
          case 22 =>
            spark.udf.register(
              functionName.get,
              udf.asInstanceOf[UDF21[
                _,
                _,
                _,
                _,
                _,
                _,
                _,
                _,
                _,
                _,
                _,
                _,
                _,
                _,
                _,
                _,
                _,
                _,
                _,
                _,
                _,
                _
              ]],
              rType.get
            )
          case 23 =>
            spark.udf.register(
              functionName.get,
              udf.asInstanceOf[UDF22[
                _,
                _,
                _,
                _,
                _,
                _,
                _,
                _,
                _,
                _,
                _,
                _,
                _,
                _,
                _,
                _,
                _,
                _,
                _,
                _,
                _,
                _,
                _
              ]],
              rType.get
            )
          case n =>
            throw new UDFRegistrationException(
              "Invalid number of arguments in the UDF,Arguments should be between 0 - 22."
            )
        }
      } catch {
        case exception: Exception =>
          throw new UDFRegistrationException(exception.getLocalizedMessage)
      }
    }
    spark
  }

  def applyValueTypeConversion(inputType: String): DataType = {
    inputType.toLowerCase match {
      case "byte" => org.apache.spark.sql.types.ByteType
      case "boolean" => org.apache.spark.sql.types.BooleanType
      case "double" => org.apache.spark.sql.types.DoubleType
      case "integer" => org.apache.spark.sql.types.IntegerType
      case "long" => org.apache.spark.sql.types.LongType
      case "string" => org.apache.spark.sql.types.StringType

      /*
      case "char" => org.apache.spark.sql.types.CharType.asInstanceOf[DataType]
      case "map" => org.apache.spark.sql.types.MapType.apply(StringType, StringType)
      case "null" => org.apache.spark.sql.types.NullType
      case "array" => org.apache.spark.sql.types.ArrayType.apply(StringType)
      case "object" => org.apache.spark.sql.types.ObjectType.apply(classOf[inputType.type ])
      case "short" => org.apache.spark.sql.types.ShortType
      case "SQLUserDefinedType" => org.apache.spark.sql.types.SQLUserDefinedType.asInstanceOf[DataType]
      case "struct" => org.apache.spark.sql.types.StructType.asInstanceOf[DataType]
       */

      case _ =>
        throw new InvalidInputException("invalid return data type on UDF.")
    }
  }

}
