package com.optum.reuse.scala.udf

import com.optum.reuse.util.{EncryptionUtil, Loggable}
import javax.crypto.Cipher
import javax.crypto.spec.IvParameterSpec
import org.apache.commons.codec.binary.Base64
import org.apache.spark.sql.api.java.UDF2

class DecryptUDF extends Loggable with UDF2[String, String, String]{
  def call(key: String, encryptedValue: String): String = {
    val cipher: Cipher = Cipher.getInstance("AES/CBC/PKCS5PADDING")
    cipher.init(Cipher.DECRYPT_MODE, EncryptionUtil.keyToSpec(key), new IvParameterSpec(new Array[Byte](16)))
    new String(cipher.doFinal(Base64.decodeBase64(encryptedValue)))
  }
}
