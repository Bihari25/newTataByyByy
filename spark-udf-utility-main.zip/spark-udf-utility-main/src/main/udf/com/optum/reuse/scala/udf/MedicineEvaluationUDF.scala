package com.optum.reuse.scala.udf

import com.optum.reuse.util.Loggable
import org.apache.spark.sql.api.java.UDF1

class MedicineEvaluationUDF extends Loggable with UDF1[String, String]{
  def call(symptoms: String): String = {
    symptoms match {
      case "pains" => "Advil"
      case "chill" => "Advil"
      case "cough" => "Tylenol"
      case _ => "No medicine at this time..!"
    }
  }
}
