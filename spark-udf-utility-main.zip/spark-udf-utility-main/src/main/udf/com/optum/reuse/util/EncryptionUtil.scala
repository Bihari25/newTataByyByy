package com.optum.reuse.util

import java.security.MessageDigest
import java.util

import javax.crypto.spec.SecretKeySpec

object EncryptionUtil {
  private val SALT: String = "jMhKlOuJnM34G6NHkqo9V010GhLAqOpF0BePojHgh1HgNg8^72k"
  def keyToSpec(key: String): SecretKeySpec = {
    var keyBytes: Array[Byte] = (key + SALT).getBytes("UTF-8")
    val sha: MessageDigest = MessageDigest.getInstance("SHA-256")
    keyBytes = sha.digest(keyBytes)
    keyBytes = util.Arrays.copyOf(keyBytes, 16)
    new SecretKeySpec(keyBytes, "AES")
  }

}
