package com.optum.reuse

import com.optum.reuse.util.{AppUtil, Loggable}
import org.apache.log4j.Level
import org.apache.spark.sql.SparkSession

object ManagedApplication extends Loggable {

  var hasErrors = false

  implicit var spark: SparkSession = _

  def init(): SparkSession = {
    spark = SparkSession.builder().master("local[1]").getOrCreate()
    spark.sparkContext.setLogLevel("WARN")
    applicationLogger.setLevel(Level.ALL)
    info("=== UDF Application Begins ===")
    spark
  }

  def main(args: Array[String]): Unit = {

    val sparkSession = init()

    val udfUtil = AppUtil(applicationLogger)

    try {

      udfUtil.findAndRegisterUDFOnClassPath(sparkSession, args(0))

    } catch {
      case e: Throwable =>
        applicationLogger.error("UDFs registration failed.", e)
        hasErrors = true
    } finally {
    }

    if (hasErrors) sys.exit(1) else sys.exit(0)
  }

}
