package com.optum.reuse

import org.apache.spark.sql.SparkSession
import org.apache.spark.sql.types.DataType

trait UDFDriver {
  def registerScalaUDF(spark: SparkSession, fqClassPath: String): SparkSession
  def applyValueTypeConversion(inputType: String): DataType
}
