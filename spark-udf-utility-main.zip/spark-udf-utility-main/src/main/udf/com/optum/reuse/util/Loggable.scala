package com.optum.reuse.util

import org.apache.log4j.{Level, Logger, MDC}

trait Loggable {

  @transient private lazy val logger = Logger.getLogger(getClass)

  @transient protected lazy val applicationLogger: Logger = Logger.getLogger("com.optum.udf")

  def getUDFLogLevel: Level = {
    var logger = applicationLogger

    while (logger != null && logger.getLevel == null) {
      logger = logger.getParent.asInstanceOf[Logger]
    }

    logger.getLevel
  }

  protected def info(msg: => String): Unit = {
    logger.info(msg)
  }

  protected def debug(msg: => String): Unit = {
    logger.debug(msg)
  }

  protected def warn(msg: => String): Unit = {
    logger.warn(msg)
  }

  protected def warn(msg: => String, e: Throwable): Unit = {
    logger.warn(msg, e)
  }

  protected def error(msg: => String): Unit = {
    logger.error(msg)
  }

  protected def error(msg: => String, e: Throwable): Unit = {
    logger.error(msg, e)
  }
}
