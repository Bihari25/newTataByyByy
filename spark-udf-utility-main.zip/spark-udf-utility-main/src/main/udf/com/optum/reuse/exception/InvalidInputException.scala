package com.optum.reuse.exception

import scala.util.control.NoStackTrace

class InvalidInputException(message: String)
    extends Exception(message)
    with NoStackTrace

class UDFRegistrationException(message: String)
    extends Exception(message)
    with NoStackTrace

class InvalidReturnDataTypeException(message: String)
    extends Exception(message)
    with NoStackTrace

class InvalidUserDefinedFunctionException(message: String)
    extends Exception(message)
    with NoStackTrace
