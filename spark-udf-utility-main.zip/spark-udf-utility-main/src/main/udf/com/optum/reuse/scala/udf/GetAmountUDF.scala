package com.optum.reuse.scala.udf

import com.optum.reuse.util.Loggable
import org.apache.spark.sql.api.java.UDF1

class GetAmountUDF extends Loggable with UDF1[String, String]{
  def call(input: String): String = {
    val minusSign = "-"
    var output = ""

    val formattedInput = input.replace(" ", "")
    val inputIndex = formattedInput.indexOf(minusSign)

    if (inputIndex > 0) {
      if (inputIndex == 2) {
        output = formattedInput
      }
      else {
        output = formattedInput.substring(inputIndex, formattedInput.length)
      }
    }
    else {
      output = formattedInput;
    }
    output
  }

}
