package com.optum.reuse.util

import com.google.common.reflect.ClassPath
import com.optum.reuse.scala.SparkScalaUDFApp
import org.apache.spark.sql.SparkSession
import org.apache.log4j.Logger

case class AppUtil (logger: Logger) {
  val loader: ClassLoader = Thread.currentThread.getContextClassLoader

  def findAndRegisterUDFOnClassPath(
        sparkSession: SparkSession,
        packageName: String
        ): SparkSession = {

    import scala.collection.JavaConversions._

    logger.info(s"Check for UDFs in the package: $packageName")

    for (info <- ClassPath.from(loader).getTopLevelClasses) {
      if (info.getName.startsWith(packageName)) {
         logger.info(s"Registering UDF: ${info.getName.mkString}")
         SparkScalaUDFApp().registerScalaUDF(sparkSession, info.getName.mkString)
      }
    }

    logger.info("UDFs registration succeeded.")

    sparkSession
  }
}
