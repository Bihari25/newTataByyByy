package com.optum.reuse.hive

import com.optum.reuse.exception.InvalidInputException
import org.apache.hadoop.hive.ql.exec.UDF
import org.apache.hadoop.hive.ql.udf.UDFType

@UDFType(deterministic = true, stateful = false)
trait EvaluateHiveUDF extends UDF{
  def evaluate(input: String): String = {
    if (input == null) {
      throw new InvalidInputException("Invalid/empty message")
    }
    input
  }
}
