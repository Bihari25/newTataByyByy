package com.optum.reuse.scala.examples

import com.optum.reuse.util.Loggable
import org.apache.spark.sql.api.java.UDF1
import org.apache.spark.sql.api.java.UDF0

class MultipleTraitsUDF extends Loggable with UDF1[String, String] with UDF0[String] {
  override def call(t1: String): String = ???

  override def call(): String = ???
}
