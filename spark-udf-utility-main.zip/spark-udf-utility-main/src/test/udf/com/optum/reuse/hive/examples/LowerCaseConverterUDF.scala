package com.optum.reuse.hive.examples

import com.optum.reuse.hive.EvaluateHiveUDF

class LowerCaseConverterUDF extends EvaluateHiveUDF {
  override def evaluate(input: String): String = {
    super.evaluate(input)
    input.toLowerCase()
  }
}
