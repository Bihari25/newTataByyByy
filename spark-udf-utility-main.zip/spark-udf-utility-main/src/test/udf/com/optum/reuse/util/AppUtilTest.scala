package com.optum.reuse.util

import com.optum.reuse.scala.SparkSessionTestWrapper
import org.scalatest.FlatSpec
import org.apache.log4j.Logger

class AppUtilTest extends FlatSpec with SparkSessionTestWrapper {

  "AppUtil" should "validate class on path" in {

    val logger = Logger.getLogger("AppUtilTest Logger")

    val sparkSession = AppUtil(logger).findAndRegisterUDFOnClassPath(
      spark,
      "com.optum.reuse.scala.udf"
    )
    val healthRecordDS = Seq(
      HealthRecord("101", "chill"),
      HealthRecord("102", "cough"),
      HealthRecord("103", "pains"),
      HealthRecord("104", "Unknown")
    )

    sparkSession
      .createDataFrame(healthRecordDS)
      .createOrReplaceTempView("HealthRecord")
    val resultDF = sparkSession.sql(
      "select hr.id, hr.symptoms, MedicineEvaluationUDF(hr.symptoms) as medicine from HealthRecord hr"
    )

    resultDF.show()
    assert(resultDF.col("medicine").toString() == "medicine")
    assert(!resultDF.first().mkString.isEmpty)

  }

}

case class HealthRecord(id: String, symptoms: String)
