package com.optum.reuse.scala.examples

import com.optum.reuse.util.Loggable
import org.apache.spark.sql.api.java.UDF1

/**
 * Sample SparkScala UDF code.
 */
class ClaimTypeIdentifierUDF extends Loggable with UDF1[String, String] {
  def call(s: String): String = {
    if (List("837p", "nsf").contains(s.toLowerCase)) {
      "Professional"
    } else if (List("837i", "ub92").contains(s.toLowerCase)) {
      "Institutional"
    } else {
      "Unknown"
    }
  }

}
