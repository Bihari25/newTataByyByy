package com.optum.reuse.scala
import com.optum.reuse.exception.{
  InvalidReturnDataTypeException,
  UDFRegistrationException
}
import org.scalatest.{FlatSpec}
import org.apache.spark.sql.types.{StringType, StructField, StructType}
import org.apache.spark.sql.SparkSession

class SparkScalaUDFAppTest extends FlatSpec with SparkSessionTestWrapper {

  "SparkScalaUDFAppTest" should "validate udf register function instance" in {
    val classPath = "com.optum.reuse.scala.examples.ClaimTypeIdentifierUDF"
    val functionName = "ClaimTypeIdentifierUDF"
    val udfDriver = SparkScalaUDFApp().registerScalaUDF(spark, classPath)
    assert(udfDriver.isInstanceOf[SparkSession])

    import org.apache.spark.sql.Row
    val df = Seq(Row("837p"))
    val schema = List(StructField("claimIdentifier", StringType))

    val resultDF = spark.createDataFrame(
      spark.sparkContext.parallelize(df),
      StructType(schema)
    )
    resultDF.createOrReplaceTempView("test")
    val sql1 = s""" select ${functionName}('837p') from test """
    val result = spark.sql(sql1)
    result.show()
    assert(result.count() == 1)
  }

  it should "expect exception on invalid udf trait" in {
    val classPath = "com.optum.reuse.scala.examples.InvalidUDF"
    assertThrows[ClassNotFoundException](
      SparkScalaUDFApp().registerScalaUDF(spark, classPath)
    )
  }

  it should "except exception on multiple traits" in {
    val classPath = "com.optum.reuse.scala.examples.MultipleTraitsUDF"
    assertThrows[UDFRegistrationException](
      SparkScalaUDFApp().registerScalaUDF(spark, classPath)
    )
  }

  it should "validate pattern" in {
    val actual = "<java.lang.string,java.lang.string>"
    val a = actual
      .substring(actual.indexOf("<") + 1, actual.indexOf(">"))
      .split(",")
      .last
    assert(a == "java.lang.string")
  }

}
