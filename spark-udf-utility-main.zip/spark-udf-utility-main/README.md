# UDF Util on SparkSession

Utility code that registers the UDF function on spark session object. This utility code reads all the UDFs from package, automatically evaluates the return types, and generate function names to be used from the class name.

## Getting started

### Prerequisites

- A [Java Development Kit (JDK)][jdk_link], version 8 or later.
- [Maven][maven]
- Spark `2.4.7` - [Download][spark-download], extract and add the root folder to PATH
- Make - pre-installed on macOS.  [Install][make-install] for windows

### Include the package
```xml
<dependency>
    <groupId>com.optum.reuse</groupId>
    <artifactId>spark-udf-utility</artifactId>
    <version>1.0-SNAPSHOT</version>
</dependency>
```

## Key concepts

### Registering UDFs

 - UDFs must implement the trait(org.apache.spark.sql.api.java.UDFx). 
    - Follow example code - com.optum.reuse.scala.udf.MedicineEvaluationUDF
 - Return type support on UDFs (all spark primitive types were supported)
 - Function name is taken from class name.
    - For example, MedicineEvaluationUDF will be the function name.
 
## Examples
 - AppUtil().scanUDFImplementationsOnClassPath(spark, "com.optum.reuse.scala.udf")

### IDE Setup

See [IDE Setup](dev/README.md) for commands to bootstrap up your favorite supported IDE setup!

## Running with Local Spark

```shell
make local
```

Voila! that's it, you are all set to get started :)

### Tests

```shell
make test
```

## Contributing
Pull requests are encouraged.

### Deployment

- Jenkins pipeline included

### Detailed documentation

See [documentation](http://dataatscale.optum.com)

<!-- Links -->
[java_8_sdk_javadocs]: https://docs.oracle.com/javase/8/docs/api/java/util/logging/package-summary.html
[jdk_link]: https://docs.microsoft.com/java/azure/jdk/?view=azure-java-stable
[maven]: https://maven.apache.org/
[spark-scala]: https://spark.apache.org/downloads.html
[spark-download]: https://mirrors.sonic.net/apache/spark/spark-2.4.7/spark-2.4.7-bin-hadoop2.7.tgz
[make-install]: http://gnuwin32.sourceforge.net/packages/make.htm