spark-submit --class com.optum.reuse.ManagedApplication \
    --master local[*] \
    --properties-file scripts/spark-local.conf \
    target/spark-udf-utility-3.4.3.jar \
    com.optum.reuse.scala.udf
