package com.optum.spark.kafkaToParquet

case class RawMessage(id: Long, raw_json: String, load_ts: String)
