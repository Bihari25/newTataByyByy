package com.optum.spark.kafkaToParquet

import java.lang.System.currentTimeMillis
import java.nio.charset.StandardCharsets
import java.security.MessageDigest

import org.apache.kafka.clients.consumer.ConsumerRecord
import org.apache.spark.rdd.RDD
import org.apache.spark.sql._
import org.apache.spark.streaming.StreamingContext
import org.apache.spark.streaming.dstream.InputDStream
import org.apache.spark.streaming.kafka010.ConsumerStrategies.Subscribe
import org.apache.spark.streaming.kafka010.KafkaUtils
import org.apache.spark.streaming.kafka010.LocationStrategies.PreferConsistent
import org.slf4j.{Logger, LoggerFactory}

import org.apache.spark.sql

object StreamingService {

  val LOGGER: Logger = LoggerFactory.getLogger(getClass)

  def createDStream(ssc: StreamingContext, kafkaParams: Map[String, Object], topicNames: Array[String]) = {
    KafkaUtils.createDirectStream(
      ssc,
      PreferConsistent,
      Subscribe[String, Array[Byte]](topicNames, kafkaParams))
  }

  def process(dstream: InputDStream[ConsumerRecord[String, Array[Byte]]],
              topics: Array[String])(implicit spark: SparkSession): Unit = {

    import spark.implicits._


    for { topic <- topics } {

      dstream.foreachRDD( rdd => {
        val startRDD = currentTimeMillis()
        if (rdd.isEmpty()){
          LOGGER.info(s"Empty RDD - ${topic}") //newEvent("Completed RDD").appName("spark-streaming").topicName(topic).recordCount(0).durationMillis(currentTimeMillis - startRdd))
        } else {

          val recordsRDD: RDD[RawMessage] = rdd.map(consumerRecord => {
            val raw_json: String = new String(consumerRecord.value(), StandardCharsets.UTF_8)
            val messageDigest = MessageDigest.getInstance("SHA-1")
           // val hash = messageDigest.digest(consumerRecord.value()).map("%02x".format(_)).mkString
            val load_ts: String =  System.currentTimeMillis.toString()
            val id: Long = s"${load_ts}".toLong

            RawMessage(
              id,
              raw_json,
              load_ts



            )
          })

          println (s"Nb of Records : ${recordsRDD.count()}")
          val recordDS: Dataset[RawMessage] = spark.createDataset(recordsRDD)
          saveToHiveTransational(recordDS, "uhc_cosmos_1014_ingest.odar_clm_rec")

        }
      })
    }
  }

//  def saveToParquet(ds: Dataset[RawMessage], path: String): Unit = {
//    val startHive = currentTimeMillis
//    ds.write.mode(SaveMode.Append).format("parquet").save(path)
//    LOGGER.info(s"Writing to Parquet - topicName - Finished {}", currentTimeMillis - startHive)
//  }


  def saveToHiveTransational(ds: Dataset[RawMessage], tableName: String)(implicit spark: SparkSession): Unit = {

    val startHive = currentTimeMillis()
    LOGGER.info(s"Writing to Hive Tables - topicName - Finished {}", currentTimeMillis - startHive)
    //val df = spark.createDataFrame(data, schema
    //ds.write.mode(SaveMode.Append).saveAsTable(tableName)
    ds.select("id","raw_json","load_ts")
    ds.createOrReplaceTempView("selectedDataTempTable")
    LOGGER.info("Inserting selected data into audit table")
    //spark.sql(insertSqlString)
    //val insertSqlString = spark.sql("INSERT INTO TABLE uhc_cosmos_1014_ingest.odar_clm_rec select id, raw_json, load_ts FROM selectedDataTempTable")

    spark.sql("INSERT INTO TABLE uhc_cosmos_1014_ingest.odar_clm_rec select id, raw_json, load_ts FROM selectedDataTempTable")
  }


}
