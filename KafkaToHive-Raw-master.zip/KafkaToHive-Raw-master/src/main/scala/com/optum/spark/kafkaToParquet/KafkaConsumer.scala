package com.optum.spark.kafkaToParquet

import org.apache.spark.streaming.{Duration, StreamingContext}
import org.apache.spark.{SparkConf, SparkContext}
import org.apache.kafka.clients.consumer.ConsumerRecord
import org.apache.kafka.clients.consumer.ConsumerConfig._
import org.apache.kafka.common.serialization.{ByteArrayDeserializer, StringDeserializer}
import org.apache.spark.rdd.RDD
import org.apache.spark.sql.types._
import org.apache.spark.sql.{DataFrame, Dataset, Row, SparkSession}
import org.apache.spark.sql.functions._
import org.apache.spark.streaming.kafka010._
import org.apache.spark.streaming.kafka010.LocationStrategies.PreferConsistent
import org.apache.spark.streaming.kafka010.ConsumerStrategies.Subscribe
import org.apache.log4j.Logger
import org.apache.log4j.Level

object KafkaConsumer {

  def main(args: Array[String]): Unit = {
    val conf: SparkConf = new SparkConf()
      .setAppName("Spark Streaming Json Consumer")

    //Logger.getLogger("org").setLevel(Level.ERROR)
    //Logger.getLogger("akka").setLevel(Level.ERROR)

    val topics = Array("ccat-odar-recovery")

    val streamingContext: StreamingContext = new StreamingContext(conf, new Duration(3000))
    implicit val spark: SparkSession = SparkSession
      .builder()
      .config("spark.sql.hive.convertMetastoreParquet", false)
      .config("hive.exec.dynamic.partition", "true")
      .config("hive.exec.dynamic.partition.mode", "nonstrict")
      .enableHiveSupport()
      .getOrCreate()

    var kafkaParams: Map[String, Object] = Map[String, Object](
      BOOTSTRAP_SERVERS_CONFIG -> "apsrs8828.uhc.com:29093",
      KEY_DESERIALIZER_CLASS_CONFIG -> classOf[StringDeserializer],
      VALUE_DESERIALIZER_CLASS_CONFIG -> classOf[ByteArrayDeserializer],
      GROUP_ID_CONFIG -> "use_a_separate_group_id_for_each_stream",
      AUTO_OFFSET_RESET_CONFIG -> "latest",
      ENABLE_AUTO_COMMIT_CONFIG -> (false: java.lang.Boolean)
    )

    kafkaParams = kafkaParams + (
      "security.protocol" -> "SSL",
      "ssl.truststore.location" -> "/mapr/datalake/optum/optuminsight/aalbdplt/data/ccat/restricted/uhc_cosmos_1014/topic-hive-kar/server.truststore.jks",
      "ssl.truststore.password" -> "stagekafka",
      "ssl.keystore.location" -> "/mapr/datalake/optum/optuminsight/aalbdplt/data/ccat/restricted/uhc_cosmos_1014/topic-hive-kar/piuap_ccat.keystore.jks",
      "ssl.keystore.password" -> "stagekafka",
      "ssl.key.password.cfg" -> "stagekafka")

    spark.sql("SHOW DATABASES").show()

    val dstream = StreamingService.createDStream(streamingContext, kafkaParams, topics)

    StreamingService.process(dstream, topics)

    streamingContext.start()
    streamingContext.awaitTermination()


  }

}
