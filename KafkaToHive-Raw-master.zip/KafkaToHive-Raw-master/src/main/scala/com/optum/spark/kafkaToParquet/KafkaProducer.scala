//package com.chrisyohann.spark.kafkaToParquet
//
//import java.io.InputStream
//import java.util.Properties
//import scala.util.Random
//
//import org.apache.kafka.clients.producer.{KafkaProducer, ProducerConfig, ProducerRecord}
//import org.apache.kafka.common.serialization.{ByteArraySerializer, LongSerializer}
//import org.json4s.JsonAST.JValue
//import org.json4s.jackson.JsonMethods._
//
//import scala.io.Source
//
//object KafkaProducer {
//
//  def loadData(dataPath: String): List[JValue] = {
//    val classLoader: ClassLoader = getClass.getClassLoader
//    val is: InputStream = classLoader.getResourceAsStream(dataPath)
//    val lines: Iterator[String] = Source.fromInputStream(is, "UTF-8").getLines()
//    lines.flatMap((line: String) => {
//      parseOpt(line)
//    }).toList
//  }
//
//  def main(args: Array[String]): Unit = {
//
//    val TOPIC: String = "transactions"
//    val props: Properties = new Properties()
//
//    props.put(ProducerConfig.BOOTSTRAP_SERVERS_CONFIG, "localhost:9092")
//    props.put(ProducerConfig.CLIENT_ID_CONFIG, "DataProducer")
//    props.put(ProducerConfig.KEY_SERIALIZER_CLASS_CONFIG, classOf[LongSerializer].getName())
//    props.put(ProducerConfig.VALUE_SERIALIZER_CLASS_CONFIG, classOf[ByteArraySerializer].getName())
//
//    val dataDRG: List[JValue] = loadData("data/drg.jsonl")
//    val dataRUG: List[JValue] = loadData("data/rug.jsonl")
//    val dataAPC: List[JValue] = loadData("data/apc.jsonl")
//
//    val customerIds: List[String] = List("a", "b", "c", "d")
//
//    val data = Seq(dataAPC.head, dataRUG.head, dataDRG.head)
//
//    data.foreach(jValue => println(compact(render(jValue))))
//
//    val recordData: Seq[Array[Byte]] = data.map(compact(_).getBytes())
//
//    val producer: KafkaProducer[String, Array[Byte]] = new KafkaProducer[String, Array[Byte]](props)
//
//    var autoIncrement: Long = 0
//
//    while (true) {
//      val recordChosenIndex = Random.nextInt(3)
//      val record: ProducerRecord[String, Array[Byte]] = new ProducerRecord[String, Array[Byte]](TOPIC, recordData(recordChosenIndex))
//      producer.send(record)
//      autoIncrement = autoIncrement + 1
//      if (autoIncrement % 10 == 0){
//        println(s"==================== ${autoIncrement} ====================")
//        Thread.sleep(3000)
//      }
//    }
//
//    producer.close()
//  }
//}
