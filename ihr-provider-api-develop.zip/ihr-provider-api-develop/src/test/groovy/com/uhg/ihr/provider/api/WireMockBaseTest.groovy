package com.uhg.ihr.provider.api

import com.fasterxml.jackson.databind.ObjectMapper
import com.github.tomakehurst.wiremock.junit.WireMockRule
import com.uhg.ihr.provider.api.controller.SearchController
import com.uhg.ihr.provider.api.model.Big5
import com.uhg.ihr.provider.util.TestData
import io.jsonwebtoken.lang.Strings
import io.micronaut.context.annotation.Property
import io.micronaut.http.client.RxHttpClient
import io.micronaut.http.client.annotation.Client
import io.micronaut.test.annotation.MicronautTest
import org.junit.ClassRule
import spock.lang.Shared
import spock.lang.Specification

import javax.inject.Inject

import static com.github.tomakehurst.wiremock.client.WireMock.*

@MicronautTest
@Property(name = "micronaut.security.stargate.enabled", value = "false")
@Property(name = "senzing.secretKey", value = "55555555555555555555555555555555555555555555555555555555555555555555555555555555")
@Property(name = "mongo.mongo-txn", value = "false")
//FIXME: will need to enable mongo testing
class WireMockBaseTest extends Specification {

    static String PAYLOAD_BASE = "{\"ihrIdentifier\":\"%s\",\"acceptLanguage\":\"EN\",\"taxonomy\":null,\"payload\":\"%s\"}"
    static String SENZING_BASE = "{\"data\":{\"searchResults\":%s}}"
    static ObjectMapper MAPPER = new ObjectMapper()
    static TestData TEST_DATA = new TestData()
    static String COLLECTION_NAME = "ihr2"
    static String CONSUMER_HEADER = "uhgrd.helium"

    @Inject
    @Client(id = '/', configuration = WireMockHttpClientConfiguration.class)
    RxHttpClient httpClient

    @ClassRule
    @Shared
    WireMockRule wireMockRule = new WireMockRule(8089)

    //FIXME: remove after ii retirement, always 404 all ii calls in intg tests
    def setup() {
        wireMockRule.stubFor(post(urlEqualTo("/ihrid/v1.0/nativeQuery/5")).willReturn(notFound()))
    }

    def cleanup() {
        clearMatches()
    }

    static String buildResponse(String chid, String payload) {
        return String.format(PAYLOAD_BASE, chid, payload)
    }

    def matchSenzingToChid(Big5 big5, String chid) {
        matchSenzing(big5, Strings.replace(TEST_DATA.readFileContent("senzing-base-response.json"), "#CHID#", chid))
    }

    def matchSenzing(Big5 big5, String response) {
        def request = MAPPER.writeValueAsString(SearchController.buildSenzingRequest(big5, COLLECTION_NAME))

        wireMockRule.stubFor(post(urlEqualTo("/entities/"))
                .withRequestBody(equalToJson(request))
                .willReturn(aResponse()
                        .withStatus(200)
                        .withHeader("Content-Type", "application/json")
                        .withBody(response)))
    }

    def notMatchSenzing(Big5 big5) {
        def request = MAPPER.writeValueAsString(SearchController.buildSenzingRequest(big5, COLLECTION_NAME))

        wireMockRule.stubFor(post(urlEqualTo("/entities/"))
                .withRequestBody(equalToJson(request))
                .willReturn(aResponse()
                        .withStatus(200)
                        .withHeader("Content-Type", "application/json")
                        .withBody(String.format(SENZING_BASE, "[]"))))
    }

    def errorSenzing(Big5 big5) {
        def request = MAPPER.writeValueAsString(SearchController.buildSenzingRequest(big5, COLLECTION_NAME))

        wireMockRule.stubFor(post(urlEqualTo("/entities/"))
                .withRequestBody(equalToJson(request))
                .willReturn(serverError()))
    }

    def errorIi() {
        wireMockRule.stubFor(post(urlEqualTo("/ihrid/v1.0/nativeQuery/5"))
                .willReturn(serverError()))
    }

    def matchPayload(String actorChid, String version, String response) {
        wireMockRule.stubFor(get(urlEqualTo("/payload/v1.0/" + version + "/" + actorChid))
                .willReturn(aResponse()
                        .withStatus(200)
                        .withHeader("Content-Type", "application/json")
                        .withBody(response)))
    }

    def matchPayloadAnyVersion(String actorChid, String response) {
        ["1", "2"].forEach({ v -> matchPayload(actorChid, v, response) })
    }

    def notMatchPayload(String actorChid, String version) {
        wireMockRule.stubFor(get(urlEqualTo("/payload/v1.0/" + version + "/" + actorChid))
                .willReturn(notFound()))
    }

    def errorPayload(String actorChid, String version) {
        wireMockRule.stubFor(get(urlEqualTo("/payload/v1.0/" + version + "/" + actorChid))
                .willReturn(serverError()))
    }

    /**
     * This method will wire up both senzing and data mocks to return a senzing call that will match a specific payload
     * @param big5 the big5 that should be matched against
     * @param payload the payload to return
     */
    def matchAll(Big5 big5, String payload) {
        def chid = TestData.randomChid()
        matchSenzingToChid(big5, chid)
        matchPayloadAnyVersion(chid, payload)
    }

    def matchDefault() {
        def chid = TestData.randomChid()
        matchSenzingToChid(TestData.sampleBig5(), chid)
        matchPayloadAnyVersion(chid, buildResponse(chid, "{}"))
    }

    def clearMatches() {
        wireMockRule.resetAll()
    }

}

