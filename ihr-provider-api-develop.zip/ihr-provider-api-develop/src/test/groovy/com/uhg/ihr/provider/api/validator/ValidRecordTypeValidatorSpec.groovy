package com.uhg.ihr.provider.api.validator

import com.uhg.ihr.provider.api.model.RecordType
import spock.lang.Specification

class ValidRecordTypeValidatorSpec extends Specification {
    def "Test Invalid Record Type"() {
        given:
        def validator = new ValidRecordTypeValidator()
        def recordTypes = new HashSet<>()

        expect:
        !validator.isValid(recordTypes, null)
    }
    def "Test Valid Record Type"() {
        given:
        def validator = new ValidRecordTypeValidator()
        def recordTypes = new HashSet<>()
        recordTypes.add(RecordType.ACTIVE_ADVERSE_REACTION)

        expect:
        validator.isValid(recordTypes, null)
    }
    def "Test Duplicate Record Type"() {
        given:
        def validator = new ValidRecordTypeValidator()
        def recordTypes = new HashSet<>()
        recordTypes.add(RecordType.ACTIVE_ADVERSE_REACTION)
        recordTypes.add(RecordType.ACTIVE_ADVERSE_REACTION)

        expect:
        validator.isValid(recordTypes, null)
    }
}
