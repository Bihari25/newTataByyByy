package com.uhg.ihr.provider.api.security

import com.uhg.ihr.provider.api.service.backend.senzing.SenzingTokenHelper
import com.uhg.ihr.provider.util.TestData
import spock.lang.Ignore
import spock.lang.Specification

class SenzingClientTokenHelperSpec extends Specification {
    TestData testData = new TestData()
    def today = new Date()
    def sampleRoles = ["admin"]
    def defaultSecret = 'THISISNOTREALn2rDSDA!!5u8x/A%D*G-KaPdSgVkDASDASDASYp3s6v9y$B&E(H+MbQeThWmZDSDSq4t7w!z%C*F-KKLJ@NcRf'
    def tokenDuration = new Long(30000)

    def "SenzingTokenHelper: getKeyFromFile happy path"() {
        when:
        def filePath = testData.getFilePath("senzing-default-secret.txt")
        def result = SenzingTokenHelper.getKeyFromFile(filePath)
        then:
        result
        result.contains(defaultSecret)
    }

    def "SenzingTokenHelper: getKeyFromFile file not exist exception"() {
        when:
        def filePath = testData.getFilePath("senzing-default-secret.txt")
        def result = SenzingTokenHelper.getKeyFromFile(filePath + "test")
        then:
        !result
    }

    @Ignore
    def "SenzingTokenHelper: generateToken"() {
        when:
        def result = SenzingTokenHelper.generateToken("ihr-external-api", null, null, today, tokenDuration, sampleRoles, defaultSecret)
        then:
        result
        result.length() > 0
        result.contains("eyJ0eXA")
    }

    @Ignore
    def "SenzingTokenHelper: decorateToken"() {
        when:
        def result = SenzingTokenHelper.decorateToken("ihr-external-api", null, null, today, tokenDuration, sampleRoles, defaultSecret)
        then:
        result
        result.sub == "ihr-external-api"
        result.roles.size() == 1
        result.roles[0] == "admin"
        result.token.contains("eyJ0eXA")
    }
}