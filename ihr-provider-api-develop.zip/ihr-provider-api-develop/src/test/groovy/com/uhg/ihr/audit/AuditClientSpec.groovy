package com.uhg.ihr.audit

import com.uhg.ihr.audit.producer.AuditClient
import io.micronaut.test.annotation.MicronautTest
import io.reactivex.Flowable
import spock.lang.Shared
import spock.lang.Specification

import javax.inject.Inject
import java.lang.management.ManagementFactory
import java.lang.management.RuntimeMXBean

@MicronautTest(environments = "kafka")
class AuditClientSpec extends Specification {

    @Inject
    @Shared
    private AuditClient auditClient

    def "sendWithoutKey"() {
        given:
        Map<String,String> auditDetails = new HashMap<>()
        auditDetails.put("client", "test")
        auditDetails.put("ip", "999.999.0.0")
        auditDetails.put("source", "portal")
        String[] auditType = new String[]{}
        RuntimeMXBean runtimeBean = ManagementFactory.getRuntimeMXBean()
        InetAddress ip
        String hostname
        Map<String,String> auditSysProperties = runtimeBean.getSystemProperties()
        try {
            ip = InetAddress.getLocalHost()
            hostname = ip.getHostName()
            auditSysProperties.put("ip", ip.getHostAddress())
            auditSysProperties.put("hostname",hostname)
        }catch (UnknownHostException e){
            e.printStackTrace()
        }
        Audit audit = new Audit(auditType, auditSysProperties, auditDetails)

        when:
        Flowable<Audit> auditFlowable = auditClient.send(Flowable.just(audit))
        Audit auditReturned = auditFlowable.blockingFirst()

        then:
        auditReturned.getCommon().get("client") == "test"
    }
}
