package com.uhg.ihr.provider.api.service

import com.fasterxml.jackson.databind.JsonNode
import com.uhg.ihr.provider.api.exception.IhrNotFoundException
import com.uhg.ihr.provider.api.filter.ClinicallyRelevantDateFilter
import com.uhg.ihr.provider.api.filter.DataFilter
import com.uhg.ihr.provider.api.filter.PresenceStateFilter
import com.uhg.ihr.provider.api.model.RecordType
import com.uhg.ihr.provider.api.service.backend.inflator.InflatorAdapter
import com.uhg.ihr.provider.data.model.Payload
import com.uhg.ihr.provider.util.JsonUtils
import com.uhg.ihr.provider.util.TestData
import org.bson.Document
import spock.lang.Ignore
import spock.lang.Specification
import spock.lang.Unroll

@Unroll
class InflatorServiceSpec extends Specification {

    TestData testData = new TestData()

    @Ignore
    def "validateAndConvertDocument for success: #desc"() {
        given:
        def jsonPayload = testData.readFileContent("document-payload.json")
        def dataClassesPayload = JsonUtils.deserializeJson(JsonNode.class, jsonPayload)
        Set<RecordType> requestedDataClasses = dataClasses

        when:
        JsonNode node = InflatorAdapter.filteredResponse(dataClassesPayload, requestedDataClasses)

        then:
        outputSize == node.get('dataClasses').size()

        where:
        desc               | dataClasses                                                                           || outputSize
        "Service Provider" | [RecordType.SERVICE_FACILITY_PROVIDER]                                                || 1
        "Health Cases"     | [RecordType.HEALTH_CONDITION, RecordType.HEALTH_MEDICATION, RecordType.HEALTH_DEVICE] || 3
    }

    def "validateAndConvertDocument for failure: #desc"() {
        when:
        InflatorAdapter.validateAndConvertDocument(input)

        then:
        IhrNotFoundException ihrEx = thrown()
        ihrEx.message.contains(message)

        where:
        desc            | input                    | message
        "null document" | null                     | "user was matched but no corresponding data was found"
        "bad document"  | new Document(null, null) | "Unable to translate mongodb document to jsonNode"
    }

    @Ignore
    def "filteredResponse with out data filters scenarios: #desc"() {
        given:
        Payload samplePayload = testData.buildSamplePayload("payload-sample.json")
        Set<RecordType> requestedDataClasses = dataClasses

        when:
        JsonNode node = InflatorAdapter.filteredResponse(samplePayload.payloadJson, requestedDataClasses)

        then:
        outputSize == node.get('dataClasses').size()

        where:
        desc                          | dataClasses                                                                           || outputSize
        "Empty data classes"          | []                                                                                    || 0
        "1 requested data classes"    | [RecordType.SERVICE_FACILITY_PROVIDER]                                                || 1
        "3 requested data classes"    | [RecordType.IMMUNIZATIONS, RecordType.CARE_TEAM, RecordType.ADVERSE_REACTION]         || 3
        "Health related data classes" | [RecordType.HEALTH_CONDITION, RecordType.HEALTH_MEDICATION, RecordType.HEALTH_DEVICE] || 3
    }

    //TODO: Add tests if data filters (not classes) are going to be implemented
    @Ignore
    def "filteredResponse with data filters scenarios: #desc"() {
        given:
        Payload samplePayload = testData.buildSamplePayload("datafilter-payload.json")
        Set<RecordType> requestedDataClasses = dataClasses
        def dataFilters = [new ClinicallyRelevantDateFilter('2018-12-25', '2019-12-25'),
                           new PresenceStateFilter("Present")] as List<DataFilter>

        when:
        JsonNode node = MongoDataService.filteredResponse(samplePayload.payloadJson, requestedDataClasses, dataFilters)

        then:
        node.get('dataClasses').size() == outputSize
        node.get('dataClasses').get('medications').size() == 2
        node.get('dataClasses').get('conditions').size() == 7

        where:
        desc                          | dataClasses                                                                           || outputSize
        "Health related data classes" | [RecordType.HEALTH_CONDITION, RecordType.HEALTH_MEDICATION, RecordType.HEALTH_DEVICE] || 3
    }


    @Ignore
    def "filterDataClasses scenarios: #desc"() {
        given:
        Payload samplePayload = testData.buildSamplePayload("payload-sample.json")
        Set<String> requestedDataClasses = dataClasses.size() > 0 ? dataClasses.collect({
            it.toLowerCase()
        }) : new HashSet<>()

        when:
        def result = MongoDataService.filterDataClasses(samplePayload.payloadJson, requestedDataClasses)

        then:
        outputSize == result.size()

        where:
        desc                          | dataClasses                                                                                                            || outputSize
        "Empty data classes"          | []                                                                                                                     || 0
        "1 requested data classes"    | [RecordType.SERVICE_FACILITY_PROVIDER.toString()]                                                                      || 1
        "3 requested data classes"    | [RecordType.IMMUNIZATIONS.toString(), RecordType.CARE_TEAM.toString(), RecordType.ADVERSE_REACTION.toString()]         || 3
        "Health related data classes" | [RecordType.HEALTH_CONDITION.toString(), RecordType.HEALTH_MEDICATION.toString(), RecordType.HEALTH_DEVICE.toString()] || 3
    }

    def "documentToJsonNode"() {
        given:
        String dataClassesPayload = testData.readFileContent("document-payload.json")
        Document sampleDoc = Document.parse(dataClassesPayload)
        sampleDoc.put("_id", "iHRID223334444")

        when:
        def result = InflatorAdapter.documentToJsonNode(sampleDoc)

        then:
        result.get("_id").toString().contains("iHRID223334444")
        result.get("dataClasses").size() == 12
    }

    /**
     * Method to build sample mongodb document.
     *
     * @param jsonNode
     * @return Document
     */
    private Document buildSampleDocument(String payloadJson) {
        Document payload = Document.parse(payloadJson)

        Document document = new Document()
        document.put("_id", "iHRID223334444")
        document.put("dataClasses", payload)
        document
    }

    /**
     * Method to build sample mongodb document.
     *
     * @return Document
     */
    private Document buildDocument() {
        Document document = new Document()
        document.put("_id", "iHRID223334444")
        document
    }
}
