package com.uhg.ihr.provider.api.controller

import com.fasterxml.jackson.databind.ObjectMapper
import com.fasterxml.jackson.databind.node.ArrayNode
import com.fasterxml.jackson.databind.node.ObjectNode
import com.uhg.ihr.provider.api.model.MemberName
import com.uhg.ihr.provider.api.model.ProviderApiHeaders
import com.uhg.ihr.provider.api.model.profile.*
import com.uhg.ihr.provider.api.service.profile.UserProfileApi
import com.uhg.ihr.provider.util.HttpTestHelper
import io.micronaut.context.annotation.Primary
import io.micronaut.context.annotation.Property
import io.micronaut.http.HttpRequest
import io.micronaut.http.HttpResponse
import io.micronaut.http.HttpStatus
import io.micronaut.http.MutableHttpRequest
import io.micronaut.http.client.HttpClient
import io.micronaut.http.client.annotation.Client
import io.micronaut.http.client.exceptions.HttpClientResponseException
import io.micronaut.runtime.server.EmbeddedServer
import io.micronaut.test.annotation.MicronautTest
import io.micronaut.test.annotation.MockBean
import io.reactivex.Maybe
import spock.lang.AutoCleanup
import spock.lang.Shared
import spock.lang.Specification
import spock.lang.Unroll

import javax.inject.Inject

import static com.uhg.ihr.provider.api.model.profile.UserProfileConstant.*

@Property(name = "micronaut.security.stargate.enabled", value = "false")
@MicronautTest
class UserProfileControllerSpec extends Specification {

    public static final String CORRELATION_ID = "test"
    public static final String BASE_ENDPOINT = "/profile/v1.0"

    @Shared
    ObjectMapper mapper = new ObjectMapper()

    @Inject
    UserProfileApi profileService

    @Shared
    @AutoCleanup
    @Inject
    EmbeddedServer server

    @Inject
    @Client("/")
    HttpClient client

    @MockBean
    @Primary
    UserProfileApi mockProfileService() {
        return Mock(UserProfileApi.class)
    }

    MutableHttpRequest<UserProfileRequest> buildUserProfileRequest(String endpoint, String correlationId,
                                                                   String first, String last, String email,
                                                                   String npi, STATUS status,
                                                                   USER_TYPE type,
                                                                   SECURED_CONTEXT secureContext,
                                                                   ROLE_CONTEXT roleContext,
                                                                   String role,
                                                                   Map<IDENTIFIER_CONTEXT, String> identifierContexts) {
        IhrUser user = new IhrUser()
        if (first != null || last != null) {
            MemberName name = new MemberName()
            name.setFirst(first)
            name.setLast(last)
            user.setName(name)
        }
        user.setIdentifierContexts(identifierContexts)
        user.setEmail(email)
        user.setNpi(npi)
        user.setStatus(status)
        user.setUserType(type)
        UserProfileRequest request = new UserProfileRequest()
        request.setUser(user)
        if (secureContext != null || roleContext != null || role != null) {
            request.setExternalSecurity(ExternalSecurityAccess.builder()
                    .securedContext(secureContext)
                    .roles(role == null ? null : Set.of(role))
                    .build()
            )
            request.setResponseFilter(
                    FilterClass.builder()
                    .rolesContext(roleContext == null ? null : Set.of(roleContext))
                    .build()
            )
        }
        return HttpTestHelper.buildHttpPostRequest(BASE_ENDPOINT + endpoint, request, correlationId, "testToken")
    }

    @Unroll
    def "valid / using #desc"() {
        given:
        HttpRequest request = buildUserProfileRequest(
                "/", CORRELATION_ID, firstName, lastName, null, null, STATUS.ACTIVE, userType, SECURED_CONTEXT.ESSO,
                ROLE_CONTEXT.PORTAL, "127", idContext)

        and:
        profileService.registerUser(request.getBody().get(), new ProviderApiHeaders(CORRELATION_ID)) >> Maybe.just(new UserProfile())

        when:
        HttpResponse response = client.toBlocking().exchange(request)

        then:
        response.getStatus() == HttpStatus.OK

        where:
        desc                 | firstName | lastName | userType           | idContext
        "staff global id"    | null      | null     | USER_TYPE.STAFF    | Map.of(IDENTIFIER_CONTEXT.IHR, "1234567890", IDENTIFIER_CONTEXT.PORTAL, "9999999")
        "staff demograhpics" | "Bob"     | "Jule"   | USER_TYPE.STAFF    | Map.of(IDENTIFIER_CONTEXT.PORTAL, "9999999")
        "provider global id" | null      | null     | USER_TYPE.PROVIDER | Map.of(IDENTIFIER_CONTEXT.IHR, "1234567890", IDENTIFIER_CONTEXT.PORTAL, "9999999")
    }

    @Unroll
    def "invalid / with missing #desc"() {
        given:
        HttpRequest request = buildUserProfileRequest("/", CORRELATION_ID, first, last, null,
                null, profileStatus, userType, secureContext, roleContext, role, idContext)
        when:
        client.toBlocking().exchange(request)

        then:
        HttpClientResponseException e = thrown(HttpClientResponseException.class)
        e.status == HttpStatus.BAD_REQUEST

        where:
        desc                 | first | last   | userType           | profileStatus | secureContext        | roleContext         | role  | idContext
        "staff fn"           | null  | "Jule" | USER_TYPE.STAFF    | STATUS.ACTIVE | SECURED_CONTEXT.ESSO | ROLE_CONTEXT.PORTAL | "127" | Map.of(IDENTIFIER_CONTEXT.PORTAL, "9999999")
        "staff ln"           | "Bob" | null   | USER_TYPE.STAFF    | STATUS.ACTIVE | SECURED_CONTEXT.ESSO | ROLE_CONTEXT.PORTAL | "127" | Map.of(IDENTIFIER_CONTEXT.PORTAL, "9999999")
        "staff global id"    | null  | null   | USER_TYPE.STAFF    | STATUS.ACTIVE | SECURED_CONTEXT.ESSO | ROLE_CONTEXT.PORTAL | "127" | Map.of(IDENTIFIER_CONTEXT.PORTAL, "9999999")
        "provider global id" | null  | null   | USER_TYPE.PROVIDER | STATUS.ACTIVE | SECURED_CONTEXT.ESSO | ROLE_CONTEXT.PORTAL | "127" | Map.of(IDENTIFIER_CONTEXT.PORTAL, "9999999")
        "portal id"          | "Bob" | "Jule" | USER_TYPE.STAFF    | STATUS.ACTIVE | SECURED_CONTEXT.ESSO | ROLE_CONTEXT.PORTAL | "127" | null
        "external security"  | "Bob" | "Jule" | USER_TYPE.STAFF    | STATUS.ACTIVE | null                 | null                | null  | Map.of(IDENTIFIER_CONTEXT.PORTAL, "9999999")
        "secure context"     | "Bob" | "Jule" | USER_TYPE.STAFF    | STATUS.ACTIVE | null                 | ROLE_CONTEXT.PORTAL | "127" | Map.of(IDENTIFIER_CONTEXT.PORTAL, "9999999")
        "roles"              | "Bob" | "Jule" | USER_TYPE.STAFF    | STATUS.ACTIVE | SECURED_CONTEXT.ESSO | ROLE_CONTEXT.PORTAL | null  | Map.of(IDENTIFIER_CONTEXT.PORTAL, "9999999")
        "profile status"     | "Bob" | "Jule" | USER_TYPE.STAFF    | null          | SECURED_CONTEXT.ESSO | ROLE_CONTEXT.PORTAL | "127" | Map.of(IDENTIFIER_CONTEXT.PORTAL, "9999999")
        "user type"          | "Bob" | "Jule" | null               | STATUS.ACTIVE | SECURED_CONTEXT.ESSO | ROLE_CONTEXT.PORTAL | "127" | Map.of(IDENTIFIER_CONTEXT.PORTAL, "9999999")
    }

    def "valid /update"() {
        given:
        HttpRequest request = buildUserProfileRequest(
                "/update", CORRELATION_ID, null, null, "bob.jule@joynet.net",
                null, null, null, null, null, null, Map.of(IDENTIFIER_CONTEXT.IHR,"1234567890"))

        and:
        profileService.updateUser(request.getBody().get(), new ProviderApiHeaders(CORRELATION_ID)) >> Maybe.just(new UserProfile())

        when:
        HttpResponse response = client.toBlocking().exchange(request)

        then:
        response.getStatus() == HttpStatus.OK
    }

    def "valid /update no data found"() {
        given:
        HttpRequest request = buildUserProfileRequest(
                "/update", CORRELATION_ID, null, null, "bob.jule@joynet.net",
                null, null, null, null, null, null, Map.of(IDENTIFIER_CONTEXT.IHR,"1234567890"))

        and:
        profileService.updateUser(request.getBody().get(), new ProviderApiHeaders(CORRELATION_ID)) >> Maybe.empty()

        when:
        client.toBlocking().exchange(request)

        then:
        HttpClientResponseException e = thrown(HttpClientResponseException.class)
        e.status == HttpStatus.NOT_FOUND
    }

    @Unroll
    def "invalid /update missing global actor id"() {
        given:
        HttpRequest request = buildUserProfileRequest(
                "/update", CORRELATION_ID, null, null, "bob.jule@joynet.net",
                null, null, null, null, null, null, null)

        when:
        client.toBlocking().exchange(request)

        then:
        HttpClientResponseException e = thrown(HttpClientResponseException.class)
        e.status == HttpStatus.BAD_REQUEST
    }

    UserProfileLookup configureBaseUserProfileLookup(String first, String last, String email, String npi) {
        UserProfileLookup request = new UserProfileLookup()
        LookupContext context = new LookupContext()
        request.setLookupContext(context)
        if (first != null || last != null) {
            MemberName name = new MemberName()
            name.setFirst(first)
            name.setLast(last)
            context.setName(name)
        }
        context.setEmail(email)
        context.setNpi(npi)
        return request
    }

    HttpRequest buildValidUserProfileLookup() {
        FilterClass filterClass = new FilterClass()
        filterClass.setIdentifiersContext(Set.of(IDENTIFIER_CONTEXT.IHR))
        filterClass.setRolesContext(Set.of(ROLE_CONTEXT.IHR))
        UserProfileLookup request = configureBaseUserProfileLookup("Bob", "Jule", "bob.jule@joynet.net", "1234567890")
        request.getLookupContext().setLookupContexts(Map.of(IDENTIFIER_CONTEXT.IHR,"id"))
        request.setResponseFilter(filterClass)
        return HttpTestHelper.buildHttpPostRequest(BASE_ENDPOINT + "/lookup", request, CORRELATION_ID, "testToken")
    }

    def "valid /lookup"() {
        given:
        HttpRequest request = buildValidUserProfileLookup()

        and:
        profileService.lookupUserProfile(request.getBody().get(), new ProviderApiHeaders(CORRELATION_ID)) >> Maybe.just(new UserProfile())

        when:
        HttpResponse response = client.toBlocking().exchange(request)

        then:
        response.getStatus() == HttpStatus.OK
    }

    def "valid /lookup user not found"() {
        given:
        HttpRequest request = buildValidUserProfileLookup()

        and:
        profileService.lookupUserProfile(request.getBody().get(), new ProviderApiHeaders(CORRELATION_ID)) >> Maybe.empty()

        when:
        client.toBlocking().exchange(request)

        then:
        HttpClientResponseException e = thrown(HttpClientResponseException.class)
        e.status == HttpStatus.NOT_FOUND
    }

    HttpRequest buildInvalidUserProfileLookup(String endpoint, String correlationId, String first, String last, String email,
                                              String npi, String idContext, String idValue, String filterRoleContext, String filterIdContext) {
        UserProfileLookup request = new UserProfileLookup()
        LookupContext context = new LookupContext()
        request.setLookupContext(context)
        if (first != null || last != null) {
            MemberName name = new MemberName()
            name.setFirst(first)
            name.setLast(last)
            context.setName(name)
        }
        context.setEmail(email)
        context.setNpi(npi)
        ObjectNode requestJson = (ObjectNode) mapper.readTree(mapper.writeValueAsString(request))
        if (idContext != null && idValue != null) {
            ArrayNode lookupContexts = mapper.createArrayNode()
            ObjectNode identifierContext = mapper.createObjectNode()
            lookupContexts.add(identifierContext)
            identifierContext.put("contextType", idContext)
            identifierContext.put("identifier", idValue)
            ((ObjectNode) requestJson.get("lookupContext")).set("lookupContexts", lookupContexts)
        }
        ObjectNode responseFilter = mapper.createObjectNode()
        requestJson.set("responseFilter", responseFilter)
        if (filterRoleContext != null) {
            ArrayNode rolesContext = mapper.createArrayNode()
            responseFilter.set("rolesContext", rolesContext)
            rolesContext.add(filterRoleContext)
        }
        if (filterIdContext != null) {
            ArrayNode identifiersContext = mapper.createArrayNode()
            responseFilter.set("identifiersContext", identifiersContext)
            identifiersContext.add(filterIdContext)
        }
        return HttpTestHelper.buildHttpPostRequest(endpoint, requestJson, correlationId, "testToken")
    }

    @Unroll
    def "invalid /lookup with LookupContext #desc"() {
        given:
        HttpRequest request = buildInvalidUserProfileLookup(
                BASE_ENDPOINT + "/lookup", CORRELATION_ID, first, last, email, npi,
                idContextType, "id", ROLE_CONTEXT.IHR.toString(), IDENTIFIER_CONTEXT.IHR.toString()
        )

        when:
        client.toBlocking().exchange(request)

        then:
        HttpClientResponseException e = thrown(HttpClientResponseException.class)
        e.status == HttpStatus.BAD_REQUEST

        where:
        desc               | first | last   | email                 | npi          | idContextType
        "bad context TYPE" | "Bob" | "Jule" | "bob.jule@joynet.net" | "1234567890" | "BAD_TYPE"
        "bad email"        | "Bob" | "Jule" | "bob.jule.net"        | "1234567890" | IDENTIFIER_CONTEXT.IHR.toString()
        "fn missing"       | null  | "Jule" | "bob.jule@joynet.net" | "1234567890" | IDENTIFIER_CONTEXT.IHR.toString()
        "ln missing"       | "Bob" | null   | "bob.jule@joynet.net" | "1234567890" | IDENTIFIER_CONTEXT.IHR.toString()
    }

    @Unroll
    def "invalid /lookup with FilterClass #desc"() {
        given:
        HttpRequest request = buildInvalidUserProfileLookup(
                BASE_ENDPOINT + "/lookup", CORRELATION_ID, "Bob", "Jule", "bob.jule@joynet.net", "123467890",
                IDENTIFIER_CONTEXT.IHR.toString(), "id", rolesContext, identifiersContext
        )

        when:
        client.toBlocking().exchange(request)

        then:
        HttpClientResponseException e = thrown(HttpClientResponseException.class)
        e.status == HttpStatus.BAD_REQUEST

        where:
        desc                     | rolesContext                | identifiersContext
        "bad identifier context" | ROLE_CONTEXT.IHR.toString() | "BAD_TYPE"
        "bad roles context"      | "BAD_TYPE"                  | IDENTIFIER_CONTEXT.IHR.toString()
    }

    def "valid /{profile_id}/read"() {
        given:
        String profileId = "123ACTP1234567890"
        HttpRequest request = HttpTestHelper.buildHttpGetRequest(BASE_ENDPOINT + "/" + profileId + "/read", CORRELATION_ID, "testToken")

        and:
        profileService.getUserProfileByChid(profileId, new ProviderApiHeaders(CORRELATION_ID)) >> Maybe.just(new UserProfile())

        when:
        HttpResponse response = client.toBlocking().exchange(request)

        then:
        response.getStatus() == HttpStatus.OK
    }

    def "valid /{profile_id}/read no data found"() {
        given:
        String profileId = "123ACTP1234567890"
        HttpRequest request = HttpTestHelper.buildHttpGetRequest(BASE_ENDPOINT + "/" + profileId + "/read", CORRELATION_ID, "testToken")

        and:
        profileService.getUserProfileByChid(profileId, new ProviderApiHeaders(CORRELATION_ID)) >> Maybe.empty()

        when:
        client.toBlocking().exchange(request)

        then:
        HttpClientResponseException e = thrown(HttpClientResponseException.class)
        e.getStatus() == HttpStatus.NOT_FOUND
    }
}
