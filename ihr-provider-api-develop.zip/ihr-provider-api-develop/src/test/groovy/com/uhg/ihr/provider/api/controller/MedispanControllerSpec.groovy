package com.uhg.ihr.provider.api.controller

import com.uhg.ihr.medispan.dib.model.ImageValue
import com.uhg.ihr.medispan.dib.model.MedicationMedispan
import com.uhg.ihr.medispan.dib.service.DibApiService
import com.uhg.ihr.provider.util.HttpTestHelper
import io.micronaut.context.annotation.Primary
import io.micronaut.context.annotation.Property
import io.micronaut.http.HttpRequest
import io.micronaut.http.HttpResponse
import io.micronaut.http.HttpStatus
import io.micronaut.http.client.HttpClient
import io.micronaut.http.client.annotation.Client
import io.micronaut.http.client.exceptions.HttpClientResponseException
import io.micronaut.runtime.server.EmbeddedServer
import io.micronaut.test.annotation.MicronautTest
import io.micronaut.test.annotation.MockBean
import io.reactivex.Maybe
import spock.lang.AutoCleanup
import spock.lang.Shared
import spock.lang.Specification

import javax.inject.Inject

@Property(name = "micronaut.security.stargate.enabled", value = "false")
@MicronautTest
class MedispanControllerSpec extends Specification {
    private static final String MEDISPAN_URI = "/medications/v1.0"
    @Inject
    DibApiService dibApiService

    @Shared
    @AutoCleanup
    @Inject
    EmbeddedServer server

    @Inject
    @Client("/medications/v1.0")
    HttpClient client

    @MockBean
    @Primary
    DibApiService mockSearchAdapter() {
        return Mock(DibApiService.class)
    }

    HttpRequest buildHttpRequest(String endpoint) {
        return HttpRequest.GET(HttpTestHelper.host() + MEDISPAN_URI + endpoint)
    }

    def "Valid /{id} found data"() {
        given:
        HttpRequest request = buildHttpRequest("/12345")

        and:
        dibApiService.getMedicationSpan("12345") >> Maybe.just(new MedicationMedispan())

        when:
        HttpResponse response = client.toBlocking().exchange(request)

        then:
        response.status == HttpStatus.OK
    }

    def "Valid /{id} no data found"() {
        given:
        HttpRequest request = buildHttpRequest("/12345")

        and:
        dibApiService.getMedicationSpan("12345") >> Maybe.empty()

        when:
        client.toBlocking().exchange(request)

        then:
        HttpClientResponseException e = thrown(HttpClientResponseException.class)
        e.status == HttpStatus.NOT_FOUND
    }

    def "Valid /{id}/images found data"() {
        given:
        HttpRequest request = buildHttpRequest("/12345/images")

        and:
        dibApiService.getDrugImagesFK("12345") >> Maybe.just(new ArrayList<ImageValue>())

        when:
        HttpResponse response = client.toBlocking().exchange(request)

        then:
        response.status == HttpStatus.OK
    }

    def "Valid /{id}/images no data found"() {
        given:
        HttpRequest request = buildHttpRequest("/12345/images")

        and:
        dibApiService.getDrugImagesFK("12345") >> Maybe.empty()

        when:
        client.toBlocking().exchange(request)

        then:
        HttpClientResponseException e = thrown(HttpClientResponseException.class)
        e.status == HttpStatus.NOT_FOUND
    }

    def "Valid /{id}/education found data"() {
        given:
        HttpRequest request = buildHttpRequest("/12345/education")

        and:
        dibApiService.getPatientEducationMonographFK("12345") >> Maybe.just("Stuff")

        when:
        HttpResponse response = client.toBlocking().exchange(request)

        then:
        response.status == HttpStatus.OK
    }

    def "Valid /{id}/education no data found"() {
        given:
        HttpRequest request = buildHttpRequest("/12345/education")

        and:
        dibApiService.getPatientEducationMonographFK("12345") >> Maybe.empty()

        when:
        client.toBlocking().exchange(request)

        then:
        HttpClientResponseException e = thrown(HttpClientResponseException.class)
        e.status == HttpStatus.NOT_FOUND
    }
}
