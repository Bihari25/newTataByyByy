package com.uhg.ihr.provider.integration

import com.fasterxml.jackson.databind.JsonNode
import com.uhg.ihr.provider.api.model.PatientHealthItemRequest
import com.uhg.ihr.provider.util.HttpTestHelper
import io.micronaut.context.annotation.Property
import io.micronaut.context.annotation.Requires
import io.micronaut.http.HttpRequest
import io.micronaut.http.HttpStatus
import io.micronaut.http.client.HttpClient
import io.micronaut.http.client.annotation.Client
import io.micronaut.runtime.server.EmbeddedServer
import io.micronaut.test.annotation.MicronautTest
import spock.lang.AutoCleanup
import spock.lang.Shared
import spock.lang.Specification
import spock.lang.Unroll

import javax.inject.Inject

import static com.uhg.ihr.provider.api.model.RecordType.*

@Requires(env = "integration")
@Property(name = "micronaut.security.stargate.enabled", value = "false")
@MicronautTest(propertySources = ["application.yml"])
class DataControllerSpec extends Specification {
    public static final String BASE_ENDPOINT = "/individual-health-records/v1.0"

    @Inject
    HttpTestHelper testData

    @Shared
    @AutoCleanup
    @Inject
    EmbeddedServer server

    @Inject
    @Client("/individual-health-records/v1.0")
    HttpClient client

    @Unroll
    def "Get all patient data when #desc provided"() {
        given: "A health item request object"
        PatientHealthItemRequest body = new PatientHealthItemRequest()
        if (classes != null) {
            body.setDataClasses(new HashSet<>(classes))
        }
        HttpTestHelper.configureIhrApiRequest(body, testData.providerChid, "test")

        and: "A HttpClient"
        HttpRequest request = HttpRequest.POST(new URI(HttpTestHelper.host() + BASE_ENDPOINT + "/" + testData.dataPatientChid + "/read"), body)
                .header("JWT", "jwtToken")

        when: "The HttpClient calls the endpoint with #desc"
        HttpStatus responseStatus
        try {
            responseStatus = client.toBlocking().exchange(request, JsonNode.class).status()
        } catch (Exception ignored) {
            responseStatus = HttpStatus.BAD_REQUEST
        }

        then: "The return status should be #status"
        responseStatus == status

        where:
        desc               | status                 | classes
        "all data classes" | HttpStatus.OK          | [CARE_GIVER, CARE_TEAM, HEALTH_OBSERVATIONS, HEALTH_STATUS, PROCEDURE_HISTORY, SERVICE_FACILITY_PROVIDER, VISIT_HISTORY, ADVERSE_REACTION, HEALTH_CONDITION, HEALTH_DEVICE, HEALTH_MEDICATION, IMMUNIZATIONS]
        "no data classes"  | HttpStatus.BAD_REQUEST | null
    }

    def "Get single health item for patient"() {
        given:
        HttpRequest request = HttpRequest.POST(new URI(HttpTestHelper.host() + BASE_ENDPOINT + "/" + testData.dataPatientChid + "/health_item/1/read"), HttpTestHelper.buildIhrProvider(testData.providerChid))
                .header("JWT", "jwtToken")

        when:
        HttpStatus responseStatus = client.toBlocking().exchange(request, JsonNode.class).status()

        then:
        responseStatus == HttpStatus.OK
    }

    def "Get demographics for one patient"() {
        given:
        HttpRequest request = HttpRequest.POST(new URI(testData.baseUri() + "/" + testData.demoPatientChid + "/demographics"), HttpTestHelper.buildIhrProvider(testData.providerChid))
                .header("JWT", "jwtToken")

        when:
        HttpStatus responseStatus = client.toBlocking().exchange(request, JsonNode.class).status()

        then:
        responseStatus == HttpStatus.OK
    }
}
