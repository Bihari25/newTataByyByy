package com.uhg.ihr.provider.api.service.b50

import com.fasterxml.jackson.databind.ObjectMapper
import com.fasterxml.jackson.databind.node.ArrayNode
import com.fasterxml.jackson.databind.node.ObjectNode
import com.uhg.ihr.provider.api.exception.UnhandledApiException
import com.uhg.ihr.provider.api.model.ProviderApiHeaders
import com.uhg.ihr.provider.api.service.backend.b50.B50ApiSecurity
import com.uhg.ihr.provider.api.service.backend.b50.relationship.B50RelationshipClient
import com.uhg.ihr.provider.api.service.backend.b50.relationship.B50RelationshipService
import com.uhg.ihr.provider.api.service.backend.b50.relationship.model.B50RelationshipRequest
import com.uhg.ihr.provider.api.service.relationship.model.Relationship
import com.uhg.ihr.provider.api.service.relationship.model.RelationshipRequest
import com.uhg.ihr.provider.api.service.relationship.model.RelationshipResponse
import com.uhg.ihr.provider.api.service.relationship.model.RelationshipRole
import io.micronaut.context.annotation.Primary
import io.micronaut.http.HttpResponseFactory
import io.micronaut.http.HttpStatus
import io.micronaut.http.client.exceptions.HttpClientResponseException
import io.micronaut.test.annotation.MicronautTest
import io.micronaut.test.annotation.MockBean
import io.reactivex.Maybe
import spock.lang.Specification

import javax.inject.Inject

import static com.uhg.ihr.provider.api.controller.RelationshipControllerSpec.buildRelationshipRequest
import static com.uhg.ihr.provider.api.controller.RelationshipControllerSpec.dateCreator

@MicronautTest
class RelationshipSpec extends Specification {

    private static final String CORRELATION_ID = "test"
    private static final String LANGUAGE = "EN"
    private static final String PROVIDER = "123ACT9999999"
    private static final String PATIENT = "111ACTI888888888"
    private static final RelationshipRole RELATIONSHIP = RelationshipRole.REFERRING_PROVIDER
    private static final int DEFAULT_EFF_DATE_OFFSET = 1
    private static final int DEFAULT_END_DATE_OFFSET = 3
    private static final String JWT_TOKEN = "JWT-TOKEN"

    @Inject
    B50RelationshipService relationshipService

    @Inject
    B50RelationshipClient client

    @Inject
    B50ApiSecurity security

    @MockBean
    @Primary
    B50RelationshipClient buildClient() {
        return Mock(B50RelationshipClient.class)
    }

    @MockBean
    @Primary
    B50ApiSecurity buildSecurity() {
        return Mock(B50ApiSecurity.class)
    }

    B50RelationshipRequest buildB50Request(int effectiveDateOffset, int endDateOffset, String patientId, String providerId, RelationshipRole relationship) {
        B50RelationshipRequest.builder()
                .providerChid(providerId)
                .patientChid(patientId)
                .providerRole(relationship)
                .effectiveDate(dateCreator(effectiveDateOffset))
                .endDate(dateCreator(endDateOffset))
                .build()
    }

    def "relationship create success"() {
        given:
        RelationshipRequest request = buildRelationshipRequest(DEFAULT_EFF_DATE_OFFSET, DEFAULT_END_DATE_OFFSET, RELATIONSHIP, PROVIDER)

        and:
        security.generateProviderBearerToken(PROVIDER) >> JWT_TOKEN

        and:
        ObjectMapper mapper = new ObjectMapper()
        ObjectNode root = mapper.createObjectNode()
        ArrayNode relationshipsArray = mapper.createArrayNode()
        ObjectNode relationshipNode = mapper.createObjectNode()
        ArrayNode participantsArray = mapper.createArrayNode()
        ObjectNode participantNode = mapper.createObjectNode()
        participantNode.put("actorId", PROVIDER)
        participantNode.put("role", RELATIONSHIP.name())
        participantsArray.add(participantNode)
        relationshipNode.set("participants", participantsArray)
        relationshipNode.put("effective_date", request.getEffectiveDate())
        relationshipNode.put("end_date", request.getTerminationDate())
        relationshipsArray.add(relationshipNode)
        root.set("relationships", relationshipsArray)

        and:
        client.manageRelationship(JWT_TOKEN, buildB50Request(DEFAULT_EFF_DATE_OFFSET, DEFAULT_END_DATE_OFFSET, PATIENT, PROVIDER, RELATIONSHIP), CORRELATION_ID, LANGUAGE) >> Maybe.just(root)

        when:
        RelationshipResponse response = relationshipService.manageRelationship(request, PATIENT, new ProviderApiHeaders(CORRELATION_ID, LANGUAGE)).blockingGet()

        then:
        response.patientActorId == PATIENT
        response.providerRelationships.size() == 1
        Relationship rel = response.providerRelationships.get(0)
        rel.getProviderChid() == PROVIDER
        rel.getRelationship() == RELATIONSHIP.name()
        rel.getEffectiveDate() == dateCreator(DEFAULT_EFF_DATE_OFFSET)
        rel.getEndDate() == dateCreator(DEFAULT_END_DATE_OFFSET)
    }

    def "relationship already exists"() {
        given:
        RelationshipRequest request = buildRelationshipRequest(DEFAULT_EFF_DATE_OFFSET, DEFAULT_END_DATE_OFFSET, RELATIONSHIP, PROVIDER)

        and:
        security.generateProviderBearerToken(PROVIDER) >> JWT_TOKEN

        and:
        client.manageRelationship(JWT_TOKEN, buildB50Request(DEFAULT_EFF_DATE_OFFSET, DEFAULT_END_DATE_OFFSET, PATIENT, PROVIDER, RELATIONSHIP), CORRELATION_ID, LANGUAGE) >>
                Maybe.error(new HttpClientResponseException("Test", HttpResponseFactory.INSTANCE.status(HttpStatus.BAD_REQUEST)))

        when:
        Maybe<RelationshipResponse> response = relationshipService.manageRelationship(request, PATIENT, new ProviderApiHeaders(CORRELATION_ID, LANGUAGE))

        then:
        response.isEmpty()
    }

    def "relationship client error"() {
        given:
        RelationshipRequest request = buildRelationshipRequest(DEFAULT_EFF_DATE_OFFSET, DEFAULT_END_DATE_OFFSET, RELATIONSHIP, PROVIDER)

        and:
        security.generateProviderBearerToken(PROVIDER) >> JWT_TOKEN

        and:
        client.manageRelationship(JWT_TOKEN, buildB50Request(DEFAULT_EFF_DATE_OFFSET, DEFAULT_END_DATE_OFFSET, PATIENT, PROVIDER, RELATIONSHIP), CORRELATION_ID, LANGUAGE) >>
                Maybe.error(new HttpClientResponseException("Test", HttpResponseFactory.INSTANCE.status(HttpStatus.INTERNAL_SERVER_ERROR)))

        when:
        relationshipService.manageRelationship(request, PATIENT, new ProviderApiHeaders(CORRELATION_ID, LANGUAGE)).blockingGet()

        then:
        thrown(UnhandledApiException.class)
    }
}
