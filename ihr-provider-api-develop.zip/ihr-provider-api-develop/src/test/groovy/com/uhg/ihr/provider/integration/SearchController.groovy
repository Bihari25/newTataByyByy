package com.uhg.ihr.provider.integration

import com.fasterxml.jackson.databind.JsonNode
import com.uhg.ihr.provider.api.model.*
import com.uhg.ihr.provider.util.HttpTestHelper
import io.micronaut.context.annotation.Property
import io.micronaut.context.annotation.Requires
import io.micronaut.http.HttpRequest
import io.micronaut.http.HttpStatus
import io.micronaut.http.client.HttpClient
import io.micronaut.http.client.annotation.Client
import io.micronaut.runtime.server.EmbeddedServer
import io.micronaut.test.annotation.MicronautTest
import spock.lang.AutoCleanup
import spock.lang.Shared
import spock.lang.Specification
import spock.lang.Unroll

import javax.inject.Inject

@Requires(env = "integration")
@Property(name = "micronaut.security.stargate.enabled", value = "false")
@MicronautTest(propertySources = ["application.yml"])
class SearchController extends Specification {
    public static final String BASE_ENDPOINT = "/individual-health-records/v1.0"

    @Inject
    HttpTestHelper testData

    @Shared
    @AutoCleanup
    @Inject
    EmbeddedServer server

    @Inject
    @Client("/individual-health-records/v1.0")
    HttpClient client

    @Unroll
    def "Get all patient data when #desc provided"() {
        given:
        IhrSearchApiRequest body = new IhrSearchApiRequest()
        SearchRequestCriteria criteria = new SearchRequestCriteria()
        body.setRequestCriteria(criteria)
        SearcRequestMemberDemographic demographic = new SearcRequestMemberDemographic()
        criteria.setMbrDemographics(demographic)
        MemberName name = new MemberName()
        name.setFirst("Winnie")
        name.setLast("Pooh")
        Set<FilterPair> identifiers = new HashSet<>()
        identifiers.add(new FilterPair("SUBSCRIBER_ID", "00472233802"))
        demographic.setName(name)
        demographic.setDateOfBirth("1991/03/27")
        demographic.setIdentifiers(identifiers)
        HttpTestHelper.configureIhrApiRequest(body, testData.providerChid, "test", "EN")

        and:
        HttpRequest request = HttpRequest.POST(new URI(HttpTestHelper.host() + BASE_ENDPOINT + "/search"), body)
                .header("JWT", "jwtToken")

        when:
        HttpStatus responseStatus = client.toBlocking().exchange(request, JsonNode.class).status()

        then:
        responseStatus == HttpStatus.OK
    }
}
