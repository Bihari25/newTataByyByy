package com.uhg.ihr.provider.api.service.b50

import com.fasterxml.jackson.databind.ObjectMapper
import com.fasterxml.jackson.databind.node.ArrayNode
import com.fasterxml.jackson.databind.node.ObjectNode
import com.mongodb.reactivestreams.client.MongoClient
import com.mongodb.reactivestreams.client.MongoClients
import com.uhg.ihr.provider.api.controller.UserRoleControllerSpec
import com.uhg.ihr.provider.api.model.MemberAddress
import com.uhg.ihr.provider.api.model.MemberName
import com.uhg.ihr.provider.api.model.ProviderApiHeaders
import com.uhg.ihr.provider.api.model.profile.*
import com.uhg.ihr.provider.api.service.backend.b50.profile.B50ProfileService
import com.uhg.ihr.provider.api.service.backend.b50.search.model.Address
import com.uhg.ihr.provider.api.service.backend.b50.search.model.Phone
import com.uhg.ihr.provider.api.service.profile.database.UserProfileApiImpl
import com.uhg.ihr.provider.util.HttpTestHelper
import de.flapdoodle.embed.mongo.MongodExecutable
import de.flapdoodle.embed.mongo.MongodProcess
import de.flapdoodle.embed.mongo.MongodStarter
import de.flapdoodle.embed.mongo.config.MongodConfigBuilder
import de.flapdoodle.embed.mongo.config.Net
import de.flapdoodle.embed.mongo.distribution.Version
import de.flapdoodle.embed.process.runtime.Network
import io.micronaut.context.annotation.Primary
import io.micronaut.context.annotation.Property
import io.micronaut.http.HttpRequest
import io.micronaut.http.HttpResponse
import io.micronaut.http.HttpStatus
import io.micronaut.http.client.exceptions.HttpClientResponseException
import io.micronaut.test.annotation.MicronautTest
import io.micronaut.test.annotation.MockBean
import io.reactivex.Flowable
import io.reactivex.Maybe
import lombok.Data
import org.bson.Document
import org.junit.ClassRule
import org.testcontainers.containers.MongoDBContainer
import spock.lang.*

import javax.inject.Inject
import javax.inject.Named

@Ignore
@MicronautTest
class ActorProfileSpec extends Specification {

    private static final String CORRELATION_ID = "test"

    @Shared
    ObjectMapper mapper = new ObjectMapper()

    // TestContainer/ Embedded mongo start

    @Shared
    @Property(name = "mongoportal.test-type", value = "embedded")
    // testcontainer or embedded
    private String testType

    @Shared
    @AutoCleanup
    MongoDBContainer mongoDBContainer = new MongoDBContainer("mongo:" + "4.0.16")

    @MockBean
    @Named("mongoportal")
    @Primary
    MongoClient mongoClient() {
        if ("embedded".equals(testType)) {
            return getEmbeddedMongo()
        } else {
            mongoDBContainer.start()
            return MongoClients.create(mongoDBContainer.getReplicaSetUrl())
        }
    }

    @AutoCleanup(value = "stop")
    private static final MongodStarter starter = MongodStarter.getDefaultInstance()

    @AutoCleanup(value = "stop")
    private static MongodExecutable _mongodExe

    @AutoCleanup(value = "stop")
    private static MongodProcess _mongod

    @AutoCleanup(value = "close")
    private static MongoClient _mongo

    private MongoClient getEmbeddedMongo() {
        if (_mongo == null) {
            int port = Network.getFreeServerPort()
            _mongodExe = starter.prepare(new MongodConfigBuilder()
                    .version(Version.Main.PRODUCTION)
                    .net(new Net("localhost", port, Network.localhostIsIPv6()))
                    .build())
            _mongod = _mongodExe.start()
            _mongo = MongoClients.create("mongodb://localhost:" + port + "/" + database)
        }
        return _mongo
    }

    // TestContainer/ Embedded mongo end

    @Inject
    UserProfileApiImpl profileService

    @Inject
    B50ProfileService b50ProfileService

    @MockBean
    B50ProfileService mockB50Service() {
        return Mock(B50ProfileService.class)
    }

    @Shared
    @Property(name = "profile.security.api")
    String profileSecurityApi

    @Shared
    @Property(name = "mongoportal.database")
    private String database

    @Shared
    @Property(name = "mongoportal.collection.role")
    private String roleCollection

    @Data
    private static class RoleMapping {
        UserProfileConstant.SECURED_CONTEXT securedContext
        List<SecurityMapping> securities
    }

    @Data
    private static class SecurityMapping {
        String key
        List<UserPermission> permissions
    }

    @ClassRule
    def setupSpec() {
        if ("database".equals(profileSecurityApi)) {
            List<RoleMapping> roleMappingList
            List<Document> roleMappingDocumentList = new ArrayList<>()
            URL dummyDataUrl = UserRoleControllerSpec.class.getResource("/security/mock/roles.json")
            System.out.println("DummyDataURL: " + ((dummyDataUrl != null) ? ("path: " + dummyDataUrl.getPath()) : "null or empty"))
            RoleMapping[] dummyData = null

            if (dummyDataUrl != null) {
                try {
                    dummyData = mapper.readValue(dummyDataUrl, RoleMapping[].class)
                }
                catch (IOException e) {
                    System.err.println("throws exception - Unable to read dummy profile data -- using empty data: " + e)
                }
            } else {
                System.err.println("Unable to initialize dummy profile data -- using empty data")
            }

            roleMappingList = dummyData != null ? List.of(dummyData) : new ArrayList<RoleMapping>()

            MongoClient mongoClient = mongoClient()
            final Object modifyMutex = new Object()
            roleMappingList.forEach() {
                roleMapping ->
                    roleMappingDocumentList.add Document.parse(
                            mapper.writeValueAsString(roleMapping))
            }

            synchronized (modifyMutex) {
                if (Success.SUCCESS != Flowable.fromPublisher(
                        mongoClient.
                                getDatabase(database).
                                getCollection(roleCollection).
                                insertMany(roleMappingDocumentList)
                ).
                        firstElement().
                        map({ response -> response }).
                        blockingGet()) {
                    return Maybe.empty()
                }
            }
        }
    }

    UserProfileRequest buildUserProfileRequest(String first, String middle, String last, String email,
                                               String npi, UserProfileConstant.STATUS status,
                                               UserProfileConstant.USER_TYPE type,
                                               UserProfileConstant.IDENTIFIER_CONTEXT contextType, String identifier) {
        IhrUser user = new IhrUser()
        if (first != null || last != null) {
            MemberName name = new MemberName()
            name.setFirst(first)
            name.setLast(last)
            name.setMiddle(middle)
            user.setName(name)
        }
        if (contextType != null)
            user.addIdentifierContext(contextType, identifier)
        user.setEmail(email)
        user.setNpi(npi)
        user.setStatus(status)
        user.setUserType(type)
        UserProfileRequest request = new UserProfileRequest()
        request.setUser(user)
        return request
    }

    UserProfileRequest buildUserProfileRequest(String first, String middle, String last, String email,
                                               String npi, UserProfileConstant.STATUS status,
                                               UserProfileConstant.USER_TYPE type,
                                               UserProfileConstant.IDENTIFIER_CONTEXT contextType1, String identifier1,
                                               UserProfileConstant.IDENTIFIER_CONTEXT contextType2, String identifier2,
                                               String roles, UserProfileConstant.ROLE_CONTEXT filterClassRolesContext,
                                               UserProfileConstant.IDENTIFIER_CONTEXT filterClassIdentifiersContext) {
        IhrUser user = new IhrUser()
        if (first != null || last != null) {
            MemberName name = new MemberName()
            name.setFirst(first)
            name.setLast(last)
            name.setMiddle(middle)
            user.setName(name)
        }
        if (contextType1 != null)
            user.addIdentifierContext(contextType1, identifier1)
        if (contextType2 != null)
            user.addIdentifierContext(contextType2, identifier2)
        user.setEmail(email)
        user.setNpi(npi)
        user.setStatus(status)
        user.setUserType(type)
        user.setAddresses(List.of(new MemberAddress(
                "3085 aspend",
                "",
                "blaine",
                "mn",
                "55449",
                "US",
                "permanent")))
        user.setPhones(List.of(new UserPhone(
                "001-714-328-9108",
                "Home")))
        user.setAgreements(List.of(
                AgreementAcceptance.
                        builder().
                        type(UserProfileConstant.AgreementType.TERMS_OF_USE).
                        acceptanceDate("2020/06/28").
                        version("v 0.1").
                        build()
        ))
        user.setDateOfBirth("1990/06/30")
        user.setGender("F")
        UserProfileRequest request = new UserProfileRequest()
        request.setUser(user)
        request.setExternalSecurity(
                ExternalSecurityAccess.
                        builder().
                        securedContext(UserProfileConstant.SECURED_CONTEXT.LINK).
                        roles(roles == null ? new HashSet<String>() : Set.of(roles)).
                        build()
        )
        request.setResponseFilter(FilterClass.
                builder().
                rolesContext(filterClassRolesContext == null ? null : Set.of(filterClassRolesContext)).
                identifiersContext(filterClassIdentifiersContext == null ? null : Set.of(filterClassIdentifiersContext)).
                build()
        )
        return request
    }

    @Unroll
    def "valid / for #desc"() {
        given:
        UserProfileRequest request = buildUserProfileRequest(
                first, middle, last, email, npi,
                status, userType, contextType, identifier
        )

        and:
        b50ProfileService.registerProfile(request.getUser(), new ProviderApiHeaders(CORRELATION_ID)) >> Maybe.just(contextType == UserProfileConstant.IDENTIFIER_CONTEXT.IHR ? identifier : "123ACTP" + last)

        when:
        UserProfile userProfile  = profileService.registerUser(request, new ProviderApiHeaders(CORRELATION_ID)).blockingGet()

        then:
        userProfile != null
        IhrUser user = userProfile.getUser()
        user != null
        user.getIdentifierContextValue(contextType) == identifier
        user.getNpi() == npi
        user.getStatus() == status
        user.getUserType() == userType

        where:
        desc                                              | first | middle | last     | email                   | npi          | status                              | userType                                 | contextType                                   | identifier
        "ACTIVE, PROVIDER, IHR Identifier, middle"        | "Bob" | "M"    | "Jule0"  | "bob.jule0@joynet.net"  | "1234567890" | UserProfileConstant.STATUS.ACTIVE   | UserProfileConstant.USER_TYPE.PROVIDER   | UserProfileConstant.IDENTIFIER_CONTEXT.IHR    | "1234567890"
        "ACTIVE, PROVIDER with Portal Identifier, middle" | "Bob" | "M"    | "Jule1"  | "bob.jule1@joynet.net"  | "1234567891" | UserProfileConstant.STATUS.ACTIVE   | UserProfileConstant.USER_TYPE.PROVIDER   | UserProfileConstant.IDENTIFIER_CONTEXT.PORTAL | "msid.abcd1"
        "ACTIVE, STAFF, IHR Identifier, middle"           | "Bob" | "M"    | "Jule2"  | "bob.jule2@joynet.net"  | "1234567892" | UserProfileConstant.STATUS.ACTIVE   | UserProfileConstant.USER_TYPE.STAFF      | UserProfileConstant.IDENTIFIER_CONTEXT.IHR    | "1234567892"
        "ACTIVE, STAFF, Portal Identifier, middle"        | "Bob" | "M"    | "Jule3"  | "bob.jule3@joynet.net"  | "1234567893" | UserProfileConstant.STATUS.ACTIVE   | UserProfileConstant.USER_TYPE.STAFF      | UserProfileConstant.IDENTIFIER_CONTEXT.PORTAL | "msid.abcd3"
        "ACTIVE, INDIVIDUAL, IHR Identifier, middle"      | "Bob" | "M"    | "Jule4"  | "bob.jule4@joynet.net"  | "1234567894" | UserProfileConstant.STATUS.ACTIVE   | UserProfileConstant.USER_TYPE.INDIVIDUAL | UserProfileConstant.IDENTIFIER_CONTEXT.IHR    | "1234567894"
        "ACTIVE, INDIVIDUAL, Portal Identifier, middle"   | "Bob" | "M"    | "Jule5"  | "bob.jule5@joynet.net"  | "1234567895" | UserProfileConstant.STATUS.ACTIVE   | UserProfileConstant.USER_TYPE.INDIVIDUAL | UserProfileConstant.IDENTIFIER_CONTEXT.PORTAL | "msid.abcd5"
        "INACTIVE, PROVIDER, IHR Identifier, middle"      | "Bob" | "M"    | "Jule6"  | "bob.jule6@joynet.net"  | "1234567896" | UserProfileConstant.STATUS.INACTIVE | UserProfileConstant.USER_TYPE.PROVIDER   | UserProfileConstant.IDENTIFIER_CONTEXT.IHR    | "1234567896"
        "INACTIVE, PROVIDER, Portal Identifier, middle"   | "Bob" | "M"    | "Jule7"  | "bob.jule7@joynet.net"  | "1234567897" | UserProfileConstant.STATUS.INACTIVE | UserProfileConstant.USER_TYPE.PROVIDER   | UserProfileConstant.IDENTIFIER_CONTEXT.PORTAL | "msid.abcd7"
        "INACTIVE, STAFF, IHR Identifier, middle"         | "Bob" | "M"    | "Jule8"  | "bob.jule8@joynet.net"  | "1234567898" | UserProfileConstant.STATUS.INACTIVE | UserProfileConstant.USER_TYPE.STAFF      | UserProfileConstant.IDENTIFIER_CONTEXT.IHR    | "1234567898"
        "INACTIVE, STAFF, Portal Identifier, middle"      | "Bob" | "M"    | "Jule9"  | "bob.jule9@joynet.net"  | "1234567899" | UserProfileConstant.STATUS.INACTIVE | UserProfileConstant.USER_TYPE.STAFF      | UserProfileConstant.IDENTIFIER_CONTEXT.PORTAL | "msid.abcd9"
        "INACTIVE, INDIVIDUAL, IHR Identifier, middle"    | "Bob" | "M"    | "Jule10" | "bob.jule10@joynet.net" | "1234567900" | UserProfileConstant.STATUS.INACTIVE | UserProfileConstant.USER_TYPE.INDIVIDUAL | UserProfileConstant.IDENTIFIER_CONTEXT.IHR    | "1234567900"
        "INACTIVE, INDIVIDUAL, Portal Identifier, middle" | "Bob" | "M"    | "Jule11" | "bob.jule11@joynet.net" | "1234567901" | UserProfileConstant.STATUS.INACTIVE | UserProfileConstant.USER_TYPE.INDIVIDUAL | UserProfileConstant.IDENTIFIER_CONTEXT.PORTAL | "msid.abcd01"

        "ACTIVE, PROVIDER, IHR Identifier"                | "Bob" | null   | "Jule12" | "bob.jule12@joynet.net" | "1234567902" | UserProfileConstant.STATUS.ACTIVE   | UserProfileConstant.USER_TYPE.PROVIDER   | UserProfileConstant.IDENTIFIER_CONTEXT.IHR    | "1234567902"
        "ACTIVE, PROVIDER, Portal Identifier"             | "Bob" | null   | "Jule13" | "bob.jule13@joynet.net" | "1234567903" | UserProfileConstant.STATUS.ACTIVE   | UserProfileConstant.USER_TYPE.PROVIDER   | UserProfileConstant.IDENTIFIER_CONTEXT.PORTAL | "msid.abcd03"
        "ACTIVE, STAFF, IHR Identifier"                   | "Bob" | null   | "Jule14" | "bob.jule14@joynet.net" | "1234567904" | UserProfileConstant.STATUS.ACTIVE   | UserProfileConstant.USER_TYPE.STAFF      | UserProfileConstant.IDENTIFIER_CONTEXT.IHR    | "1234567904"
        "ACTIVE, STAFF, Portal Identifier"                | "Bob" | null   | "Jule15" | "bob.jule15@joynet.net" | "1234567905" | UserProfileConstant.STATUS.ACTIVE   | UserProfileConstant.USER_TYPE.STAFF      | UserProfileConstant.IDENTIFIER_CONTEXT.PORTAL | "msid.abcd05"
        "ACTIVE, INDIVIDUAL, IHR Identifier"              | "Bob" | null   | "Jule16" | "bob.jule16@joynet.net" | "1234567906" | UserProfileConstant.STATUS.ACTIVE   | UserProfileConstant.USER_TYPE.INDIVIDUAL | UserProfileConstant.IDENTIFIER_CONTEXT.IHR    | "1234567906"
        "ACTIVE, INDIVIDUAL, Portal Identifier"           | "Bob" | null   | "Jule17" | "bob.jule17@joynet.net" | "1234567907" | UserProfileConstant.STATUS.ACTIVE   | UserProfileConstant.USER_TYPE.INDIVIDUAL | UserProfileConstant.IDENTIFIER_CONTEXT.PORTAL | "msid.abcd07"
        "INACTIVE, PROVIDER, IHR Identifier"              | "Bob" | null   | "Jule18" | "bob.jule18@joynet.net" | "1234567908" | UserProfileConstant.STATUS.INACTIVE | UserProfileConstant.USER_TYPE.PROVIDER   | UserProfileConstant.IDENTIFIER_CONTEXT.IHR    | "1234567908"
        "INACTIVE, PROVIDER, Portal Identifier"           | "Bob" | null   | "Jule19" | "bob.jule19@joynet.net" | "1234567909" | UserProfileConstant.STATUS.INACTIVE | UserProfileConstant.USER_TYPE.PROVIDER   | UserProfileConstant.IDENTIFIER_CONTEXT.PORTAL | "msid.abcd09"
        "INACTIVE, STAFF, IHR Identifier"                 | "Bob" | null   | "Jule20" | "bob.jule20@joynet.net" | "1234567910" | UserProfileConstant.STATUS.INACTIVE | UserProfileConstant.USER_TYPE.STAFF      | UserProfileConstant.IDENTIFIER_CONTEXT.IHR    | "1234567910"
        "INACTIVE, STAFF, Portal Identifier"              | "Bob" | null   | "Jule21" | "bob.jule21@joynet.net" | "1234567911" | UserProfileConstant.STATUS.INACTIVE | UserProfileConstant.USER_TYPE.STAFF      | UserProfileConstant.IDENTIFIER_CONTEXT.PORTAL | "msid.abcd11"
        "INACTIVE, INDIVIDUAL, IHR Identifier"            | "Bob" | null   | "Jule22" | "bob.jule22@joynet.net" | "1234567912" | UserProfileConstant.STATUS.INACTIVE | UserProfileConstant.USER_TYPE.INDIVIDUAL | UserProfileConstant.IDENTIFIER_CONTEXT.IHR    | "1234567912"
        "INACTIVE, INDIVIDUAL, Portal Identifier"         | "Bob" | null   | "Jule23" | "bob.jule23@joynet.net" | "1234567913" | UserProfileConstant.STATUS.INACTIVE | UserProfileConstant.USER_TYPE.INDIVIDUAL | UserProfileConstant.IDENTIFIER_CONTEXT.PORTAL | "msid.abcd13"
    }

    @Unroll
    def "invalid / with #desc"() {
        given:
        HttpRequest request = buildUserProfileRequest(
                "/", "test", language, first, null, last, email, npi, profileStatus, profileType, UserProfileConstant.IDENTIFIER_CONTEXT.IHR, "1234567890"
        )

        when:
        client.toBlocking().exchange(request)

        then:
        HttpClientResponseException e = thrown(HttpClientResponseException.class)
        e.status == HttpStatus.BAD_REQUEST

        where:
        desc                     | language | first | last   | email                 | npi          | profileStatus                     | profileType
        "name missing"           | "EN"     | null  | null   | "bob.jule@joynet.net" | "1234567890" | UserProfileConstant.STATUS.ACTIVE | UserProfileConstant.USER_TYPE.PROVIDER
        "ln missing"             | "EN"     | "Bob" | null   | "bob.jule@joynet.net" | "1234567890" | UserProfileConstant.STATUS.ACTIVE | UserProfileConstant.USER_TYPE.PROVIDER
        "fn missing"             | "EN"     | null  | "Jule" | "bob.jule@joynet.net" | "1234567890" | UserProfileConstant.STATUS.ACTIVE | UserProfileConstant.USER_TYPE.PROVIDER
        "bad email"              | "EN"     | "Bob" | "Jule" | "bob.jule.net"        | "1234567890" | UserProfileConstant.STATUS.ACTIVE | UserProfileConstant.USER_TYPE.PROVIDER
        "npi missing"            | "EN"     | "Bob" | "Jule" | "bob.jule@joynet.net" | null         | UserProfileConstant.STATUS.ACTIVE | UserProfileConstant.USER_TYPE.PROVIDER
        "profile status missing" | "EN"     | "Bob" | "Jule" | "bob.jule@joynet.net" | "1234567890" | null                              | UserProfileConstant.USER_TYPE.PROVIDER
        "profile TYPE missing"   | "EN"     | "Bob" | "Jule" | "bob.jule@joynet.net" | "1234567890" | UserProfileConstant.STATUS.ACTIVE | null
        "language missing"       | null     | "Bob" | "Jule" | "bob.jule@joynet.net" | "1234567890" | UserProfileConstant.STATUS.ACTIVE | UserProfileConstant.USER_TYPE.PROVIDER
        "bad language"           | "HAHA"   | "Bob" | "Jule" | "bob.jule@joynet.net" | "1234567890" | UserProfileConstant.STATUS.ACTIVE | UserProfileConstant.USER_TYPE.PROVIDER
    }

    @Unroll
    def "valid /update with #desc"() {
        given:
        HttpRequest request = buildUserProfileRequest(
                "/update", "test", "EN", first, middle, last, email,
                npi, status, userType, contextType1, identifier1
        )

        and:
        b50ProfileService.updateUser(request.getBody().get()) >> Maybe.just(new UserProfile())

        when:
        HttpResponse response = client.toBlocking().exchange(request)

        then:
        response.getStatus() == HttpStatus.OK

        where:
        desc                             | first | middle | last   | email | npi          | status                            | userType                               | contextType1                               | identifier1
        "No update using IHR identifier" | "Bob" | null   | "Jule" | null  | "1234567890" | UserProfileConstant.STATUS.ACTIVE | UserProfileConstant.USER_TYPE.PROVIDER | UserProfileConstant.IDENTIFIER_CONTEXT.IHR | "1234567890"
    }

    @Unroll
    def "valid /update full"() {
        given:
        HttpRequest request = buildUserProfileRequest(
                "/update", "test", "EN", first, middle, last, email,
                npi, status, userType, contextType1, identifier1, contextType2, identifier2, roles, filterClassRolesContext, filterClassIdentifiersContext
        )

        and:
        b50ProfileService.updateUser(request.getBody().get()) >> Maybe.just(new UserProfile())

        when:
        HttpResponse response = client.toBlocking().exchange(request)

        then:
        response.getStatus() == HttpStatus.OK

        where:
        desc                                            | first | middle | last   | email                 | npi          | status                            | userType                               | contextType1                                  | identifier1  | contextType2                                  | identifier2 | roles       | filterClassRolesContext              | filterClassIdentifiersContext
        "Name, email update using IHR identifier"       | "Bob" | null   | "Jule" | "bob.jule@joynet.net" | "1234567890" | UserProfileConstant.STATUS.ACTIVE | UserProfileConstant.USER_TYPE.PROVIDER | UserProfileConstant.IDENTIFIER_CONTEXT.IHR    | "1234567890" | null                                          | null        | ""          | null                                 | null
        "Name, npi update using IHR identifier"         | "Bob" | null   | "Jule" | null                  | "1234567890" | UserProfileConstant.STATUS.ACTIVE | UserProfileConstant.USER_TYPE.PROVIDER | UserProfileConstant.IDENTIFIER_CONTEXT.IHR    | "1234567890" | null                                          | null        | null        | null                                 | UserProfileConstant.IDENTIFIER_CONTEXT.IHR
        "Last, email update using PORTAL identifier"    | "Bob" | null   | "Jule" | "bob.jule@joynet.net" | "1234567891" | UserProfileConstant.STATUS.ACTIVE | UserProfileConstant.USER_TYPE.PROVIDER | UserProfileConstant.IDENTIFIER_CONTEXT.PORTAL | "msid.abcd1" | null                                          | null        | "CLINICIAN" | UserProfileConstant.ROLE_CONTEXT.IHR | null
        "Portal identifier update using IHR identifier" | "Bob" | null   | "Jule" | "bob.jule@joynet.net" | "1234567890" | UserProfileConstant.STATUS.ACTIVE | UserProfileConstant.USER_TYPE.PROVIDER | UserProfileConstant.IDENTIFIER_CONTEXT.IHR    | "1234567890" | UserProfileConstant.IDENTIFIER_CONTEXT.PORTAL | "msid.abcd" | "CLINICIAN" | UserProfileConstant.ROLE_CONTEXT.IHR | UserProfileConstant.IDENTIFIER_CONTEXT.IHR
    }

    def "valid /update no data found"() {
        given:
        HttpRequest request = buildUserProfileRequest(
                "/update", "test", "EN", "Bob", null, "Jule", "bob.jule@joynet.net",
                "1234567890", UserProfileConstant.STATUS.ACTIVE, UserProfileConstant.USER_TYPE.PROVIDER, UserProfileConstant.IDENTIFIER_CONTEXT.PORTAL, "1234567890"
        )

        and:
        b50ProfileService.updateUser(request.getBody().get()) >> Maybe.empty()

        when:
        client.toBlocking().exchange(request)

        then:
        HttpClientResponseException e = thrown(HttpClientResponseException.class)
        e.status == HttpStatus.NOT_FOUND
    }

    @Unroll
    def "invalid /update demographics with #desc"() {
        given:
        HttpRequest request = buildUserProfileRequest(
                "/update", "test", "EN", first, null, last, email, npi, UserProfileConstant.STATUS.ACTIVE,
                UserProfileConstant.USER_TYPE.PROVIDER, UserProfileConstant.IDENTIFIER_CONTEXT.IHR, "1234567890"
        )

        when:
        client.toBlocking().exchange(request)

        then:
        HttpClientResponseException e = thrown(HttpClientResponseException.class)
        e.status == HttpStatus.BAD_REQUEST

        where:
        desc           | first | last   | email                 | npi
        "name missing" | null  | null   | "bob.jule@joynet.net" | "1234567890"
        "ln missing"   | "Bob" | null   | "bob.jule@joynet.net" | "1234567890"
        "fn missing"   | null  | "Jule" | "bob.jule@joynet.net" | "1234567890"
        "bad email"    | "Bob" | "Jule" | "bob.jule.net"        | "1234567890"
        "npi missing"  | "Bob" | "Jule" | "bob.jule@joynet.net" | null
    }

    @Unroll
    def "invalid /update metadata with #desc"() {
        given:
        HttpRequest request = buildUserProfileRequest(
                "/update", "test", language, "Bob", null, "Jule", "bob.jule@joynet.net",
                "1234567890", profileStatus, profileType, contextType, "1234567890"
        )

        when:
        client.toBlocking().exchange(request)

        then:
        HttpClientResponseException e = thrown(HttpClientResponseException.class)
        e.status == HttpStatus.BAD_REQUEST

        where:
        desc                         | language | profileStatus                     | profileType                            | contextType
        "profile status missing"     | "EN"     | null                              | UserProfileConstant.USER_TYPE.PROVIDER | UserProfileConstant.IDENTIFIER_CONTEXT.IHR
        "profile TYPE missing"       | "EN"     | UserProfileConstant.STATUS.ACTIVE | null                                   | UserProfileConstant.IDENTIFIER_CONTEXT.IHR
        "missing identifier context" | "EN"     | UserProfileConstant.STATUS.ACTIVE | UserProfileConstant.USER_TYPE.PROVIDER | null
        "language missing"           | null     | UserProfileConstant.STATUS.ACTIVE | UserProfileConstant.USER_TYPE.PROVIDER | UserProfileConstant.IDENTIFIER_CONTEXT.IHR
        "bad language"               | "HAHA"   | UserProfileConstant.STATUS.ACTIVE | UserProfileConstant.USER_TYPE.PROVIDER | UserProfileConstant.IDENTIFIER_CONTEXT.IHR
    }

    UserProfileLookup configureBaseUserProfileLookup(String correlationId, String language,
                                                     String first, String middle, String last, String email, String npi) {
        UserProfileLookup request = new UserProfileLookup()
        LookupContext context = new LookupContext()
        request.setLookupContext(context)
        if (first != null || last != null) {
            MemberName name = new MemberName()
            name.setFirst(first)
            name.setMiddle(middle)
            name.setLast(last)
            context.setName(name)
        }
        context.setEmail(email)
        context.setNpi(npi)
        HttpTestHelper.configureIhrApiRequest(request, correlationId, language)
        return request
    }

    HttpRequest buildUserProfileLookup(String first, String middle, String last, String email, String npi, UserProfileConstant.IDENTIFIER_CONTEXT contextType, String identifier) {
        FilterClass filterClass = new FilterClass()
        filterClass.setIdentifiersContext(Set.of(UserProfileConstant.IDENTIFIER_CONTEXT.IHR))
        filterClass.setRolesContext(Set.of(UserProfileConstant.ROLE_CONTEXT.IHR))
        UserProfileLookup request = configureBaseUserProfileLookup("test", "EN", first, middle, last, email, npi)
        if (contextType != null) {
            Map<UserProfileConstant.IDENTIFIER_CONTEXT, String> ids = new HashMap<>();
            ids.put(contextType, identifier);
            request.getLookupContext().setLookupContexts(ids);
        }
        request.setResponseFilter(filterClass)
        return HttpTestHelper.buildHttpPostRequest(BASE_ENDPOINT + "/lookup", request, "test", "testToken")
    }

    @Unroll
    def "valid /lookup with #desc"() {
        given:
        HttpRequest request = buildUserProfileLookup(first, middle, last, email, npi, idContextType, identifier)

        and:
        b50ProfileService.lookupUserProfile(request.getBody().get()) >> Maybe.just(new UserProfile())

        when:
        HttpResponse response = client.toBlocking().exchange(request)

        then:
        response.getStatus() == HttpStatus.OK

        where:
        desc                                     | first | middle | last    | email                  | npi          | idContextType                              | identifier
        "middle, email, npi, identifier missing" | "Bob" | null   | "Jule2" | null                   | null         | null                                       | null
        "middle, email, npi missing"             | "Bob" | null   | "Jule2" | null                   | null         | UserProfileConstant.IDENTIFIER_CONTEXT.IHR | "1234567892"
        "middle, email, identifier missing"      | "Bob" | null   | "Jule2" | null                   | "1234567892" | null                                       | null
        "middle, email missing"                  | "Bob" | null   | "Jule2" | null                   | "1234567892" | UserProfileConstant.IDENTIFIER_CONTEXT.IHR | "1234567892"
        "middle, npi, identifier missing"        | "Bob" | null   | "Jule2" | "bob.jule2@joynet.net" | null         | null                                       | null
        "middle, npi missing"                    | "Bob" | null   | "Jule2" | "bob.jule2@joynet.net" | null         | UserProfileConstant.IDENTIFIER_CONTEXT.IHR | "1234567892"
        "middle, identifier missing"             | "Bob" | null   | "Jule2" | "bob.jule2@joynet.net" | "1234567892" | null                                       | null
        "middle missing"                         | "Bob" | null   | "Jule2" | "bob.jule2@joynet.net" | "1234567892" | UserProfileConstant.IDENTIFIER_CONTEXT.IHR | "1234567892"
        "email, npi, identifier missing"         | "Bob" | "M"    | "Jule2" | null                   | null         | null                                       | null
        "email, npi missing"                     | "Bob" | "M"    | "Jule2" | null                   | null         | UserProfileConstant.IDENTIFIER_CONTEXT.IHR | "1234567892"
        "email, identifier missing"              | "Bob" | "M"    | "Jule2" | null                   | "1234567892" | null                                       | null
        "email missing"                          | "Bob" | "M"    | "Jule2" | null                   | "1234567892" | UserProfileConstant.IDENTIFIER_CONTEXT.IHR | "1234567892"
        "npi, identifier missing"                | "Bob" | "M"    | "Jule2" | "bob.jule2@joynet.net" | null         | null                                       | null
        "npi missing"                            | "Bob" | "M"    | "Jule2" | "bob.jule2@joynet.net" | null         | UserProfileConstant.IDENTIFIER_CONTEXT.IHR | "1234567892"
        "identifier missing"                     | "Bob" | "M"    | "Jule2" | "bob.jule2@joynet.net" | "1234567892" | null                                       | null
        "all filters"                            | "Bob" | "M"    | "Jule2" | "bob.jule2@joynet.net" | "1234567892" | UserProfileConstant.IDENTIFIER_CONTEXT.IHR | "1234567892"
    }

    @Unroll
    def "valid /lookup user not found with #desc"() {
        given:
        HttpRequest request = buildUserProfileLookup(first, middle, last, email, npi, idContextType, identifier)

        and:
        b50ProfileService.lookupUserProfile(request.getBody().get()) >> Maybe.empty()

        when:
        client.toBlocking().exchange(request)

        then:
        HttpClientResponseException e = thrown(HttpClientResponseException.class)
        e.status == HttpStatus.NOT_FOUND

        where:
        desc                                | first  | middle | last    | email                  | npi          | idContextType                              | identifier
        "all filters - first mismatch"      | "Bob1" | "M"    | "Jule"  | "bob.jule@joynet.net"  | "1234567890" | UserProfileConstant.IDENTIFIER_CONTEXT.IHR | "1234567890"
        "all filters - middle mismatch"     | "Bob"  | "X"    | "Jule"  | "bob.jule@joynet.net"  | "1234567890" | UserProfileConstant.IDENTIFIER_CONTEXT.IHR | "1234567890"
        "all filters - last mismatch"       | "Bob"  | "M"    | "Jule1" | "bob.jule@joynet.net"  | "1234567890" | UserProfileConstant.IDENTIFIER_CONTEXT.IHR | "1234567890"
        "all filters - email mismatch"      | "Bob"  | "M"    | "Jule"  | "bob.jule1@joynet.net" | "1234567890" | UserProfileConstant.IDENTIFIER_CONTEXT.IHR | "1234567890"
        "all filters - npi mismatch"        | "Bob"  | "M"    | "Jule"  | "bob.jule@joynet.net"  | "1234567891" | UserProfileConstant.IDENTIFIER_CONTEXT.IHR | "1234567890"
        "all filters - identifier mismatch" | "Bob"  | "M"    | "Jule"  | "bob.jule@joynet.net"  | "1234567890" | UserProfileConstant.IDENTIFIER_CONTEXT.IHR | "1234567990"
    }

    HttpRequest buildInvalidUserProfileLookup(String endpoint, String correlationId, String language, String first, String last, String email,
                                              String npi, String idContext, String idValue, String filterRoleContext, String filterIdContext) {
        UserProfileLookup request = new UserProfileLookup()
        LookupContext context = new LookupContext()
        request.setLookupContext(context)
        if (first != null || last != null) {
            MemberName name = new MemberName()
            name.setFirst(first)
            name.setLast(last)
            context.setName(name)
        }
        context.setEmail(email)
        context.setNpi(npi)
        HttpTestHelper.configureIhrApiRequest(request, correlationId, language)
        ObjectNode requestJson = (ObjectNode) mapper.readTree(mapper.writeValueAsString(request))
        if (idContext != null && idValue != null) {
            ArrayNode lookupContexts = mapper.createArrayNode()
            ObjectNode identifierContext = mapper.createObjectNode()
            lookupContexts.add(identifierContext)
            identifierContext.put("contextType", idContext)
            identifierContext.put("identifier", idValue)
            ((ObjectNode) requestJson.get("lookupContext")).set("lookupContexts", lookupContexts)
        }
        ObjectNode responseFilter = mapper.createObjectNode()
        requestJson.set("responseFilter", responseFilter)
        if (filterRoleContext != null) {
            ArrayNode rolesContext = mapper.createArrayNode()
            responseFilter.set("rolesContext", rolesContext)
            rolesContext.add(filterRoleContext)
        }
        if (filterIdContext != null) {
            ArrayNode identifiersContext = mapper.createArrayNode()
            responseFilter.set("identifiersContext", identifiersContext)
            identifiersContext.add(filterIdContext)
        }
        return HttpTestHelper.buildHttpPostRequest(endpoint, requestJson, correlationId, "testToken")
    }

    @Unroll
    def "invalid /lookup with IhrApiRequest #desc"() {
        given:
        HttpRequest request = buildInvalidUserProfileLookup(
                BASE_ENDPOINT + "/lookup", "test", language, "Bob", "Jule",
                "bob.jule@joynet.net", "1234567890", UserProfileConstant.IDENTIFIER_CONTEXT.IHR.toString(), "id",
                UserProfileConstant.ROLE_CONTEXT.IHR.toString(), UserProfileConstant.IDENTIFIER_CONTEXT.IHR.toString()
        )

        when:
        client.toBlocking().exchange(request)

        then:
        HttpClientResponseException e = thrown(HttpClientResponseException.class)
        e.status == HttpStatus.BAD_REQUEST

        where:
        desc               | language
        "language missing" | null
        "bad language"     | "HAHA"
    }

    @Unroll
    def "invalid /lookup with LookupContext #desc"() {
        given:
        HttpRequest request = buildInvalidUserProfileLookup(
                BASE_ENDPOINT + "/lookup", "test", "EN", first, last, email, npi,
                idContextType, "id", UserProfileConstant.ROLE_CONTEXT.IHR.toString(), UserProfileConstant.IDENTIFIER_CONTEXT.IHR.toString()
        )

        when:
        client.toBlocking().exchange(request)

        then:
        HttpClientResponseException e = thrown(HttpClientResponseException.class)
        e.status == HttpStatus.BAD_REQUEST

        where:
        desc               | first | last   | email                 | npi          | idContextType
        "bad context TYPE" | "Bob" | "Jule" | "bob.jule@joynet.net" | "1234567890" | "BAD_TYPE"
        "bad email"        | "Bob" | "Jule" | "bob.jule.net"        | "1234567890" | UserProfileConstant.IDENTIFIER_CONTEXT.IHR.toString()
        "fn missing"       | null  | "Jule" | "bob.jule@joynet.net" | "1234567890" | UserProfileConstant.IDENTIFIER_CONTEXT.IHR.toString()
        "ln missing"       | "Bob" | null   | "bob.jule@joynet.net" | "1234567890" | UserProfileConstant.IDENTIFIER_CONTEXT.IHR.toString()
    }

    @Unroll
    def "invalid /lookup with FilterClass #desc"() {
        given:
        HttpRequest request = buildInvalidUserProfileLookup(
                BASE_ENDPOINT + "/lookup", "test", "EN", "Bob", "Jule", "bob.jule@joynet.net", "123467890",
                UserProfileConstant.IDENTIFIER_CONTEXT.IHR.toString(), "id", rolesContext, identifiersContext
        )

        when:
        client.toBlocking().exchange(request)

        then:
        HttpClientResponseException e = thrown(HttpClientResponseException.class)
        e.status == HttpStatus.BAD_REQUEST

        where:
        desc                     | rolesContext                                    | identifiersContext
        "bad identifier context" | UserProfileConstant.ROLE_CONTEXT.IHR.toString() | "BAD_TYPE"
        "bad roles context"      | "BAD_TYPE"                                      | UserProfileConstant.IDENTIFIER_CONTEXT.IHR.toString()
    }

    def "valid /register"() {
        given:
        HttpRequest request = buildUserProfileRequest(
                "/register", "test", "EN", "Bob", null, "Jule", "bob.jule@joynet.net",
                "1234567890", UserProfileConstant.STATUS.ACTIVE, UserProfileConstant.USER_TYPE.PROVIDER,
                UserProfileConstant.IDENTIFIER_CONTEXT.IHR, "1234567890",
                UserProfileConstant.IDENTIFIER_CONTEXT.PORTAL, "msid.abcd", "CLINICIAN",
                UserProfileConstant.ROLE_CONTEXT.IHR, UserProfileConstant.IDENTIFIER_CONTEXT.IHR)

        and:
        b50ProfileService.registerUser(request.getBody().get()) >> Maybe.just(new UserProfile())

        when:
        HttpResponse response = client.toBlocking().exchange(request)

        then:
        response.getStatus() == HttpStatus.OK
    }

    @Unroll
    def "invalid /register with #desc"() {
        given:
        HttpRequest request = buildUserProfileRequest(
                "/register", "test", language, first, null, last, email, npi, profileStatus, profileType,
                UserProfileConstant.IDENTIFIER_CONTEXT.IHR, "1234567890"
        )

        when:
        client.toBlocking().exchange(request)

        then:
        HttpClientResponseException e = thrown(HttpClientResponseException.class)
        e.status == HttpStatus.BAD_REQUEST

        where:
        desc                     | language | first | last   | email                 | npi          | profileStatus                     | profileType
        "name missing"           | "EN"     | null  | null   | "bob.jule@joynet.net" | "1234567890" | UserProfileConstant.STATUS.ACTIVE | UserProfileConstant.USER_TYPE.PROVIDER
        "ln missing"             | "EN"     | "Bob" | null   | "bob.jule@joynet.net" | "1234567890" | UserProfileConstant.STATUS.ACTIVE | UserProfileConstant.USER_TYPE.PROVIDER
        "fn missing"             | "EN"     | null  | "Jule" | "bob.jule@joynet.net" | "1234567890" | UserProfileConstant.STATUS.ACTIVE | UserProfileConstant.USER_TYPE.PROVIDER
        "bad email"              | "EN"     | "Bob" | "Jule" | "bob.jule.net"        | "1234567890" | UserProfileConstant.STATUS.ACTIVE | UserProfileConstant.USER_TYPE.PROVIDER
        "npi missing"            | "EN"     | "Bob" | "Jule" | "bob.jule@joynet.net" | null         | UserProfileConstant.STATUS.ACTIVE | UserProfileConstant.USER_TYPE.PROVIDER
        "profile status missing" | "EN"     | "Bob" | "Jule" | "bob.jule@joynet.net" | "1234567890" | null                              | UserProfileConstant.USER_TYPE.PROVIDER
        "profile TYPE missing"   | "EN"     | "Bob" | "Jule" | "bob.jule@joynet.net" | "1234567890" | UserProfileConstant.STATUS.ACTIVE | null
        "language missing"       | null     | "Bob" | "Jule" | "bob.jule@joynet.net" | "1234567890" | UserProfileConstant.STATUS.ACTIVE | UserProfileConstant.USER_TYPE.PROVIDER
        "bad language"           | "HAHA"   | "Bob" | "Jule" | "bob.jule@joynet.net" | "1234567890" | UserProfileConstant.STATUS.ACTIVE | UserProfileConstant.USER_TYPE.PROVIDER
    }

    def "valid /{profile_id}/read"() {
        given:
        String profileId = "1234567890"
        HttpRequest request = HttpTestHelper.buildHttpGetRequest(BASE_ENDPOINT + "/" + profileId + "/read" , "testToken")

        and:
        b50ProfileService.getUserProfileByChid(profileId, api) >> Maybe.just(new UserProfile())

        when:
        HttpResponse response = client.toBlocking().exchange(request)

        then:
        response.getStatus() == HttpStatus.OK
    }

    def "valid /{profile_id}/read no data found"() {
        given:
        String profileId = "123ACTP1234567890"
        HttpRequest request = HttpTestHelper.buildHttpGetRequest(BASE_ENDPOINT + "/" + profileId + "/read", "test", "testToken")

        and:
        b50ProfileService.getProfile(profileId, new ProviderApiHeaders(CORRELATION_ID)) >> Maybe.empty()

        when:
        client.toBlocking().exchange(request)

        then:
        HttpClientResponseException e = thrown(HttpClientResponseException.class)
        e.getStatus() == HttpStatus.NOT_FOUND
    }
}
