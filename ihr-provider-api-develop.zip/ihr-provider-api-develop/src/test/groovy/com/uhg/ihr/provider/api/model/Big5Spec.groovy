package com.uhg.ihr.provider.api.model

import spock.lang.Specification
import spock.lang.Unroll

import javax.validation.ConstraintViolation
import javax.validation.Validation
import javax.validation.Validator
import javax.validation.ValidatorFactory

class Big5Spec extends Specification {
    @Unroll
    void "Check for Bad Data"() {
        setup:
        def big5 = new Big5()
        big5.setDateOfBirth dateOfBirth
        big5.setFirstName firstName
        big5.setLastName lastName
        big5.setPolicyNumber policyNumber
        big5.setSearchId searchId

        when:
        def factory = Validation.buildDefaultValidatorFactory()
        def validator = factory.getValidator()
        def violations = validator.validate(big5)

        then:
        violations.size() == size
        if (size > 0) {
            def message = violations.first()
            def returned = message.message
            returned == expected
        }

        where:
        dateOfBirth    | firstName       | lastName       | policyNumber       | searchId       | size | expected
        //null           | "My First Name" | "My Last Name" | "My Policy Number" | "My Search Id" | 1    | "The request could not be validated. A date of birth was not provided."
        "1945-10-10"   | null            | "My Last Name" | "My Policy Number" | "My Search Id" | 1    | "The request could not be validated. A first name was not provided."
        "1945-10-10"   | "My First Name" | null           | "My Policy Number" | "My Search Id" | 1    | "The request could not be validated. A last name was not provided."
        "1945-10-10"   | "My First Name" | "My Last Name" | null               | "My Search Id" | 0    | "The policy number in the big5 record may not be blank."
        "1945-10-10"   | "My First Name" | "My Last Name" | "My Policy Number" | null           | 1    | "The request could not be validated. A search id was not provided."
        null   | "My First Name" | "My Last Name" | "My Policy Number" | "My Search Id" | 1    | "The request could not be validated. A date of birth was not provided."
    }

    @Unroll
    void "Check for Good Data"() {
        setup:
        def big5 = new Big5()
        big5.setDateOfBirth dateOfBirth
        big5.setFirstName firstName
        big5.setLastName lastName
        big5.setPolicyNumber policyNumber
        big5.setSearchId searchId

        when:
        ValidatorFactory factory = Validation.buildDefaultValidatorFactory()
        Validator validator = factory.getValidator()
        Set<ConstraintViolation<Big5>> violations = validator.validate(big5)

        then:
        violations.size() == 0
        big5.getDateOfBirth() == dateOfBirth
        big5.getFirstName() == firstName
        big5.getLastName() == lastName
        big5.getPolicyNumber() == policyNumber
        big5.getSearchId() == searchId

        where:
        dateOfBirth    | firstName       | lastName       | policyNumber       | searchId
        "1945-10-10"   | "My First Name" | "My Last Name" | "My Policy Number" | "My Search Id"
    }

    def "Test All Args Constructor"() {
        setup:
        String dateOfBirth = "2010/10/10"
        String firstName = "first"
        String lastName = "last"
        String policyNumber = "policy"
        String searchId = "id"

        when:
        def big5 = new Big5(firstName, lastName, dateOfBirth, policyNumber, searchId, IdType.searchId, new ArrayList<>())

        then:
        big5.getDateOfBirth() == dateOfBirth
        big5.getFirstName() == firstName
        big5.getLastName() == lastName
        big5.getPolicyNumber() == policyNumber
        big5.getSearchId() == searchId
    }

    def "Test Builder"() {
        setup:
        String dateOfBirth = "2010/10/10"
        String firstName = "first"
        String lastName = "last"
        String policyNumber = "policy"
        String searchId = "id"

        when:
        def big5 = Big5.builder().dateOfBirth(dateOfBirth).firstName(firstName).lastName(lastName).policyNumber(policyNumber).searchId(searchId).build()

        then:
        big5.dateOfBirth == dateOfBirth
        big5.firstName == firstName
        big5.lastName == lastName
        big5.policyNumber == policyNumber
        big5.searchId == searchId
    }
}
