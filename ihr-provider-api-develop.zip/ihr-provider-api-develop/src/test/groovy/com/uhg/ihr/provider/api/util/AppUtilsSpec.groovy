package com.uhg.ihr.provider.api.util

import com.uhg.ihr.provider.api.exception.IhrBadRequestException
import spock.lang.Specification
import spock.lang.Unroll

@Unroll
class AppUtilsSpec extends Specification {


    def "AppUtils::parseInputDate happy path : #scenario"() {
        when:
        def result = AppUtils.parseInputDate(inputValue, "no exception")

        then:
        result

        where:
        scenario               | inputValue
        "Valid date value"     | "2019-12-25"
        "Valid iso date value" | "2019-12-25 10:21:23"
    }

    def "AppUtils::parseInputDate exception path : #scenario"() {
        when:
        AppUtils.parseInputDate(inputValue, exceptionMsg)

        then:
        IhrBadRequestException ihrBadRequestEx = thrown()
        ihrBadRequestEx.message.contains(exceptionMsg)

        where:
        scenario                                 | inputValue          | exceptionMsg
        "Valid text value"                       | "test value"        | "Non date value"
        "Invalid date without days"              | "2018-12"           | "Date value without day"
        "Invalid date without month"             | "2018--12"          | "Date value without month"
        "Invalid iso date value only hours"      | "2019-12-25 12"     | "Date value only hours"
        "Invalid iso date value without minutes" | "2019-12-25 12::12" | "Date value only hours without minutes"
        "Invalid iso date value without seconds" | "2019-12-25 12:25"  | "Date value only hours without seconds"
        "Invalid date value separator /"         | "2019/12/25"        | "Invalid date value separator /"
        "Invalid date value separator -/"        | "2019-12/25"        | "Invalid date value separator /"
        "Empty date value"                       | ""                  | "Empty date value"
        "Null date value"                        | null                | "Null date value"
    }


    def "AppUtils::isDateValue : #scenario"() {
        when:
        def result = AppUtils.isDateValue(inputValue)

        then:
        result == expectedResult

        where:
        scenario                                 | inputValue            || expectedResult
        "Valid date value"                       | "2019-12-25"          || true
        "Valid iso date value"                   | "2019-12-25 10:21:23" || true
        "Valid text value"                       | "test value"          || false
        "Invalid date without days"              | "2018-12"             || true
        "Invalid date without month"             | "2018--12"            || true
        "Invalid iso date value only hours"      | "2019-12-25 12"       || true
        "Invalid iso date value without minutes" | "2019-12-25 12::12"   || true
        "Invalid iso date value without seconds" | "2019-12-25 12:25"    || true
    }


    def "AppUtils::todayDate"() {
        when:
        def result = AppUtils.todayDate()

        then:
        result
    }

    def "AppUtils::isDateInBetween : #scenario"() {
        given:
        def startDateValue = AppUtils.parseInputDate(startDate, "no exception")
        def endDateValue = AppUtils.parseInputDate(endDate, "no exception")
        def crDateValue = AppUtils.parseInputDate(crDate, "no exception")

        when:
        def result = AppUtils.isDateInBetween(startDateValue, endDateValue, crDateValue)

        then:
        result == expectedResult

        where:
        scenario                      | startDate    | endDate      | crDate       || expectedResult
        "CR Date with in range"       | "2018-12-25" | "2019-12-25" | "2019-02-27" || true
        "CR Date equal to start date" | "2018-12-25" | "2019-12-25" | "2018-12-25" || true
        "CR Date equal to end date"   | "2018-12-25" | "2019-12-25" | "2019-12-25" || true
        "CR Date before start date"   | "2018-12-25" | "2019-12-25" | "2018-12-24" || false
        "CR Date after end date"      | "2018-12-25" | "2019-12-25" | "2019-12-26" || false
    }
}
