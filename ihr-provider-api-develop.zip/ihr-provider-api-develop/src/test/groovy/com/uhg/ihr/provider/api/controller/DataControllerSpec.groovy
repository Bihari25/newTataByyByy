package com.uhg.ihr.provider.api.controller

import com.fasterxml.jackson.databind.JsonNode
import com.fasterxml.jackson.databind.ObjectMapper
import com.fasterxml.jackson.databind.node.ArrayNode
import com.fasterxml.jackson.databind.node.ObjectNode
import com.uhg.ihr.provider.api.model.*
import com.uhg.ihr.provider.api.service.DataServiceInterface
import com.uhg.ihr.provider.api.service.backend.SearchAdapterInterface
import com.uhg.ihr.provider.util.HttpTestHelper
import io.micronaut.context.annotation.Primary
import io.micronaut.context.annotation.Property
import io.micronaut.http.HttpRequest
import io.micronaut.http.HttpResponse
import io.micronaut.http.HttpStatus
import io.micronaut.http.client.HttpClient
import io.micronaut.http.client.annotation.Client
import io.micronaut.http.client.exceptions.HttpClientResponseException
import io.micronaut.runtime.server.EmbeddedServer
import io.micronaut.test.annotation.MicronautTest
import io.micronaut.test.annotation.MockBean
import io.reactivex.Maybe
import spock.lang.AutoCleanup
import spock.lang.Shared
import spock.lang.Specification
import spock.lang.Unroll

import javax.inject.Inject

import static com.uhg.ihr.provider.api.model.RecordType.*

@Property(name = "micronaut.security.stargate.enabled", value = "false")
@MicronautTest
class DataControllerSpec extends Specification {

    public static final String CORRELATION_ID = "test"
    public static final String BASE_ENDPOINT = "/individual-health-records/v1.0"
    ObjectMapper mapper = new ObjectMapper()

    @Inject
    SearchAdapterInterface search

    @Inject
    DataServiceInterface data

    @Shared
    @AutoCleanup
    @Inject
    EmbeddedServer server

    @Inject
    @Client("/individual-health-records/v1.0")
    HttpClient client

    @MockBean
    @Primary
    SearchAdapterInterface mockSearchAdapter() {
        return Mock(SearchAdapterInterface.class)
    }

    @MockBean
    @Primary
    DataServiceInterface mockDataService() {
        return Mock(DataServiceInterface.class)
    }

    def "Valid /{patient-id}/demographics with all parameters"() {
        given:
        IhrApiWithActorRequest body = new IhrApiWithActorRequest()
        HttpTestHelper.configureIhrApiWithActorRequest(body, "999ACTP999999999")

        and:
        HttpRequest request = HttpTestHelper.buildHttpPostRequest(BASE_ENDPOINT + "/123ACT123123123/demographics", body, CORRELATION_ID, "testToken")

        and:
        search.getPatientDemographics("123ACT123123123", "999ACTP999999999", new ProviderApiHeaders(CORRELATION_ID)) >> Maybe.just(new PatientDemographics())

        when:
        HttpResponse<JsonNode> response = client.toBlocking().exchange(request, JsonNode.class)

        then:
        response.status() == HttpStatus.OK
    }

    def "Valid /{patient-id}/demographics with no data found"() {
        given:
        IhrApiWithActorRequest body = new IhrApiWithActorRequest()
        HttpTestHelper.configureIhrApiWithActorRequest(body, "999ACTP999999999")

        and:
        HttpRequest request = HttpTestHelper.buildHttpPostRequest(BASE_ENDPOINT + "/123ACT123123123/demographics", body, CORRELATION_ID, "testToken")

        and:
        search.getPatientDemographics("123ACT123123123", "999ACTP999999999", new ProviderApiHeaders(CORRELATION_ID)) >> Maybe.empty()

        when:
        client.toBlocking().exchange(request, JsonNode.class)

        then:
        HttpClientResponseException e = thrown(HttpClientResponseException.class)
        e.status == HttpStatus.NOT_FOUND
    }

    @Unroll
    def "Invalid /{patient-id}/demographics with #desc"() {
        given:
        IhrApiWithActorRequest body = new IhrApiWithActorRequest()
        HttpTestHelper.configureIhrApiWithActorRequest(body, actorId)

        and:
        HttpRequest request = HttpTestHelper.buildHttpPostRequest(BASE_ENDPOINT + "/" + actor + "/demographics", body, CORRELATION_ID, "testToken")

        when:
        client.toBlocking().exchange(request, JsonNode.class)

        then:
        HttpClientResponseException e = thrown(HttpClientResponseException.class)
        e.status == HttpStatus.BAD_REQUEST


        where:
        desc          | language | actorId | actor
        "no actor id" | "EN"     | null    | "123ACT123123123"
    }

    @Unroll
    def "Valid /{patient-id}/read with #desc"() {
        given:
        PatientHealthItemRequest body = new PatientHealthItemRequest(new HashSet<RecordType>(dataClasses))
        HttpTestHelper.configureIhrApiWithActorRequest(body, "999ACTP999999999")

        and:
        HttpRequest request = HttpTestHelper.buildHttpPostRequest(BASE_ENDPOINT + "/123ACT123123123/read", body, CORRELATION_ID, "testToken")

        and:
        data.getFilteredByActorChid(
                "999ACTP999999999", "123ACT123123123",
                new HashSet<RecordType>(dataClasses), new ProviderApiHeaders(CORRELATION_ID)) >> Maybe.just(mapper.createObjectNode())

        when:
        HttpResponse<JsonNode> response = client.toBlocking().exchange(request, JsonNode.class)

        then:
        response.status() == HttpStatus.OK

        where:
        desc               | dataClasses
        "all data classes" | [CARE_GIVER, CARE_TEAM, HEALTH_OBSERVATIONS, HEALTH_STATUS, PROCEDURE_HISTORY, SERVICE_FACILITY_PROVIDER, VISIT_HISTORY, ADVERSE_REACTION, HEALTH_CONDITION, HEALTH_DEVICE, HEALTH_MEDICATION, IMMUNIZATIONS]
        "one data class"   | [CARE_GIVER]
    }

    @Unroll
    def "Valid /{patient-id}/read with no data found"() {
        given:
        PatientHealthItemRequest body = new PatientHealthItemRequest(new HashSet<RecordType>([CARE_GIVER]))
        HttpTestHelper.configureIhrApiWithActorRequest(body, "999ACTP999999999")

        and:
        HttpRequest request = HttpTestHelper.buildHttpPostRequest(BASE_ENDPOINT + "/123ACT123123123/read", body, "test", "testToken")

        and:
        data.getFilteredByActorChid(
                "999ACTP999999999", "123ACT123123123",
                new HashSet<RecordType>([CARE_GIVER]), new ProviderApiHeaders(CORRELATION_ID)) >> Maybe.empty()

        when:
        client.toBlocking().exchange(request, JsonNode.class)

        then:
        HttpClientResponseException e = thrown(HttpClientResponseException.class)
        e.status == HttpStatus.NOT_FOUND
    }

    @Unroll
    def "Invalid /{patient-id}/read with #desc"() {
        given:
        IhrApiWithActorRequest body = new IhrApiWithActorRequest()
        HttpTestHelper.configureIhrApiWithActorRequest(body, actorId)
        ObjectNode jsonBody = (ObjectNode) mapper.readTree(mapper.writeValueAsString(body))
        if (dataClass != null) {
            ArrayNode classes = mapper.createArrayNode()
            classes.add(dataClass)
            jsonBody.set("dataClasses", classes)
        }

        and:
        HttpRequest request = HttpTestHelper.buildHttpPostRequest(BASE_ENDPOINT + "/123ACT123123123/read", jsonBody, CORRELATION_ID, "testToken")

        when:
        client.toBlocking().exchange(request, JsonNode.class)

        then:
        HttpClientResponseException e = thrown(HttpClientResponseException.class)
        e.status == HttpStatus.BAD_REQUEST

        where:
        desc                 | dataClass    | language | actorId
        "no data classes"    | null         | "EN"     | "999ACTP999999999"
        "invalid data class" | "BAD_CLASS"  | "EN"     | "999ACTP999999999"
        "no actor id"        | "CARE_GIVER" | "EN"     | null
    }

    @Unroll
    def "Valid /{patient-id}/health_item/{global-health-item}/read"() {
        given:
        IhrApiWithActorRequest body = new IhrApiWithActorRequest()
        HttpTestHelper.configureIhrApiWithActorRequest(body, "999ACTP999999999")

        and:
        HttpRequest request = HttpTestHelper.buildHttpPostRequest(BASE_ENDPOINT + "/123ACT123123123/health_item/1-1/read", body, CORRELATION_ID, "testToken")

        and:
        data.getGlobalItemByActorChid("999ACTP999999999", "123ACT123123123", new GlobalHealthObjectId("1-1"), new ProviderApiHeaders(CORRELATION_ID)) >> Maybe.just(mapper.createObjectNode())

        when:
        HttpResponse<JsonNode> response = client.toBlocking().exchange(request, JsonNode.class)

        then:
        response.status() == HttpStatus.OK
    }

    @Unroll
    def "Valid /{patient-id}/health_item/{global-health-item}/read with no data found"() {
        given:
        IhrApiWithActorRequest body = new IhrApiWithActorRequest()
        HttpTestHelper.configureIhrApiWithActorRequest(body, "999ACTP999999999")

        and:
        HttpRequest request = HttpTestHelper.buildHttpPostRequest(BASE_ENDPOINT + "/123ACT123123123/health_item/1-1/read", body, CORRELATION_ID, "testToken")

        and:
        data.getGlobalItemByActorChid("999ACTP999999999", "123ACT123123123", new GlobalHealthObjectId("1-1"), new ProviderApiHeaders(CORRELATION_ID)) >> Maybe.empty()

        when:
        client.toBlocking().exchange(request, JsonNode.class)

        then:
        HttpClientResponseException e = thrown(HttpClientResponseException.class)
        e.status == HttpStatus.NOT_FOUND
    }

    @Unroll
    def "Invalid /{patient-id}/health_item/{global-health-item}/read with #desc"() {
        given:
        IhrApiWithActorRequest body = new IhrApiWithActorRequest()
        HttpTestHelper.configureIhrApiWithActorRequest(body, actorId)

        and:
        HttpRequest request = HttpTestHelper.buildHttpPostRequest(BASE_ENDPOINT + "/123ACT123123123/health_item/" + item + "/read", body, CORRELATION_ID, "testToken")

        when:
        client.toBlocking().exchange(request, JsonNode.class)

        then:
        HttpClientResponseException e = thrown(HttpClientResponseException.class)
        e.status == HttpStatus.BAD_REQUEST

        where:
        desc                    | item  | language | actorId
        "malformed global item" | "123" | "EN"     | "999ACTP999999999"
        "no actor id"           | "1-1" | "EN"     | null
    }
}
