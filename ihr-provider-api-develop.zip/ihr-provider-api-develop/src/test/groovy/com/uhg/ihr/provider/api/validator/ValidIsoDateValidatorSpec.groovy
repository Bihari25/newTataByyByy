package com.uhg.ihr.provider.api.validator


import spock.lang.Specification
import spock.lang.Unroll

import javax.validation.ConstraintValidatorContext

@Unroll
class ValidIsoDateValidatorSpec extends Specification {
    ConstraintValidatorContext mockConstraintValidatorContext = Mock(ConstraintValidatorContext)
    ValidIsoDateValidator validIsoDateValidator = new ValidIsoDateValidator()

    def "Validating input date for: #desc"(){
        when:
        def result = validIsoDateValidator.isValid(inputDate, mockConstraintValidatorContext)

        then:
        result == validationResult

        where:
        desc                         | inputDate             || validationResult
        "Valid Date with time"       | "2019-12-17 18:51:40" || true
        "Invalid Date without time"  | "2019/12/17"          || false
        "Invalid Date without day"   | "2019-12"             || false
        "Invalid Date without month" | "2019--21"            || false
        "Invalid Date without year"  | "-04-21"              || false
        "Valid Date without minutes" | "2019-12-17 10"       || false
        "Valid Date without seconds" | "2019-12-17 10:43"    || false
        "Empty Date"                 | ""                    || false
        "Null Date"                  | null                  || false
    }

}
