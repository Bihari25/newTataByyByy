package com.uhg.ihr.provider.api.rest

import io.micrometer.core.instrument.MeterRegistry
import spock.lang.Ignore
import spock.lang.Specification

class SimpleMeterRegistryConfigurerSpec extends Specification {
    SimpleMeterRegistryConfigurer simpleMeterRegistryConfigurer = new SimpleMeterRegistryConfigurer()

    @Ignore
    //TODO Need to find how to mock abtsract class and simulate methods.
    def "SimpleMeterRegistryConfigurer :: configure"() {
        given:
        def meterRegistry = Mock(MeterRegistry) {
            config() >> { new Object() }
        }
        when:
        def result = simpleMeterRegistryConfigurer.configure(meterRegistry)
        then:
        result
    }

    @Ignore
    //TODO Need to find how to mock abtsract class and simulate methods.
    def "SimpleMeterRegistryConfigurer :: supports"() {
        given:
        def meterRegistry = Mock(MeterRegistry) {
            config() >> { new Object() }
        }
        when:
        def result = simpleMeterRegistryConfigurer.supports(meterRegistry)
        then:
        result
    }
}