package com.uhg.ihr.provider.util


import com.uhg.ihr.provider.api.model.Big5
import com.uhg.ihr.provider.api.model.IhrApiRequestOld
import com.uhg.ihr.provider.api.model.MId
import com.uhg.ihr.provider.api.model.RecordType
import com.uhg.ihr.provider.data.model.Payload
import org.apache.commons.lang3.RandomStringUtils

import java.nio.file.Files
import java.nio.file.Path
import java.nio.file.Paths
import java.util.stream.Collectors
import java.util.stream.Stream

/**
 * HttpTestHelper class acts like test harness for sample data for Unit and Integration test cases.
 *
 * @author Ihr-Api Engineering Team
 * @CopyRight (C) All rights reserved to UHG Inc. It's Illegal to reproduce this code.
 */
class TestData {
    static final String TOKEN = 'Bearer eyJ0eXAiOiJKV1QiLCJhbGciOiJIUzUxMiJ9.eyJpc3MiOiJDSElMIiwic3ViIjoiSUhSLVNFTlpJTkctQVBJIiwiZXhwIjoxNTg2OTg2NDI5LCJpYXQiOjE1ODY4ODY0MjksInJvbCI6W119.iDWD4352SwMRm6tck20fTqcYOYIEVoCbBndme7VU8kOMck3EypV-qk3VuUh2xJAVMmIN_xS-Q35t5n2vTJe8vg'

    /**
     * Method to build ihr api request.
     *
     * @return IhrApiRequestOld
     */
    static IhrApiRequestOld sampleIhrApiRequest() {
        def sampleDataClasses = [RecordType.ACTIVE_HEALTH_CONDITION, RecordType.ACTIVE_HEALTH_DEVICE] as Set<RecordType>
        IhrApiRequestOld ihrApiRequest = IhrApiRequestOld.builder().mbrId(sampleMid()).correlationId("CR1234").language("EN").dataClasses(sampleDataClasses).build()
        ihrApiRequest
    }

    /**
     * Method to build sample member id information.
     *
     * @return MId
     */
    static MId sampleMid() {
        def memberId = MId.builder().idType("RALLYID").idValue("Mbr1234").big5(sampleBig5()).build()
        memberId
    }

    /**
     * Method to build sample big 5 information.
     *
     * @return Big5
     */
    static Big5 sampleBig5() {
        def big5 = Big5.builder().firstName("TFName").lastName("TLName")
                .policyNumber("TPLCY12345").searchId("TSrch1234").dateOfBirth("2001/01/01").build()
        big5
    }

    /**
     * Method to build sample play load.
     *
     * @param fileName
     * @return Payload
     */
    Payload buildSamplePayload(String fileName) {
        String payloadContent = readFileContent(fileName)
        Payload payload = Payload.builder()
                .language("EN")
                .taxonomy("Not Used")
                .ihrIdentifier("ACT12345678")
                .payload(payloadContent)
                .build()

        payload
    }

    static String randomChid() {
        return RandomStringUtils.randomAlphanumeric(9).toUpperCase()
    }

    /**
     * Method to read file content.
     *
     * @param fileName
     * @return
     * @throws Exception
     */
    String readFileContent(String fileName) throws Exception {
        Path path = Paths.get(getClass().getClassLoader().getResource(fileName).toURI())
        Stream<String> lines = Files.lines(path)
        String fileContent = lines.collect(Collectors.joining("\n"))
        fileContent
    }

    /**
     * Method to get the file path by file name.
     *
     * @param fileName
     * @return String
     */
    String getFilePath(String fileName) {
        Path path = Paths.get(getClass().getClassLoader().getResource(fileName).toURI())
        path.toString()
    }
}