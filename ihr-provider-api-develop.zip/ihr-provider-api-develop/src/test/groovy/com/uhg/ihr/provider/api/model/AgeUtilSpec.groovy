package com.uhg.ihr.provider.api.model

import spock.lang.Specification
import spock.lang.Unroll

import java.text.SimpleDateFormat

@Unroll
class AgeUtilSpec extends Specification {

    def "toMillis: #desc"() {
        when:
        def calculatedAge = AgeUtil.toMillis(birthdate, deathdate, isDead, currentTime)

        then:
        calculatedAge == result

        where:
        desc                      | birthdate | deathdate | isDead | currentTime | result
        "NEGATIVE_CALCULATED_AGE" | 1000      | 0         | false  | 100         | AgeUtil.NEGATIVE_CALCULATED_AGE
        "INVALID_STOP_TIME"       | 1000      | 100       | true   | 1500        | AgeUtil.INVALID_STOP_TIME
        "Is Alive"                | 1000      | 0         | false  | 1500        | 500
        "Is Dead"                 | 1000      | 1500      | true   | 1700        | 500
    }

    def "toYears: #desc"() {
        when:
        def calculatedYears = AgeUtil.toYears(ageMillis, birthdate)

        then:
        calculatedYears == result

        where:
        desc       | ageMillis    | birthdate    | result
        ">1 years" | 126230400000 | 946684800000 | 3
        "==1 year" | 31622400000  | 946684800000 | 1
        "<1 year"  | 10454400000  | 946684800000 | 0
        "<0 year"  | -1000        | 946684800000 | -1000
    }

    def "toMonths: #desc"() {
        when:
        def calculatedMonths = AgeUtil.toMonths(ageMillis, birthdate)

        then:
        calculatedMonths == result

        where:
        desc        | ageMillis   | birthdate    | result
        ">1 months" | 10454400000 | 946684800000 | 4
        "==1 month" | 2678400000  | 946684800000 | 1
        "<1 month"  | 1209600000  | 946684800000 | 0
        "<0 month"  | -1000       | 946684800000 | -1000
    }

    def "toDays: #desc"() {
        when:
        def calculatedDays = AgeUtil.toDays(ageMillis)

        then:
        calculatedDays == result

        where:
        desc      | ageMillis | result
        ">1 days" | 259200000 | 3
        "==1 day" | 86400000  | 1
        "<1 day"  | 43200000  | 0
        "<0 day"  | -1000     | -1000
    }

    def "verify age string for #desc"() {
        given:
        def currentTime = System.currentTimeMillis()
        def birthdate = currentTime - ageMillis

        when:
        def calculatedAge = AgeUtil.calculateAge(birthdate, 0, isDead)

        then:
        calculatedAge == result

        where:
        desc             | ageMillis    | isDead | result
        ">18 years old"  | 600825600000 | false  | "19 years"
        "2-18 years old" | 168825600000 | false  | "5 years 4 months"
        ">4 months old"  | 13392000000  | false  | "5 months"
        ">=29 days old"  | 2592000000   | false  | "4 weeks"
        ">4 days old"    | 432000000    | false  | "5 days"
        "<4 days old"    | 14400000     | false  | "4 hours"
    }

    def "calculateAge alive string"() {
        given:
        def currenTime = System.currentTimeMillis()
        def birthDateTime = currenTime - ageMillis
        def formatter = new SimpleDateFormat("yyyy-MM-dd")
        def birthdate = formatter.format(new Date(birthDateTime))

        when:
        def calculatedAge = AgeUtil.calculateAge(birthdate)

        then:
        calculatedAge == result

        where:
        ageMillis    | result
        600825600000 | "19 years"
    }

    def "calculateAge alive long"() {
        given:
        def currenTime = System.currentTimeMillis()
        def birthdate = currenTime - ageMillis

        when:
        def calculatedAge = AgeUtil.calculateAge(birthdate)

        then:
        calculatedAge == result

        where:
        ageMillis    | result
        600825600000 | "19 years"
    }

    def "calculateAge dead string: #desc"() {
        given:
        def currenTime = System.currentTimeMillis()
        def birthDateTime = currenTime - ageMillis * 2
        def deathDateTime = birthDateTime + ageMillis
        def formatter = new SimpleDateFormat("yyyy-MM-dd")
        def birthdate = formatter.format(new Date(birthDateTime))
        def deathdate = formatter.format(new Date(deathDateTime))

        when:
        def calculatedAge = AgeUtil.calculateAge(birthdate, deathdate)

        then:
        calculatedAge == result

        where:
        desc               | ageMillis    | result
        "9 years"          | 284601600000 | "9 years"
        "9 years 3 months" | 292636800000 | "9 years 3 months"
    }


    def "calculateAge dead long"() {
        given:
        def currenTime = System.currentTimeMillis()
        def birthdate = currenTime - ageMillis * 2
        def deathdate = currenTime - ageMillis

        when:
        def calculatedAge = AgeUtil.calculateAge(birthdate,deathdate)

        then:
        calculatedAge == result

        where:
        ageMillis    | result
        600825600000 | "19 years"
    }
}
