package com.uhg.ihr.provider.api.model

import spock.lang.Specification
import spock.lang.Unroll

class MemberAddressSpec extends Specification {
    @Unroll
    void "Check for Good Data"() {
/*        setup:
        def memberAddress  = new MemberAddress()
        memberAddress.addressLine1 = addressLine1
        memberAddress.addressLine2 = addressLine2
        memberAddress.postalCode = postalCode
        memberAddress.country = country*/

        when:
        def address = MemberAddress.builder().addressLine1(addressLine1).addressLine2(addressLine2).postalCode(postalCode).country(country).city(city).state(state);

        then:
        address.addressLine1 == addressLine1
        address.addressLine2 == addressLine2
        address.postalCode == postalCode
        address.country == country

        where:
        addressLine1    | addressLine2   | city     | state | postalCode | country
        "1234 kdkd"     |   ""           | "blaine" | "MN"  | "55332"    | "US"
        "1235 kdkd"     |   ""           | "blaine" | "MN"  | "55332"    | "US"
        "1237 kdkd"     |   ""           | "blaine" | "MN"  | "55332"    | "US"
    }

    def "Test All Args Constructor"() {
        setup:
        String addressLine1 = "3085 aspend"
        String addressLine2 = ""
        String postalCode = "55449"
        String country = "US"
        String city ="blaine"
        String state="mn"
        String type="permanent"

        when:
        def address = new MemberAddress(addressLine1,addressLine2,city, state, postalCode,country,type);

        then:
        address.addressLine1 == addressLine1
        address.addressLine2 == addressLine2
        address.postalCode == postalCode
        address.country == country
    }

    def "Test Builder"() {
        setup:
        String addressLine1 = "3085 aspend"
        String addressLine2 = ""
        String postalCode = "55449"
        String country = "US"

        when:
        def address = MemberAddress.builder().addressLine1(addressLine1).addressLine2(addressLine2).postalCode(postalCode).country(country);

        then:
        address.addressLine1 == addressLine1
        address.addressLine2 == addressLine2
        address.postalCode == postalCode
        address.country == country
    }
}
