package com.uhg.ihr.provider.api.security

import com.uhg.ihr.provider.api.model.Big5
import com.uhg.ihr.provider.api.model.IhrApiRequestOld
import com.uhg.ihr.provider.api.model.MId
import com.uhg.ihr.provider.api.model.RecordType
import io.micronaut.context.ApplicationContext
import io.micronaut.http.HttpRequest
import io.micronaut.http.HttpStatus
import io.micronaut.http.MediaType
import io.micronaut.http.client.RxHttpClient
import io.micronaut.runtime.server.EmbeddedServer
import io.micronaut.security.authentication.AuthorizationException
import spock.lang.AutoCleanup
import spock.lang.Ignore
import spock.lang.Shared
import spock.lang.Specification

//@Ignore
class SecuritySpec extends Specification {
    String BAD_TOKEN = "Bearer eyJ0eXAiOiJKV1QiLCJhbGciOiJSUzI1NiJ9.ew0KICJpc3MiOiJsYXllcjctand0LXRlc3QtaXNzdWVyIiwNCiAiYXVkIjoibGF5ZXI3LWp3dC10ZXN0LWF1ZGllbmNlIiwNCiAiaWF0IjoiMTUzMzgyNjQ0NiIsDQogImV4cCI6IjE1MzM4MjY0NTYiLA0KICJzdWIiOiJvb2IiLA0KICJlbmZvcmNlQXBpTGV2ZWxBdXRob3JpemF0aW9uIjoiZmFsc2UiLA0KDQogImNvbnRleHQiOiB7DQogICJ1c2VyIjp7DQogICAibmFtZSI6Imw3eHg0NDI3NDFlZDAzMTI0OWJjOTVmOGQzNzY2YjY0YzkxYSINCiAgICwiY2xpZW50X2lkIjoibDd4eDQ0Mjc0MWVkMDMxMjQ5YmM5NWY4ZDM3NjZiNjRjOTFhIg0KICAgfSwNCiAgImNsaWVudCI6ew0KICAgIm5hbWUiOiJteUFwcCIsDQogICAiYXV0aE1ldGhvZCI6Im9hdXRoIg0KICAgLCJhcHBOYW1lIjogIm15QXBwIiwiYXBwUGxhdGZvcm0iOiAibW9iaWxlIg0KICB9DQogfQ0KfQ.X73D6HZQxKQ8FhoLe-PN5hbzaQVGg8YY-AkoGE4YEx-KSCVDi1GRVobRI8ytlFneltAw3KIuXYDKh8OL9bAr40rblTjiXBwfD8ZKxt2swMG61o5HzROafhlEVrknSh9CB_VkKj-UuBuWpgQAMSd32DL47zaXPMmjkpgzIfZKpqS11moNcKawU2_Xhr6HNFjRUMVe1QAN0sYI8M42RqYTj2dbWvZbOZHBkWn1iYdm9JeF-OL-4Jv46JlOLl8vzZbMqFz74APNuHB_LN3bjee7YPqetB4y0HbpNhpFo9YN9ptfjhKCYdJ-Cfwjomn0hGGiEt7vKq-VdaJdoihFmSPfTg"
    String GOOD_TOKEN = "Bearer eyJhbGciOiJSUzUxMiJ9.eyJyb2xlIjoidXNlciIsImNyZWF0ZWQiOjE1MjI4NDk5OTE3OTcsInVzZXJuYW1lIjoiY2xvdWRzZGsifQ.dzfwWRugsnhPHB0RNT9lZHnX7gvNfGks_ivTc_dQ6-ejM6B1-Chx3WrwBE8drdy4ZbvkVTlHkHRSu3nBZi3Aw0wmN5N7UPUI0wP2KhAHGQS4-LOXgD58ioX9ep3k6hZQqy-oJor5Q3wZS8HJKMMY8izIROtJ5z-z5Y2RRw3ONnQLL5JR40hF9d5mFKA8Y1giEP32qg259MVbdkHNkI0ceq8hrXJ7w_OD4-JPteNhM9EeyNOmzjrKSEG-tkYrWI7g5xgvgMuO8iHFym4WhkDT6FNfcK2xs8QfCbJCZqV28xSIjbrm0El0L7kRzJbsKBxQ7FNJ35iaX18DpQMpu6usUQ"
    // see https://stackoverflow.com/questions/39636792/jvm-takes-a-long-time-to-resolve-ip-address-for-localhost/39698914#39698914
    // if tests take a while
    @Shared
    @AutoCleanup
    EmbeddedServer embeddedServer = ApplicationContext.run(EmbeddedServer)

    @Shared
    RxHttpClient client = embeddedServer
            .applicationContext.createBean(RxHttpClient, embeddedServer.getURL())

    def "Authentication with No Token"() {
        setup:
        def request = HttpRequest
                .GET("https://localhost:8080")

        def jwtFilter = new StargateJwtFilter()

        when:
        jwtFilter.doFilterOnce(request, null)

        then:
        AuthorizationException e = thrown(AuthorizationException.class)
        e.authentication instanceof StargateJwtFilter.JWTAuthentication
        ((StargateJwtFilter.JWTAuthentication)e.authentication).getJwtToken() == "No token provided"
    }

    def "Authentication with Bearer Null"() {
        setup:
        def token = "Bearer "
        def request = HttpRequest
                .GET("https://localhost:8080")
                .header("JWT", token)

        def jwtFilter = new StargateJwtFilter()

        when:
        jwtFilter.doFilterOnce(request, null)

        then:
        AuthorizationException e = thrown(AuthorizationException.class)
        e.authentication instanceof  StargateJwtFilter.JWTAuthentication
        ((StargateJwtFilter.JWTAuthentication)e.authentication).getJwtToken() == token
    }

    def "Authentication with Bad Token"() {
        setup:
        def request = HttpRequest
                .GET("https://localhost:8080")
                .header("JWT", BAD_TOKEN)

        def jwtFilter = new StargateJwtFilter()

        when:
        jwtFilter.doFilterOnce(request, null)

        then:
        AuthorizationException e = thrown(AuthorizationException.class)
        e.authentication instanceof  StargateJwtFilter.JWTAuthentication
        ((StargateJwtFilter.JWTAuthentication)e.authentication).getJwtToken() == BAD_TOKEN
    }

    @Ignore
    def "Check Stargate Token"() {
        setup:
//        def tokenRequest = HttpRequest.GET("https://gateway-stage-core.optum.com/jwt/validation")
        def request = new IhrApiRequestOld()
        request.setCorrelationId "123"
        def recordType = new HashSet<>()
        recordType.add(RecordType.ACTIVE_ADVERSE_REACTION)
        request.setDataClasses recordType
        request.setLanguage "EN"

        def mId = new MId()
//        request.setMbrID mId
        mId.setIdType "RALLYID"
        mId.setIdValue "123"

        def big5 = new Big5()
        mId.setBig5 big5
        big5.setDateOfBirth "1998-03-04"
        big5.setFirstName "MIQUEL"
        big5.setLastName "GRAMMATICO"
//        big5.setPolicyNumber "policy"
//        big5.setSearchId "search id"

        request.setMbrId(mId)
        when:
//        def response = client.toBlocking().exchange(tokenRequest, String.class)
//        def response = client.toBlocking().exchange(tokenRequest, String.class)

        //GOOD_TOKEN = GOOD_TOKEN + response.body()
        println("GOOD TOKEN IS: " + GOOD_TOKEN)
        def httpRequest = HttpRequest
                .POST("/individual-health-records/v1.0/read", request)
                .contentType(MediaType.APPLICATION_JSON)
                .header("JWT", BAD_TOKEN)
                .header("optum-cid-ext", "example")
        def resp = client.toBlocking().exchange(httpRequest)

        then: 'the POST returns data'
        println("Response status is: "+resp.status())
        resp.status() != HttpStatus.UNAUTHORIZED
//        resp.status() == HttpStatus.BAD_REQUEST
    }
}
