package com.uhg.ihr.provider.api.rest

import com.google.common.collect.ImmutableList
import com.uhg.ihr.provider.api.WireMockBaseTest
import com.uhg.ihr.provider.api.controller.SearchController
import com.uhg.ihr.provider.api.exception.IhrBadRequestException
import com.uhg.ihr.provider.api.model.Big5
import com.uhg.ihr.provider.api.model.Id
import com.uhg.ihr.provider.api.model.IdType
import com.uhg.ihr.provider.util.TestData
import io.micronaut.context.annotation.Property
import io.micronaut.http.HttpHeaders
import io.micronaut.http.HttpRequest
import io.micronaut.http.HttpStatus
import io.micronaut.http.MediaType
import io.micronaut.http.client.exceptions.HttpClientResponseException
import io.micronaut.test.annotation.MicronautTest
import spock.lang.Ignore
import spock.lang.Unroll

@MicronautTest
@Property(name = "micronaut.security.stargate.enabled", value = "false")
@Ignore
class SearchControllerSpec extends WireMockBaseTest {
    String BAD_TOKEN = "Bearer eyJ0eXAiOiJKV1QiLCJhbGciOiJSUzI1NiJ9.ew0KICJpc3MiOiJsYXllcjctand0LXRlc3QtaXNzdWVyIiwNCiAiYXVkIjoibGF5ZXI3LWp3dC10ZXN0LWF1ZGllbmNlIiwNCiAiaWF0IjoiMTUzMzgyNjQ0NiIsDQogImV4cCI6IjE1MzM4MjY0NTYiLA0KICJzdWIiOiJvb2IiLA0KICJlbmZvcmNlQXBpTGV2ZWxBdXRob3JpemF0aW9uIjoiZmFsc2UiLA0KDQogImNvbnRleHQiOiB7DQogICJ1c2VyIjp7DQogICAibmFtZSI6Imw3eHg0NDI3NDFlZDAzMTI0OWJjOTVmOGQzNzY2YjY0YzkxYSINCiAgICwiY2xpZW50X2lkIjoibDd4eDQ0Mjc0MWVkMDMxMjQ5YmM5NWY4ZDM3NjZiNjRjOTFhIg0KICAgfSwNCiAgImNsaWVudCI6ew0KICAgIm5hbWUiOiJteUFwcCIsDQogICAiYXV0aE1ldGhvZCI6Im9hdXRoIg0KICAgLCJhcHBOYW1lIjogIm15QXBwIiwiYXBwUGxhdGZvcm0iOiAibW9iaWxlIg0KICB9DQogfQ0KfQ.X73D6HZQxKQ8FhoLe-PN5hbzaQVGg8YY-AkoGE4YEx-KSCVDi1GRVobRI8ytlFneltAw3KIuXYDKh8OL9bAr40rblTjiXBwfD8ZKxt2swMG61o5HzROafhlEVrknSh9CB_VkKj-UuBuWpgQAMSd32DL47zaXPMmjkpgzIfZKpqS11moNcKawU2_Xhr6HNFjRUMVe1QAN0sYI8M42RqYTj2dbWvZbOZHBkWn1iYdm9JeF-OL-4Jv46JlOLl8vzZbMqFz74APNuHB_LN3bjee7YPqetB4y0HbpNhpFo9YN9ptfjhKCYdJ-Cfwjomn0hGGiEt7vKq-VdaJdoihFmSPfTg"
    String TOKEN = "Bearer eyJhbGciOiJSUzUxMiJ9.eyJyb2xlIjoidXNlciIsImNyZWF0ZWQiOjE1MjI4NDk5OTE3OTcsInVzZXJuYW1lIjoiY2xvdWRzZGsifQ.dzfwWRugsnhPHB0RNT9lZHnX7gvNfGks_ivTc_dQ6-ejM6B1-Chx3WrwBE8drdy4ZbvkVTlHkHRSu3nBZi3Aw0wmN5N7UPUI0wP2KhAHGQS4-LOXgD58ioX9ep3k6hZQqy-oJor5Q3wZS8HJKMMY8izIROtJ5z-z5Y2RRw3ONnQLL5JR40hF9d5mFKA8Y1giEP32qg259MVbdkHNkI0ceq8hrXJ7w_OD4-JPteNhM9EeyNOmzjrKSEG-tkYrWI7g5xgvgMuO8iHFym4WhkDT6FNfcK2xs8QfCbJCZqV28xSIjbrm0El0L7kRzJbsKBxQ7FNJ35iaX18DpQMpu6usUQ"
    String CORRELATION_ID = "abcdefg1234567"
    String CORRELATION_HEADER = "optum-cid-ext"
    String CONSUMER_USER_NAME_HEADER = "X-Consumer-Username"
    String CONSUMER_USER_NAME = "abc.def"
    static String COLLECTION_NAME = "ihr2"
    static String CONSUMER_HEADER = "uhgrd.helium"

    static Map<String, Big5> big5Map

    def setupSpec() {
        initBig5Map()
    }

    // remove senzing/data matching routes set after each test
    def cleanup() {
        clearMatches()
    }

    def "it builds a correlation id"() {
        when:
        def result = SearchController.buildCorrelationId("bdy123", "hdr345")
        then:
        result == "Rally Id: bdy123 Stargate Id: hdr345"
    }

    @Unroll
    def "it gets version from header #desc"() {
        when:
        HttpHeaders headers = Mock(HttpHeaders)
        headers.accept() >> ImmutableList.of(MediaType.of(input))

        then:
        output == SearchController.getVersionFromHeader(headers)

        where:
        desc           | input                             || output
        "current"      | "application/json"                || 1
        "all"          | "*/*"                             || 1
        "version 1"    | "application/vnd.uhg.v1+json"     || 1
        "version 35"   | "application/vnd.uhg.v35+json"    || 35
        "doesnt match" | "application/vndasdasda.v35+json" || -1
    }

    @Unroll
    def "it gets version from multiple headers #desc"() {
        when:
        HttpHeaders headers = Mock(HttpHeaders)
        headers.accept() >> input

        then:
        output == SearchController.getVersionFromHeader(headers)

        where:
        desc         | input                                                                                                      || output
        "one way"    | ImmutableList.of(MediaType.of("application/vnd.uhg.v1+json"), MediaType.of("application/vnd.uhg.v2+json")) || 2
        "other way"  | ImmutableList.of(MediaType.of("application/vnd.uhg.v2+json"), MediaType.of("application/vnd.uhg.v1+json")) || 2
        "vs current" | ImmutableList.of(MediaType.of("application/json"), MediaType.of("application/vnd.uhg.v2+json"))            || 2
    }

    def "it returns 406 when type isn't deliverable"() {
        when:
        HttpRequest req = baseRequest().accept(MediaType.of("application/vnd.nah.v1+json"))

        then:
        def caught = false
        try {
            httpClient.toBlocking().exchange(req, String.class)
        } catch (HttpClientResponseException hcre) {
            assert hcre.status == HttpStatus.NOT_ACCEPTABLE
            caught = true
        }

        caught
    }

//    def "it returns media type and versions in 2.0 response"() {
//        when:
//        matchDefault()
//        HttpRequest req = baseRequest().accept(MediaType.of("application/vnd.uhg.v2+json"))
//
//        then:
//        HttpResponse<String> rsp = httpClient.toBlocking().exchange(req, String.class)
//        def jsonSlurper = new JsonSlurper()
//        def body = jsonSlurper.parseText(rsp.getBody().get())
//        "uhg.v2.3.0" == rsp.header("x-uhg-media-TYPE")
//        "2.3.0" == body.apiVersion
//        "2.0.0" == body.dataVersion
//        "2.3.0" == body.schemaVersion
//        body.mbrId
//    }

//    def "it doesnt return versions in response for 1.0"() {
//        when:
//        matchDefault()
//        HttpRequest req = baseRequest().accept(MediaType.of("application/json"))
//
//        then:
//        HttpResponse<String> rsp = httpClient.toBlocking().exchange(req, String.class)
//        "uhg.v1.0.0" == rsp.header("x-uhg-media-TYPE")
//        def jsonSlurper = new JsonSlurper()
//        def body = jsonSlurper.parseText(rsp.getBody().get())
//        null == body.apiVersion
//        null == body.dataVersion
//        null == body.schemaVersion
//        body.mbrID
//    }

    def "it 404s when big5 doesnt match"() {
        when:
        notMatchSenzing(TestData.sampleBig5())
        HttpRequest req = baseRequest().accept(MediaType.of("application/json"))

        then:
        def exceptionThrown = false
        try {
            httpClient.toBlocking().exchange(req, String.class)
        } catch (HttpClientResponseException hcre) {
            assert hcre.getMessage().contains('unable to match user')
            assert 404 == hcre.getResponse().getStatus().code
            assert hcre.getResponse().getBody(String.class).get().contains('unable to match user: ID search found no member with this Big 3 ID')
            exceptionThrown = true
        }

        exceptionThrown
    }

    def "it 404s when payload cannot be found"() {
        when:
        def chid = TestData.randomChid()
        matchSenzingToChid(TestData.sampleBig5(), chid)
        notMatchPayload(chid, "1")
        HttpRequest req = baseRequest().accept(MediaType.of("application/json"))

        then:
        def exceptionThrown = false
        try {
            httpClient.toBlocking().exchange(req, String.class)
        } catch (HttpClientResponseException hcre) {
            assert hcre.getMessage().contains('user was matched but no corresponding data was found')
            assert 404 == hcre.getResponse().getStatus().code
            assert hcre.getResponse().getBody(String.class).get().contains('user was matched but no corresponding data was found')
            exceptionThrown = true
        }

        exceptionThrown
    }

    def "it 500ss when payload has an issue"() {
        when:
        def chid = TestData.randomChid()
        matchSenzingToChid(TestData.sampleBig5(), chid)
        errorPayload(chid, "1")
        HttpRequest req = baseRequest().accept(MediaType.of("application/json"))

        then:
        def exceptionThrown = false
        try {
            httpClient.toBlocking().exchange(req, String.class)
        } catch (HttpClientResponseException hcre) {
            assert hcre.getMessage().contains('there was an error handling this request')
            assert 500 == hcre.getResponse().getStatus().code
            assert hcre.getResponse().getBody(String.class).get().contains('there was an error handling this request')
            exceptionThrown = true
        }

        exceptionThrown
    }

    //FIXME: todo, doesnt quite work because of the fallback between senzing/ii right now
    // will make more sense when senzing is alone
    @Ignore
    def "it 500s when senzing has an issue"() {
        when:
        clearMatches()
        errorIi()
        errorSenzing(TestData.sampleBig5())
        HttpRequest req = baseRequest().accept(MediaType.of("application/json"))

        then:
        def exceptionThrown = false
        try {
            httpClient.toBlocking().exchange(req, String.class)
        } catch (HttpClientResponseException hce) {
            assert hce.getMessage().contains('Server Error')
            assert 500 == hce.getResponse().getStatus().code
            assert hce.getResponse().getBody(String.class).get().contains('Server Error')
            exceptionThrown = true
        }

        exceptionThrown
    }

    def baseRequest() {
        return HttpRequest.POST("/individual-health-records/v1.0/read", TestData.sampleIhrApiRequest())
                .header(CORRELATION_HEADER, CORRELATION_ID)
                .header(CONSUMER_USER_NAME_HEADER, CONSUMER_USER_NAME)
                .header("JWT", TOKEN)
    }

    def big5Base() {
        return Big5.builder().firstName("santa").lastName("claus").dateOfBirth("1940/01/01")
    }

    @Unroll
    def "it builds senzing request #inputBig5"() {
        when:
        def big5 = big5Map.get(inputBig5)
        def req = SearchController.buildSenzingRequest(big5, COLLECTION_NAME)

        then:
        big5 != null
        req.getMemberId() == mem_id
        req.getHcId() == hc_id
        req.getSubscriberId() == sub_id
        req.getSsnNumber() == ssn_id
        req.getMedicareBenfId() == mbi_id
        req.getNameFirst() == big5Base().firstName
        req.getNameLast() == big5Base().lastName
        req.getDateOfBirth() == big5Base().dateOfBirth

        where:
        inputBig5                       || mem_id     | sub_id         | hc_id      | ssn_id | mbi_id
        "searchNull"                    || "searchId" | "searchId"     | "searchId" | null   | null
        "searchOld"                     || "searchId" | "searchId"     | "searchId" | null   | null
        "ssnOld"                        || null       | null           | null       | "SSN"  | null
        "mbiOld"                        || null       | null           | null       | null   | "MBI"
        "memberOld"                     || "memberId" | null           | null       | null   | null
        "hcidOld"                       || null       | null           | "hcId"     | null   | null
        "subscriberIdOld"               || null       | "subscriberId" | null       | null   | null

        "searchOldSsnNew"               || "searchId" | "searchId"     | "searchId" | "SSN"  | null
        "searchNullSsnNew"              || "searchId" | "searchId"     | "searchId" | "SSN"  | null
        "SsnOldSearchNew"               || "searchId" | "searchId"     | "searchId" | "SSN"  | null

        "SsnOldMemberSubcscriberMBINew" || "memberId" | "subscriberId" | null       | "SSN"  | "MBI"

    }

    @Unroll
    def "it sends bad request on id conflicts #inputBig5"() {
        when:
        def big5 = big5Map.get(inputBig5)
        def caught = false

        then:
        try {
            SearchController.buildSenzingRequest(big5, COLLECTION_NAME)
        } catch (IhrBadRequestException ibre) {
            assert ibre.getMessage().contains(conflicting_id)
            caught = true
        }

        caught

        where:
        inputBig5                             || conflicting_id
        //Conflicting
        "conflictingSearchIdNullMemberNew"    || "memberId"
        "conflictingSearchIdOldMemberNew"     || "memberId"
        "conflictingSearchIdOldSubscriberNew" || "subscriberId"
        "conflictingMemberOldSearchIdNew"     || "memberId"
        "conflictingSubscriberOldSearchIdNew" || "subscriberId"
        //Duplicates
        "DuplicateSearchIdNullSearchIdNew"    || "searchId"
        "DuplicateSearchIdOldSearchIdNew"     || "searchId"
        "DuplicateSearchIdNewSearchIdNew"     || "searchId"
        "DuplicateSSNOldSSNNew"               || "SSN"
        "DuplicateSSNNewSSNNew"               || "SSN"
    }

    def initBig5Map() {
        Id memberId = Id.builder().id("memberId").idType(IdType.memberId).build()
        Id subscriberId = Id.builder().id("subscriberId").idType(IdType.subscriberId).build()
        Id searchId = Id.builder().id("searchId").idType(IdType.searchId).build()
        Id ssn = Id.builder().id("SSN").idType(IdType.SSN).build()
        Id mbi = Id.builder().id("MBI").idType(IdType.MBI).build()

        Map<String, Big5> map = new HashMap<>()
        map.put("searchNull", big5Base().searchId("searchId").build())
        map.put("searchOld", big5Base().searchId("searchId").idType(IdType.searchId).build())
        map.put("ssnOld", big5Base().searchId("SSN").idType(IdType.SSN).build())
        map.put("mbiOld", big5Base().searchId("MBI").idType(IdType.MBI).build())
        map.put("memberOld", big5Base().searchId("memberId").idType(IdType.memberId).build())
        map.put("hcidOld", big5Base().searchId("hcId").idType(IdType.hcId).build())
        map.put("subscriberIdOld", big5Base().searchId("subscriberId").idType(IdType.subscriberId).build())

        map.put("searchOldSsnNew", big5Base().searchId("searchId").idType(IdType.searchId)
                .ids(ImmutableList.of(ssn)).build())
        map.put("searchNullSsnNew", big5Base().searchId("searchId")
                .ids(ImmutableList.of(ssn)).build())
        map.put("SsnOldSearchNew", big5Base().searchId("SSN").idType(IdType.SSN)
                .ids(ImmutableList.of(searchId)).build())
        map.put("SsnOldMemberSubcscriberMBINew", big5Base().searchId("SSN").idType(IdType.SSN)
                .ids(ImmutableList.of(memberId, subscriberId, mbi)).build())


        //conflicting
        map.put("conflictingSearchIdNullMemberNew", big5Base().searchId("searchId").idType(IdType.searchId)
                .ids(ImmutableList.of(memberId)).build())
        map.put("conflictingSearchIdOldMemberNew", big5Base().searchId("searchId").idType(IdType.searchId)
                .ids(ImmutableList.of(memberId)).build())
        map.put("conflictingSearchIdOldSubscriberNew", big5Base().searchId("searchId").idType(IdType.searchId)
                .ids(ImmutableList.of(subscriberId)).build())
        map.put("conflictingMemberOldSearchIdNew", big5Base().searchId("memberId").idType(IdType.memberId)
                .ids(ImmutableList.of(searchId)).build())
        map.put("conflictingSubscriberOldSearchIdNew", big5Base().searchId("subscriberId").idType(IdType.subscriberId)
                .ids(ImmutableList.of(searchId)).build())

        //Duplicates
        map.put("DuplicateSearchIdNullSearchIdNew", big5Base().searchId("searchId")
                .ids(ImmutableList.of(searchId)).build())
        map.put("DuplicateSearchIdOldSearchIdNew", big5Base().searchId("searchId").idType(IdType.searchId)
                .ids(ImmutableList.of(searchId)).build())
        map.put("DuplicateSearchIdNewSearchIdNew", big5Base().searchId("SSN").idType(IdType.SSN)
                .ids(ImmutableList.of(searchId, searchId)).build())
        map.put("DuplicateSSNOldSSNNew", big5Base().searchId("SSN").idType(IdType.SSN)
                .ids(ImmutableList.of(ssn)).build())
        map.put("DuplicateSSNNewSSNNew", big5Base().searchId("memberId").idType(IdType.memberId)
                .ids(ImmutableList.of(ssn, ssn)).build())

        //build new
        /*map.put("memberSsn", big5Base().ids(ImmutableList.of(memberId, ssn)).build())
        map.put("searchSsn", big5Base().ids(ImmutableList.of(searchId, ssn)).build())
        map.put("searchMbi", big5Base().ids(ImmutableList.of(searchId, mbi)).build())
        map.put("memberSubSsnMbi", big5Base().ids(ImmutableList.of(memberId, subscriberId, ssn, mbi)).build())
        //conflicts/duplicates
        //new only
        map.put("member2x", big5Base().ids(ImmutableList.of(memberId, memberId)).build())
        map.put("memberSearch", big5Base().ids(ImmutableList.of(memberId, searchId)).build())
        map.put("searchSubscriber", big5Base().ids(ImmutableList.of(searchId, subscriberId)).build())*/

        //new and old
        /*map.put("searchOldNew", big5Base().searchId("searchId")
                .ids(ImmutableList.of(searchId)).build())
        map.put("memberOldNew", big5Base().searchId("memberId").idType(IdType.memberId)
                .ids(ImmutableList.of(searchId)).build())
        map.put("searchOldMemberNew", big5Base().searchId("searchId").idType(IdType.searchId)
                .ids(ImmutableList.of(memberId)).build())
        map.put("subscriberOldSearchNew", big5Base().searchId("subscriberId").idType(IdType.subscriberId)
                .ids(ImmutableList.of(searchId)).build())*/

        big5Map = map
    }

}
