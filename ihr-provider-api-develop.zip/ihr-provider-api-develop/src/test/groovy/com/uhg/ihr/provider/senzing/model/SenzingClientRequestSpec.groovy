package com.uhg.ihr.provider.senzing.model

import com.uhg.ihr.provider.api.model.Id
import com.uhg.ihr.provider.api.service.backend.b50.search.model.Identifier
import com.uhg.ihr.provider.api.service.backend.senzing.SearchRequest
import com.uhg.ihr.provider.util.JsonUtils
import com.uhg.ihr.provider.util.TestData
import spock.lang.Ignore
import spock.lang.Specification
import spock.lang.Unroll

@Unroll
class SenzingClientRequestSpec extends Specification {
    def senzingRequest = buildSenzingRequest()

    @Ignore
    //TODO Need to see why it's failing during command line build.
    def "SenzingRequest:: setters/getters"() {
        expect:
        senzingRequest.getDateOfBirth() == "00-00-3000"
        senzingRequest.getNameFirst() == "tFirst"
        senzingRequest.getNameLast() == "tLast"
        senzingRequest.getGender() == "Female"
        senzingRequest.getHcId() == "17999999999"
        senzingRequest.getHcId() == "17999999999"
    }

    def "SenzingRequest:: toString"() {
        expect:
        senzingRequest.toString().length() > 0
    }

    def "SenzingRequest:: toBuilder"() {
        expect:
        SearchRequest.builder().nameLast("tLast").nameFirst("tFirst").build()
    }

    def "SenzingRequest:: properties translation for senzing request"() {
        given:
        def sampleSenzingRequest = SearchRequest.builder().nameLast("tLast").nameFirst("tFirst")
                .dateOfBirth("99-99-7777").hcId("1666666666").memberId("1666666666")
                .gender("Male").build()
        when:
        def requestJson = JsonUtils.serializeJson(sampleSenzingRequest)
        then:
        requestJson
        requestJson.length() > 0
    }

    def "it builds icue request"() {
        given:
        def sampleSenzingRequest = SearchRequest.builder().nameLast("tLast").nameFirst("tFirst")
                .dateOfBirth("99-99-7777").icue("000112222").build()
        when:
        def requestJson = JsonUtils.serializeJson(sampleSenzingRequest)
        then:
        requestJson.contains("icuememberidentifier\":\"000112222")
    }

    @Ignore
    def "Senzing request build scenarios: #desc"() {
        given:
        def sampleIdInput = [:] as Map<Identifier, Id>
        sampleIdInput.put(Identifier.SSN_NUMBER, Id.builder().id(inputSearchId).idType(Identifier.SSN_NUMBER).build())
        sampleIdInput.put(Identifier.MEDICARE_BENF_ID, Id.builder().id(inputSearchId).idType(Identifier.MEDICARE_BENF_ID).build())
        sampleIdInput.put(Identifier.CARDHOLDER_ID, Id.builder().id(inputSearchId).idType(Identifier.CARDHOLDER_ID).build())
        sampleIdInput.put(Identifier.SEARCH_ID, Id.builder().id(inputSearchId).idType(Identifier.SEARCH_ID).build())
        sampleIdInput.put(Identifier.SUBSCRIBER_ID, Id.builder().id(inputSearchId).idType(Identifier.SUBSCRIBER_ID).build())

        when:
        def result = SearchRequest.builder().id(sampleIdInput).build()

        then:
        result
        result.memberId == inputSearchId
        result.altMemberId == inputSearchId
        result.ssnNumber == inputSearchId
        result.medicareBenfId == inputSearchId
        result.hcId == inputSearchId
        result.subscriberId == expectedSubscriberId
        result.subscriberIdPad == expectedSubscriberPadId

        where:
        desc                                         | inputSearchId   || expectedSubscriberId || expectedSubscriberPadId
        "SearchId without zero"                      | "123456789"     || "123456789"          || "00123456789"
        "11 digits search id"                        | "11123456789"   || "11123456789"        || "11123456789"
        "SearchId with more than 11 digits has zero" | "0012345678999" || "12345678999"        || "0012345678999"
        "10 digit, already has a zero"               | "0123456789"    || "123456789"          || "0123456789"
        "7 digit, already has a zero"                | "0123456"       || "123456"             || "0123456"
        "8 digit, already has a zero"                | "00123456"      || "123456"             || "00123456"
        "9 digit, already has a zero"                | "000123456"     || "123456"             || "000123456"
    }

    def "computeSubscriberIds scenario: #desc"() {
        when:
        def result = SearchRequest.builder().computeSubscriberIds(inputSearchId)

        then:
        result
        result['subscriberId'] == expectedSubscriberId
        result['subscriberPadId'] == expectedSubscriberPadId

        where:
        desc                                         | inputSearchId   || expectedSubscriberId || expectedSubscriberPadId
        "SearchId without zero"                      | "123456789"     || "123456789"          || "00123456789"
        "11 digits search id"                        | "11123456789"   || "11123456789"        || "11123456789"
        "SearchId with more than 11 digits has zero" | "0012345678999" || "12345678999"        || "0012345678999"
        "10 digit, already has a zero"               | "0123456789"    || "123456789"          || "0123456789"
        "7 digit, already has a zero"                | "0123456"       || "123456"             || "0123456"
        "8 digit, already has a zero"                | "00123456"      || "123456"             || "00123456"
        "9 digit, already has a zero"                | "000123456"     || "123456"             || "000123456"
    }


    /**
     * Method to build sample senzing request.
     *
     * @return SearchRequest
     */
    private SearchRequest buildSenzingRequest() {
        TestData testData = new TestData()
        def sampleRequestJson = testData.readFileContent("senzing-request.json")
        def senzingRequest = JsonUtils.deserializeJson(SearchRequest.class, sampleRequestJson)
        senzingRequest
    }
}