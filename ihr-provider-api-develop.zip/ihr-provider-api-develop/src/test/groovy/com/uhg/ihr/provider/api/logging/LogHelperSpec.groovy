package com.uhg.ihr.provider.api.logging

import com.uhg.ihr.provider.api.model.Big5
import com.uhg.ihr.provider.api.model.IhrApiRequestOld
import com.uhg.ihr.provider.api.model.MId
import com.uhg.ihr.provider.api.model.RecordType
import com.uhg.ihr.provider.util.TestData
import io.micronaut.http.HttpRequest
import spock.lang.Specification

import java.time.Instant

class LogHelperSpec extends Specification {

    def defaultRequest = HttpRequest
            .POST("/read", TestData.sampleIhrApiRequest())
            .header("Accept", "application/vnd.uhg.v2+json")
            .header("optum-cid-ext", "Testing")

    def "Log Failure"() {
        setup:
        def logRecord = new LogRecord()
        logRecord.setActor "actor"
        logRecord.setActorIp "actor ip"
        logRecord.setComponent "component"
        logRecord.setCorrelationId "correlation id"
        logRecord.setDetails "details"
        logRecord.setMethod "method"
        logRecord.setOperation "operation"
        logRecord.setResponseCode "response code"
        logRecord.setResponseStatus "response status"
        logRecord.setSourceId "source id"
        def memberId = new MId()
        String idType = "RALLYID"
        String idValue = "value 1"
        memberId.setIdType idType
        memberId.setIdValue idValue
        def big5 = new Big5()
        memberId.setBig5 big5
        def searchId = "id"
        big5.setDateOfBirth "2010/10/10"
        big5.setFirstName "first"
        big5.setLastName "last"
        big5.setPolicyNumber "policy"
        big5.setSearchId searchId
        String stargateCorrId = "stargate corr id"

        def code = "200"
        def status = "Success"
        def details = LogHelper.initializeLogger(null, stargateCorrId, null, 1)
        LogHelper.addDetails(null, null, "LogHelperSpec.fetchDataClasses()", code, status)

        when:
        def ihrIdentifier = "fake id"
        def formattedString = LogHelper.logRecord(null, "LogHelperSpec", details, code, status, ihrIdentifier)

        then:
        formattedString.contains("EVENTTIME=")
        formattedString.contains("|Level=INFO|")
        formattedString.contains("|CORR_ID=null|")
        formattedString.contains("|EVENT=\"R01:Transaction:Start\"|")
        formattedString.contains("|LOGTYPE=\"RESILIENCY_AUDIT\"|")
        formattedString.contains("|SRC_IP=null|")
        def compareStatus = String.format("|STATUS=%s", status)
        formattedString.contains(compareStatus)
        def compareCode = String.format("|CODE=%s|", code)
        formattedString.contains(compareCode)
        formattedString.contains("|OP_ID=")
        formattedString.contains("|COMPONENT=LogHelperSpec|")
        formattedString.contains("|Details=")
    }

    def "Log Success Record"() {
        setup:
        def logRecord = new LogRecord()
        logRecord.setActor "actor"
        logRecord.setActorIp "actor ip"
        logRecord.setComponent "component"
        logRecord.setCorrelationId "correlation id"
        logRecord.setDetails "details"
        logRecord.setMethod "method"
        logRecord.setOperation "operation"
        logRecord.setResponseCode "response code"
        logRecord.setResponseStatus "response status"
        logRecord.setSourceId "source id"
        def request = new IhrApiRequestOld()
        def memberId = new MId()
        String idType = "RALLYID"
        String idValue = "value 1"
        memberId.setIdType idType
        memberId.setIdValue idValue
        def big5 = new Big5()
        memberId.setBig5 big5
        def searchId = "id"
        big5.setDateOfBirth "2010/10/10"
        big5.setFirstName "first"
        big5.setLastName "last"
        big5.setPolicyNumber "policy"
        big5.setSearchId searchId
        request.setMbrId memberId
        request.setLanguage "EN"
        def dataClasses = new HashSet<RecordType>()
        dataClasses.add RecordType.ACTIVE_ADVERSE_REACTION
        request.setDataClasses dataClasses
        def corrId = "unit test"
        def stargateCorrId = "stargate corr id"
        request.setCorrelationId corrId
        def origin = "my left foot"

        def httpRequest = HttpRequest
                .GET("/")
                .header("Accept", "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8")
                .header("optum-cid-ext", stargateCorrId)
                .header("Origin", origin)

        def code = "200"
        def status = "Success"
        def details = LogHelper.initializeLogger(request, stargateCorrId, null, 1)
        def start = Instant.now()
        LogHelper.addDetails(details, start, "LogHelperSpec.fetchDataClasses()", code, status)

        when:
        def ihrIdentifier = "fake id"
        def formattedString = LogHelper.logRecord(httpRequest, "LogHelperSpec", details, code, status, ihrIdentifier)

        then:
        formattedString.contains("EVENTTIME=")
        formattedString.contains("|Level=INFO|")
        formattedString.contains("|ACTOR=localhost|")
        formattedString.contains("|CORR_ID=null|")
        formattedString.contains("|EVENT=\"R01:Transaction:Start\"|")
        formattedString.contains("|LOGTYPE=\"RESILIENCY_AUDIT\"|")
        def compareOrigin = String.format("|SRC_IP=%s|", origin)
        formattedString.contains(compareOrigin)
        formattedString.contains("|ACTOR_IP=localhost:80|")
        def compareStatus = String.format("|STATUS=%s", status)
        formattedString.contains(compareStatus)
        def compareCode = String.format("|CODE=%s|", code)
        formattedString.contains(compareCode)
        formattedString.contains("|METHOD=GET|")
        formattedString.contains("|OP_ID=")
        formattedString.contains("|COMPONENT=LogHelperSpec|")
        formattedString.contains("|Details=")
        def compareStargate = String.format("\"optum-cid-ext\":\"%s\"", stargateCorrId)
        formattedString.contains(compareStargate)
        formattedString.contains("\"rally-corr-id\":\"unit test\",")
        formattedString.contains("\"big5\":")
        def compareSearchId = String.format("\"searchId\":\"%s\"", searchId)
        formattedString.contains(compareSearchId)
        def compareIdType = String.format("\"%s\":\"%s\"", idType, idValue)
        formattedString.contains(compareIdType)
        def compareIhrIdentifier = String.format("\"IHR Identifier\":\"%s\"", ihrIdentifier)
        formattedString.contains(compareIhrIdentifier)
        formattedString.contains("\"duration\":")
        def compareStatus1 = String.format("\"status\":\"%s\"", status)
        formattedString.contains(compareStatus1)
        def compareCode1 = String.format("\"code\":\"200\"", code)
        formattedString.contains(compareCode1)
        formattedString.contains("\"name\":\"LogHelperSpec.fetchDataClasses()\"")
        formattedString.contains("\"methods\":")
        //"APPLICATION_NAME": "null","BOOT_STRAP_SERVERS": "null","CLUSTER": "null","DATABASE VERSION": "null","DATA CENTER": "null","ENVIRONMENT": "null","ERROR_QUEUE": "null","GROUP ID": "null","NAMESPACE": "null","TOPIC": "null","VERSION": "null"
    }

    def "Log Success Record with Null Request"() {
        setup:
        def logRecord = new LogRecord()
        logRecord.setActor "actor"
        logRecord.setActorIp "actor ip"
        logRecord.setComponent "component"
        logRecord.setCorrelationId "correlation id"
        logRecord.setDetails "details"
        logRecord.setMethod "method"
        logRecord.setOperation "operation"
        logRecord.setResponseCode "response code"
        logRecord.setResponseStatus "response status"
        logRecord.setSourceId "source id"
        def memberId = new MId()
        String idType = "RALLYID"
        String idValue = "value 1"
        memberId.setIdType idType
        memberId.setIdValue idValue
        def big5 = new Big5()
        memberId.setBig5 big5
        def searchId = "id"
        big5.setDateOfBirth "2010/10/10"
        big5.setFirstName "first"
        big5.setLastName "last"
        big5.setPolicyNumber "policy"
        big5.setSearchId searchId
        String stargateCorrId = "stargate corr id"

        def httpRequest = HttpRequest
                .GET("/")
                .header("Accept", "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8")
                .header("optum-cid-ext", stargateCorrId)

        def code = "200"
        def status = "Success"
        def details = LogHelper.initializeLogger(null, stargateCorrId, null, 1)

        LogHelper.addDetails(details, null, "LogHelperSpec.fetchDataClasses()", code, status)

        when:
        def ihrIdentifier = "fake id"
        def formattedString = LogHelper.logRecord(httpRequest, "LogHelperSpec", details, code, status, ihrIdentifier)

        then:
        formattedString.contains("EVENTTIME=")
        formattedString.contains("|Level=INFO|")
        formattedString.contains("|ACTOR=localhost|")
        formattedString.contains("|CORR_ID=null|")
        formattedString.contains("|EVENT=\"R01:Transaction:Start\"|")
        formattedString.contains("|LOGTYPE=\"RESILIENCY_AUDIT\"|")
        formattedString.contains("|SRC_IP=null|")
        formattedString.contains("|ACTOR_IP=localhost:80|")
        def compareStatus = String.format("|STATUS=%s", status)
        formattedString.contains(compareStatus)
        def compareCode = String.format("|CODE=%s|", code)
        formattedString.contains(compareCode)
        formattedString.contains("|METHOD=GET|")
        formattedString.contains("|OP_ID=")
        formattedString.contains("|COMPONENT=LogHelperSpec|")
        formattedString.contains("|Details=")
    }


    def "Log Success Record For version logging"() {
        setup:
        def logRecord = new LogRecord()
        logRecord.setActor "actor"
        logRecord.setActorIp "actor ip"
        logRecord.setComponent "component"
        logRecord.setCorrelationId "correlation id"
        logRecord.setDetails "details"
        logRecord.setMethod "method"
        logRecord.setOperation "operation"
        logRecord.setResponseCode "response code"
        logRecord.setResponseStatus "response status"
        logRecord.setSourceId "source id"
        def request = new IhrApiRequestOld()
        def memberId = new MId()
        String idType = "RALLYID"
        String idValue = "value 1"
        memberId.setIdType idType
        memberId.setIdValue idValue
        def big5 = new Big5()
        memberId.setBig5 big5
        def searchId = "id"
        big5.setDateOfBirth "2010/10/10"
        big5.setFirstName "first"
        big5.setLastName "last"
        big5.setPolicyNumber "policy"
        big5.setSearchId searchId
        request.setMbrId memberId
        request.setLanguage "EN"
        def dataClasses = new HashSet<RecordType>()
        dataClasses.add RecordType.ACTIVE_ADVERSE_REACTION
        request.setDataClasses dataClasses
        def corrId = "unit test"
        def stargateCorrId = "stargate corr id"
        request.setCorrelationId corrId
        def origin = "my left foot"

        def httpRequest = HttpRequest
                .GET("/")
                .header("Accept", "text/html,application/xhtml+xml,application/xml;q=0.9,*/*;q=0.8")
                .header("optum-cid-ext", stargateCorrId)
                .header("Origin", origin)

        def code = "200"
        def status = "Success"
        def details = LogHelper.initializeLogger(request, stargateCorrId, null, 1)
        def start = Instant.now()
        LogHelper.addDetails(details, start, "LogHelperSpec.fetchDataClasses()", code, status)

        when:
        def ihrIdentifier = "fake id"
        def formattedString = LogHelper.logRecord(httpRequest, "LogHelperSpec", details, code, status, ihrIdentifier)

        then:
        formattedString.contains("\"API_VERSION\":\"2.3.0\"")
        formattedString.contains("\"DATA_VERSION\":\"2.0.0\"")
        formattedString.contains("\"SCHEMA_VERSION\":\"2.3.0\"")
        //EVENTTIME=2019-11-07T10:16:25.291Z|Level=INFO|ACTOR=localhost|CORR_ID=null|EVENT="R01:Transaction:Start"|LOGTYPE="RESILIENCY_AUDIT"|SRC_IP=my left foot|ACTOR_IP=localhost:80|Details={"DATACENTER":null,"ENVIRONMENT":null,"VERSION":null,"CLUSTER":null,"APPLICATION_NAME":null,"X-Consumer-Username":null,"Accept":null,"schema-version":1,"optum-cid-ext":"stargate corr id","rally-corr-id":"unit test","big5":"CF/3aCaF6Kywkl/uS51tJufyPU96pnBEOFssYNsnOAsmicGOX1ALHXWpFmcvgoFTSnmDhATbUSzRFc8BIyv/OSjKRMK3WthSV4mYUa7oDoFtmFyWq/TDSRweTTnWTR7RK+s2hB+kW/nSQFThB3dJiZAucMhdYybxYx0hcwhhHfYvnMJWEigu2HLQQX+m+kPMd1q6iyIegGFlLtG9z62y2+mYG+pecySw7yGIjmFKLXxrbmoeb9O+Rf7wN2dIqj10YQuN0oirz5vxbNdY0apuqx0DpMfjvznzZHlKRlBA3HnvDfKXCTkQBUZO+owtifOMwndeVY0bfI6BucrRzI7urw==","searchId":"id","RALLYID":"value 1","methods":[{"name":"LogHelperSpec.fetchDataClasses()","duration":"1 ms","code":"200","status":"Success"}],"IHR Identifier":"fake id","DATA_VERSION":"2.0.0","API_VERSION":"2.0.0","SCHEMA_VERSION":"2.1.0"}|COMPONENT=LogHelperSpec|OP_ID=/|HOST=10.0.75.1|METHOD=GET|CODE=200|STATUS=Success
    }

    def "logSuccess"() {
        given:
        def reason = "success"
        def method = "II"

        when:
        LogHelper.logStart(defaultRequest, method)
        LogHelper.logSuccess(defaultRequest, method)
        Map<String, Object> map = defaultRequest.getAttribute(LoggingFilter.LOG_MAP, Map.class).orElse(new HashMap())

        then:
        map.get(method + "Status") == reason
    }

    def "log Fail"() {
        given:
        def method = "senzing"
        def reason = "Not able to find id in senzing"

        when:
        LogHelper.logStart(defaultRequest, method)
        LogHelper.logFail(defaultRequest, method, reason)
        Map<String, Object> map = defaultRequest.getAttribute(LoggingFilter.LOG_MAP, Map.class).orElse(new HashMap())

        then:
        map.get(method + "Reason") == reason
    }

    def "setDuration Fail"() {
        given:
        def method = "senzing"

        when:
        LogHelper.setDuration(defaultRequest, method)
        Map<String, Object> map = defaultRequest.getAttribute(LoggingFilter.LOG_MAP, Map.class).orElse(new HashMap())

        then:
        map.containsKey("logError")
    }

    def "setDuration Success"() {
        given:
        def method = "ii"

        when:
        LogHelper.logStart(defaultRequest, method)
        LogHelper.setDuration(defaultRequest, method)
        Map<String, Object> map = defaultRequest.getAttribute(LoggingFilter.LOG_MAP, Map.class).orElse(new HashMap())

        then:
        !map.containsKey(method + "_start")
    }

}
