package com.uhg.ihr.provider.api.validator

import com.uhg.ihr.provider.api.model.IdType
import spock.lang.Specification
import spock.lang.Unroll

class ValidEnumIdTypeNullableValidatorSpec extends Specification {
    @Unroll
    void "it validates IdType #desc"() {
        given:
        def validator = new ValidEnumIdTypeNullableValidator()
        expect:
        expected == validator.isValid(idtype, null)
        where:
        desc       | idtype          || expected
        "null"     | null            || true
        "memberId" | IdType.memberId || true
        "searchId" | IdType.searchId || true
        "EID"      | IdType.EID      || true
        "SSN"      | IdType.SSN      || true
    }
}