package com.uhg.ihr.provider.api.logging

import com.uhg.ihr.provider.api.model.IhrApiRequestOld
import com.uhg.ihr.provider.util.TestData
import io.micronaut.http.HttpRequest
import io.micronaut.http.MutableHttpResponse
import spock.lang.Ignore
import spock.lang.Shared
import spock.lang.Specification

import java.time.Instant

class LoggingFilterSpec extends Specification {

    @Shared
    def loggingFilter = new LoggingFilter(false)

    def httpRequest = HttpRequest.POST("/read", TestData.sampleIhrApiRequest())
            .header("Accept", "application/vnd.uhg.v2+json")
            .header("optum-cid-ext", "Testing")

    @Ignore
    def "initializeLogMap"() {
        setup:
        def res = Mock(MutableHttpResponse)

        when:
        loggingFilter.initializeLogMap(httpRequest)
        LogHelper.addAttribute(httpRequest, "startTime", Instant.now())
        loggingFilter.log(httpRequest, res, null)
        Map<String, Object> map = httpRequest.getAttribute(LoggingFilter.LOG_MAP, Map.class).orElse(new HashMap())

        then:
        map.get("searchId") == "TSrch1234"
    }

    @Ignore("Ignored due to commented out Big5 in LoggingFilter.initializeLogMap()")
    def "logFilter logs an encrypted json request"() {
        when:
        loggingFilter.initializeLogMap(httpRequest)
        Map<String, Object> map = httpRequest.getAttribute(LoggingFilter.LOG_MAP, Map.class).orElse(new HashMap())
        def big5 = map.get("big5")

        // prove the big5 text, when decrypted, can be loaded directly back into a valid request
        def plaintext = LoggingFilter.FACADE.decryptString(big5.toString())
        def newRequest = LoggingFilter.MAPPER.readValue(plaintext, IhrApiRequestOld.class)

        then:
        big5 != plaintext
        newRequest == TestData.sampleIhrApiRequest()
        plaintext.contains(TestData.sampleIhrApiRequest().getMbrId().getBig5().firstName)
        plaintext.contains(TestData.sampleIhrApiRequest().getMbrId().getBig5().dateOfBirth)
    }
}
