package com.uhg.ihr.provider.api.controller

import com.uhg.ihr.provider.api.model.*
import com.uhg.ihr.provider.api.service.backend.SearchAdapterInterface
import com.uhg.ihr.provider.util.HttpTestHelper
import io.micronaut.context.annotation.Primary
import io.micronaut.context.annotation.Property
import io.micronaut.http.HttpRequest
import io.micronaut.http.HttpResponse
import io.micronaut.http.HttpStatus
import io.micronaut.http.client.HttpClient
import io.micronaut.http.client.annotation.Client
import io.micronaut.http.client.exceptions.HttpClientResponseException
import io.micronaut.runtime.server.EmbeddedServer
import io.micronaut.test.annotation.MicronautTest
import io.micronaut.test.annotation.MockBean
import io.reactivex.Maybe
import spock.lang.AutoCleanup
import spock.lang.Shared
import spock.lang.Specification
import spock.lang.Unroll

import javax.inject.Inject

@Property(name = "micronaut.security.stargate.enabled", value = "false")
@MicronautTest
class SearchControllerSpec extends Specification {

    public static final String CORRELATION_ID = "test"
    public static final String BASE_ENDPOINT = "/individual-health-records/v1.0"

    @Inject
    SearchAdapterInterface search

    @Shared
    @AutoCleanup
    @Inject
    EmbeddedServer server

    @Inject
    @Client("/individual-health-records/v1.0")
    HttpClient client

    @MockBean
    @Primary
    SearchAdapterInterface mockSearchAdapter() {
        return Mock(SearchAdapterInterface.class)
    }

    IhrSearchApiRequest buildIhrSearchApiRequest(String first, String last, String dob, FilterPair identifier) {
        IhrSearchApiRequest request = new IhrSearchApiRequest()
        SearchRequestCriteria criteria = new SearchRequestCriteria()
        request.setRequestCriteria(criteria)
        SearcRequestMemberDemographic searchDemo = new SearcRequestMemberDemographic()
        criteria.setMbrDemographics(searchDemo)
        if (first != null || last != null) {
            MemberName name = new MemberName()
            name.setFirst(first)
            name.setLast(last)
            searchDemo.setName(name)
        }
        searchDemo.setDateOfBirth(dob)
        if (identifier != null) {
            searchDemo.setIdentifiers(new HashSet<FilterPair>([identifier]))
        }
        return request
    }

    @Unroll
    def "Valid /search with #desc"() {
        given:
        IhrSearchApiRequest body = buildIhrSearchApiRequest(fn, ln, dob, identifier)
        if (newPatient) {
            SearchRequestModifier mod = new SearchRequestModifier()
            mod.setNewPatient(true)
            body.setModifier(mod)
        }
        HttpTestHelper.configureIhrApiWithActorRequest(body, "999ACT999999999")

        and:
        HttpRequest request = HttpTestHelper.buildHttpPostRequest(BASE_ENDPOINT + "/search", body, CORRELATION_ID, "testToken")

        and:
        search.searchForPatients(body, new ProviderApiHeaders(CORRELATION_ID)) >> Maybe.just(new ArrayList<PatientDemographics>())

        when:
        HttpResponse response = client.toBlocking().exchange(request)

        then:
        response.getStatus() == status

        where:
        desc                            | newPatient | fn    | ln     | dob          | identifier                                             | status
        "new patient sub_id/name/dob"   | true       | "Bob" | "Jule" | "1945-10-10" | new FilterPair("SUBSCRIBER_ID", "123ACTP1234567890")   | HttpStatus.OK
        "new patient glob_id"           | true       | null  | null   | null         | new FilterPair("GLOBAL_ACTOR_ID", "123ACTP1234567890") | HttpStatus.OK
        "new patient glob_id/dob"       | true       | null  | null   | "1945-10-10" | new FilterPair("GLOBAL_ACTOR_ID", "123ACTP1234567890") | HttpStatus.OK
        "new patient glob_id/name"      | true       | "Bob" | "Jule" | null         | new FilterPair("GLOBAL_ACTOR_ID", "123ACTP1234567890") | HttpStatus.OK
        "new patient glob_id/name/dob"  | true       | "Bob" | "Jule" | "1945-10-10" | new FilterPair("GLOBAL_ACTOR_ID", "123ACTP1234567890") | HttpStatus.OK
        "existing patient name only"    | false      | "Bob" | "Jule" | "1945-10-10" | null                                                   | HttpStatus.OK
        "existing patient sub_id only"  | false      | null  | null   | null         | new FilterPair("SUBSCRIBER_ID", "123ACTP1234567890")   | HttpStatus.OK
        "existing patient glob_id only" | false      | null  | null   | null         | new FilterPair("GLOBAL_ACTOR_ID", "123ACTP1234567890") | HttpStatus.OK
    }

    @Unroll
    def "Invalid /search new patient with #desc"() {
        given:
        IhrSearchApiRequest body = buildIhrSearchApiRequest(first, last, dob, identifier)
        SearchRequestModifier mod = new SearchRequestModifier()
        mod.setNewPatient(true)
        body.setModifier(mod)
        HttpTestHelper.configureIhrApiWithActorRequest(body, actorId)

        and:
        HttpRequest request = HttpTestHelper.buildHttpPostRequest(BASE_ENDPOINT + "/search", body, CORRELATION_ID, "testToken")

        when:
        client.toBlocking().exchange(request)

        then:
        HttpClientResponseException e = thrown(HttpClientResponseException.class)
        e.status == HttpStatus.BAD_REQUEST

        where:
        desc              | actorId           | first | last   | dob          | identifier
        "fn/ln/dob"       | "999ACT999999999" | "Bob" | "Jule" | "1992/01/15" | null
        "ln/dob/sub_id"   | "999ACT999999999" | null  | "Jule" | "1992/01/15" | new FilterPair("SUBSCRIBER_ID", "123ACTP1234567890")
        "ln/dob"          | "999ACT999999999" | null  | "Jule" | "1992/01/15" | null
        "fn/dob/sub_id"   | "999ACT999999999" | "Bob" | null   | "1992/01/15" | new FilterPair("SUBSCRIBER_ID", "123ACTP1234567890")
        "fn/dob"          | "999ACT999999999" | "Bob" | null   | "1992/01/15" | null
        "dob/sub_id"      | "999ACT999999999" | null  | null   | "1992/01/15" | new FilterPair("SUBSCRIBER_ID", "123ACTP1234567890")
        "bad_dob/glob_id" | "999ACT999999999" | null  | null   | "1992/01/15" | new FilterPair("GLOBAL_ACTOR_ID", "123ACTP1234567890")
        "dob"             | "999ACT999999999" | null  | null   | "1992/01/15" | null
        "fn"              | "999ACT999999999" | "Bob" | null   | null         | null
        "ln"              | "999ACT999999999" | null  | "Jule" | null         | null
        "some id"         | "999ACT999999999" | null  | null   | null         | new FilterPair("SOME_ID", "123ACTP1234567890")
    }

    @Unroll
    def "Invalid /search exist patient with #desc"() {
        given:
        IhrSearchApiRequest body = buildIhrSearchApiRequest(first, last, dob, identifier)
        HttpTestHelper.configureIhrApiWithActorRequest(body, actorId)

        and:
        HttpRequest request = HttpTestHelper.buildHttpPostRequest(BASE_ENDPOINT + "/search", body, CORRELATION_ID, "testToken")

        when:
        client.toBlocking().exchange(request)

        then:
        HttpClientResponseException e = thrown(HttpClientResponseException.class)
        e.status == HttpStatus.BAD_REQUEST

        where:
        desc              | actorId           | first | last   | dob          | identifier
        "fn/ln/bad_dob"   | "999ACT999999999" | "Bob" | "Jule" | "1992/01/15" | null
        "glob_id/bad_dob" | "999ACT999999999" | null  | null   | "1992/01/15" | new FilterPair("GLOBAL_ACTOR_ID", "123ACTP1234567890")
        "sub_id/bad_dob"  | "999ACT999999999" | null  | null   | "1992/01/15" | new FilterPair("SUBSCRIBER_ID", "123ACTP1234567890")
        "ln/dob"          | "999ACT999999999" | null  | "Jule" | "1945-10-10" | null
        "fn/dob"          | "999ACT999999999" | "Bob" | null   | "1945-10-10" | null
        "dob"             | "999ACT999999999" | null  | null   | "1945-10-10" | null
        "fn"              | "999ACT999999999" | "Bob" | null   | null         | null
        "ln"              | "999ACT999999999" | null  | "Jule" | null         | null
    }

    @Unroll
    def "Invalid /search with #desc"() {
        given:
        IhrSearchApiRequest body = buildIhrSearchApiRequest("Bob", "Jule", "1945-10-10", new FilterPair("SOME_IDENTIFIER", "123ACTP1234567890"))
        HttpTestHelper.configureIhrApiWithActorRequest(body, actorId)

        and:
        HttpRequest request = HttpTestHelper.buildHttpPostRequest(BASE_ENDPOINT + "/search", body, CORRELATION_ID, "testToken")

        and:
        search.searchForPatients(body, new ProviderApiHeaders(CORRELATION_ID)) >> Maybe.empty()

        when:
        client.toBlocking().exchange(request)

        then:
        HttpClientResponseException e = thrown(HttpClientResponseException.class)
        e.status == status

        where:
        desc            | actorId           | language | status
        "no actor"      | null              | "EN"     | HttpStatus.BAD_REQUEST
        "no data found" | "999ACT999999999" | "EN"     | HttpStatus.NOT_FOUND
    }
}
