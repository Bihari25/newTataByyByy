package com.uhg.ihr.provider.data.model

import com.fasterxml.jackson.databind.JsonNode
import spock.lang.Specification
import spock.lang.Unroll

class PayloadSpec extends Specification {

    def static TEST = '{"ihrterm":"Spinal Needle (Reusable) Miscellaneous 18g x 3-1/2\\"","sourceVocabulary":"CPT4/HCPCS/CDT Vocabulary","sourceVocabularyCode":"A4215"}'

    void "it doesnt build payloadJson twice"() {
        given:
        def payload = Payload.builder().payload('{"hello":"world"}').build()

        when:
        JsonNode node = payload.getPayloadJson()

        then:
        'world' == node.get('hello').asText()

        when:
        payload.setPayload('{"hello":"there"}')

        then:
        'world' == node.get('hello').asText()
    }

    void "it handles null gracefully"() {
        given:
        def payload = Payload.builder().build()

        when:
        JsonNode node = payload.getPayloadJson()

        then:
        node == null
    }

    @Unroll
    def "it gets payloadJson: #desc"() {
        given:
        def payload = Payload.builder().ihrIdentifier("ACT1").payload(input).build()

        when:
        def result
        def exception = false

        try {
            result = payload.getPayloadJson().get("ihrterm").asText()
        }
        catch (Exception e) {
            result = e.getMessage()
            exception = true
        }

        then:
        exception == expectException
        result.contains(resultString)

        where:
        desc                   | input                            || expectException | resultString
        "Parses cleanly"       | TEST                             || false           | "Spinal Needle (Reusable) Miscellaneous 18g x 3-1/2\""
        "Parses with sanitize" | '{\\\"ihrterm\\":\\\"world\\\"}' || false           | "world"
        "Doesn't Parse"        | Payload.sanitize(TEST)           || true            | "ACT1"
    }

}
