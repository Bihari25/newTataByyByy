package com.uhg.ihr.provider.api.filter

import com.fasterxml.jackson.databind.JsonNode
import com.uhg.ihr.provider.api.model.FilterPair
import com.uhg.ihr.provider.api.util.AppUtils
import com.uhg.ihr.provider.data.model.Payload
import com.uhg.ihr.provider.util.TestData
import spock.lang.Specification
import spock.lang.Unroll

@Unroll
class DataClassesFilterSpec extends Specification {

    TestData testData = new TestData()
    DataClassesFilter dataClassesFilter = new DataClassesFilter()


    def "filterDataClassesContent happy path : #scenario"() {
        given:
        Payload samplePayload = testData.buildSamplePayload("datafilter-payload.json")
        def dataClassesPayload = samplePayload.payloadJson['dataClasses']['_children'] as LinkedHashMap<String, JsonNode>
        def dataFilters = buildDataFilters(dataContentFilters)

        when:
        def result = dataClassesFilter.filterDataClassesContent(dataClassesPayload, dataFilters)

        then:
        result['medications'].size() == medicationSize
        result['procedureHistory'].size() == phSize
        result['visitHistory'].size() == vhSize

        where:
        scenario                                       | dataContentFilters                                                                                     || medicationSize || phSize || vhSize
        "Empty or no filters"                          | [] as Set<FilterPair>                                                                                  || 3              || 2      || 2
        "Null filters"                                 | null                                                                                                   || 3              || 2      || 2
        "Filter for start date"                        | [new FilterPair(key: AppUtils.CLINICALLY_RELEVANT_START_DATE, value: '2018-12-25')] as Set<FilterPair> || 2              || 1      || 1
        "Filter for present state"                     | [new FilterPair(key: AppUtils.PRESENCE_STATE, value: "Present")] as Set<FilterPair>                    || 2              || 1      || 1
        "Filter for past occurrence"                   | [new FilterPair(key: AppUtils.PRESENCE_STATE, value: "Past Occurrence")] as Set<FilterPair>            || 1              || 1      || 1
        "Filter for present and past occurrence"       | [new FilterPair(key: AppUtils.PRESENCE_STATE, value: "Present, Past Occurrence")] as Set<FilterPair>   || 3              || 2      || 2
        "Filter for start and end date"                | [new FilterPair(key: AppUtils.CLINICALLY_RELEVANT_START_DATE, value: '2018-12-25'),
                                                          new FilterPair(key: AppUtils.CLINICALLY_RELEVANT_END_DATE, value: '2019-12-25')] as Set<FilterPair>   || 2              || 1      || 1
        "Filter for start and present"                 | [new FilterPair(key: AppUtils.CLINICALLY_RELEVANT_START_DATE, value: '2018-12-25'),
                                                          new FilterPair(key: AppUtils.PRESENCE_STATE, value: "Present")] as Set<FilterPair>                    || 2              || 1      || 1
        "Filter for invalid start and past occurrence" | [new FilterPair(key: AppUtils.CLINICALLY_RELEVANT_START_DATE, value: '2018-12-25'),
                                                          new FilterPair(key: AppUtils.PRESENCE_STATE, value: "Past Occurrence")] as Set<FilterPair>            || 0              || 0      || 0
        "Filter for valid start and past occurrence"   | [new FilterPair(key: AppUtils.CLINICALLY_RELEVANT_START_DATE, value: '2018-01-25'),
                                                          new FilterPair(key: AppUtils.PRESENCE_STATE, value: "Past Occurrence")] as Set<FilterPair>            || 1              || 0      || 1
        "Filter for start/end date and presence state" | [new FilterPair(key: AppUtils.CLINICALLY_RELEVANT_START_DATE, value: '2018-12-25'),
                                                          new FilterPair(key: AppUtils.CLINICALLY_RELEVANT_END_DATE, value: '2019-12-25'),
                                                          new FilterPair(key: AppUtils.PRESENCE_STATE, value: "Present")] as Set<FilterPair>                    || 2              || 1      || 1
    }


    def "dataClassesFilteringByCriteria : #scenario"() {
        given:
        Payload samplePayload = testData.buildSamplePayload("datafilter-payload.json")
        def dataClassesPayload = samplePayload.payloadJson['dataClasses']['_children'] as LinkedHashMap<String, JsonNode>
        def dataFilters = buildDataFilters(dataContentFilters)


        when:
        def result = dataClassesFilter.dataClassesFilteringByCriteria(dataClassesPayload, dataFilters)

        then:
        result['medications'].size() == medicationSize
        result['procedureHistory'].size() == phSize
        result['visitHistory'].size() == vhSize

        where:
        scenario                                       | dataContentFilters                                                                                     || medicationSize || phSize || vhSize
        "Filter for start date"                        | [new FilterPair(key: AppUtils.CLINICALLY_RELEVANT_START_DATE, value: '2018-12-25')] as Set<FilterPair> || 2              || 1      || 1
        "Filter for present state"                     | [new FilterPair(key: AppUtils.PRESENCE_STATE, value: "Present")] as Set<FilterPair>                    || 2              || 1      || 1
        "Filter for past occurrence"                   | [new FilterPair(key: AppUtils.PRESENCE_STATE, value: "Past Occurrence")] as Set<FilterPair>            || 1              || 1      || 1
        "Filter for present and past occurrence"       | [new FilterPair(key: AppUtils.PRESENCE_STATE, value: "Present, Past Occurrence")] as Set<FilterPair>   || 3              || 2      || 2
        "Filter for start and end date"                | [new FilterPair(key: AppUtils.CLINICALLY_RELEVANT_START_DATE, value: '2018-12-25'),
                                                          new FilterPair(key: AppUtils.CLINICALLY_RELEVANT_END_DATE, value: '2019-12-25')] as Set<FilterPair>   || 2              || 1      || 1
        "Filter for start and present"                 | [new FilterPair(key: AppUtils.CLINICALLY_RELEVANT_START_DATE, value: '2018-12-25'),
                                                          new FilterPair(key: AppUtils.PRESENCE_STATE, value: "Present")] as Set<FilterPair>                    || 2              || 1      || 1
        "Filter for invalid start and past occurrence" | [new FilterPair(key: AppUtils.CLINICALLY_RELEVANT_START_DATE, value: '2018-12-25'),
                                                          new FilterPair(key: AppUtils.PRESENCE_STATE, value: "Past Occurrence")] as Set<FilterPair>            || 0              || 0      || 0
        "Filter for valid start and past occurrence"   | [new FilterPair(key: AppUtils.CLINICALLY_RELEVANT_START_DATE, value: '2018-01-25'),
                                                          new FilterPair(key: AppUtils.PRESENCE_STATE, value: "Past Occurrence")] as Set<FilterPair>            || 1              || 0      || 1
        "Filter for start/end date and presence state" | [new FilterPair(key: AppUtils.CLINICALLY_RELEVANT_START_DATE, value: '2018-12-25'),
                                                          new FilterPair(key: AppUtils.CLINICALLY_RELEVANT_END_DATE, value: '2019-12-25'),
                                                          new FilterPair(key: AppUtils.PRESENCE_STATE, value: "Present")] as Set<FilterPair>                    || 2              || 1      || 1

    }


    def "filteredDataByCriteria : #scenario"() {
        given:
        Payload samplePayload = testData.buildSamplePayload("datafilter-payload.json")
        JsonNode dataNode = samplePayload.payloadJson['dataClasses']['medications']
        def dataFilters = buildDataFilters(dataContentFilters)


        when:
        def result = dataClassesFilter.filterDataByCriteria(dataNode, dataFilters)

        then:
        result.size() == expectedSize

        where:
        scenario                                       | dataContentFilters                                                                                     || expectedSize
        "Filter for start date"                        | [new FilterPair(key: AppUtils.CLINICALLY_RELEVANT_START_DATE, value: '2018-12-25')] as Set<FilterPair> || 2
        "Filter for present state"                     | [new FilterPair(key: AppUtils.PRESENCE_STATE, value: "Present")] as Set<FilterPair>                    || 2
        "Filter for past occurrence"                   | [new FilterPair(key: AppUtils.PRESENCE_STATE, value: "Past Occurrence")] as Set<FilterPair>            || 1
        "Filter for present and past occurrence"       | [new FilterPair(key: AppUtils.PRESENCE_STATE, value: "Present, Past Occurrence")] as Set<FilterPair>   || 3
        "Filter for start and end date"                | [new FilterPair(key: AppUtils.CLINICALLY_RELEVANT_START_DATE, value: '2018-12-25'),
                                                          new FilterPair(key: AppUtils.CLINICALLY_RELEVANT_END_DATE, value: '2019-12-25')] as Set<FilterPair>   || 2
        "Filter for start and present"                 | [new FilterPair(key: AppUtils.CLINICALLY_RELEVANT_START_DATE, value: '2018-12-25'),
                                                          new FilterPair(key: AppUtils.PRESENCE_STATE, value: "Present")] as Set<FilterPair>                    || 2
        "Filter for invalid start and past occurrence" | [new FilterPair(key: AppUtils.CLINICALLY_RELEVANT_START_DATE, value: '2018-12-25'),
                                                          new FilterPair(key: AppUtils.PRESENCE_STATE, value: "Past Occurrence")] as Set<FilterPair>            || 0
        "Filter for valid start and past occurrence"   | [new FilterPair(key: AppUtils.CLINICALLY_RELEVANT_START_DATE, value: '2018-01-25'),
                                                          new FilterPair(key: AppUtils.PRESENCE_STATE, value: "Past Occurrence")] as Set<FilterPair>            || 1
        "Filter for start/end date and presence state" | [new FilterPair(key: AppUtils.CLINICALLY_RELEVANT_START_DATE, value: '2018-12-25'),
                                                          new FilterPair(key: AppUtils.CLINICALLY_RELEVANT_END_DATE, value: '2019-12-25'),
                                                          new FilterPair(key: AppUtils.PRESENCE_STATE, value: "Present")] as Set<FilterPair>                    || 2
    }

    def "filteredDataByCriteria crDate, pStateTerm empty/null edge cases : #scenario"() {
        given:
        Payload samplePayload = testData.buildSamplePayload("datafilter-payload-empty-crd-pstate.json")
        JsonNode dataNode = samplePayload.payloadJson['dataClasses']['medications']
        def dataFilters = buildDataFilters(dataContentFilters)


        when:
        def result = dataClassesFilter.filterDataByCriteria(dataNode, dataFilters)

        then:
        result.size() == expectedSize

        where:
        scenario                                       | dataContentFilters                                                                                     || expectedSize
        "Filter for start date"                        | [new FilterPair(key: AppUtils.CLINICALLY_RELEVANT_START_DATE, value: '2018-12-25')] as Set<FilterPair> || 3
        "Filter for present state"                     | [new FilterPair(key: AppUtils.PRESENCE_STATE, value: "Present")] as Set<FilterPair>                    || 3
        "Filter for past occurrence"                   | [new FilterPair(key: AppUtils.PRESENCE_STATE, value: "Past Occurrence")] as Set<FilterPair>            || 2
        "Filter for present and past occurrence"       | [new FilterPair(key: AppUtils.PRESENCE_STATE, value: "Present, Past Occurrence")] as Set<FilterPair>   || 3
        "Filter for start and end date"                | [new FilterPair(key: AppUtils.CLINICALLY_RELEVANT_START_DATE, value: '2018-12-25'),
                                                          new FilterPair(key: AppUtils.CLINICALLY_RELEVANT_END_DATE, value: '2019-12-25')] as Set<FilterPair>   || 3
        "Filter for start and present"                 | [new FilterPair(key: AppUtils.CLINICALLY_RELEVANT_START_DATE, value: '2018-12-25'),
                                                          new FilterPair(key: AppUtils.PRESENCE_STATE, value: "Present")] as Set<FilterPair>                    || 3
        "Filter for invalid start and past occurrence" | [new FilterPair(key: AppUtils.CLINICALLY_RELEVANT_START_DATE, value: '2018-12-25'),
                                                          new FilterPair(key: AppUtils.PRESENCE_STATE, value: "Past Occurrence")] as Set<FilterPair>            || 2
        "Filter for valid start and past occurrence"   | [new FilterPair(key: AppUtils.CLINICALLY_RELEVANT_START_DATE, value: '2018-01-25'),
                                                          new FilterPair(key: AppUtils.PRESENCE_STATE, value: "Past Occurrence")] as Set<FilterPair>            || 2
        "Filter for start/end date and presence state" | [new FilterPair(key: AppUtils.CLINICALLY_RELEVANT_START_DATE, value: '2018-12-25'),
                                                          new FilterPair(key: AppUtils.CLINICALLY_RELEVANT_END_DATE, value: '2019-12-25'),
                                                          new FilterPair(key: AppUtils.PRESENCE_STATE, value: "Present")] as Set<FilterPair>                    || 3
    }

    private List<DataFilter> buildDataFilters(Set<FilterPair> dataContentFilters) {
        /* Build data content filters. */
        DataContentFilterBuilder dataContentFilterBuilder = new DataContentFilterBuilder(dataContentFilters)
        List<DataFilter> dataFilters = dataContentFilterBuilder.getDataFilters()
        dataFilters
    }
}
