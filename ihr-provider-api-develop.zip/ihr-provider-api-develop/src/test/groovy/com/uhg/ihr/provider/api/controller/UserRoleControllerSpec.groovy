package com.uhg.ihr.provider.api.controller

import com.fasterxml.jackson.databind.ObjectMapper
import com.fasterxml.jackson.databind.node.ArrayNode
import com.fasterxml.jackson.databind.node.ObjectNode
import com.uhg.ihr.provider.api.model.profile.ExternalSecurityAccess
import com.uhg.ihr.provider.api.model.profile.FilterClass
import com.uhg.ihr.provider.api.model.profile.RoleLookup
import com.uhg.ihr.provider.api.model.profile.UserPermission
import com.uhg.ihr.provider.api.model.profile.UserProfileConstant
import com.uhg.ihr.provider.api.model.profile.UserProfileConstant.SECURED_CONTEXT
import com.uhg.ihr.provider.api.service.security.SecurityApi
import com.uhg.ihr.provider.api.service.security.model.RoleChangeRequest
import com.uhg.ihr.provider.api.service.security.model.SecurityObjectsMongo
import com.uhg.ihr.provider.util.HttpTestHelper
import io.micronaut.context.annotation.Primary
import io.micronaut.context.annotation.Property
import io.micronaut.http.HttpRequest
import io.micronaut.http.HttpResponse
import io.micronaut.http.HttpStatus
import io.micronaut.http.client.HttpClient
import io.micronaut.http.client.annotation.Client
import io.micronaut.http.client.exceptions.HttpClientResponseException
import io.micronaut.runtime.server.EmbeddedServer
import io.micronaut.test.annotation.MicronautTest
import io.micronaut.test.annotation.MockBean
import io.reactivex.Maybe
import spock.lang.AutoCleanup
import spock.lang.Shared
import spock.lang.Specification
import spock.lang.Unroll

import javax.inject.Inject

@Property(name = "micronaut.security.stargate.enabled", value = "false")
@MicronautTest
class UserRoleControllerSpec extends Specification {
    ObjectMapper mapper = new ObjectMapper()

    public static final String BASE_ENDPOINT = "/security/v1.0"
    @Inject
    SecurityApi securityApi

    @Shared
    @AutoCleanup
    @Inject
    EmbeddedServer server

    @Inject
    @Client("/")
    HttpClient client

    @MockBean
    @Primary
    SecurityApi mockUserRoleService() {
        return Mock(SecurityApi.class)
    }

    HttpRequest buildValidRoleLookup(String endpoint, String correlationId, SECURED_CONTEXT securedContext,
                                     Set<UserProfileConstant.ROLE_CONTEXT> externalFilterContext, Set<String> roles,
                                     Set<UserProfileConstant.ROLE_CONTEXT> lookupFilterContext) {
        ExternalSecurityAccess securityAccess = new ExternalSecurityAccess()
                .toBuilder()
                .securedContext(securedContext)
                .roles(roles)
                .build()
        RoleLookup request = new RoleLookup()
                .toBuilder()
                .externalSecurity(securityAccess)
                .filterContext(lookupFilterContext)
                .build()
        return HttpTestHelper.buildHttpPostRequest(BASE_ENDPOINT + endpoint, request, correlationId, "testToken")
    }

    @Unroll
    def "valid /lookupRoles"() {
        given:
        HttpRequest request = buildValidRoleLookup(
                "/lookupRoles", "test",
                SECURED_CONTEXT.ESSO, Set.of(UserProfileConstant.ROLE_CONTEXT.PORTAL), Set.of("PROVIDER"),
                Set.of(UserProfileConstant.ROLE_CONTEXT.PORTAL)
        )

        and:
        securityApi.lookupRoles(request.getBody().get()) >> returns

        when:
        HttpResponse response = client.toBlocking().exchange(request)

        then:
        response.getStatus() == HttpStatus.OK

        where:
        desc                   | returns
        "permissions"          | Maybe.just(List.of(new UserPermission()))
        "no permissions found" | Maybe.just(new ArrayList<UserPermission>())
    }

    HttpRequest buildInvalidRoleLookup(String endpoint, String correlationId, String securedContext,
                                       String externalFilterContext, String role, String lookupFilterContext) {
        ObjectNode requestNode = mapper.createObjectNode()
        //Build filterContext in RoleLookup object
        if (lookupFilterContext != null) {
            ArrayNode filterContextNode = mapper.createArrayNode()
            requestNode.set("filterContext", filterContextNode)
            filterContextNode.add(lookupFilterContext)
        }
        //Build externalSecurity in RoleLookup object
        ObjectNode externalSecurityNode = mapper.createObjectNode()
        requestNode.set("externalSecurity", externalSecurityNode)
        //Set securedContext in ExternalSecurityAccess object
        if (securedContext != null) {
            externalSecurityNode.put("securedContext", securedContext)
        }
        //Build filterContext in ExternalSecurityAccess object
        if (externalFilterContext != null) {
            ArrayNode externalFilterContextNode = mapper.createArrayNode()
            externalSecurityNode.set("filterContext", externalFilterContextNode)
            externalFilterContextNode.add(externalFilterContext)
        }
        //Build roles in ExternalSecurityAccess object
        if (role != null) {
            ArrayNode rolesNode = mapper.createArrayNode()
            externalSecurityNode.set("roles", rolesNode)
            rolesNode.add(role)
        }

        return HttpTestHelper.buildHttpPostRequest(BASE_ENDPOINT + endpoint, requestNode, correlationId, "testToken")
    }

    @Unroll
    /**
     * Request validation testing for RoleLookup class
     */
    def "invalid /lookupRoles with #desc in RoleLookup"() {
        given:
        HttpRequest request = buildInvalidRoleLookup(
                "/lookupRoles", "test", securedContext, "PORTAL", role, "PORTAL"
        )

        when:
        client.toBlocking().exchange(request)

        then:
        HttpClientResponseException e = thrown(HttpClientResponseException.class)
        e.status == HttpStatus.BAD_REQUEST

        where:
        desc                 | securedContext                  | role
        "no securedContext"  | null                            | "PROVIDER"
        "bad securedContext" | "BAD_CONTEXT"                   | "PROVIDER"
        "no role"            | SECURED_CONTEXT.ESSO.toString() | null
    }

    HttpRequest buildCreateRoleRequest(Map<String, Map<UserProfileConstant.ROLE_CONTEXT, SecurityObjectsMongo>> mapping,
                                       SECURED_CONTEXT securedContext) {
        RoleChangeRequest request = RoleChangeRequest
                .builder()
                .securedContext(securedContext)
                .mapping(mapping)
                .build()
        return HttpTestHelper.buildHttpPostRequest(BASE_ENDPOINT + "/roles", request, "test", "test-token")
    }

    //TODO: Finish testing endpoint
//    Map<String, Map<UserProfileConstant.ROLE_CONTEXT, SecurityObjectsMongo>> buildMapping("")
//
//    @Unroll
//    /**
//     * Request validation testing for RoleLookup class
//     */
//    def "valid /roles with #desc"() {
//        given:
//        Map<String, Map<UserProfileConstant.ROLE_CONTEXT, SecurityObjectsMongo>> mapping = new HashMap<>()
//
//
//        when:
//        client.toBlocking().exchange(request)
//
//        then:
//        HttpClientResponseException e = thrown(HttpClientResponseException.class)
//        e.status == HttpStatus.BAD_REQUEST
//
//        where:
//        desc                 | securedContext | portalRoles | portalGroups | ihrRoles | ihrGroups
//        "no securedContext"  | "ESSO"         | ["127"]     | null         | null     | null
//        "bad securedContext" | "ESSO"         | ["127"]     | ["128"]      | null     | null
//    }
}
