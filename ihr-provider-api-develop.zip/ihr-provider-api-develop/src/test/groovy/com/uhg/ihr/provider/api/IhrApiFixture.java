package com.uhg.ihr.provider.api;

import com.uhg.ihr.provider.api.model.Big5;
import com.uhg.ihr.provider.api.model.IhrApiRequestOld;
import com.uhg.ihr.provider.api.model.MId;
import com.uhg.ihr.provider.api.model.RecordType;

import java.util.Set;
import java.util.UUID;
import java.util.stream.Collectors;
import java.util.stream.Stream;

public class IhrApiFixture {

    public static IhrApiRequestOld defaultRequest() {
        return IhrApiRequestOld.builder()
                .language("EN")
                .dataClasses(defaultDataClasses())
                .mbrId(defaultMId())
                .correlationId(UUID.randomUUID().toString())
                .build();
    }

    public static Set<RecordType> defaultDataClasses() {
        return Stream.of(RecordType.HEALTH_OBSERVATIONS, RecordType.PROCEDURE_HISTORY).collect(Collectors.toSet());
    }

    public static MId defaultMId() {
        return MId.builder()
                .big5(defaultBig5())
                .build();
    }

    public static Big5 defaultBig5() {
        return Big5.builder()
                .firstName("Bob")
                .lastName("Dylan")
                .dateOfBirth("1941/05/24")
                .policyNumber("8675309")
                .searchId("UTD1337")
                .build();
    }
}
