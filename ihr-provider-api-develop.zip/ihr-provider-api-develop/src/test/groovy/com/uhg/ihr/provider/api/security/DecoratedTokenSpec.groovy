package com.uhg.ihr.provider.api.security

import spock.lang.Specification

class DecoratedTokenSpec extends Specification {
    def today = new Date()
    DecoratedToken sampleDecoratedToken = new DecoratedToken(sub: "ihr-external-api", iss: "ihr-senzing-api-gateway",
            aud: "secure-app", iat: today, exp: today, roles: ["admin"] as List<String>, token: "test122222")

    def "DecoratedToken: setters/getters"() {
        given:
        DecoratedToken decoratedToken = sampleDecoratedToken
        expect:
        decoratedToken.getSub() == "ihr-external-api"
        decoratedToken.getIss() == "ihr-senzing-api-gateway"
        decoratedToken.getAud() == "secure-app"
        decoratedToken.getIat() == today
        decoratedToken.getExp() == today
        decoratedToken.getRoles().size() == 1
        decoratedToken.getToken() == "test122222"
    }
}