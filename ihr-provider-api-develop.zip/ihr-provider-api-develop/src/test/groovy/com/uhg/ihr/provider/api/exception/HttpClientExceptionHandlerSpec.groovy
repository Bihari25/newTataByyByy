package com.uhg.ihr.provider.api.exception

import io.micronaut.http.HttpRequest
import io.micronaut.http.client.exceptions.HttpClientException
import spock.lang.Ignore
import spock.lang.Specification

class HttpClientExceptionHandlerSpec extends Specification {

    HttpRequest mockHttpRequest = Mock(HttpRequest)
    HttpClientException mockHttpClientException = new HttpClientException("Test Handler Exception")
    HttpClientExceptionHandler httpClientExceptionHandler = new HttpClientExceptionHandler()

    @Ignore //TODO We need to implement integration test; Unit test not works because micronaut netty server.
    def "HttpClientExceptionHandler:handle"() {
        given:
        mockHttpRequest.getUri() >> new URI("http://localhost:8080")

        when:
        def result = httpClientExceptionHandler.handle(mockHttpRequest, mockHttpClientException)

        then:
        result
    }

}