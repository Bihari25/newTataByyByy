package com.uhg.ihr.provider.api.security

import com.uhg.ihr.provider.api.logging.LogHelper
import com.uhg.ihr.provider.api.model.IhrApiRequestOld
import com.uhg.ihr.provider.util.TestData
import spock.lang.Specification
import spock.lang.Unroll

class EncryptDecryptSpec extends Specification {

    @Unroll
    def "log encrypts and decrypts"() {
        setup:
        IhrApiRequestOld req = TestData.sampleIhrApiRequest()
        def encrypted = LogHelper.FACADE.encryptString(req.toString())

        when:
        def decrypted = LogHelper.FACADE.decryptString(encrypted)

        then:
        req.toString().equals(decrypted.toString())
        decrypted.contains("TFName")
        decrypted.contains("TLName")
        decrypted.contains("2001/01/01")
        decrypted.contains("TPLCY12345")
        decrypted.contains("TSrch1234")
    }

}
