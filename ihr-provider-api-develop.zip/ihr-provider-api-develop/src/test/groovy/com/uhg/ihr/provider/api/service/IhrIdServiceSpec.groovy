package com.uhg.ihr.provider.api.service


import spock.lang.Specification

class IhrIdServiceSpec extends Specification {

}
