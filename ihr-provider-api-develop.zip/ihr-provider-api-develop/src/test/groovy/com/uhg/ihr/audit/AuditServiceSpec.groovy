package com.uhg.ihr.audit

import com.uhg.ihr.audit.consumer.AuditWriterListener
import com.uhg.ihr.audit.service.AuditService
import io.micronaut.test.annotation.MicronautTest
import io.reactivex.Flowable
import spock.lang.Shared
import spock.lang.Specification

import javax.inject.Inject

@MicronautTest(environments = "kafka")
class AuditServiceSpec extends Specification {

    @Inject
    @Shared
    private AuditService auditService

    @Inject
    @Shared
    private AuditWriterListener auditListener

//    def "CreateAudit"() {
//        given:
//        Map<String,String> auditDetails = new HashMap<>()
//        auditDetails.put("client", "test")
//        auditDetails.put("ip", "999.999.0.0")
//        auditDetails.put("source", "portal")
//
//        when:
//        auditService.createAudit(auditDetails)
//
//        then:
//        (auditListener.receive(Flowable.just(new Audit(null, null, auditDetails)))).blockingFirst().getCommon().get("client") == "test"
//    }
}
