package com.uhg.ihr.provider.api.service

import io.micronaut.test.annotation.MicronautTest
import spock.lang.Specification

@MicronautTest
class SecurityApiSpec extends Specification {
//TODO: Complete SecurityApiSpec unit testing
}
