package com.uhg.ihr.provider.api.validator

import spock.lang.Specification
import spock.lang.Unroll

import javax.validation.ConstraintValidatorContext

@Unroll
class ValidFilterValueValidatorSpec extends Specification {

    ValidFilterValueValidator validFilterValueValidator = new ValidFilterValueValidator()
    ConstraintValidatorContext mockConstraintValidatorContext = Mock(ConstraintValidatorContext)

    def "ValidFilterValueValidator:: isValid : #scenario"() {
        when:
        def result = validFilterValueValidator.isValid(inputValue, mockConstraintValidatorContext)

        then:
        result == expectedResult

        where:
        scenario                                 | inputValue            || expectedResult
        "Empty value"                            | ""                    || false
        "Null value"                             | null                  || false
        "Valid date value"                       | "2019-12-25"          || true
        "Valid iso date value"                   | "2019-12-25 10:21:23" || true
        "Valid text value"                       | "test value"          || true
        "Invalid date without days"              | "2018-12"             || false
        "Invalid date without month"             | "2018--12"            || false
        "Invalid iso date value only hours"      | "2019-12-25 12"       || false
        "Invalid iso date value without minutes" | "2019-12-25 12::12"   || false
        "Invalid iso date value without seconds" | "2019-12-25 12:25"    || false
        "Invalid date value separator /"         | "2019/12/25"          || false
        "Invalid date value separator -/"        | "2019-12/25"          || false
    }


    def "ValidFilterValueValidator:: validateFilterValue : #scenario"() {
        when:
        def result = validFilterValueValidator.validateFilterValue(inputValue)

        then:
        result == expectedResult

        where:
        scenario                                 | inputValue            || expectedResult
        "Valid date value"                       | "2019-12-25"          || true
        "Valid iso date value"                   | "2019-12-25 10:21:23" || true
        "Valid text value"                       | "test value"          || true
        "Invalid date without days"              | "2018-12"             || false
        "Invalid date without month"             | "2018--12"             | false
        "Invalid iso date value only hours"      | "2019-12-25 12"       || false
        "Invalid iso date value without minutes" | "2019-12-25 12::12"   || false
        "Invalid iso date value without seconds" | "2019-12-25 12:25"    || false
        "Invalid date value separator /"         | "2019/12/25"          || false
        "Invalid date value separator -/"        | "2019-12/25"          || false
    }
}
