package com.uhg.ihr.provider.api.model

import spock.lang.Specification
import spock.lang.Unroll

import javax.validation.ConstraintViolation
import javax.validation.Validation
import javax.validation.Validator
import javax.validation.ValidatorFactory

class MemberNameSpec extends Specification {
    @Unroll
    void "Check Good Member Name Data"() {
        setup:
        def mbrName = new MemberName()
        mbrName.setFirst first
        mbrName.setLast last


        when:
        ValidatorFactory factory = Validation.buildDefaultValidatorFactory()
        Validator validator = factory.getValidator()
        Set<ConstraintViolation<MemberName>> violations = validator.validate(mbrName)

        then:
        if(violations.size()==0) {
            mbrName.getFirst() == first
            mbrName.getLast() == last
        } else {
            violations.size()==expected
            def message = violations.first()
            def returned = message.message
            returned == expected
        }

        where:
        first   | last      | middle | size  | expected
        "chinh" | "vu"      | ""     |0     | "Good"
        "hanh"  | "tran"    | ""     |0     | "Good"
        "han"   | "vutran"  | ""     |0     |   "Good"
        "tam"   | "vutran"  | ""     |0     | "Good"
        "chinh" | null      | ""     |1     |  "last name is null"
   }

    def "Test All Args Constructor"() {
        setup:
        String first = "chinh"
        String last = "vu"

        when:
        def mbrName = new MemberName(first,"", last)

        then:
        mbrName.first == first
        mbrName.last == last

    }

    def "Test Builder"() {
        setup:
        String first = "chinh"
        String last = "vu"
        when:
        def mbrName = MemberName.builder().first(first).last(last)

        then:
        mbrName.first == first
        mbrName.last == last
    }
}
