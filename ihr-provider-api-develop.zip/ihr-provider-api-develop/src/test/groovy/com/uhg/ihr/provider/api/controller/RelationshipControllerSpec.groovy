package com.uhg.ihr.provider.api.controller

import com.uhg.ihr.provider.api.model.ProviderApiHeaders
import com.uhg.ihr.provider.api.service.RelationshipInterface
import com.uhg.ihr.provider.api.service.relationship.model.RelationshipRequest
import com.uhg.ihr.provider.api.service.relationship.model.RelationshipResponse
import com.uhg.ihr.provider.api.service.relationship.model.RelationshipRole
import com.uhg.ihr.provider.util.HttpTestHelper
import io.micronaut.context.annotation.Primary
import io.micronaut.context.annotation.Property
import io.micronaut.http.HttpRequest
import io.micronaut.http.HttpResponse
import io.micronaut.http.HttpStatus
import io.micronaut.http.client.HttpClient
import io.micronaut.http.client.annotation.Client
import io.micronaut.http.client.exceptions.HttpClientResponseException
import io.micronaut.runtime.server.EmbeddedServer
import io.micronaut.test.annotation.MicronautTest
import io.micronaut.test.annotation.MockBean
import io.reactivex.Maybe
import spock.lang.AutoCleanup
import spock.lang.Shared
import spock.lang.Specification
import spock.lang.Unroll

import javax.inject.Inject
import java.text.SimpleDateFormat
import java.util.concurrent.TimeUnit

import static com.uhg.ihr.provider.util.HttpTestHelper.buildHttpPostRequest

@Property(name = "micronaut.security.stargate.enabled", value = "false")
@MicronautTest
class RelationshipControllerSpec extends Specification {

    public static final String CORRELATION_ID = "test"
    public static final TEST_DATE_FORMATTER = new SimpleDateFormat("yyyy-MM-dd")
    public static final String BASE_ENDPOINT = "/individual-health-records/v1.0"
    public static final String PROVIDER = "123ACTP99999999"
    public static final String PATIENT = "111ACTI1234567890"

    @Inject
    RelationshipInterface relationshipService

    @Shared
    @AutoCleanup
    @Inject
    EmbeddedServer server

    @Inject
    @Client("/")
    HttpClient client

    @MockBean
    @Primary
    RelationshipInterface mockProfileService() {
        return Mock(RelationshipInterface.class)
    }

    static RelationshipRequest buildRelationshipRequest(int effectiveDate, int endDate, RelationshipRole relationship, String providerId) {
        RelationshipRequest request = RelationshipRequest.builder()
                .effectiveDate(dateCreator(effectiveDate))
                .terminationDate(dateCreator(endDate))
                .providerRole(relationship)
                .build()
        HttpTestHelper.configureIhrApiWithActorRequest(request, providerId)
        return request
    }

    static String dateCreator(int dayOffset) {
        return dayOffset == 0 ? null : TEST_DATE_FORMATTER.format(new Date(System.currentTimeMillis() + TimeUnit.DAYS.toMillis(dayOffset)))
    }

    @Unroll
    def "valid /{patientId}/relationship with #desc"() {
        given:
        RelationshipRequest body = buildRelationshipRequest(effectiveDate, endDate, RelationshipRole.REFERRING_PROVIDER, PROVIDER)
        HttpRequest request = buildHttpPostRequest(BASE_ENDPOINT + "/" + PATIENT + "/relationship", body, CORRELATION_ID, "test-token")

        and:
        relationshipService.manageRelationship(body, PATIENT, new ProviderApiHeaders(CORRELATION_ID)) >> Maybe.just(RelationshipResponse.builder().patientActorId(PATIENT).build())

        when:
        HttpResponse response = client.toBlocking().exchange(request)

        then:
        response.status() == HttpStatus.OK

        where:
        desc                                 | effectiveDate | endDate
        "no dates provided"                  | 0             | 0
        "future dates"                       | 5             | 7
        "past effectiveDate, future endDate" | -1            | 2
        "past dates"                         | -5            | -3
        "no effectiveDate, future endDate"   | 0             | 7
        "no effectiveDate, past endDate"     | 0             | -1
        "no endDate, future effectiveDate"   | 3             | 0
        "no endDate, past effectiveDate"     | -1            | 0
    }

    def "valid /{patientId}/relationship with no patient"() {
        given:
        RelationshipRequest body = buildRelationshipRequest(1, 3, RelationshipRole.REFERRING_PROVIDER, PROVIDER)
        HttpRequest request = buildHttpPostRequest(BASE_ENDPOINT + "/" + PATIENT + "/relationship", body, CORRELATION_ID, "test-token")

        and:
        relationshipService.manageRelationship(body, PATIENT, new ProviderApiHeaders(CORRELATION_ID)) >> Maybe.empty()

        when:
        client.toBlocking().exchange(request)

        then:
        HttpClientResponseException e = thrown(HttpClientResponseException.class)
        e.status == HttpStatus.NOT_FOUND
    }

    @Unroll
    def "invalid /{patientId}/relationship with #desc"() {
        given:
        RelationshipRequest body = buildRelationshipRequest(effectiveDate, endDate, relationship, provider)
        HttpRequest request = buildHttpPostRequest(BASE_ENDPOINT + "/" + PATIENT + "/relationship", body, "test", "test-token")

        when:
        client.toBlocking().exchange(request)

        then:
        HttpClientResponseException e = thrown(HttpClientResponseException.class)
        e.status == HttpStatus.BAD_REQUEST

        where:
        desc                                       | effectiveDate | endDate | relationship                        | provider
        "wrong future dates"                       | 3             | 1       | RelationshipRole.REFERRING_PROVIDER | PROVIDER
        "wrong past dates"                         | -1            | -3      | RelationshipRole.REFERRING_PROVIDER | PROVIDER
        "wrong future effectiveDate, past endDate" | 1             | -2      | RelationshipRole.REFERRING_PROVIDER | PROVIDER
        "no relationship role"                     | 1             | 3       | null                                | PROVIDER
        "no provider"                              | 1             | 3       | RelationshipRole.REFERRING_PROVIDER | null
    }

    @Unroll
    def "valid /{patientId}/update with #desc"() {
        given:
        RelationshipRequest body = buildRelationshipRequest(effectiveDate, endDate, RelationshipRole.REFERRING_PROVIDER, PROVIDER)
        HttpRequest request = buildHttpPostRequest(BASE_ENDPOINT + "/" + PATIENT + "/update", body, CORRELATION_ID, "test-token")

        and:
        relationshipService.manageRelationship(body, PATIENT, new ProviderApiHeaders(CORRELATION_ID)) >> Maybe.just(RelationshipResponse.builder().patientActorId(PATIENT).build())

        when:
        HttpResponse response = client.toBlocking().exchange(request)

        then:
        response.status() == HttpStatus.OK

        where:
        desc                                 | effectiveDate | endDate
        "no dates provided"                  | 0             | 0
        "future dates"                       | 5             | 7
        "past effectiveDate, future endDate" | -1            | 2
        "past dates"                         | -5            | -3
        "no effectiveDate, future endDate"   | 0             | 7
        "no effectiveDate, past endDate"     | 0             | -1
        "no endDate, future effectiveDate"   | 3             | 0
        "no endDate, past effectiveDate"     | -1            | 0
    }

    def "valid /{patientId}/update with no patient"() {
        given:
        RelationshipRequest body = buildRelationshipRequest(1, 3, RelationshipRole.REFERRING_PROVIDER, PROVIDER)
        HttpRequest request = buildHttpPostRequest(BASE_ENDPOINT + "/" + PATIENT + "/update", body, CORRELATION_ID, "test-token")

        and:
        relationshipService.manageRelationship(body, PATIENT, new ProviderApiHeaders(CORRELATION_ID)) >> Maybe.empty()

        when:
        client.toBlocking().exchange(request)

        then:
        HttpClientResponseException e = thrown(HttpClientResponseException.class)
        e.status == HttpStatus.NOT_FOUND
    }

    @Unroll
    def "invalid /{patientId}/update with #desc"() {
        given:
        RelationshipRequest body = buildRelationshipRequest(effectiveDate, endDate, relationship, provider)
        HttpRequest request = buildHttpPostRequest(BASE_ENDPOINT + "/" + PATIENT + "/update", body, CORRELATION_ID, "test-token")

        when:
        client.toBlocking().exchange(request)

        then:
        HttpClientResponseException e = thrown(HttpClientResponseException.class)
        e.status == HttpStatus.BAD_REQUEST

        where:
        desc                                       | effectiveDate | endDate | relationship                        | provider
        "wrong future dates"                       | 3             | 1       | RelationshipRole.REFERRING_PROVIDER | PROVIDER
        "wrong past dates"                         | -1            | -3      | RelationshipRole.REFERRING_PROVIDER | PROVIDER
        "wrong future effectiveDate, past endDate" | 1             | -2      | RelationshipRole.REFERRING_PROVIDER | PROVIDER
        "no relationship role"                     | 1             | 3       | null                                | PROVIDER
        "no provider"                              | 1             | 3       | RelationshipRole.REFERRING_PROVIDER | null
    }
}
