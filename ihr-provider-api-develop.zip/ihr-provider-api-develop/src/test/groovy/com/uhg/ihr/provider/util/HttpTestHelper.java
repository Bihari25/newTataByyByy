package com.uhg.ihr.provider.util;


import com.uhg.ihr.provider.api.model.Actor;
import com.uhg.ihr.provider.api.model.ActorId;
import com.uhg.ihr.provider.api.model.IhrApiWithActorRequest;
import io.micronaut.context.annotation.Value;
import io.micronaut.http.HttpRequest;
import io.micronaut.http.MutableHttpRequest;
import io.micronaut.runtime.event.annotation.EventListener;
import io.micronaut.runtime.server.event.ServerStartupEvent;

import javax.inject.Singleton;
import java.net.URI;
import java.net.URISyntaxException;

@Singleton
public class HttpTestHelper {

    public static HttpTestHelper INSTANCE;

    public static final String PROP_PREFIX = "integration-test";

    @Value("${" + PROP_PREFIX + ".base-uri:`http://localhost:8080`}")
    public String host;

    @Value("${" + PROP_PREFIX + ".provider-chid:300ACTO110564929804013574}")
    public String providerChid;

    @Value("${" + PROP_PREFIX + ".data-patient-chid:216ACTI140404223406039040}")
    public String dataPatientChid;

    @Value("${" + PROP_PREFIX + ".demograhpic-patient-chid:XXXTEST006}")
    public String demoPatientChid;

    @EventListener
    public void onStartup(ServerStartupEvent event) {
        INSTANCE = this;
    }

    public static String host() {
        return INSTANCE.host;
    }

    public static <T extends IhrApiWithActorRequest> void configureIhrApiWithActorRequest(T request, String providerIdString) {
        if (providerIdString != null && !providerIdString.isBlank()) {
            request.setActor(buildIhrProvider(providerIdString));
        }
    }

    public static Actor buildIhrProvider(String providerIdString) {
        ActorId providerId = new ActorId(providerIdString, providerIdString);
        return new Actor(providerId, null);
    }

    public static <T> MutableHttpRequest<T> buildHttpPostRequest(String endpointPath, T body, String correlationId, String jwtToken) {
        try {
            MutableHttpRequest<T> request = HttpRequest.POST(new URI(host() + endpointPath), body);
            return addHeaders(request, correlationId, jwtToken);
        } catch (URISyntaxException e) {
            throw new RuntimeException(e);
        }
    }

    public static MutableHttpRequest buildHttpGetRequest(String endpointPath, String correlationId, String jwtToken) {
        try {
            MutableHttpRequest<Void> request = HttpRequest.GET(new URI(host() + endpointPath));
            return addHeaders(request, correlationId, jwtToken);
        } catch (URISyntaxException e) {
            throw new RuntimeException(e);
        }
    }

    private static <T> MutableHttpRequest<T> addHeaders(MutableHttpRequest<T> request, String correlationId, String jwtToken) {
        request = request.header("JWT", jwtToken);
        if (correlationId != null) {
            request = request.header("optum-cid-ext", correlationId);
        }
        return request;
    }
}
