package com.uhg.ihr.provider.api.service

import com.fasterxml.jackson.databind.JsonNode
import com.uhg.ihr.provider.api.exception.IhrNotFoundException
import com.uhg.ihr.provider.api.model.RecordType
import com.uhg.ihr.provider.data.model.Payload
import spock.lang.Ignore
import spock.lang.Specification
import spock.lang.Unroll

import java.nio.file.Files
import java.nio.file.Path
import java.nio.file.Paths
import java.util.stream.Collectors
import java.util.stream.Stream

@Unroll
class DataServiceSpec extends Specification {

    def "DataService:: filterPayload  happy path scenarios: #desc"() {
        expect:
        Payload samplePayload = buildSamplePayload("payload-sample.json")
        Set<RecordType> requestedDataClasses = dataClasses
        JsonNode node = DataService.filterPayload(samplePayload, 2, requestedDataClasses, null)
        outputSize == node.get('dataClasses').size()

        where:
        desc         | dataClasses                                                             || outputSize
        "filter all" | []                                                                      || 0
        "one"        | [RecordType.CARE_TEAM]                                                  || 1
        "three"      | [RecordType.CARE_TEAM, RecordType.HEALTH_STATUS, RecordType.CARE_GIVER] || 3
    }

    def "DataService:: filterPayload health nodes happy path scenarios: #desc"() {
        expect:
        Payload samplePayload = buildSamplePayload("payload-sample.json")
        Set<RecordType> requestedDataClasses = dataClasses
        JsonNode node = DataService.filterPayload(samplePayload, 2, requestedDataClasses, null)
        outputSize == node.get('dataClasses').size()

        where:
        desc               | dataClasses                                                                           || outputSize
        "Service Provider" | [RecordType.SERVICE_FACILITY_PROVIDER]                                                || 1
        "Health Cases"     | [RecordType.HEALTH_CONDITION, RecordType.HEALTH_MEDICATION, RecordType.HEALTH_DEVICE] || 3
    }


    def "DataService:: filterPayload for empty medications and service providers : #desc"() {
        expect:
        Payload samplePayload = buildSamplePayload("payload-empty-medications.json")
        Set<RecordType> requestedDataClasses = dataClasses
        JsonNode node = DataService.filterPayload(samplePayload, 2, requestedDataClasses, null)
        outputSize == node.get('dataClasses').size()

        where:
        desc                | dataClasses                            | lookupKey           || outputSize
        "Service Provider"  | [RecordType.SERVICE_FACILITY_PROVIDER] | "service_providers" || 1
        "Health Medication" | [RecordType.HEALTH_MEDICATION]         | "medications"       || 1
    }

    def "DataService:: filterPayload for api version = 1 happy path scenarios: #desc"() {
        expect:
        Payload samplePayload = buildSamplePayload("payload-sample.json")
        Set<RecordType> requestedDataClasses = dataClasses
        JsonNode node = DataService.filterPayload(samplePayload, 1, requestedDataClasses, null)
        outputSize == node.get('dataClasses').size()

        where:
        desc               | dataClasses                                                                           || outputSize
        "Service Provider" | [RecordType.SERVICE_FACILITY_PROVIDER]                                                || 12
        "Health Cases"     | [RecordType.HEALTH_CONDITION, RecordType.HEALTH_MEDICATION, RecordType.HEALTH_DEVICE] || 12
    }


    @Ignore
    def "DataService:: filterPayload empty payload scenarios: #desc"() {
        when:
        Payload samplePayload = null
        Set<RecordType> requestedDataClasses = dataClasses
        JsonNode node = DataService.filterPayload(samplePayload, 2, requestedDataClasses, null)

        then:
        IhrNotFoundException ihrEx = thrown()
        ihrEx.message.contains('user was matched but no corresponding data was found')


        where:
        desc                    | dataClasses
        "null payload and dc"   | null
        "null payload empty dc" | []
    }


    /**
     * Method to build sample play load.
     *
     * @param fileName
     * @return Payload
     */
    private Payload buildSamplePayload(String fileName) {
        String pyaloadContent = readFileContent(fileName)
        Payload payload = Payload.builder()
                .language("EN")
                .taxonomy("Not Used")
                .ihrIdentifier("ACT12345678")
                .payload(pyaloadContent)
                .build()

        payload
    }


    /**
     * Method to read file content for given file.
     *
     * @param fileName
     * @return String* @throws Exception
     */
    private String readFileContent(String fileName) throws Exception {
        Path path = Paths.get(getClass().getClassLoader().getResource(fileName).toURI())

        Stream<String> lines = Files.lines(path)
        String fileContent = lines.collect(Collectors.joining("\n"))
        fileContent
    }

}
