package com.uhg.ihr.medispan.dib.loaders;

/**
*
*/
public class Mmwiptshape extends TableLoader {
    
	/**
	 *
	 */
    public Mmwiptshape() {
        super();
    }
    
    @Override
    public String getCreateQuery() {
        return
        "CREATE TABLE mmw_ipt_shape " +
        "( " +
            "shapeid                     SMALLINT NOT NULL, " +
            "description                 CHARACTER VARYING(30) NOT NULL, " +
            "paletteid                   SMALLint NOT NULL, " +
            "CONSTRAINT mmw_ipt_shape_pkey PRIMARY KEY (shapeid) " +
        ") " +
        "WITH (OIDS=TRUE); ";
    }
    
    @Override
    public String getInsertQuery(String line) {
        String[] fields = line.split("\\|");
        
        return "INSERT INTO mmw_ipt_shape VALUES " +
        "( " +
            Integer.parseInt(fields[0]) + "," +     //shapeid           SMALLINT NOT NULL
            "'" + fields[1] + "'," +                //description       CHARACTER VARYING(30) NOT NULL
            Integer.parseInt(fields[2]) +           //paletteid         SMALLint NOT NULL
        " ); ";
    }

}
