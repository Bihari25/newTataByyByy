package com.uhg.ihr.provider.api.controller;


import com.uhg.ihr.audit.annotations.AuditContextValue;
import com.uhg.ihr.audit.annotations.AuditRequest;
import com.uhg.ihr.provider.api.model.IhrSearchApiRequest;
import com.uhg.ihr.provider.api.model.PatientDemographicsResponse;
import com.uhg.ihr.provider.api.model.ProviderApiHeaders;
import com.uhg.ihr.provider.api.service.backend.SearchAdapterInterface;
import com.uhg.ihr.provider.api.validator.ValidIhrSearchApiRequest;
import io.micronaut.context.annotation.Context;
import io.micronaut.http.HttpRequest;
import io.micronaut.http.MediaType;
import io.micronaut.http.MutableHttpResponse;
import io.micronaut.http.annotation.Body;
import io.micronaut.http.annotation.Controller;
import io.micronaut.http.annotation.Post;
import io.micronaut.http.annotation.RequestBean;
import io.micronaut.validation.Validated;
import io.reactivex.Maybe;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import lombok.extern.slf4j.Slf4j;

import javax.inject.Inject;
import javax.validation.Valid;

import static com.uhg.ihr.provider.api.util.ControllerUtil.buildHttpResponse;

@Slf4j
@Validated
@Context
@Controller("/individual-health-records/v1")
public class SearchController {

    @Inject
    private SearchAdapterInterface searchService;

    @Post(uri = "/search", produces = MediaType.APPLICATION_JSON, consumes = MediaType.APPLICATION_JSON)
    @Operation(summary = "Search IHR Patient/Member",
            description = "Search for an IHR Patient - returns IHR Patient Information.",
            operationId = "search")
    @ApiResponse(responseCode = "200", description = "A Brief Description of this resource Path and action",
            content = @Content(mediaType = "application/json")
    )
    @Schema(name = "Ihr Search Request")
    @AuditRequest(auditType = "patient_search")
    public Maybe<MutableHttpResponse<PatientDemographicsResponse>> search(final HttpRequest<IhrSearchApiRequest> myRequest,
                                                                          final @Valid @RequestBean ProviderApiHeaders headers,
                                                                          @AuditContextValue(
                                                                                  context = AuditContextValue.ContextType.DETAIL,
                                                                                  dataPath = "modifier.newPatient",
                                                                                  contextPath = {"search", "newPatient"}
                                                                          )
                                                                          @AuditContextValue(
                                                                                  context = AuditContextValue.ContextType.DETAIL,
                                                                                  dataPath = "requestCriteria.mbrDemographics.nameFilter",
                                                                                  contextPath = {"search", "name"}
                                                                          )
                                                                          @AuditContextValue(
                                                                                  context = AuditContextValue.ContextType.DETAIL,
                                                                                  dataPath = "requestCriteria.mbrDemographics.identifierFilter",
                                                                                  contextPath = {"search", "identifier"}
                                                                          )
                                                                          @AuditContextValue(
                                                                                  context = AuditContextValue.ContextType.DETAIL,
                                                                                  dataPath = "requestCriteria.mbrDemographics.dateOfBirthFilter",
                                                                                  contextPath = {"search", "dateOfBirth"}
                                                                          )
                                                                          @AuditContextValue(
                                                                                  context = AuditContextValue.ContextType.DETAIL,
                                                                                  dataPath = "requestCriteria.mbrDemographics.genderFilter",
                                                                                  contextPath = {"search", "gender"}
                                                                          ) final @ValidIhrSearchApiRequest @Body IhrSearchApiRequest apiDto) {
        // todo: extract to a method for portal search and senzning search translator
        return buildHttpResponse(searchService.searchForPatients(apiDto, headers), myRequest, "Search");
    }
}
