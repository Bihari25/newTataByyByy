package com.uhg.ihr.provider.api.logging;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.common.collect.ImmutableSet;
import com.optum.cloudsdk.crypto.CryptoFacadePBE;
import com.uhg.ihr.provider.api.model.Big5;
import com.uhg.ihr.provider.api.model.IhrApiRequestOld;
import com.uhg.ihr.provider.api.model.MId;
import com.uhg.ihr.provider.api.util.AppUtils;
import io.micronaut.http.HttpHeaders;
import io.micronaut.http.HttpRequest;
import lombok.NoArgsConstructor;
import lombok.extern.slf4j.Slf4j;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.net.InetAddress;
import java.net.InetSocketAddress;
import java.net.URL;
import java.net.UnknownHostException;
import java.time.Duration;
import java.time.Instant;
import java.time.ZoneOffset;
import java.time.ZonedDateTime;
import java.util.*;

@Slf4j
@NoArgsConstructor
public class LogHelper {
    private static final CryptoFacadePBE FACADE;
    private static final String FORMAT = "EVENTTIME=%s|Level=INFO|ACTOR=%s|CORR_ID=%s|EVENT=\"R01:Transaction:Start\"|LOGTYPE=\"RESILIENCY_AUDIT\"|SRC_IP=%s|ACTOR_IP=%s|Details=%s|COMPONENT=%s|OP_ID=%s|HOST=%s|METHOD=%s|CODE=%s|STATUS=%s";
    private static final String HOST;
    private static final ObjectMapper MAPPER = new ObjectMapper();
    private static final String METHODS = "methods";
    private static final Map<String, String> ENVIRONMENTALS = new HashMap<>();
    private static final Set<String> ENV_VARS = ImmutableSet.of("APPLICATION_NAME", "CLUSTER", "DATACENTER", "ENVIRONMENT", "VERSION");
    private static final Properties properties;
    public static final String MDC_LOG_TYPE_KEY = "logType";

    static {
        File cryptoFile = AppUtils.findRelativeOrAbsoluteFilePath("configs/restcrypto.properties");
        String name = null;
        if (cryptoFile != null) {
            name = cryptoFile.getAbsolutePath();
        } else {
            URL url = LogHelper.class.getClassLoader().getResource("restcrypto.properties");
            if (url != null) {
                name = url.getPath();
            }
        }
        FACADE = new CryptoFacadePBE(name);

        File versionFile = AppUtils.findRelativeOrAbsoluteFilePath("configs/version.properties");
        String versionPropertiesUrl = null;
        if (versionFile != null) {
            versionPropertiesUrl = versionFile.getAbsolutePath();
        } else {
            URL url = LogHelper.class.getClassLoader().getResource("version.properties");
            if (url != null) {
                versionPropertiesUrl = url.getPath();
            }
        }
        properties = new Properties();
        try {
            InputStream inputStream = new FileInputStream(versionPropertiesUrl);
            properties.load(inputStream);
        } catch (IOException e) {
            log.error("Unable to load version properties file");
        }

        String ip = null;
        try {
            ip = InetAddress.getLocalHost().getHostAddress();
        } catch (UnknownHostException e) {
            log.error("Could not find the ip address", e);
        }
        HOST = ip == null ? "unknown" : ip;
        ENV_VARS.forEach(env -> ENVIRONMENTALS.put(env, System.getenv(env)));
    }

    @SuppressWarnings("unchecked")
    public static void addAttribute(final HttpRequest request, final String key, final Object value) {
        Map<String, Object> map = request.getAttribute(LoggingFilter.LOG_MAP, Map.class).orElse(new HashMap());
        map.put(key, value);
        request.setAttribute(LoggingFilter.LOG_MAP, map);
    }

    public static void logStart(final HttpRequest request, final String method) {
        addAttribute(request, method + "_start", Instant.now());
    }

    @SuppressWarnings("unchecked")
    public static void logSuccess(final HttpRequest request, final String method) {
        setDuration(request, method);
        Map<String, Object> map = request.getAttribute(LoggingFilter.LOG_MAP, Map.class).orElse(new HashMap());
        map.put(method + "Status", "success");
        request.setAttribute(LoggingFilter.LOG_MAP, map);
    }

    @SuppressWarnings("unchecked")
    public static void logFail(final HttpRequest request, final String method, final String reason) {
        setDuration(request, method);
        Map<String, Object> map = request.getAttribute(LoggingFilter.LOG_MAP, Map.class).orElse(new HashMap());
        map.put(method + "Status", "failure");
        map.put(method + "Reason", reason);
        request.setAttribute(LoggingFilter.LOG_MAP, map);
    }

    @SuppressWarnings("unchecked")
    public static void addDetails(final Map<String, Object> details, final Instant start, final String method, final String code, final String status) {
        if (details == null) {
            return;
        }
        String duration = "not provided";
        if (start != null) {
            duration = Duration.between(start, Instant.now()).toMillis() + " ms";
        }

        Map<String, String> methodDetails = new LinkedHashMap<>();
        methodDetails.put("name", method);
        methodDetails.put("duration", duration);
        methodDetails.put("code", code);
        methodDetails.put("status", status);
        List<Map<String, String>> methods = (ArrayList) details.get(METHODS);
        if (methods != null) {
            methods.add(methodDetails);
        }
    }

    public static Map<String, Object> initializeLogger(IhrApiRequestOld datum, String corrId, final HttpRequest<IhrApiRequestOld> myRequest, int schemaVersion) {
        if (datum == null) {
            return new LinkedHashMap<>();
        }

        String accept = null;
        String clientId = null;
        if (myRequest != null) {
            accept = myRequest.getHeaders().get("Accept");
            clientId = myRequest.getHeaders().get(AppUtils.X_CONSUMER_HEADER);
        }
        String encryptBig5 = FACADE.encryptString(datum.toString());
        MId mbrId = datum.getMbrId();
        Big5 big5 = mbrId.getBig5();
        Map<String, Object> logMap = new LinkedHashMap<>(ENVIRONMENTALS);
        logMap.put("X-Consumer-Username", clientId);
        logMap.put("Accept", accept);
        logMap.put("schema-version", schemaVersion);
        logMap.put("optum-cid-ext", corrId);
        logMap.put("rally-corr-id", datum.getCorrelationId());
        logMap.put("big5", encryptBig5);
        logMap.put("searchId", big5.getSearchId());
        logMap.put(mbrId.getIdType(), mbrId.getIdValue());
        logMap.put(METHODS, new ArrayList<>());
        return logMap;
    }

    public static String logRecord(final HttpRequest request, String component, final Map<String, Object> logMap, String code,
                                   String status, String ihrIdentifier) {
        LogRecord record = new LogRecord();
        String actorIp = "internal user";
        record.setResponseCode(code);
        record.setResponseStatus(status);
        record.setComponent(component);
        if (request == null) {
            record.setActor(actorIp);
            record.setMethod("internal usage");
            String formattedString = getFormattedString(record);
            log.info(formattedString);
            return formattedString;
        }

        HttpHeaders headers = request.getHeaders();
        if (headers != null) {
            Optional<String> origin = headers.getOrigin();
            if (origin.isPresent()) {
                origin.ifPresent(record::setSourceId);
            }
        }
        String url = request.getPath();
        record.setOperation(url);
        InetSocketAddress addr = request.getRemoteAddress();
        record.setActor(addr.getHostString());
        actorIp = request.getRemoteAddress().getHostString() + ":" + request.getRemoteAddress().getPort();
        record.setActorIp(actorIp);
        record.setMethod(request.getMethod().toString());

        if (logMap != null && !logMap.isEmpty()) {
            logMap.put("IHR Identifier", ihrIdentifier);
            properties.forEach((key, value) -> logMap.put(key.toString(), value.toString()));
            String message = "";
            try {
                message = MAPPER.writeValueAsString(logMap);
            } catch (JsonProcessingException e) {
                log.warn("unable to convert logMap to json {}", logMap);
            }
            record.setDetails(message);
        }
        String formattedString = getFormattedString(record);
        log.info(formattedString);
        return formattedString;
    }

    private static String getFormattedString(LogRecord record) {
        return String.format(FORMAT, ZonedDateTime.now(ZoneOffset.UTC), record.getActor(), record.getCorrelationId(),
                record.getSourceId(), record.getActorIp(), record.getDetails(), record.getComponent(),
                record.getOperation(), HOST, record.getMethod(), record.getResponseCode(), record.getResponseStatus());
    }

    @SuppressWarnings("unchecked")
    public static void setDuration(final HttpRequest request, final String method) {
        Map<String, Object> map = request.getAttribute(LoggingFilter.LOG_MAP, Map.class).orElse(new HashMap());
        Instant start = (Instant) map.get(method + "_start");
        if (start == null) {
            log.error("tried to get start time for {} and failed", method + "_start");
            map.put("logError", "tried to get start time for " + method + "_start and failed");
        } else {
            map.put(method + "Ms", Duration.between(start, Instant.now()).toMillis());
            map.remove(method + "_start");
        }
        request.setAttribute(LoggingFilter.LOG_MAP, map);
    }
}