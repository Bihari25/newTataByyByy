package com.uhg.ihr.provider.api.service.backend.b50.relationship;

import com.fasterxml.jackson.databind.JsonNode;
import com.uhg.ihr.provider.api.exception.LiteHttpClientException;
import com.uhg.ihr.provider.api.exception.UnhandledApiException;
import com.uhg.ihr.provider.api.model.ProviderApiHeaders;
import com.uhg.ihr.provider.api.service.RelationshipInterface;
import com.uhg.ihr.provider.api.service.backend.b50.B50ApiSecurity;
import com.uhg.ihr.provider.api.service.backend.b50.relationship.model.B50RelationshipRequest;
import com.uhg.ihr.provider.api.service.relationship.model.Relationship;
import com.uhg.ihr.provider.api.service.relationship.model.RelationshipRequest;
import com.uhg.ihr.provider.api.service.relationship.model.RelationshipResponse;
import io.micronaut.http.client.exceptions.HttpClientResponseException;
import io.reactivex.Maybe;
import lombok.extern.slf4j.Slf4j;

import javax.inject.Inject;
import javax.inject.Singleton;
import java.util.ArrayList;
import java.util.List;
import java.util.regex.Pattern;

import static com.uhg.ihr.provider.api.util.AppUtils.getTextOrNull;

@Slf4j
@Singleton
public class B50RelationshipService implements RelationshipInterface {

    public static final String B50_RELATIONSHIP_NODE = "relationships";
    public static final String B50_PARTICIPANTS_NODE = "participants";
    public static final String B50_ROLE_NODE = "role";
    public static final String B50_CHID_NODE = "actorId";
    public static final String B50_EFFECTIVE_DATE_NODE = "effective_date";
    public static final String B50_END_DATE_NODE = "end_date";

    @Inject
    B50RelationshipClient client;

    @Inject
    B50ApiSecurity security;

    public Maybe<RelationshipResponse> manageRelationship(RelationshipRequest request, String patientChid, ProviderApiHeaders headers) {
        B50RelationshipRequest b50Request = B50RelationshipRequest.builder()
                .patientChid(patientChid)
                .providerChid(request.getActorId())
                .providerRole(request.getProviderRole())
                .effectiveDate(request.getEffectiveDate())
                .endDate(request.getTerminationDate())
                .build();
        return client.manageRelationship(security.generateProviderBearerToken(request.getActorId()), b50Request, headers.getCorrelationId(), headers.getAcceptLanguage())
                .onErrorResumeNext(e -> {
                    if (e instanceof HttpClientResponseException) {
                        return Maybe.error(new LiteHttpClientException((HttpClientResponseException) e, b50Request));
                    } else {
                        return Maybe.error(new UnhandledApiException(e));
                    }
                })
                //Build successful response
                .map(response -> {
                    System.out.println("Relationship response: " + response);

                    return RelationshipResponse.builder()
                            .patientActorId(patientChid)
                            .providerRelationships(
                                    compileRelatedRelationships(request.getActorId(), response.get(B50_RELATIONSHIP_NODE), false)
                            )
                            .build();
                });
    }

    public static List<Relationship> compileRelatedRelationships(JsonNode relationshipNode) {
        return compileRelatedRelationships("", relationshipNode, true);
    }

    /**
     * Method will compile a list of provider relationships based on the passed JSON node which should have the following format:
     * [
     * {
     * "role": "Healthcare Delivery Relationship",
     * "role_chid": "QLR316",
     * "status": "Enrolled",
     * "effective_date": "2020-05-17",
     * "end_date": "2020-08-22",
     * "selfRole": "Patient",
     * "participants": [
     * {
     * "role": "Record Reviewer",
     * "role_chid": "OBS57249",
     * "actorId": "300ACTO110564929804013533"
     * }
     * ]
     * },
     * {
     * ...
     * }
     * ]
     *
     * @param providerId
     * @param relationshipsNode
     * @return
     */
    public static List<Relationship> compileRelatedRelationships(String providerId, JsonNode relationshipsNode, boolean skipProviderFilter) {
        List<Relationship> relationships = new ArrayList<>();
        if (relationshipsNode != null) {
            Pattern providerMatcher = Pattern.compile(providerId);
            //Loop through relationship objects
            for (JsonNode relationshipNode : relationshipsNode) {
                if (relationshipNode.get(B50_PARTICIPANTS_NODE) != null) {
                    //Loop through participants and add relationships which match providerId
                    for (JsonNode participant : relationshipNode.get(B50_PARTICIPANTS_NODE)) {
                        if (participant.get(B50_CHID_NODE) != null &&
                                (skipProviderFilter || providerMatcher.matcher(participant.get(B50_CHID_NODE).asText()).matches())) {
                            relationships.add(
                                    Relationship
                                            .builder()
                                            .providerChid(getTextOrNull(participant.get(B50_CHID_NODE)))
                                            .relationship(getTextOrNull(participant.get(B50_ROLE_NODE)))
                                            .effectiveDate(getTextOrNull(relationshipNode.get(B50_EFFECTIVE_DATE_NODE)))
                                            .endDate(getTextOrNull(relationshipNode.get(B50_END_DATE_NODE)))
                                            .build()
                            );
                        }
                    }
                }
            }
        }
        return relationships;
    }
}
