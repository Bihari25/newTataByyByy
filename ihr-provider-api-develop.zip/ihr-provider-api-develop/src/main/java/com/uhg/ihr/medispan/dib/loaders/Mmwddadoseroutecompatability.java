package com.uhg.ihr.medispan.dib.loaders;

/**
*
*/
public class Mmwddadoseroutecompatability extends TableLoader {
    
	/**
	 *
	 */
    public Mmwddadoseroutecompatability() {
        super();
    }
    
    @Override
    public String getCreateQuery() {
        return
        "CREATE TABLE mmw_dda_doseroutecompatability " + 
        "( " +
            "rtid                    INTEGER NOT NULL, " +
            "rtabbrev                CHARACTER VARYING(3) NOT NULL, " +
            "rtdescription           CHARACTER VARYING(20) NOT NULL, " +
            "routeid                 INTEGER NOT NULL, " +
            "routeabbrev             CHARACTER VARYING(3) NOT NULL, " +
            "routedescription        CHARACTER VARYING(20) NOT NULL, " +
            "CONSTRAINT mmw_dda_doseroutecompatability_pkey PRIMARY KEY (rtid, routeid) " + 
        ") " +
        "WITH (OIDS=TRUE); ";
    }
    
    @Override
    public String getInsertQuery(String line) {
        String[] fields = line.split("\\|");
        
        return "INSERT INTO mmw_dda_doseroutecompatability VALUES " +
        "( " +
            Integer.parseInt(fields[0]) + "," +     //rtid                    INTEGER NOT NULL
            "'" + fields[1] + "'," +                //rtabbrev                CHARACTER VARYING(3) NOT NULL
            "'" + fields[2] + "'," +                //rtdescription           CHARACTER VARYING(20) NOT NULL
            Integer.parseInt(fields[3]) + "," +     //routeid                 INTEGER NOT NULL
            "'" + fields[4] + "'," +                //routeabbrev             CHARACTER VARYING(3) NOT NULL
            "'" + fields[5] + "'" +                 //routedescription        CHARACTER VARYING(20) NOT NULL
        " ); ";
    }

}
