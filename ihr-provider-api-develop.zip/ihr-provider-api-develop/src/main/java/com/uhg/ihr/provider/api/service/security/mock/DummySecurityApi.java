package com.uhg.ihr.provider.api.service.security.mock;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.uhg.ihr.provider.api.model.profile.*;
import com.uhg.ihr.provider.api.service.security.SecurityApi;
import com.uhg.ihr.provider.api.service.security.model.RoleChangeRequest;
import io.micronaut.context.annotation.Secondary;
import io.reactivex.Maybe;
import lombok.Data;
import lombok.extern.slf4j.Slf4j;

import javax.inject.Singleton;
import java.io.IOException;
import java.net.URL;
import java.util.*;
import java.util.stream.Collectors;

@Slf4j
@Secondary
@Singleton
public class DummySecurityApi implements SecurityApi {
    private static final List<RoleMapping> roleMappingList;

    static {
        URL dummyDataUrl = DummySecurityApi.class.getResource("/security/mock/roles.json");
        log.info("DummyDataURL: "+ ((dummyDataUrl != null) ? ("path: " + dummyDataUrl.getPath()) : "null or empty"));
        RoleMapping[] dummyData = null;

        if (dummyDataUrl != null) {
            ObjectMapper mapper = new ObjectMapper();
            try {
                dummyData = mapper.readValue(dummyDataUrl, RoleMapping[].class);
            }
            catch (IOException e) {
                System.err.println("throws exception - Unable to read dummy profile data -- using empty data: "+e);
            }
        }
        else {
            System.err.println("Unable to initialize dummy profile data -- using empty data");
        }

        roleMappingList = dummyData != null ? List.of(dummyData) : Collections.emptyList();

    }


//    private String resolveName(String name) {
//        if (name == null) {
//            return name;
//        }
//        if (!name.startsWith("/")) {
//            Class c = this;
//            while (c.isArray()) {
//                c = c.getComponentType();
//            }
//            String baseName = c.getName();
//            int index = baseName.lastIndexOf('.');
//            if (index != -1) {
//                name = baseName.substring(0, index).replace('.', '/') + "/" + name;
//            }
//        } else {
//            name = name.substring(1);
//        }
//        return name;
//    }

    @Override
    public Maybe<List<UserPermission>> lookupRoles(RoleLookup lookup) {
        List<UserPermission> rtnPermissions = new ArrayList<>();

        ExternalSecurityAccess extSecurity = lookup.getExternalSecurity();
        UserProfileConstant.SECURED_CONTEXT securedContext = extSecurity != null ? extSecurity.getSecuredContext() : null;
        if (securedContext != null) {
            Optional<RoleMapping> mapping
                    = roleMappingList.stream()
                    .filter(rm -> rm.securedContext == securedContext)
                    .findFirst();
            if (mapping.isPresent()) {
                RoleMapping rm = mapping.get();
                List<SecurityMapping> securityMappings = rm.getSecurities();
                if (securityMappings != null && !securityMappings.isEmpty()) {
                    Set<String> roles = extSecurity.getRoles();
                    if (roles != null && !roles.isEmpty()) {
                        Set<String> roleSet = new HashSet<>(roles);

                        securityMappings
                                = securityMappings.stream()
                                .filter(sMapping -> roleSet.contains(sMapping.getKey()))
                                .collect(Collectors.toList());
                        if (!securityMappings.isEmpty()) {
                            Set<UserProfileConstant.ROLE_CONTEXT> filterContext
                                    = lookup.getFilterContext();

                            if (filterContext != null && filterContext.isEmpty()) {
                                filterContext = null;
                            }

                            Map<UserProfileConstant.ROLE_CONTEXT,UserPermission> buildPermissions = new HashMap<>();
                            for (SecurityMapping sMapping : securityMappings) {
                                if (sMapping.permissions != null && !sMapping.permissions.isEmpty()) {
                                    for (UserPermission perm : sMapping.permissions) {
                                        UserProfileConstant.ROLE_CONTEXT ctx = perm.getContext();
                                        if (filterContext != null
                                                && !filterContext.contains(ctx)) {
                                            continue;
                                        }
                                        UserPermission buildPermission;
                                        if (!buildPermissions.containsKey(ctx)) {
                                            buildPermission = new UserPermission();
                                            buildPermission.setContext(ctx);
                                            buildPermissions.put(ctx, buildPermission);
                                        } else {
                                            buildPermission = buildPermissions.get(ctx);
                                        }

                                        if (perm.getRoles() != null) {
                                            if (buildPermission.getRoles() == null) {
                                                buildPermission.setRoles(new HashSet<>());
                                            }
                                            buildPermission.getRoles().addAll(perm.getRoles());
                                        }
                                        if (perm.getGroups() != null) {
                                            if (buildPermission.getGroups() == null) {
                                                buildPermission.setGroups(new HashSet<>());
                                            }
                                            buildPermission.getGroups().addAll(perm.getGroups());
                                        }
                                    }
                                }
                            }
                            if (!buildPermissions.isEmpty()) {
                                rtnPermissions.addAll(buildPermissions.values());
                            }
                        }
                    }
                }
            }
        }
        return Maybe.just(rtnPermissions);
    }

    @Override
    public Maybe<RoleChangeRequest> putRoles(RoleChangeRequest request) {
        return Maybe.just(request);
    }

    @Data
    private static class RoleMapping {
        private UserProfileConstant.SECURED_CONTEXT securedContext;
        private List<SecurityMapping> securities;
    }
    @Data
    private static class SecurityMapping {
        private String key;
        private List<UserPermission> permissions;
    }
}
