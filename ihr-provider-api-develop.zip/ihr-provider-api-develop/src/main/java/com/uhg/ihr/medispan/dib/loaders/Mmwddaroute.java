package com.uhg.ihr.medispan.dib.loaders;

/**
*
*/
public class Mmwddaroute extends TableLoader {
    
	/**
	 *
	 */
    public Mmwddaroute() {
        super();
    }
    
    @Override
    public String getCreateQuery() {
        return
        "CREATE TABLE mmw_dda_route " + 
        "( " +
            "routeid             INTEGER NOT NULL, " +
            "abbrev              CHARACTER VARYING(3) NOT NULL, " +
            "description         CHARACTER VARYING(50) NOT NULL, " +
            "CONSTRAINT mmw_dda_route_pkey PRIMARY KEY (routeid) " + 
        ") " +
        "WITH (OIDS=TRUE); ";
    }
    
    @Override
    public String getInsertQuery(String line) {
        String[] fields = line.split("\\|");
        
        return "INSERT INTO mmw_dda_route VALUES " +
        "( " +
            Integer.parseInt(fields[0]) + "," +     //routeid             INTEGER NOT NULL
            "'" + fields[1] + "'," +                //abbrev              CHARACTER VARYING(3) NOT NULL
            "'" + fields[2] + "'" +                 //description         CHARACTER VARYING(50) NOT NULL
        " ); ";
    }

}
