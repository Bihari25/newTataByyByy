package com.uhg.ihr.medispan.dib.loaders;

/**
*
*/
public class Mmwparint extends TableLoader {
    
	/**
	 *
	 */
    public Mmwparint() {
        super();
    }
    
    @Override
    public String getCreateQuery() {
        return
        "CREATE TABLE mmw_par_int " +
        "( " +
            "classid1                    CHARACTER VARYING(5) NOT NULL, " +
            "classid2                    CHARACTER VARYING(5) NOT NULL, " +
            "symptomcode                 CHARACTER VARYING(6) NOT NULL, " +
            "monoid                      CHARACTER VARYING(20) NULL, " +
            "symrashind                  SMALLINT NOT NULL, " +
            "symshockind                 SMALLINT NOT NULL, " +
            "symasthmaind                SMALLINT NOT NULL, " +
            "symnauseaind                SMALLINT NOT NULL, " +
            "symanemiaind                SMALLINT NOT NULL, " +
            "symunspecifiedind           SMALLINT NOT NULL, " +
            "CONSTRAINT mmw_par_int_pkey PRIMARY KEY (classid1, classid2, symptomcode) " +
        ") " +
        "WITH (OIDS=TRUE); ";
    }
    
    @Override
    public String getInsertQuery(String line) {
        String[] fields = line.split("\\|");
        
        return "INSERT INTO mmw_par_int VALUES " +
        "( " +
            "'" + fields[0] + "'," +                //classid1                    CHARACTER VARYING(5) NOT NULL
            "'" + fields[1] + "'," +                //classid2                    CHARACTER VARYING(5) NOT NULL
            "'" + fields[2] + "'," +                //symptomcode                 CHARACTER VARYING(6) NOT NULL
            (fields[3].isEmpty() ? "NULL" : "'" + fields[3] + "'") + "," +    //monoid                      CHARACTER VARYING(20) NULL
            Integer.parseInt(fields[4]) + "," +     //symrashind                  SMALLINT NOT NULL
            Integer.parseInt(fields[5]) + "," +     //symshockind                 SMALLINT NOT NULL
            Integer.parseInt(fields[6]) + "," +     //symasthmaind                SMALLINT NOT NULL
            Integer.parseInt(fields[7]) + "," +     //symnauseaind                SMALLINT NOT NULL
            Integer.parseInt(fields[8]) + "," +     //symanemiaind                SMALLINT NOT NULL
            Integer.parseInt(fields[9]) +           //symunspecifiedind           SMALLINT NOT NULL
        " ); ";
    }

}
