package com.uhg.ihr.provider.api.exception;

import io.micronaut.context.annotation.Requires;
import io.micronaut.http.HttpRequest;
import io.micronaut.http.HttpResponse;
import io.micronaut.http.annotation.Produces;
import io.micronaut.http.hateoas.JsonError;
import io.micronaut.http.hateoas.Link;
import io.micronaut.http.server.exceptions.ExceptionHandler;
import lombok.extern.slf4j.Slf4j;

import javax.inject.Singleton;

@Slf4j
@Produces
@Singleton
@Requires(classes = {UnhandledApiException.class, ExceptionHandler.class})
public class UnhandledApiExceptionHandler implements ExceptionHandler<UnhandledApiException, HttpResponse> {
    @Override
    public HttpResponse handle(HttpRequest request, UnhandledApiException exception) {
        Throwable cause = exception.getCause();
        
        if (cause != null) {
            String message = "An unexpected exception " + cause.getClass().getName() + " was thrown: " + cause.getMessage();
            log.error(message, exception);
        } else {
            log.error(exception.getMessage(), exception);
        }
        return HttpResponse.serverError(new JsonError("There was an error handling this request")
                .link(Link.SELF, Link.of(request.getUri())));
    }
}
