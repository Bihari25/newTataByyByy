package com.uhg.ihr.provider.api.service.backend.b50;

public class B50ApiUtils {
    public static final String PROPERTY_PREFIX = "b50-api";
}
