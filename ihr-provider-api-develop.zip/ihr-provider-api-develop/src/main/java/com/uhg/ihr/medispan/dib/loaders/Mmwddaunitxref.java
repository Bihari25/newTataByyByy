package com.uhg.ihr.medispan.dib.loaders;

/**
*
*/
public class Mmwddaunitxref extends TableLoader {
    
	/**
	 *
	 */
    public Mmwddaunitxref() {
        super();
    }
    
    @Override
    public String getCreateQuery() {
        return
        "CREATE TABLE mmw_dda_unit_xref " +
        "( " +
            "fromunitid              INTEGER NOT NULL, " +
            "fromunitdescription     CHARACTER VARYING(50) NOT NULL, " +
            "unitid          INTEGER NOT NULL, " +
            "unitdescription     CHARACTER VARYING(50) NOT NULL, " +
            "typecode                CHARACTER VARYING(2) NOT NULL, " +
            "validforinputind        SMALLINT NOT NULL, " +
            "CONSTRAINT mmw_dda_unit_xref_pkey PRIMARY KEY (fromunitid, unitid) " +
        ") " +
        "WITH (OIDS=TRUE); ";
    }
    
    @Override
    public String getInsertQuery(String line) {
        String[] fields = line.split("\\|");
        
        return "INSERT INTO mmw_dda_unit_xref VALUES " +
        "( " +
            Integer.parseInt(fields[0]) + "," +     //fromunitid                INTEGER NOT NULL
            "'" + fields[1] + "'," +                //fromunitdescription       CHARACTER VARYING(50) NOT NULL
            Integer.parseInt(fields[2]) + "," +     //unitid                    INTEGER NOT NULL
            "'" + fields[3] + "'," +                //unitdescription           CHARACTER VARYING(50) NOT NULL
            "'" + fields[4] + "'," +                //typecode                  CHARACTER VARYING(2) NOT NULL
            Integer.parseInt(fields[5]) +           //validforinputind          SMALLINT NOT NULL
        " ); ";
    }

}
