package com.uhg.ihr.medispan.dib.service;

import com.uhg.ihr.medispan.dib.DibApi;
import com.uhg.ihr.medispan.dib.model.ImageValue;
import com.uhg.ihr.medispan.dib.model.MedicationMedispan;
import com.uhg.ihr.medispan.prescriptions.DrugImage;
import com.uhg.ihr.medispan.util.CollectionUtils;
import io.micronaut.context.annotation.Property;
import io.reactivex.Maybe;
import lombok.extern.slf4j.Slf4j;

import javax.inject.Inject;
import javax.inject.Singleton;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

@Slf4j
@Singleton
public class DibApiService {

    //    @Property(name = "medispan.image-server")
    private String imageServerUrl;

    public DibApiService() {
        this.imageServerUrl = "http://testing.url.com";
    }

    @Inject
    public DibApiService(@Property(name = "medispan.image-server") String imageServerUrl) {
        this.imageServerUrl = imageServerUrl.charAt(imageServerUrl.length() - 1) == '/' ?
                imageServerUrl.substring(0, imageServerUrl.length() - 1) :
                imageServerUrl;
    }

    public Maybe<List<ImageValue>> getDrugImagesFK(String productFK) {
        return productFK == null || productFK.isBlank() ? Maybe.empty()
                : Maybe.just(DibApi.SHARED_INSTANCE.getDrugImages(/*context.getContext().getDatabase(),*/
                productFK))
                .map(drugImages -> {
                    if (CollectionUtils.hasContent(drugImages)) {
                        List<ImageValue> imageValues = new ArrayList<>();
                        for (DrugImage drugImage : drugImages) {
                            imageValues.add(new ImageValue("drugimage", drugImage.getImageFile(), imageServerUrl,
                                    drugImage.getDescription(), drugImage.getLabeler(), null, null,
                                    ImageValue.getMimeTypeFromImageName(drugImage.getImageFile())));
                        }
                        return imageValues;
                    } else {
                        return Collections.emptyList();
                    }
                });
    }

    public Maybe<String> getPatientEducationMonographFK(String productFK) {
        return productFK == null ? Maybe.empty()
                : Maybe.just(DibApi.SHARED_INSTANCE.getPatientEducationMonograph(
                productFK,
                null,
                true))
                .onErrorResumeNext(t -> {
                    return Maybe.error(new RuntimeException("Exception getting foreign key for " + "product.toExternalForm()"
                            + ", vocabulary "
                            + "MedicalVocabularyConceptConstants.MEDICAL_VOCABULARY_MEDISPAN_DRUG.toExternalForm()" + ": "
                            + t.getMessage(), t));
                });
    }

    public Maybe<MedicationMedispan> getMedicationSpan(String productFK) {
        return getDrugImagesFK(productFK)
                .onErrorReturn(error -> Collections.emptyList())
                .flatMap(images ->
                        getPatientEducationMonographFK(productFK)
                                .onErrorReturn(error -> "")
                                .map(educationNote -> {
                                    if (images != null || educationNote != null && !educationNote.isBlank()) {
                                        return MedicationMedispan.builder()
                                                .images(images)
                                                .educationNote(educationNote).build();
                                    } else {
                                        return new MedicationMedispan();
                                    }
                                })
                );
    }
}
