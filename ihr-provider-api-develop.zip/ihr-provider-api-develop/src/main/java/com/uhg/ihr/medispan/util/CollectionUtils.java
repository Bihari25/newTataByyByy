package com.uhg.ihr.medispan.util;

import java.util.Collection;
import java.util.Enumeration;
import java.util.Iterator;
import java.util.Map;

public class CollectionUtils {
    public static int compareIgnoreCase(String o1, String o2, int nullOrder) {
        if (!StringUtils.hasContent(o1)) {
            return !StringUtils.hasContent(o2) ? 0 : nullOrder;
        } else if (!StringUtils.hasContent(o2)) {
            return -nullOrder;
        } else {
            int comparison = o1.compareToIgnoreCase(o2);
            if (comparison == 0) {
                comparison = o1.compareTo(o2);
            }
            return comparison;
        }
    }

    /**
     * Returns whether the collection has any non-null entry.
     *
     * @param collection the object collection
     * @return whether the collection has any non-null entry.
     */
//    public static boolean containsNonNull(Collection<?> collection) {
//        if (!com.uhg.ihr.commons.utils.CollectionUtils.hasContent(collection)) {
//            return false;
//        } else {
//            for (Object o : collection) {
//                if (o != null) {
//                    return true;
//                }
//            }
//            return false;
//        }
//    }

    /**
     * Returns whether the array parameter is not null and its length > 0.
     *
     * @param array the object array
     * @return whether the array parameter is not null and its length > 0.
     */
    public static <T> boolean hasContent(T[] array) {
        return !(array == null || array.length == 0);
    }

    /**
     * Returns whether the array parameter is not null and its length > 0.
     *
     * @param array the object array
     * @return whether the array parameter is not null and its length > 0.
     */
    public static boolean hasContent(byte[] array) {
        return !(array == null || array.length == 0);
    }

    /**
     * Returns whether the array parameter is not null and its length > 0.
     *
     * @param array the object array
     * @return whether the array parameter is not null and its length > 0.
     */
    public static boolean hasContent(int[] array) {
        return !(array == null || array.length == 0);
    }

    /**
     * Returns whether the array parameter is not null and its length > 0.
     *
     * @param array the object array
     * @return whether the array parameter is not null and its length > 0.
     */
    public static boolean hasContent(long[] array) {
        return !(array == null || array.length == 0);
    }

    /**
     * Returns whether the collection parameter is not null and its size > 0.
     *
     * @param collection the collection
     * @return whether the collection parameter is not null and its size > 0.
     */
    public static boolean hasContent(Collection<?> collection) {
        return !(collection == null || collection.isEmpty());
    }

    /**
     * Returns whether the enumeration parameter is not null and its length > 0.
     *
     * @param e the object enumeration
     * @return whether the enumeration parameter is not null and its length > 0.
     */
    public static <T> boolean hasContent(Enumeration<?> e) {
        return e != null && e.hasMoreElements();
    }

    /**
     * Returns whether the array parameter is not null and its length > 0.
     *
     * @param array the object array
     * @return whether the array parameter is not null and its length > 0.
     */
    public static boolean hasContent(char[] array) {
        return !(array == null || array.length == 0);
    }

    /**
     * Returns whether the array parameter is not null and its length > 0.
     *
     * @param array the object array
     * @return whether the array parameter is not null and its length > 0.
     */
    public static boolean hasContent(double[] array) {
        return !(array == null || array.length == 0);
    }

    /**
     * Returns whether the array parameter is not null and its length > 0.
     *
     * @param array the object array
     * @return whether the array parameter is not null and its length > 0.
     */
    public static boolean hasContent(float[] array) {
        return !(array == null || array.length == 0);
    }

    /**
     * Returns whether the map parameter is not null and its size > 0.
     *
     * @param map the map
     * @return whether the map parameter is not null and its size > 0.
     */
    public static boolean hasContent(Map<?, ?> map) {
        return !(map == null || map.isEmpty());
    }

    /**
     * Returns whether the iterator is not null and is non-empty.
     *
     * @param iterator the iterator
     * @return whether the iterator is not null and is non-empty.
     */
    public static boolean hasContent(Iterator<?> iterator) {
        return !(iterator == null || !iterator.hasNext());
    }
}
