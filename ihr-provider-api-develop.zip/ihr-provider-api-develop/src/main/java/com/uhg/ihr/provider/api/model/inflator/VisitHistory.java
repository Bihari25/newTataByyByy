
package com.uhg.ihr.provider.api.model.inflator;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.google.gson.annotations.Expose;

import javax.annotation.Generated;
import java.io.Serializable;
import java.util.List;

@Generated("net.hexar.json2pojo")
@JsonIgnoreProperties(ignoreUnknown = true)
@SuppressWarnings("unused")
public class VisitHistory implements Serializable {

    @Expose
    private String admitDate;
    @Expose
    private List<Object> admittingDiagnosis;
    @Expose
    private List<String> dataSource;
    @Expose
    private List<Object> dischargeDiagnosis;
    @Expose
    private String lastUpdateDate;
    @Expose
    private Long objectId;
    @Expose
    private String presenceStateTerm;
    @Expose
    private String recordType;
    @Expose
    private List<Long> relatedCareTeam;
    @Expose
    private List<Long> relatedConditions;
    @Expose
    private List<Object> relatedDevices;
    @Expose
    private List<Object> relatedImmunizations;
    @Expose
    private List<Object> relatedMedications;
    @Expose
    private List<Object> relatedObservations;
    @Expose
    private List<Object> relatedProcedures;
    @Expose
    private List<Object> relatedServiceProviders;
    @Expose
    private List<Object> sensitivityClasses;
    @Expose
    private List<String> sourceClaimIds;
    @Expose
    private Visit visit;
    @Expose
    private String visitType;

    public String getAdmitDate() {
        return admitDate;
    }

    public void setAdmitDate(String admitDate) {
        this.admitDate = admitDate;
    }

    public List<Object> getAdmittingDiagnosis() {
        return admittingDiagnosis;
    }

    public void setAdmittingDiagnosis(List<Object> admittingDiagnosis) {
        this.admittingDiagnosis = admittingDiagnosis;
    }

    public List<String> getDataSource() {
        return dataSource;
    }

    public void setDataSource(List<String> dataSource) {
        this.dataSource = dataSource;
    }

    public List<Object> getDischargeDiagnosis() {
        return dischargeDiagnosis;
    }

    public void setDischargeDiagnosis(List<Object> dischargeDiagnosis) {
        this.dischargeDiagnosis = dischargeDiagnosis;
    }

    public String getLastUpdateDate() {
        return lastUpdateDate;
    }

    public void setLastUpdateDate(String lastUpdateDate) {
        this.lastUpdateDate = lastUpdateDate;
    }

    public Long getObjectId() {
        return objectId;
    }

    public void setObjectId(Long objectId) {
        this.objectId = objectId;
    }

    public String getPresenceStateTerm() {
        return presenceStateTerm;
    }

    public void setPresenceStateTerm(String presenceStateTerm) {
        this.presenceStateTerm = presenceStateTerm;
    }

    public String getRecordType() {
        return recordType;
    }

    public void setRecordType(String recordType) {
        this.recordType = recordType;
    }

    public List<Long> getRelatedCareTeam() {
        return relatedCareTeam;
    }

    public void setRelatedCareTeam(List<Long> relatedCareTeam) {
        this.relatedCareTeam = relatedCareTeam;
    }

    public List<Long> getRelatedConditions() {
        return relatedConditions;
    }

    public void setRelatedConditions(List<Long> relatedConditions) {
        this.relatedConditions = relatedConditions;
    }

    public List<Object> getRelatedDevices() {
        return relatedDevices;
    }

    public void setRelatedDevices(List<Object> relatedDevices) {
        this.relatedDevices = relatedDevices;
    }

    public List<Object> getRelatedImmunizations() {
        return relatedImmunizations;
    }

    public void setRelatedImmunizations(List<Object> relatedImmunizations) {
        this.relatedImmunizations = relatedImmunizations;
    }

    public List<Object> getRelatedMedications() {
        return relatedMedications;
    }

    public void setRelatedMedications(List<Object> relatedMedications) {
        this.relatedMedications = relatedMedications;
    }

    public List<Object> getRelatedObservations() {
        return relatedObservations;
    }

    public void setRelatedObservations(List<Object> relatedObservations) {
        this.relatedObservations = relatedObservations;
    }

    public List<Object> getRelatedProcedures() {
        return relatedProcedures;
    }

    public void setRelatedProcedures(List<Object> relatedProcedures) {
        this.relatedProcedures = relatedProcedures;
    }

    public List<Object> getRelatedServiceProviders() {
        return relatedServiceProviders;
    }

    public void setRelatedServiceProviders(List<Object> relatedServiceProviders) {
        this.relatedServiceProviders = relatedServiceProviders;
    }

    public List<Object> getSensitivityClasses() {
        return sensitivityClasses;
    }

    public void setSensitivityClasses(List<Object> sensitivityClasses) {
        this.sensitivityClasses = sensitivityClasses;
    }

    public List<String> getSourceClaimIds() {
        return sourceClaimIds;
    }

    public void setSourceClaimIds(List<String> sourceClaimIds) {
        this.sourceClaimIds = sourceClaimIds;
    }

    public Visit getVisit() {
        return visit;
    }

    public void setVisit(Visit visit) {
        this.visit = visit;
    }

    public String getVisitType() {
        return visitType;
    }

    public void setVisitType(String visitType) {
        this.visitType = visitType;
    }

}
