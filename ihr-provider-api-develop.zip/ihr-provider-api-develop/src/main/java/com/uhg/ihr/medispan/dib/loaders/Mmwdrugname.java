package com.uhg.ihr.medispan.dib.loaders;

/**
*
*/
public class Mmwdrugname extends TableLoader {
    
	/**
	 *
	 */
    public Mmwdrugname() {
        super();
    }
    
    @Override
    public String getCreateQuery() {
        return
        "CREATE TABLE mmw_drug_name " +
        "( " +
            "pnid                        INTEGER NOT NULL, " +
            "descdisplay                 CHARACTER VARYING(35) NOT NULL, " +
            "descsearch                  CHARACTER VARYING(35) NOT NULL, " +
            "descphonetic                CHARACTER VARYING(35) NOT NULL, " +
            "rpidunique                  INTEGER NULL, " +
            "ddidunique                  INTEGER NULL, " +
            "nametypecode                CHARACTER VARYING(1) NOT NULL, " +
            "rxotccode                   CHARACTER VARYING(1) NULL, " +
            "singleingrind               SMALLINT NOT NULL, " +
            "meddevind                   SMALLINT NOT NULL, " +
            "haspackdrugind              SMALLINT NOT NULL, " +
            "haseqvpackdrugind           SMALLINT NOT NULL, " +
            "haskdcind                   SMALLINT NOT NULL, " +
            "CONSTRAINT mmw_drug_name_pkey PRIMARY KEY (pnid) " +
        ") " +
        "WITH (OIDS=TRUE); ";
    }
    
    @Override
    public String getInsertQuery(String line) {
        String[] fields = line.split("\\|");
        
        return "INSERT INTO mmw_drug_name VALUES " +
        "( " +  
            Integer.parseInt(fields[0]) + "," +        //pnid                  INTEGER NOT NULL
            "'" + fields[1].replace("'", "''") + "'," +                   //descdisplay           CHARACTER VARYING(35) NOT NULL
            "'" + fields[2].replace("'", "''") + "'," +                   //descsearch            CHARACTER VARYING(35) NOT NULL
            "'" + fields[3].replace("'", "''") + "'," +                   //descphonetic          CHARACTER VARYING(35) NOT NULL
            (fields[4].isEmpty() ? "NULL" : Integer.parseInt(fields[4])) + "," +        //rpidunique            INTEGER NULL
            (fields[5].isEmpty() ? "NULL" : Integer.parseInt(fields[5])) + "," +        //ddidunique            INTEGER NULL
            "'" + fields[6] + "'," +                                                        //nametypecode          CHARACTER VARYING(1) NOT NULL
            (fields[7].isEmpty() ? "NULL" : "'" + fields[7] + "'") + "," +              //rxotccode             CHARACTER VARYING(1) NULL
            Integer.parseInt(fields[8]) + "," +        //singleingrind         SMALLINT NOT NULL
            Integer.parseInt(fields[9]) + "," +        //meddevind             SMALLINT NOT NULL
            Integer.parseInt(fields[10]) + "," +       //haspackdrugind        SMALLINT NOT NULL
            Integer.parseInt(fields[10]) + "," +       //haseqvpackdrugind     SMALLINT NOT NULL
            Integer.parseInt(fields[12]) +             //haskdcind             SMALLINT NOT NULL
        " ); ";
    }

}
