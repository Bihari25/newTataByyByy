package com.uhg.ihr.provider.api.model.inflator;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import org.apache.commons.lang3.builder.ToStringBuilder;

import java.io.Serializable;
import java.util.List;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
        "specialties",
        "concept"
})
@JsonIgnoreProperties(ignoreUnknown = true)
public class Occupation implements Serializable {

    @JsonProperty("specialties")
    private List<Specialty> specialties = null;
    @JsonProperty("concept")
    private Concept concept;

    @JsonProperty("specialties")
    public List<Specialty> getSpecialties() {
        return specialties;
    }

    @JsonProperty("specialties")
    public void setSpecialties(List<Specialty> specialties) {
        this.specialties = specialties;
    }

    @JsonProperty("concept")
    public Concept getConcept() {
        return concept;
    }

    @JsonProperty("concept")
    public void setConcept(Concept concept) {
        this.concept = concept;
    }

    @Override
    public String toString() {
        return new ToStringBuilder(this).append("specialties", specialties).append("concept", concept).toString();
    }

}