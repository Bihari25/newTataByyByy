package com.uhg.ihr.provider.api.validator;

import com.uhg.ihr.provider.api.exception.UnhandledApiException;
import com.uhg.ihr.provider.api.service.relationship.model.RelationshipRequest;

import javax.validation.*;
import java.util.Date;
import java.util.Set;

import static com.uhg.ihr.provider.api.util.AppUtils.DATE_FORMATTER;

public class ValidRelationshipRequestValidator implements ConstraintValidator<ValidRelationshipRequest, RelationshipRequest> {

    @Override
    public boolean isValid(final RelationshipRequest request, final ConstraintValidatorContext constraintValidatorContext) {
        constraintValidatorContext.disableDefaultConstraintViolation();
        //Validate annotation validations
        Validator validator = Validation.buildDefaultValidatorFactory().getValidator();
        Set<ConstraintViolation<RelationshipRequest>> violations = validator.validate(request);
        if (!violations.isEmpty()) {
            constraintValidatorContext.buildConstraintViolationWithTemplate(violations.iterator().next().getMessage()).addConstraintViolation();
            return false;
        }

        try {
            Date effectiveDate = DATE_FORMATTER.parse(request.getEffectiveDate());
            Date terminationDate = DATE_FORMATTER.parse(request.getTerminationDate());
            if (effectiveDate.after(terminationDate)) {
                constraintValidatorContext
                        .buildConstraintViolationWithTemplate("Invalid dates, effective date must be before termination date.")
                        .addConstraintViolation();
                return false;
            }
        } catch (Exception e) {
            throw new UnhandledApiException(e);
        }
        return true;
    }
}