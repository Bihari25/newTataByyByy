package com.uhg.ihr.medispan.dib.loaders;

/**
*
*/
public class Mmwddaunit extends TableLoader {
    
	/**
	 *
	 */
    public Mmwddaunit() {
        super();
    }
    
    @Override
    public String getCreateQuery() {
        return
        "CREATE TABLE mmw_dda_unit " + 
        "( " +
            "unitid                  INTEGER NOT NULL, " +
            "unitdescription         CHARACTER VARYING(50) NOT NULL, " +
            "typecode                CHARACTER VARYING(10) NOT NULL, " +
            "validforinputind        SMALLINT NOT NULL, " +
            "CONSTRAINT mmw_dda_unit_pkey PRIMARY KEY (unitid) " +
        ") " +
        "WITH (OIDS=TRUE); ";
    }
    
    @Override
    public String getInsertQuery(String line) {
        String[] fields = line.split("\\|");
        
        return "INSERT INTO mmw_dda_unit VALUES " +
        "( " +
            Integer.parseInt(fields[0]) + "," +    //unitid                  INTEGER NOT NULL
            "'" + fields[1] + "'," +               //unitdescription         CHARACTER VARYING(50) NOT NULL
            "'" + fields[2] + "'," +               //typecode                CHARACTER VARYING(10) NOT NULL
            Integer.parseInt(fields[3]) +          //validforinputind        SMALLINT NOT NULL
        " ); ";
    }

}
