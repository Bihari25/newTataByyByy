package com.uhg.ihr.medispan.dib.loaders;

/**
*
*/
public class Mmwindcotreat extends TableLoader {
    
	/**
	 *
	 */
    public Mmwindcotreat() {
        super();
    }
    
    @Override
    public String getCreateQuery() {
        return
        "CREATE TABLE mmw_ind_cotreat " +
        "( " +
            "gpi                         CHARACTER VARYING(14) NOT NULL, " +
            "mcid                        INTEGER NOT NULL, " +
            "restrictionid               INTEGER NOT NULL, " +
            "microorganismid             INTEGER NOT NULL, " +
            "cotreatsetid                INTEGER NOT NULL, " +
            "sequencenumber              SMALLINT NOT NULL, " +
            "description                 CHARACTER VARYING(80) NOT NULL, " +
            "CONSTRAINT mmw_ind_cotreat_pkey PRIMARY KEY (gpi, mcid, restrictionid, microorganismid, cotreatsetid, sequencenumber) " +
        ") " +
        "WITH (OIDS=TRUE); ";
    }
    
    @Override
    public String getInsertQuery(String line) {
        String[] fields = line.split("\\|");
        
        return "INSERT INTO mmw_ind_cotreat VALUES " +
        "( " +
            "'" + fields[0] + "'," +                //gpi                         CHARACTER VARYING(14) NOT NULL
            Integer.parseInt(fields[1]) + "," +     //mcid                        INTEGER NOT NULL
            Integer.parseInt(fields[2]) + "," +     //restrictionid               INTEGER NOT NULL
            Integer.parseInt(fields[3]) + "," +     //microorganismid             INTEGER NOT NULL
            Integer.parseInt(fields[4]) + "," +     //cotreatsetid                INTEGER NOT NULL
            Integer.parseInt(fields[5]) + "," +     //sequencenumber              SMALLINT NOT NULL
            "'" + fields[6].replace("'", "''") + "'" +  //description                 CHARACTER VARYING(80) NOT NULL
        " ); ";
    }

}
