package com.uhg.ihr.provider.api.model.profile;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.Set;

@Data
@Builder(toBuilder = true)
@AllArgsConstructor
@NoArgsConstructor
@JsonInclude(JsonInclude.Include.NON_NULL)
public class UserPermission {
    private UserProfileConstant.ROLE_CONTEXT context;
    private Set<UserGroup> groups;
    private Set<UserRole> roles;

    /**
     * Returns whether or not this UserPermission object does not have
     * any roles or groups associated with it.
     */
    @JsonIgnore
    public boolean isEmpty() {
        return (groups == null || groups.isEmpty())
                && (roles == null || roles.isEmpty());
    }
}
