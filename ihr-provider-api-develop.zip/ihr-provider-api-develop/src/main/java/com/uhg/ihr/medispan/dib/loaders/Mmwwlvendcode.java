package com.uhg.ihr.medispan.dib.loaders;

/**
*
*/
public class Mmwwlvendcode extends TableLoader {
    
	/**
	 *
	 */
    public Mmwwlvendcode() {
        super();
    }
    
    @Override
    public String getCreateQuery() {
        return
        "CREATE TABLE mmw_wl_vendcode " +
        "( " +
            "versioncode                 CHARACTER VARYING(10) NOT NULL, " +
            "wlid                        CHARACTER VARYING(6) NOT NULL, " +
            "vendversioncode             CHARACTER VARYING(3) NOT NULL, " +
            "textcode                    CHARACTER VARYING(6) NOT NULL, " +
            "graphiccode                 CHARACTER VARYING(6) NULL, " +
            "CONSTRAINT mmw_wl_vendcode_pkey PRIMARY KEY (versioncode, wlid, vendversioncode) " +
        ") " +
        "WITH (OIDS=TRUE); ";
    }
    
    @Override
    public String getInsertQuery(String line) {
        String[] fields = line.split("\\|");
        
        return "INSERT INTO mmw_wl_vendcode VALUES " +
        "( " +
            "'" + fields[0] + "'," +        //versioncode           CHARACTER VARYING(10) NOT NULL
            "'" + fields[1] + "'," +        //wlid                  CHARACTER VARYING(6) NOT NULL
            "'" + fields[2] + "'," +        //vendversioncode       CHARACTER VARYING(3) NOT NULL
            "'" + fields[3] + "'," +        //textcode              CHARACTER VARYING(6) NOT NULL
            (fields.length < 5 || fields[4].isEmpty() ? "NULL" : "'" + fields[4] + "'") +   //graphiccode           CHARACTER VARYING(6) NULL
        " ); "; 
    }

}
