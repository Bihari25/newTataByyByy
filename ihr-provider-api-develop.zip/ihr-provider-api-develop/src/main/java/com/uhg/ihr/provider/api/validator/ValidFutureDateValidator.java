package com.uhg.ihr.provider.api.validator;

import lombok.extern.slf4j.Slf4j;

import javax.validation.ConstraintValidator;
import javax.validation.ConstraintValidatorContext;
import java.text.ParseException;
import java.util.Date;

import static com.uhg.ihr.provider.api.util.AppUtils.DATE_FORMATTER;

@Slf4j
public class ValidFutureDateValidator implements ConstraintValidator<ValidFutureDate, String> {

    @Override
    public boolean isValid(final String value, final ConstraintValidatorContext constraintValidatorContext) {

        if (value == null || value.isBlank()) {
            //Validators should only validate whether a non null object is a valid or not. @Notnull/@NotBlank constraints should be
            //applied outside of validators to improve the utility of validators
            return true;
        }
        return ValidDateValidator.isValidFormat(value, constraintValidatorContext) &&
                isValidFuture(value);
    }

    public static boolean isValidFuture(String value) {
        Date date = null;
        try {
            date = DATE_FORMATTER.parse(value);
            if (date.before(new Date(System.currentTimeMillis()))) {
                log.info("Invalid date");
                date = null;
            }

        } catch (ParseException ex) {
            log.info("Invalid date");
        }
        return date != null;
    }
}