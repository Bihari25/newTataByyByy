package com.uhg.ihr.provider.api.model.inflator;


import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import org.apache.commons.lang3.builder.ToStringBuilder;

import java.io.Serializable;
import java.util.List;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
        "recordType",
        "adminInstructions",
        "medication",
        "dataSource",
        "daysSupply",
        "dosageForm",
        "dosageFrequency",
        "dosageQuantity",
        "expectedFillDate",
        "lastFillDate",
        "icueSeqId",
        "lastUpdateDate",
        "objectId",
        "presenceStateTerm",
        "refillAuthorizedNumber",
        "relatedCareTeam",
        "relatedConditions",
        "relatedDevices",
        "relatedServiceProviders",
        "sensitivityClasses",
        "refillCount",
        "medicationStartDate",
        "medicationStatus",
        "icueLastUpdateDate",
        "clinicallyRelevantDate"
})
@JsonIgnoreProperties(ignoreUnknown = true)
public class Medication implements Serializable {

    @JsonProperty("recordType")
    private String recordType;
    @JsonProperty("adminInstructions")
    private Object adminInstructions;
    @JsonProperty("medication")
    private Medication_ medication;
    @JsonProperty("dataSource")
    private List<String> dataSource = null;
    @JsonProperty("daysSupply")
    private long daysSupply;
    @JsonProperty("dosageForm")
//    private List<DosageForm> dosageForm;
    private DosageForm dosageForm;
    @JsonProperty("dosageFrequency")
    private Object dosageFrequency;
    @JsonProperty("dosageQuantity")
    private Object dosageQuantity;
    @JsonProperty("expectedFillDate")
    private Object expectedFillDate;
    @JsonProperty("lastFillDate")
    private String lastFillDate;
    @JsonProperty("icueSeqId")
    private Object icueSeqId;
    @JsonProperty("lastUpdateDate")
    private String lastUpdateDate;
    @JsonProperty("objectId")
    private long objectId;
    @JsonProperty("presenceStateTerm")
    private String presenceStateTerm;
    @JsonProperty("refillAuthorizedNumber")
    private double refillAuthorizedNumber;
    @JsonProperty("relatedCareTeam")
    private List<Object> relatedCareTeam = null;
    @JsonProperty("relatedConditions")
    private List<Long> relatedConditions = null;
    @JsonProperty("relatedDevices")
    private List<Object> relatedDevices = null;
    @JsonProperty("relatedServiceProviders")
    private List<Object> relatedServiceProviders = null;
    @JsonProperty("sensitivityClasses")
    private List<String> sensitivityClasses = null;
    @JsonProperty("refillCount")
    private String refillCount;
    @JsonProperty("medicationStartDate")
    private String medicationStartDate;
    @JsonProperty("medicationStatus")
    private Status medicationStatus;
    @JsonProperty("icueLastUpdateDate")
    private String icueLastUpdateDate;
    @JsonProperty("clinicallyRelevantDate")
    private String clinicallyRelevantDate;

    @JsonProperty("recordType")
    public String getRecordType() {
        return recordType;
    }

    @JsonProperty("recordType")
    public void setRecordType(String recordType) {
        this.recordType = recordType;
    }

    @JsonProperty("adminInstructions")
    public Object getAdminInstructions() {
        return adminInstructions;
    }

    @JsonProperty("adminInstructions")
    public void setAdminInstructions(Object adminInstructions) {
        this.adminInstructions = adminInstructions;
    }

    @JsonProperty("medication")
    public Medication_ getMedication() {
        return medication;
    }

    @JsonProperty("medication")
    public void setMedication(Medication_ medication) {
        this.medication = medication;
    }

    @JsonProperty("dataSource")
    public List<String> getDataSource() {
        return dataSource;
    }

    @JsonProperty("dataSource")
    public void setDataSource(List<String> dataSource) {
        this.dataSource = dataSource;
    }

    @JsonProperty("daysSupply")
    public long getDaysSupply() {
        return daysSupply;
    }

    @JsonProperty("daysSupply")
    public void setDaysSupply(long daysSupply) {
        this.daysSupply = daysSupply;
    }

    @JsonProperty("dosageForm")
    public DosageForm getDosageForm() {
        return dosageForm;
    }

    @JsonProperty("dosageForm")
    public void setDosageForm(DosageForm dosageForm) {
        this.dosageForm = dosageForm;
    }

    @JsonProperty("dosageFrequency")
    public Object getDosageFrequency() {
        return dosageFrequency;
    }

    @JsonProperty("dosageFrequency")
    public void setDosageFrequency(Object dosageFrequency) {
        this.dosageFrequency = dosageFrequency;
    }

    @JsonProperty("dosageQuantity")
    public Object getDosageQuantity() {
        return dosageQuantity;
    }

    @JsonProperty("dosageQuantity")
    public void setDosageQuantity(Object dosageQuantity) {
        this.dosageQuantity = dosageQuantity;
    }

    @JsonProperty("expectedFillDate")
    public Object getExpectedFillDate() {
        return expectedFillDate;
    }

    @JsonProperty("expectedFillDate")
    public void setExpectedFillDate(Object expectedFillDate) {
        this.expectedFillDate = expectedFillDate;
    }

    @JsonProperty("lastFillDate")
    public String getLastFillDate() {
        return lastFillDate;
    }

    @JsonProperty("lastFillDate")
    public void setLastFillDate(String lastFillDate) {
        this.lastFillDate = lastFillDate;
    }

    @JsonProperty("icueSeqId")
    public Object getIcueSeqId() {
        return icueSeqId;
    }

    @JsonProperty("icueSeqId")
    public void setIcueSeqId(Object icueSeqId) {
        this.icueSeqId = icueSeqId;
    }

    @JsonProperty("lastUpdateDate")
    public String getLastUpdateDate() {
        return lastUpdateDate;
    }

    @JsonProperty("lastUpdateDate")
    public void setLastUpdateDate(String lastUpdateDate) {
        this.lastUpdateDate = lastUpdateDate;
    }

    @JsonProperty("objectId")
    public long getObjectId() {
        return objectId;
    }

    @JsonProperty("objectId")
    public void setObjectId(long objectId) {
        this.objectId = objectId;
    }

    @JsonProperty("presenceStateTerm")
    public String getPresenceStateTerm() {
        return presenceStateTerm;
    }

    @JsonProperty("presenceStateTerm")
    public void setPresenceStateTerm(String presenceStateTerm) {
        this.presenceStateTerm = presenceStateTerm;
    }

    @JsonProperty("refillAuthorizedNumber")
    public double getRefillAuthorizedNumber() {
        return refillAuthorizedNumber;
    }

    @JsonProperty("refillAuthorizedNumber")
    public void setRefillAuthorizedNumber(double refillAuthorizedNumber) {
        this.refillAuthorizedNumber = refillAuthorizedNumber;
    }

    @JsonProperty("relatedCareTeam")
    public List<Object> getRelatedCareTeam() {
        return relatedCareTeam;
    }

    @JsonProperty("relatedCareTeam")
    public void setRelatedCareTeam(List<Object> relatedCareTeam) {
        this.relatedCareTeam = relatedCareTeam;
    }

    @JsonProperty("relatedConditions")
    public List<Long> getRelatedConditions() {
        return relatedConditions;
    }

    @JsonProperty("relatedConditions")
    public void setRelatedConditions(List<Long> relatedConditions) {
        this.relatedConditions = relatedConditions;
    }

    @JsonProperty("relatedDevices")
    public List<Object> getRelatedDevices() {
        return relatedDevices;
    }

    @JsonProperty("relatedDevices")
    public void setRelatedDevices(List<Object> relatedDevices) {
        this.relatedDevices = relatedDevices;
    }

    @JsonProperty("relatedServiceProviders")
    public List<Object> getRelatedServiceProviders() {
        return relatedServiceProviders;
    }

    @JsonProperty("relatedServiceProviders")
    public void setRelatedServiceProviders(List<Object> relatedServiceProviders) {
        this.relatedServiceProviders = relatedServiceProviders;
    }

    @JsonProperty("sensitivityClasses")
    public List<String> getSensitivityClasses() {
        return sensitivityClasses;
    }

    @JsonProperty("sensitivityClasses")
    public void setSensitivityClasses(List<String> sensitivityClasses) {
        this.sensitivityClasses = sensitivityClasses;
    }

    @JsonProperty("medicationStartDate")
    public String getMedicationStartDate() {
        return medicationStartDate;
    }

    @JsonProperty("medicationStartDate")
    public void setMedicationStartDate(String medicationStartDate) {
        this.medicationStartDate = medicationStartDate;
    }

    @JsonProperty("medicationStatus")
    public Status getMedicationStatus() {
        return medicationStatus;
    }

    @JsonProperty("medicationStatus")
    public void setMedicationStatus(Status medicationStatus) {
        this.medicationStatus = medicationStatus;
    }

    @JsonProperty("icueLastUpdateDate")
    public String getIcueLastUpdateDate() {
        return icueLastUpdateDate;
    }

    @JsonProperty("icueLastUpdateDate")
    public void setIcueLastUpdateDate(String icueLastUpdateDate) {
        this.icueLastUpdateDate = icueLastUpdateDate;
    }

    @JsonProperty("clinicallyRelevantDate")
    public String getClinicallyRelevantDate() {
        return clinicallyRelevantDate;
    }

    @JsonProperty("clinicallyRelevantDate")
    public void setClinicallyRelevantDate(String clinicallyRelevantDate) {
        this.clinicallyRelevantDate = clinicallyRelevantDate;
    }

    public String getRefillCount() {
        return refillCount;
    }

    public void setRefillCount(String refillCount) {
        this.refillCount = refillCount;
    }

    @Override
    public String toString() {
        return new ToStringBuilder(this).append("recordType", recordType).append("adminInstructions", adminInstructions).append("medication", medication).append("dataSource", dataSource).append("daysSupply", daysSupply).append("dosageForm", dosageForm).append("dosageFrequency", dosageFrequency).append("dosageQuantity", dosageQuantity).append("expectedFillDate", expectedFillDate).append("lastFillDate", lastFillDate).append("icueSeqId", icueSeqId).append("lastUpdateDate", lastUpdateDate).append("objectId", objectId).append("presenceStateTerm", presenceStateTerm).append("refillAuthorizedNumber", refillAuthorizedNumber)/*.append("relatedCareTeam", relatedCareTeam)*/.append("relatedConditions", relatedConditions).append("relatedDevices", relatedDevices)/*.append("relatedServiceProviders", relatedServiceProviders)*/.append("sensitivityClasses", sensitivityClasses).append("medicationStartDate", medicationStartDate).append("medicationStatus", medicationStatus).append("icueLastUpdateDate", icueLastUpdateDate).append("clinicallyRelevantDate", clinicallyRelevantDate).toString();
    }

}