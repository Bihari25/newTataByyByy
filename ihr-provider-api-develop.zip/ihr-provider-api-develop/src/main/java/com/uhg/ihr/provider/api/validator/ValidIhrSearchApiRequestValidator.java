package com.uhg.ihr.provider.api.validator;

import com.uhg.ihr.provider.api.model.FilterPair;
import com.uhg.ihr.provider.api.model.IhrSearchApiRequest;
import com.uhg.ihr.provider.api.model.MemberName;
import com.uhg.ihr.provider.api.model.SearcRequestMemberDemographic;
import com.uhg.ihr.provider.api.util.AppUtils;

import javax.validation.*;
import java.util.Set;

public class ValidIhrSearchApiRequestValidator implements ConstraintValidator<ValidIhrSearchApiRequest, IhrSearchApiRequest> {
    public static final String GLOBAL_IDENTIFIER = "global_actor_id";
    public static final String SUBSCRIBER_IDENTIFIER = "subscriber_id";

    @Override
    public boolean isValid(IhrSearchApiRequest request, ConstraintValidatorContext constraintValidatorContext) {
        Validator validator = Validation.buildDefaultValidatorFactory().getValidator();
        Set<ConstraintViolation<IhrSearchApiRequest>> violations = validator.validate(request);
        if (!violations.isEmpty()) {
            return false;
        }
        //We don't want to use the default message
        constraintValidatorContext.disableDefaultConstraintViolation();
        SearcRequestMemberDemographic criteria = request.getRequestCriteria().getMbrDemographics();
        if (request.getModifier().isNewPatient()) {
            return containsIdentifier(GLOBAL_IDENTIFIER, criteria.getIdentifiers(), constraintValidatorContext) ||
                    containsOneIdentifier(criteria.getIdentifiers(), constraintValidatorContext) &&
                            notBlankDob(criteria, constraintValidatorContext) &&
                            validName(criteria.getName(), constraintValidatorContext);
        } else {
            return (containsOneIdentifier(criteria.getIdentifiers(), constraintValidatorContext) ||
                    containsIdentifier(GLOBAL_IDENTIFIER, criteria.getIdentifiers(), constraintValidatorContext) ||
                    validName(criteria.getName(), constraintValidatorContext));
        }
    }

    private boolean containsOneIdentifier(Set<FilterPair> identifiers, ConstraintValidatorContext context) {
        if (identifiers != null && !identifiers.isEmpty()) {
            return true;
        }
        context.buildConstraintViolationWithTemplate("At least one identifier should be provided").addConstraintViolation();
        return false;
    }

    private boolean containsIdentifier(String identifierKey, Set<FilterPair> identifiers, ConstraintValidatorContext context) {
        if (identifiers != null) {
            for (FilterPair identifier : identifiers) {
                if (identifier.getKey().equalsIgnoreCase(identifierKey)) {
                    return true;
                }
            }
        }
        context.buildConstraintViolationWithTemplate("A valid " + identifierKey.toUpperCase() + " must be provided.").addConstraintViolation();
        return false;
    }

    private boolean validName(MemberName name, ConstraintValidatorContext constraintValidatorContext) {
        if (name == null ||
                name.getFirst() == null || name.getFirst().isBlank() ||
                name.getLast() == null || name.getLast().isBlank()) {
            constraintValidatorContext.buildConstraintViolationWithTemplate("A valid first and last name must be provided.").addConstraintViolation();
            return false;
        } else {
            return true;
        }
    }

    private boolean notBlankDob(SearcRequestMemberDemographic criteria, ConstraintValidatorContext constraintValidatorContext) {
        if (criteria.getDateOfBirth() == null || criteria.getDateOfBirth().isBlank()) {
            constraintValidatorContext.buildConstraintViolationWithTemplate("A valid date of birth must be provided in the form of " + AppUtils.DATE_FORMAT).addConstraintViolation();
            return false;
        }
        return true;
    }
}
