package com.uhg.ihr.provider.api.service.backend.b50.profile.model;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import com.uhg.ihr.provider.api.model.profile.UserProfileConstant;
import com.uhg.ihr.provider.api.service.backend.b50.model.B50UserDemographics;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

import java.io.Serializable;
import java.util.List;

@Data
@NoArgsConstructor
@JsonInclude(JsonInclude.Include.NON_EMPTY)
@JsonPropertyOrder(value = {
        "SOURCE",
        "ROLES",
        "USER_TYPE",
        "NAME_FIRST",
        "NAME_MIDDLE",
        "NAME_LAST",
        "DATE_OF_BIRTH",
        "GENDER",
        "GLOBAL_ACTOR_ID",
        "IDENTIFIERS",
        "PHONES",
        "ADDRESSES"
})
@EqualsAndHashCode(callSuper=false)
public class B50ProfileRegisterRequest extends B50UserDemographics implements Serializable {
    @JsonProperty("SOURCE")
    private UserProfileConstant.ROLE_CONTEXT source;
    @JsonProperty("ROLES")
    private List<String> role;
    @JsonProperty("USER_TYPE")
    private UserProfileConstant.USER_TYPE userType;
}
