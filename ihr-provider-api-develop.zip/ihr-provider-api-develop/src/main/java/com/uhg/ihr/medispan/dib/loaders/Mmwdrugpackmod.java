package com.uhg.ihr.medispan.dib.loaders;

/**
*
*/
public class Mmwdrugpackmod extends TableLoader {
    
	/**
	 *
	 */
    public Mmwdrugpackmod() {
        super();
    }
    
    @Override
    public String getCreateQuery() {
        return
        "CREATE TABLE mmw_drug_pack_mod " +
        "( " +
            "ppid                        CHARACTER VARYING(20) NOT NULL, " +
            "modid                       CHARACTER VARYING(6) NOT NULL, " +
            "typecode                    CHARACTER VARYING(2) NOT NULL, " +
            "catcode                     CHARACTER VARYING(4) NOT NULL, " +
            "description                 CHARACTER VARYING(25) NOT NULL, " +
            "CONSTRAINT mmw_drug_pack_mod_pkey PRIMARY KEY (ppid, modid) " +
        ") " +
        "WITH (OIDS=TRUE); ";
    }
    
    @Override
    public String getInsertQuery(String line) {
        String[] fields = line.split("\\|");
        
        return "INSERT INTO mmw_drug_pack_mod VALUES " +
        "( " +
            "'" + fields[0] + "'," +        //ppid              CHARACTER VARYING(20) NOT NULL
            "'" + fields[1] + "'," +        //modid             CHARACTER VARYING(6) NOT NULL
            "'" + fields[2] + "'," +        //typecode          CHARACTER VARYING(2) NOT NULL
            "'" + fields[3] + "'," +        //catcode           CHARACTER VARYING(4) NOT NULL
            "'" + fields[4].replace("'", "''") + "'" +         //description       CHARACTER VARYING(25) NOT NULL
        " ); ";
    }

}
