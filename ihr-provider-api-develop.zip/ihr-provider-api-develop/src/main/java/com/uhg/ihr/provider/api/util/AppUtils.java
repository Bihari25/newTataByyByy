package com.uhg.ihr.provider.api.util;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ObjectNode;
import com.uhg.ihr.provider.api.exception.IhrBadRequestException;
import com.uhg.ihr.provider.api.exception.UnhandledApiException;
import org.apache.commons.lang3.time.DateUtils;
import org.apache.commons.validator.routines.RegexValidator;

import javax.annotation.Nullable;
import java.io.File;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.util.*;

public class AppUtils {
    public static final String CRD_FILTER_CLASSES = "healthDevices,medications,immunizations,healthStatuses,procedureHistory,visitHistory";
    public static final String[] DATE_PATTERNS = {"yyyy-MM-dd", "yyyy-MM-dd HH:mm:ss", "yyyy-MM-dd'T'HH:mm:ss'Z'"};
    public static final String[] DATE_VALUE_REGEXS = {"[0-9]{4}\\-[0-9]{1,2}", "[0-9]{4}\\--[0-9]{1,2}",
            "[0-9]{4}\\/[0-9]{1,2}\\/[0-9]{1,2}", "[0-9]{4}\\-[0-9]{1,2}\\/[0-9]{1,2}", "[0-9]{4}\\/[0-9]{1,2}\\-[0-9]{1,2}", "[0-9]{4}\\-[0-9]{1,2}\\-[0-9]{1,2}",
            "[0-9]{4}\\-[0-9]{1,2}\\-[0-9]{1,2} [0-9]{1,2}", "[0-9]{4}\\-[0-9]{1,2}\\-[0-9]{1,2} [0-9]{1,2}\\:[0-9]{1,2}",
            "[0-9]{4}\\-[0-9]{1,2}\\-[0-9]{1,2} [0-9]{1,2}\\::[0-9]{1,2}", "[0-9]{4}\\-[0-9]{1,2}\\-[0-9]{1,2} [0-9]{1,2}\\:[0-9]{1,2}\\:[0-9]{1,2}"};

    public static final String CR_DATE_EX_MESSAGE = "Date parsing issues for clinical relevant date: {}";
    public static final String CR_START_DATE_EX_MESSAGE = "Date parsing issues for clinical relevant start date: ";
    public static final String CR_END_DATE_EX_MESSAGE = "Date parsing issues for clinical relevant end date: ";

    public static final String CLINICALLY_RELEVANT_DATE = "clinicallyRelevantDate";
    public static final String CLINICALLY_RELEVANT_START_DATE = "clinicallyRelevantStartDate";
    public static final String CLINICALLY_RELEVANT_END_DATE = "clinicallyRelevantEndDate";
    public static final String PRESENCE_STATE = "PresenceState";
    public static final String PRESENCE_STATE_TERM = "presenceStateTerm";
    public static final String SUBSCRIBER_ID_KEY = "subscriberId";
    public static final String SUBSCRIBER_PAD_ID_KEY = "subscriberPadId";

    public static final String HELIUM_MEMBER = "uhgrd.helium";
    public static final String X_CONSUMER_HEADER = "X-Consumer-Username";
    public static final String X_COLLECTION_HEADER = "X-Collection";
    public static final String B_50_COLLECTION = "b50";
    public static final String IHR2_COLLECTION = "ihr2";
    public static final String COMPUTED_COLLECTION = "computedCollection";

    public static final String DATE_FORMAT = "yyyy-MM-dd";
    public static final SimpleDateFormat DATE_FORMATTER = new SimpleDateFormat(DATE_FORMAT);

    /**
     * Method to parse input date string to date object.
     *
     * @param filterDate
     * @param exceptionMessage
     * @return Date
     */
    public static Date parseInputDate(String filterDate, String exceptionMessage) throws IhrBadRequestException {
        Date date;

        try {
            date = DateUtils.parseDateStrictly(filterDate, AppUtils.DATE_PATTERNS);
        } catch (Exception ex) {
            throw new IhrBadRequestException(exceptionMessage.concat(ex.getMessage()));
        }

        return date;
    }

    /**
     * Method to validate the input value is tex or date.
     *
     * @param inputValue
     * @return boolean
     */
    public static boolean isDateValue(String inputValue) {
        RegexValidator validator = new RegexValidator(AppUtils.DATE_VALUE_REGEXS, false);
        boolean isDate = validator.isValid(inputValue);
        return isDate;
    }

    /**
     * Method to get today date in yyyy-MM-dd.
     *
     * @return String
     */
    public static Date todayDate() {
        return parseInputDate(LocalDate.now().toString(), CR_END_DATE_EX_MESSAGE);
    }


    /**
     * Method to validate given date with in given start & end date.
     *
     * @param startDate
     * @param endDate
     * @param inputDate
     * @return boolean
     */
    public static boolean isDateInBetween(final Date startDate, final Date endDate, final Date inputDate) {
        return !(inputDate.before(startDate) || inputDate.after(endDate));
    }

    /**
     * Looks for a file at the given relative/absolute path, if not found then another attempt will be made to look in
     * the filepath's absolute/relative path respectively or return null if filepath is blank or doesn't exist in either.
     * @param filepath The path pointing to a file
     * @return A file pointing to an existing file or null if the file doesn't exist or filepath is empty
     */
    public static File findRelativeOrAbsoluteFilePath(String filepath) {
        if (!filepath.isBlank()) {
            File file = new File(filepath);
            if (file.exists()) {
                return file;
            } else {
                file = new File(filepath.charAt(0) == '/' ? filepath.substring(1) : "/" + filepath);
                if (file.exists()) {
                    return file;
                }
            }
        }
        //Catch all that returns null if filepath string is blank/null or file doesn't exist
        return null;
    }

    @Nullable
    public static String getTextOrNull(JsonNode checkNode) {
        return checkNode != null ? checkNode.asText() : null;
    }

    /**
     * Combines two lists without duplicates, the primaryList data being supplemented by the secondaryList data which is
     * saved to a new List object.
     * @param primaryList The list with data selection priority
     * @param secondaryList The list with supplemental data
     * @param <T> The type of list
     * @return A new List with the combined data
     */
    public static <T> List<T> combineLists(List<T> primaryList, List<T> secondaryList) {
        if (primaryList == null || primaryList.isEmpty()) {
            return secondaryList == null ? new ArrayList<>() : List.copyOf(secondaryList);
        } else if (secondaryList == null || secondaryList.isEmpty()) {
            return List.copyOf(primaryList);
        } else {
            Set<T> combinedList = new HashSet<>(primaryList);
            combinedList.addAll(secondaryList);
            return List.copyOf(combinedList);
        }
    }

    /**
     * Combines two Maps without duplicates, the primaryMap data being supplemented by the secondaryMap data which is
     * saved to a new Map object.
     * @param primaryMap The Map with data selection priority
     * @param secondaryMap The Map with supplemental data
     * @param <T> The type of Map
     * @return A new Map with the combined data
     */
    public static <T,V> Map<T,V> combineMaps(Map<T,V> primaryMap, Map<T,V> secondaryMap) {
        if (primaryMap == null || primaryMap.isEmpty()) {
            return secondaryMap == null ? new HashMap<>() : Map.copyOf(secondaryMap);
        } else if (secondaryMap == null || secondaryMap.isEmpty()) {
            return primaryMap;
        } else {
            Map<T,V> combinedMap = new HashMap<>(secondaryMap);
            combinedMap.putAll(primaryMap);
            return combinedMap;
        }
    }

    public static JsonNode buildCacheKey(String cacheName, String providerId, Object request) {
        ObjectMapper mapper = new ObjectMapper();
        String envStr = System.getenv("ENVIRONMENT");
        if (envStr == null || envStr.isBlank()) {
            throw new UnhandledApiException("No environment is set and it is required for cache keys");
        }
        try {
            JsonNode requestNode = mapper.readTree(mapper.writeValueAsString(request));
            ObjectNode keyRootNode = mapper.createObjectNode();
            keyRootNode.put("providerId", providerId);
            keyRootNode.put("cache", envStr + "-" + cacheName);
            keyRootNode.set("request", requestNode);
            return keyRootNode;
        } catch (JsonProcessingException e) {
            throw new UnhandledApiException("Failed to convert request to ObjectNode", e);
        }
    }
}
