package com.uhg.ihr.provider.api.service.backend.senzing;

import com.google.common.collect.ImmutableMap;
import com.google.common.collect.Iterables;
import com.uhg.ihr.provider.api.exception.*;
import com.uhg.ihr.provider.api.model.*;
import com.uhg.ihr.provider.api.model.senzing.Name;
import com.uhg.ihr.provider.api.model.senzing.Response;
import com.uhg.ihr.provider.api.model.senzing.SearchResult;
import com.uhg.ihr.provider.api.service.backend.SearchAdapterInterface;
import com.uhg.ihr.provider.api.service.backend.b50.search.model.Identifier;
import io.micronaut.context.annotation.Secondary;
import io.micronaut.core.util.CollectionUtils;
import io.micronaut.http.client.exceptions.HttpClientResponseException;
import io.reactivex.Maybe;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;

import javax.inject.Inject;
import javax.inject.Singleton;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.stream.Collectors;

/**
 * SenzingAdapter class used to consume senzing api call to get the ihr id information.
 *
 * @author ihr extract engineering team.
 * @CopyRight (C) All rights reserved to UHG Inc. It's Illegal to reproduce this code.
 */
@Slf4j
@Secondary
@Singleton
public class SenzingAdapter implements SearchAdapterInterface {
    private static final String SSN_KEY = "SSN";
    private static final String[] MATCHKEY_REF_LOOKUP = {"+DOB", "+NAME", "+PNAME"};
    private static final SimpleDateFormat DATE_FORMAT = new SimpleDateFormat("yyyy-MM-dd");
    private static final boolean ALLOW_EMPTY = false;

    @Inject
    private SenzingClient client;

    @Inject
    private SenzingTokenHelper tokenHelper;

    /**
     * Method to fetch senzing results from b50 senzing end point.
     *
     * @param headers
     * @return Maybe
     */
    public Maybe<PatientDemographicsResponse> searchForPatients(IhrSearchApiRequest apiDto, ProviderApiHeaders headers) {
        /* Collect and hold the collection name and api consumer to compute chid keys. */
        SearchRequest searchRequest = SearchRequestTransformer.buildSearchRequest(apiDto);
        return callSenzingApi(headers.getCorrelationId(), apiDto.getActorId(), searchRequest)
                .map(this::buildDemograhpicResponse)
                .defaultIfEmpty(buildDemograhpicResponse(new ArrayList<>()));
    }

    public Maybe<PatientDemographics> getPatientDemographics(String patientChid, String providerChid, ProviderApiHeaders headers) {
        SearchRequest searchRequest = SearchRequest.builder().GLOBAL_ACTOR_ID(patientChid).build();
        return callSenzingApi(headers.getCorrelationId(), providerChid, searchRequest)
                .map(results -> {
                            return results
                                    .stream()
                                    .map(SenzingAdapter::parseResultIntoPatientDemographic)
                                    .collect(Collectors.toList())
                                    .get(0);
                        }
                );
    }

    public Maybe<List<SearchResult>> callSenzingApi(String correlationId, String providerChid, SearchRequest searchRequest) {
        String token = tokenHelper.generateToken();
        return client.fetchEntities(token, correlationId, searchRequest)
                .doOnError(ex -> {
                            if (ex instanceof HttpClientResponseException) {
                                HttpClientResponseException hcre = (HttpClientResponseException) ex;
                                log.error("error with the b50 senzing service. status code: {}, message: {}", hcre.getStatus(), ex.getMessage());
                            } else {
                                log.error("could not hit the b50 senzing service {}", ex.getMessage());
                            }
                        }
                )
                .map(response -> validateSenzingResponse(response, ALLOW_EMPTY))
                .onErrorResumeNext(Maybe.empty());
    }

    public PatientDemographicsResponse buildDemograhpicResponse(List<SearchResult> results) {
        List<PatientDemographics> parsed = results
                .stream()
                .map(SenzingAdapter::parseResultIntoPatientDemographic)
                .collect(Collectors.toList());
        PatientDemographicsResponse fullResponse = new PatientDemographicsResponse();
        fullResponse.setPatientDemographics(parsed);
        return fullResponse;
    }

    /**
     * Method to search and filter for ihrId from api response.
     *
     * @param searchResults
     * @param searchRequest
     * @param correlationId
     * @return String
     */
    @SuppressWarnings("unchecked")
    public String searchIhrId(final List<SearchResult> searchResults, final SearchRequest searchRequest,
                              final String correlationId) {

        /* Navigate through JSON response tree to cherry pick the values.*/

        /* Validate if filtered IhrIds are available at indicator level = 1 or else indicator level = 2 as a fallback. */
        ImmutableMap<String, List<String>> filteredResults = filterResults(searchResults, searchRequest, SenzingLookup.INDICATOR_LEVEL_1, false);
        if (filteredResults.get(SenzingLookup.FILTERED_IHR_IDS).size() == 0) {
            filteredResults = filterResults(searchResults, searchRequest, SenzingLookup.INDICATOR_LEVEL_2, true);
        }

        /* Log all search results information.*/
        log.info("optum-cid-ext '{}' senzing call found possible {} identifiers: {}",
                correlationId, CollectionUtils.isNotEmpty(searchResults) ? searchResults.size() : 0, filteredResults.get(SenzingLookup.LOG_RESULTS));

        return getIdFromList(filteredResults.get(SenzingLookup.FILTERED_IHR_IDS));
    }


    /**
     * Method get ihr id from list.
     *
     * @param ihrIds
     * @return String
     */
    public String getIdFromList(List<String> ihrIds) {
        if (CollectionUtils.isEmpty(ihrIds)) {
            throw new IhrNotFoundException("Unable to find ihr identifier (IhrId) from senzing response for given member");
        }

        if (ihrIds.size() > 1) {
            throw new IhrNotFoundException("Found multiple ihr identifiers: " + ihrIds);
        }

        return Iterables.getOnlyElement(ihrIds);
    }

    /**
     * Method to get all logs from results.
     *
     * @param result
     * @param chidKey
     * @return String
     */
    @SuppressWarnings("unchecked")
    public static String getLogDataFromResult(SearchResult result, String chidKey) {
        try {
            result.getMatchLevel();
            List<String> identifierData = result.getIdentifierData();
            String chid = getValueFromIdentifiers(identifierData, chidKey);
            return String.format("%s:%s:%s",
                    chid,
                    result.getMatchLevel(),
                    result.getMatchKey());
        } catch (Exception e) {
            log.warn("unable to parse log entry for senzing response");
            return "unknown";
        }
    }


    /**
     * Method to filter results from senzing response for IhrIds and log statements.
     *
     * @param searchResults
     * @param searchRequest
     * @param indicatorLevel
     * @param isFallBack
     * @return ImmutableMap
     */
    private static ImmutableMap<String, List<String>> filterResults(List<SearchResult> searchResults, SearchRequest searchRequest,
                                                                    int indicatorLevel, boolean isFallBack) {

        List<String> foundIhrIds = new ArrayList<>();
        List<String> logResults = new ArrayList<>();

        /* Compute which chid key to use to look data in B50 Vs existing senzing response.*/
        String chidKey = SenzingLookup.B50_CHID;//computeChidKey(searchRequest.getCollectionName());

        /* Iterate over each search results data to get match level indicator and owner chid value.
         log : ACTCHID, MatchLevel, matchkey (matchKey -> +PNAME+DOB+SUBSCRIBER_ID) */
        for (SearchResult resultData : searchResults) {

            /* Cherry pick and validate match level indicator. */
            int matchLevelIndicator = resultData.getMatchLevel();
            if (matchLevelIndicator == indicatorLevel) {
                /* Further filter for owner chid value which will be iHr id.*/
                String chid = null;
                List<String> identifierData = resultData.getIdentifierData();

                /* Keep track fall back for match level 2 and validate for SSN matches with request searchId and grab the chid (ihrId).*/
                if (isFallBack) {
                    String senzingSsnValue = getValueFromIdentifiers(identifierData, SSN_KEY);
                    String requestedSsnValue = computeSsnPadding(searchRequest.getMemberId());
                    if (StringUtils.isNotBlank(senzingSsnValue) && StringUtils.equals(requestedSsnValue, senzingSsnValue)) {

                        /* Get the match key value and validate against required match key values. */
                        String matchKey = resultData.getMatchKey();
                        boolean isMatchKeyMatched = validateMatchKey(matchKey);
                        if (isMatchKeyMatched) {
                            chid = getValueFromIdentifiers(identifierData, chidKey);
                            log.info("SenzingClient match level indicator: {}, after matching in fallback for ihrId: {}", indicatorLevel, chid);
                        }
                    }
                } else {
                    chid = getValueFromIdentifiers(identifierData, chidKey);
                }

                /* Collect searched ihrIds.*/
                if (StringUtils.isNotBlank(chid)) {
                    foundIhrIds.add(chid);
                }
            }

            logResults.add(getLogDataFromResult(resultData, chidKey));
        }

        /* Hold the result filtered IhrIds and Log results. */
        ImmutableMap<String, List<String>> senzingFilterResults = ImmutableMap.of(SenzingLookup.LOG_RESULTS, logResults, SenzingLookup.FILTERED_IHR_IDS, foundIhrIds);
        return senzingFilterResults;
    }

    /**
     * Method to get chid from identifiers.
     *
     * @param identifierData
     * @return String
     */
    public static String getValueFromIdentifiers(List<String> identifierData, String searchKey) {
        String chidValue = CollectionUtils.isNotEmpty(identifierData) ?
                StringUtils.substringAfter(identifierData.stream()
                        .filter(data -> data.startsWith(searchKey))
                        .findFirst().orElse(""), ":")
                        .trim() : "";
        return chidValue;
    }


    /**
     * Method to compute and add 0 padding's as leading zeros.
     *
     * @param requestedSsn
     * @return String
     */
    public static String computeSsnPadding(String requestedSsn) {
        String inputSsnValue = null;
        if (StringUtils.isNotBlank(requestedSsn)) {
            inputSsnValue = (requestedSsn.length() == 7 || requestedSsn.length() == 8) ? StringUtils.leftPad(requestedSsn, 9, "0") : requestedSsn;
        }
        return inputSsnValue;
    }

    /**
     * Method to validate match key with match key reference lookup.
     *
     * @param matchKey
     * @return boolean
     */
    public static boolean validateMatchKey(String matchKey) {
        boolean isMatchKeyMatched = matchKey.contains(MATCHKEY_REF_LOOKUP[0]) &&
                (matchKey.contains(MATCHKEY_REF_LOOKUP[1]) || matchKey.contains(MATCHKEY_REF_LOOKUP[2]));

        return isMatchKeyMatched;
    }

    /**
     * Method to validate senzing response.
     *
     * @param senzingResponse
     * @return List<LinkedHashMap < String, Object>>
     */
    @SuppressWarnings("unchecked")
    public static List<SearchResult> validateSenzingResponse(Response senzingResponse, boolean allowEmpty) {
        /* Validate senzing response is empty or not. */
        if (senzingResponse != null && !senzingResponse.isEmpty()) {
            List<SearchResult> searchResults = senzingResponse.getData().getSearchResults();

            /* If search results in senzing response is empty throw 404 exception. */
            if (!allowEmpty && CollectionUtils.isEmpty(searchResults)) {
                throw new IhrNotFoundException("Unable to find ihr identifier (IhrId) because senzing response search results are empty");
            } else {
                return searchResults == null ? Collections.emptyList() : searchResults;
            }
        } else if (allowEmpty) {
            return Collections.emptyList();
        } else {
            throw new IhrNotFoundException("Unable to find ihr identifier (IhrId) because senzing response data is empty");
        }

    }

    public static PatientDemographics parseResultIntoPatientDemographic(SearchResult result) {
        String chid = getValueFromIdentifiers(result.getIdentifierData(), SenzingLookup.B50_CHID);
        MemberName memberName = getMemberName(result);
        String gender = getGender(result);
        List<MemberAddress> addresses = getMemberAddresses(result);
        List<Id> identifiers = getMemberIdentifiers(result);
        PatientDemographics patient = new PatientDemographics(chid, memberName, null, null, null, gender, addresses, Collections.emptyList(), identifiers, new ArrayList<>());
        try {
            addLifeDates(result, patient);
        } catch (DobException e) {
            log.error(e.getMessage());
        }
        return patient;
    }

    public static MemberName getMemberName(SearchResult result) {
        String entityName = result.getEntityName();
        ArrayList<List<Name>> names = new ArrayList<>();
        result.getRecords().forEach(record -> names.add(record.getOriginalSourceData().getNames()));

        //Match record names against entity name to find exact match
        for (List<Name> recordNames : names) {
            for (Name name : recordNames) {
                StringBuilder builder = new StringBuilder();
                //Build the name
                builder.append(name.getFirstName());
                if (name.getMiddleName() != null && !name.getMiddleName().isBlank()) {
                    builder.append(" ").append(name.getMiddleName());
                }
                if (name.getLastName() != null && !name.getLastName().isBlank()) {
                    builder.append(" ").append(name.getLastName());
                }

                if (entityName.equalsIgnoreCase(builder.toString())) {
                    return new MemberName(name.getFirstName(), name.getMiddleName(), name.getLastName());
                }
            }
        }

        //Best effort name parsing when no record names match entity name
        String[] nameParts = entityName.split(" ");
        switch (nameParts.length) {
            case 1: {
                return new MemberName(nameParts[0], null, null);
            }
            case 2: {
                return new MemberName(nameParts[0], null, nameParts[1]);
            }
            case 3: {
                return new MemberName(nameParts[0], nameParts[1], nameParts[2]);
            }
            //Assumes last name is the biggest
            default: {
                StringBuilder lastNameBuilder = new StringBuilder();
                lastNameBuilder.append(nameParts[2]);
                for (int i = 3; i < nameParts.length; ++i) {
                    lastNameBuilder.append(" ").append(nameParts[i]);
                }
                return new MemberName(nameParts[0], nameParts[1], lastNameBuilder.toString());
            }
        }
    }

    public static void addLifeDates(SearchResult result, PatientDemographics demographics) {
        try {
            List<String> dobs = new ArrayList<>();
            //Collect all dobs if there's no unique date of death prefix
            result.getAttributeData().forEach(data -> {
                if (data.matches("^DOB.*$")) {
                    dobs.add(data.substring(data.indexOf(":") + 1).trim());
                }
            });
            //Return empty string, single dob, or figure out which dob is younger
            if (dobs.size() > 2) {
                throw new TooManyBirthDates("Too many birthdates in data for patient");
            } else if (dobs.size() == 2) {
                long time1 = DATE_FORMAT.parse(dobs.get(0)).getTime();
                long time2 = DATE_FORMAT.parse(dobs.get(1)).getTime();
                if (time1 > time2) {
                    demographics.setDateOfDeath(dobs.get(0));
                    demographics.setDateOfBirth(dobs.get(1));
                } else {
                    demographics.setDateOfBirth(dobs.get(0));
                    demographics.setDateOfDeath(dobs.get(1));
                }
            } else if (dobs.size() == 1) {
                demographics.setDateOfBirth(dobs.get(0));
            } else {
                throw new NoBirthDateException("No birthdate exists for patient");
            }

            demographics.setAge(demographics.getDateOfDeath() == null ?
                    AgeUtil.calculateAge(demographics.getDateOfBirth()) :
                    AgeUtil.calculateAge(demographics.getDateOfBirth(), demographics.getDateOfDeath()));
        } catch (ParseException e) {
            throw new AgeParseException("Failed to parse age due to error: " + e.getMessage());
        }
    }

    public static String getGender(SearchResult result) {
        List<String> dobs = new ArrayList<>();
        //Collect all dobs if there's no unique date of death prefix
        for (String data : result.getAttributeData()) {
            if (data.matches("^GENDER.*$")) {
                return data.substring(data.indexOf(":") + 1).trim();
            }
        }
        //Return empty string if no gender set
        return "";
    }

    public static List<MemberAddress> getMemberAddresses(SearchResult result) {
        List<MemberAddress> addresses = new ArrayList<>();
        result.getRecords().forEach(
                record -> {
                    record.getOriginalSourceData().getAddresses().forEach(
                            address -> addresses.add(new MemberAddress(
                                    address.getADDRLINE1(),
                                    address.getaDDRLINE2(),
                                    address.getADDRCITY(),
                                    address.getADDRSTATE(),
                                    address.getADDRPOSTALCODE(),
                                    address.getADDRCOUNTRY(),
                                    null)));
                });
        return addresses;
    }

    public static List<Id> getMemberIdentifiers(SearchResult result) {
        List<Id> identifiers = new ArrayList<>();
        result.getIdentifierData().forEach(
                id -> {
                    String prefix = id.substring(0, id.indexOf(":")).trim();
                    try {
                        Identifier idType = Identifier.valueOf(prefix);
                        String idNum = id.substring(id.indexOf(":") + 1).trim();
                        identifiers.add(new Id(idNum, idType));
                    } catch (IllegalArgumentException e) {
                        log.debug("No IdType ENUM for identifier prefix '" + prefix + "'");
                    }
                });
        return identifiers;
    }

    //TODO: Implement member relationship parsing
    public static List<String> getMemberRelationships(SearchResult result) {
        return new ArrayList<>();
    }
}


