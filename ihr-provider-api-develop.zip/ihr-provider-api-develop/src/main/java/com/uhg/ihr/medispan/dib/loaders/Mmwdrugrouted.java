package com.uhg.ihr.medispan.dib.loaders;

/**
*
*/
public class Mmwdrugrouted extends TableLoader {
    
	/**
	 *
	 */
    public Mmwdrugrouted() {
        super();
    }
    
    @Override
    public String getCreateQuery() {
        return
        "CREATE TABLE mmw_drug_routed " +
        "( " +
            "rpid                        INTEGER NOT NULL, " +
            "descdisplay                 CHARACTER VARYING(65) NOT NULL, " +
            "descsearch                  CHARACTER VARYING(65) NOT NULL, " +
            "descphonetic                CHARACTER VARYING(65) NOT NULL, " +
            "rtid                        INTEGER NOT NULL, " +
            "pnid                        INTEGER NOT NULL, " +
            "ddidunique                  INTEGER NULL, " +
            "nametypecode                CHARACTER VARYING(1) NOT NULL, " +
            "rxotccode                   CHARACTER VARYING(1) NULL, " +
            "actcode                     CHARACTER VARYING(1) NULL, " +
            "singleingrind               SMALLINT NOT NULL, " +
            "meddevind                   SMALLINT NOT NULL, " +
            "haspackdrugind              SMALLINT NOT NULL, " +
            "haseqvpackdrugind           SMALLINT NOT NULL, " +
            "hasgpiind                   SMALLINT NOT NULL, " +
            "haskdcind                   SMALLINT NOT NULL, " +
            "screencleandfa          smallINT NULL, " +
            "screencleandi           smallINT NULL, " +
            "CONSTRAINT mmw_drug_routed_pkey PRIMARY KEY (rpid) " +
        ") " +
        "WITH (OIDS=TRUE); ";
    }
    
    @Override
    public String getInsertQuery(String line) {
        String[] fields = line.split("\\|");
        
        return "INSERT INTO mmw_drug_routed VALUES " +
        "( " +
            Integer.parseInt(fields[0]) + "," +     //rpid                        INTEGER NOT NULL
            "'" + fields[1].replace("'", "''") + "'," +                //descdisplay                 CHARACTER VARYING(65) NOT NULL
            "'" + fields[2].replace("'", "''") + "'," +                //descsearch                  CHARACTER VARYING(65) NOT NULL
            "'" + fields[3].replace("'", "''") + "'," +                //descphonetic                CHARACTER VARYING(65) NOT NULL
            Integer.parseInt(fields[4]) + "," +     //rtid                        INTEGER NOT NULL
            Integer.parseInt(fields[5]) + "," +     //pnid                        INTEGER NOT NULL
            (fields[6].isEmpty() ? "NULL" : Integer.parseInt(fields[6])) + "," +     //ddidunique                  INTEGER NULL
            "'" + fields[7] + "'," +                //nametypecode                CHARACTER VARYING(1) NOT NULL
            (fields[8].isEmpty() ? "NULL" : "'" + fields[8] + "'") + "," +  //rxotccode                   CHARACTER VARYING(1) NULL
            (fields[9].isEmpty() ? "NULL" : "'" + fields[9] + "'") + "," +  //actcode                     CHARACTER VARYING(1) NULL
            Integer.parseInt(fields[10]) + "," +    //singleingrind               SMALLINT NOT NULL
            Integer.parseInt(fields[11]) + "," +    //meddevind                   SMALLINT NOT NULL
            Integer.parseInt(fields[12]) + "," +    //haspackdrugind              SMALLINT NOT NULL
            Integer.parseInt(fields[13]) + "," +    //haseqvpackdrugind           SMALLINT NOT NULL
            Integer.parseInt(fields[14]) + "," +    //hasgpiind                   SMALLINT NOT NULL
            Integer.parseInt(fields[15]) + "," +    //haskdcind                   SMALLINT NOT NULL
            (fields.length < 17 || fields[16].isEmpty() ? "NULL" : Integer.parseInt(fields[16])) + "," +    //screencleandfa              smallINT NULL
            (fields.length < 18 || fields[17].isEmpty() ? "NULL" : Integer.parseInt(fields[17])) +          //screencleandi               smallINT NULL
        " ); ";
    }

}
