package com.uhg.ihr.provider.api.model;

import com.uhg.ihr.provider.api.filter.DataFilter;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;
import java.util.Set;

/**
 * MongoDataRequest class used as a request object for mongodb service.
 *
 * @author ihr extract engineering team.
 * @CopyRight (C) All rights reserved to UHG Inc. It's Illegal to reproduce this code.
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class MongoDataRequest {

    private String ihrId;
    private int apiVersion;
    private Set<RecordType> dataClasses;
    private List<DataFilter> dataFilters;
    private String collection2Route;
}
