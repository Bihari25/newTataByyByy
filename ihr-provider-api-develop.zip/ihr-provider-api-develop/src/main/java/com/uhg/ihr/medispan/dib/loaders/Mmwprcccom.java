package com.uhg.ihr.medispan.dib.loaders;

/**
*
*/
public class Mmwprcccom extends TableLoader {
    
	/**
	 *
	 */
    public Mmwprcccom() {
        super();
    }
    
    @Override
    public String getCreateQuery() {
        return
        "CREATE TABLE mmw_prcc_com " +
        "( " +
            "gpi                         CHARACTER VARYING(14) NOT NULL, " +
            "mcid                        INTEGER NOT NULL, " +
            "restrictionid               INTEGER NOT NULL, " +
            "sequencenumber              SMALLINT NOT NULL, " +
            "textid                      integer NOT NULL, " +
            "CONSTRAINT mmw_prcc_com_pkey PRIMARY KEY (gpi, mcid, restrictionid, sequencenumber) " +
        ") " +
        "WITH (OIDS=TRUE); ";
    }
    
    @Override
    public String getInsertQuery(String line) {
        String[] fields = line.split("\\|");
        
        return "INSERT INTO mmw_prcc_com VALUES " +
        "( " +
            "'" + fields[0] + "'," +                //gpi                         CHARACTER VARYING(14) NOT NULL
            Integer.parseInt(fields[1]) + "," +     //mcid                        INTEGER NOT NULL
            Integer.parseInt(fields[2]) + "," +     //restrictionid               INTEGER NOT NULL
            Integer.parseInt(fields[3]) + "," +     //sequencenumber              SMALLINT NOT NULL
            Integer.parseInt(fields[4]) +           //textid                      integer NOT NULL
        " ); ";
    }

}
