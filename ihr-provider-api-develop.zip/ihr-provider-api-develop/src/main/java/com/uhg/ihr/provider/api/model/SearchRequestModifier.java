package com.uhg.ihr.provider.api.model;

import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder(toBuilder = true)
@AllArgsConstructor
@NoArgsConstructor
//@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({"newPatient"})
public class SearchRequestModifier {
    @Builder.Default
    private boolean newPatient = false;
}
