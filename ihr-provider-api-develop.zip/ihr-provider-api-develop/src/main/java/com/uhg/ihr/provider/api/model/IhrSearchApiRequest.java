package com.uhg.ihr.provider.api.model;

import com.fasterxml.jackson.annotation.JsonAlias;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

import javax.validation.Valid;
import javax.validation.constraints.NotNull;

@Data
@NoArgsConstructor
@AllArgsConstructor
@EqualsAndHashCode(callSuper = false)
public class IhrSearchApiRequest extends IhrApiWithActorRequest {

    @JsonProperty
    private SearchRequestModifier modifier = new SearchRequestModifier();

    /**
     * Used to handle 1.0 = mbrID and 2.0+ = mbrId request.
     */
    @JsonAlias({"criteria", "criteria"})
    @NotNull(message = "The member Criteria record may not be null.")
    @Valid
    private SearchRequestCriteria requestCriteria;
}