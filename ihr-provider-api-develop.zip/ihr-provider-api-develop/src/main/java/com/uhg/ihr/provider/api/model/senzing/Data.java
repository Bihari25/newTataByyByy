package com.uhg.ihr.provider.api.model.senzing;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import org.apache.commons.lang3.builder.ToStringBuilder;

import java.io.Serializable;
import java.util.List;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
        "searchResults"
})
@JsonIgnoreProperties(ignoreUnknown = true)
public class Data implements Serializable {

    @JsonProperty("searchResults")
    private List<SearchResult> searchResults = null;

    @JsonProperty("searchResults")
    public List<SearchResult> getSearchResults() {
        return searchResults;
    }

    @JsonProperty("searchResults")
    public void setSearchResults(List<SearchResult> searchResults) {
        this.searchResults = searchResults;
    }

    public boolean isEmpty() {
        return searchResults == null;
    }

    @Override
    public String toString() {
        return new ToStringBuilder(this).append("searchResults", searchResults).toString();
    }

}