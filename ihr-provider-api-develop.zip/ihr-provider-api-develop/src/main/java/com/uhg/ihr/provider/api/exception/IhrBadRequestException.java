package com.uhg.ihr.provider.api.exception;

import lombok.RequiredArgsConstructor;

@RequiredArgsConstructor
public class IhrBadRequestException extends RuntimeException {
    public IhrBadRequestException(String message) {
        super(message);
    }
}