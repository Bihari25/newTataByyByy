package com.uhg.ihr.medispan.dib.loaders;

/**
*
*/
public class Mmwlibdisclaimer extends TableLoader {
    
	/**
	 *
	 */
    public Mmwlibdisclaimer() {
        super();
    }
    
    @Override
    public String getCreateQuery() {
        return
        "CREATE TABLE mmw_lib_disclaimer " +
        "( " +
            "versioncode                 CHARACTER VARYING(10) NOT NULL, " +
            "categorycode                CHARACTER VARYING(10) NOT NULL, " +
            "sequencenumber              SMALLINT NOT NULL, " +
            "sectioncode                 CHARACTER VARYING(1) NOT NULL, " +
            "formatcode                  CHARACTER VARYING(1) NOT NULL, " +
            "linetext                    CHARACTER VARYING(255) NOT NULL, " +
            "CONSTRAINT mmw_lib_disclaimer_pkey PRIMARY KEY (versioncode, categorycode, sequencenumber) " +
        ") " +
        "WITH (OIDS=TRUE); ";
    }
    
    @Override
    public String getInsertQuery(String line) {
        String[] fields = line.split("\\|");
        
        return "INSERT INTO mmw_lib_disclaimer VALUES " +
        "( " +
            "'" + fields[0] + "'," +                //versioncode           CHARACTER VARYING(10) NOT NULL
            "'" + fields[1] + "'," +                //categorycode          CHARACTER VARYING(10) NOT NULL
            Integer.parseInt(fields[2]) + "," +     //sequencenumber        SMALLINT NOT NULL
            "'" + fields[3] + "'," +                //sectioncode           CHARACTER VARYING(1) NOT NULL
            "'" + fields[4] + "'," +                //formatcode            CHARACTER VARYING(1) NOT NULL
            "'" + fields[5].replace("'", "''") + "'" +                 //linetext              CHARACTER VARYING(255) NOT NULL
        " ); ";
    }

}
