package com.uhg.ihr.provider.api.model.profile;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.*;

import javax.validation.Valid;
import javax.validation.constraints.NotNull;

@Data
@Builder(toBuilder = true)
@AllArgsConstructor
@NoArgsConstructor
@JsonInclude(JsonInclude.Include.NON_NULL)
@EqualsAndHashCode(callSuper=false)
public class UserProfileLookup {
//    @JsonProperty
//    private UserProfileConstant.SYSTEM system;
//
//    @JsonProperty
//    private UserProfileConstant.SECURED_CONTEXT securedContext;

    @JsonProperty
    @NotNull(message = "Lookup context must be provided in request body")
    @Valid
    private LookupContext lookupContext;

    @JsonProperty
    private FilterClass responseFilter;
}
