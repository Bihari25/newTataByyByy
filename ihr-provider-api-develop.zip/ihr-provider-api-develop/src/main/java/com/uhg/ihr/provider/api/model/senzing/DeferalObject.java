package com.uhg.ihr.provider.api.model.senzing;

import java.io.Serializable;
import java.util.LinkedHashMap;
import java.util.List;

public class DeferalObject implements Serializable {
    private SearchCriteria criteria;
    private SearchResult topMatch;
    private Response response;
    private MatchInfo matchInfo;
    private LinkedHashMap rSearchCriteria;


    public DeferalObject() {}

    public DeferalObject(Response response) {
        setResponse(response);
        init();
    }

    public SearchCriteria getCriteria() {
        return criteria;
    }

    public void setCriteria(SearchCriteria criteria) {
        this.criteria = criteria;
    }

    public SearchResult getTopMatch() {
        return topMatch;
    }

    public void setTopMatch(SearchResult topMatch) {
        this.topMatch = topMatch;
    }

    public Response getResponse() {
        return response;
    }

    public void setResponse(Response response) {
        this.response = response;
    }

    public MatchInfo getMatchInfo() {
        return matchInfo;
    }

    public void setMatchInfo(MatchInfo matchInfo) {
        this.matchInfo = matchInfo;
    }

    public void setRawCriteria(LinkedHashMap rSearchCriteria) {
        this.rSearchCriteria = rSearchCriteria;
    }

    public LinkedHashMap getrSearchCriteria() {
        return rSearchCriteria;
    }

    public void setrSearchCriteria(LinkedHashMap rSearchCriteria) {
        this.rSearchCriteria = rSearchCriteria;
    }

    private void init() {
        if (response != null && response.getData() != null) {
            SearchResult retainResult = null;
            MatchInfo matchInfo = new MatchInfo();

            List<SearchResult> results = response.getData().getSearchResults();
            matchInfo.setNoOfRecords(results.size());
            long matchLevel = 100;

            for (SearchResult result : results) {
                if (result.getMatchLevel() < matchLevel) {
                    matchLevel = result.getMatchLevel();
                    retainResult = result;
                }
                String globalId = null;
                List<String> identifiers = result.getIdentifierData();
                for (String identifier : identifiers) {
                    if (identifier.contains("GLOBAL_ACTOR_ID")) {
                        String s2[] = identifier.split(":");
                        globalId = s2[1];
                    }
                }
                MatchLevel level = new MatchLevel(
                        globalId,
                        result.getEntityName(),
                        result.getMatchLevel(),
                        result.getFullNameScore(),
                        result.getMatchScore(),
                        result.isAmbiguous(),
                        result.getMatchKey(),
                        result.getResolutionRuleCode(),
                        result.getRefScore(),
                        result.isPartial(),
                        result.getResultType()
                );

                List<String> addressData = result.getAddressData();
                System.out.println("address data: " + addressData);
                if(addressData!=null && !addressData.isEmpty()) {
                    String address = "";
                    for(String s : addressData) {
                        address += " " + s;
                    }
                    level.setAddress(address);
                }
                List<String> attributeData = result.getAttributeData();
                System.out.println("attribute data: " + attributeData);
                if(attributeData!=null && !attributeData.isEmpty()) {
                    for(String s : attributeData) {
                        String [] splitData = s.split(":");
                        if(splitData!=null && splitData.length>1) {
                            if(splitData[0]!=null && splitData[0].trim().equalsIgnoreCase("DOB")) level.setDob(splitData[1]);
                            if(splitData[0]!=null && splitData[0].trim().equalsIgnoreCase("GENDER")) level.setGender(splitData[1]);
                        }
                    }
                }
                matchInfo.addMatchLevel(level);
            }

//            DeferalObject deferalObject = new DeferalObject();
            this.setTopMatch(retainResult);
            this.setMatchInfo(matchInfo);
            this.setResponse(response);
        }
    }
}
