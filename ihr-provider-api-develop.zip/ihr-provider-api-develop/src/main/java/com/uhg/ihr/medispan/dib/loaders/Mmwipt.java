package com.uhg.ihr.medispan.dib.loaders;

/**
*
*/
public class Mmwipt extends TableLoader {
    
	/**
	 *
	 */
    public Mmwipt() {
        super();
    }
    
    @Override
    public String getCreateQuery() {
        return
        "CREATE TABLE mmw_ipt " +
        "( " +
            "ppid                        CHARACTER VARYING(20) NOT NULL, " +
            "startdate                   CHARACTER VARYING(8) NOT NULL, " +
            "imprint1                    CHARACTER VARYING(40) NULL, " +
            "imprint2                    CHARACTER VARYING(40) NULL, " +
            "shapeid                     SMALLINT NULL, " +
            "flavorcode                  CHARACTER VARYING(4) NULL, " +
            "formcode                    CHARACTER VARYING(4) NOT NULL, " +
            "coatingcode                 CHARACTER VARYING(4) NULL, " +
            "scoringcode                 CHARACTER VARYING(4) NULL, " +
            "claritycode                 CHARACTER VARYING(4) NULL, " +
            "descsearch                  CHARACTER VARYING(85) NOT NULL, " +
            "currentimprintind           SMALLINT NOT NULL, " +
            "colorpaletteidlist          CHARACTER VARYING(32) NULL, " +
            "CONSTRAINT mmw_ipt_pkey PRIMARY KEY (ppid, startdate) " +
        ") " +
        "WITH (OIDS=TRUE); ";
    }
    
    @Override
    public String getInsertQuery(String line) {
        String[] fields = line.split("\\|");
        
        return "INSERT INTO mmw_ipt VALUES " +
        "( " +
            "'" + fields[0] + "'," +                //ppid                        CHARACTER VARYING(20) NOT NULL
            "'" + fields[1] + "'," +                //startdate                   CHARACTER VARYING(8) NOT NULL
            (fields[2].isEmpty() ? "NULL" : "'" + fields[2].replace("'", "''") + "'") + "," +    //imprint1                    CHARACTER VARYING(40) NULL
            (fields[3].isEmpty() ? "NULL" : "'" + fields[3].replace("'", "''") + "'") + "," +    //imprint2                    CHARACTER VARYING(40) NULL
            (fields[4].isEmpty() ? "NULL" : Integer.parseInt(fields[4])) + "," +     //shapeid                     SMALLINT NULL
            (fields[5].isEmpty() ? "NULL" : "'" + fields[5] + "'") + "," +           //flavorcode                  CHARACTER VARYING(4) NULL
            "'" + fields[6] + "'," +                //formcode                    CHARACTER VARYING(4) NOT NULL
            (fields[7].isEmpty() ? "NULL" : "'" + fields[7] + "'") + "," +           //coatingcode                 CHARACTER VARYING(4) NULL
            (fields[8].isEmpty() ? "NULL" : "'" + fields[8] + "'") + "," +           //scoringcode                 CHARACTER VARYING(4) NULL
            (fields[9].isEmpty() ? "NULL" : "'" + fields[9] + "'") + "," +         //claritycode                 CHARACTER VARYING(4) NULL
            "'" + fields[10].replace("'", "''") + "'," +               //descsearch                  CHARACTER VARYING(85) NOT NULL
            Integer.parseInt(fields[11]) + "," +    //currentimprintind           SMALLINT NOT NULL
            (fields.length < 13 || fields[12].isEmpty() ? "NULL" : "'" + fields[12] + "'") +    //colorpaletteidlist          CHARACTER VARYING(32) NULL
        " ); ";
    }

}
