package com.uhg.ihr.provider.api.model;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

import javax.validation.constraints.NotNull;

@Data
@NoArgsConstructor
@AllArgsConstructor
@EqualsAndHashCode(callSuper=false)
public class IhrApiWithActorRequest {

    @JsonProperty
    @NotNull(message = "The request body must contain an actor")
    private Actor actor;

    public IhrApiWithActorRequest(String provider) {
        this.actor = new Actor();
        this.actor.setId(new ActorId(provider, provider));
    }

    /**
     * Returns the identifier for the Actor associated with this request.
     */
    @JsonIgnore
    public String getActorId() {
        return actor != null
                ? actor.getActiveId()
                : null;
    }
}
