package com.uhg.ihr.medispan.dib.loaders;

/**
*
*/
public class Mmwdiint extends TableLoader {
    
	/**
	 *
	 */
    public Mmwdiint() {
        super();
    }
    
    @Override
    public String getCreateQuery() {
        return
        "CREATE TABLE mmw_di_int " +
        "( " +
            "classid1                    CHARACTER VARYING(5) NOT NULL, " +
            "classid2                    CHARACTER VARYING(5) NOT NULL, " +
            "actcode1                    CHARACTER VARYING(1) NOT NULL, " +
            "actcode2                    CHARACTER VARYING(1) NOT NULL, " +
            "duration1                   SMALLINT NOT NULL, " +
            "duration2                   SMALLINT NOT NULL, " +
            "schedreg1ind                SMALLINT NOT NULL, " +
            "schedasneeded1ind           SMALLINT NOT NULL, " +
            "schedsingle1ind             SMALLINT NOT NULL, " +
            "schedreg2ind                SMALLINT NOT NULL, " +
            "schedasneeded2ind           SMALLINT NOT NULL, " +
            "schedsingle2ind             SMALLINT NOT NULL, " +
            "onsetcode                   CHARACTER VARYING(1) NOT NULL, " +
            "severitycode                CHARACTER VARYING(1) NOT NULL, " +
            "doclevelcode                CHARACTER VARYING(1) NOT NULL, " +
            "class1name                  CHARACTER VARYING(75) NOT NULL, " +
            "class2name                  CHARACTER VARYING(75) NOT NULL, " +
            "monoid                      CHARACTER VARYING(20) NOT NULL, " +
            "screeningind                SMALLINT NOT NULL, " +
            "mgmtcode                    CHARACTER VARYING(1) NOT NULL, " +
            "CONSTRAINT mmw_di_int_pkey PRIMARY KEY (classid1, classid2) " +
        ") " +
        "WITH (OIDS=TRUE); ";
    }
    
    @Override
    public String getInsertQuery(String line) {
        String[] fields = line.split("\\|");
        
        return "INSERT INTO mmw_di_int VALUES " +
        "( " +
            "'" + fields[0] + "'," +                        //classid1                    CHARACTER VARYING(5) NOT NULL
            "'" + fields[1] + "'," +                        //classid2                    CHARACTER VARYING(5) NOT NULL
            "'" + fields[2] + "'," +                        //actcode1                    CHARACTER VARYING(1) NOT NULL
            "'" + fields[3] + "'," +                        //actcode2                    CHARACTER VARYING(1) NOT NULL
            Integer.parseInt(fields[4]) + "," +             //duration1                   SMALLINT NOT NULL
            Integer.parseInt(fields[5]) + "," +             //duration2                   SMALLINT NOT NULL
            Integer.parseInt(fields[6]) + "," +             //schedreg1ind                SMALLINT NOT NULL
            Integer.parseInt(fields[7]) + "," +             //schedasneeded1ind           SMALLINT NOT NULL
            Integer.parseInt(fields[8]) + "," +             //schedsingle1ind             SMALLINT NOT NULL
            Integer.parseInt(fields[9]) + "," +             //schedreg2ind                SMALLINT NOT NULL
            Integer.parseInt(fields[10]) + "," +            //schedasneeded2ind           SMALLINT NOT NULL
            Integer.parseInt(fields[11]) + "," +            //schedsingle2ind             SMALLINT NOT NULL
            "'" + fields[12] + "'," +                       //onsetcode                   CHARACTER VARYING(1) NOT NULL
            "'" + fields[13] + "'," +                       //severitycode                CHARACTER VARYING(1) NOT NULL
            "'" + fields[14] + "'," +                       //doclevelcode                CHARACTER VARYING(1) NOT NULL
            "'" + fields[15].replace("'", "''") + "'," +    //class1name                  CHARACTER VARYING(75) NOT NULL
            "'" + fields[16].replace("'", "''") + "'," +    //class2name                  CHARACTER VARYING(75) NOT NULL
            "'" + fields[17] + "'," +                       //monoid                      CHARACTER VARYING(20) NOT NULL
            Integer.parseInt(fields[18]) + "," +            //screeningind                SMALLINT NOT NULL
            "'" + fields[19] + "'" +                        //mgmtcode                    CHARACTER VARYING(1) NOT NULL
        " ); ";
    }

}
