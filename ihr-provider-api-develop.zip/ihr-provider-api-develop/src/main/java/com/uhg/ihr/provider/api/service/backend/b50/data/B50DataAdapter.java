package com.uhg.ihr.provider.api.service.backend.b50.data;

import com.fasterxml.jackson.databind.JsonNode;
import com.uhg.ihr.provider.api.exception.LiteHttpClientException;
import com.uhg.ihr.provider.api.exception.UnhandledApiException;
import com.uhg.ihr.provider.api.model.ProviderApiHeaders;
import com.uhg.ihr.provider.api.service.backend.DataAdapterInterface;
import com.uhg.ihr.provider.api.service.backend.b50.B50ApiSecurity;
import com.uhg.ihr.provider.api.service.backend.b50.data.model.request.B50DataRequest;
import com.uhg.ihr.provider.api.service.backend.b50.data.sdc.SDCService;
import io.micronaut.http.HttpStatus;
import io.micronaut.http.client.exceptions.HttpClientResponseException;
import io.reactivex.Maybe;
import lombok.extern.slf4j.Slf4j;

import javax.inject.Inject;
import javax.inject.Singleton;

@Slf4j
@Singleton
public class B50DataAdapter implements DataAdapterInterface {

    @Inject
    private B50DataClient client;
    @Inject
    private SDCService sdcService;
    @Inject
    private B50ApiSecurity apiSecurity;

    public Maybe<JsonNode> getAllByActorChid(final String providerChid, final String patientChid, final ProviderApiHeaders headers) {
        B50DataRequest requestBody = new B50DataRequest();
        requestBody.setPatientChid(patientChid);
        String bearerToken = apiSecurity.generateProviderBearerToken(providerChid);
        String overrideToken = sdcService.validateToken(patientChid, providerChid, headers) ? "View" : "";
        return client
                .requestData(bearerToken, requestBody, headers.getCorrelationId(), headers.getAcceptLanguage(), overrideToken)
                .onErrorResumeNext(e -> {
                    if (e instanceof HttpClientResponseException) {
                        if (((HttpClientResponseException) e).getResponse().getStatus().equals(HttpStatus.NO_CONTENT)) {
                            log.debug("Data request returned no results");
                            return Maybe.empty();
                        } else {
                            return Maybe.error(new LiteHttpClientException((HttpClientResponseException) e, requestBody));
                        }
                    } else {
                        return Maybe.error(new UnhandledApiException(e));
                    }
                });
    }
}
