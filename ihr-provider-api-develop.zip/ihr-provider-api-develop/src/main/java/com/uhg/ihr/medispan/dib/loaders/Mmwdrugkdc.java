package com.uhg.ihr.medispan.dib.loaders;

/**
*
*/
public class Mmwdrugkdc extends TableLoader {
    
	/**
	 *
	 */
    public Mmwdrugkdc() {
        super();
    }
    
    @Override
    public String getCreateQuery() {
        return
        "CREATE TABLE mmw_drug_kdc " +
        "( " +
            "kdc1                        CHARACTER VARYING(5) NOT NULL, " +
            "description                 CHARACTER VARYING(50) NOT NULL, " +
            "CONSTRAINT mmw_drug_kdc_pkey PRIMARY KEY (kdc1) " +
        ") " +
        "WITH (OIDS=TRUE); ";
    }
    
    @Override
    public String getInsertQuery(String line) {
        String[] fields = line.split("\\|");
        
        return "INSERT INTO mmw_drug_kdc VALUES " +
        "( " +
            "'" + fields[0] + "'," +    //kdc1                        CHARACTER VARYING(5) NOT NULL
            "'" + fields[1].replace("'", "''") + "'" +     //description                 CHARACTER VARYING(50) NOT NULL
        " ); ";
    }

}
