package com.uhg.ihr.provider.api.service.backend.b50.relationship.model;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.uhg.ihr.provider.api.service.relationship.model.RelationshipRole;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;

@Data
@AllArgsConstructor
@Builder(toBuilder = true)
public class B50RelationshipRequest {
    @JsonProperty("GLOBAL_ACTOR_ID")
    private String patientChid;
    @JsonProperty("PROVIDER_ACTOR_ID")
    private String providerChid;
    @JsonProperty("PROVIDER_ROLE")
    private RelationshipRole providerRole;
    @JsonProperty("EFFECTIVE_DATE")
    private String effectiveDate;
    @JsonProperty("END_DATE")
    private String endDate;
}
