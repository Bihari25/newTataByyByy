package com.uhg.ihr.medispan.dib.loaders;

/**
*
*/
public class Mmwiptdescclr extends TableLoader {
    
	/**
	 *
	 */
    public Mmwiptdescclr() {
        super();
    }
    
    @Override
    public String getCreateQuery() {
        return
        "CREATE TABLE mmw_ipt_descclr " +
        "( " +
            "ppid                        CHARACTER VARYING(20) NOT NULL, " +
            "startdate                   CHARACTER VARYING(8) NOT NULL, " +
            "colorid                     SMALLINT NOT NULL, " +
            "CONSTRAINT mmw_ipt_descclr_pkey PRIMARY KEY (ppid, startdate, colorid) " +
        ") " +
        "WITH (OIDS=TRUE); ";
    }
    
    @Override
    public String getInsertQuery(String line) {
        String[] fields = line.split("\\|");
        
        return "INSERT INTO mmw_ipt_descclr VALUES " +
        "( " +
            "'" + fields[0] + "'," +            //ppid          CHARACTER VARYING(20) NOT NULL
            "'" + fields[1] + "'," +            //startdate     CHARACTER VARYING(8) NOT NULL
            Integer.parseInt(fields[2]) +       //colorid       SMALLINT NOT NULL
        " ); ";
    }

}
