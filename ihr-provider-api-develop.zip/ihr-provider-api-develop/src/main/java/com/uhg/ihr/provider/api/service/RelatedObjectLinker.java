package com.uhg.ihr.provider.api.service;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ObjectNode;
import com.uhg.ihr.provider.api.exception.IhrNotFoundException;
import com.uhg.ihr.provider.api.model.GlobalHealthObjectId;
import com.uhg.ihr.provider.api.model.RecordType;
import com.uhg.ihr.provider.api.service.backend.b50.data.model.healthitem.*;
import io.micronaut.context.annotation.Value;
import lombok.Data;
import lombok.extern.slf4j.Slf4j;

import javax.annotation.Nullable;
import javax.inject.Inject;
import java.util.*;
import java.util.concurrent.Callable;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;
import java.util.regex.Pattern;

import static com.uhg.ihr.provider.api.model.RecordType.*;
import static com.uhg.ihr.provider.api.service.DataService.*;
import static com.uhg.ihr.provider.api.util.JsonUtils.getJsonNodeText;
import static com.uhg.ihr.provider.api.util.JsonUtils.validateJsonNode;

@Slf4j
public class RelatedObjectLinker {

    private static final Pattern SURGERY_PATTERN = Pattern.compile("(?i)^surgery.*$");
    private static final Pattern ABNORMAL_HIGH_PATTERN = Pattern.compile("(?i)^.*high$");
    private static final Pattern ABNORMAL_LOW_PATTERN = Pattern.compile("(?i)^.*low$");
    private static final String GID_ITERATOR_NAME = "gid";
    private static final String LINK_DEC_ITERATOR_NAME = "linkDecorator";
    private static final String IS_PROTECTED_FIELD = "isProtected";
    private static final String ALLOW_OVERRIED_FIELD = "allowOverried";
    private static final ObjectMapper MAPPER = new ObjectMapper();
    private final int numOfThreads;
    private final int tasksPerThread;

    @Inject
    public RelatedObjectLinker(@Value("${performance.object-linker.num-of-threads}") int numOfThreads,
                               @Value("${performance.object-linker.tasks-per-thread}") int tasksPerThread) {
        this.numOfThreads = numOfThreads > 0 ? numOfThreads : 1;
        this.tasksPerThread = tasksPerThread > 0 ? tasksPerThread : 1;
    }

    public Map<RecordType, Map<Integer, JsonNode>> populateRelatedObjectsForAllHealthItems(JsonNode root) {
        if (root != null && getDataClassesNode(root) != null) {
            long startTime = System.currentTimeMillis();
            Map<Map<String, Iterator<JsonNode>>, Integer> iteratorAndTaskCount = allocateTaskCount(getDataClassesNode(root));
            int completedTasks = 0;
            List<GlobalObjectIdTask> gIdTasks = new ArrayList<>();
            List<LinkerAndDecoratorTask> linkDecorateTasks = new ArrayList<>();
            final DataClassManager dataObjects = new DataClassManager(root);
            while (completedTasks != iteratorAndTaskCount.size()) {
                Set<Map.Entry<Map<String, Iterator<JsonNode>>, Integer>> dataClasses = iteratorAndTaskCount.entrySet();
                for (Map.Entry<Map<String, Iterator<JsonNode>>, Integer> dataClass : dataClasses) {
                    int tasksLeft = dataClass.getValue();
                    if (tasksLeft > 0) {
                        gIdTasks.add(new GlobalObjectIdTask(dataClass.getKey().get(GID_ITERATOR_NAME), dataObjects));
                        linkDecorateTasks.add(new LinkerAndDecoratorTask(dataClass.getKey().get(LINK_DEC_ITERATOR_NAME), dataObjects));
                        --tasksLeft;
                        dataClass.setValue(tasksLeft);
                        if (tasksLeft == 0) {
                            ++completedTasks;
                        }
                    }
                }
            }

            ExecutorService threadPool = Executors.newFixedThreadPool(numOfThreads);
            try {
                threadPool.invokeAll(gIdTasks);
                threadPool.invokeAll(linkDecorateTasks);
                threadPool.shutdown();
                threadPool = null;
            } catch (InterruptedException e) {
                log.error("LINKER ERROR", e);
            }
            log.debug("Total linker time for " + gIdTasks.size() + " objects was " + (System.currentTimeMillis() - startTime));
            return dataObjects.getObjectDataClassPointers();
        } else {
            throw new IhrNotFoundException("No data found for user");
        }
    }

    private Map<Map<String, Iterator<JsonNode>>, Integer> allocateTaskCount(JsonNode dataClasses) {
        Map<Map<String, Iterator<JsonNode>>, Integer> iteratorsAndTasks = new HashMap<>();
        int totalNumOfTasks = numOfThreads * tasksPerThread;
        int totalObjects = 0;
        //Get dataclass iterator and count number of object for dataclass
        dataClasses.fields().forEachRemaining(dataClass -> {
            if (!dataClass.getValue().isEmpty()) {
                Map<String, Iterator<JsonNode>> taskIterators = new HashMap<>();
                taskIterators.put(GID_ITERATOR_NAME, dataClass.getValue().elements());
                taskIterators.put(LINK_DEC_ITERATOR_NAME, dataClass.getValue().elements());
                iteratorsAndTasks.put(taskIterators, dataClass.getValue().size());
            }
        });
        //Sum up all the counts of dataobjects to get total count
        for (Map.Entry<Map<String, Iterator<JsonNode>>, Integer> dataClass : iteratorsAndTasks.entrySet()) {
            totalObjects += dataClass.getValue();
        }
        //Allocate number of tasks per dataclass based on ratio of dataclass objects to total objects multiplied by the configured
        //maximum number of tasks allowed.
        for (Map.Entry<Map<String, Iterator<JsonNode>>, Integer> dataClass : iteratorsAndTasks.entrySet()) {
            int tasksForClass = (int) (((double) dataClass.getValue() / (double) totalObjects) * (double) totalNumOfTasks);
            if (tasksForClass <= 0) {
                tasksForClass = 1;
            } else if (tasksForClass > dataClass.getValue()) {
                tasksForClass = dataClass.getValue();
            }
            tasksForClass = dataClass.getValue() < tasksForClass ? dataClass.getValue() : tasksForClass;
            dataClass.setValue(tasksForClass);
        }
        return iteratorsAndTasks;
    }

    private void populateAllRelatedObjectsForHealthItem(DataClassManager dataObjects, JsonNode data) {
        buildRelatedCareTeamLinkage(dataObjects, data);
        buildRelatedConditionLinkage(dataObjects, data);
        buildRelatedProcedures(dataObjects, data);
        buildRelatedObservations(dataObjects, data);
        buildRelatedServiceProviders(dataObjects, data);
        buildRelatedMedication(dataObjects, data);
        buildRelatedVisit(dataObjects, data);
    }

    private void decorateDataclass(DataClassManager dataManager, JsonNode workingNode) {

        switch (getRecordType(workingNode)) {
            case PROCEDURE_HISTORY: {
                RecordType specficProcedure = procedureIsSurgicalOrTest(workingNode);
                ObjectNode copiedNode = workingNode.deepCopy();
                GlobalHealthObjectId oldObjectId = new GlobalHealthObjectId(getGlobalObjectId(copiedNode));
                GlobalHealthObjectId newObjectId = new GlobalHealthObjectId(specficProcedure,oldObjectId.getObjectId());
                copiedNode.put("objectId", newObjectId.getGlobalId());
                copiedNode.put(RECORD_TYPE_NODE, specficProcedure.name());
                dataManager.putDataObject(newObjectId.getObjectId(), specficProcedure, copiedNode);
                break;
            }
            case CARE_TEAM: {
            }
            case SERVICE_FACILITY_PROVIDER: {
                JsonNode occupationsArray = workingNode.get("occupations");
                if (occupationsArray != null) {
                    Set<String> occupationsConcepts = new HashSet<>();
                    Set<String> specialties = new HashSet<>();
                    for (JsonNode occupationRow : occupationsArray) {
                        JsonNode conceptNode = occupationRow.get("concept");
                        if (conceptNode != null) {
                            String term = getIhrTermOrLayman(conceptNode);
                            if (term != null) {
                                occupationsConcepts.add(term);
                            }
                        }
                        JsonNode specialtiesNode = occupationRow.get("specialties");
                        if (specialtiesNode != null) {
                            for (JsonNode specialty : specialtiesNode) {
                                String term = getIhrTermOrLayman(specialty);
                                if (term != null) {
                                    specialties.add(term);
                                }
                            }
                        }
                    }
                    ((ObjectNode) workingNode).putPOJO("occupationConcepts", occupationsConcepts);
                    ((ObjectNode) workingNode).putPOJO("specialties", specialties);
                }
                break;
            }
        }
    }

    private RecordType procedureIsSurgicalOrTest(JsonNode workingNode) {
        String medicalDomain = workingNode.get("healthEvent") != null ? getJsonNodeText(workingNode.get("healthEvent").get("medicalDomain")) : "";
        return medicalDomain != null && SURGERY_PATTERN.matcher(medicalDomain).matches() ?
                SURGICAL_HISTORY :
                TEST_EXAM_ASSESSMENT_HISTORY;
    }

    private boolean relatedObjectIsProtected(JsonNode workingNode) {
        return workingNode.has(IS_PROTECTED_FIELD) && workingNode.get(IS_PROTECTED_FIELD).asBoolean(true);
    }

    @Nullable
    private String getIhrTermOrLayman(JsonNode ihrNode) {
        if (ihrNode.get("ihrTerm") != null) {
            return ihrNode.get("ihrTerm").asText();
        } else {
            return ihrNode.get("ihrLaymanTerm") == null ? null : ihrNode.get("ihrLaymanTerm").asText();
        }
    }

    private List<Integer> fetchRelatedIds(JsonNode data, String node) {
        List<Integer> ids = null;
        if (node != null && data.findValue(node.trim()) != null) {
            JsonNode relatedCareTeamIds = data.path(node.trim());
            ids = new ArrayList<>();
            for (JsonNode n : relatedCareTeamIds) {
                ids.add(n.intValue());
            }
        }

        return ids;
    }

    private void buildRelatedVisit(DataClassManager dataObjects, JsonNode data) {
        List<Integer> ids = fetchRelatedIds(data, "relatedVisit");
        if (ids != null && !ids.isEmpty()) {
            List<RelatedVisit> relatedVisits = new ArrayList<>();
            for (Integer id : ids) {
                JsonNode item = dataObjects.getDataObject(id, VISIT_HISTORY);
                if (!validateJsonNode(item) || relatedObjectIsProtected(item)) continue;
                String admitDate = getJsonNodeText(item.path("admitDate"));
                String dischargeDate = getJsonNodeText(item.path("dischargeDate"));
                String clinicallyRelevantDate = getJsonNodeText(item.path("clinicallyRelevantDate"));
                String term = getJsonNodeText(item.path("visit").path("ihrTerm"));
                RelatedVisit relatedVisit = RelatedVisit.builder()
                        .admitDate(admitDate)
                        .dischargeDate(dischargeDate)
                        .clinicallyRelevantDate(clinicallyRelevantDate)
                        .term(term)
                        .build();
                relatedVisit.setObjectId(getGlobalObjectId(item));
                relatedVisit.setRecordType(getRecordType(item));
                relatedVisits.add(relatedVisit);
            }
            nodeConcatenation(relatedVisits, "RelatedVisitsLinkage", data);
        }
    }

    private void buildRelatedMedication(DataClassManager dataObjects, JsonNode data) {
        List<Integer> ids = fetchRelatedIds(data, "relatedMedications");
        if (ids != null && !ids.isEmpty()) {
            List<RelatedMedication> relatedMedications = new ArrayList<>();

            for (Integer id : ids) {
                JsonNode item = dataObjects.getDataObject(id, HEALTH_MEDICATION);
                if (!validateJsonNode(item) || relatedObjectIsProtected(item)) continue;

                String startDate = getJsonNodeText(item.path("medicationStartDate"));
                String fillDate = getJsonNodeText(item.path("lastFillDate"));
                String term = "";
                if (validateJsonNode(item.path("medication"))) {
                    term = getJsonNodeText(item.path("medication").path("ihrTerm"));
                }
                RelatedMedication relatedMedication = RelatedMedication.builder()
                        .term(term)
                        .medicationStartDate(startDate)
                        .lastFillDate(fillDate)
                        .build();
                relatedMedication.setObjectId(getGlobalObjectId(item));
                relatedMedication.setRecordType(getRecordType(item));
                relatedMedications.add(relatedMedication);
            }
            nodeConcatenation(relatedMedications, "RelatedMedicationsLinkage", data);
        }
    }

    private void buildRelatedServiceProviders(DataClassManager dataObjects, JsonNode data) {
        List<Integer> ids = fetchRelatedIds(data, "relatedServiceProviders");
        if (ids != null && !ids.isEmpty()) {
            List<RelatedServiceProvider> relatedServiceProviders = new ArrayList<>();

            List<RelatedServiceProvider> relatedMedicationServiceProviders = new ArrayList<>();
            List<RelatedServiceProvider> relatedServiceProviderOrganizations = new ArrayList<>();
            for (Integer id : ids) {
                JsonNode item = dataObjects.getDataObject(id, SERVICE_FACILITY_PROVIDER);
                if (!validateJsonNode(item) || !validateJsonNode(item.get("occupations")) || relatedObjectIsProtected(item)) continue;

                String type = getJsonNodeText(item.path("providerType"));
                String name = getJsonNodeText(item.path("relatedEntityName"));
                String npi = getJsonNodeText(item.path("relatedEntityNPInum"));
                RelatedServiceProvider relatedServiceProvider = RelatedServiceProvider.builder()
                        .name(name)
                        .type(type)
                        .npi(npi)
                        .build();

                relatedServiceProvider.setObjectId(getGlobalObjectId(item));
                relatedServiceProvider.setRecordType(getRecordType(item));
                String relatedEntityRoleTerm = getJsonNodeText(item.path("relatedEntityRoleTerm"));

                // todo: work with APP Eng. on populate the ONT CHID
                if (relatedEntityRoleTerm != null) {
                    switch (relatedEntityRoleTerm) {
                        case HealthItemConstant.RelatedProviderService.MEDICATION_PRODUCT_SUPPLIER:
                            relatedMedicationServiceProviders.add(relatedServiceProvider);
                            break;
                        case HealthItemConstant.RelatedProviderService.SERVICE_PROVIDER_ORGANIZATION:
                            relatedServiceProviderOrganizations.add(relatedServiceProvider);
                            break;
                    }
                }
                relatedServiceProviders.add(relatedServiceProvider);
            }

            nodeConcatenation(relatedServiceProviders, "RelatedServiceProvidersLinkage", data);
            nodeConcatenation(relatedServiceProviderOrganizations, "RelatedServiceProviderOrganizationsLinkage", data);
            nodeConcatenation(relatedMedicationServiceProviders, "RelatedMedicationServiceProvidersLinkage", data);


            /*if (!relatedServiceProviders.isEmpty()) {
                JsonNode node = MAPPER.convertValue(relatedServiceProviders, JsonNode.class);
                ((ObjectNode) data).set("RelatedServiceProvidersLinkage", node);
            }*/
        }
    }


    /*
        relatedEntityRoleTerm:
            Referring Provider          [referring physician]
            Ordering Provider           [Order/Service]
            Rendering Service Provider  [rendering physician]
            Attending Practitioner      [???]
     */
    private void buildRelatedCareTeamLinkage(DataClassManager dataObjects, JsonNode data) {
        log.trace("Related Care Team get Invoked!!!!");
        if (data.findValue("relatedCareTeam") != null) {
            JsonNode relatedCareTeamIds = data.path("relatedCareTeam");
            List<Integer> ids = new ArrayList<>();
            for (JsonNode n : relatedCareTeamIds) {
                ids.add(n.intValue());
            }

            if (!ids.isEmpty()) {
                List<RelatedCareTeam> relatedCareTeams = new ArrayList<>();
                List<RelatedCareTeam> relatedReferringCareTeams = new ArrayList<>();
                List<RelatedCareTeam> relatedOrderingCareTeams = new ArrayList<>();
                List<RelatedCareTeam> relatedRenderingCareTeams = new ArrayList<>();
                List<RelatedCareTeam> relatedAttendingCareTeams = new ArrayList<>();

                for (int id : ids) {
                    JsonNode item = dataObjects.getDataObject(id, CARE_TEAM);
                    if (!validateJsonNode(item) || !validateJsonNode(item.path("occupations")) || relatedObjectIsProtected(item)) continue;

                    JsonNode occupations = item.path("occupations");
                    StringBuilder spc = new StringBuilder();
                    for (JsonNode node : occupations) {
                        JsonNode concept = node.path("concept");
                        if (!validateJsonNode(concept)) continue;

                        if (validateJsonNode(concept.path("ihrTerm")))
                            spc.append(getJsonNodeText(concept.path("ihrTerm"))).append(", ");

                        JsonNode specialties = node.path("specialties");
                        for (JsonNode s : specialties) {
                            if (!validateJsonNode(s) || !validateJsonNode(s.path("ihrTerm"))) continue;

                            spc.append(s.path("ihrTerm").asText()).append(", ");
                        }
                    }
                    //Trim excess ', ' off of string builder
                    if (spc.length() > 0) {
                        spc.delete(spc.length() - 2, spc.length());
                    }

                    String relatedEntityName = getJsonNodeText(item.path("relatedEntityName"));
                    String relatedEntityNPInum = getJsonNodeText(item.path("relatedEntityNPInum"));
                    RelatedCareTeam relatedCareTeam = RelatedCareTeam.builder()
                            .name(relatedEntityName != null ? relatedEntityName : "")
                            .npi(relatedEntityNPInum != null ? relatedEntityNPInum : "")
                            .specialties(spc.toString())
                            .build();
                    relatedCareTeam.setObjectId(getGlobalObjectId(item));
                    relatedCareTeam.setRecordType(getRecordType(item));

                    String relatedEntityRoleTerm = getJsonNodeText(item.path("relatedEntityRoleTerm"));
                    if (relatedEntityRoleTerm != null) {
                        switch (relatedEntityRoleTerm) {
                            case HealthItemConstant.RelatedCareTeam.REFERRING_PROVIDER:
                                relatedReferringCareTeams.add(relatedCareTeam);
                                break;

                            case HealthItemConstant.RelatedCareTeam.ORDERING_PROVIDER:
                                relatedOrderingCareTeams.add(relatedCareTeam);
                                break;

                            case HealthItemConstant.RelatedCareTeam.RENDERING_SERVICE_PROVIDER:
                                relatedRenderingCareTeams.add(relatedCareTeam);
                                break;

                            case HealthItemConstant.RelatedCareTeam.ATTENDING_PRACTIONER:
                                relatedAttendingCareTeams.add(relatedCareTeam);
                                break;

                        }
                    }

                    relatedCareTeams.add(relatedCareTeam);
                }

                // todo: work with APP ENG on exposing the CHID
                nodeConcatenation(relatedReferringCareTeams, "RelatedReferringCareTeamsLinkage", data);
                nodeConcatenation(relatedOrderingCareTeams, "RelatedOrderingCareTeamsLinkage", data);
                nodeConcatenation(relatedRenderingCareTeams, "RelatedRenderingCareTeamsLinkage", data);
                nodeConcatenation(relatedAttendingCareTeams, "RelatedAttendingCareTeamsLinkage", data);

                //todo: to be removed when finalizing needed data for health item detail
                nodeConcatenation(relatedCareTeams, "RelatedCareTeamsLinkage", data);
            }
        }

        log.trace("Done - Related Care Team get Invoked!!!!");

    }

    private void nodeConcatenation(List<? extends RelatedHealthItem> l, String node, JsonNode data) {

        if (!l.isEmpty() && node != null) {
            JsonNode n = MAPPER.convertValue(l, JsonNode.class);
            ((ObjectNode) data).set(node.trim(), n);
        }
    }

    private void buildRelatedConditionLinkage(DataClassManager dataObjects, JsonNode data) {
        if (data.findValue("relatedConditions") != null) {
            JsonNode relatedConditionIds = data.path("relatedConditions");
            if (validateJsonNode(relatedConditionIds)) {
                List<RelatedCondition> relatedConditions = new ArrayList<>();
                for (JsonNode id : relatedConditionIds) {
                    JsonNode relatedCondtion = dataObjects.getDataObject(id.asInt(), HEALTH_CONDITION);
                    if (validateJsonNode(relatedCondtion) && !relatedObjectIsProtected(relatedCondtion)) {
                        RelatedCondition condition;

                        JsonNode tmp = relatedCondtion.path("healthCondition");
                        if (validateJsonNode(tmp)) {
                            String ihrTerm = getJsonNodeText(tmp.path("ihrTerm"));
                            String status = null;
                            if (validateJsonNode(relatedCondtion.path("status")) &&
                                    validateJsonNode(relatedCondtion.path("status").path("ihrTerm"))) {
                                status = getJsonNodeText(relatedCondtion.path("status").path("ihrTerm"));
                            }
                            String onsetDate = getJsonNodeText(relatedCondtion.path("onsetDate"));
                            String lastUpdateDate = getJsonNodeText(relatedCondtion.path("lastUpdateDate"));
                            condition = RelatedCondition.builder()
                                    .term(ihrTerm)
                                    .status(status)
                                    .onsetDate(onsetDate)
                                    .lastUpdateDate(lastUpdateDate)
                                    .build();

                            condition.setObjectId(getGlobalObjectId(relatedCondtion));
                            condition.setRecordType(getRecordType(relatedCondtion));

                            relatedConditions.add(condition);
                        }
                    }
                }
                if (!relatedConditions.isEmpty()) {
                    JsonNode node = MAPPER.convertValue(relatedConditions, JsonNode.class);
                    ((ObjectNode) data).set("RelatedConditionLinkage", node);
                }
            }
        }
    }

    private void buildRelatedProcedures(DataClassManager dataObjects, JsonNode data) {
        if (data.findValue("relatedProcedures") != null) {
            JsonNode relatedProceduresIds = data.findValue("relatedProcedures");
            List<RelatedProcedure> relatedProcedures = new ArrayList<>();
            for (JsonNode n : relatedProceduresIds) {
                JsonNode tmp = dataObjects.getDataObject(n.asInt(), PROCEDURE_HISTORY);
                if (validateJsonNode(tmp) && !relatedObjectIsProtected(tmp)) {
                    String ihrTerm = null, healthEventDate, healthEventStatus = null;

                    if (validateJsonNode(tmp.path("healthEvent")))
                        ihrTerm = getJsonNodeText(tmp.path("healthEvent").path("ihrTerm"));

                    healthEventDate = getJsonNodeText(tmp.path("healthEventDate"));
                    if (validateJsonNode(tmp.path("healthEventStatus")))
                        healthEventStatus = getJsonNodeText(tmp.path("healthEventStatus").path("ihrTerm"));

                    RelatedProcedure relatedProcedure = RelatedProcedure.builder()
                            .term(ihrTerm)
                            .date(healthEventDate)
                            .status(healthEventStatus)
                            .build();
                    relatedProcedure.setObjectId(getGlobalObjectId(tmp));
                    relatedProcedure.setRecordType(getRecordType(tmp));
                    relatedProcedures.add(relatedProcedure);
                }
            }

            if (!relatedProcedures.isEmpty()) {
                JsonNode node = MAPPER.convertValue(relatedProcedures, JsonNode.class);
                ((ObjectNode) data).set("RelatedProceduresLinkage", node);
            }
        }
    }

    private void buildRelatedObservations(DataClassManager dataObjects, JsonNode data) {
        if (data.findValue("relatedObservations") != null) {
            JsonNode relatedProceduresIds = data.findValue("relatedObservations");
            List<RelatedObservation> relatedObservations = new ArrayList<>();
            boolean abnormalHigh = false;
            boolean abnormalLow = false;
            for (JsonNode n : relatedProceduresIds) {
                JsonNode tmp = dataObjects.getDataObject(n.asInt(), HEALTH_OBSERVATIONS);
                if (validateJsonNode(tmp) && !relatedObjectIsProtected(tmp)) {
                    String ihrTerm = null;

                    if (validateJsonNode(tmp.path("observation"))) {
                        ihrTerm = getJsonNodeText(tmp.path("observation").path("ihrTerm"));
                    }
                    JsonNode abnormalObservation = tmp.path("abnormalObservation");
                    String abnormalIndicator = abnormalObservation != null ? getJsonNodeText(abnormalObservation.path("ihrTerm")) : "";
                    if (!abnormalHigh) {
                        if (abnormalIndicator != null && !abnormalIndicator.isBlank()) {
                            if (ABNORMAL_HIGH_PATTERN.matcher(abnormalIndicator).matches()) {
                                abnormalHigh = true;
                            } else if (!abnormalLow && ABNORMAL_LOW_PATTERN.matcher(abnormalIndicator).matches()) {
                                abnormalLow = true;
                            }
                        }
                    }
                    RelatedObservation relatedObservation = RelatedObservation.builder()
                            .value(getJsonNodeText(tmp.path("valueString")))
                            .indicator(abnormalIndicator)
                            .refRange(getJsonNodeText(tmp.path("referenceRange")))
                            .term(tmp.path("observation").path("ihrTerm").asText())
                            .unit(tmp.path("observationUnitOfMeasure") != null ? getJsonNodeText(tmp.path("observationUnitOfMeasure").path("ihrTerm")) : "")
                            .date(getJsonNodeText(tmp.path("observationDate")))
                            .sourceVocabularyCode(getJsonNodeText(tmp.path("sourceVocabularyCode")))
                            .build();
                    relatedObservation.setObjectId(getGlobalObjectId(tmp));
                    relatedObservation.setRecordType(getRecordType(tmp));
                    relatedObservations.add(relatedObservation);
                }
            }

            if (abnormalHigh || abnormalLow) {
                ((ObjectNode) data).put("observationIndicator", "Abnormal " + (abnormalHigh ? "High" : "Low"));
            }

            if (!relatedObservations.isEmpty()) {
                JsonNode node = MAPPER.convertValue(relatedObservations, JsonNode.class);
                ((ObjectNode) data).set("RelatedObservationsLinkage", node);
            }
        }
    }

    private class GlobalObjectIdTask extends ObjectProcessorTaskParent {

        private GlobalObjectIdTask(Iterator<JsonNode> dataClassObjects, DataClassManager dataManager) {
            super(dataClassObjects, dataManager);
        }

        @Override
        public Boolean call() {
            try {
                JsonNode workingNode;
                while ((workingNode = super.getNextObject()) != null) {
                    int objectId = getObjectId(workingNode);
                    RecordType recordType = getRecordType(workingNode);
                    super.getDataManager().putDataObject(objectId, recordType, workingNode);
                    GlobalHealthObjectId newObjectId = new GlobalHealthObjectId(recordType, objectId);
                    ((ObjectNode) workingNode).put("objectId", newObjectId.getGlobalId());
                }
            } catch (Exception e) {
                log.error("Bad thing", e);
            }
            return true;
        }
    }

    private class LinkerAndDecoratorTask extends ObjectProcessorTaskParent {

        private LinkerAndDecoratorTask(Iterator<JsonNode> dataClassObjects, DataClassManager dataManager) {
            super(dataClassObjects, dataManager);
        }

        @Override
        public Boolean call() {
            try {
                JsonNode workingNode;
                while ((workingNode = super.getNextObject()) != null) {
                    populateAllRelatedObjectsForHealthItem(super.getDataManager(), workingNode);
                    decorateDataclass(super.getDataManager(), workingNode);
                }
            } catch (Exception e) {
                log.error("Bad thing", e);
            }
            return true;
        }
    }

    @Data
    private abstract class ObjectProcessorTaskParent implements Callable<Boolean> {
        private final Iterator<JsonNode> dataClassObjects;
        private final DataClassManager dataManager;

        private ObjectProcessorTaskParent(Iterator<JsonNode> dataClassObjects, DataClassManager dataManager) {
            this.dataClassObjects = dataClassObjects;
            this.dataManager = dataManager;
        }

        private JsonNode getNextObject() {
            synchronized (dataClassObjects) {
                return dataClassObjects.hasNext() ? dataClassObjects.next() : null;
            }
        }
    }

    private class DataClassManager {
        private final Map<RecordType, Map<Integer, JsonNode>> objectDataClassPointers;
//        private final JsonNode rawData;

        public DataClassManager(JsonNode rawData) {
//            this.rawData = rawData;
            this.objectDataClassPointers = new HashMap<>();
            for (RecordType dataClass : RecordType.values()) {
                objectDataClassPointers.put(dataClass, new HashMap<>());
            }
        }
//
//        public JsonNode getRelatedObject(Integer relatedObjectId, RecordType dataClass) {
//            JsonNode foundObject;
//            if ((foundObject = getDataObject(relatedObjectId, dataClass)) == null) {
//                foundObject = findItemById(rawData, relatedObjectId, dataClass);
//                if (foundObject != null) {
//                    putDataObjectIfNotThere(relatedObjectId, getRecordType(foundObject), foundObject);
//                }
//            }
//            return foundObject;
//        }

        private synchronized JsonNode getDataObject(Integer objectId, RecordType dataClassType) {
            Map<Integer, JsonNode> dataClass = objectDataClassPointers.get(dataClassType);
            return dataClass.get(objectId);
        }

//        public void putDataObjectIfNotThere(Integer objectId, RecordType dataClass, JsonNode data) {
//            if (getDataObject(objectId, dataClass) == null) {
//                putDataObject(objectId, dataClass, data);
//            }
//        }

        public synchronized JsonNode putDataObject(Integer objectId, RecordType dataClass, JsonNode data) {
            return objectDataClassPointers.get(dataClass).put(objectId, data);
        }

        public Map<RecordType, Map<Integer, JsonNode>> getObjectDataClassPointers() {
            return objectDataClassPointers;
        }
    }
}
