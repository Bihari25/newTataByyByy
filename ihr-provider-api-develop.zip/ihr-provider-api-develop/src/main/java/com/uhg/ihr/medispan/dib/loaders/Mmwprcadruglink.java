package com.uhg.ihr.medispan.dib.loaders;

/**
*
*/
public class Mmwprcadruglink extends TableLoader {
    
	/**
	 *
	 */
    public Mmwprcadruglink() {
        super();
    }
    
    @Override
    public String getCreateQuery() {
        return
        "CREATE TABLE mmw_prca_druglink " +
        "( " +
            "gpi                         CHARACTER VARYING(14) NOT NULL, " +
            "ageindayslow                INTEGER NOT NULL, " +
            "ageindayshigh               INTEGER NOT NULL, " +
            "restrictionid               INTEGER NOT NULL, " +
            "mgmtlevelcode               CHARACTER VARYING(1) NOT NULL, " +
            "origagelow                  SMALLint NOT NULL, " +
            "origagehigh                 SMALLint NOT NULL, " +
            "origageunitcode             CHARACTER VARYING(1) NOT NULL, " +
            "CONSTRAINT mmw_prca_druglink_pkey PRIMARY KEY (gpi, ageindayslow, ageindayshigh, restrictionid) " +
        ") " +
        "WITH (OIDS=TRUE); ";
    }
    
    @Override
    public String getInsertQuery(String line) {
        String[] fields = line.split("\\|");
        
        return "INSERT INTO mmw_prca_druglink VALUES " +
        "( " +
            "'" + fields[0] + "'," +                //gpi                         CHARACTER VARYING(14) NOT NULL
            Integer.parseInt(fields[1]) + "," +     //ageindayslow                INTEGER NOT NULL
            Integer.parseInt(fields[2]) + "," +     //ageindayshigh               INTEGER NOT NULL
            Integer.parseInt(fields[3]) + "," +     //restrictionid               INTEGER NOT NULL
            "'" + fields[4] + "'," +                //mgmtlevelcode               CHARACTER VARYING(1) NOT NULL
            Integer.parseInt(fields[5]) + "," +     //origagelow                  SMALLint NOT NULL
            Integer.parseInt(fields[6]) + "," +     //origagehigh                 SMALLint NOT NULL
            "'" + fields[7] + "'" +                 //origageunitcode             CHARACTER VARYING(1) NOT NULL
        " ); ";
    }

}
