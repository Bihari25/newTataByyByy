package com.uhg.ihr.provider.api.service.backend.inflator;

import com.mongodb.reactivestreams.client.MongoClient;
import io.reactivex.Flowable;
import io.reactivex.Maybe;
import org.bson.Document;

import javax.inject.Singleton;

import static com.mongodb.client.model.Filters.eq;

@Singleton
public class InflatorMongoClient {

//    @Value("${mongo.database}")
    private String database;
//    @Value("${mongo.collection.transcribed}")
    private String apiCollection;
//    @Value("${mongo.collection.raw}")
    private String rawCollection;
//    @Inject
    private MongoClient mongoClient;

    public Maybe<Document> queryMongoForSinglePaitent(String patientChid) {
        return Flowable
                .fromPublisher(mongoClient.getDatabase(database).getCollection(apiCollection).find(eq("_id", patientChid)).limit(1))
                .firstElement();
    }
}
