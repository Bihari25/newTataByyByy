package com.uhg.ihr.provider.api.security;

import com.google.common.collect.ImmutableSet;
import edu.umd.cs.findbugs.annotations.NonNull;
import io.micronaut.context.annotation.Requires;
import io.micronaut.core.util.StringUtils;
import io.micronaut.http.HttpRequest;
import io.micronaut.http.HttpStatus;
import io.micronaut.http.MutableHttpResponse;
import io.micronaut.http.annotation.Filter;
import io.micronaut.http.filter.OncePerRequestHttpServerFilter;
import io.micronaut.http.filter.ServerFilterChain;
import io.micronaut.security.authentication.Authentication;
import io.micronaut.security.authentication.AuthorizationException;
import lombok.Data;
import lombok.extern.slf4j.Slf4j;
import org.reactivestreams.Publisher;

import javax.inject.Singleton;
import javax.net.ssl.TrustManagerFactory;
import java.io.*;
import java.security.KeyStore;
import java.util.Map;
import java.util.Set;

import static io.micronaut.management.endpoint.EndpointDefaultConfiguration.PATH;

@Slf4j
@Singleton
@Filter("${" + PATH + ":/}**")
@Requires(property = "micronaut.security.stargate.enabled", notEquals = StringUtils.FALSE)
public class StargateJwtFilter extends OncePerRequestHttpServerFilter {
    private static final String DEFAULT_MAGIC_TOKEN = "eyJhbGciOiJSUzUxMiJ9.eyJyb2xlIjoidXNlciIsImNyZWF0ZWQiOjE1MjI4NDk5OTE3OTcsInVzZXJuYW1lIjoiY2xvdWRzZGsifQ.dzfwWRugsnhPHB0RNT9lZHnX7gvNfGks_ivTc_dQ6-ejM6B1-Chx3WrwBE8drdy4ZbvkVTlHkHRSu3nBZi3Aw0wmN5N7UPUI0wP2KhAHGQS4-LOXgD58ioX9ep3k6hZQqy-oJor5Q3wZS8HJKMMY8izIROtJ5z-z5Y2RRw3ONnQLL5JR40hF9d5mFKA8Y1giEP32qg259MVbdkHNkI0ceq8hrXJ7w_OD4-JPteNhM9EeyNOmzjrKSEG-tkYrWI7g5xgvgMuO8iHFym4WhkDT6FNfcK2xs8QfCbJCZqV28xSIjbrm0El0L7kRzJbsKBxQ7FNJ35iaX18DpQMpu6usUQ";
    private static final String MAGIC_TOKEN;

    private static final String KEYSTORE_PATH1 = "configs/stargate-truststore.jks";
    private static final String KEYSTORE_PATH2 = "stargate-truststore.jks";
    private static final Set<String> ENVS = ImmutableSet.of("local", "dev", "gold",  "test", "demo", "stage");
    private static final Boolean LOWER_ENV;
    private static final String JWT_TOKEN = "JWT";
    private static final String PASWD = "StargateTrust";
    private static final CharSequence REJECTION = "micronaut.security.REJECTION";
    //FIXME: remove "/status" when the status endpoint can be retired
    private static final Set<String> HEALTH_ENDPOINTS = ImmutableSet.of("/health", "/info", "/prometheus", "/status");
    private static final String SWAGGER_ENDPOINT = ".*swagger.*";

    private final TrustManagerFactory trustManagerFactory;
    private final StargateJwtValidator validator = new StargateJwtValidator();

    static {
        String myEnv = System.getenv("ENVIRONMENT");
        LOWER_ENV = ENVS.contains(myEnv);
        log.info("found '{}' for the ENVIRONMENT environment variable. magic token is allowed: {}", myEnv, LOWER_ENV);

        String jwtTokenOverride = System.getenv("JWT_MAGIC_TOKEN");
        if (jwtTokenOverride != null && !jwtTokenOverride.isBlank()) {
            MAGIC_TOKEN = jwtTokenOverride;
        }
        else {
            MAGIC_TOKEN = DEFAULT_MAGIC_TOKEN;
        }

    }

    public StargateJwtFilter() {
        InputStream is = null;
        try {
            this.trustManagerFactory = TrustManagerFactory.getInstance(TrustManagerFactory.getDefaultAlgorithm());
            KeyStore ks = KeyStore.getInstance(KeyStore.getDefaultType());
            File file = new File(KEYSTORE_PATH1);
            if (!file.exists()) {
                log.info("could not find keystore at {}, trying {}", KEYSTORE_PATH1, KEYSTORE_PATH2);
                is = this.getClass().getClassLoader().getResourceAsStream(KEYSTORE_PATH2);
                log.info("using keystore at {}", KEYSTORE_PATH2);
            } else {
                is = new FileInputStream(file);
                log.info("using keystore at {}", file.getAbsolutePath());
            }
            ks.load(is, PASWD.toCharArray());
            trustManagerFactory.init(ks);
        } catch (Exception e) {
            throw new RuntimeException("unable to initialize the trustManagerFactory", e);
        } finally {
            try {
                is.close();
            } catch (Exception e) {
                log.error("Error while closing the inputstream {}", e.getMessage());
            }
        }
    }

    @Override
    protected Publisher<MutableHttpResponse<?>> doFilterOnce(HttpRequest<?> request, ServerFilterChain chain) {
        try {
            // allow /info, /health, /prometheus
            if (HEALTH_ENDPOINTS.contains(request.getPath()) || request.getPath().matches(SWAGGER_ENDPOINT)) {
                return chain.proceed(request);
            }

            String stargateJwt = request.getHeaders().get(JWT_TOKEN);
            log.info("Passed in JWT_TOKEN: {}", stargateJwt);
            if (stargateJwt == null || stargateJwt.isEmpty()) {
                throw new StargateJwtException(JWT_TOKEN + " header not found.");
            }
            stargateJwt = stargateJwt.replace("Bearer ", "");
            if (stargateJwt.isEmpty() || stargateJwt.equals("null")) {
                throw new StargateJwtException(JWT_TOKEN + " token not found.");
            }

            if (!MAGIC_TOKEN.equals(stargateJwt) || !LOWER_ENV) {
                validator.validate(stargateJwt, new ByteArrayInputStream(request.getBody().toString().getBytes()), trustManagerFactory);
            }
        } catch (Exception e) {
            if (e instanceof StargateJwtException) {
                log.info("jwt token validation failed: {}", e.getMessage());
            } else {
                log.info("error processing jwt: {}", e.getMessage());
            }
            request.setAttribute(REJECTION, HttpStatus.UNAUTHORIZED);
            throw new AuthorizationException(new JWTAuthentication(request.getHeaders().get(JWT_TOKEN)));
        }

        return chain.proceed(request);
    }

    @Data
    public class JWTAuthentication implements Authentication {

        private String jwtToken;

        private JWTAuthentication() {
            this.jwtToken = "No token provided";
        }

        public JWTAuthentication(String jwtToken) {
            this.jwtToken = jwtToken == null || jwtToken.isBlank() ? "No token provided" : jwtToken;
        }

        /**
         * In order to correctly implement the {@link Serializable} specification, this map
         * should be {@literal Map<String, Serializable>}, however that would place a burden on
         * those not requiring serialization, forcing their values to conform to that spec.
         * <p>
         * This is left intentionally as Object in order to meet both use cases and those
         * requiring serialization must ensure all values in the map implement {@link Serializable}.
         *
         * @return Any additional attributes in the authentication
         */
        @NonNull
        public Map<String, Object> getAttributes() {
            return Map.of("JWT", jwtToken);
        }

        /**
         * Compares this principal to the specified object.  Returns true
         * if the object passed in matches the principal represented by
         * the implementation of this interface.
         *
         * @param another principal to compare with.
         * @return true if the principal passed in is the same as that
         * encapsulated by this principal, and false otherwise.
         */
        public boolean equals(Object another) {
            if (another instanceof JWTAuthentication) {
                return ((JWTAuthentication) another).getJwtToken().equals(this.jwtToken);
            } else {
                return false;
            }
        }

        /**
         * Returns a string representation of this principal.
         *
         * @return a string representation of this principal.
         */
        public String toString() {
            return "JWT Token: " + jwtToken;
        }

        /**
         * Returns a hashcode for this principal.
         *
         * @return a hashcode for this principal.
         */
        public int hashCode() {
            return jwtToken.hashCode();
        }

        /**
         * Returns the name of this principal.
         *
         * @return the name of this principal.
         */
        public String getName() {
            return "JWT token";
        }
    }
}