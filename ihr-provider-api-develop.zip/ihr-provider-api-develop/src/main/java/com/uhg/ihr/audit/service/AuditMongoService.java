/**
 * Copyright (C) 2020 UnitedHealth Group
 * <p>
 * All rights reserved.
 */
package com.uhg.ihr.audit.service;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ObjectNode;
import com.mongodb.reactivestreams.client.MongoClient;
import com.uhg.ihr.audit.Audit;
import io.micronaut.context.annotation.Value;
import io.reactivex.Flowable;
import lombok.extern.slf4j.Slf4j;
import org.bson.Document;

import javax.inject.Inject;
import javax.inject.Named;
import javax.inject.Singleton;
import java.io.IOException;
import java.util.Arrays;

/**
 * @author Anurag Singh
 * @version 1.0
 */
@Slf4j
@Singleton
public class AuditMongoService {

    private static final ObjectMapper MAPPER = new ObjectMapper();

    @Value("${mongoportal.database}")
    private String database;

    @Value("${mongoportal.collection.audit}")
    private String auditCollection;

    @Inject
    @Named("mongoportal")
    private MongoClient mongoClient;

    public void saveAudit(Audit audit) throws IOException {
        if (log.isDebugEnabled()) {
            log.debug("Saving Audit to Mongo - " + audit);
        }

        // manual build document here in order to simplify date processing
        Document auditDoc = new Document()
                .append("date", audit.getDate())
                .append("type", Arrays.asList(audit.getType()));

        JsonNode jsNode = null;
        if ((jsNode = audit.getCommon()) != null && !jsNode.isNull()) {
            auditDoc.append("common", Document.parse(MAPPER.writeValueAsString(jsNode)));
        }
        if ((jsNode = audit.getDetails()) != null && !jsNode.isNull()) {
            auditDoc.append("details", Document.parse(MAPPER.writeValueAsString(jsNode)));
        }

        Flowable
                .fromPublisher(
                        mongoClient
                                .getDatabase(database)
                                .getCollection(auditCollection)
                                .insertOne(auditDoc)
                              )
                .firstElement()
                .ignoreElement()
                .subscribe();
    }
}


