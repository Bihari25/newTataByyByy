package com.uhg.ihr.provider.api.model.profile;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.uhg.ihr.provider.api.model.Id;
import com.uhg.ihr.provider.api.model.MemberAddress;
import com.uhg.ihr.provider.api.model.MemberName;
import com.uhg.ihr.provider.api.util.AppUtils;
import com.uhg.ihr.provider.api.validator.ValidDate;
import lombok.*;

import javax.validation.constraints.Email;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import static com.uhg.ihr.provider.api.model.profile.UserProfileConstant.IDENTIFIER_CONTEXT;

@Data
@Builder(toBuilder = true)
@AllArgsConstructor
@NoArgsConstructor
@JsonInclude(JsonInclude.Include.NON_EMPTY)
@EqualsAndHashCode(callSuper = false)
public class IhrUser {
    private MemberName name;
    @Email
    private String email;
    private String npi;

    @ValidDate
    private String dateOfBirth;
    private String gender;
    private List<MemberAddress> addresses;
    private List<UserPhone> phones;
    private List<Id> identifiers;

    private UserProfileConstant.STATUS status;
    private UserProfileConstant.USER_TYPE userType;

    private Map<IDENTIFIER_CONTEXT, String> identifierContexts;
    private List<UserPermission> userPermissions;
    private List<AgreementAcceptance> agreements;

    /**
     * Adds the specified identifier to the user.
     *
     * @param context The identifier to be added
     * @param value   The value to be associated with the provided context
     */
    public void addIdentifierContext(IDENTIFIER_CONTEXT context, String value) {
        if (identifierContexts == null) {
            identifierContexts = new HashMap<>();
        }
        identifierContexts.put(context, value);
    }

    /**
     * Returns the identifier for the specified context.
     *
     * @param context The context for which the identifier is to be retrieved.
     */
    public String getIdentifierContextValue(IDENTIFIER_CONTEXT context) {
        return identifierContexts != null ? identifierContexts.get(context) : null;
    }

//    /**
//     * Returns the identifier for the specified context.
//     *
//     * @param context The context for which the identifier is to be retrieved.
//     */
//    public IdentifierContext getIdentifierContext(UserProfileConstant.IDENTIFIER_CONTEXT context) {
//        IdentifierContext rtnContext = null;
//        if (identifierContexts != null && !identifierContexts.isEmpty()) {
//            rtnContext
//                    = identifierContexts.stream()
//                    .filter(id -> id.getContextType() == context)
//                    .findFirst().orElse(null);
//        }
//        return rtnContext;
//    }

    /**
     * Returns whether or not the user is active.
     */
    @JsonIgnore
    public boolean isActive() {
        return status == UserProfileConstant.STATUS.ACTIVE;
    }

    /**
     * Returns whether or not this user is a staff user.
     */
    @JsonIgnore
    public boolean isStaff() {
        return userType == UserProfileConstant.USER_TYPE.STAFF;
    }

    /**
     * Returns whether or not this user is a provider user.
     */
    @JsonIgnore
    public boolean isProvider() {
        return userType == UserProfileConstant.USER_TYPE.PROVIDER;
    }

    /**
     * Returns whether or not this user is a individual user.
     */
    @JsonIgnore
    public boolean isIndividual() {
        return userType == UserProfileConstant.USER_TYPE.INDIVIDUAL;
    }

    /**
     * This method combines the data from this instantiated IhrUser with a passed IhrUser. Data in this instantiated IhrUser
     * is considered immutable and is only added to and not overwritten. Finally NO USER EQUALITY IS PERFORMED! If the
     * IhrUsers are two different persons then it will still combine the users, equality checks should be performed outside of this tool.
     * @param extraUserData The additional data to add to this user
     */
    public void combineIhrUsers(IhrUser extraUserData) {
        if (this.getName() == null) {
            this.setName(extraUserData.getName());
        }
        if (this.getEmail() == null || this.getEmail().isBlank()) {
            this.setEmail(extraUserData.getEmail());
        }
        if (this.getNpi() == null || this.getNpi().isBlank()) {
            this.setNpi(extraUserData.getNpi());
        }
        if (this.getGender() == null || this.getGender().isBlank()) {
            this.setGender(extraUserData.getGender());
        }
        if (this.getDateOfBirth() == null || this.getDateOfBirth().isBlank()) {
            this.setDateOfBirth(extraUserData.getDateOfBirth());
        }
        if (this.getStatus() == null) {
            this.setStatus(extraUserData.getStatus());
        }
        if (this.getUserType() == null) {
            this.setUserType(extraUserData.getUserType());
        }
        if (this.getAddresses() == null || this.getAddresses().isEmpty()) {
            this.setAddresses(AppUtils.combineLists(this.getAddresses(), extraUserData.getAddresses()));
        }
        if (this.getPhones() == null || this.getPhones().isEmpty()) {
            this.setPhones(AppUtils.combineLists(this.getPhones(), extraUserData.getPhones()));
        }
        if (this.getIdentifiers() == null || this.getIdentifiers().isEmpty()) {
            this.setIdentifiers(AppUtils.combineLists(this.getIdentifiers(), extraUserData.getIdentifiers()));
        }
        if (this.getIdentifierContexts() == null || this.getIdentifierContexts().isEmpty()) {
            this.setIdentifierContexts(AppUtils.combineMaps(this.getIdentifierContexts(), extraUserData.getIdentifierContexts()));
        }
        if (this.getUserPermissions() == null || this.getUserPermissions().isEmpty()) {
            this.setUserPermissions(AppUtils.combineLists(this.getUserPermissions(), extraUserData.getUserPermissions()));
        }
        if (this.getAgreements() == null || this.getAgreements().isEmpty()) {
            this.setAgreements(AppUtils.combineLists(this.getAgreements(), extraUserData.getAgreements()));
        }
    }
}
