package com.uhg.ihr.medispan.dib.loaders;

/**
*
*/
public class Mmwiptshapepal extends TableLoader {
    
	/**
	 *
	 */
    public Mmwiptshapepal() {
        super();
    }
    
    @Override
    public String getCreateQuery() {
        return
        "CREATE TABLE mmw_ipt_shapepal " +
        "( " +
            "paletteid                   SMALLINT NOT NULL, " +
            "description                 CHARACTER VARYING(30) NOT NULL, " +
            "CONSTRAINT mmw_ipt_shapepal_pkey PRIMARY KEY (paletteid) " +
        ") " +
        "WITH (OIDS=TRUE); ";
    }
    
    @Override
    public String getInsertQuery(String line) {
        String[] fields = line.split("\\|");
        
        return "INSERT INTO mmw_ipt_shapepal VALUES " +
        "( " +
            Integer.parseInt(fields[0]) + "," +     //paletteid         SMALLINT NOT NULL
            "'" + fields[1] + "'" +                 //description       CHARACTER VARYING(30) NOT NULL
        " ); ";
    }

}
