package com.uhg.ihr.medispan.dib.loaders;

/**
*
*/
public class Mmwdirpidlink extends TableLoader {
    
	/**
	 *
	 */
    public Mmwdirpidlink() {
        super();
    }
    
    @Override
    public String getCreateQuery() {
        return
        "CREATE TABLE mmw_di_rpidlink " +
        "( " +
            "kdc1                        CHARACTER VARYING(5) NOT NULL, " +
            "nametypecode                CHARACTER VARYING(1) NOT NULL, " +
            "rpid                        INTEGER NOT NULL, " +
            "description                 CHARACTER VARYING(65) NULL, " +
            "actcode                     CHARACTER VARYING(1) NULL, " +
            "CONSTRAINT mmw_di_rpidlink_pkey PRIMARY KEY (kdc1, nametypecode, rpid) " +
        ") " +
        "WITH (OIDS=TRUE); ";
    }
    
    @Override
    public String getInsertQuery(String line) {
        String[] fields = line.split("\\|");
        
        return "INSERT INTO mmw_di_rpidlink VALUES " +
        "( " +
            "'" + fields[0] + "'," +                    //kdc1                        CHARACTER VARYING(5) NOT NULL
            "'" + fields[1] + "'," +                    //nametypecode                CHARACTER VARYING(1) NOT NULL
            Integer.parseInt(fields[2]) + "," +         //rpid                        INTEGER NOT NULL
            (fields.length < 4 || fields[3].isEmpty() ? "NULL" : "'" + fields[3].replace("'", "''") + "'") + "," +     //description   CHARACTER VARYING(65) NULL
            (fields.length < 5 || fields[4].isEmpty() ? "NULL" : "'" + fields[4].replace("'", "''") + "'") +           //actcode       CHARACTER VARYING(1) NULL
        " ); ";
    }

}
