package com.uhg.ihr.medispan.dib.loaders;

/**
*
*/
public class Mmwiptcolor extends TableLoader {
    
	/**
	 *
	 */
    public Mmwiptcolor() {
        super();
    }
    
    @Override
    public String getCreateQuery() {
        return
        "CREATE TABLE mmw_ipt_color " +
        "( " +
            "colorid                     SMALLINT NOT NULL, " +
            "description                 CHARACTER VARYING(30) NOT NULL, " +
            "paletteid                   SMALLint NOT NULL, " +
            "CONSTRAINT mmw_ipt_color_pkey PRIMARY KEY (colorid) " +
        ") " +
        "WITH (OIDS=TRUE); ";
    }
    
    @Override
    public String getInsertQuery(String line) {
        String[] fields = line.split("\\|");
        
        return "INSERT INTO mmw_ipt_color VALUES " +
        "( " +
            Integer.parseInt(fields[0]) + "," +     //colorid           SMALLINT NOT NULL
            "'" + fields[1] + "'," +                //description       CHARACTER VARYING(30) NOT NULL
            Integer.parseInt(fields[2]) +           //paletteid         SMALLint NOT NULL
        " ); ";
    }

}
