package com.uhg.ihr.medispan.dib.loaders;

/**
*
*/
public class Mmwduptext extends TableLoader {
    
	/**
	 *
	 */
    public Mmwduptext() {
        super();
    }
    
    @Override
    public String getCreateQuery() {
        return
        "CREATE TABLE mmw_dup_text " +
        "( " +
            "dtcid                       CHARACTER VARYING(8) NOT NULL, " +
            "description                 CHARACTER VARYING(40) NOT NULL, " +
            "potentialabusecode          CHARACTER VARYING(1) NOT NULL, " +
            "dupallowance                SMALLint NOT NULL, " +
            "CONSTRAINT mmw_dup_text_pkey PRIMARY KEY (dtcid) " +
        ") " +
        "WITH (OIDS=TRUE); ";
    }
    
    @Override
    public String getInsertQuery(String line) {
        String[] fields = line.split("\\|");
        
        return "INSERT INTO mmw_dup_text VALUES " +
        "( " +
            "'" + fields[0] + "'," +                        //dtcid                       CHARACTER VARYING(8) NOT NULL
            "'" + fields[1].replace("'", "''") + "'," +     //description                 CHARACTER VARYING(40) NOT NULL
            "'" + fields[2] + "'," +                        //potentialabusecode          CHARACTER VARYING(1) NOT NULL
            Integer.parseInt(fields[3]) +                   //dupallowance                SMALLint NOT NULL
        " ); ";
    }

}
