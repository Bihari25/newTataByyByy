package com.uhg.ihr.provider.api.model;

public interface IModel {
    String MULT_IDS = "ID search found multiple members with this ID information.";
    String NO_BIG3_IDS = "ID search found no member with this Big 3 ID information.";
    String NO_IDS = "ID search found no member with this ID information.";
    String POLICYNUM = "Pol_Num";
    String SSN = "SSN";
}
