package com.uhg.ihr.medispan.dib.loaders;

/**
*
*/
public class Mmwdrugdispimg extends TableLoader {
    
	/**
	 *
	 */
    public Mmwdrugdispimg() {
        super();
    }
    
    @Override
    public String getCreateQuery() {
        return
        "CREATE TABLE mmw_drug_disp_img " +
        "( " +
            "ddid                        INTEGER NOT NULL, " +
            "labelerid                   CHARACTER VARYING(5) NOT NULL, " +
            "imagefilename               CHARACTER VARYING(8) NOT NULL, " +
            "refrepackcode               CHARACTER VARYING(1) NOT NULL, " +
            "CONSTRAINT mmw_drug_disp_img_pkey PRIMARY KEY (ddid, labelerid, imagefilename) " +
        ") " +
        "WITH (OIDS=TRUE); ";
    }
    
    @Override
    public String getInsertQuery(String line) {
        String[] fields = line.split("\\|");
        
        return "INSERT INTO mmw_drug_disp_img VALUES " +
        "( " +
            Integer.parseInt(fields[0]) + "," +         //ddid                        INTEGER NOT NULL
            "'" + fields[1] + "'," +                    //labelerid                   CHARACTER VARYING(5) NOT NULL
            "'" + fields[2] + "'," +                    //imagefilename               CHARACTER VARYING(8) NOT NULL
            "'" + fields[3] + "'" +                     //refrepackcode               CHARACTER VARYING(1) NOT NULL
        " ); ";
    }

}
