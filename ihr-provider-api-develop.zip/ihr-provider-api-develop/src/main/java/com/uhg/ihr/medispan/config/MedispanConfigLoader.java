/**
 * Copyright (C) 2020 UnitedHealth Group
 * <p>
 * All rights reserved.
 */
package com.uhg.ihr.medispan.config;

import io.micronaut.context.annotation.Property;
import io.micronaut.context.event.ApplicationEventListener;
import io.micronaut.discovery.event.ServiceReadyEvent;
import lombok.Data;
import medispan.configuration.ConfigManager;
import medispan.configuration.ConfigSource;
import medispan.exceptions.ConfigFileException;

import javax.inject.Singleton;
import java.util.List;
import java.util.Map;
import java.util.Properties;

/**
 * A configuration loader that overrides the Medispan API default requirement of using an
 * XML file to configure it's database configuration.  This loader allows us to initialize
 * the Medispan configuration from the Application configuration.
 *
 * @author Kristopher T Babic
 * @version 1.0
 */
@Singleton
@Data
public class MedispanConfigLoader implements ApplicationEventListener<ServiceReadyEvent> {
    @Property(name="medispan.config")
    private List<Map<String, String>> config;
    @Property(name="medispan.name-space")
    private String nameSpace;

    @Override
    public void onApplicationEvent(ServiceReadyEvent event) {
        if (config != null && nameSpace != null) {
            // intialize the ConfigSource and register it with the ConfigManager
            ConfigSource configSource = new ConfigSource(nameSpace, false);
            try {
                // this will load a default <namespace>.xml file, which is empty be default
                ConfigManager.loadConfig(configSource);
            }
            catch (ConfigFileException ce) {
                System.err.println(ce);
                ce.printStackTrace();
            }

            // override the configuration which was stored in the ConfigManager by building a
            // config Properties object based on the application config settings.
            Properties configProps = new Properties();
            config.stream().forEach(cMap -> {
                if (!cMap.isEmpty()) {
                    cMap.keySet().stream().forEach(key -> {
                        configProps.setProperty(key, cMap.get(key));
                    });
                }
            });

            configSource.setProperties(configProps);
        }
    }
}
