/**
 * Copyright (C) 2020 UnitedHealth Group
 * <p>
 * All rights reserved.
 */
package com.uhg.ihr.audit.consumer;

import com.uhg.ihr.audit.Audit;
import com.uhg.ihr.audit.service.AuditMongoService;
import io.micronaut.configuration.kafka.annotation.KafkaListener;
import io.micronaut.configuration.kafka.annotation.OffsetReset;
import io.micronaut.configuration.kafka.annotation.Topic;
import io.micronaut.context.annotation.Requires;
import io.micronaut.core.util.StringUtils;
import io.reactivex.Flowable;
import lombok.extern.slf4j.Slf4j;

import javax.inject.Inject;

/**
 * @author Anurag Singh
 * @version 1.0
 */
@Slf4j
@KafkaListener(offsetReset = OffsetReset.EARLIEST, threads = 5, groupId = "${audit.topic}_audit_writer")
@Requires(property = "audit.consumer.writer.enabled", value = StringUtils.TRUE)
@Requires(property = "audit.enabled", value = StringUtils.TRUE)
public class AuditWriterListener {
    @Inject
    private AuditMongoService auditMongoService;

    @Topic("${audit.topic}")
    public Flowable<Audit> receive(Flowable<Audit> auditFlowable) {
        return auditFlowable.doOnNext(audit -> {
                auditMongoService.saveAudit(audit);
        });
    }

}