package com.uhg.ihr.provider.api.service;

import com.fasterxml.jackson.databind.JsonNode;
import com.uhg.ihr.provider.api.model.GlobalHealthObjectId;
import com.uhg.ihr.provider.api.model.ProviderApiHeaders;
import com.uhg.ihr.provider.api.model.RecordType;
import io.reactivex.Maybe;

import java.util.Map;
import java.util.Set;

public interface DataServiceInterface {
    Maybe<Map<RecordType, Map<Integer, JsonNode>>> getAllByActorChid(final String providerChid, final String patientChid, final ProviderApiHeaders headers);

    Maybe<JsonNode> getFilteredByActorChid(final String providerChid, final String patientChid, final Set<RecordType> dataClasses, final ProviderApiHeaders headers);

    Maybe<JsonNode> getGlobalItemByActorChid(final String providerChid, final String patientChid, final GlobalHealthObjectId itemId, final ProviderApiHeaders headers);

    Maybe<JsonNode> getItemByActorChid(final String providerChid, final String patientChid, final RecordType dataclass, final int itemId, final ProviderApiHeaders headers);
}
