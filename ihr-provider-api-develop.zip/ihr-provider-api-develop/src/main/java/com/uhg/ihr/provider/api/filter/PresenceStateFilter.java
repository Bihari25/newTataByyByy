package com.uhg.ihr.provider.api.filter;

import com.fasterxml.jackson.databind.JsonNode;
import com.uhg.ihr.provider.api.exception.IhrBadRequestException;
import com.uhg.ihr.provider.api.util.AppUtils;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Objects;

/**
 * PresenceStateFilter used to filter data content of dataclass for given presence states.
 *
 * @author ihr extract engineering team.
 * @CopyRight (C) All rights reserved to UHG Inc. It's Illegal to reproduce this code.
 */
@Slf4j
public class PresenceStateFilter implements DataFilter {
    //TODO move to yaml file as configuration.
    private static final String REFERENCE_PRESENCE_STATES = "Present, Not Present, Past Occurrence, Planned Occurrence";

    public List<String> presenceStates;

    public PresenceStateFilter(String presenceState) {
        /* Validate presence state value is null or empty. */
        if (StringUtils.isBlank(presenceState)) {
            throw new IhrBadRequestException("PresenceState value can't be null or empty");
        }

        /* Validate requested presence state value is valid or not. */
        this.presenceStates = Arrays.asList(presenceState.split("\\s*,\\s*"));
        validatePresenceState();
    }

    @Override
    public boolean filter(JsonNode dataNode) {
        String presenceState;

        /* Validate to handle  data structure requests which don't have presence state term. */
        JsonNode presenceStateTermNode = dataNode.get(AppUtils.PRESENCE_STATE_TERM);
        if (Objects.isNull(presenceStateTermNode)) {
            log.warn("There is no presence state term field in the data node");
            return false;
        } else {
            presenceState = presenceStateTermNode.textValue();
        }

        /* Validate given input present states exists or not. */
        boolean isPresenceState = StringUtils.isBlank(presenceState) || this.presenceStates.contains(presenceState);
        return isPresenceState;
    }

    /**
     * Method to validate given presence state is valid value or not.
     */
    private void validatePresenceState() {
        List<String> presentStateTypes = Arrays.asList(REFERENCE_PRESENCE_STATES.split("\\s*,\\s*"));
        List<Boolean> isAnyPresenceStates = new ArrayList<>();

        /* Iterate and validate requested presence state filter value with reference presence state values. */
        for (String requestedPresentState : this.presenceStates) {
            boolean isValuePresent = presentStateTypes.contains(requestedPresentState);

            /* Keep track on the requested present state filter values. */
            if (!isValuePresent) {
                isAnyPresenceStates.add(false);
            }
        }

        /* Validate requested presence state filters are not matching any of the presence state types. */
        if (isAnyPresenceStates.size() == this.presenceStates.size()) {
            throw new IhrBadRequestException("Requested presence state filter values are invalid");
        }
    }

}
