package com.uhg.ihr.provider.api.service.backend.b50;

import io.micronaut.http.HttpStatus;
import io.micronaut.http.client.exceptions.HttpClientResponseException;
import io.micronaut.retry.annotation.RetryPredicate;
import lombok.extern.slf4j.Slf4j;

import java.util.Collections;
import java.util.List;
import java.util.regex.Pattern;

@Slf4j
public class B50ApiRetryPredicate implements RetryPredicate {

    private static final String RETRY_STATUS_REGEX_ENV = "RETRY_EXCLUDE_HTTP_STATUS";
    private static final String DEFAULT_HTTP_PATTERN = "5[0-9][0-9]";
    private Pattern statusPattern;
    private final List<Class<? extends Throwable>> includes;
    private final List<Class<? extends Throwable>> excludes;
    private final boolean hasIncludes;
    private final boolean hasExcludes;

    /**
     * @param includes Classes to include for retry
     * @param excludes Classes to exclude for retry
     */
    public B50ApiRetryPredicate(List<Class<? extends Throwable>> includes, List<Class<? extends Throwable>> excludes) {
        this.includes = includes;
        this.excludes = excludes;
        this.hasIncludes = !includes.isEmpty();
        this.hasExcludes = !excludes.isEmpty();
        buildExcludeStatusPattern();
    }

    /**
     * Default constructor.
     */
    public B50ApiRetryPredicate() {
        this(Collections.emptyList(), List.of(HttpClientResponseException.class));
    }

    public void buildExcludeStatusPattern() {
        String statusRegex = System.getenv(RETRY_STATUS_REGEX_ENV);
        if (statusRegex == null || statusRegex.isBlank()) {
            statusPattern = Pattern.compile(DEFAULT_HTTP_PATTERN);
        } else {
            statusPattern = Pattern.compile(statusRegex);
        }
    }

    @Override
    public boolean test(Throwable exception) {
        if (hasIncludes && includes.stream().noneMatch(cls -> cls.isInstance(exception))) {
            return false;
        } else {
            boolean inExcludes = hasExcludes && excludes.stream().anyMatch(cls -> cls.isInstance(exception));
            if (inExcludes && exception instanceof HttpClientResponseException) {
                HttpStatus responseStatus = ((HttpClientResponseException) exception).getStatus();
                boolean retryThisRequest = statusPattern.matcher("" + responseStatus.getCode()).matches();
                return retryThisRequest;
            } else {
                return !inExcludes;
            }
        }
    }
}
