package com.uhg.ihr.provider.api.validator;

import com.uhg.ihr.provider.api.model.RecordType;

import javax.validation.ConstraintValidator;
import javax.validation.ConstraintValidatorContext;

import java.util.Arrays;
import java.util.stream.Collectors;
import java.util.Set;

public class ValidRecordTypeValidator implements ConstraintValidator<ValidRecordType, Set<RecordType>> {
    private static final Set<RecordType> RECORD_TYPES = Arrays.stream(RecordType.values()).collect(Collectors.toSet());

    @Override
    public boolean isValid(Set<RecordType> value, ConstraintValidatorContext constraintValidatorContext) {
        if (value == null || value.isEmpty()) {
            return false;
        }
        boolean isSubset = RECORD_TYPES.containsAll(value);
        if (!isSubset) {
            return false;
        }
        boolean isUnique = value.size() == value.stream().distinct().count();
        if (!isUnique) {
            return false;
        }
        return true;
    }
}