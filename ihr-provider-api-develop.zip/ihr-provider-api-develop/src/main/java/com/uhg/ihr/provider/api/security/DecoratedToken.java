package com.uhg.ihr.provider.api.security;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;

/**
 * DecoratedToken class used in senzing token helper.
 *
 * @author ihr extract engineering team.
 * @CopyRight (C) All rights reserved to UHG Inc. It's Illegal to reproduce this code.
 */
@Data
@AllArgsConstructor
@NoArgsConstructor
@JsonPropertyOrder({"sub","iss","aud","iat","exp","roles","token"})
public class DecoratedToken {

    private String sub;
    private String iss;
    private String aud;

    @JsonFormat(shape=JsonFormat.Shape.STRING, pattern="dd-MM-yyyy hh:mm:ss")
    private Date iat;
    @JsonFormat(shape=JsonFormat.Shape.STRING, pattern="dd-MM-yyyy hh:mm:ss")
    private Date exp;

    private List<String> roles = new ArrayList<>();
    private String token;

}