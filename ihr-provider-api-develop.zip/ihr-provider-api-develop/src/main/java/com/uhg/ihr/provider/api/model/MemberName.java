package com.uhg.ihr.provider.api.model;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.validation.constraints.NotBlank;

@Data
@Builder(toBuilder = true)
@AllArgsConstructor
@NoArgsConstructor
@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({"first","middle", "last"})
public class MemberName {
    @JsonProperty
    @NotBlank(message = "The request could not be validated. A member first name.")
    private String first;

    @JsonProperty
    private String middle;

    @JsonProperty
    @NotBlank(message = "The request could not be validated. A member last name.")
    private String last;

    @JsonIgnore
    public boolean isEmpty() {
        return (first == null || first.isBlank())
                && (middle == null || middle.isBlank())
                && (last == null || last.isBlank());
    }
}
