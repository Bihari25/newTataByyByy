package com.uhg.ihr.provider.api.rest;

import io.micronaut.runtime.Micronaut;
import io.swagger.v3.oas.annotations.OpenAPIDefinition;
import io.swagger.v3.oas.annotations.enums.SecuritySchemeType;
import io.swagger.v3.oas.annotations.extensions.Extension;
import io.swagger.v3.oas.annotations.extensions.ExtensionProperty;
import io.swagger.v3.oas.annotations.info.Contact;
import io.swagger.v3.oas.annotations.info.Info;
import io.swagger.v3.oas.annotations.security.*;
import io.swagger.v3.oas.annotations.servers.Server;

@OpenAPIDefinition(
        info = @Info(
                title = "IHR Provider API",
                version = "1.0",
                description = "The IHR Provider API allows registered provider applications to access data contained " +
                        "within a consolidated Individual Health Record for a UnitedHealth Care member with " +
                        "Medical, Dental and Pharmacy.",
                termsOfService = "https://www.optumdeveloper.com/content/odv-optumdev/optum-developer/en/legal-terms/terms-of-use.html",
                contact = @Contact(url = "https://github.optum.com/IHR/ihr-provider-api",
                        name = "IHR Provider API Support", email = "IHR_PROVIDER_API_SUPPORT_DL@ds.uhc.com")
        ),
        servers = {
                @Server(
                        url = "https://gateway-dmz.optum.com/app/ihr-provider",
                        description = "IHR Provider API - App - Prod"
                )
//                , @Server(
//                          url = "https://gateway-dmz.optum.com/app/dev/ihr-provider",
//                          description = "IHR Provider API - App - Dev"
//                )
//                , @Server(
//                          url = "https://gateway-dmz.optum.com/app/gold/ihr-provider",
//                          description = "IHR Provider API - App - Gold"
//                )
//                , @Server(
//                          url = "https://gateway-dmz.optum.com/app/test/ihr-provider",
//                          description = "IHR Provider API - App - Test"
//                )
//                , @Server(
//                          url = "https://gateway-dmz.optum.com/app/stage/ihr-provider",
//                          description = "IHR Provider API - App - Stage"
//                )
//                , @Server(
//                          url = "https://gateway-dmz.optum.com/app/demo/ihr-provider",
//                          description = "IHR Provider API - App - Demo"
//                )
        },
        extensions = {
                @Extension(
                        name = "serviceLevelObjectives",
                        properties = {
                                @ExtensionProperty(name = "x-availability", value = "99.9")
                                , @ExtensionProperty(name = "x-expectedMsgsPerDay", value = "10000")
                                , @ExtensionProperty(name = "x-maxMsgsPerHour", value = "2000")
                                , @ExtensionProperty(name = "x-responseTime", value = "9000")
                                , @ExtensionProperty(name = "x-throughput", value = "30")
                                , @ExtensionProperty(name = "x-maxPayloadSize", value = "8")
                        }
                ),
                @Extension(
                        name = "",
                        properties = @ExtensionProperty(name="domain", value="app")
                )
        },
        security = {
                @SecurityRequirement(
                        name = "oauth2Scheme"
                )
//                ,
//                @SecurityRequirement(
//                        name = "oauth2Scheme-nonprod-dmz"
//                )
//                ,
//                @SecurityRequirement(
//                        name = "oauth2Scheme-nonprod-core"
//                )
        }
)
@SecuritySchemes({
        @SecurityScheme(
                name = "oauth2Scheme",
                type = SecuritySchemeType.OAUTH2,
                description = "Production OAuth2 API Security",
                flows = @OAuthFlows(
                        clientCredentials = @OAuthFlow(
                                tokenUrl = "https://gateway-dmz.optum.com/auth/oauth2/cached/token"
                        )
                )
        ),
        @SecurityScheme(
                name = "oauth2Scheme-nonprod-dmz",
                type = SecuritySchemeType.OAUTH2,
                description = "Non-Prod OAuth2 API Security for DMZ",
                flows = @OAuthFlows(
                        clientCredentials = @OAuthFlow(
                                tokenUrl = "https://gateway-stage-dmz.optum.com/auth/oauth2/cached/token"
                        )
                )
        )
        ,
        @SecurityScheme(
                name = "oauth2Scheme-nonprod-core",
                type = SecuritySchemeType.OAUTH2,
                description = "Non-Prod OAuth2 API Security for core",
                flows = @OAuthFlows(
                        clientCredentials = @OAuthFlow(
                                tokenUrl = "https://gateway-stage-core.optum.com/auth/oauth2/cached/token"
                        )
                )
        )

})
public class Application {
    public static void main(String[] args) {
        Micronaut.run(Application.class);
    }
}