package com.uhg.ihr.provider.api.model;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.validation.Valid;
import javax.validation.constraints.NotNull;
import java.util.Set;

@Data
@Builder(toBuilder = true)
@AllArgsConstructor
@NoArgsConstructor
public class SearchRequestCriteria {
    @JsonProperty
    @Valid
    private Set<FilterPair> overrides; // disable relationship search or client

    @JsonProperty
    @NotNull(message="The portal search demographic record may not be null.")
    @Valid
    private SearcRequestMemberDemographic mbrDemographics;
}
