package com.uhg.ihr.medispan.dib.loaders;

/**
*
*/
public class Mmwwltext extends TableLoader {
    
	/**
	 *
	 */
    public Mmwwltext() {
        super();
    }
    
    @Override
    public String getCreateQuery() {
        return
        "CREATE TABLE mmw_wl_text " +
        "( " +
            "versioncode                 CHARACTER VARYING(10) NOT NULL, " +
            "wlid                        CHARACTER VARYING(6) NOT NULL, " +
            "sequencenumber              SMALLINT NOT NULL, " +
            "linetext                    CHARACTER VARYING(100) NOT NULL, " +
            "CONSTRAINT mmw_wl_text_pkey PRIMARY KEY (versioncode, wlid, sequencenumber) " +
        ") " +
        "WITH (OIDS=TRUE); ";
    }
    
    @Override
    public String getInsertQuery(String line) {
        String[] fields = line.split("\\|");
        
        return "INSERT INTO mmw_wl_text VALUES " +
        "( " +
            "'" + fields[0] + "'," +                    //versioncode                 CHARACTER VARYING(10) NOT NULL
            "'" + fields[1] + "'," +                    //wlid                        CHARACTER VARYING(6) NOT NULL
            Integer.parseInt(fields[2]) + "," +         //sequencenumber              SMALLINT NOT NULL
            "'" + fields[3].replace("'", "''") + "'" +  //linetext                    CHARACTER VARYING(100) NOT NULL
        " ); ";
    }

}
