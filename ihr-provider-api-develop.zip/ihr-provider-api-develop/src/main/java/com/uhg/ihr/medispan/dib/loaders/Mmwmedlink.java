package com.uhg.ihr.medispan.dib.loaders;

/**
*
*/
public class Mmwmedlink extends TableLoader {
    
	/**
	 *
	 */
    public Mmwmedlink() {
        super();
    }
    
    @Override
    public String getCreateQuery() {
        return
        "CREATE TABLE mmw_med_link " +
        "( " +
            "mcid                        INTEGER NOT NULL, " +
            "relatedmcid                 INTEGER NOT NULL, " +
            "relationtypecode            CHARACTER VARYING(2) NOT NULL, " +
            "directioncode               CHARACTER VARYING(1) NOT NULL, " +
            "distance                    SMALLint NOT NULL, " +
            "CONSTRAINT mmw_med_link_pkey PRIMARY KEY (mcid, relatedmcid) " +
        ") " +
        "WITH (OIDS=TRUE); ";
    }
    
    @Override
    public String getInsertQuery(String line) {
        String[] fields = line.split("\\|");
        
        return "INSERT INTO mmw_med_link VALUES " +
        "( " +
            Integer.parseInt(fields[0]) + "," +     //mcid                        INTEGER NOT NULL
            Integer.parseInt(fields[1]) + "," +     //relatedmcid                 INTEGER NOT NULL
            "'" + fields[2] + "'," +                //relationtypecode            CHARACTER VARYING(2) NOT NULL
            "'" + fields[3] + "'," +                //directioncode               CHARACTER VARYING(1) NOT NULL
            Integer.parseInt(fields[4]) +           //distance                    SMALLint NOT NULL
        " ); ";
    }

}
