package com.uhg.ihr.provider.api.controller;

import com.uhg.ihr.audit.annotations.AuditRequest;
import com.uhg.ihr.provider.api.model.ProviderApiHeaders;
import com.uhg.ihr.provider.api.model.profile.UserProfile;
import com.uhg.ihr.provider.api.model.profile.UserProfileLookup;
import com.uhg.ihr.provider.api.model.profile.UserProfileRequest;
import com.uhg.ihr.provider.api.service.profile.UserProfileApi;
import com.uhg.ihr.provider.api.validator.ValidUserProfileLookup;
import com.uhg.ihr.provider.api.validator.ValidUserProfileRegister;
import com.uhg.ihr.provider.api.validator.ValidUserProfileUpdate;
import io.micronaut.context.annotation.Context;
import io.micronaut.http.HttpRequest;
import io.micronaut.http.MediaType;
import io.micronaut.http.MutableHttpResponse;
import io.micronaut.http.annotation.*;
import io.micronaut.validation.Validated;
import io.reactivex.Maybe;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import lombok.extern.slf4j.Slf4j;

import javax.inject.Inject;

import static com.uhg.ihr.provider.api.util.ControllerUtil.buildHttpResponse;

@Slf4j
@Validated
@Context
@Controller("/profiles/v1")
public class UserProfileController {

    @Inject
    private UserProfileApi userProfileService;

    @Post(uri = "/", produces = MediaType.APPLICATION_JSON, consumes = MediaType.APPLICATION_JSON)
    @Operation(summary = "Creates a user profile",
            description = "Performs a 'user registration', creating a user profile in the system")
    @ApiResponse(responseCode = "200", description = "Responds with created User Profile",
            content = @Content(mediaType = "application/json")
    )
    @AuditRequest(auditType = "profile_create")
    public Maybe<MutableHttpResponse<UserProfile>> createProfile(final HttpRequest myRequest,
                                                                 final @RequestBean ProviderApiHeaders headers,
                                                                 final @ValidUserProfileRegister @Body UserProfileRequest request) {
        return buildHttpResponse(
                userProfileService.registerUser(request, headers),
                myRequest,
                "CreateProfile");
    }

    @Post(uri = "/update", produces = MediaType.APPLICATION_JSON, consumes = MediaType.APPLICATION_JSON)
    @Operation(summary = "Updates a user profile",
            description = "Updates an existing user profile in the system, or returns 404 if that user profile is not found")
    @ApiResponse(responseCode = "200", description = "Responds with updated User Profile",
            content = @Content(mediaType = "application/json")
    )
    @ApiResponse(responseCode = "404", description = "User not found")
    @AuditRequest(auditType = "profile_update")
    public Maybe<MutableHttpResponse<UserProfile>> updateProfile(final HttpRequest myRequest,
                                                                 final @RequestBean ProviderApiHeaders headers,
                                                                 final @ValidUserProfileUpdate @Body UserProfileRequest userProfileRequest) {
        return buildHttpResponse(
                userProfileService.updateUser(userProfileRequest, headers),
                myRequest,
                "UpdateProfile");
    }


    @Post(uri = "/lookup", produces = MediaType.APPLICATION_JSON, consumes = MediaType.APPLICATION_JSON)
    @Operation(summary = "lookup provider information",
            description = "lookup provider information",
            operationId = "lookup-user-profile"
    )
    @ApiResponse(responseCode = "200", description = "Responds with User Profile",
            content = @Content(mediaType = "application/json")
    )
    @ApiResponse(responseCode = "404", description = "User not found")
    @AuditRequest(auditType = "profile_lookup")
    public Maybe<MutableHttpResponse<UserProfile>> lookupUserProfile(final HttpRequest myRequest,
                                                                     final @RequestBean ProviderApiHeaders headers,
                                                                     final @ValidUserProfileLookup @Body UserProfileLookup lookup) {
        return buildHttpResponse(
                userProfileService.lookupUserProfile(lookup, headers),
                myRequest,
                "LookupProfile");
    }

    @Get(uri = "/{profile-id}/read", produces = MediaType.APPLICATION_JSON)
    @Operation(summary = "lookup provider information",
            description = "lookup provider information",
            operationId = "get-user-profile"
    )
    @ApiResponse(responseCode = "200", description = "Responds with User Profile or empty Json if no profile found",
            content = @Content(mediaType = "application/json")
    )
    @AuditRequest(auditType = "profile_read")
    public Maybe<MutableHttpResponse<UserProfile>> getUserProfile(final HttpRequest myRequest,
                                                                  final @RequestBean ProviderApiHeaders headers,
                                                                  final @PathVariable("profile-id") String providerId) {
        return buildHttpResponse(
                userProfileService.getUserProfileByChid(providerId, headers),
                myRequest,
                "GetProfile");
    }
}   //  end of UserProfileController
