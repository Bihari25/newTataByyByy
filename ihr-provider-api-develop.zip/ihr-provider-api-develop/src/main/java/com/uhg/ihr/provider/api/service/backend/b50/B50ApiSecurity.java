package com.uhg.ihr.provider.api.service.backend.b50;

import io.jsonwebtoken.JwtBuilder;
import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.SignatureAlgorithm;
import io.jsonwebtoken.security.Keys;
import io.micronaut.context.annotation.Property;

import javax.inject.Inject;
import javax.inject.Singleton;
import java.nio.charset.StandardCharsets;
import java.util.Arrays;
import java.util.Date;
import java.util.List;

@Singleton
public class B50ApiSecurity {

    private static final String PROPERTY_PREFIX = B50ApiUtils.PROPERTY_PREFIX + ".security";
    private static final String JWT_PREFIX = PROPERTY_PREFIX + ".jwt";
    private static final String ENV = System.getenv("ENVIRONMENT");

    @Property(name = JWT_PREFIX + ".secret-key")
    private String jwtSecretKey;
    @Property(name = JWT_PREFIX + ".issuer")
    private String jwtIssuer;
    @Property(name = JWT_PREFIX + ".audience")
    private String jwtAudience;
    @Property(name = JWT_PREFIX + ".ttl")
    private long jwtTTL;
    private List<String> roles;

    public B50ApiSecurity() {

    }

    @Inject
    public B50ApiSecurity(@Property(name = JWT_PREFIX+".roles") String roles) {
        this.roles = Arrays.asList(roles.split(","));
    }

    public String generateProviderBearerToken(String providerChid) {
        long issueTime = System.currentTimeMillis();
        long expireTime = issueTime + jwtTTL;
        Date issueDate = new Date(issueTime);
        Date expireDate = new Date(expireTime);
        String multiTenantIssuer = jwtIssuer + "_" + ENV;
        JwtBuilder builder = Jwts.builder()
                .setHeaderParam("typ", "JWT")
                .setIssuer(multiTenantIssuer)
                .setSubject(providerChid)
                .setAudience(jwtAudience)
                .setIssuedAt(issueDate)
                .setExpiration(expireDate)
                .claim("rol", roles)
                .signWith(Keys.hmacShaKeyFor(jwtSecretKey.getBytes(StandardCharsets.US_ASCII)), SignatureAlgorithm.HS512);
        String jwtToken = builder.compact();
        return "Bearer " + jwtToken;
    }
}
