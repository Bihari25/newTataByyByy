/**
 * Copyright (C) 2020 UnitedHealth Group
 * <p>
 * All rights reserved.
 */
package com.uhg.ihr.provider.api.configuration;

import io.micronaut.context.MessageSource;
import io.micronaut.context.annotation.Bean;
import io.micronaut.context.annotation.Factory;
import io.micronaut.context.i18n.ResourceBundleMessageSource;

/**
 * @author Kristopher T Babic
 * @version 1.0
 */
@Factory
public class ResourceBundleFactory {
    @Bean
    MessageSource messageSource() {
        return new ResourceBundleMessageSource("provider.i18n.language");
    }
}
