package com.uhg.ihr.medispan.dib.loaders;

/**
*
*/
public class Mmwfcdruglink extends TableLoader {
    
	/**
	 *
	 */
    public Mmwfcdruglink() {
        super();
    }
    
    @Override
    public String getCreateQuery() {
        return
        "CREATE TABLE mmw_fc_druglink " +
        "( " +
            "drugid                      CHARACTER VARYING(20) NOT NULL, " +
            "elementid                   INTEGER NOT NULL, " +
            "documentcode                CHARACTER VARYING(10) NOT NULL, " +
            "CONSTRAINT mmw_fc_druglink_pkey PRIMARY KEY (drugid, elementid, documentcode) " +
        ") " +
        "WITH (OIDS=TRUE); ";
    }
    
    @Override
    public String getInsertQuery(String line) {
        String[] fields = line.split("\\|");
        
        return "INSERT INTO mmw_fc_druglink VALUES " +
        "( " +
            "'" + fields[0] + "'," +                //drugid            CHARACTER VARYING(20) NOT NULL
            Integer.parseInt(fields[1]) + "," +     //elementid         INTEGER NOT NULL
            "'" + fields[2] + "'" +                 //documentcode      CHARACTER VARYING(10) NOT NULL
        " ); ";
    }

}
