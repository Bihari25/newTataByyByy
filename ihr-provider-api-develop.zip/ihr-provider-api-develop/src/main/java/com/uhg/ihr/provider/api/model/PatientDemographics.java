package com.uhg.ihr.provider.api.model;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import com.uhg.ihr.provider.api.model.profile.UserPhone;
import com.uhg.ihr.provider.api.service.relationship.model.Relationship;
import com.uhg.ihr.provider.api.validator.ValidDate;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.validation.Valid;
import javax.validation.constraints.NotBlank;
import java.util.List;

@Data
@Builder(toBuilder = true)
@AllArgsConstructor
@NoArgsConstructor
@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({"id", "name", "gender", "dateOfBirth", "addresses", "identifiers", "relationships"})
public class PatientDemographics {
    @JsonProperty
    @NotBlank(message = "The request could not be validated. patient chid.")
    private String id;

    @JsonProperty
    @NotBlank(message = "The request could not be validated. patient name.")
    private MemberName name;

    @JsonProperty
    @ValidDate(message = "The request could not be validated. A date of birth was not provided.")
    private String dateOfBirth;

    @JsonProperty
    private String dateOfDeath;

    @JsonProperty
    private String age;

    @JsonProperty
    private String gender;

    @JsonProperty
    @Valid
    private List<MemberAddress> addresses;

    @JsonProperty
    @Valid
    private List<UserPhone> phones;

    @JsonProperty
    @NotBlank(message = "The request could not be validated. A search id was not provided.")
    @Valid
    private List<Id> identifiers;

    @JsonProperty
    private List<Relationship> relationships;
}
