package com.uhg.ihr.medispan.dib.model;

import com.uhg.ihr.medispan.util.StringUtils;

import java.util.Arrays;
import java.util.Objects;

public class ImageValue  implements Comparable<ImageValue> {

    public static String getMimeTypeFromImageName(String imageName) {
        if (!StringUtils.hasContent(imageName)) {
            return null;
        }
        int dotIndex = imageName.lastIndexOf('.');
        if (dotIndex < 0) {
            return null;
        }
        String extension = imageName.substring(dotIndex + 1);
        if (extension.equalsIgnoreCase("png")) {
            return "image/png";
        }
        if (extension.equalsIgnoreCase("jpeg") || extension.equals("jpg")) {
            return "image/jpeg";
        }
        if (extension.equalsIgnoreCase("gif")) {
            return "image/gif";
        }
        if (extension.equalsIgnoreCase("tiff") || extension.equals("tif")) {
            return "image/tiff";
        }
        return null;
    }

    private String type;
    private String image;
    private String url;
    private String description;
    private String labeler;
    private Integer width;
    private Integer height;
    private String mimeType;

    /**
     * @param type
     * @param image
     * @param description
     * @param labeler
     * @param width
     * @param height
     * @param mimeType
     */
    public ImageValue(String type, String image, String imageServerUrl, String description, String labeler,
                      Integer width, Integer height, String mimeType) {
        this.type = type;
        this.image = image;
        this.url = imageServerUrl + "/" + image;
        this.description = description;
        this.labeler = labeler;
        this.width = width;
        this.height = height;
        this.mimeType = mimeType;
    }

    @Override
    public int compareTo(ImageValue o) {
        int comparison = StringUtils.compareIgnoreCase(getDescription(), o.getDescription());
        return comparison == 0 ? StringUtils.compareIgnoreCase(getImage(), o.getImage()) : comparison;
    }

    @Override
    public boolean equals(Object o) {
        if (!(o instanceof ImageValue)) {
            return false;
        }
        ImageValue other = (ImageValue) o;
        return Objects.equals(image, other.image) && Objects.equals(type, other.type);
    }

    public String getImage() {
        return image;
    }

    public String getUrl() {
        return url;
    }

    public String getType() {
        return type;
    }

    public String getDescription() {
        return description;
    }

    public String getLabeler() {
        return labeler;
    }

    public Integer getWidth() {
        return width;
    }

    public Integer getHeight() {
        return height;
    }

    public String getMimeType() {
        return mimeType;
    }

    @Override
    public int hashCode() {
        return Arrays.hashCode(new Object[] { getImage(), getType() });
    }

    @Override
    public String toString() {
        return hasContent(getDescription()) ? getDescription() : getImage();
    }

    public static boolean hasContent(CharSequence text) {
        return !(text == null || text.length() == 0);
    }
    public String getText() {
        return getDescription();
    }

    /**
     * @param text
     */
    public void setText(String text) {
        description = text;
    }
}
