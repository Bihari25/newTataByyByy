package com.uhg.ihr.medispan.dib.loaders;

/**
*
*/
public class Mmwdruglabeler extends TableLoader {
    
	/**
	 *
	 */
    public Mmwdruglabeler() {
        super();
    }
    
    @Override
    public String getCreateQuery() {
        return
        "CREATE TABLE mmw_drug_labeler " +
        "( " +
            "labelerid                   CHARACTER VARYING(5) NOT NULL, " +
            "namefull                    CHARACTER VARYING(30) NOT NULL, " +
            "nameabbrev                  CHARACTER VARYING(10) NOT NULL, " +
            "typecode                    CHARACTER VARYING(1) NOT NULL, " +
            "CONSTRAINT mmw_drug_labeler_pkey PRIMARY KEY (labelerid) " +
        ") " +
        "WITH (OIDS=TRUE); ";
    }
    
    @Override
    public String getInsertQuery(String line) {
        String[] fields = line.split("\\|");
        
        return "INSERT INTO mmw_drug_labeler VALUES " +
        "( " +
            "'" + fields[0] + "'," +                        //labelerid                   CHARACTER VARYING(5) NOT NULL
            "'" + fields[1].replace("'", "''") + "'," +     //namefull                    CHARACTER VARYING(30) NOT NULL
            "'" + fields[2].replace("'", "''") + "'," +     //nameabbrev                  CHARACTER VARYING(10) NOT NULL
            "'" + fields[3] + "'" +                         //typecode                    CHARACTER VARYING(1) NOT NULL
        " ); ";
    }

}
