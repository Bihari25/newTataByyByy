package com.uhg.ihr.provider.api.model;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import com.uhg.ihr.provider.api.validator.ValidLanguage;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.validation.constraints.NotBlank;

@Data
@Builder(toBuilder = true)
@AllArgsConstructor
@NoArgsConstructor
@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({"addressLine1", "addressLine2", "city", "state", "postalCode", "country", "addressType"})
public class MemberAddress {
    @JsonProperty
    private String addressLine1;

    @JsonProperty
    private String addressLine2;

    @JsonProperty
    private String city;

    @JsonProperty
    private String state;

    @JsonProperty
    private String postalCode;

    @JsonProperty
    private String country;

    @JsonProperty
    private String addressType;
}
