package com.uhg.ihr.provider.api.controller;

import com.uhg.ihr.audit.annotations.AuditRequest;
import com.uhg.ihr.medispan.dib.model.ImageValue;
import com.uhg.ihr.medispan.dib.model.MedicationMedispan;
import com.uhg.ihr.medispan.dib.service.DibApiService;
import io.micronaut.context.annotation.Context;
import io.micronaut.http.HttpRequest;
import io.micronaut.http.HttpStatus;
import io.micronaut.http.MutableHttpResponse;
import io.micronaut.http.annotation.Controller;
import io.micronaut.http.annotation.Get;
import io.micronaut.http.annotation.PathVariable;
import io.micronaut.http.server.netty.NettyHttpResponseFactory;
import io.micronaut.validation.Validated;
import io.reactivex.Maybe;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import lombok.extern.slf4j.Slf4j;

import javax.inject.Inject;
import java.util.List;

@Slf4j
@Validated
@Context
@Controller("/medications/v1")
public class MedispanController {
    @Inject
    private DibApiService dibApiService;


    @Get("/{id}")    // return both images and education notice
    @Operation(summary = "Retrieve medication details",
            description = "Return details about a specified medication, or 404 if the medication is not found",
            operationId = "get-medication")
    @ApiResponse(responseCode = "404", description = "Not found response returned when no data found for provided request")
    @AuditRequest(auditType = "medication_read")
    public Maybe<MutableHttpResponse<MedicationMedispan>> getMedicationSpan(final HttpRequest myRequest, @PathVariable("id") String id) {
        return buildResponse(dibApiService.getMedicationSpan(id));
    }

    @Get("/{id}/images")
    @Operation(summary = "Returns a list of drug images",
            description = "Returns a list of drug images for the specified medication resource, or 404 if the medication is not found")
    @ApiResponse(responseCode = "404", description = "Not found response returned when no data found for provided request")
    @AuditRequest(auditType = "medication_image_read")
    public Maybe<MutableHttpResponse<List<ImageValue>>> getDrugImages(final HttpRequest myRequest, @PathVariable("id") String id) {
        return buildResponse(dibApiService.getDrugImagesFK(id));
    }

    @Get("/{id}/education")
    @Operation(summary = "Retrieves patient education information for the specified medication",
            description = "Retrieves patient education information for the specified medication, or 404 if the medication is not foudn",
            operationId = "get-patient-education")
    @ApiResponse(responseCode = "404", description = "Not found response returned when no data found for provided request")
    @AuditRequest(auditType = "medication_education_read")
    public Maybe<MutableHttpResponse<String>> getPatientEducationMonograph(final HttpRequest myRequest, @PathVariable("id") String id) {
        return buildResponse(dibApiService.getPatientEducationMonographFK(id));
    }

    private static <T> Maybe<MutableHttpResponse<T>> buildResponse(Maybe<T> data) {
        return data
                .map(NettyHttpResponseFactory.INSTANCE::ok)
                .defaultIfEmpty(NettyHttpResponseFactory.INSTANCE.status(HttpStatus.NOT_FOUND));
    }
}

