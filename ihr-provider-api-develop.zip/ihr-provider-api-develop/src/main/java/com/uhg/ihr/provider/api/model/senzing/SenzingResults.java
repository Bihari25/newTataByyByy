package com.uhg.ihr.provider.api.model.senzing;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

public class SenzingResults implements Serializable {
    private List<DeferalObject> deferalObjects;

    public SenzingResults() {
        deferalObjects = new ArrayList<>();
    }

    public List<DeferalObject> getDeferalObjects() {
        return deferalObjects;
    }

    public void setDeferalObjects(List<DeferalObject> deferalObjects) {
        this.deferalObjects = deferalObjects;
    }

    public void addDeferalObject(DeferalObject deferalObject) {
        deferalObjects.add(deferalObject);
    }
}
