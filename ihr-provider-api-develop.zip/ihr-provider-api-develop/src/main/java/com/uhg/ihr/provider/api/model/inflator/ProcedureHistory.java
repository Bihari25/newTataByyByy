package com.uhg.ihr.provider.api.model.inflator;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import org.apache.commons.lang3.builder.ToStringBuilder;

import java.io.Serializable;
import java.util.List;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
        "relatedObservations",
        "recordType",
        "objectId",
        "sensitivityClasses",
        "relatedServiceProviders",
        "healhtEventCategoryText",
        "healthEventDate",
        "healthEventOrderDate",
        "lastUpdateDate",
        "dataSource",
        "healthStatus",
        "relatedConditions",
        "sourceClaimIds",
        "specimens",
        "healthEvent",
        "relatedCareTeam",
        "presenceStateTerm"
})
@JsonIgnoreProperties(ignoreUnknown = true)
public class ProcedureHistory implements Serializable {

    @JsonProperty("relatedObservations")
    private List<Object> relatedObservations = null;
    @JsonProperty("recordType")
    private String recordType;
    @JsonProperty("objectId")
    private int objectId;
    @JsonProperty("sensitivityClasses")
    private List<Object> sensitivityClasses = null;
    @JsonProperty("relatedServiceProviders")
    private List<Object> relatedServiceProviders = null;
    @JsonProperty("healhtEventCategoryText")
    private Object healhtEventCategoryText;
    @JsonProperty("healthEventDate")
    private String healthEventDate;
    @JsonProperty("healthEventOrderDate")
    private Object healthEventOrderDate;
    @JsonProperty("lastUpdateDate")
    private String lastUpdateDate;
    @JsonProperty("dataSource")
    private List<Object> dataSource = null;
    @JsonProperty("healthStatus")
    private HealthStatus healthStatus;
    @JsonProperty("relatedConditions")
    private List<Object> relatedConditions = null;
    @JsonProperty("sourceClaimIds")
    private List<Object> sourceClaimIds = null;
    @JsonProperty("specimens")
    private List<Object> specimens = null;
    @JsonProperty("healthEvent")
    private HealthEvent healthEvent;
    @JsonProperty("relatedCareTeam")
    private List<Object> relatedCareTeam = null;
    @JsonProperty("presenceStateTerm")
    private Object presenceStateTerm;

    @JsonProperty("relatedObservations")
    public List<Object> getRelatedObservations() {
        return relatedObservations;
    }

    @JsonProperty("relatedObservations")
    public void setRelatedObservations(List<Object> relatedObservations) {
        this.relatedObservations = relatedObservations;
    }

    @JsonProperty("recordType")
    public String getRecordType() {
        return recordType;
    }

    @JsonProperty("recordType")
    public void setRecordType(String recordType) {
        this.recordType = recordType;
    }

    @JsonProperty("objectId")
    public int getObjectId() {
        return objectId;
    }

    @JsonProperty("objectId")
    public void setObjectId(int objectId) {
        this.objectId = objectId;
    }

    @JsonProperty("sensitivityClasses")
    public List<Object> getSensitivityClasses() {
        return sensitivityClasses;
    }

    @JsonProperty("sensitivityClasses")
    public void setSensitivityClasses(List<Object> sensitivityClasses) {
        this.sensitivityClasses = sensitivityClasses;
    }

    @JsonProperty("relatedServiceProviders")
    public List<Object> getRelatedServiceProviders() {
        return relatedServiceProviders;
    }

    @JsonProperty("relatedServiceProviders")
    public void setRelatedServiceProviders(List<Object> relatedServiceProviders) {
        this.relatedServiceProviders = relatedServiceProviders;
    }

    @JsonProperty("healhtEventCategoryText")
    public Object getHealhtEventCategoryText() {
        return healhtEventCategoryText;
    }

    @JsonProperty("healhtEventCategoryText")
    public void setHealhtEventCategoryText(Object healhtEventCategoryText) {
        this.healhtEventCategoryText = healhtEventCategoryText;
    }

    @JsonProperty("healthEventDate")
    public String getHealthEventDate() {
        return healthEventDate;
    }

    @JsonProperty("healthEventDate")
    public void setHealthEventDate(String healthEventDate) {
        this.healthEventDate = healthEventDate;
    }

    @JsonProperty("healthEventOrderDate")
    public Object getHealthEventOrderDate() {
        return healthEventOrderDate;
    }

    @JsonProperty("healthEventOrderDate")
    public void setHealthEventOrderDate(Object healthEventOrderDate) {
        this.healthEventOrderDate = healthEventOrderDate;
    }

    @JsonProperty("lastUpdateDate")
    public String getLastUpdateDate() {
        return lastUpdateDate;
    }

    @JsonProperty("lastUpdateDate")
    public void setLastUpdateDate(String lastUpdateDate) {
        this.lastUpdateDate = lastUpdateDate;
    }

    @JsonProperty("dataSource")
    public List<Object> getDataSource() {
        return dataSource;
    }

    @JsonProperty("dataSource")
    public void setDataSource(List<Object> dataSource) {
        this.dataSource = dataSource;
    }

    @JsonProperty("healthStatus")
    public HealthStatus getHealthStatus() {
        return healthStatus;
    }

    @JsonProperty("healthStatus")
    public void setHealthStatus(HealthStatus healthStatus) {
        this.healthStatus = healthStatus;
    }

    @JsonProperty("relatedConditions")
    public List<Object> getRelatedConditions() {
        return relatedConditions;
    }

    @JsonProperty("relatedConditions")
    public void setRelatedConditions(List<Object> relatedConditions) {
        this.relatedConditions = relatedConditions;
    }

    @JsonProperty("sourceClaimIds")
    public List<Object> getSourceClaimIds() {
        return sourceClaimIds;
    }

    @JsonProperty("sourceClaimIds")
    public void setSourceClaimIds(List<Object> sourceClaimIds) {
        this.sourceClaimIds = sourceClaimIds;
    }

    @JsonProperty("specimens")
    public List<Object> getSpecimens() {
        return specimens;
    }

    @JsonProperty("specimens")
    public void setSpecimens(List<Object> specimens) {
        this.specimens = specimens;
    }

    @JsonProperty("healthEvent")
    public HealthEvent getHealthEvent() {
        return healthEvent;
    }

    @JsonProperty("healthEvent")
    public void setHealthEvent(HealthEvent healthEvent) {
        this.healthEvent = healthEvent;
    }

    @JsonProperty("relatedCareTeam")
    public List<Object> getRelatedCareTeam() {
        return relatedCareTeam;
    }

    @JsonProperty("relatedCareTeam")
    public void setRelatedCareTeam(List<Object> relatedCareTeam) {
        this.relatedCareTeam = relatedCareTeam;
    }

    @JsonProperty("presenceStateTerm")
    public Object getPresenceStateTerm() {
        return presenceStateTerm;
    }

    @JsonProperty("presenceStateTerm")
    public void setPresenceStateTerm(Object presenceStateTerm) {
        this.presenceStateTerm = presenceStateTerm;
    }



    @Override
    public String toString() {
        return new ToStringBuilder(this).append("relatedObservations", relatedObservations).append("recordType", recordType).append("objectId", objectId).append("sensitivityClasses", sensitivityClasses).append("relatedServiceProviders", relatedServiceProviders).append("healhtEventCategoryText", healhtEventCategoryText).append("healthEventDate", healthEventDate).append("healthEventOrderDate", healthEventOrderDate).append("lastUpdateDate", lastUpdateDate).append("dataSource", dataSource).append("healthStatus", healthStatus).append("relatedConditions", relatedConditions).append("sourceClaimIds", sourceClaimIds).append("specimens", specimens).append("healthEvent", healthEvent).append("relatedCareTeam", relatedCareTeam).append("presenceStateTerm", presenceStateTerm).toString();
    }


}