package com.uhg.ihr.medispan.dib.loaders;

/**
*
*/
public class Mmwlibversion extends TableLoader {
    
	/**
	 *
	 */
    public Mmwlibversion() {
        super();
    }
    
    @Override
    public String getCreateQuery() {
        return
        "CREATE TABLE mmw_lib_version " +
        "( " +
            "versionkey                  SMALLINT NOT NULL, " +
            "dbversion                   CHARACTER VARYING(5) NOT NULL, " +
            "buildversion                CHARACTER VARYING(5) NOT NULL, " +
            "frequency                   CHARACTER VARYING(1) NOT NULL, " +
            "issuedate                   CHARACTER VARYING(8) NOT NULL, " +
            "versioncomment              CHARACTER VARYING(80) NOT NULL, " +
            "lastupdate                  CHARACTER VARYING(20) NULL, " +
            "CONSTRAINT mmw_lib_version_pkey PRIMARY KEY (versionkey) " +
        ") " +
        "WITH (OIDS=TRUE); ";
    }
    
    @Override
    public String getInsertQuery(String line) {
        String[] fields = line.split("\\|");
        
        return "INSERT INTO mmw_lib_version VALUES " +
        "( " +
            Integer.parseInt(fields[0]) + "," +     //versionkey                  SMALLINT NOT NULL
            "'" + fields[1] + "'," +                //dbversion                   CHARACTER VARYING(5) NOT NULL
            "'" + fields[2] + "'," +                //buildversion                CHARACTER VARYING(5) NOT NULL
            "'" + fields[3] + "'," +                //frequency                   CHARACTER VARYING(1) NOT NULL
            "'" + fields[4] + "'," +                //issuedate                   CHARACTER VARYING(8) NOT NULL
            "'" + fields[5] + "'," +                //versioncomment              CHARACTER VARYING(80) NOT NULL
            (fields.length < 6 || fields[6].isEmpty() ? "NULL" : "'" + fields[6] + "'") +   //lastupdate                  CHARACTER VARYING(20) NULL
        " ); ";
    }

}
