package com.uhg.ihr.medispan.dib.loaders;

/**
*
*/
public class Mmwmedcit extends TableLoader {
    
	/**
	 *
	 */
    public Mmwmedcit() {
        super();
    }
    
    @Override
    public String getCreateQuery() {
        return
        "CREATE TABLE mmw_med_cit " +
        "( " +
            "citationid                  INTEGER NOT NULL, " +
            "citationtext                CHARACTER VARYING(250) NOT NULL, " +
            "CONSTRAINT mmw_med_cit_pkey PRIMARY KEY (citationid) " +
        ") " +
        "WITH (OIDS=TRUE); ";
    }
    
    @Override
    public String getInsertQuery(String line) {
        String[] fields = line.split("\\|");
        
        return "INSERT INTO mmw_med_cit VALUES " +
        "( " +
            Integer.parseInt(fields[0]) + "," +     //citationid        INTEGER NOT NULL
            "'" + fields[1].replace("'", "''") + "'" +                 //citationtext      CHARACTER VARYING(250) NOT NULL
        " ); ";
    }

}
