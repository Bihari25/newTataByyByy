package com.uhg.ihr.medispan.dib.loaders;

/**
*
*/
public class Mmwddadoseforgpi extends TableLoader {
    
	/**
	 *
	 */
    public Mmwddadoseforgpi() {
        super();
    }
    
    @Override
    public String getCreateQuery() {
        return
        "CREATE TABLE mmw_dda_doseforgpi " + 
        "( " +
            "gpi                         CHARACTER VARYING(14) NOT NULL, " +
            "doseid                      CHARACTER VARYING(10) NOT NULL, " +
            "profileid                   CHARACTER VARYING(10) NOT NULL, " +
            "routeid                     INTEGER NOT NULL, " +
            "dosetypecode                CHARACTER VARYING(2) NOT NULL, " +
            "indicationid                INTEGER NOT NULL, " +
            "speccondid                  INTEGER NOT NULL, " +
            "agetypecode                 CHARACTER VARYING(2) NOT NULL, " +
            "ageindayslow                INTEGER NOT NULL, " +
            "ageindayshigh               INTEGER NOT NULL, " +
            "addagetypecode              CHARACTER VARYING(2) NOT NULL, " +
            "addageindayslow             INTEGER NOT NULL, " +
            "addageindayshigh            INTEGER NOT NULL, " +
            "renalfunctypecode           CHARACTER VARYING(2) NOT NULL, " +
            "renalfunclow                NUMERIC(8,4) NOT NULL, " +
            "renalfunchigh               NUMERIC(8,4) NOT NULL, " +
            "renalfuncunit               CHARACTER VARYING(2) NOT NULL, " +
            "weightcatlow                NUMERIC(7,2) NOT NULL, " +
            "weightcathigh               NUMERIC(7,2) NOT NULL, " +
            "weightcatunit               CHARACTER VARYING(2) NOT NULL, " +
            "halflifelow                 NUMERIC(5,2) NOT NULL, " +
            "halflifehigh                NUMERIC(5,2) NOT NULL, " +
            "halflifeunit                CHARACTER VARYING(2) NOT NULL, " +
            "CONSTRAINT mmw_dda_doseforgpi_pkey PRIMARY KEY (gpi,doseid,profileid) " +
        ") " +
        "WITH (OIDS=TRUE); ";
    }
    
    @Override
    public String getInsertQuery(String line) {
        String[] fields = line.split("\\|");
        
        return "INSERT INTO mmw_dda_doseforgpi VALUES " +
        "( " +
            "'" + fields[0] + "'," +                 //gpi                         CHARACTER VARYING(14) NOT NULL
            "'" + fields[1] + "'," +                 //doseid                      CHARACTER VARYING(10) NOT NULL
            "'" + fields[2] + "'," +                 //profileid                   CHARACTER VARYING(10) NOT NULL
            Integer.parseInt(fields[3]) + "," +      //routeid                     INTEGER NOT NULL
            "'" + fields[4] + "'," +                 //dosetypecode                CHARACTER VARYING(2) NOT NULL
            Integer.parseInt(fields[5]) + "," +      //indicationid                INTEGER NOT NULL
            Integer.parseInt(fields[6]) + "," +      //speccondid                  INTEGER NOT NULL
            "'" + fields[7] + "'," +                 //agetypecode                 CHARACTER VARYING(2) NOT NULL
            Integer.parseInt(fields[8]) + "," +      //ageindayslow                INTEGER NOT NULL
            Integer.parseInt(fields[9]) + "," +      //ageindayshigh               INTEGER NOT NULL
            "'" + fields[10] + "'," +                //addagetypecode              CHARACTER VARYING(2) NOT NULL
            Integer.parseInt(fields[11]) + "," +     //addageindayslow             INTEGER NOT NULL
            Integer.parseInt(fields[12]) + "," +     //addageindayshigh            INTEGER NOT NULL
            "'" + fields[13] + "'," +                //renalfunctypecode           CHARACTER VARYING(2) NOT NULL
            Float.parseFloat(fields[14]) + "," +     //renalfunclow                NUMERIC(8,4) NOT NULL
            Float.parseFloat(fields[15]) + "," +     //renalfunchigh               NUMERIC(8,4) NOT NULL
            "'" + fields[16] + "'," +                //renalfuncunit               CHARACTER VARYING(2) NOT NULL
            Float.parseFloat(fields[17]) + "," +     //weightcatlow                NUMERIC(7,2) NOT NULL
            Float.parseFloat(fields[18]) + "," +     //weightcathigh               NUMERIC(7,2) NOT NULL
            "'" + fields[19] + "'," +                //weightcatunit               CHARACTER VARYING(2) NOT NULL
            Float.parseFloat(fields[20]) + "," +     //halflifelow                 NUMERIC(5,2) NOT NULL
            Float.parseFloat(fields[21]) + "," +     //halflifehigh                NUMERIC(5,2) NOT NULL
            "'" + fields[22] + "'" +                 //halflifeunit                CHARACTER VARYING(2) NOT NULL
        " ); ";
    }

}
