package com.uhg.ihr.provider.api.exception;

public class DataSyncException extends UnhandledApiException {

    public enum Location {
        MONGO,
        B50
    }

    private DataSyncException() {

    }

    public DataSyncException(String data, Location missingIn) {
        super("Missing in " + missingIn + ": " + data);
    }

    public DataSyncException(String data, Location missingIn, Throwable cause) {
        super("Missing in " + missingIn + ": " + data, cause);
    }
}
