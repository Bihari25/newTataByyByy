package com.uhg.ihr.provider.api.service.backend.b50.search;

public class B50ApiRequestException extends RuntimeException {
    public B50ApiRequestException(String message) {
        super(message);
    }
}
