package com.uhg.ihr.medispan.dib.loaders;

/**
*
*/
public class Mmwadespeccond extends TableLoader {
    
    /**
     * 
     */
    public Mmwadespeccond() {
        super();
    }
    
    @Override
    public String getCreateQuery() {
        return
        "CREATE TABLE mmw_ade_speccond " +
        "( " +
            "gpi                         CHARACTER VARYING(14) NOT NULL, " +
            "mcid                        INTEGER NOT NULL, " +
            "restrictionid               INTEGER NOT NULL, " +
            "speccondid                  INTEGER NOT NULL, " +
            "incidencecode               CHARACTER VARYING(2) NOT NULL, " +
            "CONSTRAINT mmw_ade_speccond_pkey PRIMARY KEY (gpi, mcid, restrictionid, speccondid) " +
        ") " +
        "WITH (OIDS=TRUE); ";
    }
    
    @Override
    public String getInsertQuery(String line) {
        String[] fields = line.split("\\|");
        
        return "INSERT INTO mmw_ade_speccond VALUES " +
        "( " +
            "'" + fields[0] + "'," +                //gpi               CHARACTER VARYING(14) NOT NULL
            Integer.parseInt(fields[1]) + "," +     //mcid              INTEGER NOT NULL
            Integer.parseInt(fields[2]) + "," +     //restrictionid     INTEGER NOT NULL
            Integer.parseInt(fields[3]) + "," +     //speccondid        INTEGER NOT NULL
            "'" + fields[4] + "'" +                 //incidencecode     CHARACTER VARYING(2) NOT NULL
        " ); ";
    }

}
