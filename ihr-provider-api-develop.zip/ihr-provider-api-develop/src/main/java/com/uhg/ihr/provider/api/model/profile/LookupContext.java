package com.uhg.ihr.provider.api.model.profile;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.uhg.ihr.provider.api.model.MemberName;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.validation.constraints.Email;
import java.util.Map;

@Data
@Builder(toBuilder = true)
@AllArgsConstructor
@NoArgsConstructor
@JsonInclude(JsonInclude.Include.NON_EMPTY)
public class LookupContext {
    @JsonProperty
    private Map<UserProfileConstant.IDENTIFIER_CONTEXT, String> lookupContexts;

    @JsonProperty
    @Email
    private String email;

    @JsonProperty
    private MemberName name;

    @JsonProperty
    private String npi;
}
