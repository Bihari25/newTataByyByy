package com.uhg.ihr.provider.api.service;

import com.uhg.ihr.provider.api.model.ProviderApiHeaders;
import com.uhg.ihr.provider.api.service.relationship.model.RelationshipRequest;
import com.uhg.ihr.provider.api.service.relationship.model.RelationshipResponse;
import io.reactivex.Maybe;

public interface RelationshipInterface {
    Maybe<RelationshipResponse> manageRelationship(RelationshipRequest request, String patientChid, ProviderApiHeaders headers);
}
