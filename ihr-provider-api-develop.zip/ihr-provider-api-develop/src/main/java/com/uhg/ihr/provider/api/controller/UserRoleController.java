package com.uhg.ihr.provider.api.controller;


import com.uhg.ihr.audit.annotations.AuditRequest;
import com.uhg.ihr.provider.api.model.ProviderApiHeaders;
import com.uhg.ihr.provider.api.model.profile.RoleLookup;
import com.uhg.ihr.provider.api.model.profile.UserPermission;
import com.uhg.ihr.provider.api.service.security.SecurityApi;
import com.uhg.ihr.provider.api.service.security.model.RoleChangeRequest;
import com.uhg.ihr.provider.api.validator.ValidRoleChangeRequest;
import io.micronaut.context.annotation.Context;
import io.micronaut.http.HttpRequest;
import io.micronaut.http.MediaType;
import io.micronaut.http.MutableHttpResponse;
import io.micronaut.http.annotation.Body;
import io.micronaut.http.annotation.Controller;
import io.micronaut.http.annotation.Post;
import io.micronaut.http.annotation.RequestBean;
import io.micronaut.validation.Validated;
import io.reactivex.Maybe;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import lombok.extern.slf4j.Slf4j;

import javax.inject.Inject;
import javax.validation.Valid;
import java.util.List;

import static com.uhg.ihr.provider.api.util.ControllerUtil.buildHttpResponse;

@Slf4j
@Validated
@Context
@Controller("/securities/v1")
public class UserRoleController {
    @Inject
    private SecurityApi securityApi;

    @Post(uri = "/lookup-roles", produces = MediaType.APPLICATION_JSON, consumes = MediaType.APPLICATION_JSON)
    @Operation(summary = "lookup user role",
            description = "lookup user role mapping between PORTAL and IHR",
            operationId = "lookup-roles"
    )
    @ApiResponse(responseCode = "200", description = "lookup on set of roles",
            content = @Content(mediaType = "application/json")
    )

    @AuditRequest(auditType = "security_lookup_roles")
    public Maybe<MutableHttpResponse<List<UserPermission>>> lookupRoles(final HttpRequest myRequest,
                                                                        final @RequestBean ProviderApiHeaders headers,
                                                                        final @Valid @Body RoleLookup roleLookup) {


        return buildHttpResponse(securityApi.lookupRoles(roleLookup), myRequest, "LookupRoles");
    }

    @Post(uri = "/roles", produces = MediaType.APPLICATION_JSON, consumes = MediaType.APPLICATION_JSON)
    @Operation(summary = "create or update user role",
            description = "Providing a new role creates the role, providing an existing role replaces the existing role",
            operationId = "put-roles"
    )
    @ApiResponse(responseCode = "200", description = "returns the change request if successful",
            content = @Content(mediaType = "application/json")
    )
    @AuditRequest(auditType = "security_update_roles")
    public Maybe<MutableHttpResponse<RoleChangeRequest>> putRoles(final HttpRequest myRequest,
                                                                  final @RequestBean ProviderApiHeaders headers,
                                                                  final @ValidRoleChangeRequest @Body RoleChangeRequest changeRequest) {

        return buildHttpResponse(securityApi.putRoles(changeRequest), myRequest, "PutRoles");
    }
}
