package com.uhg.ihr.provider.api.validator;

import com.uhg.ihr.provider.api.model.MemberName;
import com.uhg.ihr.provider.api.model.profile.ExternalSecurityAccess;
import com.uhg.ihr.provider.api.model.profile.IhrUser;
import com.uhg.ihr.provider.api.model.profile.UserProfileConstant;
import com.uhg.ihr.provider.api.model.profile.UserProfileRequest;
import com.uhg.ihr.provider.api.util.ValidationUtil;

import javax.validation.*;
import java.util.Set;

public class ValidUserProfileRegisterValidator implements ConstraintValidator<ValidUserProfileRegister, UserProfileRequest> {
    @Override
    public boolean isValid(UserProfileRequest request, ConstraintValidatorContext constraintValidatorContext) {
        Validator validator = Validation.buildDefaultValidatorFactory().getValidator();
        Set<ConstraintViolation<UserProfileRequest>> violations = validator.validate(request);
        if (!violations.isEmpty()) {
            ValidationUtil.addConstraintViolation(violations, constraintValidatorContext);
            return false;
        }

        return validIhrUser(request, constraintValidatorContext, validator) &&
                (validStaffRequest(request, constraintValidatorContext, validator) ||
                        validProviderRequest(request, constraintValidatorContext));
    }

    public boolean validIhrUser(UserProfileRequest request, ConstraintValidatorContext constraintValidatorContext, Validator validator) {
        //Check class annotation validations
        IhrUser user = request.getUser();
        Set<ConstraintViolation<IhrUser>> violations = validator.validate(user);
        if (!violations.isEmpty()) {
            ValidationUtil.addConstraintViolation(violations, constraintValidatorContext);
            return false;
        }
        if (user.getStatus() == null) {
            user.setStatus(UserProfileConstant.STATUS.ACTIVE);
        }
        if (user.getUserType() == null) {
            ValidationUtil.addConstraintViolation("A userType must be provided", constraintValidatorContext);
            return false;
        }
        return validRegisterRequest(request, constraintValidatorContext) &&
                request.getExternalSecurity() != null;
    }

//    public boolean validExternalSecurityAccess(UserProfileRequest request, ConstraintValidatorContext constraintValidatorContext, Validator validator) {
//        ExternalSecurityAccess access = request.getExternalSecurity();
//        if (access == null) {
//            ValidationUtil.addConstraintViolation("Profile registration requires security access roles", constraintValidatorContext);
//            return false;
//        } else {
//            Set<ConstraintViolation<ExternalSecurityAccess>> violations = validator.validate(access);
//            if (!violations.isEmpty()) {
//                ValidationUtil.addConstraintViolation(violations, constraintValidatorContext);
//                return false;
//            }
//        }
//        return true;
//    }

    public boolean validRegisterRequest(UserProfileRequest request, ConstraintValidatorContext constraintValidatorContext) {
        IhrUser user = request.getUser();
        if (user.getIdentifierContexts() == null || user.getIdentifierContexts().isEmpty() ||
                user.getIdentifierContextValue(UserProfileConstant.IDENTIFIER_CONTEXT.PORTAL) == null
        ) {
            ValidationUtil.addConstraintViolation("A PORTAL identifier context must be provided", constraintValidatorContext);
            return false;
        }
        ExternalSecurityAccess securityAccess = request.getExternalSecurity();
        if (securityAccess == null) {
            ValidationUtil.addConstraintViolation("An externalSecurityAccess object must be provided", constraintValidatorContext);
            return false;
        }
        return true;
    }

    public boolean validStaffRequest(UserProfileRequest request, ConstraintValidatorContext constraintValidatorContext, Validator validator) {
        IhrUser user = request.getUser();
        if (user.getUserType() != UserProfileConstant.USER_TYPE.STAFF) {
            return false;
        }
        MemberName name = user.getName();
        if (user.getIdentifierContextValue(UserProfileConstant.IDENTIFIER_CONTEXT.IHR) == null) {
            if (name == null ||
                    name.getLast() == null || name.getLast().isBlank() ||
                    name.getFirst() == null || name.getFirst().isBlank()) {
                constraintValidatorContext.buildConstraintViolationWithTemplate("Staff register without global actor id request requires first and last name.").addConstraintViolation();
                return false;
            }
        }
        return true;
    }

    public boolean validProviderRequest(UserProfileRequest request, ConstraintValidatorContext constraintValidatorContext) {
        IhrUser user = request.getUser();
        if (user.getUserType() != UserProfileConstant.USER_TYPE.PROVIDER) {
            return false;
        }
        if (user.getIdentifierContextValue(UserProfileConstant.IDENTIFIER_CONTEXT.IHR) == null) {
            constraintValidatorContext.buildConstraintViolationWithTemplate("Provider register request requires a global actor id.").addConstraintViolation();
            return false;
        }
        return true;
    }
}
