package com.uhg.ihr.medispan.dib.loaders;

/**
*
*/
public class Mmwdrugdoseform extends TableLoader {
    
	/**
	 *
	 */
    public Mmwdrugdoseform() {
        super();
    }
    
    @Override
    public String getCreateQuery() {
        return
        "CREATE TABLE mmw_drug_doseform " +
        "( " +
            "dfid                        INTEGER NOT NULL, " +
            "description                 CHARACTER VARYING(40) NOT NULL, " +
            "abbrev                      CHARACTER VARYING(4) NOT NULL, " +
            "CONSTRAINT mmw_drug_doseform_pkey PRIMARY KEY (dfid) " +
        ") " +
        "WITH (OIDS=TRUE); ";
    }
    
    @Override
    public String getInsertQuery(String line) {
        String[] fields = line.split("\\|");
        
        return "INSERT INTO mmw_drug_doseform VALUES " +
        "( " +
            Integer.parseInt(fields[0]) + "," +         //dfid                        INTEGER NOT NULL
            "'" + fields[1] + "'," +                    //description                 CHARACTER VARYING(40) NOT NULL
            "'" + fields[2] + "'" +                     //abbrev                      CHARACTER VARYING(4) NOT NULL
        " ); ";
    }

}
