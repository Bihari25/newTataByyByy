package com.uhg.ihr.provider.api.model.inflator;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import org.apache.commons.lang3.builder.ToStringBuilder;

import java.io.Serializable;
import java.util.List;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
        "recordType",
        "objectId",
        "firstName",
        "relatedEntityName",
        "lastName",
        "middleName",
        "relatedEntityMPIN",
        "relatedEntityNPInum",
        "occupations",
        "prefix",
        "relatedEntityRoleTerm",
        "relationshipEndDate",
        "relationshipStartDate",
        "personRoleTerm"
})
@JsonIgnoreProperties(ignoreUnknown = true)
public class CareTeam implements Serializable {

    @JsonProperty("recordType")
    private String recordType;
    @JsonProperty("objectId")
    private long objectId;
    @JsonProperty("firstName")
    private String firstName;
    @JsonProperty("relatedEntityName")
    private String relatedEntityName;
    @JsonProperty("lastName")
    private String lastName;
    @JsonProperty("middleName")
    private String middleName;
    @JsonProperty("relatedEntityMPIN")
    private Object relatedEntityMPIN;
    @JsonProperty("relatedEntityNPInum")
    private String relatedEntityNPInum;
    @JsonProperty("occupations")
    private List<Occupation> occupations = null;
    @JsonProperty("prefix")
    private String prefix;
    @JsonProperty("relatedEntityRoleTerm")
    private String relatedEntityRoleTerm;
    @JsonProperty("relationshipEndDate")
    private Object relationshipEndDate;
    @JsonProperty("relationshipStartDate")
    private String relationshipStartDate;
    @JsonProperty("personRoleTerm")
    private String personRoleTerm;

    @JsonProperty("recordType")
    public String getRecordType() {
        return recordType;
    }

    @JsonProperty("recordType")
    public void setRecordType(String recordType) {
        this.recordType = recordType;
    }

    @JsonProperty("objectId")
    public long getObjectId() {
        return objectId;
    }

    @JsonProperty("objectId")
    public void setObjectId(long objectId) {
        this.objectId = objectId;
    }

    @JsonProperty("firstName")
    public String getFirstName() {
        return firstName;
    }

    @JsonProperty("firstName")
    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    @JsonProperty("relatedEntityName")
    public String getRelatedEntityName() {
        return relatedEntityName;
    }

    @JsonProperty("relatedEntityName")
    public void setRelatedEntityName(String relatedEntityName) {
        this.relatedEntityName = relatedEntityName;
    }

    @JsonProperty("lastName")
    public String getLastName() {
        return lastName;
    }

    @JsonProperty("lastName")
    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    @JsonProperty("middleName")
    public String getMiddleName() {
        return middleName;
    }

    @JsonProperty("middleName")
    public void setMiddleName(String middleName) {
        this.middleName = middleName;
    }

    @JsonProperty("relatedEntityMPIN")
    public Object getRelatedEntityMPIN() {
        return relatedEntityMPIN;
    }

    @JsonProperty("relatedEntityMPIN")
    public void setRelatedEntityMPIN(Object relatedEntityMPIN) {
        this.relatedEntityMPIN = relatedEntityMPIN;
    }

    @JsonProperty("relatedEntityNPInum")
    public String getRelatedEntityNPInum() {
        return relatedEntityNPInum;
    }

    @JsonProperty("relatedEntityNPInum")
    public void setRelatedEntityNPInum(String relatedEntityNPInum) {
        this.relatedEntityNPInum = relatedEntityNPInum;
    }

    @JsonProperty("occupations")
    public List<Occupation> getOccupations() {
        return occupations;
    }

    @JsonProperty("occupations")
    public void setOccupations(List<Occupation> occupations) {
        this.occupations = occupations;
    }

    @JsonProperty("prefix")
    public String getPrefix() {
        return prefix;
    }

    @JsonProperty("prefix")
    public void setPrefix(String prefix) {
        this.prefix = prefix;
    }

    @JsonProperty("relatedEntityRoleTerm")
    public String getRelatedEntityRoleTerm() {
        return relatedEntityRoleTerm;
    }

    @JsonProperty("relatedEntityRoleTerm")
    public void setRelatedEntityRoleTerm(String relatedEntityRoleTerm) {
        this.relatedEntityRoleTerm = relatedEntityRoleTerm;
    }

    @JsonProperty("relationshipEndDate")
    public Object getRelationshipEndDate() {
        return relationshipEndDate;
    }

    @JsonProperty("relationshipEndDate")
    public void setRelationshipEndDate(Object relationshipEndDate) {
        this.relationshipEndDate = relationshipEndDate;
    }

    @JsonProperty("relationshipStartDate")
    public String getRelationshipStartDate() {
        return relationshipStartDate;
    }

    @JsonProperty("relationshipStartDate")
    public void setRelationshipStartDate(String relationshipStartDate) {
        this.relationshipStartDate = relationshipStartDate;
    }

    @JsonProperty("personRoleTerm")
    public String getPersonRoleTerm() {
        return personRoleTerm;
    }

    @JsonProperty("personRoleTerm")
    public void setPersonRoleTerm(String personRoleTerm) {
        this.personRoleTerm = personRoleTerm;
    }

    @Override
    public String toString() {
        return new ToStringBuilder(this).append("recordType", recordType).append("objectId", objectId).append("firstName", firstName).append("relatedEntityName", relatedEntityName).append("lastName", lastName).append("middleName", middleName).append("relatedEntityMPIN", relatedEntityMPIN).append("relatedEntityNPInum", relatedEntityNPInum).append("occupations", occupations).append("prefix", prefix).append("relatedEntityRoleTerm", relatedEntityRoleTerm).append("relationshipEndDate", relationshipEndDate).append("relationshipStartDate", relationshipStartDate).append("personRoleTerm", personRoleTerm).toString();
    }

}
