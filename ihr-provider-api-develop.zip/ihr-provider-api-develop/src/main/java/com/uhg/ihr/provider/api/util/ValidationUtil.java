package com.uhg.ihr.provider.api.util;

import javax.validation.ConstraintValidatorContext;
import javax.validation.ConstraintViolation;
import java.util.Set;

public class ValidationUtil {

    public static void addConstraintViolation(String message, ConstraintValidatorContext constraintValidatorContext) {
        constraintValidatorContext.disableDefaultConstraintViolation();
        constraintValidatorContext.buildConstraintViolationWithTemplate(message).addConstraintViolation();
    }

    public static <T> void addConstraintViolation(Set<ConstraintViolation<T>> violations, ConstraintValidatorContext constraintValidatorContext) {
        String message = violations.stream()
                .map(ConstraintViolation::getMessage)
                .reduce("", (str1,str2) -> str1 + "\n" + str2);
        addConstraintViolation(message, constraintValidatorContext);
    }
}
