package com.uhg.ihr.provider.api.validator;

import com.uhg.ihr.provider.api.model.profile.IhrUser;
import com.uhg.ihr.provider.api.model.profile.UserProfileConstant;
import com.uhg.ihr.provider.api.model.profile.UserProfileRequest;

import javax.validation.*;
import java.util.Set;

public class ValidUserProfileUpdateValidator implements ConstraintValidator<ValidUserProfileUpdate, UserProfileRequest> {
    @Override
    public boolean isValid(UserProfileRequest request, ConstraintValidatorContext constraintValidatorContext) {
        Validator validator = Validation.buildDefaultValidatorFactory().getValidator();
        Set<ConstraintViolation<UserProfileRequest>> violations = validator.validate(request);
        if (!violations.isEmpty()) {
            return false;
        }
        IhrUser user = request.getUser();
        if (user.getIdentifierContexts() == null || user.getIdentifierContexts().isEmpty() ||
                user.getIdentifierContextValue(UserProfileConstant.IDENTIFIER_CONTEXT.IHR) == null
        ) {
            constraintValidatorContext.disableDefaultConstraintViolation();
            constraintValidatorContext.buildConstraintViolationWithTemplate("A PORTAL or IHR identifier must be provided").addConstraintViolation();
            return false;
        }
        return true;
    }
}
