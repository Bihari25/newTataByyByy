package com.uhg.ihr.provider.api.service.cache;

import com.fasterxml.jackson.databind.JsonNode;
import com.uhg.ihr.provider.api.model.ProviderApiHeaders;
import com.uhg.ihr.provider.api.service.backend.DataAdapterInterface;
import io.micronaut.context.annotation.Requires;
import io.reactivex.Maybe;

import javax.inject.Inject;
import javax.inject.Singleton;

@Requires(missingBeans = {CachedDataImpl.class})
@Singleton
public class NoCacheDataImpl implements CachedDataInterface {

    @Inject
    DataAdapterInterface adapter;

    @Override
    public Maybe<JsonNode> getFromCache(String providerChid, String patientChid,
                                        String overrideToken, ProviderApiHeaders headers) {
        return adapter.getAllByActorChid(providerChid, patientChid, headers);
    }
}
