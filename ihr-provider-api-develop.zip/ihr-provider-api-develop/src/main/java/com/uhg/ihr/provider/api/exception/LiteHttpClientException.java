package com.uhg.ihr.provider.api.exception;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import io.micronaut.http.HttpResponse;
import io.micronaut.http.client.exceptions.HttpClientResponseException;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@Slf4j
public class LiteHttpClientException extends UnhandledApiException {

    private static final ObjectMapper MAPPER = new ObjectMapper();

    private LiteHttpClientException() {
        super();
    }

    public LiteHttpClientException(HttpClientResponseException throwable, Object requestBody) {
        super(throwable.getMessage());
        try {
            log.error("HTTP_CLIENT_ERROR | " + MAPPER.writeValueAsString(new LiteHttpClientExceptionLog(throwable, requestBody)));
        } catch (JsonProcessingException e) {
            log.error("Failed to write out LiteHttpClientExceptionLog as JSON", e);
        }
    }

    @Data
    @NoArgsConstructor
    @AllArgsConstructor
    private class LiteHttpClientExceptionLog {
        private int statusCode;
        private String statusReason;
        private String errorMessage;
        private Object requestBody;

        LiteHttpClientExceptionLog(HttpClientResponseException exception, Object requestBody) {
            HttpResponse response = exception.getResponse();
            this.statusCode = response.getStatus().getCode();
            this.statusReason = response.getStatus().getReason();
            this.errorMessage = exception.getMessage();
            this.requestBody = requestBody;
        }
    }
}
