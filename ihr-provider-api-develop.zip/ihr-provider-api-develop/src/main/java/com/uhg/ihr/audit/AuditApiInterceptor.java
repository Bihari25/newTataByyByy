package com.uhg.ihr.audit;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.uhg.ihr.audit.annotations.AuditContextValue;
import com.uhg.ihr.audit.annotations.AuditContextValues;
import com.uhg.ihr.audit.annotations.AuditRequest;
import com.uhg.ihr.audit.factory.AuditFactory;
import com.uhg.ihr.audit.service.AuditService;
import com.uhg.ihr.provider.api.model.Actor;
import com.uhg.ihr.provider.api.model.ActorId;
import com.uhg.ihr.provider.api.model.IhrApiWithActorRequest;
import io.micronaut.aop.MethodInterceptor;
import io.micronaut.aop.MethodInvocationContext;
import io.micronaut.core.annotation.AnnotationValue;
import io.micronaut.core.type.Argument;
import io.micronaut.http.HttpRequest;
import io.micronaut.http.MutableHttpResponse;
import io.micronaut.http.annotation.PathVariable;
import io.reactivex.Maybe;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.beanutils.NestedNullException;
import org.apache.commons.beanutils.PropertyUtils;

import javax.inject.Inject;
import java.lang.reflect.InvocationTargetException;
import java.time.Instant;
import java.util.HashMap;
import java.util.Map;

@Slf4j
public class AuditApiInterceptor implements MethodInterceptor<Object, Maybe<Object>> {
    private static final ObjectMapper MAPPER = new ObjectMapper();

    @Inject
    private AuditService auditService;
    @Inject
    private AuditFactory auditFactory;


    private void setContextValue(Map<String, Object> context, String[] ctxPath, Object value) {
        setContextValue(context, ctxPath, value, 0);

    }
    @SuppressWarnings("unchecked")
    private void setContextValue(Map<String, Object> context, String[] ctxPath, Object value, int idx) {
        if (idx == ctxPath.length -1) {
            context.put(ctxPath[idx], value);
        }
        else {
            Object tmp = context.get(ctxPath[idx]);
            Map<String, Object> subCtxMap = null;
            if (tmp == null) {
                subCtxMap = new HashMap<>();
                context.put(ctxPath[idx], subCtxMap);
            }
            else if (tmp instanceof Map) {
                subCtxMap = (Map<String, Object>) tmp;
            }
            else {
                log.warn("Unable to set context value due to context being with an object, not a map");
                return;
            }
            setContextValue(subCtxMap, ctxPath, value, idx+1);
        }
    }


    @Override
    public Maybe<Object> intercept(MethodInvocationContext<Object, Maybe<Object>> context) {
        long startTime = System.currentTimeMillis();
        // initialize the auid data
        Map<String, Object> auditCommon = new HashMap<>();
        Map<String, Object> auditDetails = new HashMap<>();
        Map<String, Object> statusMap = new HashMap<>();
        statusMap.put("success", true);
        auditCommon.put("status", statusMap);

        HttpRequest tRequest = null;
        String type = (String) context.getAnnotationMetadata().getValue(AuditRequest.class, "auditType")
                .orElse(null);
        String[] auditType = type != null ? new String[]{"ihr_provider_api", type} : new String[]{"ihr_provider_api"};
        auditCommon.put(AuditConstant.Details.METHOD,
                        context.getTargetMethod().getDeclaringClass().getName() + ":" + context.getTargetMethod().getName());

        Map<String, Object> pathMap = new HashMap<>();
        Map<String, Object> pValueMap = context.getParameterValueMap();
        for (Argument argument : context.getArguments()) {
            String argName = argument.getName();
            Object paramVal = pValueMap.get(argName);

            // check for request specific audit context entries to add to common/detail
            AnnotationValue<AuditContextValues> avCtxValues = argument.getAnnotation(AuditContextValues.class);
            if (avCtxValues != null) {
                AuditContextValue[] audCtxVals = avCtxValues.getValue(AuditContextValue[].class).orElse(null);

                if (audCtxVals != null && audCtxVals.length > 0) {
                    for (AuditContextValue ctxVal : audCtxVals) {
                        AuditContextValue.ContextType ctxType = ctxVal.context();
                        String dataPath = ctxVal.dataPath();
                        Object val = null;
                        if (!dataPath.isBlank()) {
                            try {
                                val = PropertyUtils.getProperty(paramVal, dataPath);
                            }
                            catch (NestedNullException ignore) {
                                // ok
                            }
                            catch(IllegalAccessException | InvocationTargetException | NoSuchMethodException e) {
                                log.warn("Invalid AuditContextValue contextPath value: "+dataPath);
                                continue;
                            }
                        }
                        // if no path is specified, then use the value itself
                        else {
                            val = paramVal;
                        }

                        String[] ctxPath = ctxVal.contextPath();
                        // if not path specified, then use the name of the argument.
                        if (ctxPath.length == 0) {
                            ctxPath = new String[] { argName };
                        }

                        setContextValue(ctxType == AuditContextValue.ContextType.DETAIL ? auditDetails : auditCommon,
                                        ctxPath, val);
                    }
                }
            }

            AnnotationValue<PathVariable> av = argument.getAnnotation(PathVariable.class);
            if (av != null) {
                String pathVar = av.getValue(String.class).orElse(null);
                if (pathVar == null) {
                    pathVar = argName;
                }

                pathMap.put(pathVar, String.valueOf(paramVal));
            }

            if (paramVal instanceof IhrApiWithActorRequest) {
                Actor actor  = ((IhrApiWithActorRequest) paramVal).getActor();
                if (actor != null) {
                    String primary = actor.getPrimaryId();
                    ActorId onBehalf = actor.getOnBehalfOf();
                    ActorId id = actor.getId();
                    if (primary != null) {
                        auditDetails.put(AuditConstant.Details.ACTOR_REQUEST_ID, primary);
                    }
                    if (onBehalf != null && id != onBehalf) {
                        auditDetails.put(AuditConstant.Details.ON_BEHALF_OF, onBehalf);
                    }
                }
            }
            else {
                if (paramVal instanceof HttpRequest) {
                    tRequest = (HttpRequest) paramVal;
                }
            }
        }

        if (!pathMap.isEmpty()) {
            auditDetails.put("params", pathMap);
        }

        final HttpRequest request = tRequest;
        Audit audit = auditFactory.createAudit(request, auditType);
        log.info("Audit initialization time: "+(System.currentTimeMillis()-startTime));
        try {
            return context.proceed()
                    .doOnError(e -> {
                        // doesn't seem to be called on exception
                        statusMap.put("success", false);
                        auditCommon.put("request", createErrorMap(e));
                    })
                    .doOnSuccess(methodResult -> {
                        Map<String, Object> reqMap = new HashMap<>();
                        int statusCode = ((MutableHttpResponse) methodResult).status().getCode();
                        if (statusCode < 200 || statusCode >= 300) {
                            statusMap.put("success", false);
                        }

                        reqMap.put(AuditConstant.Details.RESULT, String.valueOf(statusCode));
                        reqMap.put(AuditConstant.Details.LOG_EVT_REASON, String.valueOf(((MutableHttpResponse) methodResult).status().getReason()));
                        reqMap.put(AuditConstant.Details.RESPONSE_BODY_LENGTH, ((MutableHttpResponse) methodResult).getBody().toString().length());
                        reqMap.put(AuditConstant.Details.LOG_EVT_END, Instant.now().toEpochMilli());

                        auditCommon.put("request", reqMap);
                    })
                    .doFinally(() -> sendAudit(audit, auditCommon, auditDetails));
        }
        catch (RuntimeException e) {
            statusMap.put("success", false);
            auditCommon.put("request", createErrorMap(e));
            sendAudit(audit, auditCommon, auditDetails);
            throw e;
        }
        finally {
            // nothing at the moment.
        }

    }

    private Map<String, Object> createErrorMap(Throwable e) {
        Map<String, Object> reqMap = new HashMap<>();
        reqMap.put(AuditConstant.Details.RESULT, "500");

        String error = e.getMessage();
        if (error == null) {
            error = e.getClass().getName();
        }
        reqMap.put(AuditConstant.Details.ERROR_MESSAGE, error);
        reqMap.put(AuditConstant.Details.LOG_EVT_END, Instant.now().toEpochMilli());

        return reqMap;
    }
    private void sendAudit(Audit audit, Map<String, Object> auditCommon, Map<String, Object> auditDetails) {
        JsonNode nodeCommon = MAPPER.valueToTree(auditCommon);
        JsonNode nodeDetails = MAPPER.valueToTree(auditDetails);
        audit.mergeCommon(nodeCommon);
        audit.mergeDetails(nodeDetails);

        auditService.sendAudit(audit).subscribe();
    }
}
