/**
 * Copyright (C) 2020 UnitedHealth Group
 * <p>
 * All rights reserved.
 */
package com.uhg.ihr.audit.consumer;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.uhg.ihr.audit.Audit;
import com.uhg.ihr.provider.api.logging.LogHelper;
import io.micronaut.configuration.kafka.annotation.KafkaListener;
import io.micronaut.configuration.kafka.annotation.OffsetReset;
import io.micronaut.configuration.kafka.annotation.Topic;
import io.micronaut.context.annotation.Requires;
import io.micronaut.core.util.StringUtils;
import io.reactivex.Flowable;
import lombok.extern.slf4j.Slf4j;
import org.slf4j.MDC;

/**
 * @author Kristopher T Babic
 * @version 1.0
 */
@Slf4j
@KafkaListener(offsetReset = OffsetReset.EARLIEST, threads = 5, groupId = "${audit.topic}_audit_logger")
@Requires(property = "audit.consumer.logging.enabled", value = StringUtils.TRUE)
@Requires(property = "audit.enabled", value = StringUtils.TRUE)
public class LoggingAuditListener {
    private static final ObjectMapper MAPPER = new ObjectMapper();

    @Topic("${audit.topic}")
    public Flowable<Audit> receive(Flowable<Audit> auditFlowable) {
        return auditFlowable.doOnNext(audit -> {
            if (audit != null && log.isInfoEnabled()) {
                MDC.put(LogHelper.MDC_LOG_TYPE_KEY,"kafka-audit");

                try {
                    log.info(MAPPER.writeValueAsString(audit));
                }
                catch (Exception e) {
                    log.info(audit.toString());
                }
                finally {
                    MDC.remove(LogHelper.MDC_LOG_TYPE_KEY);
                }
            }
        });
    }
}
