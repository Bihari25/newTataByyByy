package com.uhg.ihr.medispan.dib.loaders;

/**
*
*/
public class Mmwdrugroute extends TableLoader {
    
	/**
	 *
	 */
    public Mmwdrugroute() {
        super();
    }
    
    @Override
    public String getCreateQuery() {
        return
        "CREATE TABLE mmw_drug_route " +
        "( " +
            "rtid                        INTEGER NOT NULL, " +
            "description                 CHARACTER VARYING(40) NULL, " +
            "abbrev                      CHARACTER VARYING(2) NOT NULL, " +
            "CONSTRAINT mmw_drug_route_pkey PRIMARY KEY (rtid) " +
        ") " +
        "WITH (OIDS=TRUE); ";
    }
    
    @Override
    public String getInsertQuery(String line) {
        String[] fields = line.split("\\|");
        
        return "INSERT INTO mmw_drug_route VALUES " +
        "( " +
            Integer.parseInt(fields[0]) + "," +     //rtid              INTEGER NOT NULL
            (fields[1].isEmpty() ? "NULL" : "'" + fields[1].replace("'", "''") + "'") + "," +   //description       CHARACTER VARYING(40) NULL
            "'" + fields[2] + "'" +                 //abbrev            CHARACTER VARYING(2) NOT NULL
        " ); ";
    }

}
