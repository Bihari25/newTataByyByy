package com.uhg.ihr.provider.api.service.backend.b50.search.model;

import com.uhg.ihr.provider.api.model.FilterPair;
import com.uhg.ihr.provider.api.model.IhrSearchApiRequest;
import com.uhg.ihr.provider.api.model.MemberAddress;
import com.uhg.ihr.provider.api.model.SearcRequestMemberDemographic;
import lombok.extern.slf4j.Slf4j;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Slf4j
public class RequestTransformer {
    public static B50SearchRequest buildSearchRequest(IhrSearchApiRequest apiDto) {
        SearcRequestMemberDemographic demo = apiDto.getRequestCriteria().getMbrDemographics();
        B50SearchRequest searchRequest = new B50SearchRequest();
        if (demo.getIdentifiers() != null && !demo.getIdentifiers().isEmpty()) {
            List<Map<Identifier, String>> identifiers = getIdentifiersOrGlobalId(demo);
            if (identifiers.size() == 1 && identifiers.get(0).containsKey(Identifier.GLOBAL_ACTOR_ID)) {
                searchRequest.setGlobalActorId(identifiers.get(0).get(Identifier.GLOBAL_ACTOR_ID));
                return searchRequest;
            }
            searchRequest.setIdentifiers(identifiers);
        }
        if (demo.getName() != null) {
            if (demo.getName().getFirst() != null) {
                searchRequest.setFirstName(demo.getName().getFirst());
            }
            if (demo.getName().getLast() != null) {
                searchRequest.setLastName(demo.getName().getLast());
            }
        }
        if (demo.getGender() != null) {
            searchRequest.setGender(demo.getGender());
        }
        if (demo.getDateOfBirth() != null) {
            searchRequest.setDateOfBirth(demo.getDateOfBirth());
        }
        if (demo.getAddress() != null) {
            searchRequest.setAddresses(transformAddress(demo));
        }
        return searchRequest;
    }

    public static List<Map<Identifier, String>> getIdentifiersOrGlobalId(SearcRequestMemberDemographic demo) {
        List<Map<Identifier, String>> identifiers = new ArrayList<>();
        if (demo.getIdentifiers() != null && !demo.getIdentifiers().isEmpty()) {
            for (FilterPair identifier : demo.getIdentifiers()) {
                try {
                    Map<Identifier, String> identifierMap = new HashMap<>();
                    identifierMap.put(Identifier.valueOf(identifier.getKey()), identifier.getValue());
                    if (identifier.getKey().equalsIgnoreCase(Identifier.GLOBAL_ACTOR_ID.name())) {
                        List<Map<Identifier, String>> global_id = new ArrayList<>();
                        global_id.add(identifierMap);
                        return global_id;
                    }
                    identifiers.add(identifierMap);
                } catch (IllegalArgumentException e) {
                    log.error("No IdType ENUM for identifier '" + identifier + "'");
                }
            }
        }
        return identifiers;
    }

    public static List<Address> transformAddress(SearcRequestMemberDemographic demo) {
        MemberAddress address = demo.getAddress();
        //TODO: Implement address type for Server side request
        Address b50Address = new Address(
                address.getAddressLine1(),
                address.getAddressLine2(),
                address.getPostalCode(),
                address.getCountry(),
                address.getState(),
                address.getCity(),
                null
        );
        return List.of(b50Address);
    }
}
