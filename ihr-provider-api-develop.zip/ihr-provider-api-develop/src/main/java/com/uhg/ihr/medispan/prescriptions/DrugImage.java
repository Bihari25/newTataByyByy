package com.uhg.ihr.medispan.prescriptions;

/**
 * Defines DrugImage.java.
 */
public class DrugImage {

    /**
     * @param imageFile the drug image file.
     * @param description the drug description.
     * @param descAbbrev the product description abbreviation.
     * @param labeler the drug labeler description.
     */
    public DrugImage(String imageFile, String description, String descAbbrev, String labeler) {
        super();
        setImageFile(imageFile);
        setDescription(description);
        setDescAbbrev(descAbbrev);
        setLabeler(labeler);
    }
    
    private String imageFile;
    private String description;
    private String descAbbrev;
    private String labeler;
    
    /**
     * Returns the drug image file.
     * 
     * @return the drug image file.
     */
    public String getImageFile() {
        return imageFile;
    }
    
    /**
     * Returns the drug description.
     * 
     * @return the drug description.
     */
    public String getDescription() {
        return description;
    }
    
    /**
     * Returns the identifier of name, strength, dose form, and manufacturer in a structured format.
     * 
     * @return the product description abbreviation.
     */
    public String getDescAbbrev() {
        return descAbbrev;
    }
    
    /**
     * Returns the drug labeler description.
     * 
     * @return the drug labeler description.
     */
    public String getLabeler() {
        return labeler;
    }
    
    /**
     * Sets the drug image file.
     * 
     * @param imageFile the drug image file.
     */
    private void setImageFile(String imageFile) {
        this.imageFile = imageFile;
    }
    
    /**
     * Sets the drug description.
     * 
     * @param description   the drug description.
     */
    private void setDescription(String description) {
        this.description = description;
    }
    
    /**
     * Sets the product description abbreviation.
     * 
     * @param descAbbrev    the product description abbreviation.
     */
    private void setDescAbbrev(String descAbbrev) {
        this.descAbbrev = descAbbrev;
    }

    /**
     * Sets the drug labeler description.
     * 
     * @param labeler   the drug labeler description.
     */
    private void setLabeler(String labeler) {
        this.labeler = labeler;
    }
    
    @Override
	public String toString() {
        return imageFile;
    }
    
}
