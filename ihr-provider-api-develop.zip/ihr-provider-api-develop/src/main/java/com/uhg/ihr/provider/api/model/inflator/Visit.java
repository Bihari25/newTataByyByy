
package com.uhg.ihr.provider.api.model.inflator;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.google.gson.annotations.Expose;

import javax.annotation.Generated;
import java.io.Serializable;

@Generated("net.hexar.json2pojo")
@JsonIgnoreProperties(ignoreUnknown = true)
@SuppressWarnings("unused")
public class Visit implements Serializable {

    @Expose
    private String ihrLaymanTerm;
    @Expose
    private String ihrTerm;
    @Expose
    private String sourceVocabulary;
    @Expose
    private String sourceVocabularyCode;

    public String getIhrLaymanTerm() {
        return ihrLaymanTerm;
    }

    public void setIhrLaymanTerm(String ihrLaymanTerm) {
        this.ihrLaymanTerm = ihrLaymanTerm;
    }

    public String getIhrTerm() {
        return ihrTerm;
    }

    public void setIhrTerm(String ihrTerm) {
        this.ihrTerm = ihrTerm;
    }

    public String getSourceVocabulary() {
        return sourceVocabulary;
    }

    public void setSourceVocabulary(String sourceVocabulary) {
        this.sourceVocabulary = sourceVocabulary;
    }

    public String getSourceVocabularyCode() {
        return sourceVocabularyCode;
    }

    public void setSourceVocabularyCode(String sourceVocabularyCode) {
        this.sourceVocabularyCode = sourceVocabularyCode;
    }

}
