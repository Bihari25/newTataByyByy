package com.uhg.ihr.provider.api.model.inflator;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import org.apache.commons.lang3.builder.ToStringBuilder;

import java.io.Serializable;
import java.util.List;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
        "recordType",
        "healthCondition",
        "dataSource",
        "lastUpdateDate",
        "objectId",
        "onsetDate",
        "presenceStateTerm",
        "relatedCareTeam",
        "relatedConditions",
        "relatedObservations",
        "sensitivityClasses",
        "sourceClaimIds",
        "conditionStartDate",
        "status",
        "clinicallyRelevantDate"
})
@JsonIgnoreProperties(ignoreUnknown = true)
public class Condition implements Serializable {

    @JsonProperty("recordType")
    private String recordType;
    @JsonProperty("healthCondition")
    private HealthCondition healthCondition;
    @JsonProperty("dataSource")
    private List<String> dataSource = null;
    @JsonProperty("lastUpdateDate")
    private String lastUpdateDate;
    @JsonProperty("objectId")
    private long objectId;
    @JsonProperty("onsetDate")
    private Object onsetDate;
    @JsonProperty("presenceStateTerm")
    private String presenceStateTerm;
    @JsonProperty("relatedCareTeam")
    private List<Object> relatedCareTeam = null;
    @JsonProperty("relatedConditions")
    private List<Object> relatedConditions = null;
    @JsonProperty("relatedObservations")
    private List<Object> relatedObservations = null;
    @JsonProperty("sensitivityClasses")
    private List<Object> sensitivityClasses = null;
    @JsonProperty("sourceClaimIds")
    private List<String> sourceClaimIds = null;
    @JsonProperty("conditionStartDate")
    private String conditionStartDate;
    @JsonProperty("status")
    private Status status;
    @JsonProperty("clinicallyRelevantDate")
    private String clinicallyRelevantDate;

    @JsonProperty("recordType")
    public String getRecordType() {
        return recordType;
    }

    @JsonProperty("recordType")
    public void setRecordType(String recordType) {
        this.recordType = recordType;
    }

    @JsonProperty("healthCondition")
    public HealthCondition getHealthCondition() {
        return healthCondition;
    }

    @JsonProperty("healthCondition")
    public void setHealthCondition(HealthCondition healthCondition) {
        this.healthCondition = healthCondition;
    }

    @JsonProperty("dataSource")
    public List<String> getDataSource() {
        return dataSource;
    }

    @JsonProperty("dataSource")
    public void setDataSource(List<String> dataSource) {
        this.dataSource = dataSource;
    }

    @JsonProperty("lastUpdateDate")
    public String getLastUpdateDate() {
        return lastUpdateDate;
    }

    @JsonProperty("lastUpdateDate")
    public void setLastUpdateDate(String lastUpdateDate) {
        this.lastUpdateDate = lastUpdateDate;
    }

    @JsonProperty("objectId")
    public long getObjectId() {
        return objectId;
    }

    @JsonProperty("objectId")
    public void setObjectId(long objectId) {
        this.objectId = objectId;
    }

    @JsonProperty("onsetDate")
    public Object getOnsetDate() {
        return onsetDate;
    }

    @JsonProperty("onsetDate")
    public void setOnsetDate(Object onsetDate) {
        this.onsetDate = onsetDate;
    }

    @JsonProperty("presenceStateTerm")
    public String getPresenceStateTerm() {
        return presenceStateTerm;
    }

    @JsonProperty("presenceStateTerm")
    public void setPresenceStateTerm(String presenceStateTerm) {
        this.presenceStateTerm = presenceStateTerm;
    }

    @JsonProperty("relatedCareTeam")
    public List<Object> getRelatedCareTeam() {
        return relatedCareTeam;
    }

    @JsonProperty("relatedCareTeam")
    public void setRelatedCareTeam(List<Object> relatedCareTeam) {
        this.relatedCareTeam = relatedCareTeam;
    }

    @JsonProperty("relatedConditions")
    public List<Object> getRelatedConditions() {
        return relatedConditions;
    }

    @JsonProperty("relatedConditions")
    public void setRelatedConditions(List<Object> relatedConditions) {
        this.relatedConditions = relatedConditions;
    }

    @JsonProperty("relatedObservations")
    public List<Object> getRelatedObservations() {
        return relatedObservations;
    }

    @JsonProperty("relatedObservations")
    public void setRelatedObservations(List<Object> relatedObservations) {
        this.relatedObservations = relatedObservations;
    }

    @JsonProperty("sensitivityClasses")
    public List<Object> getSensitivityClasses() {
        return sensitivityClasses;
    }

    @JsonProperty("sensitivityClasses")
    public void setSensitivityClasses(List<Object> sensitivityClasses) {
        this.sensitivityClasses = sensitivityClasses;
    }

    @JsonProperty("sourceClaimIds")
    public List<String> getSourceClaimIds() {
        return sourceClaimIds;
    }

    @JsonProperty("sourceClaimIds")
    public void setSourceClaimIds(List<String> sourceClaimIds) {
        this.sourceClaimIds = sourceClaimIds;
    }

    @JsonProperty("conditionStartDate")
    public String getConditionStartDate() {
        return conditionStartDate;
    }

    @JsonProperty("conditionStartDate")
    public void setConditionStartDate(String conditionStartDate) {
        this.conditionStartDate = conditionStartDate;
    }

    @JsonProperty("status")
    public Status getStatus() {
        return status;
    }

    @JsonProperty("status")
    public void setStatus(Status status) {
        this.status = status;
    }

    @JsonProperty("clinicallyRelevantDate")
    public String getClinicallyRelevantDate() {
        return clinicallyRelevantDate;
    }

    @JsonProperty("clinicallyRelevantDate")
    public void setClinicallyRelevantDate(String clinicallyRelevantDate) {
        this.clinicallyRelevantDate = clinicallyRelevantDate;
    }

    @Override
    public String toString() {
        return new ToStringBuilder(this).append("recordType", recordType).append("healthCondition", healthCondition).append("dataSource", dataSource).append("lastUpdateDate", lastUpdateDate).append("objectId", objectId).append("onsetDate", onsetDate).append("presenceStateTerm", presenceStateTerm).append("relatedCareTeam", relatedCareTeam).append("relatedConditions", relatedConditions).append("relatedObservations", relatedObservations).append("sensitivityClasses", sensitivityClasses).append("sourceClaimIds", sourceClaimIds).append("conditionStartDate", conditionStartDate).append("status", status).append("clinicallyRelevantDate", clinicallyRelevantDate).toString();
    }

}