package com.uhg.ihr.medispan.dib.loaders;

/**
*
*/
public class Mmwinddruglink extends TableLoader {
    
	/**
	 *
	 */
    public Mmwinddruglink() {
        super();
    }
    
    @Override
    public String getCreateQuery() {
        return
        "CREATE TABLE mmw_ind_druglink " +
        "( " +
            "gpi                         CHARACTER VARYING(14) NOT NULL, " +
            "mcid                        INTEGER NOT NULL, " +
            "restrictionid               INTEGER NOT NULL, " +
            "microorganismid             INTEGER NOT NULL, " +
            "roleoftherapycode           CHARACTER VARYING(2) NOT NULL, " +
            "outcomecode                 CHARACTER VARYING(2) NOT NULL, " +
            "treatmentrankcode           CHARACTER VARYING(2) NOT NULL, " +
            "acceptancelvlcode           CHARACTER VARYING(2) NOT NULL, " +
            "proxycode                   CHARACTER VARYING(1) NOT NULL, " +
            "proxyonlyind                SMALLint NOT NULL, " +
            "CONSTRAINT mmw_ind_druglink_pkey PRIMARY KEY (gpi, mcid, restrictionid, microorganismid) " +
        ") " +
        "WITH (OIDS=TRUE); ";
    }
    
    @Override
    public String getInsertQuery(String line) {
        String[] fields = line.split("\\|");
        
        return "INSERT INTO mmw_ind_druglink VALUES " +
        "( " +
            "'" + fields[0] + "'," +                //gpi                         CHARACTER VARYING(14) NOT NULL
            Integer.parseInt(fields[1]) + "," +     //mcid                        INTEGER NOT NULL
            Integer.parseInt(fields[2]) + "," +     //restrictionid               INTEGER NOT NULL
            Integer.parseInt(fields[3]) + "," +     //microorganismid             INTEGER NOT NULL
            "'" + fields[4] + "'," +                //roleoftherapycode           CHARACTER VARYING(2) NOT NULL
            "'" + fields[5] + "'," +                //outcomecode                 CHARACTER VARYING(2) NOT NULL
            "'" + fields[6] + "'," +                //treatmentrankcode           CHARACTER VARYING(2) NOT NULL
            "'" + fields[7] + "'," +                //acceptancelvlcode           CHARACTER VARYING(2) NOT NULL
            "'" + fields[8] + "'," +                //proxycode                   CHARACTER VARYING(1) NOT NULL
            Integer.parseInt(fields[9]) +           //proxyonlyind                SMALLint NOT NULL
        " ); ";
    }

}
