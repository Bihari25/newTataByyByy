package com.uhg.ihr.medispan.dib.loaders;

/**
*
*/
public class Mmwclsahfs extends TableLoader {
    
	/**
	 *
	 */
    public Mmwclsahfs() {
        super();
    }
    
    @Override
    public String getCreateQuery() {
        return
        "CREATE TABLE mmw_cls_ahfs " +
        "( " +
            "classid                     CHARACTER VARYING(6) NOT NULL, " +
            "descdisplay                 CHARACTER VARYING(65) NOT NULL, " +
            "descsearch                  CHARACTER VARYING(65) NOT NULL, " +
            "descphonetic                CHARACTER VARYING(65) NOT NULL, " +
            "parentclassid               CHARACTER VARYING(6) NULL, " +
            "haschildrenind              SMALLINT NOT NULL, " +
            "CONSTRAINT mmw_cls_ahfs_pkey PRIMARY KEY (classid) " +
        ") " +
        "WITH (OIDS=TRUE); ";
    }
    
    @Override
    public String getInsertQuery(String line) {
        String[] fields = line.split("\\|");
        
        return "INSERT INTO mmw_cls_ahfs VALUES " +
        "( " +
            "'" + fields[0] + "'," +        //classid           CHARACTER VARYING(6) NOT NULL
            "'" + fields[1] + "'," +        //descdisplay       CHARACTER VARYING(65) NOT NULL
            "'" + fields[2] + "'," +        //descsearch        CHARACTER VARYING(65) NOT NULL
            "'" + fields[3] + "'," +        //descphonetic      CHARACTER VARYING(65) NOT NULL
            (fields[4].isEmpty() ? "NULL" : "'" + fields[4] + "'") + "," +        //parentclassid     CHARACTER VARYING(6) NULL
            Integer.parseInt(fields[5]) +   //haschildrenind    SMALLINT NOT NULL
        " ); ";
    }

}
