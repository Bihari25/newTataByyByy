package com.uhg.ihr.provider.api.controller;

import com.uhg.ihr.audit.annotations.AuditContextValue;
import com.uhg.ihr.provider.api.model.ProviderApiHeaders;
import com.uhg.ihr.provider.api.service.RelationshipInterface;
import com.uhg.ihr.audit.annotations.AuditRequest;
import com.uhg.ihr.provider.api.service.relationship.model.RelationshipRequest;
import com.uhg.ihr.provider.api.service.relationship.model.RelationshipResponse;
import com.uhg.ihr.provider.api.validator.ValidRelationshipRequest;
import io.micronaut.context.annotation.Context;
import io.micronaut.http.HttpRequest;
import io.micronaut.http.MutableHttpResponse;
import io.micronaut.http.annotation.*;
import io.micronaut.validation.Validated;
import io.reactivex.Maybe;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.responses.ApiResponse;

import javax.inject.Inject;

import static com.uhg.ihr.provider.api.util.ControllerUtil.buildHttpResponse;

@Validated
@Context
@Controller("/individual-health-records/v1")
public class RelationshipController {

    @Inject
    RelationshipInterface service;

    @Post("{patient-id}/relationship")
    @Operation(
            summary = "Create a Patient-Provider relationship",
            description = "Creates a relationship between a patient and provider.",
            operationId = "create-relationship"
    )
    @ApiResponse(
            responseCode = "200",
            description = "Returns JSON object containing the new relationship data"
    )
    @ApiResponse(
            responseCode = "404",
            description = "Returned when no patient is found"
    )
    @AuditRequest(auditType = "patient_relationship_create")
    public Maybe<MutableHttpResponse<RelationshipResponse>> createRelationship(HttpRequest myRequest,
                                                                               @RequestBean ProviderApiHeaders headers,
                                                                               @PathVariable("patient-id") String patientId,
                                                                               @AuditContextValue(
                                                                                       context = AuditContextValue.ContextType.DETAIL,
                                                                                       dataPath = "providerRole",
                                                                                       contextPath = {"relationship", "role"}
                                                                               )
                                                                               @AuditContextValue(
                                                                                       context = AuditContextValue.ContextType.DETAIL,
                                                                                       dataPath = "effectiveDate",
                                                                                       contextPath = {"relationship", "effectiveDate"}
                                                                               )
                                                                               @AuditContextValue(
                                                                                       context = AuditContextValue.ContextType.DETAIL,
                                                                                       dataPath = "terminationDate",
                                                                                       contextPath = {"relationship", "terminationDate"}
                                                                               )
                                                                               @ValidRelationshipRequest @Body RelationshipRequest request) {
        return buildHttpResponse(
                service.manageRelationship(request, patientId, headers),
                myRequest,
                "CreateRelationship");
    }

    @Post("{patient-id}/update")
    @Operation(
            summary = "Update a Patient-Provider relationship",
            description = "Updates a relationship between a patient and provider.",
            operationId = "manage-relationship"
    )
    @ApiResponse(
            responseCode = "200",
            description = "Returns JSON object containing the updated relationship data"
    )
    @ApiResponse(
            responseCode = "404",
            description = "Returned when no patient is found"
    )
    @AuditRequest(auditType = "patient_relationship_read")
    public Maybe<MutableHttpResponse<RelationshipResponse>> updateRelationship(HttpRequest myRequest,
                                                                               @RequestBean ProviderApiHeaders headers,
                                                                               @PathVariable("patient-id") String patientId,
                                                                               @ValidRelationshipRequest @Body RelationshipRequest request) {

        return buildHttpResponse(
                service.manageRelationship(request, patientId, headers),
                myRequest,
                "UpdateRelationship");
    }
}
