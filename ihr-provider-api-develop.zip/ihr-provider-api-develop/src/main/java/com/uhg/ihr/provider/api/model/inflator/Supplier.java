package com.uhg.ihr.provider.api.model.inflator;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import org.apache.commons.lang3.builder.ToStringBuilder;

import java.io.Serializable;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
        "name",
        "npinum"
})
@JsonIgnoreProperties(ignoreUnknown = true)
public class Supplier implements Serializable {

    @JsonProperty("name")
    private String name;
    @JsonProperty("npinum")
    private String npinum;

    @JsonProperty("name")
    public String getName() {
        return name;
    }

    @JsonProperty("name")
    public void setName(String name) {
        this.name = name;
    }

    @JsonProperty("npinum")
    public String getNpinum() {
        return npinum;
    }

    @JsonProperty("npinum")
    public void setNpinum(String npinum) {
        this.npinum = npinum;
    }

    @Override
    public String toString() {
        return new ToStringBuilder(this).append("name", name).append("npinum", npinum).toString();
    }

}
