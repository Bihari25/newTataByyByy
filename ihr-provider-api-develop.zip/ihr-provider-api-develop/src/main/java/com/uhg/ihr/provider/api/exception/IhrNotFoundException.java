package com.uhg.ihr.provider.api.exception;

import lombok.RequiredArgsConstructor;

@RequiredArgsConstructor
public class IhrNotFoundException extends RuntimeException {
    public IhrNotFoundException(String message) {
        super(message);
    }
}