package com.uhg.ihr.provider.api.model.senzing;


import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import org.apache.commons.lang3.builder.ToStringBuilder;

import java.io.Serializable;
import java.util.List;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
        "primaryValue",
        "usageType",
        "duplicateValues"
})
@JsonIgnoreProperties(ignoreUnknown = true)
public class Feature implements Serializable {

    @JsonProperty("primaryValue")
    private String primaryValue;
    @JsonProperty("usageType")
    private String usageType;
    @JsonProperty("duplicateValues")
    private List<Object> duplicateValues = null;

    @JsonProperty("primaryValue")
    public String getPrimaryValue() {
        return primaryValue;
    }

    @JsonProperty("primaryValue")
    public void setPrimaryValue(String primaryValue) {
        this.primaryValue = primaryValue;
    }

    @JsonProperty("usageType")
    public String getUsageType() {
        return usageType;
    }

    @JsonProperty("usageType")
    public void setUsageType(String usageType) {
        this.usageType = usageType;
    }

    @JsonProperty("duplicateValues")
    public List<Object> getDuplicateValues() {
        return duplicateValues;
    }

    @JsonProperty("duplicateValues")
    public void setDuplicateValues(List<Object> duplicateValues) {
        this.duplicateValues = duplicateValues;
    }

    @Override
    public String toString() {
        return new ToStringBuilder(this).append("primaryValue", primaryValue).append("usageType", usageType).append("duplicateValues", duplicateValues).toString();
    }

}