package com.uhg.ihr.provider.api.service.security.database;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ObjectNode;
import com.mongodb.reactivestreams.client.MongoClient;
import com.uhg.ihr.provider.api.exception.IhrBadRequestException;
import com.uhg.ihr.provider.api.exception.UnhandledApiException;
import com.uhg.ihr.provider.api.model.profile.RoleLookup;
import com.uhg.ihr.provider.api.model.profile.UserPermission;
import com.uhg.ihr.provider.api.model.profile.UserProfileConstant;
import com.uhg.ihr.provider.api.service.security.SecurityApi;
import com.uhg.ihr.provider.api.service.security.model.RoleChangeRequest;
import com.uhg.ihr.provider.api.service.security.model.SecurityMappingMongo;
import com.uhg.ihr.provider.api.service.security.model.SecurityObjectsMongo;
import io.micronaut.context.annotation.Value;
import io.reactivex.Flowable;
import io.reactivex.Maybe;
import lombok.extern.slf4j.Slf4j;
import org.bson.Document;

import javax.inject.Inject;
import javax.inject.Named;
import javax.inject.Singleton;
import java.io.IOException;
import java.util.*;

import static com.mongodb.client.model.Filters.eq;

@Slf4j
@Singleton
public class SecurityApiImpl implements SecurityApi {

    @Value("${mongoportal.database}")
    private String database;

    @Value("${mongoportal.collection.role}")
    private String roleCollection;

    @Value("${mongoportal.collection.ihrroles}")
    private String ihrRolesCollection;

    @Inject
    @Named("mongoportal")
    private MongoClient mongoClient;

    public Maybe<List<UserPermission>> lookupRoles(RoleLookup lookup) {
        return Flowable
                .fromPublisher(
                        mongoClient
                                .getDatabase(database)
                                .getCollection(roleCollection)
                                .find(eq("_id", lookup.getExternalSecurity().getSecuredContext().name()))
                                .limit(1)
                )
                .firstElement()
                .map(roleMapping -> {
                    SecurityMappingMongo rootMap = buildMappingObj(roleMapping);
                    Map<String, Map<UserProfileConstant.ROLE_CONTEXT, SecurityObjectsMongo>> mapping = rootMap.getMapping();
                    Map<String, Map<UserProfileConstant.ROLE_CONTEXT, SecurityObjectsMongo>> foundRoles = new HashMap<>();
                    lookup.getExternalSecurity().getRoles().forEach(role -> {
                        if (mapping.containsKey(role)) {
                            foundRoles.put(role, mapping.get(role));
                        }
                    });

                    Set<UserProfileConstant.ROLE_CONTEXT> contextFilters = lookup.getFilterContext();
                    boolean skipFilter = contextFilters == null || contextFilters.isEmpty();

                    Map<UserProfileConstant.ROLE_CONTEXT, UserPermission> permissions = new HashMap<>();
                    foundRoles.forEach((role, contexts) ->
                            contexts.forEach((context, securityObjects) -> {
                                if (skipFilter || contextFilters.contains(context)) {
                                    UserPermission buildPermission;
                                    if (!permissions.containsKey(context)) {
                                        buildPermission = new UserPermission();
                                        buildPermission.setContext(context);
                                        permissions.put(context, buildPermission);
                                    } else {
                                        buildPermission = permissions.get(context);
                                    }
                                    if (securityObjects.getRoles() != null) {
                                        if (buildPermission.getRoles() == null) {
                                            buildPermission.setRoles(new HashSet<>());
                                        }
                                        buildPermission.getRoles().addAll(securityObjects.getRoles());
                                    }
                                    if (securityObjects.getGroups() != null) {
                                        if (buildPermission.getGroups() == null) {
                                            buildPermission.setGroups(new HashSet<>());
                                        }
                                        buildPermission.getGroups().addAll(securityObjects.getGroups());
                                    }
                                }
                            })
                    );
                    return new ArrayList<>(permissions.values());
                });
    }

    public Maybe<RoleChangeRequest> putRoles(RoleChangeRequest request) {
        return validateIhrRoles(request)
                .flatMap(result ->
                        Flowable
                                .fromPublisher(
                                        mongoClient
                                                .getDatabase(database)
                                                .getCollection(roleCollection)
                                                .find(eq("_id", request.getSecuredContext().name()))
                                                .limit(1)
                                )
                                .firstElement()
                )
                .flatMap(document -> {
                    UserProfileConstant.SECURED_CONTEXT contextId = UserProfileConstant.SECURED_CONTEXT.valueOf(document.getString("_id"));
                    SecurityMappingMongo mapping;
                    if (document.containsKey("mapping")) {
                        mapping = buildMappingObj(document);
                    } else {
                        mapping = new SecurityMappingMongo(new HashMap<>());
                    }
                    Map<String, Map<UserProfileConstant.ROLE_CONTEXT, SecurityObjectsMongo>> requestMapping = request.getMapping();
                    mapping.getMapping().putAll(requestMapping);

                    ObjectMapper mapper = new ObjectMapper();
                    return Flowable
                            .fromPublisher(
                                    mongoClient
                                            .getDatabase(database)
                                            .getCollection(roleCollection)
                                            .replaceOne(eq("_id", contextId.name()), Document.parse(mapper.writeValueAsString(mapping)))
                            )
                            .firstElement()
                            .flatMap(updateResult -> {
                                if (updateResult.getModifiedCount() != 1 || updateResult.getMatchedCount() != 1) {
                                    return Maybe.error(new UnhandledApiException("Had issue with updating mongo"));
                                } else {
                                    return Maybe.just(request);
                                }
                            });
                });
    }

    public Maybe<Boolean> validateIhrRoles(RoleChangeRequest changeRequest) {
        return Flowable
                .fromPublisher(
                        mongoClient
                                .getDatabase(database)
                                .getCollection(ihrRolesCollection)
                                .find()
                )
                .map(document -> {
                    Set<String> stuff = new HashSet<>();
                    stuff.add(document.getString("_id"));
                    return stuff;
                })
                .reduce((combined, list) -> {
                    combined.addAll(list);
                    return combined;
                })
                .flatMap(ihrRoles -> {
                    Set<String> nonexistentIhrRoles = new HashSet<>();
                    changeRequest.getMapping().forEach((roleName, roleContexts) -> {
                        SecurityObjectsMongo securityObject = roleContexts.get(UserProfileConstant.ROLE_CONTEXT.IHR);
                        if (securityObject != null && securityObject.getRoles() != null) {
                            securityObject
                                    .getRoles()
                                    .forEach(role -> {
                                        if (!ihrRoles.contains(role.getId())) {
                                            nonexistentIhrRoles.add(role.getId());
                                        }
                                    });
                        }
                    });
                    if (!nonexistentIhrRoles.isEmpty()) {
                        return Maybe.error(new IhrBadRequestException("The following IHR Roles do not exist: " + nonexistentIhrRoles.stream().reduce((str1, str2) -> str1 + "," + str2).orElse("")));
                    } else {
                        return Maybe.just(true);
                    }
                });
    }

    public SecurityMappingMongo buildMappingObj(Document mongoDoc) {
        try {
            ObjectMapper mapper = new ObjectMapper();
            ObjectNode docNode = (ObjectNode) mapper.readTree(mongoDoc.toJson());
            docNode.remove("_id");
            return mapper.readValue(mapper.writeValueAsString(docNode), SecurityMappingMongo.class);
        } catch (IOException e) {
            throw new UnhandledApiException(e);
        }
    }
}
