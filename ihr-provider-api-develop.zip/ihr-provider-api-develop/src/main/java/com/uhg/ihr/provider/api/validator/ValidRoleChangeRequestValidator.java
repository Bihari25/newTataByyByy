package com.uhg.ihr.provider.api.validator;

import com.uhg.ihr.provider.api.service.security.model.RoleChangeRequest;
import com.uhg.ihr.provider.api.service.security.model.SecurityObjectsMongo;

import javax.validation.*;
import java.util.ArrayList;
import java.util.List;
import java.util.Set;

public class ValidRoleChangeRequestValidator implements ConstraintValidator<ValidRoleChangeRequest, RoleChangeRequest> {

    @Override
    public boolean isValid(final RoleChangeRequest request, final ConstraintValidatorContext constraintValidatorContext) {
        constraintValidatorContext.disableDefaultConstraintViolation();
        Validator validator = Validation.buildDefaultValidatorFactory().getValidator();
        Set<ConstraintViolation<RoleChangeRequest>> violations = validator.validate(request);
        if (!violations.isEmpty()) {
            violations.forEach(violation ->
                    constraintValidatorContext.buildConstraintViolationWithTemplate(violation.getMessage()).addConstraintViolation()
            );
            return false;
        }
        List<String> configViolations = new ArrayList<>();
        request.getMapping().forEach((role, roleMap) -> {
            if (roleMap == null || roleMap.isEmpty()) {
                configViolations.add("The context mapping for '" + role + "' must not be empty.");
            } else {
                roleMap.forEach((context, config) -> {
                    if (config == null ||
                            (config.getRoles() == null || config.getRoles().isEmpty()) &&
                                    (config.getGroups() == null || config.getGroups().isEmpty())) {
                        configViolations.add("The role mapping for '" + role + "' -> '" + context.name() + "' must have at least groups or roles with one element");
                        return;
                    }
                    Set<ConstraintViolation<SecurityObjectsMongo>> badConfigViolations = validator.validate(config);
                    badConfigViolations.forEach(violation -> configViolations.add(violation.getMessage()));
                });
            }
        });

        if (configViolations.isEmpty()) {
            return true;
        } else {
            constraintValidatorContext.buildConstraintViolationWithTemplate(configViolations.get(0)).addConstraintViolation();
            return false;
        }
    }
}