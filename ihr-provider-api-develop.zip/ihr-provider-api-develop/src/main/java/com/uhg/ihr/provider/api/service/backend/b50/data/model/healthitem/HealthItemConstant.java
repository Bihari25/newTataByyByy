package com.uhg.ihr.provider.api.service.backend.b50.data.model.healthitem;

public interface HealthItemConstant {

    interface RelatedCareTeam {
        public final static String ORDERING_PROVIDER = "Ordering Provider";

        public final static String RENDERING_SERVICE_PROVIDER = "Rendering Service Provider";

        public final static String ATTENDING_PRACTIONER = "Attending Practitioner";

        public final static String REFERRING_PROVIDER = "Referring Provider";
    }

    interface RelatedProviderService {
        public final static String SERVICE_PROVIDER_ORGANIZATION = "Service Provider Organization";
        public final static String MEDICATION_PRODUCT_SUPPLIER = "Medication Product Supplier";
    }
}
