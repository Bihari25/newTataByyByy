
package com.uhg.ihr.provider.api.model.inflator;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.google.gson.annotations.Expose;

import javax.annotation.Generated;
import java.io.Serializable;

@Generated("net.hexar.json2pojo")
@JsonIgnoreProperties(ignoreUnknown = true)
@SuppressWarnings("unused")
public class MbrId implements Serializable {

    @Expose
    private Big5 big5;
    @Expose
    private String idType;
    @Expose
    private String idValue;

    public Big5 getBig5() {
        return big5;
    }

    public void setBig5(Big5 big5) {
        this.big5 = big5;
    }

    public String getIdType() {
        return idType;
    }

    public void setIdType(String idType) {
        this.idType = idType;
    }

    public String getIdValue() {
        return idValue;
    }

    public void setIdValue(String idValue) {
        this.idValue = idValue;
    }

}
