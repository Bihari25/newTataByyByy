package com.uhg.ihr.provider.api.service.relationship;

import com.uhg.ihr.provider.api.model.ProviderApiHeaders;
import com.uhg.ihr.provider.api.service.RelationshipInterface;
import com.uhg.ihr.provider.api.service.relationship.model.Relationship;
import com.uhg.ihr.provider.api.service.relationship.model.RelationshipRequest;
import com.uhg.ihr.provider.api.service.relationship.model.RelationshipResponse;
import io.micronaut.context.annotation.Secondary;
import io.reactivex.Maybe;

import javax.inject.Singleton;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Secondary
@Singleton
public class RelationshipService implements RelationshipInterface {

    private Map<String, Map<String, Relationship>> patientProviderRelationships;

    public RelationshipService() {
        patientProviderRelationships = new HashMap<>();
    }

    public Maybe<RelationshipResponse> manageRelationship(RelationshipRequest request, String patientChid, ProviderApiHeaders headers) {
        Relationship relationship = new Relationship(
                request.getActorId(),
                request.getProviderRole().name(),
                request.getEffectiveDate(),
                request.getTerminationDate()
        );
        if (patientProviderRelationships.containsKey(patientChid)) {
            patientProviderRelationships.get(patientChid).put(request.getActorId(), relationship);
        } else {
            Map<String, Relationship> providers = new HashMap<>();
            providers.put(request.getActorId(), relationship);
            patientProviderRelationships.put(patientChid, providers);
        }
        return Maybe.just(new RelationshipResponse(patientChid, List.of(relationship)));
    }

//    public Maybe<RelationshipResponse> getRelationships(String patientChid) {
//        if (patientProviderRelationships.containsKey(patientChid)) {
//            return Maybe.just(new RelationshipResponse(patientChid, List.copyOf(patientProviderRelationships.get(patientChid).values())));
//        } else {
//            return Maybe.empty();
//        }
//    }
}
