package com.uhg.ihr.audit.service;

import com.uhg.ihr.audit.Audit;
import com.uhg.ihr.audit.producer.AuditClient;
import io.reactivex.Flowable;
import lombok.Data;
import lombok.extern.slf4j.Slf4j;

import javax.inject.Inject;
import javax.inject.Singleton;
import java.net.InetAddress;
import java.util.Map;

@Slf4j
@Singleton
@Data
public class AuditService {
    @Deprecated
    Map<String,Object> auditSysProperties;
    @Deprecated
    InetAddress ip;
    @Deprecated
    String hostname;
    @Inject
    private AuditClient auditClient;

    public Flowable<Audit> sendAudit(Audit audit) {
        return auditClient.send(audit);
    }

}


