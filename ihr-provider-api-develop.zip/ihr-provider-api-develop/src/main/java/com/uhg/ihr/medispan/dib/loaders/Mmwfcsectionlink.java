package com.uhg.ihr.medispan.dib.loaders;

/**
*
*/
public class Mmwfcsectionlink extends TableLoader {
    
	/**
	 *
	 */
    public Mmwfcsectionlink() {
        super();
    }
    
    @Override
    public String getCreateQuery() {
        return
        "CREATE TABLE mmw_fc_sectionlink " +
        "( " +
            "elementid                   INTEGER NOT NULL, " +
            "sectionid                   INTEGER NOT NULL, " +
            "CONSTRAINT mmw_fc_sectionlink_pkey PRIMARY KEY (elementid, sectionid) " +
        ") " +
        "WITH (OIDS=TRUE); ";
    }
    
    @Override
    public String getInsertQuery(String line) {
        String[] fields = line.split("\\|");
        
        return "INSERT INTO mmw_fc_sectionlink VALUES " +
        "( " +
            Integer.parseInt(fields[0]) + "," +     //elementid     INTEGER NOT NULL
            Integer.parseInt(fields[1]) +           //sectionid     INTEGER NOT NULL
        " ); ";
    }

}
