package com.uhg.ihr.provider.api.model.senzing;


import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import org.apache.commons.lang3.builder.ToStringBuilder;

import java.io.Serializable;
import java.util.List;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
        "ADDRESS",
        "ALT_MEMBER_ID",
        "CDB_CONSUMER_ID",  //
        "DOB",
        "GENDER",
        "GLOBAL_ACTOR_ID", //
        "NAME",
        "PHONE",
        "SSN",  //
        "SUBSCRIBER_ID",
        "UHCCDB_FAMILY_ID"
})
@JsonIgnoreProperties(ignoreUnknown = true)
public class Features implements Serializable {

    @JsonProperty("ADDRESS")
    private List<Feature> addresses = null;

    @JsonProperty("DOB")
    private List<Feature> dob = null;
    @JsonProperty("GENDER")
    private List<Feature> gender = null;
    @JsonProperty("NAME")
    private List<Feature> name = null;
    @JsonProperty("PHONE")
    private List<Feature> phone = null;

    @JsonProperty("ALT_MEMBER_ID")
    private List<Feature> altMemberId = null;
    @JsonProperty("CDB_CONSUMER_ID")
    private List<Feature> cdbConsumerId = null;
    @JsonProperty("SSN")
    private List<Feature> ssn = null;
    @JsonProperty("GLOBAL_ACTOR_ID")
    private List<Feature> globalActorId = null;
    @JsonProperty("UHCCDB_FAMILY_ID")
    private List<Feature> uhccdb = null;
    @JsonProperty("SUBSCRIBER_ID")
    private List<Feature> subscriberId = null;

    @JsonProperty("Feature")
    public List<Feature> getAddresses() {
        return addresses;
    }

    @JsonProperty("ADDRESS")
    public void setAddresses(List<Feature> addresses) {
        this.addresses = addresses;
    }

    @JsonProperty("DOB")
    public List<Feature> getDob() {
        return dob;
    }

    @JsonProperty("DOB")
    public void setDob(List<Feature> dob) {
        this.dob = dob;
    }

    @JsonProperty("GENDER")
    public List<Feature> getGender() {
        return gender;
    }

    @JsonProperty("GENDER")
    public void setGender(List<Feature> gender) {
        this.gender = gender;
    }


    @JsonProperty("NAME")
    public List<Feature> getName() {
        return name;
    }

    @JsonProperty("NAME")
    public void setName(List<Feature> name) {
        this.name = name;
    }

    @JsonProperty("PHONE")
    public List<Feature> getPhone() {
        return phone;
    }

    @JsonProperty("PHONE")
    public void setPhone(List<Feature> phone) {
        this.phone = phone;
    }

    @JsonProperty("ALT_MEMBER_ID")
    public List<Feature> getAltMemberId() {
        return altMemberId;
    }

    @JsonProperty("ALT_MEMBER_ID")
    public void setAltMemberId(List<Feature> altMemberId) {
        this.altMemberId = altMemberId;
    }

    @JsonProperty("CDB_CONSUMER_ID")
    public List<Feature> getCdbConsumerId() {
        return cdbConsumerId;
    }

    @JsonProperty("CDB_CONSUMER_ID")
    public void setCdbConsumerId(List<Feature> cdbConsumerId) {
        this.cdbConsumerId = cdbConsumerId;
    }

    @JsonProperty("SSN")
    public List<Feature> getSsn() {
        return ssn;
    }

    @JsonProperty("SSN")
    public void setSsn(List<Feature> ssn) {
        this.ssn = ssn;
    }

    @JsonProperty("GLOBAL_ACTOR_ID")
    public List<Feature> getGlobalActorId() {
        return globalActorId;
    }

    @JsonProperty("GLOBAL_ACTOR_ID")
    public void setGlobalActorId(List<Feature> globalActorId) {
        this.globalActorId = globalActorId;
    }

    @JsonProperty("UHCCDB_FAMILY_ID")
    public List<Feature> getUhccdb() {
        return uhccdb;
    }

    @JsonProperty("UHCCDB_FAMILY_ID")
    public void setUhccdb(List<Feature> uhccdb) {
        this.uhccdb = uhccdb;
    }
    @JsonProperty("SUBSCRIBER_ID")
    public List<Feature> getSubscriberId() {
        return subscriberId;
    }

    @JsonProperty("SUBSCRIBER_ID")
    public void setSubscriberId(List<Feature> subscriberId) {
        this.subscriberId = subscriberId;
    }

    @Override
    public String toString() {
        return new ToStringBuilder(this).append("addresses", addresses).append("dOB", dob).append("gender", gender).append("nAME", name).append("pHONE", phone).toString();
    }
}