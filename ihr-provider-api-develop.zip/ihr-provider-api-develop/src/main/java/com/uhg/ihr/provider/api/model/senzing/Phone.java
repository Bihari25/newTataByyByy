package com.uhg.ihr.provider.api.model.senzing;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import org.apache.commons.lang3.builder.ToStringBuilder;

import java.io.Serializable;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
        "PHONE_NUMBER",
        "PHONE_TYPE"
})
@JsonIgnoreProperties(ignoreUnknown = true)
public class Phone implements Serializable {

    @JsonProperty("PHONE_NUMBER")
    private String phoneNumber;
    @JsonProperty("PHONE_TYPE")
    private String phoneType;

    @JsonProperty("PHONE_NUMBER")
    public String getPhoneNumber() {
        return phoneNumber;
    }

    @JsonProperty("PHONE_NUMBER")
    public void setPhoneNumber(String phoneNumber) {
        this.phoneNumber = phoneNumber;
    }

    @JsonProperty("PHONE_TYPE")
    public String getPhoneType() {
        return phoneType;
    }

    @JsonProperty("PHONE_TYPE")
    public void setPhoneType(String phoneType) {
        this.phoneType = phoneType;
    }

    @Override
    public String toString() {
        return new ToStringBuilder(this).append("pHONENUMBER", getPhoneNumber()).append("pHONETYPE", getPhoneType()).toString();
    }

}