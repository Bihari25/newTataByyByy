package com.uhg.ihr.medispan.dib.loaders;

/**
*
*/
public class Mmwdrugkdclink extends TableLoader {
    
	/**
	 *
	 */
    public Mmwdrugkdclink() {
        super();
    }
    
    @Override
    public String getCreateQuery() {
        return
        "CREATE TABLE mmw_drug_kdclink " +
        "( " +
            "drugid                      CHARACTER VARYING(12) NOT NULL, " +
            "kdc1                        CHARACTER VARYING(5) NOT NULL, " +
            "rpid                        INTEGER NULL, " +
            "CONSTRAINT mmw_drug_kdclink_pkey PRIMARY KEY (drugid, kdc1) " +
        ") " +
        "WITH (OIDS=TRUE); ";
    }
    
    @Override
    public String getInsertQuery(String line) {
        String[] fields = line.split("\\|");
        
        return "INSERT INTO mmw_drug_kdclink VALUES " +
        "( " +
            "'" + fields[0] + "'," +           //drugid     CHARACTER VARYING(12) NOT NULL
            "'" + fields[1] + "'," +           //kdc1       CHARACTER VARYING(5) NOT NULL
            (fields.length < 3 || fields[2].isEmpty() ? "NULL" : Integer.parseInt(fields[2])) +      //rpid       INTEGER NULL
        " ); ";
    }

}
