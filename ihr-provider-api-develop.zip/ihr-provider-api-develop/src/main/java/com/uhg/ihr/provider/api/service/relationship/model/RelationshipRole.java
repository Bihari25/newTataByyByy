package com.uhg.ihr.provider.api.service.relationship.model;

import com.fasterxml.jackson.annotation.JsonValue;

public enum RelationshipRole {
    //The commented out relationship roles must be added to Core Ontology
    ATTENDING_NURSE("ATTENDING-NURSE"),
    CASE_MANAGER("CASE-MANAGER"),
    TRIAGER("TRIAGER"),
    RECORD_REVIEWER("RECORD-REVIEWER"),
    CONSULTING_PROVIDER("CONSULTING-PROVIDER"),
    ADMITTING_PROVIDER("ADMITTING-PROVIDER"),
    ATTRIBUTED_PROVIDER("ATTRIBUTED-PROVIDER"),
    MANAGING_CLINICIAN("MANAGING-CLINICIAN"),
    ATTENDING_PROVIDER("ATTENDING-PROVIDER"),
    ORDERING_PROVIDER("ORDERING-PROVIDER"),
    REFERRING_PROVIDER("REFERRING-PROVIDER"),
    PCP("PCP");

    @JsonValue
    String value;

    RelationshipRole(String value) {
        this.value = value;
    }
}
