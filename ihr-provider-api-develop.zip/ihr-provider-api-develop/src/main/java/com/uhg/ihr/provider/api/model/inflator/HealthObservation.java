package com.uhg.ihr.provider.api.model.inflator;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import org.apache.commons.lang3.builder.ToStringBuilder;

import java.io.Serializable;
import java.util.List;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
        "recordType",
        "abnormalObservation",
        "observation",
        "dataSource",
        "objectId",
        "observationDate",
        "referenceRange",
        "sensitivityClasses",
        "observationUnitOfMeasure",
        "observationValue",
        "valueString"
})
@JsonIgnoreProperties(ignoreUnknown = true)
public class HealthObservation implements Serializable {

    @JsonProperty("recordType")
    private String recordType;
    @JsonProperty("abnormalObservation")
    private Status abnormalObservation;
    @JsonProperty("observation")
    private Observation observation;
    @JsonProperty("dataSource")
    private List<Object> dataSource = null;
    @JsonProperty("objectId")
    private long objectId;
    @JsonProperty("observationDate")
    private String observationDate;
    @JsonProperty("referenceRange")
    private String referenceRange;
    @JsonProperty("sensitivityClasses")
    private List<Object> sensitivityClasses = null;
    @JsonProperty("observationUnitOfMeasure")
    private ObservationUnitOfMeasure observationUnitOfMeasure;
    @JsonProperty("observationValue")
    private ObservationValue observationValue;
    @JsonProperty("valueString")
    private String valueString;

    @JsonProperty("recordType")
    public String getRecordType() {
        return recordType;
    }

    @JsonProperty("recordType")
    public void setRecordType(String recordType) {
        this.recordType = recordType;
    }

    @JsonProperty("abnormalObservation")
    public Status getAbnormalObservation() {
        return abnormalObservation;
    }

    @JsonProperty("abnormalObservation")
    public void setAbnormalObservation(Status abnormalObservation) {
        this.abnormalObservation = abnormalObservation;
    }

    @JsonProperty("observation")
    public Observation getObservation() {
        return observation;
    }

    @JsonProperty("observation")
    public void setObservation(Observation observation) {
        this.observation = observation;
    }

    @JsonProperty("dataSource")
    public List<Object> getDataSource() {
        return dataSource;
    }

    @JsonProperty("dataSource")
    public void setDataSource(List<Object> dataSource) {
        this.dataSource = dataSource;
    }

    @JsonProperty("objectId")
    public long getObjectId() {
        return objectId;
    }

    @JsonProperty("objectId")
    public void setObjectId(long objectId) {
        this.objectId = objectId;
    }

    @JsonProperty("observationDate")
    public String getObservationDate() {
        return observationDate;
    }

    @JsonProperty("observationDate")
    public void setObservationDate(String observationDate) {
        this.observationDate = observationDate;
    }

    @JsonProperty("referenceRange")
    public String getReferenceRange() {
        return referenceRange;
    }

    @JsonProperty("referenceRange")
    public void setReferenceRange(String referenceRange) {
        this.referenceRange = referenceRange;
    }

    @JsonProperty("sensitivityClasses")
    public List<Object> getSensitivityClasses() {
        return sensitivityClasses;
    }

    @JsonProperty("sensitivityClasses")
    public void setSensitivityClasses(List<Object> sensitivityClasses) {
        this.sensitivityClasses = sensitivityClasses;
    }

    @JsonProperty("observationUnitOfMeasure")
    public ObservationUnitOfMeasure getObservationUnitOfMeasure() {
        return observationUnitOfMeasure;
    }

    @JsonProperty("observationUnitOfMeasure")
    public void setObservationUnitOfMeasure(ObservationUnitOfMeasure observationUnitOfMeasure) {
        this.observationUnitOfMeasure = observationUnitOfMeasure;
    }

    @JsonProperty("observationValue")
    public ObservationValue getObservationValue() {
        return observationValue;
    }

    @JsonProperty("observationValue")
    public void setObservationValue(ObservationValue observationValue) {
        this.observationValue = observationValue;
    }

    @JsonProperty("valueString")
    public String getValueString() {
        return valueString;
    }

    @JsonProperty("valueString")
    public void setValueString(String valueString) {
        this.valueString = valueString;
    }

    @Override
    public String toString() {
        return new ToStringBuilder(this).append("recordType", recordType).append("abnormalObservation", abnormalObservation).append("observation", observation).append("dataSource", dataSource).append("objectId", objectId).append("observationDate", observationDate).append("referenceRange", referenceRange).append("sensitivityClasses", sensitivityClasses).append("observationUnitOfMeasure", observationUnitOfMeasure).append("observationValue", observationValue).append("valueString", valueString).toString();
    }

}
