package com.uhg.ihr.provider.api.model.inflator;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import org.apache.commons.lang3.builder.ToStringBuilder;

import java.io.Serializable;
import java.util.List;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
        "recordType",
        "classification",
        "concept",
        "dataSource",
        "dueDate",
        "evaluation",
        "expectedAchievement",
        "lastUpdateDate",
        "objectId",
        "presenceState",
        "relatedConditions",
        "sensitivityClasses",
        "startDate",
        "clinicallyRelevantDate"
})
@JsonIgnoreProperties(ignoreUnknown = true)
public class HealthStatus implements Serializable {

    @JsonProperty("recordType")
    private String recordType;
    @JsonProperty("classification")
    private Classification classification;
    @JsonProperty("concept")
    private Concept concept;
    @JsonProperty("dataSource")
    private List<String> dataSource = null;
    @JsonProperty("dueDate")
    private Object dueDate;
    @JsonProperty("evaluation")
    private Evaluation evaluation;
    @JsonProperty("expectedAchievement")
    private Object expectedAchievement;
    @JsonProperty("lastUpdateDate")
    private String lastUpdateDate;
    @JsonProperty("objectId")
    private long objectId;
    @JsonProperty("presenceState")
    private PresenceState presenceState;
    @JsonProperty("relatedConditions")
    private List<Long> relatedConditions = null;
    @JsonProperty("sensitivityClasses")
    private List<Object> sensitivityClasses = null;
    @JsonProperty("startDate")
    private String startDate;
    @JsonProperty("clinicallyRelevantDate")
    private String clinicallyRelevantDate;

    @JsonProperty("recordType")
    public String getRecordType() {
        return recordType;
    }

    @JsonProperty("recordType")
    public void setRecordType(String recordType) {
        this.recordType = recordType;
    }

    @JsonProperty("classification")
    public Classification getClassification() {
        return classification;
    }

    @JsonProperty("classification")
    public void setClassification(Classification classification) {
        this.classification = classification;
    }

    @JsonProperty("concept")
    public Concept getConcept() {
        return concept;
    }

    @JsonProperty("concept")
    public void setConcept(Concept concept) {
        this.concept = concept;
    }

    @JsonProperty("dataSource")
    public List<String> getDataSource() {
        return dataSource;
    }

    @JsonProperty("dataSource")
    public void setDataSource(List<String> dataSource) {
        this.dataSource = dataSource;
    }

    @JsonProperty("dueDate")
    public Object getDueDate() {
        return dueDate;
    }

    @JsonProperty("dueDate")
    public void setDueDate(Object dueDate) {
        this.dueDate = dueDate;
    }

    @JsonProperty("evaluation")
    public Evaluation getEvaluation() {
        return evaluation;
    }

    @JsonProperty("evaluation")
    public void setEvaluation(Evaluation evaluation) {
        this.evaluation = evaluation;
    }

    @JsonProperty("expectedAchievement")
    public Object getExpectedAchievement() {
        return expectedAchievement;
    }

    @JsonProperty("expectedAchievement")
    public void setExpectedAchievement(Object expectedAchievement) {
        this.expectedAchievement = expectedAchievement;
    }

    @JsonProperty("lastUpdateDate")
    public String getLastUpdateDate() {
        return lastUpdateDate;
    }

    @JsonProperty("lastUpdateDate")
    public void setLastUpdateDate(String lastUpdateDate) {
        this.lastUpdateDate = lastUpdateDate;
    }

    @JsonProperty("objectId")
    public long getObjectId() {
        return objectId;
    }

    @JsonProperty("objectId")
    public void setObjectId(long objectId) {
        this.objectId = objectId;
    }

    @JsonProperty("presenceState")
    public PresenceState getPresenceState() {
        return presenceState;
    }

    @JsonProperty("presenceState")
    public void setPresenceState(PresenceState presenceState) {
        this.presenceState = presenceState;
    }

    @JsonProperty("relatedConditions")
    public List<Long> getRelatedConditions() {
        return relatedConditions;
    }

    @JsonProperty("relatedConditions")
    public void setRelatedConditions(List<Long> relatedConditions) {
        this.relatedConditions = relatedConditions;
    }

    @JsonProperty("sensitivityClasses")
    public List<Object> getSensitivityClasses() {
        return sensitivityClasses;
    }

    @JsonProperty("sensitivityClasses")
    public void setSensitivityClasses(List<Object> sensitivityClasses) {
        this.sensitivityClasses = sensitivityClasses;
    }

    @JsonProperty("startDate")
    public String getStartDate() {
        return startDate;
    }

    @JsonProperty("startDate")
    public void setStartDate(String startDate) {
        this.startDate = startDate;
    }

    @JsonProperty("clinicallyRelevantDate")
    public String getClinicallyRelevantDate() {
        return clinicallyRelevantDate;
    }

    @JsonProperty("clinicallyRelevantDate")
    public void setClinicallyRelevantDate(String clinicallyRelevantDate) {
        this.clinicallyRelevantDate = clinicallyRelevantDate;
    }

    @Override
    public String toString() {
        return new ToStringBuilder(this).append("recordType", recordType).append("classification", classification).append("concept", concept).append("dataSource", dataSource).append("dueDate", dueDate).append("evaluation", evaluation).append("expectedAchievement", expectedAchievement).append("lastUpdateDate", lastUpdateDate).append("objectId", objectId).append("presenceState", presenceState).append("relatedConditions", relatedConditions).append("sensitivityClasses", sensitivityClasses).append("startDate", startDate).append("clinicallyRelevantDate", clinicallyRelevantDate).toString();
    }

}