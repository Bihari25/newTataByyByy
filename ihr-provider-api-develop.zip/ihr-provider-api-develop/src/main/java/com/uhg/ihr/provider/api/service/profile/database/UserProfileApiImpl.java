package com.uhg.ihr.provider.api.service.profile.database;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ObjectNode;
import com.mongodb.ErrorCategory;
import com.mongodb.MongoWriteException;
import com.mongodb.reactivestreams.client.MongoClient;
import com.uhg.ihr.provider.api.exception.DataSyncException;
import com.uhg.ihr.provider.api.exception.IhrBadRequestException;
import com.uhg.ihr.provider.api.exception.NoUserFoundException;
import com.uhg.ihr.provider.api.exception.UnhandledApiException;
import com.uhg.ihr.provider.api.model.MemberName;
import com.uhg.ihr.provider.api.model.ProviderApiHeaders;
import com.uhg.ihr.provider.api.model.profile.*;
import com.uhg.ihr.provider.api.service.backend.b50.profile.B50ProfileService;
import com.uhg.ihr.provider.api.service.exception.ServiceException;
import com.uhg.ihr.provider.api.service.profile.UserProfileApi;
import com.uhg.ihr.provider.api.service.security.SecurityApi;
import io.micronaut.context.annotation.Value;
import io.micronaut.core.util.CollectionUtils;
import io.reactivex.Flowable;
import io.reactivex.Maybe;
import lombok.extern.slf4j.Slf4j;
import org.bson.Document;
import org.bson.conversions.Bson;

import javax.inject.Inject;
import javax.inject.Named;
import javax.inject.Singleton;
import java.io.IOException;
import java.util.*;
import java.util.stream.Collectors;

import static com.mongodb.client.model.Filters.and;
import static com.mongodb.client.model.Filters.eq;

@Slf4j
@Singleton
public class UserProfileApiImpl implements UserProfileApi {
    private static final Object modifyMutex = new Object();
    private static final ObjectMapper MAPPER = new ObjectMapper();

    @Inject
    private SecurityApi securityApi;

    @Inject
    private B50ProfileService profileService;

    @Value("${mongoportal.database}")
    private String database;

    @Value("${mongoportal.collection.userProfile}")
    private String userProfileCollection;

    @Inject
    @Named("mongoportal")
    private MongoClient mongoClient;

    @Override
    public Maybe<UserProfile> getUserProfileByChid(String chid, ProviderApiHeaders headers) {
        return Flowable
                .fromPublisher(mongoClient
                        .getDatabase(database)
                        .getCollection(userProfileCollection)
                        .find(eq("_id", chid))
                        .limit(1)
                )
                .firstElement()
                //Convert Mongo document to IhrUser
                .map(document -> {
                    try {
                        // Deserialize: remove the primary key from Json
                        document.remove("_id");
                        return MAPPER.readValue(document.toJson(), IhrUser.class);
                    } catch (IOException e) {
                        throw new ServiceException("Unable to deserialize UserProfile");
                    }
                })
                //Sanity check against B50 API to ensure user exists
                .flatMap(ihrUser ->
                        profileService
                                .getProfile(chid, headers)
                                .switchIfEmpty(Maybe.error(new DataSyncException("Failed to retrieve user from B50 API", DataSyncException.Location.B50)))
                                .map(b50User -> {
                                    ihrUser.combineIhrUsers(b50User);
                                    return UserProfile.builder()
                                            .user(ihrUser).build();
                                })
                                .onErrorResumeNext(Maybe.error(new DataSyncException("Failed to retrieve user from B50 API", DataSyncException.Location.B50)))
                )
                .defaultIfEmpty(new UserProfile());
    }

    @Override
    public Maybe<UserProfile> registerUser(UserProfileRequest request, ProviderApiHeaders headers) {
        return getUpdatedPermissions(request)
                .flatMap(updatedPermissions -> {
                    if (updatedPermissions == null || updatedPermissions.isEmpty()) {
                        return Maybe.error(new IhrBadRequestException("No actor roles found for the given externalSecurity roles"));
                    }
                    IhrUser user = request.getUser();
                    IhrUser createdUser = cloneUser(user);
                    createdUser.setUserPermissions(updatedPermissions);
                    return profileService.registerProfile(createdUser, headers)
                            .flatMap(registeredUser -> {
                                String chid = registeredUser.getIdentifierContextValue(UserProfileConstant.IDENTIFIER_CONTEXT.IHR);
                                createdUser.addIdentifierContext(UserProfileConstant.IDENTIFIER_CONTEXT.IHR, chid);
                                if (createdUser.getName() == null) {
                                    createdUser.setName(registeredUser.getName());
                                }
                                if (createdUser.getNpi() == null || createdUser.getNpi().isBlank()) {
                                    createdUser.setNpi(registeredUser.getNpi());
                                }

                                ObjectNode actorDocument = (ObjectNode) MAPPER.readTree(MAPPER.writeValueAsBytes(createdUser));
                                actorDocument.put("_id", chid);
                                synchronized (modifyMutex) {
                                    return Flowable
                                            .fromPublisher(
                                                    mongoClient
                                                            .getDatabase(database)
                                                            .getCollection(userProfileCollection)
                                                            .insertOne(Document.parse(MAPPER.writeValueAsString(actorDocument)))
                                            )
                                            .firstElement()
                                            .map(result -> {
                                                if (!result.wasAcknowledged()) {
                                                    log.error("Failed to insert user into Mongo due to existing user already.");
                                                }
                                                IhrUser rtnUser = cloneUser(createdUser);
                                                filterUser(request.getResponseFilter(),
                                                        rtnUser);
                                                return UserProfile.builder()
                                                        .user(rtnUser)
                                                        .build();
                                            })
                                            .onErrorResumeNext(e -> {
                                                if (e instanceof MongoWriteException && ((MongoWriteException) e).getError().getCategory() == ErrorCategory.DUPLICATE_KEY) {
                                                    UserProfileRequest updateRequest = UserProfileRequest.builder()
                                                            .externalSecurity(request.getExternalSecurity())
                                                            .user(createdUser)
                                                            .build();
                                                    return updateUser(updateRequest, headers)
                                                            .switchIfEmpty(Maybe.error(new DataSyncException("Failed to insert user into Mongo", DataSyncException.Location.MONGO, e)))
                                                            .map(userProfile -> {
                                                                filterUser(request.getResponseFilter(), userProfile.getUser());
                                                                return userProfile;
                                                            });
                                                } else {
                                                    return Maybe.error(new DataSyncException("Failed to insert user into Mongo", DataSyncException.Location.MONGO, e));
                                                }
                                            });
                                }
                            });
                });
    }

    @Override
    public Maybe<UserProfile> updateUser(UserProfileRequest request, ProviderApiHeaders headers) {
        IhrUser user = request.getUser();

        String chid = user.getIdentifierContextValue(UserProfileConstant.IDENTIFIER_CONTEXT.IHR);
        String portalId = user.getIdentifierContextValue(UserProfileConstant.IDENTIFIER_CONTEXT.PORTAL);

        return getUpdatedPermissions(request)
                .flatMap(updatedPermissions ->
                        Flowable
                                .fromPublisher(mongoClient
                                        .getDatabase(database)
                                        .getCollection(userProfileCollection)
                                        .find(eq("_id", chid))
                                        .limit(1)
                                )
                                .firstElement()
                                .flatMap(document -> {
                                    IhrUser userToBeUpdated;
                                    try {
                                        // Deserialize: remove the primary key from Json
                                        document.remove("_id");
                                        userToBeUpdated = MAPPER.readValue(document.toJson(), IhrUser.class);
                                    } catch (IOException e) {
                                        throw new ServiceException("Unable to deserialize UserProfile");
                                    }

                                    if (portalId != null) {
                                        userToBeUpdated.addIdentifierContext(UserProfileConstant.IDENTIFIER_CONTEXT.PORTAL, portalId);
                                    }
                                    if (user.getStatus() != null) {
                                        userToBeUpdated.setStatus(user.getStatus());
                                    }
                                    if (user.getName() != null) {
                                        MemberName updatedName = userToBeUpdated.getName();
                                        if (user.getName().getFirst() != null) {
                                            updatedName.setFirst(user.getName().getFirst());
                                        }
                                        if (user.getName().getMiddle() != null) {
                                            updatedName.setMiddle(user.getName().getMiddle());
                                        }
                                        if (user.getName().getLast() != null) {
                                            updatedName.setLast(user.getName().getLast());
                                        }
                                    }
                                    if (user.getEmail() != null) {
                                        userToBeUpdated.setEmail(user.getEmail());
                                    }
                                    if (user.getAddresses() != null) {
                                        userToBeUpdated.setAddresses(new ArrayList<>(user.getAddresses()));
                                    }
                                    if (user.getPhones() != null) {
                                        userToBeUpdated.setPhones(new ArrayList<>(user.getPhones()));
                                    }
                                    if (user.getAgreements() != null) {
                                        userToBeUpdated.setAgreements(new ArrayList<>(user.getAgreements()));
                                    }
                                    if (user.getDateOfBirth() != null) {
                                        userToBeUpdated.setDateOfBirth(user.getDateOfBirth());
                                    }
                                    if (user.getGender() != null) {
                                        userToBeUpdated.setGender(user.getGender());
                                    }
                                    if (user.getNpi() != null) {
                                        userToBeUpdated.setNpi(user.getNpi());
                                    }
                                    if (!updatedPermissions.isEmpty()) {
                                        userToBeUpdated.setUserPermissions(updatedPermissions);
                                    }

                                    synchronized (modifyMutex) {
                                        return Flowable
                                                .fromPublisher(mongoClient
                                                        .getDatabase(database)
                                                        .getCollection(userProfileCollection)
                                                        .findOneAndReplace(
                                                                eq("_id", chid),
                                                                Document.parse(MAPPER.writeValueAsString(userToBeUpdated))
                                                        )
                                                )
                                                .firstElement()
                                                .defaultIfEmpty(new Document())
                                                .onErrorResumeNext(e -> {
                                                    if (e instanceof JsonProcessingException) {
                                                        return Maybe.error(new ServiceException("User update to MongoDB failed"));
                                                    } else {
                                                        return Maybe.error(new UnhandledApiException(e));
                                                    }
                                                })
                                                .flatMap(updateResult -> {
                                                    if (updateResult.isEmpty()) {
                                                        return Maybe.error(new ServiceException("User update to MongoDB failed"));
                                                    } else {
                                                        return Maybe.just(userToBeUpdated);
                                                    }
                                                });
                                    }
                                })
                                .flatMap(userToBeUpdated ->
                                        profileService
                                                .registerProfile(userToBeUpdated, headers)
                                                .onErrorResumeNext(e -> {
                                                    return Maybe.error(new DataSyncException("Failed to update user profile in B50 API", DataSyncException.Location.B50, e));
                                                })
                                                .switchIfEmpty(Maybe.error(new DataSyncException("Failed to update user profile in B50 API", DataSyncException.Location.B50)))
                                                .map(b50IhrUser -> {
                                                    IhrUser rtnUser = cloneUser(userToBeUpdated);
                                                    filterUser(request.getResponseFilter(), rtnUser);
                                                    return UserProfile.builder()
                                                            .user(rtnUser)
                                                            .build();
                                                })
                                )
                );
    }

    private Maybe<List<UserPermission>> getUpdatedPermissions(UserProfileRequest request) {
        ExternalSecurityAccess access = request.getExternalSecurity();
        Maybe<List<UserPermission>> updatedPermissions = Maybe.just(Collections.emptyList());
        if (access != null) {
            UserProfileConstant.SECURED_CONTEXT sCtx = access.getSecuredContext();
            Set<String> roles = access.getRoles();
            if (!roles.isEmpty()) {
                updatedPermissions =
                        securityApi
                                .lookupRoles(
                                        RoleLookup.builder()
                                                .externalSecurity(
                                                        ExternalSecurityAccess.builder()
                                                                .securedContext(sCtx)
                                                                .roles(roles)
                                                                .build()
                                                )
                                                .build()
                                );
            }
        }

        return updatedPermissions;
    }

    @Override
    public Maybe<UserProfile> lookupUserProfile(UserProfileLookup lookup, ProviderApiHeaders headers) {
        List<Bson> filters = new ArrayList<>();
        Map<UserProfileConstant.IDENTIFIER_CONTEXT, String> lookupContexts = lookup.getLookupContext().getLookupContexts();
        boolean isNPILookup = false;
        boolean hasChid = false;
        if (lookupContexts != null) {
            if (lookupContexts.get(UserProfileConstant.IDENTIFIER_CONTEXT.IHR) != null) {
                hasChid = true;
                filters.add(eq("_id", lookupContexts.get(UserProfileConstant.IDENTIFIER_CONTEXT.IHR)));
            } else {
                lookupContexts
                        .forEach((context, value) -> filters.add(eq("identifierContexts." + context, value)));
            }
        } else {
            String email = lookup.getLookupContext().getEmail();
            MemberName name = lookup.getLookupContext().getName();
            isNPILookup = true;

            filters.add(eq("npi", lookup.getLookupContext().getNpi()));

            if (email != null) {
                filters.add(eq("email", email));
            }
            if (name.getMiddle() != null && name.getFirst() != null) {
                filters.add(and
                        (
                                eq("name.first", lookup.getLookupContext().getName().getFirst()),
                                eq("name.middle", lookup.getLookupContext().getName().getMiddle()),
                                eq("name.last", lookup.getLookupContext().getName().getLast())
                        )
                );
            } else if (name.getFirst() != null) {
                filters.add(and
                        (
                                eq("name.first", lookup.getLookupContext().getName().getFirst()),
                                eq("name.last", lookup.getLookupContext().getName().getLast())
                        )
                );
            } else if (name.getMiddle() != null) {
                filters.add(and
                        (
                                eq("name.middle", lookup.getLookupContext().getName().getMiddle()),
                                eq("name.last", lookup.getLookupContext().getName().getLast())
                        )
                );
            } else {
                filters.add(eq("name.last", lookup.getLookupContext().getName().getLast()));
            }
        }

        return Flowable
                .fromPublisher(mongoClient.getDatabase(database).getCollection(userProfileCollection).find(
                        and(filters)
                ))
                .singleElement()
                .flatMap(document -> {
                    IhrUser user;
                    try {
                        // Deserialize: remove the primary key from Json
                        document.remove("_id");
                        user = MAPPER.readValue(document.toJson(), IhrUser.class);
//                            userProfile = UserProfile.builder()
//                                    .user(foundUser).build();
//                            filterUser(lookup.getResponseFilter(), foundUser);
                    } catch (IOException e) {
                        throw new ServiceException("Unable to deserialize UserProfile");
                    }
                    //Sanity check against B50 API
                    String ihrChid = user.getIdentifierContextValue(UserProfileConstant.IDENTIFIER_CONTEXT.IHR);
                    if (ihrChid != null && !ihrChid.isBlank()) {
                        return profileService
                                .getProfile(ihrChid, headers)
                                .onErrorResumeNext(e -> {
                                    return Maybe.error(new DataSyncException("Failed to retrieve actor profile from B50", DataSyncException.Location.B50, e));
                                })
                                .switchIfEmpty(Maybe.error(new DataSyncException("No actor found with chid " + ihrChid, DataSyncException.Location.B50)))
                                .map(b50User -> {
                                    user.combineIhrUsers(b50User);
                                    UserProfile userProfile = UserProfile.builder()
                                            .user(user).build();
                                    filterUser(lookup.getResponseFilter(), user);
                                    return userProfile;
                                });
                    } else {
                        return Maybe.error(new DataSyncException("Failed to lookup user due to no IHR Chid in Mongo", DataSyncException.Location.B50));
                    }
                })
                //Lookup provider profile in B50 API
                .switchIfEmpty(lookupInService(lookup, headers, isNPILookup, hasChid));
    }

    private Maybe<UserProfile> lookupInService(UserProfileLookup lookup, ProviderApiHeaders headers, boolean isNPILookup, boolean hasChid) {
        Maybe<IhrUser> result;
        if (isNPILookup) {
            result = profileService
                    .lookupProfile(lookup.getLookupContext().getName().getLast(),
                            lookup.getLookupContext().getNpi(),
                            headers);
        } else if (hasChid) {
            result = profileService
                    .getProfile(lookup.getLookupContext().getLookupContexts().get(UserProfileConstant.IDENTIFIER_CONTEXT.IHR), headers);
        } else {
            result = Maybe.empty();
        }

        return result
                .map(user -> {
                    UserProfile userProfile = UserProfile.builder()
                            .user(user).build();
                    filterUser(lookup.getResponseFilter(), user);
                    return userProfile;
                })
                .onErrorResumeNext(error -> {
                    if (error instanceof NoUserFoundException) {
                        return Maybe.empty();
                    } else {
                        return Maybe.error(error);
                    }
                });
    }

    private static void filterUser(FilterClass filter, IhrUser foundUser) {
        if (filter != null) {
            final Set<UserProfileConstant.ROLE_CONTEXT> roleFilter = filter.getRolesContext();
            if (!CollectionUtils.isEmpty(roleFilter)) {
                if (!CollectionUtils.isEmpty(foundUser.getUserPermissions())) {
                    foundUser.setUserPermissions(
                            foundUser.getUserPermissions().stream()
                                    .filter(uPerm -> roleFilter.stream().anyMatch(f -> f == uPerm.getContext()))
                                    .collect(Collectors.toList()));
                }

            }

            final Set<UserProfileConstant.IDENTIFIER_CONTEXT> idFilter = filter.getIdentifiersContext();
            if (!CollectionUtils.isEmpty(idFilter)) {
                if (!CollectionUtils.isEmpty(foundUser.getIdentifierContexts())) {
                    foundUser.setIdentifierContexts(
                            foundUser.getIdentifierContexts().entrySet().stream()
                                    .filter(id -> idFilter.stream().anyMatch(f -> f == id.getKey()))
                                    .collect(Collectors.toMap(Map.Entry::getKey, Map.Entry::getValue)));


                }
            }

        }
    }

    private IhrUser cloneUser(IhrUser profile) {
        try {
            ObjectMapper mapper = new ObjectMapper();
            return mapper.readValue(mapper.writeValueAsString(profile), IhrUser.class);
        } catch (IOException e) {
            // should not happen
            return profile;
        }
    }
}
