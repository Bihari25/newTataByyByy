package com.uhg.ihr.provider.api.rest;

import io.micrometer.core.instrument.Meter;
import io.micrometer.core.instrument.MeterRegistry;
import io.micrometer.core.instrument.config.MeterFilter;
import io.micrometer.core.instrument.distribution.DistributionStatisticConfig;
import io.micrometer.core.lang.NonNull;
import io.micronaut.configuration.metrics.aggregator.MeterRegistryConfigurer;
import lombok.extern.slf4j.Slf4j;

import javax.inject.Singleton;

@Slf4j
@Singleton
public class SimpleMeterRegistryConfigurer implements MeterRegistryConfigurer {

    @Override
    public void configure(MeterRegistry meterRegistry) {
        meterRegistry.config().meterFilter(
                new MeterFilter() {
                    @Override
                    public DistributionStatisticConfig configure(Meter.Id id, @NonNull DistributionStatisticConfig config) {
                        if (id.getName().startsWith("http.client.requests") || id.getName().startsWith("http.server.requests")) {
                            return DistributionStatisticConfig.builder()
                                    .percentiles(0.50, 0.90, 0.95)
//                                    .percentilesHistogram(true)
//                                    .minimumExpectedValue(Duration.ofMillis(10).toMillis())
//                                    .maximumExpectedValue(Duration.ofMillis(2000).toMillis())
//                                    .sla(100L)
                                    .build()
                                    .merge(config);
                        }
                        return config;
                    }
                });
    }

    @Override
    public boolean supports(MeterRegistry meterRegistry) {
        return true;
    }

}
