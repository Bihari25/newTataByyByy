package com.uhg.ihr.provider.api.exception;

public class AgeParseException extends DobException {
    public AgeParseException(String message) {
        super(message);
    }
}
