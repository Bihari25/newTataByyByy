package com.uhg.ihr.provider.api.service;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ArrayNode;
import com.fasterxml.jackson.databind.node.ObjectNode;
import com.google.common.base.CaseFormat;
import com.uhg.ihr.medispan.dib.model.MedicationMedispan;
import com.uhg.ihr.medispan.dib.service.DibApiService;
import com.uhg.ihr.provider.api.exception.IhrBadRequestException;
import com.uhg.ihr.provider.api.exception.IhrNotFoundException;
import com.uhg.ihr.provider.api.model.GlobalHealthObjectId;
import com.uhg.ihr.provider.api.model.ProviderApiHeaders;
import com.uhg.ihr.provider.api.model.RecordType;
import com.uhg.ihr.provider.api.service.backend.DataAdapterInterface;
import com.uhg.ihr.provider.api.service.cache.CachedDataInterface;
import io.reactivex.Maybe;
import lombok.extern.slf4j.Slf4j;

import javax.inject.Inject;
import javax.inject.Singleton;
import javax.validation.constraints.NotNull;
import java.util.*;
import java.util.stream.Collectors;

@Slf4j
@Singleton
public class DataService implements DataServiceInterface {

    public static final String DATA_CLASSES = "dataClasses";
    public static final String OBJECT_ID_NODE = "objectId";
    public static final String RECORD_TYPE_NODE = "recordType";
    public static final String MEDICATION_NODE = "medication";
    public static final String MEDISPAN_CODE_NODE = "mediSpanCode";
    private static final ObjectMapper MAPPER = new ObjectMapper();

    @Inject
    DibApiService dibApiService;
    @Inject
    DataAdapterInterface adapter;
    @Inject
    CachedDataInterface cache;
    @Inject
    RelatedObjectLinker linker;

    //TODO: Rework caching while preventing blockingGet calls within Flowables
    public Maybe<Map<RecordType, Map<Integer, JsonNode>>> getAllByActorChid(final String providerChid, final String patientChid, ProviderApiHeaders headers) {
        return cache.getFromCache(providerChid, patientChid, headers.getSdcOverride(), headers)
                .map(rawData -> linker.populateRelatedObjectsForAllHealthItems(rawData))
                .onErrorResumeNext(e -> {
                    if (e instanceof IhrNotFoundException) {
                        return Maybe.empty();
                    } else {
                        return Maybe.error(e);
                    }
                });
    }

    public static void logTime(String process, long startTime) {
        log.debug("The " + process + " process took a total of " + (System.currentTimeMillis() - startTime));
    }

    public Maybe<JsonNode> getFilteredByActorChid(String providerChid, String patientChid, Set<RecordType> dataClasses, ProviderApiHeaders headers) {
        return getAllByActorChid(providerChid, patientChid, headers)
                .map(dataClassPointer -> filteredResponse(dataClassPointer, dataClasses));
    }

    public Maybe<JsonNode> getGlobalItemByActorChid(String providerChid, String patientChid, GlobalHealthObjectId itemId, ProviderApiHeaders headers) {
        return getItemByActorChid(providerChid, patientChid, itemId.getRecordType(), itemId.getObjectId(), headers);
    }

    public Maybe<JsonNode> getItemByActorChid(String providerChid, String patientChid, RecordType dataclass, int itemId, ProviderApiHeaders headers) {
        return getAllByActorChid(providerChid, patientChid, headers)
                .map(dataClassPointer -> filterForItem(dataClassPointer, dataclass, itemId))
                .flatMap(healthItem -> {
                    if (healthItem != null && healthItem.size() > 0) {
                        if (getRecordType(healthItem) == RecordType.HEALTH_MEDICATION &&
                                healthItem.has(MEDICATION_NODE) &&
                                healthItem.get(MEDICATION_NODE).has(MEDISPAN_CODE_NODE)) {
                            return dibApiService.getMedicationSpan(healthItem.get(MEDICATION_NODE).get(MEDISPAN_CODE_NODE).asText())
                                    .onErrorReturn(e -> new MedicationMedispan())
                                    .map(mediSpanData -> {
                                        ((ObjectNode) healthItem).putPOJO("mediSpan", mediSpanData);
                                        return healthItem;
                                    });
                        } else {
                            return Maybe.just(healthItem);
                        }
                    } else {
                        return Maybe.just(MAPPER.createObjectNode());
                    }
                });
    }

    public JsonNode filterForItem(final Map<RecordType, Map<Integer, JsonNode>> dataClassPointer, @NotNull final RecordType dataclass, @NotNull final int itemId) {
        final long start = System.currentTimeMillis();
        Map<Integer, JsonNode> objectIdPointer = dataClassPointer.get(dataclass);
        if (objectIdPointer != null &&
                objectIdPointer.containsKey(itemId)) {
            logTime("filter for item", start);
            return objectIdPointer.get(itemId);
        }
        logTime("filter for item", start);
        return MAPPER.createObjectNode();
    }

    public static JsonNode findItemById(JsonNode root, int itemId, RecordType dataclass) {
        JsonNode dataClassNodes = getDataClassesNode(root);
        JsonNode specificDataClassNode = dataClassNodes.get(dataclass.getNodeName());
        if (specificDataClassNode != null) {
            for (JsonNode item : specificDataClassNode) {
                if (itemId == getObjectId(item)) {
                    return item.deepCopy();
                }
            }
        }
        return null;
    }

    public static RecordType getRecordType(JsonNode data) {
        String recordType = data.get(RECORD_TYPE_NODE).asText();
        return RecordType.valueOf(recordType);
    }

    public static int getObjectId(JsonNode data) {
        return data.get(OBJECT_ID_NODE).asInt();
    }

    public static String getGlobalObjectId(JsonNode data) {
        return data.get(OBJECT_ID_NODE).asText();
    }

    public static JsonNode getDataClassesNode(JsonNode root) {
        return root.get(DATA_CLASSES);
    }


    /**
     * Method to filter payload response based on api version > 1.
     *
     * @param payload     The full data set to filter
     * @param dataClasses //     * @param dataFilters
     * @return JsonNode
     */
    public JsonNode filteredResponse(final Map<RecordType, Map<Integer, JsonNode>> payload, final Set<RecordType> dataClasses) throws IhrBadRequestException {//, final List<DataFilter> dataFilters) throws IhrBadRequestException {
        final long start = System.currentTimeMillis();
        ObjectNode dataClassObject = MAPPER.createObjectNode();
        for (RecordType dataClass : dataClasses) {
            ArrayNode dataClassArray = MAPPER.createArrayNode();
            if (payload.containsKey(dataClass)) {
                dataClassArray.addAll(payload.get(dataClass).values());
            }
            dataClassObject.set(dataClass.getNodeName(), dataClassArray);
        }
        logTime("filter dataclasses", start);
        return MAPPER.createObjectNode().set(DATA_CLASSES, dataClassObject);
    }

    /**
     * Method to filter data classes based on user request.
     *
     * @param payload
     * @param dcStrings
     * @return LinkedHashMap
     */
    public LinkedHashMap<String, JsonNode> filterDataClasses(JsonNode payload, Set<String> dcStrings) {
        LinkedHashMap<String, JsonNode> customDataView = new LinkedHashMap<>();

        /* Validate if the payload is null or empty without data classes. */
        if (Objects.nonNull(payload) && Objects.nonNull(payload.get(DATA_CLASSES))) {
            /* Iterate over the json node tree and filter the response based on the user requested data classes. */
            for (Iterator<Map.Entry<String, JsonNode>> it = payload.get(DATA_CLASSES).fields(); it.hasNext(); ) {
                Map.Entry<String, JsonNode> objNode = it.next();

                /* Translate object node key to data class pattern and Keep track the requested data class if data is available or not. */
                String nodeKey = CaseFormat.LOWER_CAMEL.to(CaseFormat.LOWER_UNDERSCORE, objNode.getKey());

                /* Filter and build custom view for data classes and also keep track of the empty results for requested data classes. */
                if (objNode.getValue().size() > 0) {
                    String recType = (objNode.getValue().size() > 0) ? objNode.getValue().get(0).get(RecordType.RECORD_TYPE).asText() : "";
                    if (dcStrings.contains(recType.toLowerCase())) {
                        customDataView.put(objNode.getKey(), objNode.getValue());
                    }
                } else if (isValidRequestedDataClass(dcStrings, nodeKey) && objNode.getValue().size() == 0) {
                    customDataView.put(objNode.getKey(), objNode.getValue());
                }
            }
        }

        return customDataView;
    }

    /**
     * Method to convert data classes properties to lower cases.
     *
     * @param dataClasses
     * @return Set
     */
    private Set<String> dataClassesPropertiesToLowerCase(final Set<RecordType> dataClasses) {
        return Objects.isNull(dataClasses) ? Collections.emptySet() :
                dataClasses.stream().map(Objects::toString).map(String::toLowerCase).collect(Collectors.toSet());
    }

    /**
     * Method to keep track and validate requested data class to response with empty data array([]).
     *
     * @param dcStrings
     * @param dataClassValue
     * @return boolean
     */
    private boolean isValidRequestedDataClass(Set<String> dcStrings, String dataClassValue) {
        /* Need to keep track if the response results for data classes are empty and need to return in response as [] .*/
        final String computedDataClassValue = specialCasesLookup().containsKey(dataClassValue) ? specialCasesLookup().get(dataClassValue) : dataClassValue;
        boolean isRequestedDataClass = dcStrings.stream().anyMatch(computedDataClassValue::contains);
        return isRequestedDataClass;
    }

    /**
     * Method to lookup special cases incoming data class values when there is no data in data classes.
     *
     * @return Map
     */
    private Map<String, String> specialCasesLookup() {
        Map<String, String> lookup = new HashMap<>();
        lookup.put("service_providers", RecordType.SERVICE_FACILITY_PROVIDER.toString().toLowerCase());
        lookup.put("medications", RecordType.HEALTH_MEDICATION.toString().toLowerCase());
        lookup.put("conditions", RecordType.HEALTH_CONDITION.toString().toLowerCase());
        return lookup;
    }


}