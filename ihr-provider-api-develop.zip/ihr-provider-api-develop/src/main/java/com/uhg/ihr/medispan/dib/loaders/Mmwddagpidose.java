package com.uhg.ihr.medispan.dib.loaders;

/**
*
*/
public class Mmwddagpidose extends TableLoader {
    
	/**
	 *
	 */
    public Mmwddagpidose() {
        super();
    }
    
    @Override
    public String getCreateQuery() {
        return
        "CREATE TABLE mmw_dda_gpi_dose " + 
        "( " +
            "doseid                      CHARACTER VARYING(10) NOT NULL, " +
            "profileid                   CHARACTER VARYING(10) NOT NULL, " +
            "gpi                         CHARACTER VARYING(14) NOT NULL, " +
            "routeid                     INTEGER NOT NULL, " +
            "dosetypecode                CHARACTER VARYING(2) NOT NULL, " +
            "dailydoselow                NUMERIC(9,4) NOT NULL, " +
            "dailydoselowunit            INTEGER NOT NULL, " +
            "dailydosehigh               NUMERIC(9,4) NOT NULL, " +
            "dailydosehighunit           INTEGER NOT NULL, " +
            "dailydoseformlow            NUMERIC(9,4) NOT NULL, " +
            "dailydoseformlowunit        INTEGER NOT NULL, " +
            "dailydoseformhigh           NUMERIC(9,4) NOT NULL, " +
            "dailydoseformhighunit       INTEGER NOT NULL, " +
            "maxdailydose                NUMERIC(9,4) NOT NULL, " +
            "maxdailydoseunit            INTEGER NOT NULL, " +
            "maxdailydoseform            NUMERIC(9,4) NOT NULL, " +
            "maxdailydoseformunit        INTEGER NOT NULL, " +
            "maxsingledose               NUMERIC(9,4) NOT NULL, " +
            "maxsingledoseunit           INTEGER NOT NULL, " +
            "maxsingledoseform           NUMERIC(9,4) NOT NULL, " +
            "maxsingledoseformunit       INTEGER NOT NULL, " +
            "maxlifetimedose             NUMERIC(9,4) NOT NULL, " +
            "maxlifetimedoseunit         INTEGER NOT NULL, " +
            "maxlifetimedoseform         NUMERIC(9,4) NOT NULL, " +
            "maxlifetimedoseformunit     INTEGER NOT NULL, " +
            "frequencylow                NUMERIC(9,4) NOT NULL, " +
            "frequencyhigh               NUMERIC(9,4) NOT NULL, " +
            "frequencymax                NUMERIC(9,4) NOT NULL, " +
            "durationlow                 NUMERIC(9,4) NOT NULL, " +
            "durationhigh                NUMERIC NOT NULL, " + //NUMERIC(9,4)
            "durationmax                 NUMERIC NOT NULL, " + //NUMERIC(9,4)
            "halflifelow                 NUMERIC(5,2) NOT NULL, " +
            "halflifehigh                NUMERIC(5,2) NOT NULL, " +
            "halflifeunit                CHARACTER VARYING(2) NOT NULL, " +
            "hasdoserectextind           SMALLINT NOT NULL, " +
            "hasqualifiertextind         SMALLINT NOT NULL, " +
            "CONSTRAINT mmw_dda_gpi_dose_pkey PRIMARY KEY (doseid) " +
        ") " +
        "WITH (OIDS=TRUE); ";
    }
    
    @Override
    public String getInsertQuery(String line) {
        String[] fields = line.split("\\|");
        
        return "INSERT INTO mmw_dda_gpi_dose VALUES " +
        "( " +
        "'" + fields[0] + "'," +                    //doseid                      CHARACTER VARYING(10) NOT NULL
        "'" + fields[1] + "'," +                    //profileid                   CHARACTER VARYING(10) NOT NULL
        "'" + fields[2] + "'," +                    //gpi                         CHARACTER VARYING(14) NOT NULL
        Integer.parseInt(fields[3]) + "," +         //routeid                     INTEGER NOT NULL
        "'" + fields[4] + "'," +                    //dosetypecode                CHARACTER VARYING(2) NOT NULL
        Float.parseFloat(fields[5]) + "," +         //dailydoselow                NUMERIC(9,4) NOT NULL
        Integer.parseInt(fields[6]) + "," +         //dailydoselowunit            INTEGER NOT NULL
        Float.parseFloat(fields[7]) + "," +         //dailydosehigh               NUMERIC(9,4) NOT NULL
        Integer.parseInt(fields[8]) + "," +         //dailydosehighunit           INTEGER NOT NULL
        Float.parseFloat(fields[9]) + "," +         //dailydoseformlow            NUMERIC(9,4) NOT NULL
        Integer.parseInt(fields[10]) + "," +        //dailydoseformlowunit        INTEGER NOT NULL
        Float.parseFloat(fields[11]) + "," +        //dailydoseformhigh           NUMERIC(9,4) NOT NULL
        Integer.parseInt(fields[12]) + "," +        //dailydoseformhighunit       INTEGER NOT NULL
        Float.parseFloat(fields[13]) + "," +        //maxdailydose                NUMERIC(9,4) NOT NULL
        Integer.parseInt(fields[14]) + "," +        //maxdailydoseunit            INTEGER NOT NULL
        Float.parseFloat(fields[15]) + "," +        //maxdailydoseform            NUMERIC(9,4) NOT NULL
        Integer.parseInt(fields[16]) + "," +        //maxdailydoseformunit        INTEGER NOT NULL
        Float.parseFloat(fields[17]) + "," +        //maxsingledose               NUMERIC(9,4) NOT NULL
        Integer.parseInt(fields[18]) + "," +        //maxsingledoseunit           INTEGER NOT NULL
        Float.parseFloat(fields[19]) + "," +        //maxsingledoseform           NUMERIC(9,4) NOT NULL
        Integer.parseInt(fields[20]) + "," +        //maxsingledoseformunit       INTEGER NOT NULL
        Float.parseFloat(fields[21]) + "," +        //maxlifetimedose             NUMERIC(9,4) NOT NULL
        Integer.parseInt(fields[22]) + "," +        //maxlifetimedoseunit         INTEGER NOT NULL
        Float.parseFloat(fields[23]) + "," +        //maxlifetimedoseform         NUMERIC(9,4) NOT NULL
        Integer.parseInt(fields[24]) + "," +        //maxlifetimedoseformunit     INTEGER NOT NULL
        Float.parseFloat(fields[25]) + "," +        //frequencylow                NUMERIC(9,4) NOT NULL
        Float.parseFloat(fields[26]) + "," +        //frequencyhigh               NUMERIC(9,4) NOT NULL
        Float.parseFloat(fields[27]) + "," +        //frequencymax                NUMERIC(9,4) NOT NULL
        Float.parseFloat(fields[28]) + "," +        //durationlow                 NUMERIC(9,4) NOT NULL
        Float.parseFloat(fields[29]) + "," +        //durationhigh                NUMERIC(9,4) NOT NULL
        Float.parseFloat(fields[30]) + "," +        //durationmax                 NUMERIC(9,4) NOT NULL
        Float.parseFloat(fields[31]) + "," +        //halflifelow                 NUMERIC(5,2) NOT NULL
        Float.parseFloat(fields[32]) + "," +        //halflifehigh                NUMERIC(5,2) NOT NULL
        "'" + fields[33] + "'," +                   //halflifeunit                CHARACTER VARYING(2) NOT NULL
        Integer.parseInt(fields[34]) + "," +        //hasdoserectextind           SMALLINT NOT NULL
        Integer.parseInt(fields[35]) +              //hasqualifiertextind         SMALLINT NOT NULL
        " ); ";
    }

}
