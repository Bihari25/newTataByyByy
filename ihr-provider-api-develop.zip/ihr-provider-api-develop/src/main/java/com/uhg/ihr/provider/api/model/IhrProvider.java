package com.uhg.ihr.provider.api.model;

import lombok.*;

/**
 * @deprecated Use Actor/ActorId instead
 */
@Data
@NoArgsConstructor
@Builder(toBuilder = true)
@AllArgsConstructor
@EqualsAndHashCode(callSuper=false)
@Deprecated
public class IhrProvider {
    private String providerId;
    private String onPerhapsProviderId;

    public String getOnPerhapsProviderId() {
        //Default to providerId as onPerhapsProviderId will always be called when searching
        if (onPerhapsProviderId == null || onPerhapsProviderId.isBlank()) {
            return getProviderId();
        } else {
            return onPerhapsProviderId;
        }
    }
}
