package com.uhg.ihr.provider.api.service.security.model;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.uhg.ihr.provider.api.model.profile.UserProfileConstant;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.validation.Valid;
import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;
import java.util.Map;

@Data
@Builder(toBuilder = true)
@NoArgsConstructor
@AllArgsConstructor
@JsonInclude(JsonInclude.Include.NON_EMPTY)
public class RoleChangeRequest {
    @NotNull(message = "'securedContext' must not be null")
    private UserProfileConstant.SECURED_CONTEXT securedContext;
    @NotEmpty(message = "'mapping' must not be null or empty")
    @Valid
    private Map<String,Map<UserProfileConstant.ROLE_CONTEXT,SecurityObjectsMongo>> mapping;
}
