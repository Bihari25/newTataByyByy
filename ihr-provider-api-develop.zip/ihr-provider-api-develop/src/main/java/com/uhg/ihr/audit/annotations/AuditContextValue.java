/**
 * Copyright (C) 2020 UnitedHealth Group
 * <p>
 * All rights reserved.
 */
package com.uhg.ihr.audit.annotations;

import java.lang.annotation.*;

import static java.lang.annotation.RetentionPolicy.RUNTIME;

/**
 * @author Kristopher T Babic
 * @version 1.0
 */
@Documented
@Retention(RUNTIME)
@Target({ElementType.PARAMETER, ElementType.ANNOTATION_TYPE})
@Repeatable(AuditContextValues.class)
@Inherited
public @interface AuditContextValue {
    enum ContextType {
        COMMON, DETAIL
    }
    ContextType context() default ContextType.DETAIL;

    String[] contextPath() default {};

    /**
     * Dot notated path within the parameter value used to retrieve the
     * audit data to be added to the audit context.  If null, the parameter
     * object will be added to the audit context as-is.
     *
     * @see <a href="http://commons.apache.org/proper/commons-beanutils/javadocs/v1.9.2/apidocs/org/apache/commons/beanutils/package-summary.html#package_description">Bean Utils</a>
     */
    String dataPath() default "";
}
