package com.uhg.ihr.provider.api.exception;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import io.micronaut.http.HttpRequest;
import io.micronaut.http.hateoas.JsonError;
import io.micronaut.http.hateoas.Link;
import lombok.extern.slf4j.Slf4j;

import java.util.HashMap;
import java.util.Map;

@Slf4j
public class ErrorHelper {
    private static final ObjectMapper MAPPER = new ObjectMapper();
    private static final String ERROR_MESSAGE = "errors";

    public static JsonError handleError(HttpRequest request, Throwable e) {
        Map<String, String> errors = new HashMap<>();
        errors.put(ERROR_MESSAGE, e.getMessage());
        String message = "";
        try {
            message = MAPPER.writeValueAsString(errors);
        } catch (JsonProcessingException ex) {
            log.error("unable to convert logMap to json {}", ex.getMessage());
        }

        return new JsonError(message).link(Link.SELF, Link.of(request.getUri()));
    }
}
