package com.uhg.ihr.medispan.dib.loaders;

/**
*
*/
public class Mmwmedtext extends TableLoader {
    
	/**
	 *
	 */
    public Mmwmedtext() {
        super();
    }
    
    @Override
    public String getCreateQuery() {
        return
        "CREATE TABLE mmw_med_text " +
        "( " +
            "textid                      INTEGER NOT NULL, " +
            "linenumber                  SMALLINT NOT NULL, " +
            "linetext                    CHARACTER VARYING(140) NOT NULL, " +
            "CONSTRAINT mmw_med_text_pkey PRIMARY KEY (textid, linenumber) " +
        ") " +
        "WITH (OIDS=TRUE); ";
    }
    
    @Override
    public String getInsertQuery(String line) {
        String[] fields = line.split("\\|");
        
        return "INSERT INTO mmw_med_text VALUES " +
        "( " +
            Integer.parseInt(fields[0]) + "," +         //textid            INTEGER NOT NULL
            Integer.parseInt(fields[1]) + "," +         //linenumber        SMALLINT NOT NULL
            "'" + fields[2].replace("'", "''") + "'" +  //linetext          CHARACTER VARYING(140) NOT NULL
        " ); ";
    }

}
