package com.uhg.ihr.provider.api.service.backend.senzing;

import io.jsonwebtoken.Header;
import io.jsonwebtoken.Jwts;
import io.jsonwebtoken.SignatureAlgorithm;
import io.jsonwebtoken.security.Keys;
import io.micronaut.context.annotation.Property;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.exception.ExceptionUtils;

import javax.inject.Singleton;
import java.io.File;
import java.nio.charset.Charset;
import java.nio.charset.StandardCharsets;
import java.nio.file.Files;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

/**
 * SenzingTokenHelper class used to generate senzing token during runtime.
 *
 * @author ihr extract engineering team.
 * @CopyRight (C) All rights reserved to UHG Inc. It's Illegal to reproduce this code.
 */
@Slf4j
@Singleton
public class SenzingTokenHelper {
//    private static final String TOKEN_TYPE = "JWT";
//    private static final String DEFAULT_AUD = "secure-app";
//    private static final String DEFAULT_ISS = "CHIL";//"ihr-senzing-api-gateway";
//    private static final String DEFAULT_SUBJECT = "IHR-SENZING-API";//"ihr-api";
//    private static final long DEFAULT_DURRATION = 10800000;
//    private static final String TOKEN_BEARER = "Bearer ";

    @Property(name = "senzing.security.jwt.subject")
    private String subject;
    @Property(name = "senzing.security.jwt.duration")
    private Long duration;
    @Property(name = "senzing.security.jwt.secretKey")
    private String secretKey;
    @Property(name = "senzing.security.jwt.roles")
    private List<String> roles;
    @Property(name = "senzing.security.jwt.audience")
    private String audience;
    @Property(name = "senzing.security.jwt.issuer")
    private String issuer;

    /**
     * Method to get token key from file.
     *
     * @param filePath
     * @return String
     */
    public static String getKeyFromFile(String filePath) {
        String token = null;
        try {
            File file = new File(filePath);
            if (!file.exists()) {
                log.error(file.getName(), " {} does not exist!");
            }

            token = new String(Files.readAllBytes(file.toPath()), StandardCharsets.US_ASCII);
        } catch (Exception ex) {
            log.error("Error reading file {} ", ExceptionUtils.getMessage(ex));
        }
        return token;
    }

    /**
     * Method to generate senzing token.
     *
     * @return String
     */
    public String generateToken() {
        String token;
        Charset cs = StandardCharsets.US_ASCII;
        ArrayList rls = new ArrayList();
        Date iat = new Date(System.currentTimeMillis());
        token = Jwts.builder()
                .signWith(Keys.hmacShaKeyFor(secretKey.getBytes(cs)), SignatureAlgorithm.HS512)
                .setHeaderParam(Header.TYPE, Header.JWT_TYPE)
                .setSubject(subject)
                .setIssuer(issuer)
                .setAudience(audience)
                .setIssuedAt(iat)
                .claim("rol", rls)
                .setExpiration(new Date(iat.getTime() + duration)) //FIXME: what if iat is null?
                .compact();
        return "Bearer " + token;
    }

//    /**
//     * Method to decorate the token.
//     *
//     * @param sub
//     * @param iss
//     * @param aud
//     * @param iat
//     * @param duration
//     * @param roles
//     * @param signingKey
//     * @return DecoratedToken
//     */
//    public static DecoratedToken decorateToken(String sub, String iss, String aud, Date iat, long duration, List<String> roles, String signingKey) {
//        String token = generateToken(sub, iss, aud, iat, duration, roles, signingKey);
//        return new DecoratedToken(sub, iss, aud, iat, new Date(iat.getTime() + duration), roles, token);
//    }

}