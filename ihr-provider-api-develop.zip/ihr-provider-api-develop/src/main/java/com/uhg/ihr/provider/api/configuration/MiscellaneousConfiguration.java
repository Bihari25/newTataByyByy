package com.uhg.ihr.provider.api.configuration;

import io.micronaut.context.annotation.Property;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * MiscellaneousConfiguration class used to hold property values from yaml which is used for logging and other computational process.
 *
 * @author ihr extract engineering team.
 * @CopyRight (C) All rights reserved to UHG Inc. It's Illegal to reproduce this code.
 */
@Data
@NoArgsConstructor
public class MiscellaneousConfiguration {

    @Property(name = "micronaut.http.services.senzing.urls")
    private String senzingUrl;

    @Property(name = "mongo.mongo-txn")
    private boolean mongoEnabled;

    @Property(name = "client.b50Consumers")
    private String[] b50Consumers;
}
