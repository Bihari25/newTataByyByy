package com.uhg.ihr.provider.api.service.backend.b50.model;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import com.uhg.ihr.provider.api.service.backend.b50.search.model.Address;
import com.uhg.ihr.provider.api.service.backend.b50.search.model.Identifier;
import com.uhg.ihr.provider.api.service.backend.b50.search.model.Phone;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.io.Serializable;
import java.util.List;
import java.util.Map;

@Data
@NoArgsConstructor
@JsonInclude(JsonInclude.Include.NON_EMPTY)
@JsonPropertyOrder(value = {
        "NAME_FIRST",
        "NAME_MIDDLE",
        "NAME_LAST",
        "DATE_OF_BIRTH",
        "GENDER",
        "GLOBAL_ACTOR_ID",
        "IDENTIFIERS",
        "PHONES",
        "ADDRESSES"
})
public class B50UserDemographics implements Serializable {
    @JsonProperty("NAME_FIRST")
    private String firstName;

    @JsonProperty("NAME_MIDDLE")
    private String middleName;

    @JsonProperty("NAME_LAST")
    private String lastName;

    @JsonProperty("DATE_OF_BIRTH")
    private String dateOfBirth;

    @JsonProperty("GLOBAL_ACTOR_ID")
    private String globalActorId;

    @JsonProperty("GENDER")
    private String gender;

    @JsonProperty("IDENTIFIERS")
    private List<Map<Identifier, String>> identifiers;

    @JsonProperty("PHONES")
    private List<Phone> phones;

    @JsonProperty("ADDRESSES")
    private List<Address> addresses;
}
