package com.uhg.ihr.provider.api.validator;

import lombok.extern.slf4j.Slf4j;

import javax.validation.ConstraintValidator;
import javax.validation.ConstraintValidatorContext;
import java.text.ParseException;
import java.util.Date;

import static com.uhg.ihr.provider.api.util.AppUtils.DATE_FORMAT;
import static com.uhg.ihr.provider.api.util.AppUtils.DATE_FORMATTER;

@Slf4j
public class ValidDateValidator implements ConstraintValidator<ValidDate, String> {

    @Override
    public boolean isValid(final String value, final ConstraintValidatorContext constraintValidatorContext) {

        if (value == null || value.isBlank()) {
            //Validators should only validate whether a non null object is a valid or not. @Notnull constraints should be
            //applied outside of validators to improve the utility of validators
            return true;
        }
        return isValidFormat(value, constraintValidatorContext);
    }

    public static boolean isValidFormat(final String value, ConstraintValidatorContext constraintValidatorContext) {
        Date date = null;
        try {
            date = DATE_FORMATTER.parse(value);
            if (!value.equals(DATE_FORMATTER.format(date))) {
                log.info("Invalid date");
                date = null;
            }

        } catch (ParseException ex) {
            log.info("Invalid date");
        }
        if (date == null) {
            constraintValidatorContext.disableDefaultConstraintViolation();
            constraintValidatorContext.buildConstraintViolationWithTemplate("A valid date in the form of " + DATE_FORMAT + " must be provided.").addConstraintViolation();
        }
        return date != null;
    }
}