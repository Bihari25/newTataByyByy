package com.uhg.ihr.provider.api.validator;

import io.micronaut.context.annotation.Replaces;
import io.micronaut.context.annotation.Requires;
import io.micronaut.core.convert.exceptions.ConversionErrorException;
import io.micronaut.http.HttpRequest;
import io.micronaut.http.HttpResponse;
import io.micronaut.http.HttpStatus;
import io.micronaut.http.annotation.Produces;
import io.micronaut.http.server.exceptions.ConversionErrorHandler;
import io.micronaut.http.server.exceptions.ExceptionHandler;
import lombok.extern.slf4j.Slf4j;

import javax.annotation.PostConstruct;
import javax.inject.Singleton;
import java.util.HashMap;

@Slf4j
@Produces
@Singleton
@Requires(classes = {ConversionErrorException.class, ExceptionHandler.class})
@Replaces(bean = ConversionErrorHandler.class)
public class ConversionErrorExceptionHandler implements ExceptionHandler<ConversionErrorException, HttpResponse> {

    private HashMap<String, String> conversionErrorMessages;

    @PostConstruct
    public void initMap() {
        conversionErrorMessages = new HashMap<>();
        conversionErrorMessages.put("healthItemId", "The item-id for the health item must be a positive integer.");
        conversionErrorMessages.put("apiDto", "A valid health item data class must be provided.");
        conversionErrorMessages.put("lookup", "A valid lookup context must be provided.");
    }

    @Override
    public HttpResponse handle(HttpRequest request, ConversionErrorException exception) {
        int subStrStart = exception.getMessage().indexOf('[') + 1;
        int subStrEnd = exception.getMessage().indexOf(']');
        log.error("Failed to convert request to server POJO, check body and try again.", exception);
        String reason = exception.getMessage().substring(subStrStart, subStrEnd).trim();
        String response;
        if ((response = conversionErrorMessages.get(reason)) == null) {
            response = exception.getMessage();
        }
        return HttpResponse.status(HttpStatus.BAD_REQUEST).body(response);
    }
}
