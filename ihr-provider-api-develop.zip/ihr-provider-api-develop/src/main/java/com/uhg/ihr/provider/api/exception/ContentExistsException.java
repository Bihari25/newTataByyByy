package com.uhg.ihr.provider.api.exception;

public class ContentExistsException extends RuntimeException {
    public ContentExistsException() {
        super();
    }
    public ContentExistsException(String message) {
        super(message);
    }
}
