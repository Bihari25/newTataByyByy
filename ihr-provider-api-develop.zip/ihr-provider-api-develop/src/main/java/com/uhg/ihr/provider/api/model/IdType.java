package com.uhg.ihr.provider.api.model;

public enum IdType {
    memberId,
    searchId,
    EID,
    SSN,
    MBI,
    subscriberId,
    hcId,
    icue,
    GLOBAL_ACTOR_ID,
    UHCCDB_FAMILY_ID,
    SUBSCRIBER_ID,
    CDB_CONSUMER_ID,
    ALT_MEMBER_ID,
    HICN,
    HCID,
    MEDICARE_BENF_ID,
    MEDICARE_NUMBER,
    CARDHOLDER_ID,
    MEDICADE_NUMBER,
    SSN_NUMBER,
    SEARCH_ID,

    MEDICAID_NUMBER,
    NPI_ID,
    PORTAL_ID
}