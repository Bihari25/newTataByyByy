/**
 * Copyright (C) 2020 UnitedHealth Group
 * <p>
 * All rights reserved.
 */
package com.uhg.ihr.provider.api.testing;

import io.micronaut.retry.event.RetryEvent;
import io.micronaut.retry.event.RetryEventListener;

import javax.inject.Singleton;

/**
 * @author Kristopher T Babic
 * @version 1.0
 */
@Singleton
public class TestingRetryEventListener implements RetryEventListener {
    @Override
    public void onApplicationEvent(RetryEvent event) {

    }

    @Override
    public boolean supports(RetryEvent event) {
        if (event != null) {
            if (event.getThrowable() != null) {
                event.getThrowable().printStackTrace();
            }
        }
        return false;
    }
}
