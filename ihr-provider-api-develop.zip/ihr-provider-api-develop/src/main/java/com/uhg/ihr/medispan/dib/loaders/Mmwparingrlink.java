package com.uhg.ihr.medispan.dib.loaders;

/**
*
*/
public class Mmwparingrlink extends TableLoader {
    
	/**
	 *
	 */
    public Mmwparingrlink() {
        super();
    }
    
    @Override
    public String getCreateQuery() {
        return
        "CREATE TABLE mmw_par_ingrlink " +
        "( " +
            "kdc1                        CHARACTER VARYING(5) NOT NULL, " +
            "ingredkdc1                  CHARACTER VARYING(5) NOT NULL, " +
            "CONSTRAINT mmw_par_ingrlink_pkey PRIMARY KEY (kdc1, ingredkdc1) " +
        ") " +
        "WITH (OIDS=TRUE); ";
    }
    
    @Override
    public String getInsertQuery(String line) {
        String[] fields = line.split("\\|");
        
        return "INSERT INTO mmw_par_ingrlink VALUES " +
        "( " +
            "'" + fields[0] + "'," +        //kdc1              CHARACTER VARYING(5) NOT NULL
            "'" + fields[1] + "'" +         //ingredkdc1        CHARACTER VARYING(5) NOT NULL
        " ); ";
    }

}
