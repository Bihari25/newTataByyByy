package com.uhg.ihr.audit.consumer;

import com.fasterxml.jackson.databind.JsonNode;
import com.uhg.ihr.audit.Audit;
import com.uhg.ihr.audit.util.JsonNodeUtil;
import io.micronaut.configuration.kafka.annotation.KafkaListener;
import io.micronaut.configuration.kafka.annotation.OffsetReset;
import io.micronaut.configuration.kafka.annotation.Topic;
import io.micronaut.context.annotation.Property;
import io.micronaut.context.annotation.Requires;
import io.micronaut.core.util.StringUtils;
import io.reactivex.Flowable;
import lombok.extern.slf4j.Slf4j;

import javax.annotation.PostConstruct;
import javax.inject.Inject;
import javax.inject.Named;
import javax.sql.DataSource;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.util.*;

//import io.vertx.reactivex.mysqlclient.MySQLPool;
//import io.vertx.reactivex.sqlclient.Tuple;

@Slf4j
@KafkaListener(offsetReset = OffsetReset.EARLIEST, threads = 5, groupId = "${audit.topic}_inactivity_feed")
@Requires(property = "audit.consumer.inactivity.enabled", value = StringUtils.TRUE)
@Requires(property = "audit.enabled", value = StringUtils.TRUE)
@Requires(beans = DataSource.class)
@Requires(property = "datasources.inactivity")
public class InactivityFeedListener {
    private static final String INSERT_SQL_DEFAULT
            = "INSERT into AUDIT_ACTIVITY (CREATE_DT, ENVIRONMENT, USER_ID, SOURCE, ACTION) " +
            "VALUES (?, ?, ?, ?, ?)";

    @Property(name = "audit.consumer.inactivity.types")
    private Set<String> TRACKABLE_EVENTS;
    @Property(name = "audit.consumer.inactivity.actionMap")
    private String ACTION_MAP_CONFIG;
    @Property(name = "audit.consumer.inactivity.columnConfig.environment")
    private String COLUMN_CONFIG_ENV;
    @Property(name = "audit.consumer.inactivity.columnConfig.userId")
    private String COLUMN_CONFIG_USER_ID;
    @Property(name = "audit.consumer.inactivity.columnConfig.source")
    private String COLUMN_CONFIG_SRC;

    @Property(name = "audit.consumer.inactivity.insertSql")
    private String INSERT_SQL_CONFIG;

    private Map<String, String> actionMap;
    //    private MySQLPool dbClient;
    private DataSource dataSource;
    private boolean disabled = false;

    @Inject
    public InactivityFeedListener(@Named("inactivity") Optional<DataSource> dataSource) {
        if (dataSource != null && dataSource.isPresent()) {
            this.dataSource = dataSource.get();
        }
        else {
            this.dataSource = null;
            this.disabled = true;

            if (log.isWarnEnabled()) {
                log.warn("Inactivity Event Listener -- DB client not configured -- Listener Disabled");
            }
        }
    }

    @PostConstruct
    @SuppressWarnings("unchecked")
    public void initialize() {
        if (!disabled) {
            if (INSERT_SQL_CONFIG == null || INSERT_SQL_CONFIG.isBlank()) {
                INSERT_SQL_CONFIG = INSERT_SQL_DEFAULT;
            }

            final Map<String, String> aMap = new HashMap<>();
            if (ACTION_MAP_CONFIG != null && !ACTION_MAP_CONFIG.isBlank()) {
                Arrays.stream(ACTION_MAP_CONFIG.split(","))
                        .forEach(mapping -> {
                            if (mapping != null && !mapping.isBlank()) {
                                String[] vals = mapping.split("\\|");
                                if (vals.length != 2) {
                                    log.warn("Skipping invalid actionMap configuration: '" + mapping + "'");
                                }
                                else {
                                    aMap.put(vals[0], vals[1]);
                                }
                            }
                        });
            }

            this.actionMap = aMap;
        }
    }

    @Topic("${audit.topic}")
    public Flowable<Audit> receive(Flowable<Audit> auditFlowable) {
        if (disabled) {
            return auditFlowable;
        }

        return auditFlowable.doOnNext(audit -> {
            String eventType;
            if ((eventType = getTrackedEventType(audit)) == null) {
                // not something we want to deal with, so ignore
                return;
            }

            String action = actionMap.getOrDefault(eventType, eventType);
            String env = getValue(audit, COLUMN_CONFIG_ENV);
            String userId = getValue(audit, COLUMN_CONFIG_USER_ID);
            String src = getValue(audit, COLUMN_CONFIG_SRC);

            Date dtEventDate = audit.getDate();
            if (dtEventDate == null) {
                dtEventDate = new Date();
            }

            try (Connection conn = dataSource.getConnection()) {
                try (PreparedStatement stmt = conn.prepareStatement(INSERT_SQL_CONFIG)) {
                    stmt.setTimestamp(1, new java.sql.Timestamp(dtEventDate.getTime()));
                    stmt.setString(2, env);
                    stmt.setString(3, userId);
                    stmt.setString(4, src);
                    stmt.setString(5, action);

                    stmt.execute();
                }
            }
            catch (Exception e) {
                log.error("Failed to update inactivity feed", e);
            }
        });
    }

    private static final String PREFIX_COMMON = "common.";
    private static final String PREFIX_DETAILS = "details.";

    private String getValue(Audit audit, String instruction) {
        JsonNode root = audit.getDetails();
        String path;
        if (instruction.startsWith(PREFIX_COMMON)) {
            root = audit.getCommon();
            path = instruction.substring(PREFIX_COMMON.length());
        }
        else {
            if (instruction.startsWith(PREFIX_DETAILS)) {
                path = instruction.substring(PREFIX_DETAILS.length());
            }
            else {
                path = instruction;
            }
        }

        return JsonNodeUtil.getString(root, path, "");
    }

    private String getTrackedEventType(Audit event) {
        String[] types = event.getType();
        if (types != null && types.length > 0) {
            for (String type : types) {
                if (TRACKABLE_EVENTS.contains(type)) {
                    return type;
                }
            }
        }

        return null;
    }

}