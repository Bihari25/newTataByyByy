package com.uhg.ihr.medispan.dib.loaders;

/**
*
*/
public class Mmwmedintvocab extends TableLoader {
    
	/**
	 *
	 */
    public Mmwmedintvocab() {
        super();
    }
    
    @Override
    public String getCreateQuery() {
        return
        "CREATE TABLE mmw_med_intvocab " + 
        "( " +
            "vocabtypecode       CHARACTER VARYING(1)  NOT NULL, " +
            "mcid                INTEGER     NOT NULL, " +
            "extvocabid          CHARACTER VARYING(20) NOT NULL, " +    
            "CONSTRAINT mmw_med_intvocab_pkey PRIMARY KEY (vocabtypecode, mcid, extvocabid) " +
        ") " +
        "WITH (OIDS=TRUE); ";
    }
    
    @Override
    public String getInsertQuery(String line) {
        String[] fields = line.split("\\|");
        
        return "INSERT INTO mmw_med_intvocab VALUES " +
        "( " +
            "'" + fields[0] + "'," +                //vocabtypecode       CHARACTER VARYING(1)  NOT NULL
            Integer.parseInt(fields[1]) + "," +     //mcid                INTEGER     NOT NULL
            "'" + fields[2] + "'" +                 //extvocabid          CHARACTER VARYING(20) NOT NULL    
        " ); ";
    }

}
