package com.uhg.ihr.provider.api.controller;

import com.uhg.ihr.audit.annotations.AuditRequest;
import io.micronaut.http.HttpResponse;
import io.micronaut.http.MediaType;
import io.micronaut.http.MutableHttpResponse;
import io.micronaut.http.annotation.Controller;
import io.micronaut.http.annotation.Get;
import io.reactivex.Maybe;
import io.swagger.v3.oas.annotations.Hidden;
import io.swagger.v3.oas.annotations.Operation;
import lombok.NoArgsConstructor;

@Controller("/status")
@NoArgsConstructor
public class StatusController {
    private static final String MESSAGE = "{\"status\":\"UP\",\"Message\":\"The service is up and running.\"}";
    private static final String CONTENT_MEDIA_TYPE = MediaType.APPLICATION_JSON + ";charset=utf-8";

    @Get(produces = CONTENT_MEDIA_TYPE)
    @AuditRequest(auditType = "status")
    @Operation(hidden = true)
    @Hidden
    public Maybe<MutableHttpResponse> read() {
        return Maybe.just(HttpResponse.ok(MESSAGE));
    }

}
