package com.uhg.ihr.medispan.dib.loaders;

/**
*
*/
public class Mmwdiclasslink extends TableLoader {
    
	/**
	 *
	 */
    public Mmwdiclasslink() {
        super();
    }
    
    @Override
    public String getCreateQuery() {
        return
        "CREATE TABLE mmw_di_classlink " +
        "( " +
            "kdc1                        CHARACTER VARYING(5) NOT NULL, " +
            "classid                     CHARACTER VARYING(5) NOT NULL, " +
            "CONSTRAINT mmw_di_classlink_pkey PRIMARY KEY (kdc1, classid) " +
        ") " +
        "WITH (OIDS=TRUE); ";
    }
    
    @Override
    public String getInsertQuery(String line) {
        String[] fields = line.split("\\|");
        
        return "INSERT INTO mmw_di_classlink VALUES " +
        "( " +
            "'" + fields[0] + "'," +    //kdc1                        CHARACTER VARYING(5) NOT NULL
            "'" + fields[1] + "'" +     //classid                     CHARACTER VARYING(5) NOT NULL
        " ); ";
    }

}
