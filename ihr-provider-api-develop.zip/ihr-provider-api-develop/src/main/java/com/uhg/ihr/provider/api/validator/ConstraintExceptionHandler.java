package com.uhg.ihr.provider.api.validator;

import io.micronaut.context.annotation.Replaces;
import io.micronaut.context.annotation.Requires;
import io.micronaut.http.HttpRequest;
import io.micronaut.http.HttpResponse;
import io.micronaut.http.HttpStatus;
import io.micronaut.http.annotation.Produces;
import io.micronaut.http.server.exceptions.ExceptionHandler;

import javax.inject.Singleton;
import javax.validation.ConstraintViolationException;

@Produces
@Singleton
@Requires(classes = {ConstraintViolationException.class, ExceptionHandler.class})
@Replaces(bean = io.micronaut.validation.exceptions.ConstraintExceptionHandler.class)
public class ConstraintExceptionHandler implements ExceptionHandler<ConstraintViolationException, HttpResponse> {

    @Override
    public HttpResponse handle(HttpRequest request, ConstraintViolationException exception) {
        String reason = exception.getMessage().substring(exception.getMessage().lastIndexOf(':') + 1).trim();
        return HttpResponse.status(HttpStatus.BAD_REQUEST).body(reason);
    }
}
