package com.uhg.ihr.provider.api.model.senzing;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import org.apache.commons.lang3.builder.ToStringBuilder;

import java.io.Serializable;
import java.util.List;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
        "entityId",
        "entityName",
        "bestName",
        "recordSummaries",
        "addressData",
        "attributeData",
        "identifierData",
        "nameData",
        "phoneData",
        "relationshipData",
        "otherData",
        "features",
        "records",
        "matchLevel",
        "fullNameScore",
        "matchScore",
        "ambiguous",
        "matchKey",
        "resolutionRuleCode",
        "refScore",
        "partial",
        "resultType"
})
public class SearchResult implements Serializable {

    @JsonProperty("entityId")
    private long entityId;
    @JsonProperty("entityName")
    private String entityName;
    @JsonProperty("bestName")
    private String bestName;
    @JsonProperty("recordSummaries")
    private List<RecordSummary> recordSummaries = null;
    @JsonProperty("addressData")
    private List<String> addressData = null;
    @JsonProperty("attributeData")
    private List<String> attributeData = null;
    @JsonProperty("identifierData")
    private List<String> identifierData = null;
    @JsonProperty("nameData")
    private List<String> nameData = null;
    @JsonProperty("phoneData")
    private List<String> phoneData = null;
    @JsonProperty("relationshipData")
    private List<Object> relationshipData = null;
    @JsonProperty("otherData")
    private List<Object> otherData = null;
    @JsonProperty("features")
    private Features features;
    @JsonProperty("records")
    private List<Record> records = null;
    @JsonProperty("matchLevel")
    private int matchLevel;
    @JsonProperty("fullNameScore")
    private long fullNameScore;
    @JsonProperty("matchScore")
    private long matchScore;
    @JsonProperty("ambiguous")
    private boolean ambiguous;
    @JsonProperty("matchKey")
    private String matchKey;
    @JsonProperty("resolutionRuleCode")
    private String resolutionRuleCode;
    @JsonProperty("refScore")
    private long refScore;
    @JsonProperty("partial")
    private boolean partial;
    @JsonProperty("resultType")
    private String resultType;

    @JsonProperty("entityId")
    public long getEntityId() {
        return entityId;
    }

    @JsonProperty("entityId")
    public void setEntityId(long entityId) {
        this.entityId = entityId;
    }

    @JsonProperty("entityName")
    public String getEntityName() {
        return entityName;
    }

    @JsonProperty("entityName")
    public void setEntityName(String entityName) {
        this.entityName = entityName;
    }

    @JsonProperty("bestName")
    public String getBestName() {
        return bestName;
    }

    @JsonProperty("bestName")
    public void setBestName(String bestName) {
        this.bestName = bestName;
    }

    @JsonProperty("recordSummaries")
    public List<RecordSummary> getRecordSummaries() {
        return recordSummaries;
    }

    @JsonProperty("recordSummaries")
    public void setRecordSummaries(List<RecordSummary> recordSummaries) {
        this.recordSummaries = recordSummaries;
    }

    @JsonProperty("addressData")
    public List<String> getAddressData() {
        return addressData;
    }

    @JsonProperty("addressData")
    public void setAddressData(List<String> addressData) {
        this.addressData = addressData;
    }

    @JsonProperty("attributeData")
    public List<String> getAttributeData() {
        return attributeData;
    }

    @JsonProperty("attributeData")
    public void setAttributeData(List<String> attributeData) {
        this.attributeData = attributeData;
    }

    @JsonProperty("identifierData")
    public List<String> getIdentifierData() {
        return identifierData;
    }

    @JsonProperty("identifierData")
    public void setIdentifierData(List<String> identifierData) {
        this.identifierData = identifierData;
    }

    @JsonProperty("nameData")
    public List<String> getNameData() {
        return nameData;
    }

    @JsonProperty("nameData")
    public void setNameData(List<String> nameData) {
        this.nameData = nameData;
    }

    @JsonProperty("phoneData")
    public List<String> getPhoneData() {
        return phoneData;
    }

    @JsonProperty("phoneData")
    public void setPhoneData(List<String> phoneData) {
        this.phoneData = phoneData;
    }

    @JsonProperty("relationshipData")
    public List<Object> getRelationshipData() {
        return relationshipData;
    }

    @JsonProperty("relationshipData")
    public void setRelationshipData(List<Object> relationshipData) {
        this.relationshipData = relationshipData;
    }

    @JsonProperty("otherData")
    public List<Object> getOtherData() {
        return otherData;
    }

    @JsonProperty("otherData")
    public void setOtherData(List<Object> otherData) {
        this.otherData = otherData;
    }

    @JsonProperty("features")
    public Features getFeatures() {
        return features;
    }

    @JsonProperty("features")
    public void setFeatures(Features features) {
        this.features = features;
    }

    @JsonProperty("records")
    public List<Record> getRecords() {
        return records;
    }

    @JsonProperty("records")
    public void setRecords(List<Record> records) {
        this.records = records;
    }

    @JsonProperty("matchLevel")
    public int getMatchLevel() {
        return matchLevel;
    }

    @JsonProperty("matchLevel")
    public void setMatchLevel(int matchLevel) {
        this.matchLevel = matchLevel;
    }

    @JsonProperty("fullNameScore")
    public long getFullNameScore() {
        return fullNameScore;
    }

    @JsonProperty("fullNameScore")
    public void setFullNameScore(long fullNameScore) {
        this.fullNameScore = fullNameScore;
    }

    @JsonProperty("matchScore")
    public long getMatchScore() {
        return matchScore;
    }

    @JsonProperty("matchScore")
    public void setMatchScore(long matchScore) {
        this.matchScore = matchScore;
    }

    @JsonProperty("ambiguous")
    public boolean isAmbiguous() {
        return ambiguous;
    }

    @JsonProperty("ambiguous")
    public void setAmbiguous(boolean ambiguous) {
        this.ambiguous = ambiguous;
    }

    @JsonProperty("matchKey")
    public String getMatchKey() {
        return matchKey;
    }

    @JsonProperty("matchKey")
    public void setMatchKey(String matchKey) {
        this.matchKey = matchKey;
    }

    @JsonProperty("resolutionRuleCode")
    public String getResolutionRuleCode() {
        return resolutionRuleCode;
    }

    @JsonProperty("resolutionRuleCode")
    public void setResolutionRuleCode(String resolutionRuleCode) {
        this.resolutionRuleCode = resolutionRuleCode;
    }

    @JsonProperty("refScore")
    public long getRefScore() {
        return refScore;
    }

    @JsonProperty("refScore")
    public void setRefScore(long refScore) {
        this.refScore = refScore;
    }

    @JsonProperty("partial")
    public boolean isPartial() {
        return partial;
    }

    @JsonProperty("partial")
    public void setPartial(boolean partial) {
        this.partial = partial;
    }

    @JsonProperty("resultType")
    public String getResultType() {
        return resultType;
    }

    @JsonProperty("resultType")
    public void setResultType(String resultType) {
        this.resultType = resultType;
    }

    @Override
    public String toString() {
        return new ToStringBuilder(this).append("entityId", entityId).append("entityName", entityName).append("bestName", bestName).append("recordSummaries", recordSummaries).append("addressData", addressData).append("attributeData", attributeData).append("identifierData", identifierData).append("nameData", nameData).append("phoneData", phoneData).append("relationshipData", relationshipData).append("otherData", otherData).append("features", features).append("records", records).append("matchLevel", matchLevel).append("fullNameScore", fullNameScore).append("matchScore", matchScore).append("ambiguous", ambiguous).append("matchKey", matchKey).append("resolutionRuleCode", resolutionRuleCode).append("refScore", refScore).append("partial", partial).append("resultType", resultType).toString();
    }

}