package com.uhg.ihr.provider.api.service.backend.b50;

import com.uhg.ihr.provider.api.model.Id;
import com.uhg.ihr.provider.api.model.MemberAddress;
import com.uhg.ihr.provider.api.model.profile.UserPhone;
import com.uhg.ihr.provider.api.service.backend.b50.search.model.Address;
import com.uhg.ihr.provider.api.service.backend.b50.search.model.Identifier;
import com.uhg.ihr.provider.api.service.backend.b50.search.model.Phone;

import java.util.Map;

public class CommonTransformers {

    public static Address memberAddressToAddress(MemberAddress memberAddr) {
        return Address.builder()
                .line1(memberAddr.getAddressLine1())
                .line2(memberAddr.getAddressLine2())
                .city(memberAddr.getCity())
                .state(memberAddr.getState())
                .country(memberAddr.getCountry())
                .postalCode(memberAddr.getPostalCode())
                .type(memberAddr.getAddressType())
                .build();
    }

    public static MemberAddress addressToMemberAddress(Address addr) {
        return MemberAddress.builder()
                .addressLine1(addr.getLine1())
                .addressLine2(addr.getLine2())
                .city(addr.getCity())
                .state(addr.getState())
                .country(addr.getCountry())
                .postalCode(addr.getPostalCode())
                .addressType(addr.getType())
                .build();
    }

    public static Phone userPhoneToPhone(UserPhone userPhone) {
        return Phone.builder()
                .number(userPhone.getPhoneNumber())
                .type(userPhone.getPhoneType())
                .build();
    }

    public static UserPhone phoneToUserPhone(Phone phone) {
        return UserPhone.builder()
                .phoneNumber(phone.getNumber())
                .phoneType(phone.getType())
                .build();
    }

    public static Map<Identifier, String> idToMap(Id identifier) {
        return Map.of(identifier.getIdType(), identifier.getId());
    }
}
