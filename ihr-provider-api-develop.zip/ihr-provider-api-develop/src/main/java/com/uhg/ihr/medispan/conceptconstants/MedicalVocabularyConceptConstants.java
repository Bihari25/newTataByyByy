package com.uhg.ihr.medispan.conceptconstants;

public interface MedicalVocabularyConceptConstants {

    /**
     * 
     */
    String MEDICAL_VOCABULARY_MEDISPAN_DRUG = "QLR234";
    
}
