package com.uhg.ihr.provider.api.service.cache;

import com.fasterxml.jackson.databind.JsonNode;
import com.uhg.ihr.provider.api.model.ProviderApiHeaders;
import io.reactivex.Maybe;

public interface CachedDataInterface {
    Maybe<JsonNode> getFromCache(String providerChid, String patientChid,
                                 String overrideToken, ProviderApiHeaders headers);
}
