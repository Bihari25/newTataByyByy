package com.uhg.ihr.medispan.dib.loaders;

/**
*
*/
public class Mmwddaaunit extends TableLoader {
    
	/**
	 *
	 */
    public Mmwddaaunit() {
        super();
    }
    
    @Override
    public String getCreateQuery() {
        return
        "CREATE TABLE mmw_dda_aunit " + 
        "( " +
            "aunitid             INTEGER NOT NULL, " +
            "unitid              INTEGER NOT NULL, " +
            "altdescription      CHARACTER VARYING(50) NOT NULL, " +
            "CONSTRAINT pkmmwddaaunit PRIMARY KEY (aunitid) " +
        ") " +
        "WITH (OIDS=TRUE); ";
    }
    
    @Override
    public String getInsertQuery(String line) {
        String[] fields = line.split("\\|");
        
        return "INSERT INTO mmw_dda_aunit VALUES " +
        "( " +
            Integer.parseInt(fields[0]) + "," +     //aunitid             INTEGER NOT NULL
            Integer.parseInt(fields[1]) + "," +     //unitid              INTEGER NOT NULL
            "'" + fields[2] + "'" +                 //altdescription      CHARACTER VARYING(50) NOT NULL
        " ); ";
    }

}
