package com.uhg.ihr.provider.api.service.backend.b50.search.cache;

import com.fasterxml.jackson.databind.JsonNode;
import com.uhg.ihr.provider.api.model.ProviderApiHeaders;
import com.uhg.ihr.provider.api.service.backend.b50.search.B50SearchClient;
import com.uhg.ihr.provider.api.service.backend.b50.search.model.B50SearchRequest;
import io.micronaut.context.annotation.Requires;
import io.reactivex.Maybe;

import javax.inject.Inject;
import javax.inject.Singleton;

@Requires(missingBeans = {B50CachedSearchProxy.class})
@Singleton
public class B50NoCacheSearchProxy implements B50CachedSearchInterface {
    @Inject
    B50SearchClient client;

    public Maybe<JsonNode> findExistingPatients(String authorization, String providerId, String searchRequestString,
                                                B50SearchRequest searchRequest, ProviderApiHeaders headers) {
        return client.findExistingPatients(authorization, searchRequest, headers.getCorrelationId(),
                headers.getAcceptLanguage());
    }

    public Maybe<JsonNode> findNewPatients(String authorization, String providerId, B50SearchRequest searchRequest,
                                           ProviderApiHeaders headers) {
        return client.findNewPatients(authorization, searchRequest, headers.getCorrelationId(), headers.getAcceptLanguage());
    }
}
