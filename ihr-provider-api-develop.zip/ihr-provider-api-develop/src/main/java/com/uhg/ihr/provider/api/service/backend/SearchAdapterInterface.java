package com.uhg.ihr.provider.api.service.backend;

import com.uhg.ihr.provider.api.model.IhrSearchApiRequest;
import com.uhg.ihr.provider.api.model.PatientDemographics;
import com.uhg.ihr.provider.api.model.PatientDemographicsResponse;
import com.uhg.ihr.provider.api.model.ProviderApiHeaders;
import io.reactivex.Maybe;

public interface SearchAdapterInterface {
    Maybe<PatientDemographicsResponse> searchForPatients(final IhrSearchApiRequest apiDto, final ProviderApiHeaders headers);

    Maybe<PatientDemographics> getPatientDemographics(final String patientChid, final String providerChid, final ProviderApiHeaders headers);
}
