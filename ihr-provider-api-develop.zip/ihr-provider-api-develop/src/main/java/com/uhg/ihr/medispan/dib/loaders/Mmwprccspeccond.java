package com.uhg.ihr.medispan.dib.loaders;

/**
*
*/
public class Mmwprccspeccond extends TableLoader {
    
	/**
	 *
	 */
    public Mmwprccspeccond() {
        super();
    }
    
    @Override
    public String getCreateQuery() {
        return
        "CREATE TABLE mmw_prcc_speccond " +
        "( " +
            "gpi                         CHARACTER VARYING(14) NOT NULL, " +
            "mcid                        INTEGER NOT NULL, " +
            "restrictionid               INTEGER NOT NULL, " +
            "speccondid                  INTEGER NOT NULL, " +
            "CONSTRAINT mmw_prcc_speccond_pkey PRIMARY KEY (gpi, mcid, restrictionid, speccondid) " +
        ") " +
        "WITH (OIDS=TRUE); ";
    }
    
    @Override
    public String getInsertQuery(String line) {
        String[] fields = line.split("\\|");
        
        return "INSERT INTO mmw_prcc_speccond VALUES " +
        "( " +
            "'" + fields[0] + "'," +                //gpi               CHARACTER VARYING(14) NOT NULL
            Integer.parseInt(fields[1]) + "," +     //mcid              INTEGER NOT NULL
            Integer.parseInt(fields[2]) + "," +     //restrictionid     INTEGER NOT NULL
            Integer.parseInt(fields[3]) +           //speccondid        INTEGER NOT NULL
        " ); ";
    }

}
