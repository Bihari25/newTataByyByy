package com.uhg.ihr.provider.api.service.backend.b50.profile;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.node.ArrayNode;
import com.uhg.ihr.provider.api.exception.NoUserFoundException;
import com.uhg.ihr.provider.api.model.MemberName;
import com.uhg.ihr.provider.api.model.profile.IhrUser;
import com.uhg.ihr.provider.api.model.profile.UserProfileConstant;
import com.uhg.ihr.provider.api.service.backend.b50.CommonTransformers;
import com.uhg.ihr.provider.api.service.backend.b50.search.model.Address;
import com.uhg.ihr.provider.api.service.backend.b50.search.model.Phone;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import static com.uhg.ihr.provider.api.util.AppUtils.getTextOrNull;

public class B50ProfileTransformer {

    public static IhrUser transformProfile(JsonNode results) {
        if (results.get("results") == null || results.get("results").size() == 0) {
            throw new NoUserFoundException("No users found in reply: " + results);
        }
        JsonNode root = results.get("results").get(0);
        return IhrUser.builder()
                .name(getName(root))
                .gender(getTextOrNull(root.get("gender")))
                .identifierContexts(getIhrId(root))
                .npi(root.get("providerNpi") != null ? root.get("providerNpi").get("npi").asText() : null)
                .addresses(getAddresses(root)
                        .stream()
                        .map(CommonTransformers::addressToMemberAddress)
                        .collect(Collectors.toUnmodifiableList())
                )
                .phones(getPhones(root)
                        .stream()
                        .map(CommonTransformers::phoneToUserPhone)
                        .collect(Collectors.toUnmodifiableList())
                )
                .build();
    }

    public static List<Address> getAddresses(JsonNode root) {
        if (root.get("addresses") != null) {
            List<Address> addresses = new ArrayList<>();
            ArrayNode addressArray = (ArrayNode) root.get("addresses");
            if (addressArray != null) {
                for (JsonNode addressNode : addressArray) {
                    addresses.add(Address.builder()
                            .type(getTextOrNull(addressNode.get("addrType")))
                            .line1(getTextOrNull(addressNode.get("addrLine1")))
                            .line2(getTextOrNull(addressNode.get("addrLine2")))
                            .city(getTextOrNull(addressNode.get("addrCity")))
                            .state(getTextOrNull(addressNode.get("addrState")))
                            .country(getTextOrNull(addressNode.get("addrCountry")))
                            .postalCode(getTextOrNull(addressNode.get("addrPostalCode")))
                            .build());
                }
            }
            return addresses;
        }
        return Collections.emptyList();
    }

    public static List<Phone> getPhones(JsonNode root) {
        if (root.get("phones") != null) {
            List<Phone> phones = new ArrayList<>();
            ArrayNode phoneArray = (ArrayNode) root.get("phones");
            if (phoneArray != null) {

            }
            return phones;
        }
        return Collections.emptyList();
    }

    public static MemberName getName(JsonNode root) {
        if (root.get("names") != null) {
            JsonNode nameNode = root.get("names").get(0);
            return MemberName.builder()
                    .first(getTextOrNull(nameNode.get("firstName")))
                    .middle(getTextOrNull(nameNode.get("middleName")))
                    .last(getTextOrNull(nameNode.get("lastName")))
                    .build();
        }
        return null;
    }

    public static Map<UserProfileConstant.IDENTIFIER_CONTEXT, String> getIhrId(JsonNode root) {
        return Map.of(UserProfileConstant.IDENTIFIER_CONTEXT.IHR, getTextOrNull(root.get("_id")));
    }
}
