package com.uhg.ihr.medispan.dib.loaders;

/**
*
*/
public class Mmwdruggpilink extends TableLoader {
    
	/**
	 *
	 */
    public Mmwdruggpilink() {
        super();
    }
    
    @Override
    public String getCreateQuery() {
        return
        "CREATE TABLE mmw_drug_gpilink " +
        "( " +
            "drugid                      CHARACTER VARYING(16) NOT NULL, " +
            "gpi                         CHARACTER VARYING(14) NOT NULL, " +
            "CONSTRAINT mmw_drug_gpilink_pkey PRIMARY KEY (drugid, gpi) " +
        ") " +
        "WITH (OIDS=TRUE); ";
    }
    
    @Override
    public String getInsertQuery(String line) {
        String[] fields = line.split("\\|");
        
        return "INSERT INTO mmw_drug_gpilink VALUES " +
        "( " +
            "'" + fields[0] + "'," +    //drugid                      CHARACTER VARYING(16) NOT NULL
            "'" + fields[1] + "'" +     //gpi                         CHARACTER VARYING(14) NOT NULL
        " ); ";
    }

}
