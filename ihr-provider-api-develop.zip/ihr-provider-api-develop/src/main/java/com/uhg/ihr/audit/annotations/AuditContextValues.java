/**
 * Copyright (C) 2020 UnitedHealth Group
 * <p>
 * All rights reserved.
 */
package com.uhg.ihr.audit.annotations;

import java.lang.annotation.*;

import static java.lang.annotation.ElementType.*;

/**
 * @author Kristopher T Babic
 * @version 1.0
 */
@Target({ElementType.PARAMETER, ANNOTATION_TYPE})
@Retention(RetentionPolicy.RUNTIME)
@Inherited
@Documented
public @interface AuditContextValues {
    AuditContextValue[] value() default {};
}
