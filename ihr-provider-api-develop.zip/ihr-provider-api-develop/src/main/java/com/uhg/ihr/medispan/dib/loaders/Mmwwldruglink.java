package com.uhg.ihr.medispan.dib.loaders;

/**
*
*/
public class Mmwwldruglink extends TableLoader {
    
	/**
	 *
	 */
    public Mmwwldruglink() {
        super();
    }
    
    @Override
    public String getCreateQuery() {
        return
        "CREATE TABLE mmw_wl_druglink " +
        "( " +
            "gpi                         CHARACTER VARYING(14) NOT NULL, " +
            "wlid                        CHARACTER VARYING(6) NOT NULL, " +
            "priority                    SMALLint NOT NULL, " +
            "CONSTRAINT mmw_wl_druglink_pkey PRIMARY KEY (gpi, wlid) " +
        ") " +
        "WITH (OIDS=TRUE); ";
    }
    
    @Override
    public String getInsertQuery(String line) {
        String[] fields = line.split("\\|");
        
        return "INSERT INTO mmw_wl_druglink VALUES " +
        "( " +
            "'" + fields[0] + "'," +            //gpi           CHARACTER VARYING(14) NOT NULL
            "'" + fields[1] + "'," +            //wlid          CHARACTER VARYING(6) NOT NULL
            Integer.parseInt(fields[2]) +       //priority      SMALLint NOT NULL
        " ); ";
    }

}
