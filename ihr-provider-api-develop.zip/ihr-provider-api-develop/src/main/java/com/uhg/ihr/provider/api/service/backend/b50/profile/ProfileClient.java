package com.uhg.ihr.provider.api.service.backend.b50.profile;

import com.fasterxml.jackson.databind.JsonNode;
import com.uhg.ihr.provider.api.service.backend.b50.B50ApiRetryPredicate;
import com.uhg.ihr.provider.api.service.backend.b50.model.B50UserDemographics;
import com.uhg.ihr.provider.api.service.backend.b50.profile.model.B50ProfileRegisterRequest;
import io.micronaut.http.HttpHeaders;
import io.micronaut.http.MediaType;
import io.micronaut.http.annotation.Body;
import io.micronaut.http.annotation.Header;
import io.micronaut.http.annotation.Headers;
import io.micronaut.http.annotation.Post;
import io.micronaut.http.client.annotation.Client;
import io.micronaut.retry.annotation.CircuitBreaker;
import io.reactivex.Maybe;

@Client("b50-profile")
@Headers({
        @Header(name = HttpHeaders.CONTENT_TYPE, value = MediaType.APPLICATION_JSON),
        @Header(name = HttpHeaders.ACCEPT, value = MediaType.APPLICATION_JSON)
})
public interface ProfileClient {
    @Post(uri = "/v${b50-api.version}/actors/create")
    Maybe<JsonNode> createStaffProfile(@Header String authorization,
                                       @Body B50ProfileRegisterRequest request,
                                       @Header("optum-cid-ext") String correlationId,
                                       @Header String acceptLanguage);

    @Post(uri = "/v${b50-api.version}/actors/roles")
    Maybe<JsonNode> registerProfile(@Header String authorization,
                                    @Body B50ProfileRegisterRequest request,
                                    @Header("optum-cid-ext") String correlationId,
                                    @Header String acceptLanguage);

    @CircuitBreaker(
            attempts = "${micronaut.http.services.retry.attempts}",
            delay = "${micronaut.http.services.retry.delay}",
            maxDelay = "${micronaut.http.services.retry.max-delay}",
            reset = "${micronaut.http.services.retry.reset}",
            predicate = B50ApiRetryPredicate.class
    )
    @Post(uri = "/v${b50-api.version}/actors/read")
    Maybe<JsonNode> searchProfile(@Header String authorization,
                                  @Body B50UserDemographics request,
                                  @Header("optum-cid-ext") String correlationId,
                                  @Header String acceptLanguage);
}
