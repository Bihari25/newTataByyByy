package com.uhg.ihr.medispan.dib.loaders;

/**
*
*/
public class Mmwmedname extends TableLoader {
    
	/**
	 *
	 */
    public Mmwmedname() {
        super();
    }
    
    @Override
    public String getCreateQuery() {
        return
        "CREATE TABLE mmw_med_name " +
        "( " +
            "mcid                        INTEGER NOT NULL, " +
            "nametypecode                CHARACTER VARYING(2) NOT NULL, " +
            "sequencenumber              SMALLINT NOT NULL, " +
            "namedisplay                 CHARACTER VARYING(60) NOT NULL, " +
            "namesearch                  CHARACTER VARYING(60) NOT NULL, " +
            "namephonetic                CHARACTER VARYING(60) NOT NULL, " +
            "CONSTRAINT mmw_med_name_pkey PRIMARY KEY (mcid, nametypecode, sequencenumber) " +
        ") " +
        "WITH (OIDS=TRUE); ";
    }
    
    @Override
    public String getInsertQuery(String line) {
        String[] fields = line.split("\\|");
        
        return "INSERT INTO mmw_med_name VALUES " +
        "( " +
            Integer.parseInt(fields[0]) + "," +     //mcid                        INTEGER NOT NULL
            "'" + fields[1] + "'," +                //nametypecode                CHARACTER VARYING(2) NOT NULL
            "'" + fields[2] + "'," +                //sequencenumber              SMALLINT NOT NULL
            "'" + fields[3].replace("'", "''") + "'," +                //namedisplay                 CHARACTER VARYING(60) NOT NULL
            "'" + fields[4].replace("'", "''") + "'," +                //namesearch                  CHARACTER VARYING(60) NOT NULL
            "'" + fields[5].replace("'", "''") + "'" +                 //namephonetic                CHARACTER VARYING(60) NOT NULL
        " ); ";
    }

}
