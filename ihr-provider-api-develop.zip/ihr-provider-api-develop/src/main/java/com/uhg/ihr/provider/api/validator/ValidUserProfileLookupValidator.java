package com.uhg.ihr.provider.api.validator;

import com.uhg.ihr.provider.api.model.profile.LookupContext;
import com.uhg.ihr.provider.api.model.profile.UserProfileConstant;
import com.uhg.ihr.provider.api.model.profile.UserProfileLookup;
import com.uhg.ihr.provider.api.util.ValidationUtil;

import javax.validation.*;
import java.util.Map;
import java.util.Set;

public class ValidUserProfileLookupValidator implements ConstraintValidator<ValidUserProfileLookup, UserProfileLookup> {
    @Override
    public boolean isValid(UserProfileLookup request, ConstraintValidatorContext constraintValidatorContext) {
        Validator validator = Validation.buildDefaultValidatorFactory().getValidator();
        Set<ConstraintViolation<UserProfileLookup>> violations = validator.validate(request);
        if (!violations.isEmpty()) {
            ValidationUtil.addConstraintViolation(violations, constraintValidatorContext);
            return false;
        }
        constraintValidatorContext.disableDefaultConstraintViolation();
        return validNameAndNpi(request, constraintValidatorContext) ||
                validIdentifierContext(request, constraintValidatorContext);
    }

    public boolean validNameAndNpi(UserProfileLookup request, ConstraintValidatorContext constraintValidatorContext) {
        LookupContext context = request.getLookupContext();
        String npi = context.getNpi();
        if (context.getName() == null || context.getName().getLast() == null || context.getName().getLast().isBlank() ||
                npi == null || npi.isBlank()) {
            constraintValidatorContext.buildConstraintViolationWithTemplate("A provider's last name and npi must be provided.").addConstraintViolation();
            return false;
        }
        return true;
    }

    public boolean validIdentifierContext(UserProfileLookup request, ConstraintValidatorContext constraintValidatorContext) {
        Map<UserProfileConstant.IDENTIFIER_CONTEXT, String> identifierContexts = request.getLookupContext().getLookupContexts();
        if (identifierContexts == null || identifierContexts.isEmpty()) {
            constraintValidatorContext.buildConstraintViolationWithTemplate("A provider's portal or ihr id must be provided.").addConstraintViolation();
            return false;
        } else {
            if (identifierContexts.get(UserProfileConstant.IDENTIFIER_CONTEXT.IHR) != null ||
                    identifierContexts.get(UserProfileConstant.IDENTIFIER_CONTEXT.PORTAL) != null
            ) {
                return true;
            } else {
                constraintValidatorContext.buildConstraintViolationWithTemplate("A provider's portal or ihr id must be provided.").addConstraintViolation();
                return false;
            }
        }
    }
}