package com.uhg.ihr.provider.api.service.backend;

import com.fasterxml.jackson.databind.JsonNode;
import com.uhg.ihr.provider.api.model.ProviderApiHeaders;
import io.reactivex.Maybe;

public interface DataAdapterInterface {
    Maybe<JsonNode> getAllByActorChid(final String providerChid, final String patientChid, final ProviderApiHeaders headers);
}
