package com.uhg.ihr.medispan.dib.loaders;

/**
*
*/
public class Mmwcmdisplink extends TableLoader {
    
	/**
	 *
	 */
    public Mmwcmdisplink() {
        super();
    }
    
    @Override
    public String getCreateQuery() {
        return
        "CREATE TABLE mmw_cm_displink " +
        "( " +
            "ddid                        INTEGER NOT NULL, " +
            "cmid                        CHARACTER VARYING(3) NOT NULL, " +
            "priority                    SMALLINT NOT NULL, " +
            "CONSTRAINT mmw_cm_displink_pkey PRIMARY KEY (ddid, cmid) " +
        ") " +
        "WITH (OIDS=TRUE); ";
    }
    
    @Override
    public String getInsertQuery(String line) {
        String[] fields = line.split("\\|");
        
        return "INSERT INTO mmw_cm_displink VALUES " +
        "( " +
            Integer.parseInt(fields[0]) + "," +     //ddid          INTEGER NOT NULL
            "'" + fields[1] + "'," +                //cmid          CHARACTER VARYING(3) NOT NULL
            Integer.parseInt(fields[2]) +           //priority      SMALLINT NOT NULL
        " ); ";
    }

}
