package com.uhg.ihr.provider.api.model.senzing;

import java.io.Serializable;

public class DeferalObjectStr implements Serializable {
    private String search;
    private String topMatch;
    private String response;

    public String getSearch() {
        return search;
    }

    public void setSearch(String search) {
        this.search = search;
    }

    public String getTopMatch() {
        return topMatch;
    }

    public void setTopMatch(String topMatch) {
        this.topMatch = topMatch;
    }

    public String getResponse() {
        return response;
    }

    public void setResponse(String response) {
        this.response = response;
    }

    @Override
    public String toString() {
        return "{" +
                "'search':'" + search + '\'' +
                ", 'topMatch':'" + topMatch + '\'' +
                ", 'response':'" + response + '\'' +
                '}';
    }
}
