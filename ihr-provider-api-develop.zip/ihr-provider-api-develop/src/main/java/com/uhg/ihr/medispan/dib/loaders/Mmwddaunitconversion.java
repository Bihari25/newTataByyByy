package com.uhg.ihr.medispan.dib.loaders;

/**
*
*/
public class Mmwddaunitconversion extends TableLoader {
    
	/**
	 *
	 */
    public Mmwddaunitconversion() {
        super();
    }
    
    @Override
    public String getCreateQuery() {
        return
        "CREATE TABLE mmw_dda_unitconversion " + 
        "( " +
            "unittype                CHARACTER VARYING(2) NOT NULL, " +
            "fromunitid              INTEGER NOT NULL, " +
            "fromunitabbrev          CHARACTER VARYING(20) NOT NULL, " +
            "fromunitdesc            CHARACTER VARYING(80) NOT NULL, " +
            "tounitid                INTEGER NOT NULL, " +
            "tounitabbrev            CHARACTER VARYING(20) NOT NULL, " +
            "tounitdesc              CHARACTER VARYING(80) NOT NULL, " +
            "bsaadjust               CHARACTER VARYING(2) NULL, " +
            "weightadjust            CHARACTER VARYING(2) NULL, " +
            "conversionfactor        NUMERIC(16,9) NOT NULL, " +
            "unittypedesc            CHARACTER VARYING(100) NOT NULL, " +
            "bsaoperation            CHARACTER VARYING(1) NULL, " +
            "weightoperation         CHARACTER VARYING(1) NULL, " +
            "CONSTRAINT mmw_dda_unitconversion_pkey PRIMARY KEY (unittype,fromunitid,tounitid) " +
        ") " +
        "WITH (OIDS=TRUE); ";
    }
    
    @Override
    public String getInsertQuery(String line) {
        String[] fields = line.split("\\|");
        
        return "INSERT INTO mmw_dda_unitconversion VALUES " +
        "( " +
            "'" + fields[0] + "'," +                //unittype                CHARACTER VARYING(2) NOT NULL
            Integer.parseInt(fields[1]) + "," +     //fromunitid              INTEGER NOT NULL
            "'" + fields[2] + "'," +                //fromunitabbrev          CHARACTER VARYING(20) NOT NULL
            "'" + fields[3] + "'," +                //fromunitdesc            CHARACTER VARYING(80) NOT NULL
            Integer.parseInt(fields[4]) + "," +     //tounitid                INTEGER NOT NULL
            "'" + fields[5] + "'," +                //tounitabbrev            CHARACTER VARYING(20) NOT NULL
            "'" + fields[6] + "'," +                //tounitdesc              CHARACTER VARYING(80) NOT NULL
            (fields[7].isEmpty() ? "NULL" : "'" + fields[7] + "'") + "," +  //bsaadjust               CHARACTER VARYING(2) NULL
            (fields[8].isEmpty() ? "NULL" : "'" + fields[8] + "'") + "," +  //weightadjust            CHARACTER VARYING(2) NULL
            Float.parseFloat(fields[9]) + "," +                                 //conversionfactor        NUMERIC(16,9) NOT NULL
            "'" + fields[10] + "'," +                                           //unittypedesc            CHARACTER VARYING(100) NOT NULL
            (fields.length < 12 || fields[11].isEmpty() ? "NULL" : "'" + fields[11] + "'") + "," +  //bsaoperation            CHARACTER VARYING(1) NULL
            (fields.length < 13 || fields[12].isEmpty() ? "NULL" : "'" + fields[12] + "'") +        //weightoperation         CHARACTER VARYING(1) NULL
        " ); ";
    }

}
