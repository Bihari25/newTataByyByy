package com.uhg.ihr.provider.api.service.backend.inflator;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.uhg.ihr.provider.api.exception.IhrNotFoundException;
import com.uhg.ihr.provider.api.exception.UnhandledApiException;
import com.uhg.ihr.provider.api.model.ProviderApiHeaders;
import com.uhg.ihr.provider.api.service.backend.DataAdapterInterface;
import de.undercouch.bson4jackson.BsonFactory;
import io.micronaut.context.annotation.Secondary;
import io.reactivex.Maybe;
import lombok.extern.slf4j.Slf4j;
import org.bson.BsonBinaryWriter;
import org.bson.Document;
import org.bson.codecs.DocumentCodec;
import org.bson.codecs.EncoderContext;
import org.bson.io.BasicOutputBuffer;

import javax.inject.Inject;
import javax.inject.Singleton;
import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.Objects;


@Slf4j
@Secondary
@Singleton
public class InflatorAdapter implements DataAdapterInterface {

    @Inject
    InflatorMongoClient client;

    public Maybe<JsonNode> getAllByActorChid(final String providerChid, final String patientChid, final ProviderApiHeaders headers) {
        return client.queryMongoForSinglePaitent(patientChid)
                .map(InflatorAdapter::validateAndConvertDocument)
                .onErrorResumeNext(e -> {
                    if (e instanceof IhrNotFoundException) {
                        log.debug("Data request returned no results");
                        return Maybe.empty();
                    } else {
                        throw new UnhandledApiException(e);
                    }
                });
    }

    private static InputStream documentToInputStream(final Document document) {
        BasicOutputBuffer outputBuffer = new BasicOutputBuffer();
        BsonBinaryWriter writer = new BsonBinaryWriter(outputBuffer);
        new DocumentCodec().encode(writer, document, EncoderContext.builder().isEncodingCollectibleDocument(true).build());
        return new ByteArrayInputStream(outputBuffer.toByteArray());
    }

    public static JsonNode documentToJsonNode(final Document document) throws IOException {
        ObjectMapper mapper = new ObjectMapper(new BsonFactory());
        InputStream is = documentToInputStream(document);
        return mapper.readTree(is);
    }

    public static JsonNode validateAndConvertDocument(Document document) {
        if (Objects.isNull(document)) {
            throw new IhrNotFoundException("user was matched but no corresponding data was found");
        }

        try {
            return documentToJsonNode(document);
        } catch (Exception ex) {
            log.error("Unable to translate mongodb document to jsonNode exception message: {}", ex.getMessage());
            throw new IhrNotFoundException("Unable to translate mongodb document to jsonNode " + ex.getMessage());
        }
    }
}
