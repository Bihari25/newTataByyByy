package com.uhg.ihr.audit;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.node.ObjectNode;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import org.codehaus.jackson.annotate.JsonProperty;

import javax.validation.constraints.NotNull;
import java.util.Date;
import java.util.Iterator;

@Data
@AllArgsConstructor
@NoArgsConstructor
@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonIgnoreProperties(ignoreUnknown = true)
public class Audit {

//    @NotNull
    @JsonProperty("date")
    @JsonFormat(shape = JsonFormat.Shape.STRING, pattern = "yyyy-MM-dd'T'HH:mm:ss.SSSXXX")
    private Date date;

    @NotNull
    @JsonProperty("type")
    private String[] type;

    @NotNull
    @JsonProperty("details")
    private JsonNode details;

    @JsonProperty("common")
    private JsonNode common;

    @JsonIgnore
    public void mergeDetails(JsonNode updates) {
        if (details == null || common.isNull()) {
            details = updates;
        }
        else {
            details = merge(details, updates);
        }
    }

    @JsonIgnore
    public void mergeCommon(JsonNode updates) {
        if (common == null || common.isNull()) {
            common = updates;
        }
        else {
            common = merge(common, updates);
        }
    }

    private static JsonNode merge(JsonNode mainNode, JsonNode updateNode) {
        if (updateNode != null) {
            Iterator<String> fieldNames = updateNode.fieldNames();
            while (fieldNames.hasNext()) {

                String fieldName = fieldNames.next();
                JsonNode jsonNode = mainNode.get(fieldName);
                // if field exists and is an embedded object
                if (jsonNode != null && jsonNode.isObject()) {
                    merge(jsonNode, updateNode.get(fieldName));
                }
                else {
                    if (mainNode instanceof ObjectNode) {
                        // Overwrite field
                        JsonNode value = updateNode.get(fieldName);
                        ((ObjectNode) mainNode).put(fieldName, value);
                    }
                }

            }
        }
        return mainNode;
    }

}

