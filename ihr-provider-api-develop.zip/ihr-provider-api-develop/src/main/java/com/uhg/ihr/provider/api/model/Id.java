package com.uhg.ihr.provider.api.model;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.uhg.ihr.provider.api.service.backend.b50.search.model.Identifier;
import com.uhg.ihr.provider.api.validator.ValidEnumIdType;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.validation.constraints.NotBlank;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@JsonInclude(JsonInclude.Include.NON_NULL)
public class Id {
    public Id(String id, Identifier idType) {
        this (id, idType, null);
    }

    @JsonProperty
    @NotBlank(message = "The request could not be validated. A id was not provided.")
    private String id;

    @JsonProperty
    @ValidEnumIdType(message = "Not a valid searchIdType. Cannot be null and Valid Types are - memberId, searchId, EID, SSN, MBI, subscriberId, hcId,icue")
    private Identifier idType;

    @JsonProperty
    private String idTypeTerm;
}