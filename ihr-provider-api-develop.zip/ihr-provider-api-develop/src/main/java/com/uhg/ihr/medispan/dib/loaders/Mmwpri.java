package com.uhg.ihr.medispan.dib.loaders;

/**
*
*/
public class Mmwpri extends TableLoader {
    
	/**
	 *
	 */
    public Mmwpri() {
        super();
    }
    
    @Override
    public String getCreateQuery() {
        return
        "CREATE TABLE mmw_pri " +
        "( " +
            "ppid                        CHARACTER VARYING(20) NOT NULL, " +
            "pricetypecode               CHARACTER VARYING(2) NOT NULL, " +
            "effectivedate               CHARACTER VARYING(8) NOT NULL, " +
            "price                       NUMERIC(12,6) NOT NULL, " +
            "currentpriceind             SMALLint NOT NULL, " +
            "CONSTRAINT mmw_pri_pkey PRIMARY KEY (ppid, pricetypecode, effectivedate) " +
        ") " +
        "WITH (OIDS=TRUE); ";
    }
    
    @Override
    public String getInsertQuery(String line) {
        String[] fields = line.split("\\|");
        
        return "INSERT INTO mmw_pri VALUES " +
        "( " +
            "'" + fields[0] + "'," +                //ppid                        CHARACTER VARYING(20) NOT NULL
            "'" + fields[1] + "'," +                //pricetypecode               CHARACTER VARYING(2) NOT NULL
            "'" + fields[2] + "'," +                //effectivedate               CHARACTER VARYING(8) NOT NULL
            Float.parseFloat(fields[3]) + "," +     //price                       NUMERIC(12,6) NOT NULL
            Integer.parseInt(fields[4]) +           //currentpriceind             SMALLint NOT NULL
        " ); ";
    }

}
