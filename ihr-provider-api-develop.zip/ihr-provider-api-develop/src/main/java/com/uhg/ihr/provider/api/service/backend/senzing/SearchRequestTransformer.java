package com.uhg.ihr.provider.api.service.backend.senzing;

import com.uhg.ihr.provider.api.model.FilterPair;
import com.uhg.ihr.provider.api.model.IhrSearchApiRequest;
import com.uhg.ihr.provider.api.model.MemberName;
import com.uhg.ihr.provider.api.model.SearcRequestMemberDemographic;

public class SearchRequestTransformer {

    public static SearchRequest buildSearchRequest(IhrSearchApiRequest apiRequest) {
        SearcRequestMemberDemographic demo = apiRequest.getRequestCriteria().getMbrDemographics();
        boolean chidSearch=false;
        SearchRequest.SearchRequestBuilder builder = SearchRequest.builder();
        if (demo.getIdentifiers() != null && !demo.getIdentifiers().isEmpty()) {
            for (FilterPair identifier : demo.getIdentifiers()) {
                if (identifier.getKey().equalsIgnoreCase("GLOBAL_ACTOR_ID")) {
                    builder.GLOBAL_ACTOR_ID(identifier.getValue());
                    chidSearch = true;
                    break;
                }
            }
        }

        if(!chidSearch) {
            MemberName name = demo.getName();
            builder.nameFirst(name.getFirst());
            builder.nameLast(name.getLast());
            builder.dateOfBirth(demo.getDateOfBirth());
            builder.gender(demo.getGender());
        }

        return builder.build();
    }
}
