package com.uhg.ihr.medispan.dib.loaders;

/**
*
*/
public class Mmwmedtextcit extends TableLoader {
    
	/**
	 *
	 */
    public Mmwmedtextcit() {
        super();
    }
    
    @Override
    public String getCreateQuery() {
        return
        "CREATE TABLE mmw_med_text_cit " +
        "( " +
            "textid                      INTEGER NOT NULL, " +
            "citationid                  INTEGER NOT NULL, " +
            "CONSTRAINT mmw_med_text_cit_pkey PRIMARY KEY (textid, citationid) " +
        ") " +
        "WITH (OIDS=TRUE); ";
    }

    @Override
    public String getInsertQuery(String line) {
        String[] fields = line.split("\\|");
        
        return "INSERT INTO mmw_med_text_cit VALUES " +
        "( " +
            Integer.parseInt(fields[0]) + "," +     //textid            INTEGER NOT NULL
            Integer.parseInt(fields[1]) +           //citationid        INTEGER NOT NULL
        " ); ";
    }

}
