/**
 * Copyright (C) 2020 UnitedHealth Group
 * <p>
 * All rights reserved.
 */
package com.uhg.ihr.provider.api.service.exception;


/**
 * Thrown if an operation is attempted on a non-existent profile.
 *
 * @author Kristopher T Babic
 * @version 1.0
 */
public class ProfileNotFoundException extends ServiceException {
    public ProfileNotFoundException(String message) {
        super(message);
    }

    public ProfileNotFoundException(String message, Throwable cause) {
        super(message, cause);
    }
}
