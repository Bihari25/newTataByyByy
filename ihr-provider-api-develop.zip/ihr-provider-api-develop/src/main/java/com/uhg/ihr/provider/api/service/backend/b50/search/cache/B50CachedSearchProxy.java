package com.uhg.ihr.provider.api.service.backend.b50.search.cache;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.uhg.ihr.provider.api.model.ProviderApiHeaders;
import com.uhg.ihr.provider.api.service.backend.b50.search.B50SearchClient;
import com.uhg.ihr.provider.api.service.backend.b50.search.model.B50SearchRequest;
import io.micronaut.cache.annotation.CacheConfig;
import io.micronaut.cache.annotation.Cacheable;
import io.micronaut.context.annotation.Requires;
import io.reactivex.Maybe;

import javax.inject.Inject;
import javax.inject.Singleton;

@CacheConfig("search")
@Requires(property = "redis.caches.search")
@Singleton
public class B50CachedSearchProxy implements B50CachedSearchInterface {

    private final ObjectMapper mapper = new ObjectMapper();

    @Inject
    private B50SearchClient client;

    @Cacheable(parameters = {"providerId", "searchRequestString"})
    public Maybe<JsonNode> findExistingPatients(String authorization, String providerId, String searchRequestString,
                                                B50SearchRequest searchRequest, ProviderApiHeaders headers) {
        return client.findExistingPatients(authorization, searchRequest, headers.getCorrelationId(),
                headers.getAcceptLanguage())
                .defaultIfEmpty(mapper.createObjectNode());
    }

    public Maybe<JsonNode> findNewPatients(String authorization, String providerId, B50SearchRequest searchRequest,
                                           ProviderApiHeaders headers) {
        return client.findNewPatients(authorization, searchRequest, headers.getCorrelationId(), headers.getAcceptLanguage());
    }
}
