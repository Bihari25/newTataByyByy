package com.uhg.ihr.provider.api.model.inflator;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import org.apache.commons.lang3.builder.ToStringBuilder;

import java.io.Serializable;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
        "rxNormCode",
        "mediSpanCode",
        "fdbCodeType",
        "fdbCode",
        "sourceVocabulary",
        "sourceVocabularyCode",
        "ihrLaymanTerm",
        "ihrTerm"
})
@JsonIgnoreProperties(ignoreUnknown = true)
public class Medication_ implements Serializable {

    @JsonProperty("rxNormCode")
    private String rxNormCode;
    @JsonProperty("mediSpanCode")
    private String mediSpanCode;
    @JsonProperty("fdbCodeType")
    private String fdbCodeType;
    @JsonProperty("fdbCode")
    private String fdbCode;
    @JsonProperty("sourceVocabulary")
    private String sourceVocabulary;
    @JsonProperty("sourceVocabularyCode")
    private String sourceVocabularyCode;
    @JsonProperty("ihrLaymanTerm")
    private String ihrLaymanTerm;
    @JsonProperty("ihrTerm")
    private String ihrTerm;

    @JsonProperty("rxNormCode")
    public String getRxNormCode() {
        return rxNormCode;
    }

    @JsonProperty("rxNormCode")
    public void setRxNormCode(String rxNormCode) {
        this.rxNormCode = rxNormCode;
    }

    @JsonProperty("mediSpanCode")
    public String getMediSpanCode() {
        return mediSpanCode;
    }

    @JsonProperty("mediSpanCode")
    public void setMediSpanCode(String mediSpanCode) {
        this.mediSpanCode = mediSpanCode;
    }

    @JsonProperty("fdbCodeType")
    public String getFdbCodeType() {
        return fdbCodeType;
    }

    @JsonProperty("fdbCodeType")
    public void setFdbCodeType(String fdbCodeType) {
        this.fdbCodeType = fdbCodeType;
    }

    @JsonProperty("fdbCode")
    public String getFdbCode() {
        return fdbCode;
    }

    @JsonProperty("fdbCode")
    public void setFdbCode(String fdbCode) {
        this.fdbCode = fdbCode;
    }

    @JsonProperty("sourceVocabulary")
    public String getSourceVocabulary() {
        return sourceVocabulary;
    }

    @JsonProperty("sourceVocabulary")
    public void setSourceVocabulary(String sourceVocabulary) {
        this.sourceVocabulary = sourceVocabulary;
    }

    @JsonProperty("sourceVocabularyCode")
    public String getSourceVocabularyCode() {
        return sourceVocabularyCode;
    }

    @JsonProperty("sourceVocabularyCode")
    public void setSourceVocabularyCode(String sourceVocabularyCode) {
        this.sourceVocabularyCode = sourceVocabularyCode;
    }

    @JsonProperty("ihrLaymanTerm")
    public String getIhrLaymanTerm() {
        return ihrLaymanTerm;
    }

    @JsonProperty("ihrLaymanTerm")
    public void setIhrLaymanTerm(String ihrLaymanTerm) {
        this.ihrLaymanTerm = ihrLaymanTerm;
    }

    @JsonProperty("ihrTerm")
    public String getIhrTerm() {
        return ihrTerm;
    }

    @JsonProperty("ihrTerm")
    public void setIhrTerm(String ihrTerm) {
        this.ihrTerm = ihrTerm;
    }

    @Override
    public String toString() {
        return new ToStringBuilder(this).append("rxNormCode", rxNormCode).append("mediSpanCode", mediSpanCode).append("fdbCodeType", fdbCodeType).append("fdbCode", fdbCode).append("sourceVocabulary", sourceVocabulary).append("sourceVocabularyCode", sourceVocabularyCode).append("ihrLaymanTerm", ihrLaymanTerm).append("ihrTerm", ihrTerm).toString();
    }

}