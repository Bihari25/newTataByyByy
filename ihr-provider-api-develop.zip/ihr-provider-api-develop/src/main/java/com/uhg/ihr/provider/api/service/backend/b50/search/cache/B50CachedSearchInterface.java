package com.uhg.ihr.provider.api.service.backend.b50.search.cache;

import com.fasterxml.jackson.databind.JsonNode;
import com.uhg.ihr.provider.api.model.ProviderApiHeaders;
import com.uhg.ihr.provider.api.service.backend.b50.search.model.B50SearchRequest;
import io.reactivex.Maybe;

public interface B50CachedSearchInterface {
    Maybe<JsonNode> findExistingPatients(String authorization, String providerId, String searchRequestString,
                                         B50SearchRequest searchRequest, ProviderApiHeaders headers);

    Maybe<JsonNode> findNewPatients(String authorization, String providerId, B50SearchRequest searchRequest,
                                    ProviderApiHeaders headers);
}
