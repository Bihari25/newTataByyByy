package com.uhg.ihr.medispan.util;

public class StringUtils {
    public static boolean hasContent(CharSequence text) {
        return !(text == null || text.length() == 0);
    }

    public static int compareIgnoreCase(String o1, String o2, int nullOrder) {
        if (!StringUtils.hasContent(o1)) {
            return !StringUtils.hasContent(o2) ? 0 : nullOrder;
        } else if (!StringUtils.hasContent(o2)) {
            return -nullOrder;
        } else {
            int comparison = o1.compareToIgnoreCase(o2);
            if (comparison == 0) {
                comparison = o1.compareTo(o2);
            }
            return comparison;
        }
    }

    public static int compareIgnoreCase(String o1, String o2) {
        return compareIgnoreCase(o1, o2, -1);
    }

}
