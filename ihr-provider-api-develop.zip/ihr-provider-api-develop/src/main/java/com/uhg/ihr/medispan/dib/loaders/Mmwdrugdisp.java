package com.uhg.ihr.medispan.dib.loaders;

/**
*
*/
public class Mmwdrugdisp extends TableLoader {
    
	/**
	 *
	 */
    public Mmwdrugdisp() {
        super();
    }
    
    @Override
    public String getCreateQuery() {
        return
        "CREATE TABLE mmw_drug_disp " +
        "( " +
            "ddid                    INTEGER NOT NULL, " +
            "descdisplay             CHARACTER VARYING(125) NOT NULL, " +
            "descsearch              CHARACTER VARYING(125) NOT NULL, " +
            "descphonetic            CHARACTER VARYING(125) NOT NULL, " +
            "rtid                    INTEGER NOT NULL, " +
            "dfid                    INTEGER NOT NULL, " +
            "strength                CHARACTER VARYING(15) NULL, " +
            "strengthunit            CHARACTER VARYING(10) NULL, " +
            "rpid                    INTEGER NOT NULL, " +
            "pnid                    INTEGER NOT NULL, " +
            "bioequivcode            CHARACTER VARYING(1) NOT NULL, " +
            "ctrlsubstancecode       CHARACTER VARYING(1) NOT NULL, " +
            "efficacycode            CHARACTER VARYING(1) NULL, " +
            "rxotccode               CHARACTER VARYING(1) NOT NULL, " +
            "genericcode             CHARACTER VARYING(1) NOT NULL, " +
            "nametypecode            CHARACTER VARYING(1) NOT NULL, " +
            "namesourcecode          CHARACTER VARYING(1) NOT NULL, " +
            "gpi                     CHARACTER VARYING(14) NULL, " +
            "partialgpiind           smallINT NOT NULL, " +
            "kdc                     CHARACTER VARYING(10) NULL, " +
            "kdcflag                 CHARACTER VARYING(1) NULL, " +
            "actcode                 CHARACTER VARYING(1) NULL, " +
            "singleingrind           smallINT NOT NULL, " +
            "meddevind               smallINT NOT NULL, " +
            "haspackdrugind          smallINT NOT NULL, " +
            "haseqvpackdrugind       smallINT NOT NULL, " +
            "hasimageind             smallINT NOT NULL, " +
            "cmmultind               smallINT NOT NULL, " +
            "dosechekunit            CHARACTER VARYING(20) NULL, " +
            "historicalind           SMALLINT NOT NULL, " +
            "obsoletedate            CHARACTER VARYING(8) NULL, " +
            "screencleanade          smallINT NULL, " +
            "screencleanprc          smallINT NULL, " +
            "screencleandfa          smallINT NULL, " +
            "screencleandi           smallINT NULL, " +
            "screencleandc           smallINT NULL, " +
            "screencleandda          smallINT NULL, " +
            "repackcode                  smallINT NOT NULL, " +
            "privatelabelercode          smallINT NOT NULL, " +
            "CONSTRAINT mmw_drug_disp_pkey PRIMARY KEY (ddid) " +
        ") " +
        "WITH (OIDS=TRUE); ";
    }
    
    @Override
    public String getInsertQuery(String line) {
        String[] fields = line.split("\\|");
        
        return "INSERT INTO mmw_drug_disp VALUES " +
            "( " +
                Integer.parseInt(fields[0]) + "," +         //ddid                    INTEGER NOT NULL
                "'" + fields[1].replace("'", "''") + "'," +                    //descdisplay             CHARACTER VARYING(125) NOT NULL
                "'" + fields[2].replace("'", "''") + "'," +                    //descsearch              CHARACTER VARYING(125) NOT NULL
                "'" + fields[3].replace("'", "''") + "'," +                    //descphonetic            CHARACTER VARYING(125) NOT NULL
                Integer.parseInt(fields[4]) + "," +         //rtid                    INTEGER NOT NULL
                Integer.parseInt(fields[5]) + "," +         //dfid                    INTEGER NOT NULL
                (fields[6].isEmpty() ? "NULL" : "'" + fields[6] + "'") + "," +      //strength                CHARACTER VARYING(15) NULL
                (fields[7].isEmpty() ? "NULL" : "'" + fields[7] + "'") + "," +      //strengthunit            CHARACTER VARYING(10) NULL
                Integer.parseInt(fields[8]) + "," +         //rpid                    INTEGER NOT NULL
                Integer.parseInt(fields[9]) + "," +         //pnid                    INTEGER NOT NULL
                "'" + fields[10] + "'," +                   //bioequivcode            CHARACTER VARYING(1) NOT NULL
                "'" + fields[11] + "'," +                   //ctrlsubstancecode       CHARACTER VARYING(1) NOT NULL
                (fields[12].isEmpty() ? "NULL" : "'" + fields[12] + "'") + "," +    //efficacycode            CHARACTER VARYING(1) NULL
                "'" + fields[13] + "'," +                   //rxotccode               CHARACTER VARYING(1) NOT NULL
                "'" + fields[14] + "'," +                   //genericcode             CHARACTER VARYING(1) NOT NULL
                "'" + fields[15] + "'," +                   //nametypecode            CHARACTER VARYING(1) NOT NULL
                "'" + fields[16] + "'," +                   //namesourcecode          CHARACTER VARYING(1) NOT NULL
                (fields[17].isEmpty() ? "NULL" : "'" + fields[17] + "'") + "," +    //gpi                     CHARACTER VARYING(14) NULL
                Integer.parseInt(fields[18]) + "," +        //partialgpiind           SMALLINT NOT NULL
                (fields[19].isEmpty() ? "NULL" : "'" + fields[19] + "'") + "," +    //kdc                     CHARACTER VARYING(10) NULL
                (fields[20].isEmpty() ? "NULL" : "'" + fields[20] + "'") + "," +    //kdcflag                 CHARACTER VARYING(1) NULL
                (fields[21].isEmpty() ? "NULL" : "'" + fields[21] + "'") + "," +    //actcode                 CHARACTER VARYING(1) NULL
                Integer.parseInt(fields[22]) + "," +        //singleingrind           smallINT NOT NULL
                Integer.parseInt(fields[23]) + "," +        //meddevind               smallINT NOT NULL
                Integer.parseInt(fields[24]) + "," +        //haspackdrugind          smallINT NOT NULL
                Integer.parseInt(fields[25]) + "," +        //haseqvpackdrugind       smallINT NOT NULL
                Integer.parseInt(fields[26]) + "," +        //hasimageind             smallINT NOT NULL
                Integer.parseInt(fields[27]) + "," +        //cmmultind               smallINT NOT NULL
                (fields[28].isEmpty() ? "NULL" : "'" + fields[28] + "'") + "," +    //dosechekunit            CHARACTER VARYING(20) NULL
                Integer.parseInt(fields[29]) + "," +        //historicalind           SMALLINT NOT NULL
                (fields[30].isEmpty() ? "NULL" : "'" + fields[30] + "'") + "," +    //obsoletedate            CHARACTER VARYING(8) NULL
                (fields[31].isEmpty() ? "NULL" : Integer.parseInt(fields[31])) + "," +        //screencleanade          smallINT NULL
                (fields[32].isEmpty() ? "NULL" : Integer.parseInt(fields[32])) + "," +        //screencleanprc          smallINT NULL
                (fields[33].isEmpty() ? "NULL" : Integer.parseInt(fields[33])) + "," +        //screencleandfa          smallINT NULL
                (fields[34].isEmpty() ? "NULL" : Integer.parseInt(fields[34])) + "," +        //screencleandi           smallINT NULL
                (fields[35].isEmpty() ? "NULL" : Integer.parseInt(fields[35])) + "," +        //screencleandc           smallINT NULL
                (fields[36].isEmpty() ? "NULL" : Integer.parseInt(fields[36])) + "," +        //screencleandda          smallINT NULL
                (fields[37].isEmpty() ? "NULL" : Integer.parseInt(fields[37])) + "," +        //repackcode              smallINT NOT NULL
                Integer.parseInt(fields[38]) +              //privatelabelercode      smallINT NOT NULL
            " ); ";
    }

}
