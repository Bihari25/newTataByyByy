package com.uhg.ihr.provider.api.controller;

import com.fasterxml.jackson.databind.JsonNode;
import com.uhg.ihr.audit.annotations.AuditContextValue;
import com.uhg.ihr.audit.annotations.AuditRequest;
import com.uhg.ihr.provider.api.model.*;
import com.uhg.ihr.provider.api.model.override.OverrideRequest;
import com.uhg.ihr.provider.api.service.DataServiceInterface;
import com.uhg.ihr.provider.api.service.backend.SearchAdapterInterface;
import com.uhg.ihr.provider.api.service.backend.b50.data.sdc.SDCService;
import com.uhg.ihr.provider.api.service.backend.b50.data.sdc.model.OverrideResponse;
import io.micronaut.context.annotation.Context;
import io.micronaut.http.HttpRequest;
import io.micronaut.http.MediaType;
import io.micronaut.http.MutableHttpResponse;
import io.micronaut.http.annotation.*;
import io.micronaut.validation.Validated;
import io.reactivex.Maybe;
import io.swagger.v3.oas.annotations.Hidden;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import lombok.extern.slf4j.Slf4j;

import javax.inject.Inject;
import javax.validation.Valid;

import static com.uhg.ihr.provider.api.util.ControllerUtil.buildHttpResponse;


@Slf4j
@Validated
@Context
@Controller("/individual-health-records/v1")
public class DataController {

    @Inject
    private DataServiceInterface dataService;
    @Inject
    private SearchAdapterInterface searchAdapter;
    @Inject
    SDCService sdcService;

    @Post(uri = "{patient-id}/read", produces = MediaType.APPLICATION_JSON, consumes = MediaType.APPLICATION_JSON)
    @Operation(summary = "Get Patient's health items Data",
            description = "Return raw, unfiltered data for the requested patient or 404 if no patient found",
            operationId = "get-all")
    @ApiResponse(responseCode = "200", description = "Responds with aggregated patient raw data for the searched user or 404 if not found",
            content = @Content(mediaType = "application/json")
    )
    @ApiResponse(responseCode = "404", description = "Not found response returned when no data found for provided request")
    @AuditRequest(auditType = "patient_read")
    public Maybe<MutableHttpResponse<JsonNode>> getAll(final HttpRequest myRequest,
                                                       @Valid @RequestBean ProviderApiHeaders headers,
                                                       final @PathVariable("patient-id") String patientId,
                                                       final @Valid @Body PatientHealthItemRequest apiDto) {
        //final @QueryValue @Nullable Set<RecordType> dataClasses) {
        // TODO - this needs validation handling (check for provider/actor setting
        return buildHttpResponse(
                dataService.getFilteredByActorChid(apiDto.getActorId(), patientId, apiDto.getDataClasses(), headers),
                myRequest,
                "DataGetAll");
    }

    @Post(uri = "/{patient-id}/health-item/{record-type}/{item-id}/read", produces = MediaType.APPLICATION_JSON, consumes = MediaType.APPLICATION_JSON)
    @Operation(summary = "Get Patient's health item data in detail using RecordType and integer objectId",
            description = "Return raw, unfiltered data for the requested patient or 404 if no patient found"
    )
    @ApiResponse(responseCode = "200", description = "Responds with aggregated patient raw data for the searched user or 404 if not found",
            content = @Content(mediaType = "application/json")
    )
    @ApiResponse(responseCode = "404", description = "Not found response returned when no data found for provided request")
    @AuditRequest(auditType = "patient_health_item_read")
    @Hidden
    public Maybe<MutableHttpResponse<JsonNode>> getItemTypeId(final HttpRequest myRequest,
                                                              @Valid @RequestBean ProviderApiHeaders headers,
                                                              final @PathVariable("patient-id") String patientId,
                                                              final @PathVariable("record-type") RecordType dataclass,
                                                              final @PathVariable("item-id") int healthItemId,
                                                              final @Valid @Body IhrApiWithActorRequest provider) {
        return buildHttpResponse(
                dataService.getItemByActorChid(provider.getActorId(), patientId, dataclass, healthItemId, headers),
                myRequest,
                "DataGetItemTypeId");
    }

    //TODO: Update this backwards compatible endpoint once able
    @Post(uri = "/{patient-id}/health-item/{global-item-id}/read", produces = MediaType.APPLICATION_JSON, consumes = MediaType.APPLICATION_JSON)
    @Operation(summary = "Get Patient's health item data in detail using global objectId",
            description = "Return raw, unfiltered data for the requested patient or 404 if no patient found"
    )
    @ApiResponse(responseCode = "200", description = "Responds with aggregated patient raw data for the searched user or 404 if not found",
            content = @Content(mediaType = "application/json")
    )
    @ApiResponse(responseCode = "404", description = "Not found response returned when no data found for provided request")
    @AuditRequest(auditType = "patient_health_item_read")
    public Maybe<MutableHttpResponse<JsonNode>> getItemGlobalId(final HttpRequest myRequest,
                                                                @Valid @RequestBean ProviderApiHeaders headers,
                                                                final @PathVariable("patient-id") String patientId,
                                                                final @PathVariable("global-item-id") String healthItemId,
                                                                final @Valid @Body IhrApiWithActorRequest provider) {
        return buildHttpResponse(
                dataService.getGlobalItemByActorChid(provider.getActorId(), patientId, new GlobalHealthObjectId(healthItemId), headers),
                myRequest,
                "DataGetItemGlobalId");
    }

    @Post(uri = "/{patient-id}/demographics", produces = MediaType.APPLICATION_JSON, consumes = MediaType.APPLICATION_JSON)
    @Operation(summary = "Get Patient's demographics",
            description = "Return raw, unfiltered data for the requested patient or 404 if no patient found"
    )
    @ApiResponse(responseCode = "200", description = "Responds with aggregated patient raw data for the searched user or 404 if not found",
            content = @Content(mediaType = "application/json")
    )
    @ApiResponse(responseCode = "404", description = "Not found response returned when no data found for provided request")
    @AuditRequest(auditType = "patient_demographics")
    public Maybe<MutableHttpResponse<PatientDemographics>> getPatientDemographics(final HttpRequest myRequest,
                                                                                  @Valid @RequestBean ProviderApiHeaders headers,
                                                                                  final @PathVariable("patient-id") String patientId,
                                                                                  final @Valid @Body IhrApiWithActorRequest provider) {
        return buildHttpResponse(
                searchAdapter.getPatientDemographics(patientId, provider.getActorId(), headers),
                myRequest,
                "DataGetDemograhpics");
    }

    @Post(uri = "/{patient-id}/override", produces = MediaType.APPLICATION_JSON, consumes = MediaType.APPLICATION_JSON)
    @Operation(summary = "Request sdc override token for patient-provider pair",
            description = "Validates provider has override security access, generates a JWT style token when verified, and returns the token",
            operationId = "request-override"
    )
    @ApiResponse(responseCode = "200", description = "Override token generated",
            content = @Content(mediaType = "application/json")
    )
    @AuditRequest(auditType = "patient_override")
    public Maybe<MutableHttpResponse<OverrideResponse>> requestOverride(final HttpRequest myRequest,
                                                                        final @RequestBean ProviderApiHeaders headers,
                                                                        final @PathVariable("patient-id") String patientId,
                                                                        @AuditContextValue(
                                                                                context = AuditContextValue.ContextType.DETAIL,
                                                                                dataPath = "reason",
                                                                                contextPath = {"override", "reason"}
                                                                        ) final @Valid @Body OverrideRequest provider) {
        // override reason is not currently used, but eventually it should be validated for data and
        // stored for later retrieval/access
        return buildHttpResponse(sdcService.requestOverride(patientId, provider.getActorId(), headers), myRequest, "RequestOverride");
    }
}
