package com.uhg.ihr.provider.api.service.backend.b50.data.sdc;

import com.uhg.ihr.provider.api.exception.UnauthorizedOverrideException;
import com.uhg.ihr.provider.api.model.ProviderApiHeaders;
import com.uhg.ihr.provider.api.model.profile.UserPermission;
import com.uhg.ihr.provider.api.model.profile.UserProfileConstant;
import com.uhg.ihr.provider.api.model.profile.UserRole;
import com.uhg.ihr.provider.api.service.backend.b50.data.sdc.model.OverrideResponse;
import com.uhg.ihr.provider.api.service.profile.UserProfileApi;
import io.jsonwebtoken.*;
import io.jsonwebtoken.security.Keys;
import io.jsonwebtoken.security.SignatureException;
import io.micronaut.context.annotation.Property;
import io.reactivex.Maybe;
import lombok.extern.slf4j.Slf4j;

import javax.inject.Inject;
import javax.inject.Singleton;
import java.nio.charset.StandardCharsets;
import java.util.*;

@Slf4j
@Singleton
public class SDCService {

    //Default set to one hour
    private static final long DEFAULT_TTL = 3600000;

    private String secretKey;
    private long ttl;
    private String env;
    private Set<String> allowedHealthRoles;

    private UserProfileApi profileApi;

    @Inject
    public SDCService(@Property(name = "sdc.secret-key") String secretKey, @Property(name = "sdc.health-roles") String allowedHealthRoles,
                      @Property(name = "sdc.ttl") long ttl, UserProfileApi profileApi) {
        //Validate configuration requirements
        if (secretKey.isBlank() || secretKey.matches("FIXME") || secretKey.length() < 64) {
            throw new RuntimeException("SDCService OVERRIDE_SECRET_KEY env variable must have 64 or more characters for signing JWT tokens");
        }
        if (allowedHealthRoles.isBlank() || allowedHealthRoles.matches("FIXME")) {
            throw new RuntimeException("SDCService OVERRIDE_HEALTH_ROLES env variable has not been configured");
        }
        this.secretKey = secretKey;
        this.ttl = ttl > 0 ? ttl : DEFAULT_TTL;
        this.env = System.getenv("ENVIRONMENT");
        this.profileApi = profileApi;
        String[] healthRolesArray = allowedHealthRoles.split(",");
        this.allowedHealthRoles = healthRolesArray.length > 0 ? new HashSet<>(Arrays.asList(healthRolesArray)) : Collections.emptySet();
    }

    public Maybe<OverrideResponse> requestOverride(String patientId, String providerId, ProviderApiHeaders headers) {
        return profileApi.getUserProfileByChid(providerId, headers)
                .map(profile -> {
                    if (profile.getUser() != null && profile.getUser().getUserPermissions() != null) {
                        for (UserPermission permission : profile.getUser().getUserPermissions()) {
                            if (permission.getContext() == UserProfileConstant.ROLE_CONTEXT.IHR) {
                                for (UserRole role : permission.getRoles()) {
                                    if (allowedHealthRoles.contains(role.getId())) {
                                        return OverrideResponse.builder()
                                                .forPatient(patientId)
                                                .forProvider(providerId)
                                                .sdcOverrideKey(buildJwtToken(patientId, providerId))
                                                .build();
                                    }
                                }
                            }
                        }
                    }
                    throw new UnauthorizedOverrideException("The requesting provider does not have override access", headers);
                })
                .flatMap(response -> {
                    if (response == null) {
                        return Maybe.error(new UnauthorizedOverrideException("The requesting provider does not have override access", headers));
                    } else {
                        return Maybe.just(response);
                    }
                });
    }

    private String buildJwtToken(String patientId, String providerId) {
        long issueTime = System.currentTimeMillis();
        long expireTime = issueTime + ttl;
        Date issueDate = new Date(issueTime);
        Date expireDate = new Date(expireTime);
        JwtBuilder builder = Jwts.builder()
                .setHeaderParam("typ", "JWT")
                .setIssuer(env)
                .setSubject(patientId)
                .setAudience(providerId)
                .setIssuedAt(issueDate)
                .setExpiration(expireDate)
                .signWith(Keys.hmacShaKeyFor(secretKey.getBytes(StandardCharsets.US_ASCII)), SignatureAlgorithm.HS512);
        return builder.compact();
    }

    public boolean validateToken(String patientId, String providerId, ProviderApiHeaders headers) {
        boolean valid = false;
        if (patientId != null && !patientId.isBlank() &&
                providerId != null && !providerId.isBlank() &&
                headers.getSdcOverride() != null && !headers.getSdcOverride().isBlank()) {
            try {
                Jwts.parser()
                        .setSigningKey(Keys.hmacShaKeyFor(secretKey.getBytes(StandardCharsets.US_ASCII)))
                        .requireIssuer(env)
                        .requireSubject(patientId)
                        .requireAudience(providerId)
                        .parse(headers.getSdcOverride());
                valid = true;
            } catch (MalformedJwtException | InvalidClaimException e) {
                log.error("Malformed sdc-override token");
            } catch (ExpiredJwtException e) {
                log.error("Expired sdc-override token");
            } catch (SignatureException e) {
                log.error("Signature of sdc-override has been tampered with");
            } catch (Exception e) {
                log.error("There's an issue with the provided sdc-override token");
            }
        }
        return valid;
    }
}
