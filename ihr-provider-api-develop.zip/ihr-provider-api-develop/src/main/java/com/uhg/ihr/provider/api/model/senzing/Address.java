package com.uhg.ihr.provider.api.model.senzing;


import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import org.apache.commons.lang3.builder.ToStringBuilder;

import java.io.Serializable;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
        "ADDR_LINE1",
        "ADDR_POSTAL_CODE",
        "ADDR_COUNTRY",
        "ADDR_STATE",
        "ADDR_CITY",
        "ADDR_TYPE"
})
@JsonIgnoreProperties(ignoreUnknown = true)
public class Address implements Serializable {

    @JsonProperty("ADDR_LINE1")
    private String aDDRLINE1;
    @JsonProperty("ADDR_LINE2")
    private String aDDRLINE2;
    @JsonProperty("ADDR_POSTAL_CODE")
    private String aDDRPOSTALCODE;
    @JsonProperty("ADDR_COUNTRY")
    private String aDDRCOUNTRY;
    @JsonProperty("ADDR_STATE")
    private String aDDRSTATE;
    @JsonProperty("ADDR_CITY")
    private String aDDRCITY;
    @JsonProperty("ADDR_TYPE")
    private String aDDRTYPE;

    @JsonProperty("ADDR_LINE1")
    public String getADDRLINE1() {
        return aDDRLINE1;
    }

    @JsonProperty("ADDR_LINE1")
    public void setADDRLINE1(String aDDRLINE1) {
        this.aDDRLINE1 = aDDRLINE1;
    }

    @JsonProperty("ADDR_LINE2")
    public String getaDDRLINE2() {
        return aDDRLINE2;
    }

    @JsonProperty("ADDR_LINE2")
    public void setaDDRLINE2(String aDDRLINE2) {
        this.aDDRLINE2 = aDDRLINE2;
    }

    @JsonProperty("ADDR_POSTAL_CODE")
    public String getADDRPOSTALCODE() {
        return aDDRPOSTALCODE;
    }

    @JsonProperty("ADDR_POSTAL_CODE")
    public void setADDRPOSTALCODE(String aDDRPOSTALCODE) {
        this.aDDRPOSTALCODE = aDDRPOSTALCODE;
    }

    @JsonProperty("ADDR_COUNTRY")
    public String getADDRCOUNTRY() {
        return aDDRCOUNTRY;
    }

    @JsonProperty("ADDR_COUNTRY")
    public void setADDRCOUNTRY(String aDDRCOUNTRY) {
        this.aDDRCOUNTRY = aDDRCOUNTRY;
    }

    @JsonProperty("ADDR_STATE")
    public String getADDRSTATE() {
        return aDDRSTATE;
    }

    @JsonProperty("ADDR_STATE")
    public void setADDRSTATE(String aDDRSTATE) {
        this.aDDRSTATE = aDDRSTATE;
    }

    @JsonProperty("ADDR_CITY")
    public String getADDRCITY() {
        return aDDRCITY;
    }

    @JsonProperty("ADDR_CITY")
    public void setADDRCITY(String aDDRCITY) {
        this.aDDRCITY = aDDRCITY;
    }

    @JsonProperty("ADDR_TYPE")
    public String getADDRTYPE() {
        return aDDRTYPE;
    }

    @JsonProperty("ADDR_TYPE")
    public void setADDRTYPE(String aDDRTYPE) {
        this.aDDRTYPE = aDDRTYPE;
    }

    @Override
    public String toString() {
        return new ToStringBuilder(this).append("aDDRLINE1", aDDRLINE1).append("aDDRLINE2", aDDRLINE2).append("aDDRPOSTALCODE", aDDRPOSTALCODE).append("aDDRCOUNTRY", aDDRCOUNTRY).append("aDDRSTATE", aDDRSTATE).append("aDDRCITY", aDDRCITY).append("aDDRTYPE", aDDRTYPE).toString();
    }

}