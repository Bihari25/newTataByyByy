package com.uhg.ihr.provider.api.validator;

import com.uhg.ihr.provider.api.model.IdType;
import java.util.Arrays;
import java.util.Set;
import java.util.stream.Collectors;
import javax.validation.ConstraintValidator;
import javax.validation.ConstraintValidatorContext;

public class ValidEnumIdTypeValidator implements ConstraintValidator<ValidEnumIdType, IdType> {
    private static final Set<IdType> ID_TYPES = Arrays.stream(IdType.values()).collect(Collectors.toSet());

    @Override
    public boolean isValid(IdType value, ConstraintValidatorContext context) {
        return value != null && ID_TYPES.contains(value);
    }
}
