package com.uhg.ihr.provider.api.validator;

import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.validator.GenericValidator;

import javax.validation.ConstraintValidator;
import javax.validation.ConstraintValidatorContext;

/**
 * ValidIsoDateValidator class used to validate date properties for date filter.
 *
 * @author ihr extract engineering team.
 * @CopyRight (C) All rights reserved to UHG Inc. It's Illegal to reproduce this code.
 */
@Slf4j
public class ValidIsoDateValidator implements ConstraintValidator<ValidIsoDate, String> {
    private static final String ISO_DATETIME_FORMAT = "yyyy-MM-dd HH:mm:ss";

    @Override
    public boolean isValid(final String value, final ConstraintValidatorContext constraintValidatorContext) {
        boolean isValidDate = (StringUtils.isNotBlank(value) && GenericValidator.isDate(value, ISO_DATETIME_FORMAT, true));
        String logMessage = isValidDate ? "Valid date" : "Invalid date";

        log.info(logMessage);
        return isValidDate;
    }
}