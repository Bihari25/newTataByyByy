package com.uhg.ihr.medispan.dib.loaders;

/**
*
*/
public class Mmwindsource extends TableLoader {
    
	/**
	 *
	 */
    public Mmwindsource() {
        super();
    }
    
    @Override
    public String getCreateQuery() {
        return
        "CREATE TABLE mmw_ind_source " +
        "( " +
            "gpi                         CHARACTER VARYING(14) NOT NULL, " +
            "mcid                        INTEGER NOT NULL, " +
            "restrictionid               INTEGER NOT NULL, " +
            "microorganismid             INTEGER NOT NULL, " +
            "sourcecode                  CHARACTER VARYING(2) NOT NULL, " +
            "sourceacceptcode            CHARACTER VARYING(2) NOT NULL, " +
            "CONSTRAINT mmw_ind_source_pkey PRIMARY KEY (gpi, mcid, restrictionid, microorganismid, sourcecode) " +
        ") " +
        "WITH (OIDS=TRUE); ";
    }
    
    @Override
    public String getInsertQuery(String line) {
        String[] fields = line.split("\\|");
        
        return "INSERT INTO mmw_ind_source VALUES " +
        "( " +
            "'" + fields[0] + "'," +                //gpi                         CHARACTER VARYING(14) NOT NULL
            Integer.parseInt(fields[1]) + "," +     //mcid                        INTEGER NOT NULL
            Integer.parseInt(fields[2]) + "," +     //restrictionid               INTEGER NOT NULL
            Integer.parseInt(fields[3]) + "," +     //microorganismid             INTEGER NOT NULL
            "'" + fields[4] + "'," +                //sourcecode                  CHARACTER VARYING(2) NOT NULL
            "'" + fields[5] + "'" +                 //sourceacceptcode            CHARACTER VARYING(2) NOT NULL
        " ); ";
    }

}
