package com.uhg.ihr.medispan.dib.loaders;

/**
*
*/
public class Mmwclsahfsdrug extends TableLoader {
    
	/**
	 *
	 */
    public Mmwclsahfsdrug() {
        super();
    }
    
    @Override
    public String getCreateQuery() {
        return
        "CREATE TABLE mmw_cls_ahfsdrug " +
        "( " +
            "classid                     CHARACTER VARYING(6) NOT NULL, " +
            "drugtype                    SMALLINT NOT NULL, " +
            "drugid                      INTEGER NOT NULL, " +
            "CONSTRAINT mmw_cls_ahfsdrug_pkey PRIMARY KEY (classid, drugtype, drugid) " +
        ") " +
        "WITH (OIDS=TRUE); ";
    }
    
    @Override
    public String getInsertQuery(String line) {
        String[] fields = line.split("\\|");
        
        return "INSERT INTO mmw_cls_ahfsdrug VALUES " +
        "( " +
            "'" + fields[0] + "'," +                //classid       CHARACTER VARYING(6) NOT NULL
            Integer.parseInt(fields[1]) + "," +     //drugtype      SMALLINT NOT NULL
            Integer.parseInt(fields[2]) +           //drugid        INTEGER NOT NULL
        " ); ";
    }
        
}
