package com.uhg.ihr.medispan.dib.loaders;

/**
*
*/
public class Mmwcmtext extends TableLoader {
    
	/**
	 *
	 */
    public Mmwcmtext() {
        super();
    }
    
    @Override
    public String getCreateQuery() {
        return
        "CREATE TABLE mmw_cm_text " +
        "( " +
            "versioncode                 CHARACTER VARYING(10) NOT NULL, " +
            "cmid                        CHARACTER VARYING(3) NOT NULL, " +
            "profmsg1                    CHARACTER VARYING(34) NULL, " +
            "profmsg2                    CHARACTER VARYING(34) NULL, " +
            "patmsg1                     CHARACTER VARYING(25) NULL, " +
            "patmsg2                     CHARACTER VARYING(25) NULL, " +
            "CONSTRAINT mmw_cm_text_pkey PRIMARY KEY (versioncode, cmid) " +
        ") " +
        "WITH (OIDS=TRUE); ";
    }
    
    @Override
    public String getInsertQuery(String line) {
        String[] fields = line.split("\\|");
        
        return "INSERT INTO mmw_cm_text VALUES " +
        "( " +
            "'" + fields[0] + "'," +                                                        //versioncode       CHARACTER VARYING(10) NOT NULL
            "'" + fields[1] + "'," +                                                        //cmid              CHARACTER VARYING(3) NOT NULL
            (fields.length < 3 || fields[2].isEmpty() ? "NULL" : "'" + fields[2].replace("'", "''") + "'") + "," + //profmsg1          CHARACTER VARYING(34) NULL
            (fields.length < 4 || fields[3].isEmpty() ? "NULL" : "'" + fields[3].replace("'", "''") + "'") + "," + //profmsg2          CHARACTER VARYING(34) NULL
            (fields.length < 5 || fields[4].isEmpty() ? "NULL" : "'" + fields[4].replace("'", "''") + "'") + "," + //patmsg1           CHARACTER VARYING(25) NULL
            (fields.length < 6 || fields[5].isEmpty() ? "NULL" : "'" + fields[5].replace("'", "''") + "'") +       //patmsg2           CHARACTER VARYING(25) NULL
        " ); ";
    }

}
