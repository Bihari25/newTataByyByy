package com.uhg.ihr.provider.api.validator;

import com.uhg.ihr.provider.api.util.AppUtils;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.time.DateUtils;

import javax.validation.ConstraintValidator;
import javax.validation.ConstraintValidatorContext;
import java.util.Date;
import java.util.Objects;

@Slf4j
public class ValidFilterValueValidator implements ConstraintValidator<ValidFilterValue, String> {

    @Override
    public boolean isValid(String value, ConstraintValidatorContext context) {
        if (StringUtils.isBlank(value)) {
            log.info("Filter value can't be null or empty");
            return false;
        }
        return validateFilterValue(value);
    }


    /**
     * Method to validate input filter value is string value or date string value.
     *
     * @param value
     * @return boolean
     */
    public boolean validateFilterValue(String value) {
        boolean isValidValue = false;

        /** If filter value is date or not and if date then date value should valid date patterns. */
        boolean isDateValue = AppUtils.isDateValue(value);
        if (isDateValue) {
            try {
                /** Validate date value format. */
                Date date = DateUtils.parseDateStrictly(value, AppUtils.DATE_PATTERNS);
                isValidValue = Objects.isNull(date) ? false: true;
            } catch (Exception ex) {
                log.info("Error parsing the date it's not valid format date: {}", value);
                isValidValue = false;
            }
        }else{
            isValidValue = true;
        }

        return isValidValue;
    }

}