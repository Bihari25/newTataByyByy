package com.uhg.ihr.medispan.dib.loaders;

/**
*
*/
public class Mmwlibcodedef extends TableLoader {
    
	/**
	 *
	 */
    public Mmwlibcodedef() {
        super();
    }
    
    @Override
    public String getCreateQuery() {
        return
        "CREATE TABLE mmw_lib_codedef " +
        "( " +
            "codetype                    SMALLINT NOT NULL, " +
            "codevalue                   CHARACTER VARYING(10) NOT NULL, " +
            "description                 CHARACTER VARYING(255) NOT NULL, " +
            "CONSTRAINT mmw_lib_codedef_pkey PRIMARY KEY (codetype, codevalue) " +
        ") " +
        "WITH (OIDS=TRUE); ";
    }
    
    @Override
    public String getInsertQuery(String line) {
        String[] fields = line.split("\\|");
        
        return "INSERT INTO mmw_lib_codedef VALUES " +
        "( " +
            Integer.parseInt(fields[0]) + "," +     //codetype          SMALLINT NOT NULL
            "'" + fields[1] + "'," +                //codevalue         CHARACTER VARYING(10) NOT NULL
            "'" + fields[2].replace("'", "''") + "'" +                 //description       CHARACTER VARYING(255) NOT NULL
        " ); ";
    }

}
