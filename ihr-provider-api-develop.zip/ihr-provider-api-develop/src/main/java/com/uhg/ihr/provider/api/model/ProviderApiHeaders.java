package com.uhg.ihr.provider.api.model;

import com.uhg.ihr.provider.api.validator.ValidLanguage;
import io.micronaut.core.annotation.Introspected;
import io.micronaut.http.annotation.Header;

@Introspected
public class ProviderApiHeaders implements Comparable<ProviderApiHeaders> {

    @Header("optum-cid-ext")
    private String correlationId;

    @Header(value = "sdc-override", defaultValue = "")
    private String sdcOverride;

    @Header(defaultValue = "*")
    @ValidLanguage
    private String acceptLanguage;

    public ProviderApiHeaders() {

    }

    public ProviderApiHeaders(String correlationId) {
        this(correlationId, "*");
    }

    public ProviderApiHeaders(String correlationId, String acceptLanguage) {
        this.correlationId = correlationId;
        this.sdcOverride = "";
        this.acceptLanguage = acceptLanguage;
    }

    public String getCorrelationId() {
        return correlationId;
    }

    public void setCorrelationId(String correlationId) {
        this.correlationId = correlationId;
    }

    public String getSdcOverride() {
        return sdcOverride;
    }

    public void setSdcOverride(String sdcOverride) {
        this.sdcOverride = sdcOverride;
    }

//    @Nullable
    public String getAcceptLanguage() {
        return acceptLanguage;
    }

    public void setAcceptLanguage(String acceptLanguage) {
        this.acceptLanguage = acceptLanguage;
    }

    @Override
    public int compareTo(ProviderApiHeaders o) {
        if (!this.correlationId.matches(o.correlationId) ||
                !this.sdcOverride.matches(o.sdcOverride)) {
            return 1;
        }
        if ((this.acceptLanguage == null && o.acceptLanguage != null) ||
                (this.acceptLanguage != null && o.acceptLanguage == null)) {
            return 1;
        }
        if (this.acceptLanguage != null && o.acceptLanguage != null) {
            String lang1 = this.acceptLanguage.contains("*") ? this.acceptLanguage.replaceAll("\\*","\\\\*") : this.acceptLanguage;
            String lang2 = o.acceptLanguage.contains("*") ? o.acceptLanguage.replaceAll("\\*","\\\\*") : o.acceptLanguage;
            if (!lang1.equals(lang2)) {
                return 1;
            }
        }
        return 0;
    }
}
