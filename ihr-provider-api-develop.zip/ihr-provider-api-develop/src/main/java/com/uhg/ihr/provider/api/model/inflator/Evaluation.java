package com.uhg.ihr.provider.api.model.inflator;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import org.apache.commons.lang3.builder.ToStringBuilder;

import java.io.Serializable;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
        "date",
        "targetResult",
        "targetType",
        "comment",
        "target",
        "status"
})
@JsonIgnoreProperties(ignoreUnknown = true)
public class Evaluation implements Serializable {

    @JsonProperty("date")
    private String date;
    @JsonProperty("targetResult")
    private Object targetResult;
    @JsonProperty("targetType")
    private TargetType targetType;
    @JsonProperty("comment")
    private Object comment;
    @JsonProperty("target")
    private String target;
    @JsonProperty("status")
    private Status status;

    @JsonProperty("date")
    public String getDate() {
        return date;
    }

    @JsonProperty("date")
    public void setDate(String date) {
        this.date = date;
    }

    @JsonProperty("targetResult")
    public Object getTargetResult() {
        return targetResult;
    }

    @JsonProperty("targetResult")
    public void setTargetResult(Object targetResult) {
        this.targetResult = targetResult;
    }

    @JsonProperty("targetType")
    public TargetType getTargetType() {
        return targetType;
    }

    @JsonProperty("targetType")
    public void setTargetType(TargetType targetType) {
        this.targetType = targetType;
    }

    @JsonProperty("comment")
    public Object getComment() {
        return comment;
    }

    @JsonProperty("comment")
    public void setComment(Object comment) {
        this.comment = comment;
    }

    @JsonProperty("target")
    public String getTarget() {
        return target;
    }

    @JsonProperty("target")
    public void setTarget(String target) {
        this.target = target;
    }

    @JsonProperty("status")
    public Status getStatus() {
        return status;
    }

    @JsonProperty("status")
    public void setStatus(Status status) {
        this.status = status;
    }

    @Override
    public String toString() {
        return new ToStringBuilder(this).append("date", date).append("targetResult", targetResult).append("targetType", targetType).append("comment", comment).append("target", target).append("status", status).toString();
    }

}
