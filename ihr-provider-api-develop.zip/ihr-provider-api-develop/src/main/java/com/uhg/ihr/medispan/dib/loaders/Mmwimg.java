package com.uhg.ihr.medispan.dib.loaders;

/**
*
*/
public class Mmwimg extends TableLoader {
    
	/**
	 *
	 */
    public Mmwimg() {
        super();
    }
    
    @Override
    public String getCreateQuery() {
        return
        "CREATE TABLE mmw_img " +
        "( " +
            "ppid                        CHARACTER VARYING(20) NOT NULL, " +
            "startdate                   CHARACTER VARYING(8) NOT NULL, " +
            "stopdate                    CHARACTER VARYING(8) NULL, " +
            "imagefilename               CHARACTER VARYING(8) NOT NULL, " +
            "CONSTRAINT mmw_img_pkey PRIMARY KEY (ppid, startdate) " +
        ") " +
        "WITH (OIDS=TRUE); ";
    }
    
    @Override
    public String getInsertQuery(String line) {
        String[] fields = line.split("\\|");
        
        return "INSERT INTO mmw_img VALUES " +
        "( " +
            "'" + fields[0] + "'," +        //ppid              CHARACTER VARYING(20) NOT NULL
            "'" + fields[1] + "'," +        //startdate         CHARACTER VARYING(8) NOT NULL
            (fields[2].isEmpty() ? "NULL" : "'" + fields[2] + "'") + "," +  //stopdate          CHARACTER VARYING(8) NULL
            "'" + fields[3] + "'" +         //imagefilename     CHARACTER VARYING(8) NOT NULL
        " ); ";
    }

}
