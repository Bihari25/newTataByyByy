package com.uhg.ihr.medispan.dib.loaders;

/**
*
*/
public class Mmwmedextvocab extends TableLoader {
    
	/**
	 *
	 */
    public Mmwmedextvocab() {
        super();
    }
    
    @Override
    public String getCreateQuery() {
        return
        "CREATE TABLE mmw_med_extvocab " +
        "( " +
            "vocabtypecode               CHARACTER VARYING(1)  NOT NULL, " +
            "extvocabid                  CHARACTER VARYING(20) NOT NULL, " +
            "mcid                        INTEGER NOT NULL, " +
            "CONSTRAINT mmw_med_extvocab_pkey PRIMARY KEY (vocabtypecode, extvocabid, mcid) " +
        ") " +
        "WITH (OIDS=TRUE); ";
    }
    
    @Override
    public String getInsertQuery(String line) {
        String[] fields = line.split("\\|");
        
        return "INSERT INTO mmw_med_extvocab VALUES " +
        "( " +
            "'" + fields[0] + "'," +            //vocabtypecode     CHARACTER VARYING(1)  NOT NULL
            "'" + fields[1] + "'," +            //extvocabid        CHARACTER VARYING(20) NOT NULL
            Integer.parseInt(fields[2]) +       //mcid              INTEGER NOT NULL
        " ); ";
    }

}
