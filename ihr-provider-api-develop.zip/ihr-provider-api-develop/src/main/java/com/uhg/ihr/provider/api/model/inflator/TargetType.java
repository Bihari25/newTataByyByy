package com.uhg.ihr.provider.api.model.inflator;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import org.apache.commons.lang3.builder.ToStringBuilder;

import java.io.Serializable;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
        "sourceVocabulary",
        "sourceVocabularyCode",
        "ihrId",
        "ihrLaymanTerm",
        "ihrTerm"
})
@JsonIgnoreProperties(ignoreUnknown = true)
public class TargetType implements Serializable {

    @JsonProperty("sourceVocabulary")
    private Object sourceVocabulary;
    @JsonProperty("sourceVocabularyCode")
    private Object sourceVocabularyCode;
    @JsonProperty("ihrId")
    private String ihrId;
    @JsonProperty("ihrLaymanTerm")
    private String ihrLaymanTerm;
    @JsonProperty("ihrTerm")
    private String ihrTerm;

    @JsonProperty("sourceVocabulary")
    public Object getSourceVocabulary() {
        return sourceVocabulary;
    }

    @JsonProperty("sourceVocabulary")
    public void setSourceVocabulary(Object sourceVocabulary) {
        this.sourceVocabulary = sourceVocabulary;
    }

    @JsonProperty("sourceVocabularyCode")
    public Object getSourceVocabularyCode() {
        return sourceVocabularyCode;
    }

    @JsonProperty("sourceVocabularyCode")
    public void setSourceVocabularyCode(Object sourceVocabularyCode) {
        this.sourceVocabularyCode = sourceVocabularyCode;
    }

    @JsonProperty("ihrId")
    public String getIhrId() {
        return ihrId;
    }

    @JsonProperty("ihrId")
    public void setIhrId(String ihrId) {
        this.ihrId = ihrId;
    }

    @JsonProperty("ihrLaymanTerm")
    public String getIhrLaymanTerm() {
        return ihrLaymanTerm;
    }

    @JsonProperty("ihrLaymanTerm")
    public void setIhrLaymanTerm(String ihrLaymanTerm) {
        this.ihrLaymanTerm = ihrLaymanTerm;
    }

    @JsonProperty("ihrTerm")
    public String getIhrTerm() {
        return ihrTerm;
    }

    @JsonProperty("ihrTerm")
    public void setIhrTerm(String ihrTerm) {
        this.ihrTerm = ihrTerm;
    }

    @Override
    public String toString() {
        return new ToStringBuilder(this).append("sourceVocabulary", sourceVocabulary).append("sourceVocabularyCode", sourceVocabularyCode).append("ihrId", ihrId).append("ihrLaymanTerm", ihrLaymanTerm).append("ihrTerm", ihrTerm).toString();
    }

}