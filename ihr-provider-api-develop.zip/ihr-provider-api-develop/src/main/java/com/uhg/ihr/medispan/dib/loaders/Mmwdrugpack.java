package com.uhg.ihr.medispan.dib.loaders;

/**
*
*/
public class Mmwdrugpack extends TableLoader {
    
	/**
	 *
	 */
    public Mmwdrugpack() {
        super();
    }
    
    @Override
    public String getCreateQuery() {
        return
        "CREATE TABLE mmw_drug_pack " + 
        "( " +
            "ppid                    CHARACTER VARYING(20) NOT NULL, " +
            "ddid                    INTEGER NOT NULL, " +
            "rtid                    INTEGER NOT NULL, " +
            "dfid                    INTEGER NOT NULL, " +
            "strength                CHARACTER VARYING(15) NULL, " +
            "strengthunit            CHARACTER VARYING(15) NULL, " +
            "teecode                 CHARACTER VARYING(2) NOT NULL, " +
            "deaclasscode            CHARACTER VARYING(1) NULL, " +
            "desicode                CHARACTER VARYING(1) NULL, " +
            "rxotccode               CHARACTER VARYING(1) NOT NULL, " +
            "gppc                    CHARACTER VARYING(8) NOT NULL, " +
            "oldppid                 CHARACTER VARYING(20) NULL, " +
            "newppid                 CHARACTER VARYING(20) NULL, " +
            "repackind               smallINT NOT NULL, " +
            "idformatcode            CHARACTER VARYING(1) NOT NULL, " +
            "thirdprtyrestrcode      CHARACTER VARYING(1) NULL, " +
            "kdc                     CHARACTER VARYING(10) NULL, " +
            "labelerid               CHARACTER VARYING(5) NOT NULL, " +
            "multisourcecode         CHARACTER VARYING(1) NOT NULL, " +
            "nametypecode            CHARACTER VARYING(1) NOT NULL, " +
            "innerpackind            smallINT NOT NULL, " +
            "clinicpackind           smallINT NOT NULL, " +
            "reimbursementcode       CHARACTER VARYING(1) NOT NULL, " +
            "pricespreadcode         CHARACTER VARYING(1) NOT NULL, " +
            "gpi                     CHARACTER VARYING(14) NOT NULL, " +
            "packsize                NUMERIC(8,3) NOT NULL, " +
            "packsizeunitcode        CHARACTER VARYING(2) NOT NULL, " +
            "packquantity            smallINT NOT NULL, " +
            "unitdosecode            CHARACTER VARYING(1) NULL, " +
            "packdesccode            CHARACTER VARYING(2) NOT NULL, " +
            "ndc                     CHARACTER VARYING(13) NOT NULL, " +
            "genidtypecode           CHARACTER VARYING(1) NOT NULL, " +
            "genidnumber             CHARACTER VARYING(9) NOT NULL, " +
            "ahfstheraclasscode      CHARACTER VARYING(6) NOT NULL, " +
            "localsystemiccode       CHARACTER VARYING(1) NOT NULL, " +
            "maintdrugind            smallINT NOT NULL, " +
            "formtypecode            CHARACTER VARYING(1) NOT NULL, " +
            "dollarrankcode          CHARACTER VARYING(1) NOT NULL, " +
            "rxrankcode              CHARACTER VARYING(1) NOT NULL, " +
            "intextcode              CHARACTER VARYING(1) NOT NULL, " +
            "singlecombcode          CHARACTER VARYING(1) NOT NULL, " +
            "storagecondcode         CHARACTER VARYING(1) NULL, " +
            "oldppideffdate          CHARACTER VARYING(8) NULL, " +
            "newppideffdate          CHARACTER VARYING(8) NULL, " +
            "productname             CHARACTER VARYING(25) NOT NULL, " +
            "productnameext          CHARACTER VARYING(35) NULL, " +
            "totalpackageqty         NUMERIC(12,3) NOT NULL, " +
            "currimagefilename       CHARACTER VARYING(8) NULL, " +
            "actcode                 CHARACTER VARYING(1) NULL, " +
            "singleingrind           smallINT NOT NULL, " +
            "meddevind               smallINT NOT NULL, " +
            "inactivedate            CHARACTER VARYING(8) NULL, " +
            "productdescabbrev       CHARACTER VARYING(25) NOT NULL, " +
            "dosechekunit            CHARACTER VARYING(20) NULL, " +
            "itemstatus              CHARACTER VARYING(1) NOT NULL, " +
            "screencleanade          smallINT NULL, " +
            "screencleanprc          smallINT NULL, " +
            "screencleandfa          smallINT NULL, " +
            "screencleandi           smallINT NULL, " +
            "screencleandc           smallINT NULL, " +
            "screencleandda          smallINT NULL, " +
            "partialgpiind           smallINT NOT NULL, " +
            "privatelabelerind       smallINT NOT NULL, " +
            "CONSTRAINT mmw_drug_pack_pkey PRIMARY KEY (ppid) " +
        ") " +
        "WITH (OIDS=TRUE); ";
    }
    
    @Override
    public String getInsertQuery(String line) {
        String[] fields = line.split("\\|");
        
        return "INSERT INTO mmw_drug_pack VALUES " +
        "( " +
            "'" + fields[0] + "'," +                //ppid                    CHARACTER VARYING(20) NOT NULL
            Integer.parseInt(fields[1]) + "," +     //ddid                    INTEGER NOT NULL
            Integer.parseInt(fields[2]) + "," +     //rtid                    INTEGER NOT NULL
            Integer.parseInt(fields[3]) + "," +     //dfid                    INTEGER NOT NULL
            (fields[4].isEmpty() ? "NULL" : "'" + fields[4] + "'") + "," +      //strength                CHARACTER VARYING(15) NULL
            (fields[5].isEmpty() ? "NULL" : "'" + fields[5] + "'") + "," +      //strengthunit            CHARACTER VARYING(15) NULL
            "'" + fields[6] + "'," +                //teecode                 CHARACTER VARYING(2) NOT NULL
            (fields[7].isEmpty() ? "NULL" : "'" + fields[7] + "'") + "," +      //deaclasscode            CHARACTER VARYING(1) NULL
            (fields[8].isEmpty() ? "NULL" : "'" + fields[8] + "'") + "," +      //desicode                CHARACTER VARYING(1) NULL
            "'" + fields[9] + "'," +                //rxotccode               CHARACTER VARYING(1) NOT NULL
            "'" + fields[10] + "'," +               //gppc                    CHARACTER VARYING(8) NOT NULL
            (fields[11].isEmpty() ? "NULL" : "'" + fields[11] + "'") + "," +    //oldppid                 CHARACTER VARYING(20) NULL
            (fields[12].isEmpty() ? "NULL" : "'" + fields[12] + "'") + "," +    //newppid                 CHARACTER VARYING(20) NULL
            "'" + fields[13] + "'," +               //repackind               smallINT NOT NULL
            "'" + fields[14] + "'," +               //idformatcode            CHARACTER VARYING(1) NOT NULL
            (fields[15].isEmpty() ? "NULL" : "'" + fields[15] + "'") + "," +    //thirdprtyrestrcode      CHARACTER VARYING(1) NULL
            (fields[16].isEmpty() ? "NULL" : "'" + fields[16] + "'") + "," +    //kdc                     CHARACTER VARYING(10) NULL
            "'" + fields[17] + "'," +               //labelerid               CHARACTER VARYING(5) NOT NULL
            "'" + fields[18] + "'," +               //multisourcecode         CHARACTER VARYING(1) NOT NULL
            "'" + fields[19] + "'," +               //nametypecode            CHARACTER VARYING(1) NOT NULL
            Integer.parseInt(fields[20]) + "," +    //innerpackind            smallINT NOT NULL
            Integer.parseInt(fields[21]) + "," +    //clinicpackind           smallINT NOT NULL
            "'" + fields[22] + "'," +               //reimbursementcode       CHARACTER VARYING(1) NOT NULL
            "'" + fields[23] + "'," +               //pricespreadcode         CHARACTER VARYING(1) NOT NULL
            "'" + fields[24] + "'," +               //gpi                     CHARACTER VARYING(14) NOT NULL
            Float.parseFloat(fields[25]) + "," +    //packsize                NUMERIC(8,3) NOT NULL
            "'" + fields[26] + "'," +               //packsizeunitcode        CHARACTER VARYING(2) NOT NULL
            Integer.parseInt(fields[27]) + "," +    //packquantity            smallINT NOT NULL
            (fields[28].isEmpty() ? "NULL" : "'" + fields[28] + "'") + "," +    //unitdosecode            CHARACTER VARYING(1) NULL
            "'" + fields[29] + "'," +               //packdesccode            CHARACTER VARYING(2) NOT NULL
            "'" + fields[30] + "'," +               //ndc                     CHARACTER VARYING(13) NOT NULL
            "'" + fields[31] + "'," +               //genidtypecode           CHARACTER VARYING(1) NOT NULL
            "'" + fields[32] + "'," +               //genidnumber             CHARACTER VARYING(9) NOT NULL
            "'" + fields[33] + "'," +               //ahfstheraclasscode      CHARACTER VARYING(6) NOT NULL
            "'" + fields[34] + "'," +               //localsystemiccode       CHARACTER VARYING(1) NOT NULL
            Integer.parseInt(fields[35]) + "," +    //maintdrugind            smallINT NOT NULL
            "'" + fields[36] + "'," +               //formtypecode            CHARACTER VARYING(1) NOT NULL
            "'" + fields[37] + "'," +               //dollarrankcode          CHARACTER VARYING(1) NOT NULL
            "'" + fields[38] + "'," +               //rxrankcode              CHARACTER VARYING(1) NOT NULL
            "'" + fields[39] + "'," +               //intextcode              CHARACTER VARYING(1) NOT NULL
            "'" + fields[40] + "'," +               //singlecombcode          CHARACTER VARYING(1) NOT NULL
            (fields[41].isEmpty() ? "NULL" : "'" + fields[41] + "'") + "," +    //storagecondcode         CHARACTER VARYING(1) NULL
            (fields[42].isEmpty() ? "NULL" : "'" + fields[42] + "'") + "," +    //oldppideffdate          CHARACTER VARYING(8) NULL
            (fields[43].isEmpty() ? "NULL" : "'" + fields[43] + "'") + "," +    //newppideffdate          CHARACTER VARYING(8) NULL
            "'" + fields[44].replace("'", "''") + "'," +               //productname             CHARACTER VARYING(25) NOT NULL
            (fields[45].isEmpty() ? "NULL" : "'" + fields[45].replace("'", "''") + "'") + "," +    //productnameext          CHARACTER VARYING(35) NULL
            Float.parseFloat(fields[46]) + "," +    //totalpackageqty         NUMERIC(12,3) NOT NULL
            (fields[47].isEmpty() ? "NULL" : "'" + fields[47] + "'") + "," +    //currimagefilename       CHARACTER VARYING(8) NULL
            (fields[48].isEmpty() ? "NULL" : "'" + fields[48] + "'") + "," +    //actcode                 CHARACTER VARYING(1) NULL
            Integer.parseInt(fields[49]) + "," +    //singleingrind           smallINT NOT NULL
            Integer.parseInt(fields[50]) + "," +    //meddevind               smallINT NOT NULL
            (fields[51].isEmpty() ? "NULL" : "'" + fields[51] + "'") + "," +    //inactivedate            CHARACTER VARYING(8) NULL
            "'" + fields[52].replace("'", "''") + "'," +               //productdescabbrev       CHARACTER VARYING(25) NOT NULL
            (fields[53].isEmpty() ? "NULL" : "'" + fields[53] + "'") + "," +    //dosechekunit            CHARACTER VARYING(20) NULL
            "'" + fields[54] + "'," +               //itemstatus              CHARACTER VARYING(1) NOT NULL
            (fields[55].isEmpty() ? "NULL" : Integer.parseInt(fields[55])) + "," +    //screencleanade          smallINT NULL
            (fields[56].isEmpty() ? "NULL" : Integer.parseInt(fields[56])) + "," +    //screencleanprc          smallINT NULL
            (fields[57].isEmpty() ? "NULL" : Integer.parseInt(fields[57])) + "," +    //screencleandfa          smallINT NULL
            (fields[58].isEmpty() ? "NULL" : Integer.parseInt(fields[58])) + "," +    //screencleandi           smallINT NULL
            (fields[59].isEmpty() ? "NULL" : Integer.parseInt(fields[59])) + "," +    //screencleandc           smallINT NULL
            (fields[60].isEmpty() ? "NULL" : Integer.parseInt(fields[60])) + "," +    //screencleandda          smallINT NULL
            Integer.parseInt(fields[61]) + "," +    //partialgpiind           smallINT NOT NULL
            Integer.parseInt(fields[62]) +          //privatelabelerind       smallINT NOT NULL
        " ); ";
    }

}
