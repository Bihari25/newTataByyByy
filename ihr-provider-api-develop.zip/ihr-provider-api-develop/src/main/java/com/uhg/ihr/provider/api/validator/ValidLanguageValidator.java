package com.uhg.ihr.provider.api.validator;

import javax.validation.ConstraintValidator;
import javax.validation.ConstraintValidatorContext;
import java.util.List;
import java.util.Locale;

public class ValidLanguageValidator implements ConstraintValidator<ValidLanguage, String> {
    @Override
    public boolean isValid(String value, ConstraintValidatorContext constraintValidatorContext) {
        if (value == null || value.isBlank() || value.matches("\\*")) {
            return true;
        }
        List<Locale.LanguageRange> locales = Locale.LanguageRange.parse(value);
        if (locales.isEmpty()) {
            return false;
        }
        return true;
    }
}