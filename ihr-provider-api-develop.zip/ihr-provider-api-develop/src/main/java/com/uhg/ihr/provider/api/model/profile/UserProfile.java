package com.uhg.ihr.provider.api.model.profile;


import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.*;

@Data
@Builder(toBuilder = true)
@AllArgsConstructor
@NoArgsConstructor
@JsonInclude(JsonInclude.Include.NON_NULL)
@EqualsAndHashCode(callSuper=false)
public class UserProfile {
//    private UserProfileConstant.SYSTEM system;
//    private UserProfileConstant.SECURED_CONTEXT securedContext;
    protected  IhrUser user;
}
