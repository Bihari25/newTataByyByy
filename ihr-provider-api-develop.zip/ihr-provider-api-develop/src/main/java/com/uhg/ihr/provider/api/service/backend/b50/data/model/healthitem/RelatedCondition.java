package com.uhg.ihr.provider.api.service.backend.b50.data.model.healthitem;


import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.*;

import javax.validation.constraints.NotNull;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder(toBuilder = true)
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(JsonInclude.Include.NON_NULL)
@EqualsAndHashCode(callSuper=false)
public class RelatedCondition extends RelatedHealthItem {
    @JsonProperty
    @NotNull(message = "related condition")
    private String term;

    @JsonProperty
    private String onsetDate;

    @JsonProperty
    private String lastUpdateDate;

    @JsonProperty
    private String status;
}
