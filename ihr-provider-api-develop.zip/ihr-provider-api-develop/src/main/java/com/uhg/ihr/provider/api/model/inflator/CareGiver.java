package com.uhg.ihr.provider.api.model.inflator;


import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import org.apache.commons.lang3.builder.ToStringBuilder;

import java.io.Serializable;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
        "recordType",
        "objectId",
        "relatedEntityName",
        "relationshipToIndividual",
        "relatedEntityRoleTerm",
        "relationshipEndDate",
        "relationshipStartDate"
})
@JsonIgnoreProperties(ignoreUnknown = true)
public class CareGiver implements Serializable {

    @JsonProperty("recordType")
    private String recordType;
    @JsonProperty("objectId")
    private long objectId;
    @JsonProperty("relatedEntityName")
    private String relatedEntityName;
    @JsonProperty("relationshipToIndividual")
    private String relationshipToIndividual;
    @JsonProperty("relatedEntityRoleTerm")
    private String relatedEntityRoleTerm;
    @JsonProperty("relationshipEndDate")
    private Object relationshipEndDate;
    @JsonProperty("relationshipStartDate")
    private String relationshipStartDate;

    @JsonProperty("recordType")
    public String getRecordType() {
        return recordType;
    }

    @JsonProperty("recordType")
    public void setRecordType(String recordType) {
        this.recordType = recordType;
    }

    @JsonProperty("objectId")
    public long getObjectId() {
        return objectId;
    }

    @JsonProperty("objectId")
    public void setObjectId(long objectId) {
        this.objectId = objectId;
    }

    @JsonProperty("relatedEntityName")
    public String getRelatedEntityName() {
        return relatedEntityName;
    }

    @JsonProperty("relatedEntityName")
    public void setRelatedEntityName(String relatedEntityName) {
        this.relatedEntityName = relatedEntityName;
    }

    @JsonProperty("relationshipToIndividual")
    public String getRelationshipToIndividual() {
        return relationshipToIndividual;
    }

    @JsonProperty("relationshipToIndividual")
    public void setRelationshipToIndividual(String relationshipToIndividual) {
        this.relationshipToIndividual = relationshipToIndividual;
    }

    @JsonProperty("relatedEntityRoleTerm")
    public String getRelatedEntityRoleTerm() {
        return relatedEntityRoleTerm;
    }

    @JsonProperty("relatedEntityRoleTerm")
    public void setRelatedEntityRoleTerm(String relatedEntityRoleTerm) {
        this.relatedEntityRoleTerm = relatedEntityRoleTerm;
    }

    @JsonProperty("relationshipEndDate")
    public Object getRelationshipEndDate() {
        return relationshipEndDate;
    }

    @JsonProperty("relationshipEndDate")
    public void setRelationshipEndDate(Object relationshipEndDate) {
        this.relationshipEndDate = relationshipEndDate;
    }

    @JsonProperty("relationshipStartDate")
    public String getRelationshipStartDate() {
        return relationshipStartDate;
    }

    @JsonProperty("relationshipStartDate")
    public void setRelationshipStartDate(String relationshipStartDate) {
        this.relationshipStartDate = relationshipStartDate;
    }

    @Override
    public String toString() {
        return new ToStringBuilder(this).append("recordType", recordType).append("objectId", objectId).append("relatedEntityName", relatedEntityName).append("relationshipToIndividual", relationshipToIndividual).append("relatedEntityRoleTerm", relatedEntityRoleTerm).append("relationshipEndDate", relationshipEndDate).append("relationshipStartDate", relationshipStartDate).toString();
    }
}