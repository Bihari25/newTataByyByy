package com.uhg.ihr.provider.api.model;

import com.uhg.ihr.provider.api.exception.MalformedGlobalObjectIdException;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.extern.slf4j.Slf4j;

@Slf4j
@Data
@AllArgsConstructor
public class GlobalHealthObjectId {

    private static final String ID_JOINER = "-";

    private RecordType recordType;
    private int objectId;

    private GlobalHealthObjectId() {

    }

    public GlobalHealthObjectId(String globalId) {
        try {
            String[] parsed = globalId.split(ID_JOINER);
            this.recordType = RecordType.valueOf(Integer.parseInt(parsed[0]));
            this.objectId = Integer.parseInt(parsed[1]);
        } catch (Exception e) {
            MalformedGlobalObjectIdException f = new MalformedGlobalObjectIdException("Malformed global health item id");
            log.error("Failed to parse id '" + globalId + "' due to: " + e.getMessage(), e);
            throw f;
        }

    }

    public String getGlobalId() {
        return this.recordType.getNodeIndex() + ID_JOINER + this.objectId;
    }
}
