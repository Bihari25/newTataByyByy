package com.uhg.ihr.provider.api.service.backend.b50.profile;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.uhg.ihr.provider.api.exception.LiteHttpClientException;
import com.uhg.ihr.provider.api.exception.NoUserFoundException;
import com.uhg.ihr.provider.api.exception.UnhandledApiException;
import com.uhg.ihr.provider.api.model.MemberName;
import com.uhg.ihr.provider.api.model.ProviderApiHeaders;
import com.uhg.ihr.provider.api.model.profile.IhrUser;
import com.uhg.ihr.provider.api.model.profile.UserPermission;
import com.uhg.ihr.provider.api.model.profile.UserProfileConstant;
import com.uhg.ihr.provider.api.model.profile.UserRole;
import com.uhg.ihr.provider.api.service.backend.b50.B50ApiSecurity;
import com.uhg.ihr.provider.api.service.backend.b50.CommonTransformers;
import com.uhg.ihr.provider.api.service.backend.b50.model.B50UserDemographics;
import com.uhg.ihr.provider.api.service.backend.b50.profile.model.B50ProfileRegisterRequest;
import com.uhg.ihr.provider.api.service.backend.b50.search.model.Identifier;
import io.micronaut.http.HttpStatus;
import io.micronaut.http.client.exceptions.HttpClientResponseException;
import io.reactivex.Maybe;
import lombok.extern.slf4j.Slf4j;

import javax.inject.Inject;
import javax.inject.Singleton;
import java.util.*;
import java.util.stream.Collectors;

@Singleton
@Slf4j
public class B50ProfileService {

    private static final ObjectMapper MAPPER = new ObjectMapper();

    @Inject
    ProfileClient client;
    @Inject
    B50ApiSecurity security;

    public Maybe<IhrUser> registerProfile(IhrUser user, ProviderApiHeaders headers) {
        B50ProfileRegisterRequest request = buildRegisterRequest(user);
        Maybe<JsonNode> response;
        if (request.getUserType() == UserProfileConstant.USER_TYPE.STAFF && request.getGlobalActorId() == null) {
            response = client.createStaffProfile(security.generateProviderBearerToken(""), request,
                    headers.getCorrelationId(), headers.getAcceptLanguage());
        } else {
            response = client.registerProfile(security.generateProviderBearerToken(""), request,
                    headers.getCorrelationId(), headers.getAcceptLanguage());
        }
        return response
                .map(json -> json.get("GLOBAL_ACTOR_ID").asText())
                .onErrorResumeNext(e -> {
                    if (e instanceof HttpClientResponseException) {
                        return Maybe.error(new LiteHttpClientException((HttpClientResponseException) e, request));
                    } else {
                        return Maybe.error(new UnhandledApiException(e));
                    }
                })
                .flatMap(chid -> {
                    IhrUser createdUser = IhrUser.builder().identifierContexts(Map.of(UserProfileConstant.IDENTIFIER_CONTEXT.IHR, chid)).build();
                    return getProfile(chid, headers)
                            .map(b50User -> {
                                if (b50User != null) {
                                    createdUser.combineIhrUsers(b50User);
                                }
                                return createdUser;
                            });
                });
    }

    public Maybe<IhrUser> lookupProfile(String providerLastName, String providerNpi, ProviderApiHeaders headers) {
        B50UserDemographics request = new B50UserDemographics();
        request.setLastName(providerLastName);
        request.setIdentifiers(List.of(Map.of(Identifier.NPI_ID, providerNpi)));
        request.setGlobalActorId("");
        return searchActors(request, headers)
                .map(B50ProfileTransformer::transformProfile);
    }

    public Maybe<IhrUser> getProfile(String globalActorId, ProviderApiHeaders headers) {
        B50UserDemographics request = new B50UserDemographics();
        request.setGlobalActorId(globalActorId);
        return searchActors(request, headers)
                .map(B50ProfileTransformer::transformProfile)
                .onErrorResumeNext(e -> {
                    if (e instanceof NoUserFoundException) {
                        return Maybe.empty();
                    } else {
                        return Maybe.error(e);
                    }
                });
    }

    public Maybe<JsonNode> searchActors(B50UserDemographics request, ProviderApiHeaders headers) {
        return client.searchProfile(security.generateProviderBearerToken(request.getGlobalActorId()), request,
                headers.getCorrelationId(), headers.getAcceptLanguage())
                .onErrorResumeNext(e -> {
                    if (e instanceof HttpClientResponseException) {
                        if (((HttpClientResponseException) e).getResponse().getStatus().equals(HttpStatus.NO_CONTENT)) {
                            return Maybe.empty();
                        } else {
                            return Maybe.error(new LiteHttpClientException((HttpClientResponseException) e, request));
                        }
                    } else {
                        return Maybe.error(new UnhandledApiException(e));
                    }
                });
    }

    public B50ProfileRegisterRequest buildRegisterRequest(IhrUser user) {
        B50ProfileRegisterRequest request = new B50ProfileRegisterRequest();
        if (user.getUserType() == UserProfileConstant.USER_TYPE.STAFF &&
                user.getIdentifierContextValue(UserProfileConstant.IDENTIFIER_CONTEXT.IHR) == null) {
            //Build staff registration request using demographics
            MemberName name = user.getName();
            request.setFirstName(name.getFirst());
            request.setMiddleName(name.getMiddle());
            request.setLastName(name.getLast());
            request.setAddresses(user.getAddresses() == null ?
                    new ArrayList<>() :
                    user.getAddresses()
                            .stream()
                            .map(CommonTransformers::memberAddressToAddress)
                            .collect(Collectors.toUnmodifiableList())
            );
            request.setPhones(user.getPhones() == null ?
                    new ArrayList<>() :
                    user.getPhones()
                            .stream()
                            .map(CommonTransformers::userPhoneToPhone)
                            .collect(Collectors.toUnmodifiableList())
            );
            request.setIdentifiers(user.getIdentifiers() == null ?
                    new ArrayList<>() :
                    user.getIdentifiers()
                            .stream()
                            .map(CommonTransformers::idToMap)
                            .collect(Collectors.toUnmodifiableList())
            );
        } else {
            //Build provider/staff registration request using Global_Actor_Id
            request.setGlobalActorId(user.getIdentifierContextValue(UserProfileConstant.IDENTIFIER_CONTEXT.IHR));
            request.setIdentifiers(new ArrayList<>());
        }
        //TODO: Update to pull subject out of JWT token
        request.setSource(UserProfileConstant.ROLE_CONTEXT.PORTAL);
        //Add PORTAL_ID to identifiers, required by B50
        request.getIdentifiers().add(Map.of(Identifier.PORTAL_ID, user.getIdentifierContextValue(UserProfileConstant.IDENTIFIER_CONTEXT.PORTAL)));

        UserPermission perms = getPermissionForContext(user, UserProfileConstant.ROLE_CONTEXT.IHR);
        List<String> roles = Collections.emptyList();
        if (perms != null) {
            Set<UserRole> sRoles = perms.getRoles();
            if (sRoles != null) {
                roles = sRoles.stream()
                        .map(UserRole::getId)
                        .collect(Collectors.toList());
            }
            else {
                log.warn("No roles found in UserPermissions: null");
            }
        }
        else {
            log.warn("No UserPermissions found: null");
        }

        request.setRole(roles);
        request.setUserType(user.getUserType());
        return request;
    }

    /**
     * @param user    User to get the permissions from
     * @param context The ROLE_CONTEXT to look for
     * @return Returns the found UserPermission or null if no UserPermission found for context
     */
    public UserPermission getPermissionForContext(IhrUser user, UserProfileConstant.ROLE_CONTEXT context) {
        for (UserPermission permission : user.getUserPermissions()) {
            if (permission.getContext() == context) {
                return permission;
            }
        }
        return null;
    }
}
