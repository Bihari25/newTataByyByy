package com.uhg.ihr.provider.api.service.backend.b50.data.model.healthitem;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.*;

@Data
@NoArgsConstructor
@AllArgsConstructor
@Builder(toBuilder = true)
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(JsonInclude.Include.NON_NULL)
@EqualsAndHashCode(callSuper=false)
public class RelatedProcedure extends  RelatedHealthItem {
    @JsonProperty
    private String term;

    @JsonProperty
    private String date;

    @JsonProperty
    private String status;
}
