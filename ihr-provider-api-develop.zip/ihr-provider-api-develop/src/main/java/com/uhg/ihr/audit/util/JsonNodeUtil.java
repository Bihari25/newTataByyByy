/**
 * Copyright (C) 2020 UnitedHealth Group
 * <p>
 * All rights reserved.
 */
package com.uhg.ihr.audit.util;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.node.MissingNode;
import com.fasterxml.jackson.databind.node.NullNode;

/**
 * @author Kristopher T Babic
 * @version 1.0
 */
public interface JsonNodeUtil {
    static JsonNode getJsonNode(JsonNode node, String path) {
        if (node == null || path == null || path.isBlank()) {
            return MissingNode.getInstance();
        }

        String[] pathElements = path.split("\\.");

        JsonNode valNode = null;
        for (String pathPart : pathElements) {
            if (valNode == null) {
                valNode = node.path(pathPart);
            }
            else {
                valNode = valNode.path(pathPart);
            }
        }

        return valNode != null ? valNode : MissingNode.getInstance();
    }

    static String getString(JsonNode node, String path) {
        return getString(node, path, "");
    }
    static String getString(JsonNode node, String path, String defaultVal) {
        JsonNode valNode = getJsonNode(node, path);

        if (valNode != null && !valNode.isMissingNode()) {
            return valNode.asText(defaultVal);
        }
        return defaultVal;
    }
    static int getInt(JsonNode node, String path) {
        return getInt(node, path, 0);
    }
    static int getInt(JsonNode node, String path, int defaultVal) {
        JsonNode valNode = getJsonNode(node, path);

        if (valNode != null && !valNode.isMissingNode()) {
            return valNode.asInt(defaultVal);
        }
        return defaultVal;
    }

    static long getLong(JsonNode node, String path) {
        return getLong(node, path, 0);
    }
    static long getLong(JsonNode node, String path, long defaultVal) {
        JsonNode valNode = getJsonNode(node, path);

        if (valNode != null && !valNode.isMissingNode()) {
            return valNode.asLong(defaultVal);
        }
        return defaultVal;
    }


/*

        static Map<String, Object> getEnvironment() {
            return Map.of(
                    "app-name", APPNAME.getValue(),
                    "env-name", NAME.getValue(),
                    "instance", INSTANCE.getValue(),
                    "secure-env", SECURE_ENVIRONMENT.getValue()
                         );
        }

 */
}
