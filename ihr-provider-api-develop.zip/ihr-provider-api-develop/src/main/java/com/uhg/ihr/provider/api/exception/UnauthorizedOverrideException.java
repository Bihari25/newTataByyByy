package com.uhg.ihr.provider.api.exception;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.ObjectNode;
import com.uhg.ihr.provider.api.model.ProviderApiHeaders;
import lombok.extern.slf4j.Slf4j;

@Slf4j
public class UnauthorizedOverrideException extends RuntimeException {
    public UnauthorizedOverrideException(String message, ProviderApiHeaders headers) {
        super(message);
        ObjectMapper mapper = new ObjectMapper();
        ObjectNode errorNode = mapper.createObjectNode();
        errorNode.put("message", message);
        errorNode.putPOJO("headers", headers);
        try {
            log.error(mapper.writeValueAsString(errorNode));
        } catch (JsonProcessingException e) {
            log.error("Failed to write out override failure details");
        }
    }
}
