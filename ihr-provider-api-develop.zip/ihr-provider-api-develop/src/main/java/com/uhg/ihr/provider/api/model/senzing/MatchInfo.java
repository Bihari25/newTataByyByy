package com.uhg.ihr.provider.api.model.senzing;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

public class MatchInfo implements Serializable {
    private int noOfRecords;

    private List<MatchLevel> matchLevels;

    public MatchInfo() {
        matchLevels = new ArrayList<>();
    }

    public int getNoOfRecords() {
        return noOfRecords;
    }

    public void setNoOfRecords(int noOfRecords) {
        this.noOfRecords = noOfRecords;
    }

    public List<MatchLevel> getMatchLevels() { return matchLevels;}

    public void setMatchLevels(List<MatchLevel> matchLevels) {
        this.matchLevels = matchLevels;
    }

    public void addMatchLevel(MatchLevel matchLevel) {
        this.matchLevels.add(matchLevel);
    }
}
