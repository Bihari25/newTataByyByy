package com.uhg.ihr.provider.api.exception;

import io.micronaut.context.annotation.Requires;
import io.micronaut.http.HttpRequest;
import io.micronaut.http.HttpResponse;
import io.micronaut.http.HttpStatus;
import io.micronaut.http.annotation.Produces;
import io.micronaut.http.server.exceptions.ExceptionHandler;
import io.micronaut.http.server.netty.NettyHttpResponseFactory;
import lombok.extern.slf4j.Slf4j;

import javax.inject.Singleton;

@Slf4j
@Produces
@Singleton
@Requires(classes = {UnhandledApiException.class, ExceptionHandler.class})
public class UnauthorizedOverrideExceptionHandler implements ExceptionHandler<UnauthorizedOverrideException, HttpResponse> {
    @Override
    public HttpResponse handle(HttpRequest request, UnauthorizedOverrideException exception) {
        return NettyHttpResponseFactory.INSTANCE.status(HttpStatus.FORBIDDEN, ErrorHelper.handleError(request, exception));
    }
}

