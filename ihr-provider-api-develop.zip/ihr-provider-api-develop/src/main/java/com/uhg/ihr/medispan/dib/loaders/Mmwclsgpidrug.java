package com.uhg.ihr.medispan.dib.loaders;

/**
*
*/
public class Mmwclsgpidrug extends TableLoader {
    
	/**
	 *
	 */
    public Mmwclsgpidrug() {
        super();
    }
    
    @Override
    public String getCreateQuery() {
        return
        "CREATE TABLE mmw_cls_gpidrug " +
        "( " +
            "classid                     CHARACTER VARYING(6) NOT NULL, " +
            "drugtype                    SMALLINT NOT NULL, " +
            "drugid                      INTEGER NOT NULL, " +
            "CONSTRAINT mmw_cls_gpidrug_pkey PRIMARY KEY (classid, drugtype, drugid) " +
        ") " +
        "WITH (OIDS=TRUE); ";
    }
    
    @Override
    public String getInsertQuery(String line) {
        String[] fields = line.split("\\|");
        
        return "INSERT INTO mmw_cls_gpidrug VALUES " +
        "( " +
            "'" + fields[0] + "'," +                //classid        CHARACTER VARYING(6) NOT NULL
            Integer.parseInt(fields[1]) + "," +     //drugtype       SMALLINT NOT NULL
            Integer.parseInt(fields[2]) +           //drugid         INTEGER NOT NULL
        " ); ";
    }

}
