package com.uhg.ihr.audit;

import com.uhg.ihr.audit.factory.AuditFactory;
import com.uhg.ihr.audit.service.AuditService;
import io.micronaut.context.annotation.Context;
import io.micronaut.http.HttpRequest;
import io.micronaut.http.HttpStatus;
import io.micronaut.http.MediaType;
import io.micronaut.http.MutableHttpResponse;
import io.micronaut.http.annotation.Body;
import io.micronaut.http.annotation.Controller;
import io.micronaut.http.annotation.Post;
import io.micronaut.http.server.netty.NettyHttpResponseFactory;
import io.micronaut.validation.Validated;
import io.reactivex.Flowable;
import io.reactivex.Maybe;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import lombok.extern.slf4j.Slf4j;

import javax.inject.Inject;
import javax.validation.Valid;

@Slf4j
@Validated
@Context
@Controller("/audits/v1")
public class AuditController {
    @Inject
    private AuditService auditService;

    @Inject
    private AuditFactory auditFactory;

    @Post(uri = "/create", produces = MediaType.APPLICATION_JSON, consumes = MediaType.APPLICATION_JSON)
    @ApiResponse(responseCode = "200", description = "Audit Accepted")
    @Operation(summary = "Create and IHR audit record",
            description = "Create an IHR audit record",
            operationId = "create")
    @Schema(name = "IHR Audit Request")
    public Maybe<MutableHttpResponse<Object>> createAudit(HttpRequest myRequest,
                                                          @Valid @Body Audit audit) {
        return buildResponse(
                auditService.sendAudit(
                        auditFactory.prefillAudit(myRequest, audit)));
    }

    private Maybe<MutableHttpResponse<Object>> buildResponse(Flowable<Audit> auditFlowable) {
        Maybe<Audit> data = auditFlowable.firstElement();
        return data
                .map(ignored -> NettyHttpResponseFactory.INSTANCE.ok())
                .defaultIfEmpty(NettyHttpResponseFactory.INSTANCE.status(HttpStatus.NOT_FOUND));
    }
}
