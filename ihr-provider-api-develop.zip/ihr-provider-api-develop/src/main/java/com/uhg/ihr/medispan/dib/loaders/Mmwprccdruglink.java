package com.uhg.ihr.medispan.dib.loaders;

/**
*
*/
public class Mmwprccdruglink extends TableLoader {
    
	/**
	 *
	 */
    public Mmwprccdruglink() {
        super();
    }
    
    @Override
    public String getCreateQuery() {
        return
        "CREATE TABLE mmw_prcc_druglink " +
        "( " +
            "gpi                         CHARACTER VARYING(14) NOT NULL, " +
            "mcid                        INTEGER NOT NULL, " +
            "restrictionid               INTEGER NOT NULL, " +
            "mgmtlevelcode               CHARACTER VARYING(1) NOT NULL, " +
            "placenttranscode            CHARACTER VARYING(1) NULL, " +
            "fdariskfactorcode           CHARACTER VARYING(1) NULL, " +
            "briggsratingcode            CHARACTER VARYING(1) NULL, " +
            "brstfeedexcretcode          CHARACTER VARYING(1) NULL, " +
            "brstfeedratingcode          CHARACTER VARYING(1) NULL, " +
            "brstfeedaapcode             CHARACTER VARYING(1) NULL, " +
            "CONSTRAINT mmw_prcc_druglink_pkey PRIMARY KEY (gpi, mcid, restrictionid) " +
        ") " +
        "WITH (OIDS=TRUE); ";
    }
    
    @Override
    public String getInsertQuery(String line) {
        String[] fields = line.split("\\|");
        
        return "INSERT INTO mmw_prcc_druglink VALUES " +
        "( " +
            "'" + fields[0] + "'," +                //gpi                         CHARACTER VARYING(14) NOT NULL
            Integer.parseInt(fields[1]) + "," +     //mcid                        INTEGER NOT NULL
            Integer.parseInt(fields[2]) + "," +     //restrictionid               INTEGER NOT NULL
            "'" + fields[3] + "'," +                //mgmtlevelcode               CHARACTER VARYING(1) NOT NULL
            (fields.length < 5 || fields[4].isEmpty() ? "NULL" : "'" + fields[4] + "'") + "," + //placenttranscode            CHARACTER VARYING(1) NULL
            (fields.length < 6 || fields[5].isEmpty() ? "NULL" : "'" + fields[5] + "'") + "," + //fdariskfactorcode           CHARACTER VARYING(1) NULL
            (fields.length < 7 || fields[6].isEmpty() ? "NULL" : "'" + fields[6] + "'") + "," + //briggsratingcode            CHARACTER VARYING(1) NULL
            (fields.length < 8 || fields[7].isEmpty() ? "NULL" : "'" + fields[7] + "'") + "," + //brstfeedexcretcode          CHARACTER VARYING(1) NULL
            (fields.length < 9 || fields[8].isEmpty() ? "NULL" : "'" + fields[8] + "'") + "," + //brstfeedratingcode          CHARACTER VARYING(1) NULL
            (fields.length < 10 || fields[9].isEmpty() ? "NULL" : "'" + fields[9] + "'") +      //brstfeedaapcode             CHARACTER VARYING(1) NULL
        " ); ";
    }

}
