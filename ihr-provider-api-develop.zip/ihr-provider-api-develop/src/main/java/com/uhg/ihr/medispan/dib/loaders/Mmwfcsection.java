package com.uhg.ihr.medispan.dib.loaders;

/**
*
*/
public class Mmwfcsection extends TableLoader {
    
	/**
	 *
	 */
    public Mmwfcsection() {
        super();
    }
    
    @Override
    public String getCreateQuery() {
        return
        "CREATE TABLE mmw_fc_section " +
        "( " +
            "sectionid                   INTEGER NOT NULL, " +
            "sectiontitle                CHARACTER VARYING(40) NOT NULL, " +
            "xpath                       CHARACTER VARYING(255) NOT NULL, " +
            "CONSTRAINT mmw_fc_section_pkey PRIMARY KEY (sectionid) " +
        ") " +
        "WITH (OIDS=TRUE); ";
    }
    
    @Override
    public String getInsertQuery(String line) {
        String[] fields = line.split("\\|");
        
        return "INSERT INTO mmw_fc_section VALUES " +
        "( " +
            Integer.parseInt(fields[0]) + "," +     //sectionid         INTEGER NOT NULL
            "'" + fields[1] + "'," +                //sectiontitle      CHARACTER VARYING(40) NOT NULL
            "'" + fields[2] + "'" +                 //xpath             CHARACTER VARYING(255) NOT NULL
        " ); ";
    }

}
