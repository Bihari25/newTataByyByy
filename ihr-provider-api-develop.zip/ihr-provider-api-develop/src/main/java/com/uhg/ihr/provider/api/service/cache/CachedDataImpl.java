package com.uhg.ihr.provider.api.service.cache;

import com.fasterxml.jackson.databind.JsonNode;
import com.uhg.ihr.provider.api.model.ProviderApiHeaders;
import com.uhg.ihr.provider.api.service.backend.DataAdapterInterface;
import io.micronaut.cache.annotation.CacheConfig;
import io.micronaut.cache.annotation.Cacheable;
import io.micronaut.context.annotation.Requires;
import io.reactivex.Maybe;

import javax.inject.Inject;
import javax.inject.Singleton;

@CacheConfig("data")
@Requires(property = "redis.caches.data")
@Singleton
public class CachedDataImpl implements CachedDataInterface {

    @Inject
    DataAdapterInterface adapter;

    @Cacheable(parameters = {"providerChid", "patientChid", "overrideToken"})
    @Override
    public Maybe<JsonNode> getFromCache(String providerChid, String patientChid,
                                        String overrideToken, ProviderApiHeaders headers) {
        return adapter.getAllByActorChid(providerChid, patientChid, headers);
    }
}
