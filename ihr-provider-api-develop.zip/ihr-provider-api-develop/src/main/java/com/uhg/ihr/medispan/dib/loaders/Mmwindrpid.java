package com.uhg.ihr.medispan.dib.loaders;

/**
*
*/
public class Mmwindrpid extends TableLoader {
    
	/**
	 *
	 */
    public Mmwindrpid() {
        super();
    }
    
    @Override
    public String getCreateQuery() {
        return
        "CREATE TABLE mmw_ind_rpid " +
        "( " +
            "mcid                        INTEGER NOT NULL, " +
            "rpid                        INTEGER NOT NULL, " +
            "outcomecode                 CHARACTER VARYING(2) NOT NULL, " +
            "acceptancelvlcode           CHARACTER VARYING(2) NOT NULL, " +
            "CONSTRAINT mmw_ind_rpid_pkey PRIMARY KEY (mcid, rpid, outcomecode, acceptancelvlcode) " +
        ") " +
        "WITH (OIDS=TRUE); ";
    }
    
    @Override
    public String getInsertQuery(String line) {
        String[] fields = line.split("\\|");
        
        return "INSERT INTO mmw_ind_rpid VALUES " +
        "( " +
            Integer.parseInt(fields[0]) + "," +     //mcid                        INTEGER NOT NULL
            Integer.parseInt(fields[1]) + "," +     //rpid                        INTEGER NOT NULL
            "'" + fields[2] + "'," +                //outcomecode                 CHARACTER VARYING(2) NOT NULL
            "'" + fields[3] + "'" +                 //acceptancelvlcode           CHARACTER VARYING(2) NOT NULL
        " ); ";
    }

}
