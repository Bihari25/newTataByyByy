/**
 * Copyright (C) 2020 UnitedHealth Group
 * <p>
 * All rights reserved.
 */
package com.uhg.ihr.audit.producer;

import com.uhg.ihr.audit.Audit;
import io.reactivex.Flowable;

/**
 * @author Anurag Singh
 * @version 1.0
 */
public interface AuditClient {

    Flowable<Audit> send(Audit audit);

}
