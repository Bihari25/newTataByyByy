/**
 * Copyright (C) 2020 UnitedHealth Group
 * <p>
 * All rights reserved.
 */
package com.uhg.ihr.provider.api.model.profile;

import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.*;

import javax.validation.Valid;
import javax.validation.constraints.NotNull;

/**
 * Represents a user profile update/create request object.
 *
 * @author Kristopher T Babic
 * @version 1.0
 */

@Data
@Builder(toBuilder = true)
@AllArgsConstructor
@NoArgsConstructor
@JsonInclude(JsonInclude.Include.NON_NULL)
@EqualsAndHashCode(callSuper=false)
public class UserProfileRequest {
    @Valid
    private ExternalSecurityAccess externalSecurity;
    @NotNull(message = "The request could not be validated. User is required")
    private IhrUser user;
    private FilterClass responseFilter;
}
