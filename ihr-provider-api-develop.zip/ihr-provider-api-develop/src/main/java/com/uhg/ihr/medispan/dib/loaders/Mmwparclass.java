package com.uhg.ihr.medispan.dib.loaders;

/**
*
*/
public class Mmwparclass extends TableLoader {
    
	/**
	 *
	 */
    public Mmwparclass() {
        super();
    }
    
    @Override
    public String getCreateQuery() {
        return
        "CREATE TABLE mmw_par_class " +
        "( " +
            "classid                     CHARACTER VARYING(5) NOT NULL, " +
            "descdisplay                 CHARACTER VARYING(75) NOT NULL, " +
            "descsearch                  CHARACTER VARYING(75) NOT NULL, " +
            "descphonetic                CHARACTER VARYING(75) NOT NULL, " +
            "crossreactind               SMALLint NOT NULL, " +
            "CONSTRAINT mmw_par_class_pkey PRIMARY KEY (classid) " +
        ") " +
        "WITH (OIDS=TRUE); ";
    }
    
    @Override
    public String getInsertQuery(String line) {
        String[] fields = line.split("\\|");
        
        return "INSERT INTO mmw_par_class VALUES " +
        "( " +
            "'" + fields[0] + "'," +            //classid                     CHARACTER VARYING(5) NOT NULL
            "'" + fields[1] + "'," +            //descdisplay                 CHARACTER VARYING(75) NOT NULL
            "'" + fields[2] + "'," +            //descsearch                  CHARACTER VARYING(75) NOT NULL
            "'" + fields[3] + "'," +            //descphonetic                CHARACTER VARYING(75) NOT NULL
            Integer.parseInt(fields[4]) +       //crossreactind               SMALLint NOT NULL
        " ); ";
    }

}
