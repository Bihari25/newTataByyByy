package com.uhg.ihr.provider.api.exception;

public class MalformedGlobalObjectIdException extends IhrBadRequestException {
    public MalformedGlobalObjectIdException(String message) {
        super(message);
    }
}
