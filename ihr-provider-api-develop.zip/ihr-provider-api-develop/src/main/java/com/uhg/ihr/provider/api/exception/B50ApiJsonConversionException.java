package com.uhg.ihr.provider.api.exception;

public class B50ApiJsonConversionException extends RuntimeException {
    public B50ApiJsonConversionException(String message) {
        super(message);
    }
}
