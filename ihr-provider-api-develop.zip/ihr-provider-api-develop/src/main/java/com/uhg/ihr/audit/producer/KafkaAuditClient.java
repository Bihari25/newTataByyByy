/**
 * Copyright (C) 2020 UnitedHealth Group
 * <p>
 * All rights reserved.
 */
package com.uhg.ihr.audit.producer;

import com.uhg.ihr.audit.Audit;
import io.micronaut.configuration.kafka.annotation.KafkaClient;
import io.micronaut.configuration.kafka.annotation.Topic;
import io.micronaut.context.annotation.Requires;
import io.micronaut.core.util.StringUtils;
import io.reactivex.Flowable;

import javax.inject.Singleton;

/**
 * @author Anurag Singh
 * @version 1.0
 */
@KafkaClient
//@Requires(property = "audit.producer.enabled", value = StringUtils.TRUE)
@Requires(property = "audit.enabled", value = StringUtils.TRUE)
public interface KafkaAuditClient extends AuditClient {

    @Override
    @Topic("${audit.topic}")
    Flowable<Audit> send(Audit audit);

}
