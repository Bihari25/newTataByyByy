package com.uhg.ihr.medispan.dib.loaders;

/**
*
*/
public class Mmwiptdesctext extends TableLoader {
    
	/**
	 *
	 */
    public Mmwiptdesctext() {
        super();
    }
    
    @Override
    public String getCreateQuery() {
        return
        "CREATE TABLE mmw_ipt_desctext " +
        "( " +
            "textid                      INTEGER NOT NULL, " +
            "linenumber                  SMALLINT NOT NULL, " +
            "linetext                    CHARACTER VARYING(70) NOT NULL, " +
            "CONSTRAINT mmw_ipt_desctext_pkey PRIMARY KEY (textid, linenumber) " +
        ") " +
        "WITH (OIDS=TRUE); ";
    }
    
    @Override
    public String getInsertQuery(String line) {
        String[] fields = line.split("\\|");
        
        return "INSERT INTO mmw_ipt_desctext VALUES " +
        "( " +
            Integer.parseInt(fields[0]) + "," +     //textid            INTEGER NOT NULL
            Integer.parseInt(fields[1]) + "," +     //linenumber        SMALLINT NOT NULL
            "'" + fields[2] + "'" +                 //linetext          CHARACTER VARYING(70) NOT NULL
        " ); ";
    }

}
