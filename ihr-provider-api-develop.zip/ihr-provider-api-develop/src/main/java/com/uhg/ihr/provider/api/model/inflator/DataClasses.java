package com.uhg.ihr.provider.api.model.inflator;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import org.apache.commons.lang3.builder.ToStringBuilder;

import java.io.Serializable;
import java.util.List;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
        "adverseReactions",
        "careGivers",
        "careTeam",
        "conditions",
        "healthDevices",
        "healthStatuses",
        "medications",
        "healthObservations",
        "procedureHistory",
        "serviceProviders",
        "visitHistory",
        "immunizations"
})
@JsonIgnoreProperties(ignoreUnknown = true)
public class DataClasses implements Serializable {

    @JsonProperty("adverseReactions")
    private List<AdverseReaction> adverseReactions = null;
    @JsonProperty("careGivers")
    private List<CareGiver> careGivers = null;
    @JsonProperty("careTeam")
    private List<CareTeam> careTeam = null;
    @JsonProperty("conditions")
    private List<Condition> conditions = null;
    @JsonProperty("healthDevices")
    private List<HealthDevice> healthDevices = null;
    @JsonProperty("healthStatuses")
    private List<HealthStatus> healthStatuses = null;
    @JsonProperty("medications")
    private List<Medication> medications = null;
    @JsonProperty("healthObservations")
    private List<HealthObservation> healthObservations = null;
    @JsonProperty("procedureHistory")
    private List<ProcedureHistory> procedureHistory = null;
    @JsonProperty("serviceProviders")
    private List<ServiceProvider> serviceProviders = null;
    @JsonProperty("visitHistory")
    private List<VisitHistory> visitHistory = null;
    @JsonProperty("immunizations")
    private List<Object> immunizations = null;

    @JsonProperty("adverseReactions")
    public List<AdverseReaction> getAdverseReactions() {
        return adverseReactions;
    }

    @JsonProperty("adverseReactions")
    public void setAdverseReactions(List<AdverseReaction> adverseReactions) {
        this.adverseReactions = adverseReactions;
    }

    @JsonProperty("careGivers")
    public List<CareGiver> getCareGivers() {
        return careGivers;
    }

    @JsonProperty("careGivers")
    public void setCareGivers(List<CareGiver> careGivers) {
        this.careGivers = careGivers;
    }

    @JsonProperty("careTeam")
    public List<CareTeam> getCareTeam() {
        return careTeam;
    }

    @JsonProperty("careTeam")
    public void setCareTeam(List<CareTeam> careTeam) {
        this.careTeam = careTeam;
    }

    @JsonProperty("conditions")
    public List<Condition> getConditions() {
        return conditions;
    }

    @JsonProperty("conditions")
    public void setConditions(List<Condition> conditions) {
        this.conditions = conditions;
    }

    @JsonProperty("healthDevices")
    public List<HealthDevice> getHealthDevices() {
        return healthDevices;
    }

    @JsonProperty("healthDevices")
    public void setHealthDevices(List<HealthDevice> healthDevices) {
        this.healthDevices = healthDevices;
    }

    @JsonProperty("healthStatuses")
    public List<HealthStatus> getHealthStatuses() {
        return healthStatuses;
    }

    @JsonProperty("healthStatuses")
    public void setHealthStatuses(List<HealthStatus> healthStatuses) {
        this.healthStatuses = healthStatuses;
    }

    @JsonProperty("medications")
    public List<Medication> getMedications() {
        return medications;
    }

    @JsonProperty("medications")
    public void setMedications(List<Medication> medications) {
        this.medications = medications;
    }

    @JsonProperty("healthObservations")
    public List<HealthObservation> getHealthObservations() {
        return healthObservations;
    }

    @JsonProperty("healthObservations")
    public void setHealthObservations(List<HealthObservation> healthObservations) {
        this.healthObservations = healthObservations;
    }

    @JsonProperty("procedureHistory")
    public List<ProcedureHistory> getProcedureHistory() {
        return procedureHistory;
    }

    @JsonProperty("procedureHistory")
    public void setProcedureHistory(List<ProcedureHistory> procedureHistory) {
        this.procedureHistory = procedureHistory;
    }

    @JsonProperty("serviceProviders")
    public List<ServiceProvider> getServiceProviders() {
        return serviceProviders;
    }

    @JsonProperty("serviceProviders")
    public void setServiceProviders(List<ServiceProvider> serviceProviders) {
        this.serviceProviders = serviceProviders;
    }

    @JsonProperty("visitHistory")
    public List<VisitHistory> getVisitHistory() {
        return visitHistory;
    }

    @JsonProperty("visitHistory")
    public void setVisitHistory(List<VisitHistory> visitHistory) {
        this.visitHistory = visitHistory;
    }

    @JsonProperty("immunizations")
    public List<Object> getImmunizations() {
        return immunizations;
    }

    @JsonProperty("immunizations")
    public void setImmunizations(List<Object> immunizations) {
        this.immunizations = immunizations;
    }

    @Override
    public String toString() {
        return new ToStringBuilder(this).append("adverseReactions", adverseReactions).append("careGivers", careGivers).append("careTeam", careTeam).append("conditions", conditions).append("healthDevices", healthDevices).append("healthStatuses", healthStatuses).append("medications", medications).append("healthObservations", healthObservations).append("procedureHistory", procedureHistory).append("serviceProviders", serviceProviders).append("visitHistory", visitHistory).append("immunizations", immunizations).toString();
    }

}