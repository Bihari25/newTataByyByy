package com.uhg.ihr.provider.api.exception;

public class NoUserFoundException extends UnhandledApiException {
    public NoUserFoundException(String message) {
        super(message);
    }
}
