package com.uhg.ihr.provider.api.exception;

public class TooManyBirthDates extends DobException {
    public TooManyBirthDates(String message) {
        super(message);
    }
}
