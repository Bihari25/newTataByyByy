package com.uhg.ihr.provider.api.service.exception;

import com.uhg.ihr.provider.api.exception.UnhandledApiException;

public class ServiceException extends UnhandledApiException {
    /**
     * Initializes the exception with the specified message.
     *
     * @param message The error message associated to the exception.
     */
    public ServiceException(String message) {
        super(message);
    }

    /**
     * Initializes the exception with the specified message and cause.
     *
     * @param message The error message associated to the exception.
     * @param cause Represents the cause of this exception.
     */
    public ServiceException(String message, Throwable cause) {
        super(message, cause);
    }
}