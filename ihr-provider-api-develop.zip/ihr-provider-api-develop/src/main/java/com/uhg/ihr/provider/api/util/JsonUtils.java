package com.uhg.ihr.provider.api.util;

import com.fasterxml.jackson.databind.JsonNode;

import javax.annotation.Nullable;

public class JsonUtils {

    public static boolean validateJsonNode(JsonNode node) {
        return node != null;
    }

    @Nullable
    public static String getJsonNodeText(JsonNode node) {
        String tmp = null;
        if (node != null) {
            tmp = node.asText();
        }

        return tmp;
    }
}
