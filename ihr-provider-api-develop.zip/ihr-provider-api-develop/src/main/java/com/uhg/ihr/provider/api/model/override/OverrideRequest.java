/**
 * Copyright (C) 2020 UnitedHealth Group
 * <p>
 * All rights reserved.
 */
package com.uhg.ihr.provider.api.model.override;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.uhg.ihr.provider.api.model.IhrApiWithActorRequest;
import lombok.*;

import javax.validation.Valid;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;

/**
 * @author Kristopher T Babic
 * @version 1.0
 */
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@EqualsAndHashCode(callSuper = true)
public class OverrideRequest extends IhrApiWithActorRequest {
    @JsonProperty
    @NotBlank(message="A valid, non-empty override reason must be provided.")
    private String reason;
}
