package com.uhg.ihr.provider.api.model.senzing;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import org.apache.commons.lang3.builder.ToStringBuilder;

import java.io.Serializable;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
        "UHCCDB_FAMILY_ID",
        "GPS_CID",
        "SUBSCRIBER_ID",
        "MEDICARE_BENF_ID",
        "UHCINS_MEMBER_ID",
        "SSN_NUMBER",
        "MEDICAID_NUMBER",
        "CDB_CONSUMER_ID",
        "ALT_MEMBER_ID",
        "HICN",
        "CARDHOLDER_ID",
        "Masterindividualid"
})
@JsonIgnoreProperties(ignoreUnknown = true)
public class Identifier implements Serializable {
    @JsonProperty("UHCCDB_FAMILY_ID")
    private String uhccdbFamilyId;
    @JsonProperty("GPS_CID")
    private String gpsCid;
    @JsonProperty("SUBSCRIBER_ID")
    private String subscriberId;
    @JsonProperty("MEDICARE_BENF_ID")
    private String medicareBenfId;
    @JsonProperty("UHCINS_MEMBER_ID")
    private String uhcinsMemberId;
    @JsonProperty("SSN_NUMBER")
    private String ssnNumber;
    @JsonProperty("MEDICAID_NUMBER")
    private String medicaidNumber;
    @JsonProperty("CDB_CONSUMER_ID")
    private String cdbConsumerId;
    @JsonProperty("ALT_MEMBER_ID")
    private String altMemberId;
    @JsonProperty("HICN")
    private String hicn;
    @JsonProperty("CARDHOLDER_ID")
    private String cardHolderId;
    @JsonProperty("Masterindividualid")
    private String Masterindividualid;

    @JsonProperty("UHCCDB_FAMILY_ID")
    public String getUhccdbFamilyId() {
        return uhccdbFamilyId;
    }

    @JsonProperty("UHCCDB_FAMILY_ID")
    public void setUhccdbFamilyId(String uhccdbFamilyId) {
        this.uhccdbFamilyId = uhccdbFamilyId;
    }


    public String getGpsCid() {
        return gpsCid;
    }

    public void setGpsCid(String gpsCid) {
        this.gpsCid = gpsCid;
    }

    public String getSubscriberId() {
        return subscriberId;
    }

    public void setSubscriberId(String subscriberId) {
        this.subscriberId = subscriberId;
    }

    public String getMedicareBenfId() {
        return medicareBenfId;
    }

    public void setMedicareBenfId(String medicareBenfId) {
        this.medicareBenfId = medicareBenfId;
    }

    public String getUhcinsMemberId() {
        return uhcinsMemberId;
    }

    public void setUhcinsMemberId(String uhcinsMemberId) {
        this.uhcinsMemberId = uhcinsMemberId;
    }

    public String getSsnNumber() {
        return ssnNumber;
    }

    public void setSsnNumber(String ssnNumber) {
        this.ssnNumber = ssnNumber;
    }

    public String getMedicaidNumber() {
        return medicaidNumber;
    }

    public void setMedicaidNumber(String medicaidNumber) {
        this.medicaidNumber = medicaidNumber;
    }

    public String getCdbConsumerId() {
        return cdbConsumerId;
    }

    public void setCdbConsumerId(String cdbConsumerId) {
        this.cdbConsumerId = cdbConsumerId;
    }

    public String getAltMemberId() {
        return altMemberId;
    }

    public void setAltMemberId(String altMemberId) {
        this.altMemberId = altMemberId;
    }

    public String getHicn() {
        return hicn;
    }

    public void setHicn(String hicn) {
        this.hicn = hicn;
    }

    public String getCardHolderId() {
        return cardHolderId;
    }

    public void setCardHolderId(String cardHolderId) {
        this.cardHolderId = cardHolderId;
    }

    public String getMasterindividualid() {
        return Masterindividualid;
    }

    public void setMasterindividualid(String masterindividualid) {
        Masterindividualid = masterindividualid;
    }

    @Override
    public String toString() {
        return new ToStringBuilder(this).append("uhccdbFamilyId", uhccdbFamilyId).toString();
    }
}
