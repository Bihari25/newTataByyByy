package com.uhg.ihr.provider.api.util;

import java.util.List;

public class CollectionUtils {
    public static boolean isEmpty(List<?> l) {
        return l!=null && !l.isEmpty();
    }
}
