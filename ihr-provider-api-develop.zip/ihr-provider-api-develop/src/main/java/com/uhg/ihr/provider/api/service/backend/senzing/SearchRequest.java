package com.uhg.ihr.provider.api.service.backend.senzing;

import com.fasterxml.jackson.annotation.JsonAutoDetect;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.google.common.collect.ImmutableMap;
import com.uhg.ihr.provider.api.model.Id;
import com.uhg.ihr.provider.api.service.backend.b50.search.model.Identifier;
import com.uhg.ihr.provider.api.util.AppUtils;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;

import java.io.Serializable;
import java.util.Map;

/**
 * SearchRequest class used as request contract to consume senzing api.
 *
 * @author ihr extract engineering team.
 * @CopyRight (C) All rights reserved to UHG Inc. It's Illegal to reproduce this code.
 */
@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
@JsonAutoDetect(fieldVisibility = JsonAutoDetect.Visibility.ANY)
@JsonInclude(JsonInclude.Include.NON_NULL)
public class SearchRequest implements Serializable {

    @JsonProperty("name_first")
    private String nameFirst;

    @JsonProperty("name_last")
    private String nameLast;

    @JsonProperty("date_of_birth")
    private String dateOfBirth;

    @JsonProperty("hcid")
    private String hcId;

    @JsonProperty("uhcins_member_id")
    private String memberId;

    @JsonProperty("alt_member_id")
    private String altMemberId;

    @JsonProperty("ssn_number")
    private String ssnNumber;

    @JsonProperty("medicare_benf_id")
    private String medicareBenfId;

    @JsonProperty("uhccdb_consumer_id")
    private String uhccdbConsumerId;

    @JsonProperty("subscriber_id")
    private String subscriberId;

    @JsonProperty("subscriber_id_pad")
    private String subscriberIdPad;

    @JsonProperty("uhcsh_consumer_id")
    private String uhcshConsumerId;

    @JsonProperty("uhccdb_family_id")
    private String uhccdbFamilyId;

    @JsonProperty("uhc_gps_cid")
    private String uhcGpsCid;

    @JsonProperty("gender")
    private String gender;

    @JsonProperty("icuememberidentifier")
    private String icue;

    @JsonProperty("GLOBAL_ACTOR_ID")
    private String GLOBAL_ACTOR_ID;

    private String collectionName;

    @Slf4j
    public static class SearchRequestBuilder {
        public SearchRequestBuilder id(Map<Identifier, Id> map) {
            map.forEach((k, v) -> {
                switch (k) {
                    case CARDHOLDER_ID:
                        this.hcId = v.getId();
                        break;
                    case ALT_MEMBER_ID:
                        this.memberId = v.getId();
                        this.altMemberId = v.getId();
                        break;
                    case SSN_NUMBER:
                        this.ssnNumber = v.getId();
                        break;
                    case MEDICARE_BENF_ID:
                        this.medicareBenfId = v.getId();
                        break;
                    case SUBSCRIBER_ID:
                        ImmutableMap<String, String> computedSubscriberIds = computeSubscriberIds(v.getId());
                        this.subscriberId = computedSubscriberIds.get(AppUtils.SUBSCRIBER_ID_KEY);
                        this.subscriberIdPad = computedSubscriberIds.get(AppUtils.SUBSCRIBER_PAD_ID_KEY);
                        break;
                    default:
                        log.warn("idType {} does not match hcId, memberId, SSN, MBI, subscriberId", k);
                }
            });
            return this;
        }

        /**
         * Method to compute and populate subscriber id's based on search id.
         *
         * @param searchId
         * @return ImmutableMap<String, String>
         */
        public ImmutableMap<String, String> computeSubscriberIds(String searchId){
            String subscriberId;
            String subscriberPadId;

            /* Validate is search id value  starting with zero or not. */
            boolean isStartsWithZero = StringUtils.startsWith(searchId, "0");

            /* Compute and populate with subscriber id's based search id is starting with zero or not.*/
            if (isStartsWithZero) {
                subscriberId = StringUtils.stripStart(searchId, "0");
                subscriberPadId = searchId;
            } else {
                String computedSubscriberId = StringUtils.isNotBlank(searchId) ? StringUtils.leftPad(searchId, 11, "0") : searchId;
                subscriberId = searchId;
                subscriberPadId = computedSubscriberId;
            }

            /* Hold the computed subscriber id's results. */
            ImmutableMap<String, String> computedSubscriberIds = ImmutableMap.of(AppUtils.SUBSCRIBER_ID_KEY, subscriberId, AppUtils.SUBSCRIBER_PAD_ID_KEY, subscriberPadId);
            return computedSubscriberIds;
        }
    }
}