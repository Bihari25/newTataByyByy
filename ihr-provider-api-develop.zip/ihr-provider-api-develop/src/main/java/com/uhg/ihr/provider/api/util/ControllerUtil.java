package com.uhg.ihr.provider.api.util;

import com.uhg.ihr.provider.api.logging.LogHelper;
import io.micronaut.http.HttpRequest;
import io.micronaut.http.HttpStatus;
import io.micronaut.http.MutableHttpResponse;
import io.micronaut.http.server.netty.NettyHttpResponseFactory;
import io.reactivex.Maybe;

public class ControllerUtil {

    /**
     * Provides pipeline logging for requests as well as 404 - NOT_FOUND response creation for responses. If a 404 response
     * is desired then ensure the service calling 'buildHttpResponse' sends a Maybe.empty() when desired criteria are met,
     * otherwise a 200 - OK response will be built
     * @param data The resulting data to return to the caller
     * @param request The HttpRequest used to hit the endpoint
     * @param method The distinguishing method of the endpoint used for logging purposes
     * @param <T> The data type
     * @return A Maybe with MutableHttpResponse type
     */
    public static <T> Maybe<MutableHttpResponse<T>> buildHttpResponse(Maybe<T> data, HttpRequest request, String method) {
        return addLoggingPipeline(data, request, method)
                .map(NettyHttpResponseFactory.INSTANCE::ok)
                .defaultIfEmpty(NettyHttpResponseFactory.INSTANCE.status(HttpStatus.NOT_FOUND,"No data found for given request"));
    }

    public static <T> Maybe<MutableHttpResponse<T>> buildHttpResponse(Maybe<T> data, HttpRequest request, String method, HttpStatus status) {
        return addLoggingPipeline(data, request, method)
                .map(body -> NettyHttpResponseFactory.INSTANCE.status(status, body))
                .defaultIfEmpty(NettyHttpResponseFactory.INSTANCE.status(HttpStatus.NOT_FOUND,"No data found for given request"));
    }

    public static <T> Maybe<T> addLoggingPipeline(Maybe<T> maybe, io.micronaut.http.HttpRequest request, String method) {
        return maybe
                .doOnSubscribe(sub -> LogHelper.logStart(request, method))
                .doOnSuccess(pl -> LogHelper.logSuccess(request, method))
                .doOnError(e -> LogHelper.logFail(request, method, e.getMessage()));
    }
}
