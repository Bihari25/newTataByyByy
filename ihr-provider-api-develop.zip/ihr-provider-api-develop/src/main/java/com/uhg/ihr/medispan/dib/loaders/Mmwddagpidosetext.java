package com.uhg.ihr.medispan.dib.loaders;

/**
*
*/
public class Mmwddagpidosetext extends TableLoader {
    
	/**
	 *
	 */
    public Mmwddagpidosetext() {
        super();
    }
    
    @Override
    public String getCreateQuery() {
        return
        "CREATE TABLE mmw_dda_gpi_dose_text " + 
        "( " +
            "doseid              CHARACTER VARYING(10) NOT NULL, " +
            "typecode            CHARACTER VARYING(3)  NOT NULL, " +
            "levelcode           CHARACTER VARYING(2)  NOT NULL, " +
            "sequencenumber      INTEGER NOT NULL, " +
            "textid              INTEGER NOT NULL, " +
            "textgroupid         INTEGER NULL, " +
            "CONSTRAINT mmw_dda_gpi_dose_text_pkey PRIMARY KEY (doseid,typecode,levelcode,sequencenumber) " +
        ") " +
        "WITH (OIDS=TRUE); ";
    }
    
    @Override
    public String getInsertQuery(String line) {
        String[] fields = line.split("\\|");
        
        return "INSERT INTO mmw_dda_gpi_dose_text VALUES " +
        "( " +
            "'" + fields[0] + "'," +                //doseid             CHARACTER VARYING(10) NOT NULL
            "'" + fields[1] + "'," +                //typecode           CHARACTER VARYING(3)  NOT NULL
            "'" + fields[2] + "'," +                //evelcode           CHARACTER VARYING(2)  NOT NULL
            Integer.parseInt(fields[3]) + "," +     //sequencenumber     INTEGER NOT NULL
            Integer.parseInt(fields[4]) + "," +     //textid             INTEGER NOT NULL
            (fields.length < 6 || fields[5].isEmpty() ? "NULL" : Integer.parseInt(fields[5])) +           //textgroupid        INTEGER NULL
        " ); ";
    }

}
