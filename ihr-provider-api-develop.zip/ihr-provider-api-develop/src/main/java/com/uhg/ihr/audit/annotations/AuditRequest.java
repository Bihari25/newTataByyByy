package com.uhg.ihr.audit.annotations;

import com.uhg.ihr.audit.AuditApiInterceptor;
import io.micronaut.aop.Around;
import io.micronaut.context.annotation.Type;

import java.lang.annotation.Inherited;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

import static java.lang.annotation.ElementType.METHOD;

@Target({METHOD})
@Retention(RetentionPolicy.RUNTIME)
@Inherited
@Around
@Type(AuditApiInterceptor.class)
public @interface AuditRequest {
    String auditType() default "";
    String description() default "";
}