package com.uhg.ihr.audit;

public interface AuditConstant {

    interface Details {
        String METHOD = "method";
        String ACTOR_REQUEST_ID = "actorRequestId";
        String ON_BEHALF_OF = "onBehalfOf";
        String RESULT = "result";
        String CORRELATION_ID = "optum-cid-ext";

        String REQUEST_PATH = "requestPath";
        String REQUEST_HOST_NAME = "requestHostName";
        String REQUEST_METHOD = "requestMethod";
        String REQUEST_CONTENT_LENGTH = "requestContentLength";
        String RESPONSE_BODY_LENGTH = "responseBodyLength";

        String ERROR_MESSAGE = "errorMessage";
        String LOG_EVT_START = "logEvtStart";
        String LOG_EVT_END = "logEvtEnd";
        String LOG_EVT_REASON = "LogEvtReason";
        String UNKNOWN_ERROR = "Unknown Error";
        
        String SECURITY_BYPASS = "security-bypass";

    }

}
