package com.uhg.ihr.provider.api.logging;

import lombok.*;

@Getter
@Setter
@NoArgsConstructor
public class LogRecord {
    private String actor = null;
    private String actorIp = null;
    private String component = null;
    private String correlationId = null;
    private String details = null;
    private String operation = null;
    private String sourceId = null;
    private String method = null;
    private String responseCode = null;
    private String responseStatus = null;
}
