package com.uhg.ihr.provider.api.service.backend.senzing;

import com.uhg.ihr.provider.api.model.senzing.Response;
import io.micronaut.http.annotation.Body;
import io.micronaut.http.annotation.Header;
import io.micronaut.http.annotation.Post;
import io.micronaut.http.client.annotation.Client;
import io.micronaut.retry.annotation.CircuitBreaker;
import io.micronaut.retry.annotation.Retryable;
import io.reactivex.Maybe;

import javax.validation.constraints.NotNull;

@Client("senzing")
//@CircuitBreaker
//@Retryable
public interface SenzingClient {
    @Post("/entities/")
    @Header(name = "Content-Type", value = "application/json")
    Maybe<Response> fetchEntities(final @Header("Authorization") String token, final @Header("X-Correlation-ID") String correlationId, final @Body @NotNull SearchRequest searchRequest);
}