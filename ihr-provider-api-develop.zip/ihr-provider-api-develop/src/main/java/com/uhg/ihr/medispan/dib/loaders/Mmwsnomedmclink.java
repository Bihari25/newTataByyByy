package com.uhg.ihr.medispan.dib.loaders;

/**
*
*/
public class Mmwsnomedmclink extends TableLoader {
    
	/**
	 *
	 */
    public Mmwsnomedmclink() {
        super();
    }
    
    @Override
    public String getCreateQuery() {
        return
        "CREATE TABLE mmw_snomed_mc_link " +
        "( " +
            "mcid                        INTEGER NOT NULL, " +
            "snomedid                    CHARACTER VARYING(18) NOT NULL, " +
            "relationtype                SMALLint NOT NULL, " +
            "CONSTRAINT mmw_snomed_mc_link_pkey PRIMARY KEY (mcid, snomedid, relationtype) " +
        ") " +
        "WITH (OIDS=TRUE); ";
    }
    
    @Override
    public String getInsertQuery(String line) {
        String[] fields = line.split("\\|");
        
        return "INSERT INTO mmw_snomed_mc_link VALUES " +
        "( " +
            "'" + fields[0] + "'," +            //mcid              INTEGER NOT NULL
            "'" + fields[1] + "'," +            //snomedid          CHARACTER VARYING(18) NOT NULL
            Integer.parseInt(fields[2]) +       //relationtype      SMALLint NOT NULL
        " ); ";
    }

}
