package com.uhg.ihr.provider.api.model.senzing;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import org.apache.commons.lang3.builder.ToStringBuilder;

import java.io.Serializable;
import java.util.List;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
        "dataSource",
        "recordId",
        "addressData",
        "attributeData",
        "identifierData",
        "nameData",
        "phoneData",
        "relationshipData",
        "otherData",
        "originalSourceData"
})
@JsonIgnoreProperties(ignoreUnknown = true)
public class Record implements Serializable {

    @JsonProperty("dataSource")
    private String dataSource;
    @JsonProperty("recordId")
    private String recordId;
    @JsonProperty("addressData")
    private List<String> addressData = null;
    @JsonProperty("attributeData")
    private List<String> attributeData = null;
    @JsonProperty("identifierData")
    private List<String> identifierData = null;
    @JsonProperty("nameData")
    private List<String> nameData = null;
    @JsonProperty("phoneData")
    private List<String> phoneData = null;
    @JsonProperty("relationshipData")
    private List<Object> relationshipData = null;
    @JsonProperty("otherData")
    private List<String> otherData = null;
    @JsonProperty("originalSourceData")
    private OriginalSourceData originalSourceData;

    @JsonProperty("dataSource")
    public String getDataSource() {
        return dataSource;
    }

    @JsonProperty("dataSource")
    public void setDataSource(String dataSource) {
        this.dataSource = dataSource;
    }

    @JsonProperty("recordId")
    public String getRecordId() {
        return recordId;
    }

    @JsonProperty("recordId")
    public void setRecordId(String recordId) {
        this.recordId = recordId;
    }

    @JsonProperty("addressData")
    public List<String> getAddressData() {
        return addressData;
    }

    @JsonProperty("addressData")
    public void setAddressData(List<String> addressData) {
        this.addressData = addressData;
    }

    @JsonProperty("attributeData")
    public List<String> getAttributeData() {
        return attributeData;
    }

    @JsonProperty("attributeData")
    public void setAttributeData(List<String> attributeData) {
        this.attributeData = attributeData;
    }

    @JsonProperty("identifierData")
    public List<String> getIdentifierData() {
        return identifierData;
    }

    @JsonProperty("identifierData")
    public void setIdentifierData(List<String> identifierData) {
        this.identifierData = identifierData;
    }

    @JsonProperty("nameData")
    public List<String> getNameData() {
        return nameData;
    }

    @JsonProperty("nameData")
    public void setNameData(List<String> nameData) {
        this.nameData = nameData;
    }

    @JsonProperty("phoneData")
    public List<String> getPhoneData() {
        return phoneData;
    }

    @JsonProperty("phoneData")
    public void setPhoneData(List<String> phoneData) {
        this.phoneData = phoneData;
    }

    @JsonProperty("relationshipData")
    public List<Object> getRelationshipData() {
        return relationshipData;
    }

    @JsonProperty("relationshipData")
    public void setRelationshipData(List<Object> relationshipData) {
        this.relationshipData = relationshipData;
    }

    @JsonProperty("otherData")
    public List<String> getOtherData() {
        return otherData;
    }

    @JsonProperty("otherData")
    public void setOtherData(List<String> otherData) {
        this.otherData = otherData;
    }

    @JsonProperty("originalSourceData")
    public OriginalSourceData getOriginalSourceData() {
        return originalSourceData;
    }

    @JsonProperty("originalSourceData")
    public void setOriginalSourceData(OriginalSourceData originalSourceData) {
        this.originalSourceData = originalSourceData;
    }

    @Override
    public String toString() {
        return new ToStringBuilder(this).append("dataSource", dataSource).append("recordId", recordId).append("addressData", addressData).append("attributeData", attributeData).append("identifierData", identifierData).append("nameData", nameData).append("phoneData", phoneData).append("relationshipData", relationshipData).append("otherData", otherData).append("originalSourceData", originalSourceData).toString();
    }
}