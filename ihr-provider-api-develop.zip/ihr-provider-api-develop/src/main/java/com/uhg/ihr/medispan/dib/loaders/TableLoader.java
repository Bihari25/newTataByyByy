package com.uhg.ihr.medispan.dib.loaders;

//import jdk.nashorn.internal.ir.annotations.Ignore;

import java.io.File;
import java.io.FileReader;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.Scanner;

//import java.io.IOException;

/**
*
*/
public abstract class TableLoader {

    protected TableLoader() {
        super();
    }

    /**
     * @param conn dib db connection
     * @param fileName file name
     */
    public void  load(Connection conn, String fileName){
        File file = new File(fileName);
        if (file != null) {
            String line = "";
            try {
                FileReader fileReader = null;//new FileReader(file);
                Scanner scanner = new Scanner(fileReader);
                try {
	                int count = 0;
	                while (scanner.hasNextLine() ) {
	                    count++;
	                    line = scanner.nextLine();
	                    String insertRow = getInsertQuery(line);
	                    if (count % 1000 == 0) {
	                        System.out.println(fileName + " row #" + count);
	                    }
	           
	                    try {
	                    	 PreparedStatement stmt  =  conn.prepareStatement(insertRow);
	                    if (stmt != null) {
		                    try {       
		                        boolean failed = stmt.execute(insertRow);
		                        if (failed ){
		                            System.out.println("ROW NOT INSERTED: " + insertRow);
		                        }
		                    } catch (SQLException e) {
		
		                        System.out.println("Error " + e.getMessage() + " " + insertRow);
		                    }
		
		                    try {
		                        stmt.close();
		                    } catch (SQLException e) {
		                        System.out.println("Error stmt.close()" + e.getMessage());
		                    }
	                    }
	                
                } 
	                    catch (SQLException e) {
	                    	
	                    }
	                    finally {
	                scanner.close();
                }
	                }
                }
                catch (Exception e) {
                	
                }
            }
        
//            catch (IOException ex){
            catch (Exception ex) {
                System.err.println(ex.getMessage());
                System.out.println(line);
            }

    }
    }
    
    protected abstract String getInsertQuery(String insertQuery);
    
    protected abstract String getCreateQuery();
    
    
    
    
    
/*    
    String insertRow = 
        "INSERT INTO mmw_drug_name values ( " +  
        Integer.parseInt(fields[0]) + "," +          //pnid integer NOT NULL,
        "'" + fields[1] + "'," +         //descdisplay character varying,
        "'" + fields[2] + "'," +         //descsearch character varying,
        "'" + fields[3] + "'," +         //descphonetic character varying,
        "'" + fields[4] + "'," +         //rpidunique character varying,
        "'" + fields[5] + "'," +         //ddidunique character varying,
        "'" + fields[6] + "'," +         //nametypecode character varying,
        "'" + fields[7] + "'," +         //rxotccode character varying,
        "'" + fields[8] + "'," +         //singleingrind character varying,
        "'" + fields[9] + "'," +         //meddevind character varying,
        "'" + fields[10] + "'," +         //haspackdrugind character varying,
        "'" + fields[10] + "'," +         //haseqvpackdrugind character varying,
        "'" + fields[12] + "');";          //haskdcind character varying,
*/
    
}
