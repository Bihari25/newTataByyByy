package com.uhg.ihr.provider.api.model.inflator;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import org.apache.commons.lang3.builder.ToStringBuilder;

import java.io.Serializable;
import java.util.List;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
        "recordType",
        "allergens",
        "adversereactiontype",
        "dataSource",
        "lastUpdateDate",
        "objectId",
        "onsetDate",
        "startDate",
        "presenceStateTerm",
        "reactions",
        "sensitivityClasses",
        "status",
        "clinicallyRelevantDate"
})
@JsonIgnoreProperties(ignoreUnknown = true)
public class AdverseReaction implements Serializable {

    @JsonProperty("recordType")
    private String recordType;
    @JsonProperty("allergens")
    private List<Allergen> allergens = null;
    @JsonProperty("adversereactiontype")
    private Adversereactiontype adversereactiontype;
    @JsonProperty("dataSource")
    private List<String> dataSource = null;
    @JsonProperty("lastUpdateDate")
    private String lastUpdateDate;
    @JsonProperty("objectId")
    private long objectId;
    @JsonProperty("onsetDate")
    private Object onsetDate;
    @JsonProperty("startDate")
    private String startDate;
    @JsonProperty("presenceStateTerm")
    private String presenceStateTerm;
    @JsonProperty("reactions")
    private List<Object> reactions = null;
    @JsonProperty("sensitivityClasses")
    private List<Object> sensitivityClasses = null;
    @JsonProperty("status")
    private Status status;
    @JsonProperty("clinicallyRelevantDate")
    private String clinicallyRelevantDate;

    @JsonProperty("recordType")
    public String getRecordType() {
        return recordType;
    }

    @JsonProperty("recordType")
    public void setRecordType(String recordType) {
        this.recordType = recordType;
    }

    @JsonProperty("allergens")
    public List<Allergen> getAllergens() {
        return allergens;
    }

    @JsonProperty("allergens")
    public void setAllergens(List<Allergen> allergens) {
        this.allergens = allergens;
    }

    @JsonProperty("adversereactiontype")
    public Adversereactiontype getAdversereactiontype() {
        return adversereactiontype;
    }

    @JsonProperty("adversereactiontype")
    public void setAdversereactiontype(Adversereactiontype adversereactiontype) {
        this.adversereactiontype = adversereactiontype;
    }

    @JsonProperty("dataSource")
    public List<String> getDataSource() {
        return dataSource;
    }

    @JsonProperty("dataSource")
    public void setDataSource(List<String> dataSource) {
        this.dataSource = dataSource;
    }

    @JsonProperty("lastUpdateDate")
    public String getLastUpdateDate() {
        return lastUpdateDate;
    }

    @JsonProperty("lastUpdateDate")
    public void setLastUpdateDate(String lastUpdateDate) {
        this.lastUpdateDate = lastUpdateDate;
    }

    @JsonProperty("objectId")
    public long getObjectId() {
        return objectId;
    }

    @JsonProperty("objectId")
    public void setObjectId(long objectId) {
        this.objectId = objectId;
    }

    @JsonProperty("onsetDate")
    public Object getOnsetDate() {
        return onsetDate;
    }

    @JsonProperty("onsetDate")
    public void setOnsetDate(Object onsetDate) {
        this.onsetDate = onsetDate;
    }

    @JsonProperty("startDate")
    public String getStartDate() {
        return startDate;
    }

    @JsonProperty("startDate")
    public void setStartDate(String startDate) {
        this.startDate = startDate;
    }

    @JsonProperty("presenceStateTerm")
    public String getPresenceStateTerm() {
        return presenceStateTerm;
    }

    @JsonProperty("presenceStateTerm")
    public void setPresenceStateTerm(String presenceStateTerm) {
        this.presenceStateTerm = presenceStateTerm;
    }

    @JsonProperty("reactions")
    public List<Object> getReactions() {
        return reactions;
    }

    @JsonProperty("reactions")
    public void setReactions(List<Object> reactions) {
        this.reactions = reactions;
    }

    @JsonProperty("sensitivityClasses")
    public List<Object> getSensitivityClasses() {
        return sensitivityClasses;
    }

    @JsonProperty("sensitivityClasses")
    public void setSensitivityClasses(List<Object> sensitivityClasses) {
        this.sensitivityClasses = sensitivityClasses;
    }

    @JsonProperty("status")
    public Status getStatus() {
        return status;
    }

    @JsonProperty("status")
    public void setStatus(Status status) {
        this.status = status;
    }

    @JsonProperty("clinicallyRelevantDate")
    public String getClinicallyRelevantDate() {
        return clinicallyRelevantDate;
    }

    @JsonProperty("clinicallyRelevantDate")
    public void setClinicallyRelevantDate(String clinicallyRelevantDate) {
        this.clinicallyRelevantDate = clinicallyRelevantDate;
    }

    @Override
    public String toString() {
        return new ToStringBuilder(this).append("recordType", recordType).append("allergens", allergens).append("adversereactiontype", adversereactiontype).append("dataSource", dataSource).append("lastUpdateDate", lastUpdateDate).append("objectId", objectId).append("onsetDate", onsetDate).append("startDate", startDate).append("presenceStateTerm", presenceStateTerm).append("reactions", reactions).append("sensitivityClasses", sensitivityClasses).append("status", status).append("clinicallyRelevantDate", clinicallyRelevantDate).toString();
    }
}