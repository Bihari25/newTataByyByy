/**
 * Copyright (C) 2020 UnitedHealth Group
 * <p>
 * All rights reserved.
 */
package com.uhg.ihr.audit.producer;

import com.uhg.ihr.audit.Audit;
import io.micronaut.context.annotation.Requires;
import io.micronaut.core.util.StringUtils;
import io.reactivex.Flowable;
import lombok.extern.slf4j.Slf4j;

import javax.inject.Singleton;

/**
 * @author Kristopher T Babic
 * @version 1.0
 */
@Slf4j
@Singleton
@Requires(property = "audit.enabled", value = StringUtils.FALSE)
public class LoggingAuditClient implements AuditClient {

    @Override
    public Flowable<Audit> send(final Audit audit) {
        if (log.isInfoEnabled()) {
            log.info(audit.toString());
        }
        return Flowable.just(audit);
    }
}
