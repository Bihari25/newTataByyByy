/**
 * Copyright (C) 2020 UnitedHealth Group
 * <p>
 * All rights reserved.
 */
package com.uhg.ihr.provider.api.model.profile;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

/**
 * @author Kristopher T Babic
 * @version 1.0
 */
@Data
@Builder(toBuilder = true)
@AllArgsConstructor
@NoArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(JsonInclude.Include.NON_NULL)
public class AgreementAcceptance {
    private UserProfileConstant.AgreementType type;
    private String acceptanceDate;
    private String version;
}
