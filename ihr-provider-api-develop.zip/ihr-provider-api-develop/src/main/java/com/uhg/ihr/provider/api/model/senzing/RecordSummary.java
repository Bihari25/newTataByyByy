package com.uhg.ihr.provider.api.model.senzing;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import org.apache.commons.lang3.builder.ToStringBuilder;

import java.io.Serializable;
import java.util.List;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
        "dataSource",
        "recordCount",
        "topRecordIds"
})
public class RecordSummary implements Serializable {

    @JsonProperty("dataSource")
    private String dataSource;
    @JsonProperty("recordCount")
    private long recordCount;
    @JsonProperty("topRecordIds")
    private List<String> topRecordIds = null;

    @JsonProperty("dataSource")
    public String getDataSource() {
        return dataSource;
    }

    @JsonProperty("dataSource")
    public void setDataSource(String dataSource) {
        this.dataSource = dataSource;
    }

    @JsonProperty("recordCount")
    public long getRecordCount() {
        return recordCount;
    }

    @JsonProperty("recordCount")
    public void setRecordCount(long recordCount) {
        this.recordCount = recordCount;
    }

    @JsonProperty("topRecordIds")
    public List<String> getTopRecordIds() {
        return topRecordIds;
    }

    @JsonProperty("topRecordIds")
    public void setTopRecordIds(List<String> topRecordIds) {
        this.topRecordIds = topRecordIds;
    }

    @Override
    public String toString() {
        return new ToStringBuilder(this).append("dataSource", dataSource).append("recordCount", recordCount).append("topRecordIds", topRecordIds).toString();
    }

}