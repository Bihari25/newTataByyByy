package com.uhg.ihr.provider.api.validator;

import javax.validation.Constraint;
import java.lang.annotation.Retention;
import java.lang.annotation.Target;

import static java.lang.annotation.ElementType.FIELD;
import static java.lang.annotation.ElementType.PARAMETER;
import static java.lang.annotation.RetentionPolicy.RUNTIME;

@Target({FIELD, PARAMETER})
@Retention(RUNTIME)
@Constraint(validatedBy = ValidUserProfileRegisterValidator.class)
public @interface ValidUserProfileRegister {
    String message() default "Invalid user profile register request";

    Class<?>[] groups() default {};

    Class<? extends String>[] payload() default {};

    boolean optional() default false;
}
