package com.uhg.ihr.medispan.dib.loaders;

/**
*
*/
public class Mmwdfaint extends TableLoader {
    
	/**
	 *
	 */
    public Mmwdfaint() {
        super();
    }
    
    @Override
    public String getCreateQuery() {
        return
        "CREATE TABLE mmw_dfa_int " +
        "( " +
            "drugclassid                 CHARACTER VARYING(5) NOT NULL, " +
            "foodclassid                 CHARACTER VARYING(5) NOT NULL, " +
            "drugactcode                 CHARACTER VARYING(1) NOT NULL, " +
            "drugduration                SMALLINT NOT NULL, " +
            "foodduration                SMALLINT NOT NULL, " +
            "drugschregind               SMALLINT NOT NULL, " +
            "drugschasneedind            SMALLINT NOT NULL, " +
            "drugschsingleind            SMALLINT NOT NULL, " +
            "foodschregind               SMALLINT NOT NULL, " +
            "foodschasneedind            SMALLINT NOT NULL, " +
            "foodschsingleind            SMALLINT NOT NULL, " +
            "onsetcode                   CHARACTER VARYING(1) NOT NULL, " +
            "severitycode                CHARACTER VARYING(1) NOT NULL, " +
            "doclevelcode                CHARACTER VARYING(1) NOT NULL, " +
            "drugclassname               CHARACTER VARYING(75) NOT NULL, " +
            "foodclassname               CHARACTER VARYING(75) NOT NULL, " +
            "monoid                      CHARACTER VARYING(20) NOT NULL, " +
            "alcoholind                  SMALLINT NOT NULL, " +
            "class1foodind               SMALLINT NOT NULL, " +
            "mgmtcode                    CHARACTER VARYING(1) NOT NULL, " +
            "CONSTRAINT mmw_dfa_int_pkey PRIMARY KEY (drugclassid, foodclassid) " +
        ") " +
        "WITH (OIDS=TRUE); ";
    }
    
    @Override
    public String getInsertQuery(String line) {
        String[] fields = line.split("\\|");
        
        return "INSERT INTO mmw_dfa_int VALUES " +
        "( " +
            "'" + fields[0] + "'," +                //drugclassid                 CHARACTER VARYING(5) NOT NULL
            "'" + fields[1] + "'," +                //foodclassid                 CHARACTER VARYING(5) NOT NULL
            "'" + fields[2] + "'," +                //drugactcode                 CHARACTER VARYING(1) NOT NULL
            Integer.parseInt(fields[3]) + "," +     //drugduration                SMALLINT NOT NULL
            Integer.parseInt(fields[4]) + "," +     //foodduration                SMALLINT NOT NULL
            Integer.parseInt(fields[5]) + "," +     //drugschregind               SMALLINT NOT NULL
            Integer.parseInt(fields[6]) + "," +     //drugschasneedind            SMALLINT NOT NULL
            Integer.parseInt(fields[7]) + "," +     //drugschsingleind            SMALLINT NOT NULL
            Integer.parseInt(fields[8]) + "," +     //foodschregind               SMALLINT NOT NULL
            Integer.parseInt(fields[9]) + "," +     //foodschasneedind            SMALLINT NOT NULL
            Integer.parseInt(fields[10]) + "," +    //foodschsingleind            SMALLINT NOT NULL
            "'" + fields[11] + "'," +               //onsetcode                   CHARACTER VARYING(1) NOT NULL
            "'" + fields[12] + "'," +               //severitycode                CHARACTER VARYING(1) NOT NULL
            "'" + fields[13] + "'," +               //doclevelcode                CHARACTER VARYING(1) NOT NULL
            "'" + fields[14] + "'," +               //drugclassname               CHARACTER VARYING(75) NOT NULL
            "'" + fields[15] + "'," +               //foodclassname               CHARACTER VARYING(75) NOT NULL
            "'" + fields[16] + "'," +               //monoid                      CHARACTER VARYING(20) NOT NULL
            Integer.parseInt(fields[17]) + "," +    //alcoholind                  SMALLINT NOT NULL
            Integer.parseInt(fields[18]) + "," +    //class1foodind               SMALLINT NOT NULL
            "'" + fields[19] + "'" +                //mgmtcode                    CHARACTER VARYING(1) NOT NULL
        " ); ";
    }

}
