/**
 * Copyright (C) 2020 UnitedHealth Group
 * <p>
 * All rights reserved.
 */
package com.uhg.ihr.audit.factory;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.nimbusds.jose.util.ArrayUtils;
import com.optum.eis.util.IpAddressUtil;
import com.optum.eis.validators.HostNameValidator;
import com.uhg.ihr.audit.Audit;
import com.uhg.ihr.audit.AuditConstant;
import com.uhg.ihr.audit.util.JsonNodeUtil;
import io.micronaut.context.annotation.Property;
import io.micronaut.http.HttpHeaders;
import io.micronaut.http.HttpRequest;
import lombok.extern.slf4j.Slf4j;

import javax.annotation.PostConstruct;
import javax.inject.Singleton;
import java.lang.management.ManagementFactory;
import java.net.InetAddress;
import java.net.UnknownHostException;
import java.time.Instant;
import java.util.*;

/**
 * @author Kristopher T Babic
 * @version 1.0
 */
@Singleton
@Slf4j
public class AuditFactory {
    private static final ObjectMapper MAPPER = new ObjectMapper();
    public static final String DEFAULT_AUDIT_TYPE = "ihr_provider_api";
    private static final String TOTAL = "total";

    @Property(name = "audit.factory.env")
    private Set<String> TRACKABLE_ENVS;
    @Property(name = "audit.factory.system")
    private Set<String> TRACKABLE_SYSTEM;
    @Property(name = "audit.factory.app")
    private Map<String, String> APP_CONFIG;
    @Property(name = "audit.factory.headers")
    private Set<String> TRACKABLE_HEADERS;

    private Map<String, Object> serverTemplate = null;
    private Map<String, Object> appTemplate = null;

    /*
Sample "server" component:
{
  "process": {
    "name": "2718@LAMU02YX4C2LVDR.uhc.com.",
    "pid": "2718"
  },
  "system": {
    "java.vendor": "AdoptOpenJDK",
    "java.version": "11.0.4",
    "user.name": "kbabic",
    "os.name": "Mac OS X",
    "java.vendor.version": "AdoptOpenJDK",
    "os.version": "10.14.6"
  },
  "env": {
    "ENVIRONMENT": "dev"
  },
  "device": {
    "hostname": "LAMU02YX4C2LVDR.uhc.com.",
    "ip": "10.94.148.252",
    "ip4": 173970684
  }
}

Sample "app" component:
{
  "product": "IHR Provider API",
  "app-id": "UHGWM110-026046",
  "vendor": "UnitedHealth Group",
  "name": "IHR-B50-Provider-API",
  "version": "v1.0"
}
     */
    @PostConstruct
    protected void initialize() {
        final Map<String, Object> appTemplate = new HashMap<>();
        if (APP_CONFIG != null) {
            APP_CONFIG.forEach((s, s2) -> {
                if (s != null && s2 != null && !s.isBlank() && !s2.isBlank()) {
                    appTemplate.put(s, s2);
                }
            });
        }
        if (!appTemplate.isEmpty()) {
            this.appTemplate = Collections.unmodifiableMap(appTemplate);
        }

        Map<String, Object> serverTemplate = new HashMap<>();

        final Map<String, Object> envTemplate = new HashMap<>();
        if (TRACKABLE_ENVS != null) {
            TRACKABLE_ENVS.forEach(env -> {
                String val = System.getenv(env);
                if (val != null && !val.isBlank()) {
                    envTemplate.put(env, val);
                }
            });
        }
        if (!envTemplate.isEmpty()) {
            serverTemplate.put("env", Collections.unmodifiableMap(envTemplate));
        }

        final Map<String, Object> systemTemplate = new HashMap<>();
        if (TRACKABLE_SYSTEM != null) {
            TRACKABLE_SYSTEM.forEach(system -> {
                String val = System.getProperty(system);
                if (val != null && !val.isBlank()) {
                    // BSON doesn't like periods in keys (even though supported by MongoDB
                    systemTemplate.put(system.replaceAll("\\.", "_"), val);
                }
            });
        }
        if (!systemTemplate.isEmpty()) {
            serverTemplate.put("system", Collections.unmodifiableMap(systemTemplate));
        }

        Map<String, Object> deviceTemplate = new HashMap<>();
        try {
            InetAddress inetAddress = InetAddress.getLocalHost();
            String hostname = inetAddress.getHostName();

            if (!HostNameValidator.isValidHostName(hostname)) {
                throw new UnknownHostException("Hostname is not valid.");
            }
            deviceTemplate.put("hostname", hostname);

            String ip = inetAddress.getHostAddress();
            Long ip4 = IpAddressUtil.convert(ip);

            deviceTemplate.put("ip", ip);
            deviceTemplate.put("ip4", ip4);
        }
        catch (UnknownHostException e) {
            log.error("Unable to load host information");
        }
        if (!deviceTemplate.isEmpty()) {
            serverTemplate.put("device", Collections.unmodifiableMap(deviceTemplate));
        }

        Map<String, Object> processTemplate = new HashMap<>();
        String processName = ManagementFactory.getRuntimeMXBean().getName();
        if (processName != null && !processName.isBlank()) {
            try {
                processTemplate.put("name", processName);
                processTemplate.put("pid", processName.split("@")[0]);
            }
            catch (Exception ex) {
                // ignore as not required info
                log.error("Unabled to load process information");
            }
        }
        if (!processTemplate.isEmpty()) {
            serverTemplate.put("process", Collections.unmodifiableMap(processTemplate));
        }

        if (!serverTemplate.isEmpty()) {
            this.serverTemplate = Collections.unmodifiableMap(serverTemplate);
        }

        if (TRACKABLE_HEADERS != null && TRACKABLE_HEADERS.isEmpty()) {
            TRACKABLE_HEADERS = null;
        }
    }

    public Audit createAudit(String... auditType) {
        return createAudit(null, auditType);
    }

    public Audit createAudit(HttpRequest request, String... auditType) {
        Audit audit = new Audit();

        if (auditType != null) {
            audit.setType(Arrays.stream(auditType).filter(Objects::nonNull).toArray(String[]::new));
        }
        audit.setType(auditType);

        return prefillAudit(request, audit);
    }

    public Audit prefillAudit(Audit audit) {
        return prefillAudit(null, audit);
    }

    public Audit prefillAudit(HttpRequest request, Audit audit) {
        if (audit.getDate() == null) {
            audit.setDate(new Date());
        }

        String[] types = audit.getType();
        if (types == null) {
            audit.setType(new String[]{ DEFAULT_AUDIT_TYPE } );
        }
        else {
            if (Arrays.stream(types).noneMatch(DEFAULT_AUDIT_TYPE::equals)) {
                String[] api = new String[]{DEFAULT_AUDIT_TYPE};
                audit.setType(ArrayUtils.concat(audit.getType(), api));
            }
        }

        Map<String, Object> requestMap = null;
        if (request != null) {
            requestMap = new HashMap<>();

            requestMap.put(AuditConstant.Details.REQUEST_PATH, request.getPath());
            requestMap.put(AuditConstant.Details.REQUEST_HOST_NAME, request.getRemoteAddress().getHostName());
            requestMap.put(AuditConstant.Details.REQUEST_METHOD, request.getMethod().name());
            requestMap.put(AuditConstant.Details.REQUEST_CONTENT_LENGTH, request.getContentLength());
            Map logMap = request.getAttribute("logMap", Map.class).orElse(null);
            if (logMap != null) {
                String timeKey = TOTAL + "_start";
                if (logMap.containsKey(timeKey)) {
                    requestMap.put(AuditConstant.Details.LOG_EVT_START, ((Instant) logMap.get(timeKey)).toEpochMilli());
                }

                if (logMap.get("error") != null) {
                    requestMap.put(AuditConstant.Details.ERROR_MESSAGE, logMap.get("error"));
                }
            }
            HttpHeaders headers = request.getHeaders();

            // not an ideal check - needs to be enhanced.
            if (!headers.contains("X-Consumer-Username")) {
                requestMap.put(AuditConstant.Details.SECURITY_BYPASS, true);
            }

            if (TRACKABLE_HEADERS != null) {
                final Map<String, Object> headerMap = new HashMap<>();
                TRACKABLE_HEADERS.forEach(s -> {
                    String val = headers.get(s);
                    if (val != null) {
                        headerMap.put(s, val);
                    }
                });

                if (!headerMap.isEmpty()) {
                    requestMap.put("headers", headerMap);
                }
            }

            if (requestMap.isEmpty()) {
                requestMap = null;
            }
        }

        JsonNode statusNode = JsonNodeUtil.getJsonNode(audit.getCommon(), "success.status");
        Map<String, Object> statusMap = null;
        if (statusNode == null || statusNode.isMissingNode()) {
            statusMap = new HashMap<>();
            statusMap.put("success", true);
        }

        Map<String, Object> commonData
                = new HashMap<>();
        if (statusMap !=null) {
            commonData.put("status", statusMap);
        }
        if (appTemplate != null) {
            commonData.put("app", appTemplate);
        }
        if (serverTemplate != null) {
            commonData.put("server", serverTemplate);
        }
        if (requestMap != null) {
            commonData.put("request", requestMap);
        }

        if (!commonData.isEmpty()) {
            JsonNode common = MAPPER.valueToTree(commonData);

            audit.mergeCommon(common);
        }

        return audit;

    }

}
