/**
 * Copyright (C) 2020 UnitedHealth Group
 * <p>
 * All rights reserved.
 */
package com.uhg.ihr.audit.consumer;

import com.fasterxml.jackson.databind.JsonNode;
import com.google.common.collect.Maps;
import com.optum.eis.NessLogEvent;
import com.optum.eis.NessLogger;
import com.optum.eis.event.model.logClass;
import com.optum.eis.event.model.outcome;
import com.optum.eis.event.model.severity;
import com.uhg.ihr.audit.Audit;
import com.uhg.ihr.audit.AuditConstant;
import com.uhg.ihr.audit.util.JsonNodeUtil;
import io.micronaut.configuration.kafka.annotation.KafkaListener;
import io.micronaut.configuration.kafka.annotation.OffsetReset;
import io.micronaut.configuration.kafka.annotation.Topic;
import io.micronaut.context.annotation.Property;
import io.micronaut.context.annotation.Requires;
import io.micronaut.core.util.StringUtils;
import io.reactivex.Flowable;
import lombok.extern.slf4j.Slf4j;

import javax.annotation.PostConstruct;
import javax.inject.Inject;
import java.io.FileInputStream;
import java.io.InputStream;
import java.util.*;
import java.util.stream.Stream;

import static com.uhg.ihr.audit.AuditConstant.Details.ACTOR_REQUEST_ID;
import static com.uhg.ihr.audit.AuditConstant.Details.ON_BEHALF_OF;
import static com.uhg.ihr.audit.factory.AuditFactory.DEFAULT_AUDIT_TYPE;

/**
 * @author Anurag Singh
 * @version 1.0
 */
@Slf4j
@KafkaListener(offsetReset = OffsetReset.EARLIEST, threads = 5, groupId = "${audit.topic}_nessListener")
@Requires(property = "audit.consumer.ness.enabled", value = StringUtils.TRUE)
@Requires(property = "audit.enabled", value = StringUtils.TRUE)
public class NessListener {

    @Property(name = "ness.config")
    private Properties NESS_CONFIG;
    @Property(name = "ness.mapping")
    private Properties NESS_MAPPING;

    private static NessLogger nessLogger;
    private static boolean nessInitialized = false;

    @Inject
    public NessListener() {
    }

    @PostConstruct
    protected void initialize() {
        if (NESS_CONFIG != null && !NESS_CONFIG.isEmpty()) {
            Properties nessConfig;

            if (NESS_MAPPING != null && !NESS_MAPPING.isEmpty()) {
                nessConfig = new Properties();
                NESS_CONFIG.stringPropertyNames().forEach(s -> {
                    String key = s;
                    if (NESS_MAPPING.containsKey(s)) {
                        key = NESS_MAPPING.getProperty(s);
                    }
                    nessConfig.setProperty(key, NESS_CONFIG.getProperty(s));
                });
            }
            else {
                nessConfig = NESS_CONFIG;
            }
            try {
                nessLogger = new NessLogger(nessConfig);
                nessInitialized = true;
            }
            catch (Exception ex) {
                log.error("Error in loading ness config file  {} :" + ex.getMessage());
            }
        }
        else {
            log.warn("Unable to initialize using NESS_CONFIG, falling back to config.properties initialization");
            try (InputStream input = new FileInputStream("configs/config.properties")) {
                nessLogger = new NessLogger(input);
                nessInitialized = true;
            }
            catch (Exception ex) {
                log.error("Error in loading ness config file  {} :" + ex.getMessage());
            }
        }
    }

    private void publishNessLog(Audit audit) {
        try {
            boolean success = false;
            JsonNode common = audit.getCommon();
            if (common == null) {
                // not a request we can process
                return;
            }
            JsonNode request = common.path("request");
            if (request.isMissingNode()) {
                // not a request we can procerss
                return;
            }

            String correlationId = JsonNodeUtil.getString(request, "headers." + AuditConstant.Details.CORRELATION_ID);

            int status = request.path(AuditConstant.Details.RESULT).asInt(200);
            if (String.valueOf(status).charAt(0) == '2') {
                success = true;
            }
            String type = DEFAULT_AUDIT_TYPE;
            String[] types = audit.getType();
            if (types != null) {
                String otherType = Stream.of(types).filter(s -> !DEFAULT_AUDIT_TYPE.equals(s)).findFirst().orElse(null);
                if (otherType != null) {
                    type = otherType;
                }
            }
            Date auditDate = audit.getDate();
            NessLogEvent logEvent = createEvent(auditDate, "Security Audit: " + type, type);

            logEvent.setLogEvtSeverity(severity.INFO)
                    .setLogEvtLogClass(logClass.SECURITY_AUDIT)
                    .setLogEvtOutcome(success ? outcome.SUCCESS : outcome.FAILURE)
                    .setLogEvtStart(request.path(AuditConstant.Details.LOG_EVT_START).asLong(-1))
                    .setLogEvtEnd(request.path(AuditConstant.Details.LOG_EVT_END).asLong(-1))
                    .setRequestRequest(request.path(AuditConstant.Details.REQUEST_PATH).asText(""))
                    .setRequestUserAgent(request.path(AuditConstant.Details.REQUEST_HOST_NAME).asText(""))
                    .setRequestOptumCIDExt(correlationId)
                    .setRequestMethod(request.path(AuditConstant.Details.REQUEST_METHOD).asText(""))
                    .setRequestIn(request.path(AuditConstant.Details.REQUEST_CONTENT_LENGTH).asLong(-1))
                    .setRequestOut(success ? request.path(AuditConstant.Details.RESPONSE_BODY_LENGTH).asLong() : 0)
                    .setLogEvtAct(request.path(AuditConstant.Details.REQUEST_METHOD).asText())
                    .setLogEvtReason(
                            request.get(AuditConstant.Details.ERROR_MESSAGE) != null
                                    ? request.path(AuditConstant.Details.ERROR_MESSAGE).asText(null)
                                    : (
                                    !request.path(AuditConstant.Details.LOG_EVT_REASON).isMissingNode()
                                            ? request.path(AuditConstant.Details.LOG_EVT_REASON).asText()
                                            : !success ? AuditConstant.Details.UNKNOWN_ERROR : null
                            )
                                    );

            String env = JsonNodeUtil.getString(common, "server.env.ENVIRONMENT", null);
            if (env != null) {
                logEvent.addLogEvtTag(env);
            }

            logEvent.addLogEvtAdditionalField("api-client",
                                              JsonNodeUtil.getString(common, "server.env.X-Consumer-Username", "JWT-Bypass-Client"));

            JsonNode endUser = JsonNodeUtil.getJsonNode(audit.getDetails(), "user");
            String sGaid = null;
            if (!endUser.isMissingNode()) {
                String gaid = JsonNodeUtil.getString(endUser, "gaid",
                                                     JsonNodeUtil.getString(audit.getDetails(),
                                                                            ACTOR_REQUEST_ID, null));
                logEvent.setSourceUserDataUuid(gaid);
                logEvent.setSourceUserDataUid(JsonNodeUtil.getString(endUser, "username", null));
                logEvent.setSourceUserDataFirstName(JsonNodeUtil.getString(endUser, "name.first", null));
                logEvent.setSourceUserDataLastName(JsonNodeUtil.getString(endUser, "name.last", null));
                logEvent.setSourceUserDataLastName(JsonNodeUtil.getString(endUser, "name.last", null));
            }
            else {
                sGaid = JsonNodeUtil.getString(audit.getDetails(),
                                               ACTOR_REQUEST_ID, null);
                if (sGaid != null) {
                    logEvent.setSourceUserDataUuid(sGaid);
                }
            }

            String dGaid = JsonNodeUtil.getString(audit.getDetails(), ON_BEHALF_OF, null);
            if (dGaid != null && !dGaid.equals(sGaid)) {
                logEvent.setDestUserDataUuid(dGaid);
            }

            if (log.isTraceEnabled()) {
                log.trace("Published logEvent: {}", logEvent);
            }
            nessLogger.publish(logEvent);
        }
        catch (Exception ex) {
            if (ex.getMessage() != null) {
                log.warn("NessLogEvent creation failed {}", ex.getMessage());
            }
        }
    }

    @Topic("${audit.topic}")
    public Flowable<Audit> receive(Flowable<Audit> auditFlowable) {
        return auditFlowable.doOnNext(audit -> {
            if (nessInitialized) {
                publishNessLog(audit);
            }
        });
    }

    private NessLogEvent createEvent(Date auditDate, String msg, String logEventName) {
        NessLogEvent event = nessLogger.createLogEvent(msg, logEventName);

        // XXX - fix for non-safe multi-thread operations in NessLogger's event creation
        Map<CharSequence, CharSequence> addFields =  event.getAdditionalFields();
        if (addFields != null) {
            event.setAdditionalFields(new HashMap<>(addFields));
        }
        List<CharSequence> tags = event.getTags();
        if (tags != null) {
            event.setTags(new ArrayList<>(tags));
        }

        return event;
    }

}