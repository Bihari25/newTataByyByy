package com.uhg.ihr.provider.api.model;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.uhg.ihr.provider.api.validator.ValidRecordType;
import lombok.*;

import java.util.Set;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
@EqualsAndHashCode(callSuper = false)
public class PatientHealthItemRequest extends IhrApiWithActorRequest {

//    @JsonProperty
////    @NotBlank(message = "The request could not be completed, a blank/null chid was provided.")
//    private String chid;

    @JsonProperty
    @ValidRecordType(message = "A valid data class was not provided.")
    private Set<RecordType> dataClasses;
}
