package com.uhg.ihr.medispan.dib.loaders;

/**
*
*/
public class Mmwdupdruglink extends TableLoader {
    
	/**
	 *
	 */
    public Mmwdupdruglink() {
        super();
    }
    
    @Override
    public String getCreateQuery() {
        return
        "CREATE TABLE mmw_dup_druglink " +
        "( " +
            "gpi                         CHARACTER VARYING(14) NOT NULL, " +
            "dtcid                       CHARACTER VARYING(8) NOT NULL, " +
            "CONSTRAINT mmw_dup_druglink_pkey PRIMARY KEY (gpi, dtcid) " +
        ") " +
        "WITH (OIDS=TRUE); ";
    }
    
    @Override
    public String getInsertQuery(String line) {
        String[] fields = line.split("\\|");
        
        return "INSERT INTO mmw_dup_druglink VALUES " +
        "( " +
            "'" + fields[0] + "'," +    //gpi       CHARACTER VARYING(14) NOT NULL
            "'" + fields[1] + "'" +     //dtcid     CHARACTER VARYING(8) NOT NULL
        " ); ";
    }

}
