package com.uhg.ihr.medispan.dib.loaders;

/**
*
*/
public class Mmwadedruglink extends TableLoader {
    
    /**
     * 
     */
    public Mmwadedruglink() {
        super();
    }
    
    @Override
    public String getCreateQuery() {
        return
        "CREATE TABLE mmw_ade_druglink " +
        "( " +
            "gpi                         CHARACTER VARYING(14) NOT NULL, " +
            "mcid                        INTEGER NOT NULL, " +
            "restrictionid               INTEGER NOT NULL, " +
            "severitycode                CHARACTER VARYING(2) NOT NULL, " +
            "onsetcode                   CHARACTER VARYING(2) NOT NULL, " +
            "incidencecode               CHARACTER VARYING(2) NOT NULL, " +
            "doclevelcode                CHARACTER VARYING(2) NOT NULL, " +
            "typecode                    CHARACTER VARYING(2) NOT NULL, " +
            "CONSTRAINT mmw_ade_druglink_pkey PRIMARY KEY (gpi, mcid, restrictionid) " +
        ") " +
        "WITH (OIDS=TRUE); ";
    }
    
    @Override
    public String getInsertQuery(String line) {
        String[] fields = line.split("\\|");
        
        return "INSERT INTO mmw_ade_druglink VALUES " +
            "( " +
                "'" + fields[0] + "'," +                //gpi               CHARACTER VARYING(14) NOT NULL
                Integer.parseInt(fields[1]) + "," +     //mcid              INTEGER NOT NULL
                Integer.parseInt(fields[2]) + "," +     //restrictionid     INTEGER NOT NULL
                "'" + fields[3] + "'," +                //severitycode      CHARACTER VARYING(2) NOT NULL
                "'" + fields[4] + "'," +                //onsetcode         CHARACTER VARYING(2) NOT NULL
                "'" + fields[5] + "'," +                //incidencecode     CHARACTER VARYING(2) NOT NULL
                "'" + fields[6] + "'," +                //doclevelcode      CHARACTER VARYING(2) NOT NULL
                "'" + fields[7] + "' " +                //typecode          CHARACTER VARYING2) NOT NULL
            " ); ";
    }
}
