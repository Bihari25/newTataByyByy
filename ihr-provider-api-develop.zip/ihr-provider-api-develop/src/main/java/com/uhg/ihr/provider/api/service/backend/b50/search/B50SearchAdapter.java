package com.uhg.ihr.provider.api.service.backend.b50.search;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.node.ArrayNode;
import com.uhg.ihr.provider.api.exception.LiteHttpClientException;
import com.uhg.ihr.provider.api.exception.UnhandledApiException;
import com.uhg.ihr.provider.api.model.*;
import com.uhg.ihr.provider.api.model.profile.UserPhone;
import com.uhg.ihr.provider.api.service.backend.SearchAdapterInterface;
import com.uhg.ihr.provider.api.service.backend.b50.B50ApiSecurity;
import com.uhg.ihr.provider.api.service.backend.b50.relationship.B50RelationshipService;
import com.uhg.ihr.provider.api.service.backend.b50.search.cache.B50CachedSearchInterface;
import com.uhg.ihr.provider.api.service.backend.b50.search.model.B50SearchRequest;
import com.uhg.ihr.provider.api.service.backend.b50.search.model.Identifier;
import com.uhg.ihr.provider.api.service.backend.b50.search.model.RequestTransformer;
import com.uhg.ihr.provider.api.service.relationship.model.Relationship;
import io.micronaut.context.MessageSource;
import io.micronaut.http.client.exceptions.HttpClientResponseException;
import io.reactivex.Maybe;
import lombok.extern.slf4j.Slf4j;

import javax.inject.Inject;
import javax.inject.Singleton;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

import static com.uhg.ihr.provider.api.util.AppUtils.getTextOrNull;

@Slf4j
@Singleton
public class B50SearchAdapter implements SearchAdapterInterface {

    public static final String B50_RELATIONSHIPS_NODE = "relationships";

    @Inject
    MessageSource languageSource;

    @Inject
    B50CachedSearchInterface apiClient;

    @Inject
    B50ApiSecurity apiSecurity;

    public Maybe<PatientDemographicsResponse> searchForPatients(final IhrSearchApiRequest apiDto, final ProviderApiHeaders headers) {
        B50SearchRequest searchRequest = RequestTransformer.buildSearchRequest(apiDto);
        String providerChid = apiDto.getActorId();

        final MessageSource.MessageContext msgContext
                = getMessageContext(headers);

        return callB50Api(providerChid, searchRequest, apiDto.getModifier().isNewPatient(), headers)
                .map(response -> {
                    List<PatientDemographics> parsed = parseMultiplePatientB50Response(response, msgContext);
                    return buildDemographicResponse(parsed, msgContext);
                })
                .defaultIfEmpty(buildDemographicResponse(new ArrayList<>(), msgContext));
    }

    public Maybe<PatientDemographics> getPatientDemographics(final String patientChid, final String providerChid, final ProviderApiHeaders headers) {
        B50SearchRequest searchRequest = new B50SearchRequest();
        searchRequest.setGlobalActorId(patientChid);

        final MessageSource.MessageContext msgContext
                = getMessageContext(headers);

        return callB50Api(providerChid, searchRequest, false, headers)
                .flatMap(response -> {
                    List<PatientDemographics> parsed = parseMultiplePatientB50Response(response, msgContext);
                    if (!parsed.isEmpty()) {
                        return Maybe.just(parsed.get(0));
                    }
                    else {
                        return Maybe.empty();
                    }
                });
    }

    private MessageSource.MessageContext getMessageContext(final ProviderApiHeaders headers) {
        Locale reqLocale = null;
        if (headers != null) {
            String acceptLanguage = headers.getAcceptLanguage();
            if (acceptLanguage != null && !acceptLanguage.isBlank()) {
                reqLocale = new Locale(acceptLanguage);
            }
        }
        if (reqLocale == null) {
            reqLocale = Locale.getDefault();
        }
        return MessageSource.MessageContext.of(reqLocale);
    }

    private Maybe<JsonNode> callB50Api(String providerChid, B50SearchRequest searchRequest, boolean newPatient,
                                       ProviderApiHeaders headers) {
        String bearerToken = apiSecurity.generateProviderBearerToken(providerChid);
        Maybe<JsonNode> response;
        if (newPatient) {
            response = apiClient.findNewPatients(bearerToken, providerChid, searchRequest, headers);
        }
        else {
            response = apiClient.findExistingPatients(bearerToken, providerChid, searchRequest.toString(), searchRequest, headers);
        }
        return response
                .onErrorResumeNext(e -> {
                    if (e instanceof HttpClientResponseException) {
                        return Maybe.error(new LiteHttpClientException((HttpClientResponseException) e, searchRequest));
                    }
                    else {
                        return Maybe.error(new UnhandledApiException(e));
                    }
                });
    }

    private PatientDemographicsResponse buildDemographicResponse(List<PatientDemographics> patients,
                                                                 MessageSource.MessageContext msgContext) {
        PatientDemographicsResponse fullResponse = new PatientDemographicsResponse();
        fullResponse.setPatientDemographics(patients);
        return fullResponse;
    }

    private List<PatientDemographics> parseMultiplePatientB50Response(JsonNode response,
                                                                      MessageSource.MessageContext msgContext) {
        List<PatientDemographics> patients = new ArrayList<>();
        if (response != null && !response.isEmpty()) {
            for (JsonNode patientObj : (ArrayNode) response.get("Patient")) {
                patients.add(parsePatientNodeIntoDemographics(patientObj, msgContext));
            }
        }
        return patients;
    }

    private PatientDemographics parsePatientNodeIntoDemographics(JsonNode patientObj,
                                                                 MessageSource.MessageContext msgContext) {
        String chid = patientObj.get("Global_Actor_ID").asText();
        MemberName memberName = getMemberName(patientObj, msgContext);
        String gender = getTextOrNull(patientObj.get("GENDER"));
        List<MemberAddress> addresses = getMemberAddresses(patientObj, msgContext);
        List<UserPhone> phones = getMemberPhones(patientObj, msgContext);
        List<Id> identifiers = getMemberIdentifiers(patientObj, msgContext);
        List<Relationship> relationships = B50RelationshipService.compileRelatedRelationships(patientObj.get(B50_RELATIONSHIPS_NODE));
        String dateOfBirth = getTextOrNull(patientObj.get("DATE_OF_BIRTH"));
        String dateOfDeath = getTextOrNull(patientObj.get("DATE_OF_DEATH"));
        return new PatientDemographics(
                chid,
                memberName,
                dateOfBirth,
                dateOfDeath,
                dateOfBirth != null ? AgeUtil.calculateAge(dateOfBirth, dateOfDeath) : null,
                gender,
                addresses,
                phones,
                identifiers,
                relationships);
    }

    private MemberName getMemberName(JsonNode patientObj, MessageSource.MessageContext msgContext) {
        JsonNode nameNode = ((ArrayNode) patientObj.get("NAMES")).get(0);
        MemberName name = new MemberName(
                getTextOrNull(nameNode.get("NAME_FIRST")),
                getTextOrNull(nameNode.get("NAME_MIDDLE")),
                getTextOrNull(nameNode.get("NAME_LAST")));
        return name;
        //TODO: Implement best name search if multiple names are returned
    }

    private List<MemberAddress> getMemberAddresses(JsonNode patientObj,
                                                   MessageSource.MessageContext msgContext) {
        List<MemberAddress> addresses = new ArrayList<>();
        if (patientObj.get("ADDRESSES") != null) {
            for (JsonNode addrNode : (ArrayNode) patientObj.get("ADDRESSES")) {
                addresses.add(new MemberAddress(
                        getTextOrNull(addrNode.get("ADDR_LINE1")),
                        getTextOrNull(addrNode.get("ADDR_LINE2")),
                        getTextOrNull(addrNode.get("ADDR_CITY")),
                        getTextOrNull(addrNode.get("ADDR_STATE")),
                        getTextOrNull(addrNode.get("ADDR_POSTAL_CODE")),
                        getTextOrNull(addrNode.get("ADDR_COUNTRY")),
                        getTextOrNull(addrNode.get("ADDR_TYPE"))
                ));
            }
        }
        return addresses;
    }

    private List<Id> getMemberIdentifiers(JsonNode patientObj,
                                          MessageSource.MessageContext msgContext) {
        List<Id> identifiers = new ArrayList<>();
        if (patientObj.get("IDENTIFIERS") != null) {
            for (JsonNode id : (ArrayNode) patientObj.get("IDENTIFIERS")) {
                String identifier = id.fieldNames().next();
                try {
                    Identifier idType = Identifier.valueOf(identifier);
                    String idNum = id.get(identifier).asText();
                    identifiers.add(
                            new Id(idNum,
                                   idType,
                                   msgContext != null
                                           ? languageSource.getMessage(String.valueOf(idType), msgContext).orElse(null)
                                           : null)
                                   );
                }
                catch (IllegalArgumentException e) {
                    log.error("No IdType ENUM for identifier '" + identifier + "'");
                }
            }
        }
        return identifiers;
    }

    private List<UserPhone> getMemberPhones(JsonNode patienObj,
                                            MessageSource.MessageContext msgContext) {
        List<UserPhone> phones = new ArrayList<>();
        if (patienObj.get("PHONES") != null) {
            for (JsonNode phone : patienObj.get("PHONES")) {
                phones.add(new UserPhone(getTextOrNull(phone.get("PHONE_NUMBER")), getTextOrNull(phone.get("PHONE_TYPE"))));
            }
        }
        return phones;
    }
}
