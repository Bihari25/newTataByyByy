package com.uhg.ihr.provider.api.security;

public class StargateJwtException extends RuntimeException {

    public StargateJwtException(String message) {
        super(message);
    }

}
