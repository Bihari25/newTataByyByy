package com.uhg.ihr.provider.api.model.inflator;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import org.apache.commons.lang3.builder.ToStringBuilder;

import java.io.Serializable;
import java.util.List;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
        "recordType",
        "medicalDevice",
        "dataSource",
        "lastDispenseDate",
        "objectId",
        "presenceStateTerm",
        "relatedCareTeam",
        "medicalDeviceDate",
        "medicalDeviceStatus",
        "supplier",
        "clinicallyRelevantDate"
})
@JsonIgnoreProperties(ignoreUnknown = true)
public class HealthDevice implements Serializable {

    @JsonProperty("recordType")
    private String recordType;
    @JsonProperty("medicalDevice")
    private MedicalDevice medicalDevice;
    @JsonProperty("dataSource")
    private List<String> dataSource = null;
    @JsonProperty("lastDispenseDate")
    private String lastDispenseDate;
    @JsonProperty("objectId")
    private long objectId;
    @JsonProperty("presenceStateTerm")
    private String presenceStateTerm;
    @JsonProperty("relatedCareTeam")
    private List<Object> relatedCareTeam = null;
    @JsonProperty("medicalDeviceDate")
    private String medicalDeviceDate;
    @JsonProperty("medicalDeviceStatus")
    private MedicalDeviceStatus medicalDeviceStatus;
    @JsonProperty("supplier")
    private Supplier supplier;
    @JsonProperty("clinicallyRelevantDate")
    private String clinicallyRelevantDate;

    @JsonProperty("recordType")
    public String getRecordType() {
        return recordType;
    }

    @JsonProperty("recordType")
    public void setRecordType(String recordType) {
        this.recordType = recordType;
    }

    @JsonProperty("medicalDevice")
    public MedicalDevice getMedicalDevice() {
        return medicalDevice;
    }

    @JsonProperty("medicalDevice")
    public void setMedicalDevice(MedicalDevice medicalDevice) {
        this.medicalDevice = medicalDevice;
    }

    @JsonProperty("dataSource")
    public List<String> getDataSource() {
        return dataSource;
    }

    @JsonProperty("dataSource")
    public void setDataSource(List<String> dataSource) {
        this.dataSource = dataSource;
    }

    @JsonProperty("lastDispenseDate")
    public String getLastDispenseDate() {
        return lastDispenseDate;
    }

    @JsonProperty("lastDispenseDate")
    public void setLastDispenseDate(String lastDispenseDate) {
        this.lastDispenseDate = lastDispenseDate;
    }

    @JsonProperty("objectId")
    public long getObjectId() {
        return objectId;
    }

    @JsonProperty("objectId")
    public void setObjectId(long objectId) {
        this.objectId = objectId;
    }

    @JsonProperty("presenceStateTerm")
    public String getPresenceStateTerm() {
        return presenceStateTerm;
    }

    @JsonProperty("presenceStateTerm")
    public void setPresenceStateTerm(String presenceStateTerm) {
        this.presenceStateTerm = presenceStateTerm;
    }

    @JsonProperty("relatedCareTeam")
    public List<Object> getRelatedCareTeam() {
        return relatedCareTeam;
    }

    @JsonProperty("relatedCareTeam")
    public void setRelatedCareTeam(List<Object> relatedCareTeam) {
        this.relatedCareTeam = relatedCareTeam;
    }

    @JsonProperty("medicalDeviceDate")
    public String getMedicalDeviceDate() {
        return medicalDeviceDate;
    }

    @JsonProperty("medicalDeviceDate")
    public void setMedicalDeviceDate(String medicalDeviceDate) {
        this.medicalDeviceDate = medicalDeviceDate;
    }

    @JsonProperty("medicalDeviceStatus")
    public MedicalDeviceStatus getMedicalDeviceStatus() {
        return medicalDeviceStatus;
    }

    @JsonProperty("medicalDeviceStatus")
    public void setMedicalDeviceStatus(MedicalDeviceStatus medicalDeviceStatus) {
        this.medicalDeviceStatus = medicalDeviceStatus;
    }

    @JsonProperty("supplier")
    public Supplier getSupplier() {
        return supplier;
    }

    @JsonProperty("supplier")
    public void setSupplier(Supplier supplier) {
        this.supplier = supplier;
    }

    @JsonProperty("clinicallyRelevantDate")
    public String getClinicallyRelevantDate() {
        return clinicallyRelevantDate;
    }

    @JsonProperty("clinicallyRelevantDate")
    public void setClinicallyRelevantDate(String clinicallyRelevantDate) {
        this.clinicallyRelevantDate = clinicallyRelevantDate;
    }

    @Override
    public String toString() {
        return new ToStringBuilder(this).append("recordType", recordType).append("medicalDevice", medicalDevice).append("dataSource", dataSource).append("lastDispenseDate", lastDispenseDate).append("objectId", objectId).append("presenceStateTerm", presenceStateTerm).append("relatedCareTeam", relatedCareTeam).append("medicalDeviceDate", medicalDeviceDate).append("medicalDeviceStatus", medicalDeviceStatus).append("supplier", supplier).append("clinicallyRelevantDate", clinicallyRelevantDate).toString();
    }

}