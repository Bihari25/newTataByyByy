package com.uhg.ihr.provider.api.model.profile;

import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.validation.Valid;
import javax.validation.constraints.NotNull;
import java.util.List;
import java.util.Set;

@Data
@Builder(toBuilder = true)
@AllArgsConstructor
@NoArgsConstructor
@JsonInclude(JsonInclude.Include.NON_NULL)
public class RoleLookup {
    @NotNull(message = "'externalSecurity' must not be null")
    @Valid
    private ExternalSecurityAccess externalSecurity;

    Set<UserProfileConstant.ROLE_CONTEXT> filterContext;
}
