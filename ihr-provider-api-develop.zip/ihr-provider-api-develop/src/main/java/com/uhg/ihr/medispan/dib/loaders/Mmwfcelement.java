package com.uhg.ihr.medispan.dib.loaders;

/**
*
*/
public class Mmwfcelement extends TableLoader {
    
	/**
	 *
	 */
    public Mmwfcelement() {
        super();
    }
    
    @Override
    public String getCreateQuery() {
        return
        "CREATE TABLE mmw_fc_element " +
        "( " +
            "elementid                   INTEGER NOT NULL, " +
            "documentcode                CHARACTER VARYING(10) NOT NULL, " +
            "parentid                    INTEGER NOT NULL, " +
            "childsequence       INTEGER NOT NULL, " +
            "tagtype                     CHARACTER VARYING(40) NOT NULL, " +
            "idattribute                 CHARACTER VARYING(32) NULL, " +
            "hassectionsind              SMALLINT NOT NULL, " +
            "filename                    CHARACTER VARYING(30) NOT NULL, " +
            "elementtitle                CHARACTER VARYING(255) NOT NULL, " +
            "xpath                       CHARACTER VARYING(255) NULL, " +
            "CONSTRAINT mmw_fc_element_pkey PRIMARY KEY (elementid) " +
        ") " +
        "WITH (OIDS=TRUE); ";
    }
    
    @Override
    public String getInsertQuery(String line) {
        String[] fields = line.split("\\|");
        
        return "INSERT INTO mmw_fc_element VALUES " +
        "( " +
            Integer.parseInt(fields[0]) + "," +     //elementid                   INTEGER NOT NULL
            "'" + fields[1] + "'," +                //documentcode                CHARACTER VARYING(10) NOT NULL
            Integer.parseInt(fields[2]) + "," +     //parentid                    INTEGER NOT NULL
            Integer.parseInt(fields[3]) + "," +     //childsequence               INTEGER NOT NULL
            "'" + fields[4] + "'," +                //tagtype                     CHARACTER VARYING(40) NOT NULL
            (fields[5].isEmpty() ? "NULL" : "'" + fields[5] + "'") + "," +      //idattribute                 CHARACTER VARYING(32) NULL
            Integer.parseInt(fields[6]) + "," +     //hassectionsind              SMALLINT NOT NULL
            "'" + fields[7] + "'," +                //filename                    CHARACTER VARYING(30) NOT NULL
            "'" + fields[8] + "'," +                //elementtitle                CHARACTER VARYING(255) NOT NULL
            (fields.length < 10 || fields[9].isEmpty() ? "NULL" : "'" + fields[9] + "'") +  //xpath                       CHARACTER VARYING(255) NULL
        " ); ";
    }

}
