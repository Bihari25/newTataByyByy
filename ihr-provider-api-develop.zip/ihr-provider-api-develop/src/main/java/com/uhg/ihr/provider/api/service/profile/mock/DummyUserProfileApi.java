package com.uhg.ihr.provider.api.service.profile.mock;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.uhg.ihr.provider.api.model.MemberName;
import com.uhg.ihr.provider.api.model.ProviderApiHeaders;
import com.uhg.ihr.provider.api.model.profile.*;
import com.uhg.ihr.provider.api.service.profile.UserProfileApi;
import com.uhg.ihr.provider.api.service.security.SecurityApi;
import io.micronaut.context.annotation.Secondary;
import io.micronaut.core.util.CollectionUtils;
import io.reactivex.Maybe;
import lombok.extern.slf4j.Slf4j;

import javax.inject.Inject;
import javax.inject.Singleton;
import java.io.IOException;
import java.net.URL;
import java.security.SecureRandom;
import java.util.*;
import java.util.stream.Collectors;

@Slf4j
@Secondary
@Singleton
public class DummyUserProfileApi implements UserProfileApi {
    private static final List<IhrUser> cachedUserProfiles;
    private static final Object modifyMutex = new Object();

    @Inject
    private SecurityApi securityApi;

    static {
        URL dummyDataUrl = DummyUserProfileApi.class.getResource("/security/mock/profiles.json");
        IhrUser[] dummyData = null;
        if (dummyDataUrl != null) {
            ObjectMapper mapper = new ObjectMapper();
            try {
                dummyData = mapper.readValue(dummyDataUrl, IhrUser[].class);
            } catch (IOException e) {
                System.err.println("Unable to read dummy profile data -- using empty data: " + e);
            }
        } else {
            System.err.println("Unable to initialize dummy profile data -- using empty data");
        }

        cachedUserProfiles = dummyData != null ? new ArrayList<>(List.of(dummyData)) : Collections.emptyList();
    }

    private static final SecureRandom RANDOM_GEN = new SecureRandom();

    private static String generateChid(UserProfileConstant.USER_TYPE userType) {
        //347ACTP115014425260806144
        //347ACTS115014425260806144
        StringBuilder chid = new StringBuilder();
        for (int i = 0; i < 3; ++i) {
            chid.append(RANDOM_GEN.nextInt(10));
        }
        chid.append("ACT");
        switch (userType) {
            case INDIVIDUAL:
                chid.append("I");
                break;
            case PROVIDER:
                chid.append("P");
                break;
            case STAFF:
            default:
                chid.append("S");

        }

        for (int i = 0; i < 18; ++i) {
            chid.append(RANDOM_GEN.nextInt(10));
        }

        return chid.toString();
    }

    @Override
    public Maybe<UserProfile> getUserProfileByChid(String chid, ProviderApiHeaders headers) {
        UserProfile profile = filterUserByChid(chid);
        return profile == null ? Maybe.empty() : Maybe.just(profile);
    }

    @Override
    public Maybe<UserProfile> registerUser(UserProfileRequest request, ProviderApiHeaders headers) {
        List<UserPermission> updatedPermissions = getUpdatedPermissions(request);
        IhrUser user = request.getUser();
        IhrUser createdUser = cloneUser(user);
        if (updatedPermissions != null) {
            createdUser.setUserPermissions(updatedPermissions);
        }

        createdUser.addIdentifierContext(UserProfileConstant.IDENTIFIER_CONTEXT.IHR,generateChid(user.getUserType()));

        synchronized (modifyMutex) {
            cachedUserProfiles.add(createdUser);
        }

        IhrUser rtnUser = cloneUser(createdUser);
        filterUser(request.getResponseFilter(),
                rtnUser);
        //TODO: Migrate Maybe to more appropriate location when real implementation is created
        return Maybe.just(UserProfile.builder()
                .user(rtnUser)
                .build());
    }

    @Override
    public Maybe<UserProfile> updateUser(UserProfileRequest request, ProviderApiHeaders headers) {
        List<UserPermission> updatedPermissions = getUpdatedPermissions(request);
        IhrUser user = request.getUser();

        String chid = user.getIdentifierContextValue(UserProfileConstant.IDENTIFIER_CONTEXT.IHR);
        String portalId = user.getIdentifierContextValue(UserProfileConstant.IDENTIFIER_CONTEXT.PORTAL);

        // shallow copy to prevent external modifications
        List<IhrUser> userProfileList = new ArrayList<>(cachedUserProfiles);
        IhrUser userToBeUpdated =
                userProfileList.stream()
                        .filter(u -> (chid != null
                                && chid.equals(u.getIdentifierContextValue(UserProfileConstant.IDENTIFIER_CONTEXT.IHR)))
                                || (portalId != null
                                && portalId.equals(u.getIdentifierContextValue(UserProfileConstant.IDENTIFIER_CONTEXT.PORTAL)))).findFirst().orElse(null);

        if (userToBeUpdated == null) {
            return Maybe.empty();
        }

        if (portalId != null) {
            String pIdCtx = userToBeUpdated.getIdentifierContextValue(UserProfileConstant.IDENTIFIER_CONTEXT.PORTAL);
            if (pIdCtx == null) {
                userToBeUpdated.addIdentifierContext(UserProfileConstant.IDENTIFIER_CONTEXT.PORTAL,portalId);
            } else {
                userToBeUpdated.addIdentifierContext(UserProfileConstant.IDENTIFIER_CONTEXT.PORTAL,portalId);
            }
        }

        if (user.getStatus() != null) {
            userToBeUpdated.setStatus(user.getStatus());
        }
        if (user.getName() != null) {
            userToBeUpdated.setName(user.getName());
        }
        if (user.getEmail() != null) {
            userToBeUpdated.setEmail(user.getEmail());
        }
        if (user.getAddresses() != null) {
            userToBeUpdated.setAddresses(new ArrayList<>(user.getAddresses()));
        }
        if (user.getPhones() != null) {
            userToBeUpdated.setPhones(new ArrayList<>(user.getPhones()));
        }
        if (user.getAgreements() != null) {
            userToBeUpdated.setAgreements(new ArrayList<>(user.getAgreements()));
        }
        if (user.getDateOfBirth() != null) {
            userToBeUpdated.setDateOfBirth(user.getDateOfBirth());
        }
        if (user.getGender() != null) {
            userToBeUpdated.setGender(user.getGender());
        }
        if (user.getNpi() != null) {
            userToBeUpdated.setNpi(user.getNpi());
        }
        if (updatedPermissions != null) {
            userToBeUpdated.setUserPermissions(updatedPermissions);
        }

        IhrUser rtnUser = cloneUser(userToBeUpdated);
        filterUser(request.getResponseFilter(),
                rtnUser);
        //TODO: Migrate Maybe to more appropriate location when real implementation is created
        return Maybe.just(UserProfile.builder()
                .user(rtnUser)
                .build());
    }

    private List<UserPermission> getUpdatedPermissions(UserProfileRequest request) {
        ExternalSecurityAccess access = request.getExternalSecurity();
        List<UserPermission> updatedPermissions = null;
        if (access != null) {
            UserProfileConstant.SECURED_CONTEXT sCtx = access.getSecuredContext();
            if (sCtx != null) {
                Set<String> roles = access.getRoles();
                if (roles != null) {
                    updatedPermissions =
                            securityApi
                                    .lookupRoles(
                                            RoleLookup.builder()
                                                    .externalSecurity(
                                                            ExternalSecurityAccess.builder()
                                                                    .securedContext(sCtx)
                                                                    .roles(roles)
                                                                    .build()
                                                    )
                                                    .build()
                                    )
                                    .blockingGet();
                }
            }
        }

        return updatedPermissions;
    }

    @Override
    public Maybe<UserProfile> lookupUserProfile(UserProfileLookup lookup, ProviderApiHeaders headers) {
        UserProfile userProfile = null;

        // create shallow copy, so that things don't change while filtering data
        List<IhrUser> userProfileList = new ArrayList<>(cachedUserProfiles);
        if (!userProfileList.isEmpty()) {

            List<IhrUser> filteredList = null;

            LookupContext lContext = lookup.getLookupContext();
            if (lContext != null) {
                Map<UserProfileConstant.IDENTIFIER_CONTEXT,String> contexts = lContext.getLookupContexts();
                if (contexts != null && !contexts.isEmpty()) {
                    // assume only one context provided
                    final Map.Entry<UserProfileConstant.IDENTIFIER_CONTEXT,String> context = contexts.entrySet().iterator().next();
                    filteredList
                            = userProfileList.stream()
                            .filter(p -> {
                                Map<UserProfileConstant.IDENTIFIER_CONTEXT, String> pIds = p.getIdentifierContexts();
                                return pIds != null
                                        && pIds.entrySet().stream()
                                        .anyMatch(id -> {
                                            return context.getKey().equals(id.getKey())
                                                    && context.getValue().equalsIgnoreCase(id.getValue());
                                        });
                            })
                            .collect(Collectors.toList());
                }

                if (lContext.getEmail() != null) {
                    filteredList = filteredList == null ? userProfileList : filteredList;

                    final String email = lContext.getEmail();
                    filteredList
                            = filteredList.stream()
                            .filter(p -> email.equalsIgnoreCase(p.getEmail()))
                            .collect(Collectors.toList());
                }

                if (lContext.getName() != null) {
                    filteredList = filteredList == null ? userProfileList : filteredList;

                    final MemberName fName = lContext.getName();
                    filteredList
                            = filteredList.stream()
                            .filter(u -> {
                                MemberName dName = u.getName();

                                return dName != null
                                        && (fName.getLast() == null || fName.getLast().equalsIgnoreCase(dName.getLast()))
                                        && (fName.getFirst() == null || fName.getFirst().equalsIgnoreCase(dName.getFirst()))
                                        && (fName.getMiddle() == null || fName.getMiddle().equalsIgnoreCase(dName.getMiddle()));
                            })
                            .collect(Collectors.toList());
                }
                if (lContext.getNpi() != null) {
                    filteredList = filteredList == null ? userProfileList : filteredList;

                    final String npi = lContext.getNpi();
                    filteredList
                            = filteredList.stream()
                            .filter(p -> npi.equalsIgnoreCase(p.getNpi()))
                            .collect(Collectors.toList());
                }
            }

            if (filteredList != null && filteredList.size() == 1) {
                IhrUser foundUser = cloneUser(filteredList.get(0));
                userProfile = UserProfile.builder()
                        .user(foundUser).build();

                filterUser(lookup.getResponseFilter(), foundUser);
            }
        }

        //TODO: Migrate Maybe to more appropriate location when real implementation is created
        return userProfile == null ? Maybe.empty() : Maybe.just(userProfile);
    }

    private static void filterUser(FilterClass filter, IhrUser foundUser) {
        if (filter != null) {
            final Set<UserProfileConstant.ROLE_CONTEXT> roleFilter = filter.getRolesContext();
            if (!CollectionUtils.isEmpty(roleFilter)) {
                if (!CollectionUtils.isEmpty(foundUser.getUserPermissions())) {
//                    foundUser.setUserPermissions(
//                            foundUser.getUserPermissions().forEach(())
//                                    .filter(uPerm -> roleFilter.stream().anyMatch(f -> f == uPerm.getContext()))
//                                    .collect(Collectors.toList()));
                }

            }

            final Set<UserProfileConstant.IDENTIFIER_CONTEXT> idFilter = filter.getIdentifiersContext();
            if (!CollectionUtils.isEmpty(idFilter)) {
                if (!CollectionUtils.isEmpty(foundUser.getIdentifierContexts())) {
                    foundUser.setIdentifierContexts(
                            foundUser.getIdentifierContexts().entrySet().stream()
                                    .filter(id -> idFilter.stream().anyMatch(f -> f == id.getKey()))
                                    .collect(Collectors.toMap(Map.Entry::getKey, Map.Entry::getValue)));


                }
            }

        }
    }

    private IhrUser cloneUser(IhrUser profile) {
        try {
            ObjectMapper mapper = new ObjectMapper();
            return mapper.readValue(mapper.writeValueAsString(profile), IhrUser.class);
        } catch (IOException e) {
            // should not happen
            return profile;
        }
    }

    private UserProfile filterUserByChid(String chid) {
        if (cachedUserProfiles != null) {
            for (IhrUser user : cachedUserProfiles) {
                Map<UserProfileConstant.IDENTIFIER_CONTEXT, String> identifiers = user.getIdentifierContexts();
                String identifierValue = identifiers.get(UserProfileConstant.IDENTIFIER_CONTEXT.IHR);
                if (identifierValue != null && identifierValue.equalsIgnoreCase(chid))
                    return UserProfile.builder().user(user).build();
            }
        }

        return null;
    }   // end of getUserByChid
}
