package com.uhg.ihr.provider.api.model.senzing;


import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import org.apache.commons.lang3.builder.ToStringBuilder;

import java.io.Serializable;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
        "NAME_LAST",
        "NAME_MIDDLE",
        "NAME_FIRST"
})
public class Name implements Serializable {

    @JsonProperty("NAME_LAST")
    private String lastName;
    @JsonProperty("NAME_MIDDLE")
    private String middleName;
    @JsonProperty("NAME_FIRST")
    private String firstName;

    @JsonProperty("NAME_LAST")
    public String getLastName() {
        return lastName;
    }

    @JsonProperty("NAME_LAST")
    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    @JsonProperty("NAME_MIDDLE")
    public String getMiddleName() {
        return middleName;
    }

    @JsonProperty("NAME_MIDDLE")
    public void setMiddleName(String middleName) {
        this.middleName = middleName;
    }

    @JsonProperty("NAME_FIRST")
    public String getFirstName() {
        return firstName;
    }

    @JsonProperty("NAME_FIRST")
    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    @Override
    public String toString() {
        return new ToStringBuilder(this).append("nAMELAST", lastName).append("nAMEMIDDLE", middleName).append("nAMEFIRST", firstName).toString();
    }

}