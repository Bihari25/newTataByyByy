package com.uhg.ihr.provider.api.logging;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.common.collect.ImmutableSet;
import com.optum.cloudsdk.crypto.CryptoFacadePBE;
import com.uhg.ihr.provider.api.util.AppUtils;
import io.micronaut.context.annotation.Context;
import io.micronaut.http.HttpRequest;
import io.micronaut.http.MutableHttpResponse;
import io.micronaut.http.annotation.Filter;
import io.micronaut.http.filter.OncePerRequestHttpServerFilter;
import io.micronaut.http.filter.ServerFilterChain;
import io.reactivex.Flowable;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.reactivestreams.Publisher;
import org.slf4j.MDC;

import javax.inject.Inject;
import java.io.File;
import java.net.InetAddress;
import java.net.URL;
import java.time.Instant;
import java.util.*;

@Slf4j
@Context
@Filter("/**")
public class LoggingFilter extends OncePerRequestHttpServerFilter {

    public static final String LOG_MAP = "logMap";
    public static final String LOG_NESS = "logNess";
    private static final CryptoFacadePBE FACADE;
    private static final String TOTAL = "total";
    private static final String REQUEST_ID_MDC_KEY = "requestId";
    private static final String UNKNOWN_ERROR = "Unknown Error";

    private static final Map<String, String> ENVIRONMENTALS = new HashMap<>();
    private static final Set<String> ENV_VARS = ImmutableSet.of("APPLICATION_NAME", "CLUSTER", "DATACENTER", "ENVIRONMENT", "VERSION");
    private static final ObjectMapper MAPPER = new ObjectMapper();

//    public static boolean nessEnabled;
//    public static NessLogger nessLogger;
//    private static boolean nessInitialized = true;

    static {
        File crytpoFile = AppUtils.findRelativeOrAbsoluteFilePath("configs/restcrypto.properties");
        String name = null;
        if (crytpoFile != null) {
            name = crytpoFile.getAbsolutePath();
        } else {
            URL url = LogHelper.class.getClassLoader().getResource("restcrypto.properties");
            if (url != null) {
                name = url.getPath();
            }
        }
        FACADE = new CryptoFacadePBE(name);
    }

    @Inject
    public LoggingFilter() {
        ENV_VARS.forEach(env -> ENVIRONMENTALS.put(env, System.getenv(env)));
//        LoggingFilter.nessEnabled = nessEnabled;

        try {
            ENVIRONMENTALS.put("host", InetAddress.getLocalHost().getHostName());
        } catch (Exception e) {
            log.warn("unable to resolve hostname, hostname won't be present in the logs.");
        }

/*
        if (nessEnabled) {
            log.info("NESS_ENABLED/ness.enabled is true, initializing ness publisher");
            try (InputStream input = new FileInputStream("configs/config.properties")) {
                nessLogger = new NessLogger(input);
            } catch (Exception ex) {
                nessInitialized = false;
                log.error("Error in loading ness config file  {} :" + ex.getMessage());
            }
        } else {
            log.info("NESS_ENABLED/ness.enabled is false, not initializing ness publisher. Will NOT be logging to ness.");
        }
*/
    }

    private static String logMapToSring(final HttpRequest<?> req) {
        try {
            return MAPPER.writeValueAsString(req.getAttribute(LOG_MAP).orElse(Collections.emptyMap()));
        } catch (Exception e) {
            return String.format("error parsing logMap: %s", e.getMessage());
        }
    }

    @Override
    protected Publisher<MutableHttpResponse<?>> doFilterOnce(HttpRequest<?> request, ServerFilterChain chain) {
        initializeLogMap(request);
//        initializeNessLogMap(request);
        String requestId = request.getHeaders().get("optum-cid-ext");
        //TODO: MAKE SURE YOU REMOVE THIS!!!!!!!!
        if (log.isTraceEnabled()) {
            try {
                if (request.getBody().isPresent()) {
                    String body = MAPPER.writeValueAsString(request.getBody().get());
                    log.trace("RequestBodyLog: " + body);
                }
                else {
                    log.trace("RequestBodyLog: No request body was provided");
                }
            }
            catch (JsonProcessingException e) {
                log.error("RequestBodyLog: failed to ready body", e);
            }
        }
        //REMOVE THE ABOVE
        MDC.put(REQUEST_ID_MDC_KEY, requestId);
        return Flowable.fromPublisher(chain.proceed(request))
                .doOnNext(res -> {
                    String logType = MDC.get(LogHelper.MDC_LOG_TYPE_KEY);
                    MDC.put(LogHelper.MDC_LOG_TYPE_KEY, LogType.audit.name());
                    log(request, res, null);
                    if (logType != null && !logType.isBlank()) {
                        MDC.put(LogHelper.MDC_LOG_TYPE_KEY,logType);
                    } else {
                        MDC.remove(LogHelper.MDC_LOG_TYPE_KEY);
                    }
                })
                .doOnError(e -> {
                    String logType = MDC.get(LogHelper.MDC_LOG_TYPE_KEY);
                    MDC.put(LogHelper.MDC_LOG_TYPE_KEY, LogType.audit.name());
                    log(request, null, e);
                    if (logType != null && !logType.isBlank()) {
                        MDC.put(LogHelper.MDC_LOG_TYPE_KEY,logType);
                    } else {
                        MDC.remove(LogHelper.MDC_LOG_TYPE_KEY);
                    }                })
                .doFinally(MDC::clear);
    }

    public void log(final HttpRequest<?> req, final MutableHttpResponse<?> res, final Throwable error) {
        if (error != null) {
            LogHelper.addAttribute(req, "error", error.getMessage());
        }

/*
        if (nessInitialized && nessEnabled) {
            Instant start = Instant.now();
            publishNessLog(req, res, error);
            LogHelper.addAttribute(req, "nessMs", Duration.between(start, Instant.now()).toMillis());
        }
*/

        //these two lines should be last so we can capture the entire duration, even including ness processing
        LogHelper.setDuration(req, TOTAL);
        log.info(logMapToSring(req));
    }

/*
    private void initializeNessLogMap(final HttpRequest<?> request) {
        if (nessEnabled) {
            Map<String, Object> nessMap = request.getAttribute(LoggingFilter.LOG_NESS, Map.class).orElse(new HashMap());
            nessMap.put("receivedTime", Instant.now().toEpochMilli());
            request.setAttribute(LoggingFilter.LOG_NESS, nessMap);
        }
    }
*/


    public void initializeLogMap(final HttpRequest<?> req) {
        Map<String, Object> logMap = new LinkedHashMap<>(ENVIRONMENTALS);
        logMap.put(TOTAL + "_start", Instant.now());

        /*req.getBody(IhrApiRequestOld.class).ifPresent(apiReq -> {
            String encryptBig5;
            try {
                encryptBig5 = FACADE.encryptString(MAPPER.writeValueAsString(apiReq));
            } catch (Exception e) {
                encryptBig5 = FACADE.encryptString(apiReq.toString());
            }

            MId mbrId = apiReq.getMbrId();
            Big5 big5 = mbrId.getBig5();
            logMap.put("request-corr-id", apiReq.getCorrelationId());
            logMap.put("big5", encryptBig5);
            logMap.put("searchId", big5.getSearchId());
            logMap.put(mbrId.getIdType(), mbrId.getIdValue());
        });*/

        logMap.put("path", req.getPath());
        logMap.put(AppUtils.X_CONSUMER_HEADER, req.getHeaders().get(AppUtils.X_CONSUMER_HEADER));
        logMap.put(AppUtils.X_COLLECTION_HEADER, req.getHeaders().get(AppUtils.X_COLLECTION_HEADER));
        logMap.put("Accept", req.getHeaders().get("Accept"));
        logMap.put("optum-cid-ext", req.getHeaders().get("optum-cid-ext"));
        req.setAttribute(LOG_MAP, logMap);
    }

    @Override
    public int getOrder() { //we want this to be earlier than most filters, which default to 0
        return -1;
    }

/*
    public void publishNessLog(final HttpRequest request, final MutableHttpResponse<?> res, final Throwable error) {
        try {
            Map<String, Object> nessMap = request.getAttribute(LoggingFilter.LOG_NESS, Map.class).orElse(new HashMap());
            Map<String, Object> logMap = request.getAttribute(LoggingFilter.LOG_MAP, Map.class).orElse(new HashMap());
            Long receivedTime = (Long) nessMap.get("receivedTime");
            boolean success = false;
            String correlationId = logMap.get("optum-cid-ext") != null ? logMap.get("optum-cid-ext").toString() : "";
            if (res != null && res.getStatus().getCode() == 200) {
                success = true;
            }
            NessLogEvent logEvent = nessLogger.createLogEvent(success ? "IHR API request processed successfully for correlation id: " + correlationId :
                            "IHR API request failed for correlation id: " + correlationId,
                    success ? "IHR API resource accessed successfully for correlation id: " + correlationId :
                            "IHR API resource accessed failed for correlation id: " + correlationId)
                    .setLogEvtOutcome(success ? outcome.SUCCESS : outcome.FAILURE)
                    .setLogEvtStart(receivedTime).setLogEvtEnd(Instant.now().toEpochMilli())
                    .setRequestRequest(request.getPath())
                    .setRequestUserAgent(request.getRemoteAddress().getHostName())
                    .setRequestOptumCIDExt(logMap.get("optum-cid-ext").toString())
                    .setRequestMethod(request.getMethod().name())
                    .setRequestIn(request.getContentLength())
                    .setRequestOut(success ? res.getBody().toString().length() : 0)
                    .setLogEvtAct(request.getMethod().name())
                    .setLogEvtLogClass(logClass.SECURITY_SUCCESS)
                    .setLogEvtReason(getReason(res, error));
            log.debug("Published logEvent: {}", logEvent);
            nessLogger.publish(logEvent);
        } catch (Exception ex) {
            if (ex != null && ex.getMessage() != null) {
                log.warn("publish to ness failed {}", ex.getMessage());
            }
        }
    }
*/

    private String getReason(final MutableHttpResponse<?> res, final Throwable error) {
        if (error != null && StringUtils.isNotEmpty(error.getMessage())) {
            return error.getMessage();
        } else if (StringUtils.isNotEmpty(res.getStatus())) {
            return res.getStatus().getReason();
        } else {
            return UNKNOWN_ERROR;
        }
    }
}
