package com.uhg.ihr.provider.api.service.relationship.model;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder(toBuilder = true)
@NoArgsConstructor
@AllArgsConstructor
public class Relationship {
    private String providerChid;
    private String relationship;
    private String effectiveDate;
    private String endDate;
}
