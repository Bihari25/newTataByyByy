package com.uhg.ihr.medispan.util;

import java.lang.annotation.Annotation;
import java.lang.reflect.Constructor;
import java.lang.reflect.Field;
import java.lang.reflect.Method;
import java.lang.reflect.Modifier;
import java.util.ArrayList;
import java.util.Collection;

/**
 * Defines ClassUtils.java.
 */
public final class ClassUtils {

    /**
     * Casts the specified object in a generic type-safe fashion.
     *
     * @param o  the object.
     *
     * @return  the casted object.
     */
    @SuppressWarnings("unchecked")
    public static <T> T cast(Object o) {
        return (T) o;
    }

    /**
     * Searches the Class, annotatedClass, and its super classes for the presence of an annotation.  The search starts
     * with annotatedClass and proceeds recursively through its parents.  As soon as the annotation is found, the
     * search stops and returns the class where the annotation was found.  If the annotation is not found, null is
     * returned.
     *
     * @param annotatedClass   the starting class for the search.  This class and its parents are searched
     *                             for the annotation specified by annotationClass.
     * @param annotationClass  the annotation of interest.
     *
     * @return  the class where the annotation is first found; null if the annotation is not found.
     */
    public static <T> Class<T> findAnnotatedClass(Class<?> annotatedClass,
                                                  Class<? extends Annotation> annotationClass) {
        if (annotatedClass == null) {
            throw new IllegalArgumentException("annotatedClass must not be null");
        }
        if (annotationClass == null) {
            throw new IllegalArgumentException("annotationClass must be null");
        }
        Class<?> currentClass = annotatedClass;
        while (currentClass != null) {
            if (currentClass.isAnnotationPresent(annotationClass)) {
                return cast(currentClass);
            }
            currentClass = currentClass.getSuperclass();
        }
        return null;
    }

    /**
     * Returns an accessible field from the specified class or one of its parents.
     *
     * @param objectClass  the object class.
     * @param fieldName    the field name.
     *
     * @return  the field.
     * @throws NoSuchFieldException
     */
    public static Field getAccessibleField(Class<?> objectClass, String fieldName) throws NoSuchFieldException {
        NoSuchFieldException exception = null;
        for ( ; objectClass != null; objectClass = objectClass.getSuperclass()) {
            try {
                return objectClass.getDeclaredField(fieldName);
            } catch (NoSuchFieldException e) {
                if (exception == null) {
                    exception = e;
                }
            }
        }
        throw exception != null ? new NoSuchFieldException(exception.getMessage()) :
                new NoSuchFieldException(fieldName);
    }

    /**
     * Returns an accessible method from the specified class or one of its parents.
     *
     * @param objectClass     the object class.
     * @param methodName      the method name.
     * @param parameterTypes  the parameter types.
     *
     * @return  the method.
     * @throws NoSuchMethodException
     */
    public static Method getAccessibleMethod(Class<?> objectClass, String methodName, Class<?>... parameterTypes)
            throws NoSuchMethodException {
        NoSuchMethodException exception = null;
        for ( ; objectClass != null; objectClass = objectClass.getSuperclass()) {
            try {
                return objectClass.getDeclaredMethod(methodName, parameterTypes);
            } catch (NoSuchMethodException e) {
                if (exception == null) {
                    exception = e;
                }
            }
        }
        throw exception != null ? new NoSuchMethodException(exception.getMessage()) :
                new NoSuchMethodException(methodName);
    }

    /**
     * Returns an accessible method conforming to the specified parameter types from the specified class or one of its
     * parents.  If there is an exact match, it is returned, otherwise, the first conforming method which is found.
     *
     * @param objectClass     the object class.
     * @param methodName      the method name.
     * @param parameterTypes  the parameter types.
     *
     * @return  the conforming method.
     * @throws NoSuchMethodException
     */
    public static Method getConformingAccessibleMethod(Class<?> objectClass, String methodName,
                                                       Class<?>... parameterTypes) throws NoSuchMethodException {
        NoSuchMethodException exception = null;
        try {
            return getAccessibleMethod(objectClass, methodName, parameterTypes);
        } catch (NoSuchMethodException e) {
            exception = e;
        }
        for ( ; objectClass != null; objectClass = objectClass.getSuperclass()) {
            try {
                return getConformingMethod(objectClass, methodName, parameterTypes);
            } catch (NoSuchMethodException e) {
            }
        }
        throw new NoSuchMethodException(exception.getMessage());
    }

    /**
     * Returns a constructor conforming to the specified parameter types.  If there is an exact match, it is returned,
     * otherwise, the first conforming constructor which is found.
     *
     * @param objectClass     the object class.
     * @param parameterTypes  the parameter types.
     *
     * @return  a conforming constructor.
     * @throws NoSuchMethodException
     */
    public static Constructor<?> getConformingConstructor(Class<?> objectClass, Class<?>... parameterTypes)
            throws NoSuchMethodException {
        NoSuchMethodException exception = null;
        try {
            return objectClass.getDeclaredConstructor(parameterTypes);
        } catch (NoSuchMethodException e) {
            exception = e;
        }
        Constructor<?> conformingConstructor = null;
        for (Constructor<?> constructor : objectClass.getDeclaredConstructors()) {
            if (!Modifier.isVolatile(constructor.getModifiers()) &&
                    isConformingParameterList(constructor.getParameterTypes(), parameterTypes)) {
                if (conformingConstructor != null) {
                    throw new NoSuchMethodException(exception.getMessage() +
                            "  Multiple conforming concstructors found.");
                }
                conformingConstructor = constructor;
            }
        }
        if (conformingConstructor == null) {
            throw new NoSuchMethodException(exception.getMessage());
        }
        return conformingConstructor;
    }

    /**
     * Returns a method conforming to the specified parameter types.  If there is an exact match, it is returned,
     * otherwise, the first conforming method which is found.
     *
     * @param objectClass     the object class.
     * @param methodName      the method name.
     * @param parameterTypes  the parameter types.
     *
     * @return  a conforming method.
     * @throws NoSuchMethodException
     */
    public static Method getConformingMethod(Class<?> objectClass, String methodName, Class<?>... parameterTypes)
            throws NoSuchMethodException {
        NoSuchMethodException exception = null;
        try {
            return objectClass.getDeclaredMethod(methodName, parameterTypes);
        } catch (NoSuchMethodException e) {
            exception = e;
        }
        Method conformingMethod = null;
        for (Method method : nonSyntheticDeclaredMethodsFor ( objectClass ) ) {
            if (method.getName().equals(methodName) && !Modifier.isVolatile(method.getModifiers()) &&
                    isConformingParameterList(method.getParameterTypes(), parameterTypes)) {
                if (conformingMethod != null) {
                    throw new NoSuchMethodException(exception.getMessage() + "  Multiple conforming methods found.");
                }
                conformingMethod = method;
            }
        }
        if (conformingMethod == null) {
            throw new NoSuchMethodException(exception.getMessage());
        }
        return conformingMethod;
    }

    /**
     * Returns generic type parameters for the specified class.
     *
     * @param cls  the class.
     *
     * @return  the generic type parameters.
     */
    public static String getGenericTypeParameters(Class<?> cls) {
        StringBuilder typeParameters = new StringBuilder();
        if (cls.getTypeParameters().length > 0) {
            typeParameters.append("<");
            for (int i = 1; i <= cls.getTypeParameters().length; i ++) {
                if (i > 1) {
                    typeParameters.append(", ");
                }
                typeParameters.append("?");
            }
            typeParameters.append(">");
        }
        return typeParameters.toString();
    }

    /**
     * @param className
     * @return  the class name
     */
    public static String getPackagelessClassName(String className) {
        if (className == null) {
            return null;
        }
        // remove packages from name
        int startIndex = className.lastIndexOf('.');
        if (startIndex >= 0) {
            className = className.substring(startIndex + 1);
        }
        // remove hibernate wrapper info
        int stopIndex = className.indexOf("$$");
        if (stopIndex >= 0) {
            className = className.substring(0, stopIndex);
        }
        return className;
    }

    /**
     * @param theClass
     * @return  the class name
     */
    public static String getPackagelessClassName(Class<?> theClass) {
        return theClass == null ? null : getPackagelessClassName(theClass.getName());
    }

    /**
     * Returns the "pure" class name without hibernate or other database wrapper.
     *
     * @param className the class name
     * @return the "pure" class name without hibernate or other database wrapper.
     */
    public static String getPureClassName(String className) {
        // remove hibernate wrapper info
        int stopIndex = className.indexOf("$$");
        if (stopIndex >= 0) {
            className = className.substring(0, stopIndex);
        }
        return className;
    }

    /**
     * Returns the "pure" class name without hibernate or other database wrapper.
     *
     * @param theClass the class
     * @return the "pure" class name without hibernate or other database wrapper.
     */
    public static String getPureClassName(Class<?> theClass) {
        return getPureClassName(theClass.getName());
    }

    /**
     * @param targetClass
     * @return  the methods
     */
    public static  Collection < Method >    nonSyntheticDeclaredMethodsFor
    (
            Class < ? >   targetClass
    ) {
        Collection < Method >    nonSyntheticDeclaredMethods;

        nonSyntheticDeclaredMethods  =  new ArrayList < > ( );
        for ( Method  declaredMethod  :  targetClass.getDeclaredMethods ( ) ) {
            if ( ! declaredMethod.isSynthetic ( ) ) {
                nonSyntheticDeclaredMethods.add ( declaredMethod );
            }
        }
        return  nonSyntheticDeclaredMethods;
    }


    /**
     * Returns whether a list of actual parameter types conforms to a list of formal parameter types.
     *
     * @param formalParameterTypes  the formal parameter types.
     * @param actualParameterTypes  the actual parameter types.
     *
     * @return  true of the actual parameter types conform to the formal parameter types; false otherwise.
     */
    private static boolean isConformingParameterList(Class<?>[] formalParameterTypes, Class<?>[] actualParameterTypes) {
        if (formalParameterTypes.length != actualParameterTypes.length) {
            return false;
        } else {
            for (int i = 0; i < formalParameterTypes.length; i ++) {
                if (!formalParameterTypes[i].isAssignableFrom(actualParameterTypes[i])) {
                    return false;
                }
            }
        }
        return true;
    }

    /**
     * Creates a new <code>ClassUtils</code>.
     */
    private ClassUtils() {
        super();
    }

}