package com.uhg.ihr.provider.api.model;

import lombok.extern.slf4j.Slf4j;

import javax.validation.constraints.NotNull;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.GregorianCalendar;

import static org.apache.commons.lang3.time.DateUtils.MILLIS_PER_HOUR;

@Slf4j
public class AgeUtil {

    private static final SimpleDateFormat YMD_TEXT_FORMATTER = new SimpleDateFormat("yyyy-MM-dd");
    private static final SimpleDateFormat MDY_TEXT_FORMATTER = new SimpleDateFormat("MM-dd-yyyy");

    /**
     * The specified aging stop time appears to be invalid.
     */
    public static final long INVALID_STOP_TIME = -2;

    /**
     * Based on the object configuration, the calculated age would be negative.
     */
    public static final long NEGATIVE_CALCULATED_AGE = -3;

    /**
     * There was not start time specified.
     */
    public static final long NO_START_TIME_SPECIFIED = -1;

    /**
     * The number of milliseconds in a day.
     */
    private static final long MILLIS_PER_DAY = 86400000L;

    /**
     * The number of milliseconds in a maximal (30 day) month.
     */
    private static final long MILLIS_PER_MAXIMAL_MONTH = 2678400000L;

    /**
     * The number of milliseconds in a maximal (366 day) year.
     */
    private static final long MILLIS_PER_MAXIMAL_YEAR = 31622400000L;

//    private String age;
//
//    /**
//     * The aged time.
//     */
//    private Long agedTime;

//    /**
//     * The calculated age as days.
//     */
//    private Long days;
//
//    /**
//     * Hard-coded result.
//     */
//    private Long hardResult;
//
//    /**
//     * The calculated age as milliseconds.
//     */
//    private Long millis;
//
//    /**
//     * The calculated age as months.
//     */
//    private Long months;
//
//    /**
//     * The aging start time.
//     */
//    private Long startTime;
//
//    /**
//     * The aging stop time.
//     */
//    private Long stopTime;
//
//    /**
//     * The calculated age as years.
//     */
//    private Long years;
//
//    public AgeUtil(String birthDate) throws ParseException {
//        this(birthDate, null);
//    }
//
//    public AgeUtil(String birthDate, String deathDate) throws ParseException {
//        this(TEXT_FORMATTER.parse(birthDate).getTime(), deathDate == null ? null : TEXT_FORMATTER.parse(deathDate).getTime());
//    }
//
//    /**
//     * Creates a new AgeUtil.
//     *
//     * @param agedTime  the aged time.
//     * @param startTime the aging start time.
//     * @param stopTime  the aging stop time.
//     */
//    public AgeUtil(Long agedTime, Long startTime, Long stopTime) {
//        super();
//        this.agedTime = agedTime;
//        this.startTime = startTime;
//        this.stopTime = stopTime;
//        initAge();
//    }
//
//    /**
//     * Creates a new AgeUtil for the current time.
//     *
//     * @param startTime the aging start time.
//     * @param stopTime  the aging stop time.
//     */
//    public AgeUtil(Long startTime, Long stopTime) {
//        this(System.currentTimeMillis(), startTime, stopTime);
//    }

    public static String calculateAge(String birthdate) {
        try {
            return calculateAge(convertDateToLong(birthdate));
        } catch (ParseException e) {
            log.error("Failed to parse string birth date " + birthdate);
        }
        return "";
    }

    public static String calculateAge(String birthdate, String deathdate) {
        boolean isDead = deathdate != null && !deathdate.isBlank();
        try {
            return calculateAge(convertDateToLong(birthdate), isDead ? convertDateToLong(deathdate) : 0, isDead);
        } catch (ParseException e) {
            if (isDead) {
                log.error("Failed to parse string birth date " + birthdate);
            } else {
                log.error("Failed to parse string birth date " + birthdate + " and/or death date " + deathdate);
            }
        }
        return "";
    }

    public static long convertDateToLong(String date) throws ParseException {
        String cleanedDate = date;
        if (date.contains("/")) {
            cleanedDate = date.replace('/','-');
        }
        if (cleanedDate.matches("[0-9]{4}-[0-1]?[0-9]-[0-3]?[0-9]")) {
            return YMD_TEXT_FORMATTER.parse(cleanedDate).getTime();
        } else {
            return MDY_TEXT_FORMATTER.parse(cleanedDate).getTime();
        }
    }

    public static String calculateAge(@NotNull long birthdate) {
        return calculateAge(birthdate, 0, false);
    }

    public static String calculateAge(@NotNull long birthdate, @NotNull long deathdate) {
        return calculateAge(birthdate, deathdate, true);
    }

    static String calculateAge(long birthdate, long deathdate, boolean isDead) {
        long currentTime = System.currentTimeMillis();
        long ageMillis = toMillis(birthdate, deathdate, isDead, currentTime);
        long years = toYears(ageMillis, birthdate);
        // for 19 year old+, use years
        if (years < 0) {
            throw new IllegalArgumentException("Negative years (" + years + "), for age: " + ageMillis);
        } else if (years > 18) {
            return Long.toString(years) + " years";
        } else {
            long months = toMonths(ageMillis, birthdate);
            if (months < 0) {
                throw new IllegalArgumentException("Negative months (" + months + "), for age: " + ageMillis);
            } // for 2-18 year old, use years, months
            else if (months > 24) {
                months -= (years * 12);
                return Long.toString(years) + " year" + checkPlurality(years) +
                        (months == 0 ? "" : " " + Long.toString(months) + " month" + checkPlurality(months));
            } // for 4+ months
            else if (months >= 4) {
                return Long.toString(months) + " month" + checkPlurality(months);
            } else {
                long days = toDays(ageMillis);
                if (days < 0) {
                    throw new IllegalArgumentException("Negative days (" + days + "), for age: " + ageMillis);
                } else if (days >= 29) {
                    long weeks = days / 7;
                    return Long.toString(weeks) + " week" + checkPlurality(weeks);
                } else if (days > 4) {
                    return Long.toString(days) + " day" + checkPlurality(days);
                } else {
                    long hours = ageMillis / MILLIS_PER_HOUR;
                    return Long.toString(hours) + " hour" + checkPlurality(hours);
                }
            }
        }
    }

    /**
     * Returns the age as days.
     *
     * @return the age as days.
     */
    static long toDays(long ageMillis) {
        return ageMillis < 0 ? ageMillis : ageMillis / MILLIS_PER_DAY;
    }

    /**
     * Returns the age as milliseconds.
     *
     * @return the age as milliseconds.
     */
    static long toMillis(long birthdate, long deathdate, boolean isDead, long currentTime) {
        long millis;
        if (currentTime < birthdate) {
            millis = NEGATIVE_CALCULATED_AGE;
        } else if (!isDead) {
            millis = currentTime - birthdate;
        } else if (deathdate < birthdate) {
            millis = INVALID_STOP_TIME;
        } else {
            millis = Math.min(currentTime, deathdate) - birthdate;
        }
        return millis;
    }

    /**
     * Returns the age as months.
     *
     * @return the age as months.
     */
    static long toMonths(long ageMillis, long birthdate) {
        long months;
        long age = ageMillis;
        if (age < 0) {
            months = age;
        } else {
            months = -1L;
            GregorianCalendar calendar = new GregorianCalendar();
            calendar.setTimeInMillis(birthdate);
            int maximalMonths = (int) (age / MILLIS_PER_MAXIMAL_MONTH);
            if (maximalMonths > 0) {
                // Must be at least maximalMonths old so shortcut loop by maximalMonths amount.
                calendar.add(Calendar.MONTH, maximalMonths);
                months += maximalMonths;
            }
            long ageTime = birthdate + age;
            do {
                calendar.add(Calendar.MONTH, 1);
                months++;
            } while (calendar.getTimeInMillis() < ageTime);
        }
        return months;
    }

    /**
     * Returns the age as years.
     *
     * @return the age as years.
     */
    static long toYears(long ageMillis, long birthdate) {
        long years;
        if (ageMillis < 0) {
            years = ageMillis;
        } else {
            years = -1L;
            GregorianCalendar calendar = new GregorianCalendar();
            calendar.setTimeInMillis(birthdate);
            int maximalYears = (int) (ageMillis / MILLIS_PER_MAXIMAL_YEAR);
            if (maximalYears > 0) {
                // Must be at least maximalYears old so shortcut loop by maximalYears amount.
                calendar.add(Calendar.YEAR, maximalYears);
                years += maximalYears;
            }
            long ageTime = birthdate + ageMillis;
            do {
                calendar.add(Calendar.YEAR, 1);
                years++;
            } while (calendar.getTimeInMillis() < ageTime);
        }
        return years;
    }

//    private void initAge() {
//        toMillis();
//        // for 19 year old+, use years
//        if (toYears() < 0) {
//            throw new IllegalArgumentException("Negative years (" + years + "), for age: " + millis);
//        } else if (years > 18) {
//            age = Long.toString(years) + " years";
//        } else if (toMonths() < 0) {
//            throw new IllegalArgumentException("Negative months (" + months + "), for age: " + millis);
//        }
//        // for 2-18 year old, use years, months
//        else if (months > 24) {
//            months -= (years * 12);
//            age = Long.toString(years) + " year" + checkPlurality(years) +
//                    Long.toString(months) + " month" + checkPlurality(months);
//        }
//        // for 4+ months
//        else if (months >= 4) {
//            age = Long.toString(months) + " month" + checkPlurality(months);
//        } else if (toDays() < 0) {
//            throw new IllegalArgumentException("Negative days (" + days + "), for age: " + millis);
//        } else if (days >= 29) {
//            long weeks = days / 7;
//            age = Long.toString(weeks) + " week" + checkPlurality(weeks);
//        } else if (days > 4) {
//            age = Long.toString(days) + " day" + checkPlurality(days);
//        } else {
//            long hours = millis / MILLIS_PER_HOUR;
//            age = Long.toString(hours) + " hour" + checkPlurality(hours);
//        }
//    }

    static String checkPlurality(long num) {
        return num > 1 ? "s" : "";
    }
}
