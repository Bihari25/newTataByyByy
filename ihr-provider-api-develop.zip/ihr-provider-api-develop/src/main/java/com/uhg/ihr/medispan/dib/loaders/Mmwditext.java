package com.uhg.ihr.medispan.dib.loaders;

/**
*
*/
public class Mmwditext extends TableLoader {
    
	/**
	 *
	 */
    public Mmwditext() {
        super();
    }
    
    @Override
    public String getCreateQuery() {
        return
        "CREATE TABLE mmw_di_text " +
        "( " +
            "version                     CHARACTER VARYING(10) NOT NULL, " +
            "classid1                    CHARACTER VARYING(5) NOT NULL, " +
            "classid2                    CHARACTER VARYING(5) NOT NULL, " +
            "linenumber                  SMALLINT NOT NULL, " +
            "linetext                    CHARACTER VARYING(255) NOT NULL, " +
            "CONSTRAINT mmw_di_text_pkey PRIMARY KEY (version, classid1, classid2, linenumber) " +
        ") " +
        "WITH (OIDS=TRUE); ";
    }
    
    @Override
    public String getInsertQuery(String line) {
        String[] fields = line.split("\\|");
        
        return "INSERT INTO mmw_di_text VALUES " +
        "( " +
            "'" + fields[0] + "'," +                    //version         CHARACTER VARYING(10) NOT NULL
            "'" + fields[1] + "'," +                    //classid1        CHARACTER VARYING(5) NOT NULL
            "'" + fields[2] + "'," +                    //classid2        CHARACTER VARYING(5) NOT NULL
            Integer.parseInt(fields[3]) + "," +         //linenumber      SMALLINT NOT NULL
            "'" + fields[4].replace("'", "''") + "'" +  //linetext        CHARACTER VARYING(255) NOT NULL
        " ); ";
    }

}
