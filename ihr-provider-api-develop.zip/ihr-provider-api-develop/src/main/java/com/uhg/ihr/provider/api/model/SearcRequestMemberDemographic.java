package com.uhg.ihr.provider.api.model;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import com.uhg.ihr.provider.api.validator.ValidDate;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.Set;

@Data
@Builder(toBuilder = true)
@AllArgsConstructor
@NoArgsConstructor
@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({"name", "dateOfBirth", "gender", "address"})
public class SearcRequestMemberDemographic {
    @JsonProperty
    private MemberName name;

    @JsonProperty
    private Set<FilterPair> identifiers;

    @JsonProperty
    @ValidDate
    private String dateOfBirth;

    @JsonProperty
    private String gender;

    @JsonProperty
    private MemberAddress address;

    @JsonIgnore
    public boolean isNameFilter() {
        return name != null && !name.isEmpty();
    }
    @JsonIgnore
    public boolean isIdentifierFilter() {
        return identifiers != null && !identifiers.isEmpty();
    }
    @JsonIgnore
    public boolean isGenderFilter() {
        return gender != null && !gender.isBlank();
    }
    @JsonIgnore
    public boolean isDateOfBirthFilter() {
        return dateOfBirth != null && !dateOfBirth.isBlank();
    }
}
