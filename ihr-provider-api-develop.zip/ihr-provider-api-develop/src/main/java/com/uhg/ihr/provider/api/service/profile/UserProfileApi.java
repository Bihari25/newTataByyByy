package com.uhg.ihr.provider.api.service.profile;

import com.uhg.ihr.provider.api.model.ProviderApiHeaders;
import com.uhg.ihr.provider.api.model.profile.UserProfile;
import com.uhg.ihr.provider.api.model.profile.UserProfileLookup;
import com.uhg.ihr.provider.api.model.profile.UserProfileRequest;
import io.reactivex.Maybe;

public interface UserProfileApi {
    Maybe<UserProfile> lookupUserProfile(UserProfileLookup lookup, ProviderApiHeaders headers);

    Maybe<UserProfile> getUserProfileByChid(String chid, ProviderApiHeaders headers);

    Maybe<UserProfile> registerUser(UserProfileRequest request, ProviderApiHeaders headers);

    Maybe<UserProfile> updateUser(UserProfileRequest request, ProviderApiHeaders headers);
}
