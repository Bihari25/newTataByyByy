package com.uhg.ihr.provider.api.model.senzing;

import com.fasterxml.jackson.annotation.JsonProperty;

import java.io.Serializable;

public class MatchLevel implements Serializable {
    private String chid;
    @JsonProperty("matchLevel")
    private long matchLevel;
    @JsonProperty("fullNameScore")
    private long fullNameScore;
    @JsonProperty("matchScore")
    private long matchScore;
    @JsonProperty("ambiguous")
    private boolean ambiguous;
    @JsonProperty("matchKey")
    private String matchKey;
    @JsonProperty("resolutionRuleCode")
    private String resolutionRuleCode;
    @JsonProperty("refScore")
    private long refScore;
    @JsonProperty("partial")
    private boolean partial;
    @JsonProperty("resultType")
    private String resultType;
    @JsonProperty("entityName")
    private String entityName;

    @JsonProperty("dob")
    private String dob;
    @JsonProperty("gender")
    private String gender;
    @JsonProperty("address")
    private String address;

    public MatchLevel(String chid, String entityName, long matchLevel, long fullNameScore, long matchScore, boolean ambiguous, String matchKey, String resolutionRuleCode, long refScore, boolean partial, String resultType) {
        this.chid = chid;
        this.entityName = entityName;
        this.matchLevel = matchLevel;
        this.fullNameScore = fullNameScore;
        this.matchScore = matchScore;
        this.ambiguous = ambiguous;
        this.matchKey = matchKey;
        this.resolutionRuleCode = resolutionRuleCode;
        this.refScore = refScore;
        this.partial = partial;
        this.resultType = resultType;
    }

    public String getChid() {
        return chid;
    }

    public void setChid(String chid) {
        this.chid = chid;
    }

    public long getMatchLevel() {
        return matchLevel;
    }

    public void setMatchLevel(long matchLevel) {
        this.matchLevel = matchLevel;
    }

    public long getFullNameScore() {
        return fullNameScore;
    }

    public void setFullNameScore(long fullNameScore) {
        this.fullNameScore = fullNameScore;
    }

    public long getMatchScore() {
        return matchScore;
    }

    public void setMatchScore(long matchScore) {
        this.matchScore = matchScore;
    }

    public boolean isAmbiguous() {
        return ambiguous;
    }

    public void setAmbiguous(boolean ambiguous) {
        this.ambiguous = ambiguous;
    }

    public String getMatchKey() {
        return matchKey;
    }

    public void setMatchKey(String matchKey) {
        this.matchKey = matchKey;
    }

    public String getResolutionRuleCode() {
        return resolutionRuleCode;
    }

    public void setResolutionRuleCode(String resolutionRuleCode) {
        this.resolutionRuleCode = resolutionRuleCode;
    }

    public long getRefScore() {
        return refScore;
    }

    public void setRefScore(long refScore) {
        this.refScore = refScore;
    }

    public boolean isPartial() {
        return partial;
    }

    public void setPartial(boolean partial) {
        this.partial = partial;
    }

    public String getResultType() {
        return resultType;
    }

    public void setResultType(String resultType) {
        this.resultType = resultType;
    }

    public String getEntityName() {
        return entityName;
    }

    public void setEntityName(String entityName) {
        this.entityName = entityName;
    }

    public String getDob() {
        return dob;
    }

    public void setDob(String dob) {
        this.dob = dob;
    }

    public String getGender() {
        return gender;
    }

    public void setGender(String gender) {
        this.gender = gender;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }
}
