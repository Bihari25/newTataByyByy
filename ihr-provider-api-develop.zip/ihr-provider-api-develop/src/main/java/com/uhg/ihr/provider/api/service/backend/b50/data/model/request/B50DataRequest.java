package com.uhg.ihr.provider.api.service.backend.b50.data.model.request;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.NonNull;

import javax.validation.constraints.NotBlank;
import java.io.Serializable;

@Data
@NoArgsConstructor
public class B50DataRequest implements Serializable {
    @JsonProperty("GLOBAL_ACTOR_ID")
    @NonNull
    @NotBlank(message = "A patient's chid must be provided for a data request")
    String patientChid;
}
