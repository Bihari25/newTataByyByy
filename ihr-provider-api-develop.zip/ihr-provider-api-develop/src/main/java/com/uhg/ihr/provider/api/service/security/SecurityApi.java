package com.uhg.ihr.provider.api.service.security;

import com.uhg.ihr.provider.api.model.profile.RoleLookup;
import com.uhg.ihr.provider.api.model.profile.UserPermission;
import com.uhg.ihr.provider.api.service.security.model.RoleChangeRequest;
import io.reactivex.Maybe;

import java.util.List;

public interface SecurityApi {
    Maybe<List<UserPermission>> lookupRoles(RoleLookup lookup);

    Maybe<RoleChangeRequest> putRoles(RoleChangeRequest request);
}


