package com.uhg.ihr.provider.api.service.relationship.model;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;

import java.util.List;

@Data
@Builder(toBuilder = true)
@AllArgsConstructor
public class RelationshipResponse {
    private String patientActorId;
    private List<Relationship> providerRelationships;
}
