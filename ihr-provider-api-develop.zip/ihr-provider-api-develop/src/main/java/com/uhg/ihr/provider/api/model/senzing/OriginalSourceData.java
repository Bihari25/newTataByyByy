package com.uhg.ihr.provider.api.model.senzing;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

import java.io.Serializable;
import java.util.List;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
        "Global_Actor_ID",
        "NAMES",
        "GENDER",
        "DATE_OF_BIRTH",
        "SUBSCRIBER_RELATIONSHIP_TYPE",
        "IDENTIFIERS",
        "PHONES",
        "ADDRESSES",
        "DATA_SOURCE",
        "ENTITY_TYPE",
        "DSRC_ACTION",
        "LENS_CODE",
        "RECORD_ID"
})
public class OriginalSourceData implements Serializable {

    @JsonProperty("Global_Actor_ID")
    private String globalActorId;
    @JsonProperty("NAMES")
    private List<Name> names = null;
    @JsonProperty("GENDER")
    private String gender;
    @JsonProperty("DATE_OF_BIRTH")
    private String dob;
    @JsonProperty("SUBSCRIBER_RELATIONSHIP_TYPE")
    private String sUBSCRIBERRELATIONSHIPTYPE;
    @JsonProperty("IDENTIFIERS")
    private List<Identifier> identifiers = null;
    @JsonProperty("PHONES")
    private List<Phone> pHONES = null;
    @JsonProperty("ADDRESSES")
    private List<Address> addresses = null;
    @JsonProperty("DATA_SOURCE")
    private String dATASOURCE;
    @JsonProperty("ENTITY_TYPE")
    private String eNTITYTYPE;
    @JsonProperty("DSRC_ACTION")
    private String dSRCACTION;
    @JsonProperty("LENS_CODE")
    private String lENSCODE;
    @JsonProperty("RECORD_ID")
    private String rECORDID;

    @JsonProperty("Global_Actor_ID")
    public String getGlobalActorId() {
        return globalActorId;
    }

    @JsonProperty("Global_Actor_ID")
    public void setGlobalActorId(String globalActorId) {
        this.globalActorId = globalActorId;
    }

    @JsonProperty("NAMES")
    public List<Name> getNames() {
        return names;
    }

    @JsonProperty("NAMES")
    public void setNAMES(List<Name> names) {
        this.names = names;
    }

    @JsonProperty("GENDER")
    public String getGender() {
        return gender;
    }

    @JsonProperty("GENDER")
    public void setGender(String gender) {
        this.gender = gender;
    }

    @JsonProperty("DATE_OF_BIRTH")
    public String getDob() {
        return dob;
    }

    @JsonProperty("DATE_OF_BIRTH")
    public void setDob(String dob) {
        this.dob = dob;
    }

    @JsonProperty("SUBSCRIBER_RELATIONSHIP_TYPE")
    public String getSUBSCRIBERRELATIONSHIPTYPE() {
        return sUBSCRIBERRELATIONSHIPTYPE;
    }

    @JsonProperty("SUBSCRIBER_RELATIONSHIP_TYPE")
    public void setSUBSCRIBERRELATIONSHIPTYPE(String sUBSCRIBERRELATIONSHIPTYPE) {
        this.sUBSCRIBERRELATIONSHIPTYPE = sUBSCRIBERRELATIONSHIPTYPE;
    }

    @JsonProperty("IDENTIFIERS")
    public List<Identifier> getIdentifiers() {
        return identifiers;
    }

    @JsonProperty("IDENTIFIERS")
    public void setIDENTIFIERS(List<Identifier> identifiers) {
        this.identifiers = identifiers;
    }

    @JsonProperty("PHONES")
    public List<Phone> getPHONES() {
        return pHONES;
    }

    @JsonProperty("PHONES")
    public void setPHONES(List<Phone> pHONES) {
        this.pHONES = pHONES;
    }

    @JsonProperty("ADDRESSES")
    public List<Address> getAddresses() {
        return addresses;
    }

    @JsonProperty("ADDRESSES")
    public void setAddresses(List<Address> addresses) {
        this.addresses = addresses;
    }

    @JsonProperty("DATA_SOURCE")
    public String getDATASOURCE() {
        return dATASOURCE;
    }

    @JsonProperty("DATA_SOURCE")
    public void setDATASOURCE(String dATASOURCE) {
        this.dATASOURCE = dATASOURCE;
    }

    @JsonProperty("ENTITY_TYPE")
    public String getENTITYTYPE() {
        return eNTITYTYPE;
    }

    @JsonProperty("ENTITY_TYPE")
    public void setENTITYTYPE(String eNTITYTYPE) {
        this.eNTITYTYPE = eNTITYTYPE;
    }

    @JsonProperty("DSRC_ACTION")
    public String getDSRCACTION() {
        return dSRCACTION;
    }

    @JsonProperty("DSRC_ACTION")
    public void setDSRCACTION(String dSRCACTION) {
        this.dSRCACTION = dSRCACTION;
    }

    @JsonProperty("LENS_CODE")
    public String getLENSCODE() {
        return lENSCODE;
    }

    @JsonProperty("LENS_CODE")
    public void setLENSCODE(String lENSCODE) {
        this.lENSCODE = lENSCODE;
    }

    @JsonProperty("RECORD_ID")
    public String getRECORDID() {
        return rECORDID;
    }

    @JsonProperty("RECORD_ID")
    public void setRECORDID(String rECORDID) {
        this.rECORDID = rECORDID;
    }


    @Override
    public String toString() {
        return "OriginalSourceData{" +
                "globalActorId='" + globalActorId + '\'' +
                ", names=" + names +
                ", gender='" + gender + '\'' +
                ", dob='" + dob + '\'' +
                ", sUBSCRIBERRELATIONSHIPTYPE='" + sUBSCRIBERRELATIONSHIPTYPE + '\'' +
                ", identifierContexts=" + identifiers +
                ", pHONES=" + pHONES +
                ", addresses=" + addresses +
                ", dATASOURCE='" + dATASOURCE + '\'' +
                ", eNTITYTYPE='" + eNTITYTYPE + '\'' +
                ", dSRCACTION='" + dSRCACTION + '\'' +
                ", lENSCODE='" + lENSCODE + '\'' +
                ", rECORDID='" + rECORDID + '\'' +
                '}';
    }
}