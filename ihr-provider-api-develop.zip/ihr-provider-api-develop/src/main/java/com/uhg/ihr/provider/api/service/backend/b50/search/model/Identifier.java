package com.uhg.ihr.provider.api.service.backend.b50.search.model;

public enum Identifier {
    CARDHOLDER_ID,
    MEDICARE_BENF_ID,
    MEDICARE_NUMBER,
    MEDICAID_NUMBER,
    ALT_MEMBER_ID,
    SSN_NUMBER,
    SUBSCRIBER_ID,
    SEARCH_ID,
    GLOBAL_ACTOR_ID,
    NPI_ID,
    PORTAL_ID,

    EID,
    SSN,
    MBI,
    UHCCDB_FAMILY_ID,
    CDB_CONSUMER_ID,
    HCID,
    HICN
}