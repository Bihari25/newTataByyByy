package com.uhg.ihr.provider.api.exception;

public class UnhandledApiException extends RuntimeException {
    public UnhandledApiException() {

    }

    public UnhandledApiException(String message) {
        super(message);
    }

    public UnhandledApiException(Throwable cause) {
        super(cause);
    }

    public UnhandledApiException(String message, Throwable cause) {
        super(message, cause);
    }
}
