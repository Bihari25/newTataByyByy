package com.uhg.ihr.provider.api.exception;

public class DobException extends RuntimeException {
    public DobException(String message) {
        super(message);
    }
}
