package com.uhg.ihr.provider.api.filter;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.node.ArrayNode;
import com.fasterxml.jackson.databind.node.JsonNodeFactory;
import com.uhg.ihr.provider.api.util.AppUtils;
import io.micronaut.core.util.CollectionUtils;
import lombok.extern.slf4j.Slf4j;

import javax.inject.Singleton;
import java.util.Arrays;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;

/**
 * DataClassesFilter class used to filter data classes category objects based on given filtering criteria, So that payload data get filtered content.
 *
 * @author ihr extract engineering team.
 * @CopyRight (C) All rights reserved to UHG Inc. It's Illegal to reproduce this code.
 */
@Slf4j
@Singleton
public class DataClassesFilter {

    /**
     * Method to filter data classes content using user defined filter criteria.
     *
     * @param dataFilters
     * @param dataClassesPayload
     * @return LinkedHashMap
     */
    public LinkedHashMap<String, JsonNode> filterDataClassesContent(LinkedHashMap<String, JsonNode> dataClassesPayload,
                                                                    List<DataFilter> dataFilters) {

        LinkedHashMap<String, JsonNode> filteredContent;

        /* Validate filters are provided or not. */
        if (CollectionUtils.isEmpty(dataFilters)) {
            filteredContent = dataClassesPayload;
        } else {
            /* Apply filter criteria to filter data classes data. */
            filteredContent = dataClassesFilteringByCriteria(dataClassesPayload, dataFilters);
        }

        return filteredContent;
    }


    /**
     * Method to filter data classes content by criteria.
     *
     * @param dataFilters
     * @param dataClassesPayload
     * @return LinkedHashMap
     */
    public LinkedHashMap<String, JsonNode> dataClassesFilteringByCriteria(LinkedHashMap<String, JsonNode> dataClassesPayload, List<DataFilter> dataFilters) {
        if (Objects.nonNull(dataClassesPayload)) {
            for (Map.Entry<String, JsonNode> dataClass : dataClassesPayload.entrySet()) {

                /* Validate and apply filters only for defined data classes which have data. */
                if (getCrdFilters().contains(dataClass.getKey()) && dataClass.getValue().size() > 0) {

                    /* Computed filtered data. */
                    ArrayNode filteredData = filterDataByCriteria(dataClass.getValue(), dataFilters);
                    dataClassesPayload.put(dataClass.getKey(), filteredData);
                }
            }
        }

        return dataClassesPayload;
    }

    /**
     * Method to filter data in data classes using filter criteria.
     *
     * @param dataNode
     * @param dataFilters
     * @return ArrayNode
     */
    @SuppressWarnings("unchecked")
    public ArrayNode filterDataByCriteria(JsonNode dataNode, List<DataFilter> dataFilters) {
        ArrayNode nodes = (ArrayNode) dataNode;
        ArrayNode computedNodes = new ArrayNode(JsonNodeFactory.instance);

        /* Filter data classes content. */
        for (JsonNode jsonNode : nodes) {
            boolean isValidFilter = false;

            /* Iterate over the data filters and validate all filters are valid or not.*/
            for (DataFilter dataFilter : dataFilters) {
                isValidFilter = dataFilter.filter(jsonNode);

                /* Id any given filters not valid break out of the loop. */
                if (!isValidFilter) {
                    break;
                }
            }
            /* Collect the nodes which matches all all given filter criteria.*/
            if (isValidFilter) {
                computedNodes.add(jsonNode);
            }
        }

        return computedNodes;
    }

    /*
     * Method to lookup for clinical relevant date (CRD) classes to apply filter.
     *
     * @return List
     */
    private List<String> getCrdFilters() {
        List<String> crdFilters = Arrays.asList(AppUtils.CRD_FILTER_CLASSES.split("\\s*,\\s*"));
        return crdFilters;
    }

}
