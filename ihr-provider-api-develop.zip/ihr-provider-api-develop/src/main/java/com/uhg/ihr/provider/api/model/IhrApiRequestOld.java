package com.uhg.ihr.provider.api.model;

import com.fasterxml.jackson.annotation.JsonAlias;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.uhg.ihr.provider.api.validator.ValidLanguage;
import com.uhg.ihr.provider.api.validator.ValidRecordType;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.validation.Valid;
import javax.validation.constraints.NotBlank;
import javax.validation.constraints.NotNull;
import java.util.Set;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class IhrApiRequestOld {

    @JsonProperty
    @NotBlank(message = "The request could not be validated. A correlation id was not provided.")
    private String correlationId;

    @JsonProperty
    @ValidLanguage(message = "The request could not be validated. An invalid language was provided.")
    private String language;

    /** Used to handle 1.0 = mbrID and 2.0+ = mbrId request. */
    @JsonAlias({"mbrID", "mbrId"})
    @NotNull(message = "The member id record may not be null.")
    @Valid
    private MId mbrId;

    @JsonProperty
    @NotBlank(message = "The request could not be validated. An actor chid was not provided.")
    private String chid;

    @JsonProperty
    @Valid
    private Set<FilterPair> dataFilters;

    @JsonProperty
    @ValidRecordType(message = "The request could not be validated. A data class was not provided.")
    private Set<RecordType> dataClasses;
}