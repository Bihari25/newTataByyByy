package com.uhg.ihr.medispan.dib.loaders;

/**
*
*/
public class Mmwiptdesc extends TableLoader {
    
	/**
	 *
	 */
    public Mmwiptdesc() {
        super();
    }
    
    @Override
    public String getCreateQuery() {
        return
        "CREATE TABLE mmw_ipt_desc " +
        "( " +
            "ppid                        CHARACTER VARYING(20) NOT NULL, " +
            "startdate                   CHARACTER VARYING(8) NOT NULL, " +
            "textid                      INTEGER NOT NULL, " +
            "CONSTRAINT mmw_ipt_desc_pkey PRIMARY KEY (ppid, startdate, textid) " +
        ") " +
        "WITH (OIDS=TRUE); ";
    }
    
    @Override
    public String getInsertQuery(String line) {
        String[] fields = line.split("\\|");
        
        return "INSERT INTO mmw_ipt_desc VALUES " +
        "( " +
            "'" + fields[0] + "'," +            //ppid          CHARACTER VARYING(20) NOT NULL
            "'" + fields[1] + "'," +            //startdate     CHARACTER VARYING(8) NOT NULL
            Integer.parseInt(fields[2]) +       //textid        INTEGER NOT NULL
        " ); ";
    }

}
