package com.uhg.ihr.provider.api.exception;

import io.micronaut.context.annotation.Requires;
import io.micronaut.http.HttpRequest;
import io.micronaut.http.HttpResponse;
import io.micronaut.http.annotation.Produces;
import io.micronaut.http.server.exceptions.ExceptionHandler;
import lombok.extern.slf4j.Slf4j;

import javax.inject.Singleton;

@Slf4j
@Produces
@Singleton
@Requires(classes = {ContentExistsException.class, ExceptionHandler.class})
public class ContentExistsExceptionHandler implements ExceptionHandler<ContentExistsException, HttpResponse> {

    @Override
    public HttpResponse handle(HttpRequest request, ContentExistsException exception) {
        return HttpResponse.noContent();
    }
}
