package com.uhg.ihr.medispan.dib.loaders;

/**
*
*/
public class Mmwddatext extends TableLoader {
    
	/**
	 *
	 */
    public Mmwddatext() {
        super();
    }
    
    @Override
    public String getCreateQuery() {
        return
        "CREATE TABLE mmw_dda_text " + 
        "( " +
            "textid              INTEGER NOT NULL, " +
            "linenumber          INTEGER NOT NULL, " +
            "linetext            CHARACTER VARYING(140) NOT NULL, " +
            "formatcode          CHARACTER VARYING(2) NOT NULL, " +
            "CONSTRAINT mmw_dda_text_pkey PRIMARY KEY (textid,linenumber) " + 
        ") " +
        "WITH (OIDS=TRUE); ";
    }
    
    @Override
    public String getInsertQuery(String line) {
        String[] fields = line.split("\\|");
        
        return "INSERT INTO mmw_dda_text VALUES " +
        "( " +
            Integer.parseInt(fields[0]) + "," +     //textid              INTEGER NOT NULL
            Integer.parseInt(fields[1]) + "," +     //linenumber          INTEGER NOT NULL
            "'" + fields[2].replace("'", "''") + "'," +                //linetext            CHARACTER VARYING(140) NOT NULL
            "'" + fields[3] + "'" +                 //formatcode          CHARACTER VARYING(2) NOT NULL 
        " ); ";
    }

}
