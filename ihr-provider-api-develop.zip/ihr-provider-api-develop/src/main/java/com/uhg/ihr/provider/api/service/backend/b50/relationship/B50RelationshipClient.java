package com.uhg.ihr.provider.api.service.backend.b50.relationship;

import com.fasterxml.jackson.databind.JsonNode;
import com.uhg.ihr.provider.api.service.backend.b50.relationship.model.B50RelationshipRequest;
import io.micronaut.http.HttpHeaders;
import io.micronaut.http.MediaType;
import io.micronaut.http.annotation.Body;
import io.micronaut.http.annotation.Header;
import io.micronaut.http.annotation.Headers;
import io.micronaut.http.annotation.Post;
import io.micronaut.http.client.annotation.Client;
import io.reactivex.Maybe;

@Client(id = "b50-relationship")
@Headers({
        @Header(name = HttpHeaders.CONTENT_TYPE, value = MediaType.APPLICATION_JSON),
        @Header(name = HttpHeaders.ACCEPT, value = MediaType.APPLICATION_JSON)
})
public interface B50RelationshipClient {
    @Post(uri = "/v${b50-api.version}/actors/patients")
    Maybe<JsonNode> manageRelationship(@Header String authorization, @Body B50RelationshipRequest request,
                                       @Header("optum-cid-ext") String correlationId,
                                       @Header String acceptLanguage);
}
