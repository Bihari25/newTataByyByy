package com.uhg.ihr.medispan.dib.loaders;

/**
*
*/
public class Mmwmed extends TableLoader {
    
	/**
	 *
	 */
    public Mmwmed() {
        super();
    }
    
    @Override
    public String getCreateQuery() {
        return
        "CREATE TABLE mmw_med " +
        "( " +
            "mcid                        INTEGER NOT NULL, " +
            "primaryprofname             CHARACTER VARYING(58) NOT NULL, " +
            "primarypatname              CHARACTER VARYING(58) NOT NULL, " +
            "typecode                    CHARACTER VARYING(2) NOT NULL, " +
            "classonlyind                SMALLint NOT NULL, " +
            "gendercode                  CHARACTER VARYING(1) NOT NULL, " +
            "pregnancyind                SMALLINT NOT NULL, " +
            "lactationind                SMALLINT NOT NULL, " +
            "ageindayslow                integer NOT NULL, " +
            "ageindayshigh               integer NOT NULL, " +
            "durationcode                CHARACTER VARYING(2) NOT NULL, " +
            "haschildrenind              SMALLINT NOT NULL, " +
            "drugstotreatind             SMALLINT NOT NULL, " +
            "drugstoavoidind             SMALLINT NOT NULL, " +
            "drugsthatcauseind           SMALLINT NOT NULL, " +
            "CONSTRAINT mmw_med_pkey PRIMARY KEY (mcid) " +
        ") " +
        "WITH (OIDS=TRUE); ";
    }
    
    @Override
    public String getInsertQuery(String line) {
        String[] fields = line.split("\\|");
        
        return "INSERT INTO mmw_med VALUES " +
        "( " +
            Integer.parseInt(fields[0]) + "," +     //mcid                        INTEGER NOT NULL
            "'" + fields[1].replace("'", "''") + "'," +                //primaryprofname             CHARACTER VARYING(58) NOT NULL
            "'" + fields[2].replace("'", "''") + "'," +                //primarypatname              CHARACTER VARYING(58) NOT NULL
            "'" + fields[3] + "'," +                //typecode                    CHARACTER VARYING(2) NOT NULL
            Integer.parseInt(fields[4]) + "," +     //classonlyind                SMALLint NOT NULL
            "'" + fields[5] + "'," +                //gendercode                  CHARACTER VARYING(1) NOT NULL
            Integer.parseInt(fields[6]) + "," +     //pregnancyind                SMALLINT NOT NULL
            Integer.parseInt(fields[7]) + "," +     //lactationind                SMALLINT NOT NULL
            Integer.parseInt(fields[8]) + "," +     //ageindayslow                integer NOT NULL
            Integer.parseInt(fields[9]) + "," +     //ageindayshigh               integer NOT NULL
            "'" + fields[10] + "'," +               //durationcode                CHARACTER VARYING(2) NOT NULL
            Integer.parseInt(fields[11]) + "," +    //haschildrenind              SMALLINT NOT NULL
            Integer.parseInt(fields[12]) + "," +    //drugstotreatind             SMALLINT NOT NULL
            Integer.parseInt(fields[13]) + "," +    //drugstoavoidind             SMALLINT NOT NULL
            Integer.parseInt(fields[14]) +          //drugsthatcauseind           SMALLINT NOT NULL
        " ); ";
    }

}
