package com.uhg.ihr.provider.api.service.backend.senzing;

/**
 * SenzingLookup  class used to hold look up keys from yml/yaml file to read senzing response
 * and cherry pick the values.
 *
 * @author ihr extract engineering team.
 * @CopyRight (C) All rights reserved to UHG Inc. It's Illegal to reproduce this code.
 */
public class SenzingLookup {
    public static final int INDICATOR_LEVEL_1 = 1;
    public static final int INDICATOR_LEVEL_2 = 2;
    public static final String DATA = "data";
    public static final String LOG_RESULTS = "logResults";
    public static final String SEARCH_RESULTS = "searchResults";
    public static final String FILTERED_IHR_IDS = "filteredIhrIds";
    public static final String IDENTIFIER_DATA = "identifierData";
    public static final String B50_CHID = "GLOBAL_ACTOR_ID";
    public static final String MATCH_LEVEL = "matchLevel";
    public static final String MATCH_KEY = "matchKey";
    public static final String RECORD_SUMMARIES = "recordSummaries";
    public static final String RECORD_COUNT = "recordCount";
}