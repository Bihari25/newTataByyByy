package com.uhg.ihr.medispan.dib.loaders;

/**
*
*/
public class Mmwdckdruglink extends TableLoader {
    
	/**
	 *
	 */
    public Mmwdckdruglink() {
        super();
    }
    
    @Override
    public String getCreateQuery() {
        return
        "CREATE TABLE mmw_dck_druglink " +
        "( " +
            "gpi                         CHARACTER VARYING(14) NOT NULL, " +
            "ageindayslow                INTEGER NOT NULL, " +
            "ageindayshigh               INTEGER NOT NULL, " +
            "doseformlow                 NUMERIC(6,2) NOT NULL, " +
            "doseformhigh                NUMERIC(6,2) NOT NULL, " +
            "doseformusual               NUMERIC(6,2) NULL, " +
            "singledosehigh              NUMERIC(6,2) NULL, " +
            "durationlow                 SMALLINT NOT NULL, " +
            "durationhigh                SMALLINT NULL, " +
            "durationusual               SMALLINT NULL, " +
            "referencecode               CHARACTER VARYING(3) NOT NULL, " +
            "CONSTRAINT mmw_dck_druglink_pkey PRIMARY KEY (gpi, ageindayslow, ageindayshigh) " +
        ") " +
        "WITH (OIDS=TRUE); ";
    }
    
    @Override
    public String getInsertQuery(String line) {
        String[] fields = line.split("\\|");
        
        return "INSERT INTO mmw_dck_druglink VALUES " +
        "( " +
            "'" + fields[0] + "'," +                //gpi                   CHARACTER VARYING(14) NOT NULL
            Integer.parseInt(fields[1]) + "," +     //ageindayslow          INTEGER NOT NULL
            Integer.parseInt(fields[2]) + "," +     //ageindayshigh         INTEGER NOT NULL
            Float.parseFloat(fields[3]) + "," +     //doseformlow           NUMERIC(6,2) NOT NULL
            Float.parseFloat(fields[4]) + "," +     //doseformhigh          NUMERIC(6,2) NOT NULL
            (fields[5].isEmpty() ? "NULL" : Float.parseFloat(fields[5])) + "," +     //doseformusual         NUMERIC(6,2) NULL
            (fields[6].isEmpty() ? "NULL" : Float.parseFloat(fields[6])) + "," +     //singledosehigh        NUMERIC(6,2) NULL
            Integer.parseInt(fields[7]) + "," +     //durationlow           SMALLINT NOT NULL
            (fields[8].isEmpty() ? "NULL" : Integer.parseInt(fields[8])) + "," +     //durationhigh          SMALLINT NULL
            (fields[9].isEmpty() ? "NULL" : Integer.parseInt(fields[9])) + "," +     //durationusual         SMALLINT NULL
            "'" + fields[10] + "'" +                //referencecode         CHARACTER VARYING(3) NOT NULL
        " ); ";
    }

}
