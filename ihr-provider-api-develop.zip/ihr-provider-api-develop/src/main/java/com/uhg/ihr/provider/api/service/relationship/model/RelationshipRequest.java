package com.uhg.ihr.provider.api.service.relationship.model;

import com.uhg.ihr.provider.api.exception.UnhandledApiException;
import com.uhg.ihr.provider.api.model.IhrApiWithActorRequest;
import com.uhg.ihr.provider.api.validator.ValidDate;
import lombok.*;
import lombok.extern.slf4j.Slf4j;

import javax.validation.constraints.NotNull;
import java.text.ParseException;
import java.time.Instant;
import java.util.Date;
import java.util.concurrent.TimeUnit;

import static com.uhg.ihr.provider.api.util.AppUtils.DATE_FORMATTER;

@Slf4j
@Data
@Builder(toBuilder = true)
@NoArgsConstructor
@AllArgsConstructor
@EqualsAndHashCode(callSuper = false)
public class RelationshipRequest extends IhrApiWithActorRequest {

    private static final int DEFAULT_END_DATE_OFFSET = 2;

    @NotNull
    private RelationshipRole providerRole;
    @ValidDate
    private String effectiveDate;
    @ValidDate
    private String terminationDate;

    public String getEffectiveDate() {
        if (this.effectiveDate == null) {
            initEffectiveDate();
        }
        return this.effectiveDate;
    }

    public String getTerminationDate() {
        if (this.terminationDate == null) {
            initEndDate();
        }
        return this.terminationDate;
    }

    private void initEffectiveDate() {
        if (this.terminationDate == null) {
            this.terminationDate = buildDate(DEFAULT_END_DATE_OFFSET);
            this.effectiveDate = buildDate(0);
        } else {
            try {
                long endDate = DATE_FORMATTER.parse(terminationDate).toInstant().toEpochMilli();
                long today = Instant.now().toEpochMilli();
                this.effectiveDate = today - endDate > 0 ? this.terminationDate : buildDate(0);
            } catch (ParseException e) {
                throw new UnhandledApiException(e);
            }
        }
    }

    private void initEndDate() {
        if (this.effectiveDate == null) {
            this.effectiveDate = buildDate(0);
            this.terminationDate = buildDate(2);
        } else {
            try {
                long effectiveDate = DATE_FORMATTER.parse(this.effectiveDate).toInstant().toEpochMilli();
                long timeDifference = effectiveDate - Instant.now().toEpochMilli();
                this.terminationDate = timeDifference < 0 ? buildDate(0) : buildDate(effectiveDate, DEFAULT_END_DATE_OFFSET);
            } catch (ParseException e) {
                throw new UnhandledApiException(e);
            }
        }
    }

    private String buildDate(long dayOffset) {
        return buildDate(System.currentTimeMillis(), dayOffset);
    }

    private String buildDate(long startTimeMilli, long dayOffset) {
        return DATE_FORMATTER.format(new Date(startTimeMilli + TimeUnit.DAYS.toMillis(dayOffset)));
    }
}
