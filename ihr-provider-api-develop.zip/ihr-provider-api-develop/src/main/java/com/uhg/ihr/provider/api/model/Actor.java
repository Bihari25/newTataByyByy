/**
 * Copyright (C) 2020 UnitedHealth Group
 * <p>
 * All rights reserved.
 */
package com.uhg.ihr.provider.api.model;

import com.fasterxml.jackson.annotation.JsonIgnore;
import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.validation.constraints.NotNull;

/**
 * Represents an API actor of the end user actor that is performing a request.
 *
 * @author Kristopher T Babic
 * @version 1.0
 */
@Data
@NoArgsConstructor
@AllArgsConstructor
@JsonIgnoreProperties(ignoreUnknown = true)
@JsonInclude(JsonInclude.Include.NON_NULL)
public class Actor {
    @JsonProperty
    @NotNull(message = "The actor in the request body must contain an id")
    private ActorId id;

    @JsonProperty
    private ActorId onBehalfOf;

    @JsonIgnore
    public ActorId getOnBehalfOf() {
        return onBehalfOf == null
                ? id
                : onBehalfOf;
    }

    /**
     * Returns the current active ID for this Actor object.
     */
    @JsonIgnore
    public String getActiveId() {
        ActorId actorId = getOnBehalfOf();
        if (actorId != null) {
            return actorId.getId();
        }
        return null;
    }


    @JsonIgnore
    public String getPrimaryId(){
        if (id != null) {
            return id.getId();
        }
        return null;
    }
}
