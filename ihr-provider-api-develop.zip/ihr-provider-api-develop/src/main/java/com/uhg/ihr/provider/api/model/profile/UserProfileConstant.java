package com.uhg.ihr.provider.api.model.profile;

public interface UserProfileConstant {
    enum AgreementType {
        TERMS_OF_USE
    }
    enum SYSTEM {
        DEV, TST, QA
    }
    enum SECURED_CONTEXT {
        ESSO, LINK
    }
    enum ROLE_CONTEXT {
        PORTAL, IHR
    }

    enum IDENTIFIER_CONTEXT {
        PORTAL, IHR
    }

    enum STATUS {
        ACTIVE, INACTIVE
    }

    enum USER_TYPE {
        STAFF, PROVIDER, INDIVIDUAL
    }
}
