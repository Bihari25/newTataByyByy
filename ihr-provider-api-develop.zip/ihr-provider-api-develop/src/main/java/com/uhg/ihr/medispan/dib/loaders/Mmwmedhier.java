package com.uhg.ihr.medispan.dib.loaders;

/**
*
*/
public class Mmwmedhier extends TableLoader {
    
	/**
	 *
	 */
    public Mmwmedhier() {
        super();
    }
    
    @Override
    public String getCreateQuery() {
        return
        "CREATE TABLE mmw_med_hier " +
        "( " +
            "mcid                        INTEGER NOT NULL, " +
            "parentid                    INTEGER NOT NULL, " +
            "relationtypecode            CHARACTER VARYING(2) NOT NULL, " +
            "CONSTRAINT mmw_med_hier_pkey PRIMARY KEY (mcid, parentid) " +
        ") " +
        "WITH (OIDS=TRUE); ";
    }
    
    @Override
    public String getInsertQuery(String line) {
        String[] fields = line.split("\\|");
        
        return "INSERT INTO mmw_med_hier VALUES " +
        "( " +
            Integer.parseInt(fields[0]) + "," +     //mcid                  INTEGER NOT NULL
            Integer.parseInt(fields[1]) + "," +     //parentid              INTEGER NOT NULL
            "'" + fields[2] + "'" +                 //relationtypecode      CHARACTER VARYING(2) NOT NULL
        " ); ";
    }

}
