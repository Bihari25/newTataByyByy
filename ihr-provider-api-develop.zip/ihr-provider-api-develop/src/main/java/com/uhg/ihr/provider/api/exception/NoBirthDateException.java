package com.uhg.ihr.provider.api.exception;

public class NoBirthDateException extends DobException {
    public NoBirthDateException(String message) {
        super(message);
    }
}
