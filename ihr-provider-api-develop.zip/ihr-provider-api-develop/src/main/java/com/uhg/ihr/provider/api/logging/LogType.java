package com.uhg.ihr.provider.api.logging;

public enum LogType {
    audit,
    api
}
