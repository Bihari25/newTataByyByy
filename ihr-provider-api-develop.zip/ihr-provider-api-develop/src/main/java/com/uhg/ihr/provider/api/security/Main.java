package com.uhg.ihr.provider.api.security;

import com.optum.cloudsdk.crypto.CryptoFacadePBE;
import com.uhg.ihr.provider.api.service.backend.b50.search.model.B50SearchRequest;
import com.uhg.ihr.provider.api.util.AppUtils;
import org.apache.commons.cli.*;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.io.File;
import java.net.URL;
import java.util.Arrays;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;
/**
 * 
 * Usage need to pass 
 * -e for encryption 
 * -d for decryption
 * -v for value to be encrypted or decrypted
 * 
 * we must send either -e or -d and -v options while running the program.
 * encypted or decrypted value get printed on the console
 *
 */

public class Main {
    private static final Logger LOGGER = LoggerFactory.getLogger(Main.class);


    private static final CryptoFacadePBE FACADE;

    static {
        File crytpoFile = AppUtils.findRelativeOrAbsoluteFilePath("/configs/restcrypto.properties");
        String name = null;
        if (crytpoFile != null) {
            name = crytpoFile.getAbsolutePath();
        } else {
            URL url = Main.class.getClassLoader().getResource("restcrypto.properties");
            if (url != null) {
                name = url.getPath();
            }
        }
        FACADE = new CryptoFacadePBE(name);

    }

    public static void main(String[] args) {
        B50SearchRequest r1 = new B50SearchRequest();
        r1.setFirstName("George");
        r1.setLastName("Thompson");
        r1.setDateOfBirth("1928-03-20");

        B50SearchRequest r2 = new B50SearchRequest();
        r2.setFirstName("George");
        r2.setLastName("Thompson");
        r2.setDateOfBirth("1929-03-20");

        System.out.println("r1.hash: "+r1.hashCode());
        System.out.println("r2.hash: "+r2.hashCode());

        String providerId="400ACTO912564929874013544";

        System.out.println("r1: "+(providerId.hashCode()^r1.hashCode()));
        System.out.println("r2: "+(providerId.hashCode()^r2.hashCode()));

        Map.Entry<String, Object> m1 = Map.entry(providerId, r1);
        Map.Entry<String, Object> m2 = Map.entry(providerId, r2);

        System.out.println("m1.hash: "+m1.hashCode());
        System.out.println("m2.hash: "+m2.hashCode());

        if (true) return;
        Options options = new Options();


        Option encrypt = new Option("e", "option to encrypt");
        encrypt.setRequired(false);
        options.addOption(encrypt);

        Option value = new Option("v", "value", true, "Value to encrypt or decrypt");
        value.setRequired(true);
        options.addOption(value);

        Option decrypt = new Option("d", "option to decrypt");
        decrypt.setRequired(false);
        options.addOption(decrypt);

        Option version = new Option("n", "option to choose the version");
        version.setRequired(false);
        options.addOption(version);

        CommandLineParser parser = new DefaultParser();
        HelpFormatter formatter = new HelpFormatter();
        CommandLine cmd;

        try {
            cmd = parser.parse(options, args);

            Option[] options2 = cmd.getOptions();

            String encryptOpt = null;
            String decryptOpt = null;


            List<Option> optionsList = Arrays.asList(options2);
            List<String> inputOptions = optionsList.stream().map(o -> o.getOpt()).collect(Collectors.toList());


            boolean newVersion = false;

            if (!(inputOptions.size() == 2)) {
                throw new ParseException("Input parameters options should be  2, one is e or d and other is v ");
            }

            if (inputOptions.contains("e") && inputOptions.contains("d")) {
                throw new ParseException("either encrypt or decrypt is allowed");
            }


            for (String opt : inputOptions) {
                if (opt.equals("e")) {
                    encryptOpt = "e";
                    break;
                }

                if (opt.equals("d")) {
                    decryptOpt = "d";
                    break;
                }

                if (opt.equals("n")) {
                    newVersion = true;
                    break;
                }
            }

            String valueOpt = cmd.getOptionValue("value");


            if (newVersion) {
                newVersion(decryptOpt, encryptOpt, valueOpt);
            } else {
                oldVersion(decryptOpt, encryptOpt, valueOpt);
            }


        } catch (ParseException e) {
            LOGGER.error("Could not parse the input parameters", e);
            formatter.printHelp("encryptORdecrypt", options);
        }
    }

    private static void newVersion( String decryptOpt, String encryptOpt, String valueOpt) {

    }

    private static void oldVersion( String decryptOpt, String encryptOpt, String valueOpt) {
        String encryptString = null;
        if (encryptOpt != null) {
            encryptString = FACADE.encryptString(valueOpt);
            System.out.println("encryptString :::" + encryptString);
        }

        String decryptString = null;
        if (decryptOpt != null) {
            decryptString = FACADE.decryptString(valueOpt);
            System.out.println("decryptString :::" + decryptString);
        }
    }

}
