package com.uhg.ihr.medispan.dib.loaders;

/**
*
*/
public class Mmwmonotext extends TableLoader {
    
	/**
	 *
	 */
    public Mmwmonotext() {
        super();
    }
    
    @Override
    public String getCreateQuery() {
        return
        "CREATE TABLE mmw_mono_text " +
        "( " +
            "versioncode                 CHARACTER VARYING(10) NOT NULL, " +
            "categorycode                CHARACTER VARYING(10) NOT NULL, " +
            "monoid                      CHARACTER VARYING(20) NOT NULL, " +
            "sequencenumber              SMALLINT NOT NULL, " +
            "sectioncode                 CHARACTER VARYING(1) NOT NULL, " +
            "formatcode                  CHARACTER VARYING(1) NOT NULL, " +
            "linetext                    CHARACTER VARYING(255) NOT NULL, " +
            "CONSTRAINT mmw_mono_text_pkey PRIMARY KEY (versioncode, categorycode, monoid, sequencenumber) " +
        ") " +
        "WITH (OIDS=TRUE); ";
    }
    
    @Override
    public String getInsertQuery(String line) {
        String[] fields = line.split("\\|");
        
        return "INSERT INTO mmw_mono_text VALUES " +
        "( " +
            "'" + fields[0] + "'," +                //versioncode                 CHARACTER VARYING(10) NOT NULL
            "'" + fields[1] + "'," +                //categorycode                CHARACTER VARYING(10) NOT NULL
            "'" + fields[2] + "'," +                //monoid                      CHARACTER VARYING(20) NOT NULL
            Integer.parseInt(fields[3]) + "," +     //sequencenumber              SMALLINT NOT NULL
            "'" + fields[4] + "'," +                //sectioncode                 CHARACTER VARYING(1) NOT NULL
            "'" + fields[5] + "'," +                //formatcode                  CHARACTER VARYING(1) NOT NULL
            "'" + fields[6].replace("'", "''") + "'" +                 //linetext                    CHARACTER VARYING(255) NOT NULL
        " ); ";
    }

}
