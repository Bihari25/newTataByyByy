package com.uhg.ihr.provider.api.service.security.model;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.uhg.ihr.provider.api.model.profile.UserGroup;
import com.uhg.ihr.provider.api.model.profile.UserRole;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.validation.Valid;
import java.util.List;

@Data
@NoArgsConstructor
@AllArgsConstructor
@JsonInclude(JsonInclude.Include.NON_EMPTY)
public class SecurityObjectsMongo {
    @Valid
    private List<UserRole> roles;
    @Valid
    private List<UserGroup> groups;
}
