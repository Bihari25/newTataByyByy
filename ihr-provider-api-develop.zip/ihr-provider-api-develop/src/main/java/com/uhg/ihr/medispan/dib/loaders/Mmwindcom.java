package com.uhg.ihr.medispan.dib.loaders;

/**
*
*/
public class Mmwindcom extends TableLoader {
    
	/**
	 *
	 */
    public Mmwindcom() {
        super();
    }
    
    @Override
    public String getCreateQuery() {
        return
        "CREATE TABLE mmw_ind_com " +
        "( " +
            "gpi                         CHARACTER VARYING(14) NOT NULL, " +
            "mcid                        INTEGER NOT NULL, " +
            "restrictionid               INTEGER NOT NULL, " +
            "microorganismid             INTEGER NOT NULL, " +
            "sequencenumber              SMALLINT NOT NULL, " +
            "textid                      integer NOT NULL, " +
            "CONSTRAINT mmw_ind_com_pkey PRIMARY KEY (gpi, mcid, restrictionid, microorganismid, sequencenumber) " +
        ") " +
        "WITH (OIDS=TRUE); ";
    }
    
    @Override
    public String getInsertQuery(String line) {
        String[] fields = line.split("\\|");
        
        return "INSERT INTO mmw_ind_com VALUES " +
        "( " +
            "'" + fields[0] + "'," +                //gpi                   CHARACTER VARYING(14) NOT NULL
            Integer.parseInt(fields[1]) + "," +     //mcid                  INTEGER NOT NULL
            Integer.parseInt(fields[2]) + "," +     //restrictionid         INTEGER NOT NULL
            Integer.parseInt(fields[3]) + "," +     //microorganismid       INTEGER NOT NULL
            Integer.parseInt(fields[4]) + "," +     //sequencenumber        SMALLINT NOT NULL
            Integer.parseInt(fields[5]) +           //textid                integer NOT NULL
        " ); ";
    }

}
