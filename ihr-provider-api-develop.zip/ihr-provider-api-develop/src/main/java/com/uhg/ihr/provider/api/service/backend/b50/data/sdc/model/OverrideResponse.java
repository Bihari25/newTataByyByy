package com.uhg.ihr.provider.api.service.backend.b50.data.sdc.model;

import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder(toBuilder = true)
@NoArgsConstructor
@AllArgsConstructor
@JsonInclude(JsonInclude.Include.NON_EMPTY)
public class OverrideResponse {

    private String sdcOverrideKey;
    private String forProvider;
    private String forPatient;
}
