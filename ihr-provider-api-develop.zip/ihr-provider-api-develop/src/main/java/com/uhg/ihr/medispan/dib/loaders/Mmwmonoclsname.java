package com.uhg.ihr.medispan.dib.loaders;

/**
*
*/
public class Mmwmonoclsname extends TableLoader {
    
	/**
	 *
	 */
    public Mmwmonoclsname() {
        super();
    }
    
    @Override
    public String getCreateQuery() {
        return
        "CREATE TABLE mmw_mono_clsname " +
        "( " +
            "categorycode                CHARACTER VARYING(10) NOT NULL, " +
            "monoid                      CHARACTER VARYING(20) NOT NULL, " +
            "class1name                  CHARACTER VARYING(75) NOT NULL, " +
            "class2name                  CHARACTER VARYING(75) NOT NULL, " +
            "class1foodind               SMALLint NOT NULL, " +
            "CONSTRAINT mmw_mono_clsname_pkey PRIMARY KEY (categorycode, monoid) " +
        ") " +
        "WITH (OIDS=TRUE); ";
    }
    
    @Override
    public String getInsertQuery(String line) {
        String[] fields = line.split("\\|");
        
        return "INSERT INTO mmw_mono_clsname VALUES " +
        "( " +
            "'" + fields[0] + "'," +            //categorycode                CHARACTER VARYING(10) NOT NULL
            "'" + fields[1] + "'," +            //monoid                      CHARACTER VARYING(20) NOT NULL
            "'" + fields[2].replace("'", "''") + "'," +            //class1name                  CHARACTER VARYING(75) NOT NULL
            "'" + fields[3].replace("'", "''") + "'," +            //class2name                  CHARACTER VARYING(75) NOT NULL
            Integer.parseInt(fields[4]) +       //class1foodind               SMALLint NOT NULL
        " ); ";
    }

}
