package com.uhg.ihr.medispan.dib.loaders;

/**
*
*/
public class Mmwddapatientprofile extends TableLoader {
    
	/**
	 *
	 */
    public Mmwddapatientprofile() {
        super();
    }
    
    @Override
    public String getCreateQuery() {
        return
        "CREATE TABLE mmw_dda_patient_profile " + 
        "( " +
            "profileid               CHARACTER VARYING(10) NOT NULL, " +
            "indicationid            INTEGER NOT NULL, " +
            "speccondid              INTEGER NOT NULL, " +
            "agetypecode             CHARACTER VARYING(2) NOT NULL, " +
            "ageindayslow            INTEGER NOT NULL, " +
            "ageindayshigh           INTEGER NOT NULL, " +
            "addagetypecode          CHARACTER VARYING(2) NOT NULL, " +
            "addageindayslow         INTEGER NOT NULL, " +
            "addageindayshigh        INTEGER NOT NULL, " +
            "renalfunctypecode       CHARACTER VARYING(2) NOT NULL, " +
            "renalfunclow            NUMERIC NOT NULL, " + //NUMERIC(8,4)
            "renalfunchigh           NUMERIC NOT NULL, " + //NUMERIC(8,4)
            "renalfuncunit           CHARACTER VARYING(2) NOT NULL, " +
            "weightcatlow            NUMERIC(7,2) NOT NULL, " +
            "weightcathigh           NUMERIC(7,2) NOT NULL, " +
            "weightcatunit           CHARACTER VARYING(2) NOT NULL, " +
            "CONSTRAINT mmw_dda_patient_profile_pkey PRIMARY KEY (profileid) " +
        ") " +
        "WITH (OIDS=TRUE); ";
    }
    
    @Override
    public String getInsertQuery(String line) {
        String[] fields = line.split("\\|");
        
        return "INSERT INTO mmw_dda_patient_profile VALUES " +
        "( " +
            "'" + fields[0] + "'," +                //profileid               CHARACTER VARYING(10) NOT NULL
            Integer.parseInt(fields[1]) + "," +     //indicationid            INTEGER NOT NULL
            Integer.parseInt(fields[2]) + "," +     //speccondid              INTEGER NOT NULL
            "'" + fields[3] + "'," +                //agetypecode             CHARACTER VARYING(2) NOT NULL
            Integer.parseInt(fields[4]) + "," +     //ageindayslow            INTEGER NOT NULL
            Integer.parseInt(fields[5]) + "," +     //ageindayshigh           INTEGER NOT NULL
            "'" + fields[6] + "'," +                //addagetypecode          CHARACTER VARYING(2) NOT NULL
            Integer.parseInt(fields[7]) + "," +     //addageindayslow         INTEGER NOT NULL
            Integer.parseInt(fields[8]) + "," +     //addageindayshigh        INTEGER NOT NULL
            "'" + fields[9] + "'," +                //renalfunctypecode       CHARACTER VARYING(2) NOT NULL
            Float.parseFloat(fields[10]) + "," +    //renalfunclow            NUMERIC(8,4) NOT NULL
            Float.parseFloat(fields[11]) + "," +    //renalfunchigh           NUMERIC(8,4) NOT NULL
            "'" + fields[12] + "'," +               //renalfuncunit           CHARACTER VARYING(2) NOT NULL
            Float.parseFloat(fields[13]) + "," +    //weightcatlow            NUMERIC(7,2) NOT NULL
            Float.parseFloat(fields[14]) + "," +    //weightcathigh           NUMERIC(7,2) NOT NULL
            "'" + fields[15] + "'" +                //weightcatunit           CHARACTER VARYING(2) NOT NULL
        " );";
    }

}
