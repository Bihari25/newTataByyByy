/**
 * Copyright (C) 2020 UnitedHealth Group
 * <p>
 * All rights reserved.
 */
package com.uhg.ihr.provider.api.exception.handler;

import io.micronaut.context.annotation.Requires;
import io.micronaut.http.HttpRequest;
import io.micronaut.http.HttpResponse;
import io.micronaut.http.annotation.Produces;
import io.micronaut.http.server.exceptions.ExceptionHandler;
import io.micronaut.security.authentication.AuthorizationException;

import javax.inject.Singleton;

/**
 * Basic AuthorizationException handler that return an unauthorized response to the client
 * when they fail authorization.
 *
 * @author Kristopher T Babic
 * @version 1.0
 */
@Produces
@Singleton
@Requires(classes = {AuthorizationException.class, ExceptionHandler.class})
public class AuthorizationExceptionHandler implements ExceptionHandler<AuthorizationException, HttpResponse> {
    @Override
    public HttpResponse handle(HttpRequest request, AuthorizationException exception) {
        return HttpResponse.unauthorized();
    }
}
