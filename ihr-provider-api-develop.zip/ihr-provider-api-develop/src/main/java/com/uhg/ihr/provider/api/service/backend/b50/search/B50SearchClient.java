package com.uhg.ihr.provider.api.service.backend.b50.search;

import com.fasterxml.jackson.databind.JsonNode;
import com.uhg.ihr.provider.api.service.backend.b50.B50ApiRetryPredicate;
import com.uhg.ihr.provider.api.service.backend.b50.search.model.B50SearchRequest;
import io.micronaut.http.HttpHeaders;
import io.micronaut.http.MediaType;
import io.micronaut.http.annotation.Body;
import io.micronaut.http.annotation.Header;
import io.micronaut.http.annotation.Headers;
import io.micronaut.http.annotation.Post;
import io.micronaut.http.client.annotation.Client;
import io.micronaut.retry.annotation.CircuitBreaker;
import io.reactivex.Maybe;

@Client(id = "b50-search")
@CircuitBreaker(
        attempts = "${micronaut.http.services.retry.attempts}",
        delay = "${micronaut.http.services.retry.delay}",
        maxDelay = "${micronaut.http.services.retry.max-delay}",
        reset = "${micronaut.http.services.retry.reset}",
        predicate = B50ApiRetryPredicate.class
)
@Headers({
        @Header(name = HttpHeaders.CONTENT_TYPE, value = MediaType.APPLICATION_JSON),
        @Header(name = HttpHeaders.ACCEPT, value = MediaType.TEXT_PLAIN)
})
public interface B50SearchClient {
    @Post(uri = "/v${b50-api.version}/patients/read")
    Maybe<JsonNode> findNewPatients(@Header String authorization, @Body B50SearchRequest searchCriteria,
                                  @Header("optum-cid-ext") String correlationId,
                                  @Header String acceptLanguage);

    @Post(uri = "/v${b50-api.version}/actors/patients/read")
    Maybe<JsonNode> findExistingPatients(@Header String authorization, @Body B50SearchRequest searchCriteria,
                                         @Header("optum-cid-ext") String correlationId,
                                         @Header String acceptLanguage);
}
