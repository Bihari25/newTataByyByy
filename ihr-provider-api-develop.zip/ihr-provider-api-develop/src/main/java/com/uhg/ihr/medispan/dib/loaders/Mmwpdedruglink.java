package com.uhg.ihr.medispan.dib.loaders;

/**
*
*/
public class Mmwpdedruglink extends TableLoader {
    
	/**
	 *
	 */
    public Mmwpdedruglink() {
        super();
    }
    
    @Override
    public String getCreateQuery() {
        return
        "CREATE TABLE mmw_pde_druglink " +
        "( " +
            "gpi                         CHARACTER VARYING(14) NOT NULL, " +
            "versioncode                 CHARACTER VARYING(10) NOT NULL, " +
            "monoid                      CHARACTER VARYING(20) NOT NULL, " +
            "CONSTRAINT mmw_pde_druglink_pkey PRIMARY KEY (gpi, versioncode, monoid) " +
        ") " +
        "WITH (OIDS=TRUE); ";
    }
    
    @Override
    public String getInsertQuery(String line) {
        String[] fields = line.split("\\|");
        
        return "INSERT INTO mmw_pde_druglink VALUES " +
        "( " +
            "'" + fields[0] + "'," +        //gpi               CHARACTER VARYING(14) NOT NULL
            "'" + fields[1] + "'," +        //versioncode       CHARACTER VARYING(10) NOT NULL
            "'" + fields[2] + "'" +         //monoid            CHARACTER VARYING(20) NOT NULL
        " ); ";
    }

}
