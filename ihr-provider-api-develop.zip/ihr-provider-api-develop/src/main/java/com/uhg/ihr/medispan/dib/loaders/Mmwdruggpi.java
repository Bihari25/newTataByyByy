package com.uhg.ihr.medispan.dib.loaders;

/**
*
*/
public class Mmwdruggpi extends TableLoader {
    
	/**
	 *
	 */
    public Mmwdruggpi() {
        super();
    }
    
    @Override
    public String getCreateQuery() {
        return
        "CREATE TABLE mmw_drug_gpi " + 
        "( " +
            "gpi                 CHARACTER VARYING(14) NOT NULL, " +
            "description         CHARACTER VARYING(60) NULL, " +
            "genericddid         INTEGER     NULL, " +
            "dosechekunit        CHARACTER VARYING(20) NULL, " +
            "ddasingleroute      INTEGER     NOT NULL, " +
            "CONSTRAINT mmw_drug_gpi_pkey PRIMARY KEY (gpi) " +
        ") " +
        "WITH (OIDS=TRUE); ";
    }
    
    @Override
    public String getInsertQuery(String line) {
        String[] fields = line.split("\\|");
        
        return "INSERT INTO mmw_drug_gpi VALUES " +
            "( " +
            "'" + fields[0] + "'," +                    //gpi                 CHARACTER VARYING(14) NOT NULL
            "'" + fields[1].replace("'", "''") + "'," +                    //description         CHARACTER VARYING(60) NULL
            (fields[2].isEmpty() ? "NULL" : Integer.parseInt(fields[2])) + "," +        //genericddid         INTEGER     NULL
            (fields[3].isEmpty() ? "NULL" : "'" + fields[3] + "'") + "," +              //dosechekunit        CHARACTER VARYING(20) NULL
            Integer.parseInt(fields[4]) +               //ddasingleroute      INTEGER     NOT NULL
        " ); ";
    }

}
