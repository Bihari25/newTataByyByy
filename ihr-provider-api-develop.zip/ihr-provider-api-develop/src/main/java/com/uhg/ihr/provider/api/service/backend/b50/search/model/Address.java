package com.uhg.ihr.provider.api.service.backend.b50.search.model;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder(toBuilder = true)
@NoArgsConstructor
@AllArgsConstructor
@JsonInclude(JsonInclude.Include.NON_EMPTY)
@JsonPropertyOrder(value = {"ADDR_TYPE","ADDR_LINE1","ADDR_LINE2","ADDR_CITY","ADDR_STATE","ADDR_COUNTRY"})
public class Address {

	@JsonProperty("ADDR_LINE1")
	private String line1;

	@JsonProperty("ADDR_LINE2")
	private String line2;

	@JsonProperty("ADDR_POSTAL_CODE")
	private String postalCode;

	@JsonProperty("ADDR_COUNTRY")
	private String country;

	@JsonProperty("ADDR_STATE")
	private String state;

	@JsonProperty("ADDR_CITY")
	private String city;

	@JsonProperty("ADDR_TYPE")
	private String type;
}