package com.uhg.ihr.provider.api.model;

public enum RecordType {
    //1.0 only record types
    ACTIVE_ADVERSE_REACTION,
    ACTIVE_HEALTH_CONDITION,
    ACTIVE_HEALTH_DEVICE,
    CURRENT_HEALTH_MEDICATION,
    HEALTH_MOTIVATION_SCORE,
    PAST_HEALTH_CONDITION,
    PAST_HEALTH_MEDICATION,
    TEST_AND_EXAM,

    //1.0 and 2.0 record types
    CARE_GIVER("careGivers",1),
    CARE_TEAM("careTeam",2),
    HEALTH_OBSERVATIONS("healthObservations",3),
    HEALTH_STATUS("healthStatuses",4),
    PROCEDURE_HISTORY("procedureHistory",5),
    SERVICE_FACILITY_PROVIDER("serviceProviders",6),
    VISIT_HISTORY("visitHistory",7),

    //2.0 record types
    ADVERSE_REACTION("adverseReactions",8),
    HEALTH_CONDITION("conditions",9),
    HEALTH_DEVICE("healthDevices",10),
    HEALTH_MEDICATION("medications",11),
    IMMUNIZATIONS("immunizations",12),

    SURGICAL_HISTORY("surgicalHistory",13),
    TEST_EXAM_ASSESSMENT_HISTORY("testExamAssessmentHistory",14);

    private final String nodeName;
    private final int nodeIndex;
    private final boolean active;

    RecordType() {
        this(INACTIVE_NODE_NAME, -1, false);
    }
    RecordType(String nodeName, int nodeIndex) {
        this(nodeName, nodeIndex, true);
    }
    RecordType(String nodeName, int nodeIndex, boolean active) {
        this.nodeName = nodeName;
        this.nodeIndex = nodeIndex;
        this.active = active;
    }

    public String getNodeName() {
        return nodeName;
    }
    public int getNodeIndex() {
        return nodeIndex;
    }
    public static RecordType valueOf(int nodeIndex) {
        for (RecordType recordType : RecordType.values()) {
            if (recordType.getNodeIndex() == nodeIndex) {
                return recordType;
            }
        }
        return null;
    }
    public boolean isActive() {
        return active;
    }

    public final static String INACTIVE_NODE_NAME="";
    public final static String RECORD_TYPE = "recordType";
}
