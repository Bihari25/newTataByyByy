package com.uhg.ihr.provider.api.model.senzing;

import com.fasterxml.jackson.annotation.JsonIgnoreProperties;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;

import java.io.Serializable;

@JsonInclude(JsonInclude.Include.NON_NULL)
@JsonPropertyOrder({
        "NAME_FIRST",
        "NAME_LAST",
        "NAME_MIDDLE",
        "GENDER",
        "DATE_OF_BIRTH",
        "GLOBAL_ACTOR_ID",
        "UHCCDB_FAMILY_ID",
        "GPS_CID",
        "SUBSCRIBER_ID",
        "ADDR_LINE1",
        "ADDR_POSTAL_CODE",
        "ADDR_COUNTRY",
        "ADDR_STATE",
        "ADDR_CITY",
        "ADDR_TYPE",
        "PHONE_NUMBER",
        "PHONE_TYPE",
        "MEDICAID_NUMBER",
        "SSN",
        "CARDHOLDER_ID",
        "MEDICARE_BENF_ID",
        "CORRELATION_ID",
        "ALT_MEMBER_ID",
        "NPI",
        "PROVIDERTYPE",
        "HICN",
        "UHCINS_MEMBER_ID",
        "CDB_CONSUMER_ID",
        "Masterindividualid"
})
@JsonIgnoreProperties(ignoreUnknown = true)
public class SearchCriteria implements Serializable {

    @JsonProperty("name_first")
    private String firstName;
    @JsonProperty("name_last")
    private String lastName;
    @JsonProperty("NAME_MIDDLE")
    private String middleName;
    @JsonProperty("gender")
    private String gender;
    @JsonProperty("DATE_OF_BIRTH")
    private String dob;
    @JsonProperty("GLOBAL_ACTOR_ID")
    private String globalActorId;

    @JsonProperty("UHCCDB_FAMILY_ID")
    private String UHCCDB_FAMILY_ID;

@JsonProperty("GPS_CID")
private String GPS_CID;

@JsonProperty("UHCINS_MEMBER_ID")
private String UHCINS_MEMBER_ID;
//CDB_CONSUMER_ID
@JsonProperty("CDB_CONSUMER_ID")
private String CDB_CONSUMER_ID;

    @JsonProperty("SUBSCRIBER_ID")
    private String subscriberId;
    @JsonProperty("ADDR_LINE1")
    private String addressLine1;
    @JsonProperty("ADDR_POSTAL_CODE")
    private String addressPostalCode;
    @JsonProperty("ADDR_COUNTRY")
    private String addressCountry;
    @JsonProperty("ADDR_STATE")
    private String addressState;
    @JsonProperty("ADDR_CITY")
    private String addressCity;
    @JsonProperty("ADDR_TYPE")
    private String addressType;
    @JsonProperty("PHONE_NUMBER")
    private String phoneNumber;
    @JsonProperty("PHONE_TYPE")
    private String phoneType;
    @JsonProperty("MEDICAID_NUMBER")
    private String medicaidNumber;
    @JsonProperty("CARDHOLDER_ID")
    private String cardHolderId;
    @JsonProperty("SSN_NUMBER")
    private String SSN;
    @JsonProperty("MEDICARE_BENF_ID")
    private String medicareBenfID;
    @JsonProperty("CORRELATION_ID")
    private String correlationId;
    @JsonProperty("ALT_MEMBER_ID")
    private String altMemberId;
    @JsonProperty("MEDICARE_NUMBER")
    private String medicareNumber;

    @JsonProperty("NPI")
    private String npi;
    @JsonProperty("PROVIDERTYPE")
    private String providerType;
//HICN
@JsonProperty("HICN")
private String HICN;

private String masterIndividualId;

    public SearchCriteria() {
    }

    public SearchCriteria(String fName, String lName, String gender, String dob,
                          String addressLine1, String addressCity, String addressState,
                          String addressPostalCode, String addressCountry, String addressType) {
        this.firstName = fName;
        this.lastName = lName;
        this.dob = dob;
        this.gender = gender;
        this.addressLine1 = addressLine1;
        this.addressCity = addressCity;
        this.addressState = addressState;
        this.addressPostalCode = addressPostalCode;
        this.addressCountry = addressCountry;
        this.addressType = addressType;
    }

    public SearchCriteria(String fName, String lName, String gender, String dob) {
        this.firstName = fName;
        this.lastName = lName;
        this.dob = dob;
        this.gender = gender;
    }

    @JsonProperty("NAME_FIRST")
    public String getFirstName() {
        return firstName;
    }

    @JsonProperty("NAME_FIRST")
    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    @JsonProperty("NAME_LAST")
    public String getLastName() {
        return lastName;
    }

    @JsonProperty("NAME_LAST")
    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    @JsonProperty("NAME_MIDDLE")
    public String getMiddleName() {
        return middleName;
    }

    public void setMiddleName(String middleName) {
        this.middleName = middleName;
    }

    @JsonProperty("GENDER")
    public String getGender() {
        return gender;
    }

    @JsonProperty("GENDER")
    public void setGender(String gender) {
        this.gender = gender;
    }

    @JsonProperty("DATE_OF_BIRTH")
    public String getDob() {
        return dob;
    }

    public void setDob(String dob) {
        this.dob = dob;
    }

    @JsonProperty("GLOBAL_ACTOR_ID")
    public String getGlobalActorId() {
        return globalActorId;
    }

    public void setGlobalActorId(String globalActorId) {
        this.globalActorId = globalActorId;
    }

    @JsonProperty("SUBSCRIBER_ID")
    public String getSubscriberId() {
        return subscriberId;
    }

    public void setSubscriberId(String subscriberId) {
        this.subscriberId = subscriberId;
    }

    @JsonProperty("ADDR_LINE1")
    public String getAddressLine1() {
        return addressLine1;
    }

    public void setAddressLine1(String addressLine1) {
        this.addressLine1 = addressLine1;
    }

    @JsonProperty("ADDR_POSTAL_CODE")
    public String getAddressPostalCode() {
        return addressPostalCode;
    }

    public void setAddressPostalCode(String addressPostalCode) {
        this.addressPostalCode = addressPostalCode;
    }

    @JsonProperty("ADDR_COUNTRY")
    public String getAddressCountry() {
        return addressCountry;
    }

    public void setAddressCountry(String addressCountry) {
        this.addressCountry = addressCountry;
    }

    @JsonProperty("ADDR_STATE")
    public String getAddressState() {
        return addressState;
    }

    public void setAddressState(String addressState) {
        this.addressState = addressState;
    }

    @JsonProperty("ADDR_CITY")
    public String getAddressCity() {
        return addressCity;
    }

    public void setAddressCity(String addressCity) {
        this.addressCity = addressCity;
    }

    public String getAddressType() {
        return addressType;
    }

    @JsonProperty("ADDR_TYPE")
    public void setAddressType(String addressType) {
        this.addressType = addressType;
    }

    @JsonProperty("PHONE_NUMBER")
    public String getPhoneNumber() {
        return phoneNumber;
    }

    public void setPhoneNumber(String phoneNumber) {
        this.phoneNumber = phoneNumber;
    }

    @JsonProperty("PHONE_TYPE")
    public String getPhoneType() {
        return phoneType;
    }

    public void setPhoneType(String phoneType) {
        this.phoneType = phoneType;
    }

    @JsonProperty("MEDICAID_NUMBER")
    public String getMedicaidNumber() {
        return medicaidNumber;
    }

    public void setMedicaidNumber(String medicaidNumber) {
        this.medicaidNumber = medicaidNumber;
    }

    @JsonProperty("SSN_NUMBER")
    public String getSSN() {
        return SSN;
    }

    public void setSSN(String SSN) {
        this.SSN = SSN;
    }

    @JsonProperty("CARDHOLDER_ID")
    public String getCardHolderId() {
        return cardHolderId;
    }

    public void setCardHolderId(String cardHolderId) {
        this.cardHolderId = cardHolderId;
    }

    @JsonProperty("MEDICARE_BENF_ID")
    public String getMedicareBenfID() {
        return medicareBenfID;
    }

    public void setMedicareBenfID(String medicareBenfID) {
        this.medicareBenfID = medicareBenfID;
    }

    @JsonProperty("CORRELATION_ID")
    public String getCorrelationId() {
        return correlationId;
    }

    public void setCorrelationId(String correlationId) {
        this.correlationId = correlationId;
    }

    @JsonProperty("ALT_MEMBER_ID")
    public String getAltMemberId() {
        return altMemberId;
    }

    public void setAltMemberId(String altMemberId) {
        this.altMemberId = altMemberId;
    }

    @JsonProperty("MEDICARE_NUMBER")
    public String getMedicareNumber() {
        return medicareNumber;
    }

    public void setMedicareNumber(String medicareNumber) {
        this.medicareNumber = medicareNumber;
    }

    public String getNpi() {
        return npi;
    }

    public void setNpi(String npi) {
        this.npi = npi;
    }

    public String getProviderType() {
        return providerType;
    }

    public void setProviderType(String providerType) {
        this.providerType = providerType;
    }

    public String getGPS_CID() {
        return GPS_CID;
    }

    public void setGPS_CID(String GPS_CID) {
        this.GPS_CID = GPS_CID;
    }

    public String getUHCINS_MEMBER_ID() {
        return UHCINS_MEMBER_ID;
    }

    public void setUHCINS_MEMBER_ID(String UHCINS_MEMBER_ID) {
        this.UHCINS_MEMBER_ID = UHCINS_MEMBER_ID;
    }

    public String getCDB_CONSUMER_ID() {
        return CDB_CONSUMER_ID;
    }

    public void setCDB_CONSUMER_ID(String CDB_CONSUMER_ID) {
        this.CDB_CONSUMER_ID = CDB_CONSUMER_ID;
    }

    public String getID() {
        if (isValidId(getSSN())) return getSSN();
        if (isValidId(getMedicaidNumber())) return getMedicaidNumber();
        if (isValidId(getMedicareBenfID())) return getMedicareBenfID();
        if (isValidId(getCorrelationId())) return getCorrelationId();
        if (isValidId(getAltMemberId())) return getAltMemberId();
        if (isValidId(getSubscriberId())) return getSubscriberId();
        if (isValidId(getCardHolderId())) return getCardHolderId();
        if (isValidId(getMedicareNumber())) return getMedicareNumber();

        return null;
    }

    public String getHICN() {
        return HICN;
    }

    public void setHICN(String HICN) {
        this.HICN = HICN;
    }

    public String getUHCCDB_FAMILY_ID() {
        return UHCCDB_FAMILY_ID;
    }

    public void setUHCCDB_FAMILY_ID(String UHCCDB_FAMILY_ID) {
        this.UHCCDB_FAMILY_ID = UHCCDB_FAMILY_ID;
    }

    public String getMasterIndividualId() {
        return masterIndividualId;
    }

    public void setMasterIndividualId(String masterIndividualId) {
        this.masterIndividualId = masterIndividualId;
    }

    private boolean isValidId(String ID) {
        return ID != null && !ID.trim().isEmpty();
    }

    private boolean isEqual(String ID, String comparedId) {
        return (isValidId(comparedId) && ID.equalsIgnoreCase(comparedId));
    }

    public void resetID() {
        setMedicaidNumber(null);
        setMedicareBenfID(null);
        setCorrelationId(null);
        setAltMemberId(null);
        setSubscriberId(null);
        setCardHolderId(null);
        setMedicareNumber(null);
        setSSN(null);
    }


    public void resetAllID() {
        String id = getID();
        boolean resetSSN = false;

        if (isEqual(id, getMedicaidNumber())) {
            setMedicaidNumber(null);
            resetSSN = true;
        }
        if (isEqual(id, getMedicareBenfID())) {
            setMedicareBenfID(null);
            resetSSN = true;
        }
        if (isEqual(id, getCorrelationId())) {
            setCorrelationId(null);
            resetSSN = true;
        }
        if (isEqual(id, getAltMemberId())) {
            setAltMemberId(null);
            resetSSN = true;
        }
        if (isEqual(id, getSubscriberId())) {
            setSubscriberId(null);
            resetSSN = true;
        }
        if (isEqual(id, getCardHolderId())) {
            setCardHolderId(null);
            resetSSN = true;
        }
        if (isEqual(id, getMedicareNumber())) {
            setMedicareNumber(null);
            resetSSN = true;
        }

        if (isEqual(id, getSSN()) && resetSSN) setSSN(null);
    }

    @Override
    public String toString() {
        return "SearchCriteria{" +
                "firstName='" + firstName + '\'' +
                ", lastName='" + lastName + '\'' +
                ", gender='" + gender + '\'' +
                ", dob='" + dob + '\'' +
                ", globalActorId='" + globalActorId + '\'' +
                ", subscriberId='" + subscriberId + '\'' +
                ", addressLine1='" + addressLine1 + '\'' +
                ", addressPostalCode='" + addressPostalCode + '\'' +
                ", addressCountry='" + addressCountry + '\'' +
                ", addressState='" + addressState + '\'' +
                ", addressCity='" + addressCity + '\'' +
                ", addressType='" + addressType + '\'' +
                ", phoneNumber='" + phoneNumber + '\'' +
                ", phoneType='" + phoneType + '\'' +
                ", medicaidNumber='" + medicaidNumber + '\'' +
                ", SSN='" + SSN + '\'' +
                '}';
    }
}