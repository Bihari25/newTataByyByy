# Provider Portal Environment Variables

This document is a work in progress.   

| Vault? | Env Specific? | Area | Variable | Description | Default Value |
| ---- | ---- | ---- | ---- | ----- | ----- |  
|     |     |  | PROVIDER_API_PORT | The HTTP listening port of the API | 8080 | 
|     | Yes |  | NESS_ENABLED |  | false | 
|     |     |  | STARGATE_ENABLED |  | true | 
|     |     | Docker | IHR_DISABLE_VAULT | Whether to bypass the vault integration.  This is a Docker container config. |  |
|     |     |  | REDIS_SERVERS | The Redis Cluster servers for caching | redis://apvrt38912:7000,redis://apvrt38913:7000,redis://apvrt38922:7000 | 
| Yes | Yes |  | MONGOPORTAL_USERNAME |     |     | 
| Yes | Yes |  | MONGOPORTAL_PASSWORD |     |     | 
|     | Yes |  | MONGOPORTAL_USER_PROFILE_COLLECTION |  | userprofile | 
|     | Yes |  | MONGOPORTAL_ROLE_COLLECTION_COLLECTION |  | securitymapping |
|     | Yes |  | MONGOPORTAL_IHR_ROLE_COLLECTION_COLLECTION |  | ihrroles |
|     | Yes |  | MONGOPORTAL_SERVERWITHPORT_LIST |  | apvrt27968.uhc.com:27017 | 
|     | Yes |  | MONGOPORTAL_DATABASE |  | ihrpldbdev | 
|     | Yes |  | MONGOPORTAL_OPTIONS |  | ?authSource=%24external&authMechanism=PLAIN&keepalive=true&ssl=true&compressors=zlib,snappy | 
|     |     |  | MEDISPAN_DB_DRIVER | The database drive to be used by the Medispan library | org.postgresql.Driver | 
|     | Yes |  | MEDISPAN_DB_URL | The database url to be used by the Medispan library |  | 
| Yes | Yes |  | MEDISPAN_DB_USERNAME | The username to be used by the Medispan library to connect to the database |  | 
| Yes | Yes |  | MEDISPAN_DB_PASSWORD | The password to be used by the Medispan library to connect to the database |  | 
|     | Yes |  | MEDISPAN_IMAGE_SERVER | The base url pointing to Medispan image server | http://uwu.change-this.net |
| Yes |     |  | B50_JWT_SECRET_KEY | Secret key used for B50 API authentication |  |
|     | Yes |  | B50_JWT_ISSUER | Issuer set in JWT token | portal-lite-api |
|     | Yes |  | B50_JWT_AUDIENCE | Audience set in JWT token | portal |
|     | Yes |  | B50_JWT_ROLES | Roles set in JWT token | ROLES_USER |
|     |     |  | B50_JWT_TTL | The time to live for the generated JWT token | 108000 |
|     | Yes |  | B50_SERVICE_URL | The B50 API service URL | |
|     |     |  | RETRY_ATTEMPTS | The number of retry attempts against B50 Api before breaking the circuit | 3 |
|     |     |  | RETRY_DELAY | The amount of time to wait between retries against the B50 Api | 500ms |
|     |     |  | RETRY_MAX_DELAY | The amount of time to wait between retries against the B50 Api | 2s |
|     |     |  | RETRY_RESET | The amount of time to reset the breaker after failed retries against the B50 Api | 10s |
|     |     |  | RETRY_EXCLUDE_HTTP_STATUS |  The regex pattern to control which HttpStatus codes should trigger a retry | 5[0-9][0-9]|
|     |     |  | CONNECTION_POOL_ENABLED |  Enable/Disable connection pooling for Micronaut Http Clients | false |
| Yes | Yes |  | OVERRIDE_SECRET_KEY |  Secret key used to sign and validate sdc-override tokens | FIXME |
| Yes | Yes |  | OVERRIDE_HEALTH_ROLES |  A string of comma separated IHR roles which have sdc-override security access | FIXME |
|     | Yes |  | IHR_AUDIT_KAFKA_ENABLED | Whether Kafka audit integration is enabled | false | 
|     | Yes |  | IHR_AUDIT_TOPIC | The topic on which the Kafka listeners are pointed |  | 
|     | Yes |  | IHR_AUDIT_C_WRITER_ENABLED | Whether the audit event 'persister' listener is enabled | false | 
|     | Yes |  | IHR_AUDIT_C_INACTIVE_ENABLED | Whether the audit event inactivity feed listenter is enabled| false | 
|     |     |  | IHR_AUDIT_C_INACTIVE_TYPES | A comma delimited list of event types picked up by the inactivity listener | user_login,user_logout | 
|     |     |  | IHR_AUDIT_C_INACTIVE_ACTION_MAP | A comma delimited list of event type to inactivity feed 'Action' convertions.  This configuration is optional, if not specified for an audit type, then the audit type will be used directly.    | user_login&#124;LOGIN,user_logout&#124;LOGOUT | 
|     |     |  | IHR_AUDIT_C_INACTIVE_SQL | Allows for override of the insert sql used by the inactivity listener |  | 
|     | Yes |  | IHR_AUDIT_C_NESS_ENABLED | Whether the NESS audit event listener is enabled | false | 
|     | Yes |  | IHR_AUDIT_C_LOG_ENABLED | Whether the logging audit event listener is enabled | false | 
|     | Yes |  | INACTIVITY_DB_URL | The JDBC connection url for the inactivity DB |  | 
| Yes | Yes |  | INACTIVITY_DB_USER | The database username for the inactivity DB |  | 
| Yes | Yes |  | INACTIVITY_DB_PASSWORD | The database password for the inactivity DB |  | 
|     |     |  | INACTIVITY_DB_DRIVER | The database driver used to connect to the inactivity DB | com.mysql.cj.jdbc.Driver | 


|     |     |  |  |     |  | 
