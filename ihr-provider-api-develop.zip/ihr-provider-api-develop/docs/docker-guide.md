# Docker Guide

## Starting Mongo instance only
In some cases, you may not want to have Mongo installed locally and would rather run it from
a Docker container.  You can use the provided Docker compose files to run your own
local Mongo image.  Run the following command to bring up the Mongo container only:<br>
    ```$ docker-compose -f local-mongo-docker-compose.yml up```

The Mongo container will be accessible on port 27017.  You can use the credentials ```runx_ihrpvdev/Abcd1234```
to access the ```ihrpldbdev``` database instance.

## Shutting down Mongo instance only
To shutdown mongo, run following command. This will take down the images.<br>
    ```$ docker-compose -f local-mongo-docker-compose.yml down```

If you want to reset the DB state to its intial state, then include the ```-v``` option to the down
command, e.g., <br>
```$ docker-compose -f local-mongo-docker-compose.yml down -v```

## How to build provider api jar
1) Build a distribution jar by running <br>
```$ ./gradlew clean build -x test```

## Run local builds in Docker
Follow the steps above to build a jar file of the docker image/ container.  You can build, startup
the container by using the provided docker compose file.  To run the docker compose take the
following steps:<br>
1) Go to ```<repo root>/support/docker/compose```<br>
2) Startup the container by running ```$ docker-compose -f local-build-docker-compose.yml up```

<p>This command will start only Provider API container.</p>

If you make any changes to your local distribution that you wish to update in the container, make
sure to rebuild the container by running ```$ docker-compose -f local-build-docker-compose.yml up --build```

## Shutting down api container
To shutdown, run ```$ docker-compose -f local-build-docker-compose.yml down```. This will take down the images.
Make sure to note that this will maintain the docker volumes created/modified during the
execution of the container.

## Notes:
When using Docker containers, if you need to connect to a local service that is not running in a
Docker container, you can use the hostname ```host.docker.internal``` where you would normally
use ```localhost```.  That will indicated to the Docker container to redirect traffic to your
machines local loop back adapter.
