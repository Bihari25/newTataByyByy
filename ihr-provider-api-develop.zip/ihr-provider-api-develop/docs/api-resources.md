# API Resource Definitions

<pre>
/individual-health-items/v1.0
    /{patient-id}/read
        POST
        getAll
    /{patient-id}/health_item/{item-id}/read
        POST
        getItem
    /search
        POST
        search
               
/medications/v1.0    
    /{id}
        GET
        getMedicationSpan
    /{id}/images
        GET
        getDrugImages
    /{id}/education
        GET
        getPatientEducationMonograph
        
/profile/v1.0
    /
        POST
        createProfile
    /update
        POST
        updateProfile
    /lookup
        POST
        lookupUserProfile
    /{profile_id}/read
        POST
        getUserProfile

/security/v1.0
    /lookupRoles
        POST
        lookupRoles
        
/status
    /
        GET
        read
        
</pre>        