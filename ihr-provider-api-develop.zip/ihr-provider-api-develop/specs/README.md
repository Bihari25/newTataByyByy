# Specification Documentation

This folder contains the resource level OpenSDK specification documents.  Each
specification document needs to be defined by resource name and version number, i.e.,
```<resource-name>-<version>.yaml```.