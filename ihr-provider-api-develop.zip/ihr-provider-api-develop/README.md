IHR Provider API
=============

IDE Setup
---------
This project uses Lombok extensively and without proper IDE setup any tests ran within the IDE will fail due to missing methods. Follow the instructions below to setup Lombok annotation processing for the specific IDE.
## testwebhook
**IntelliJ**
1. Go to Preferences > Plugins > Marketplace and search for `Lombok` and install the plugin by that exact name.
2. Go to Preferences > Build, Execution, Deployment > Compiler > Annotation Processors and ensure `Default` is highlighted then click `Enable annotation processing`

Now your IDE is Lombok ready. You can test this by running a test class and seeing if it compiles without errors.

Local Runtime
-------------


To run, configure the following environment variables:

- Select **Build** -> **Edit Configuration** from the file menu
- Click '+' 
- Select **Application**
- Key **com.uhg.ihr.provider.api.rest.Application** into Application
- Select the **Working Directory** `</directory>/ihr-provider-api`
- Enter the following into the **Environment Variables**
 
| Variable | Description | Default |
| --- | --- | --- |
| LOG_LEVEL | Adjust logging level | INFO |
| ENVIRONMENT | Set to 'dev' to enable local requests to bypass the stargate filter. Dev JWT token is also required for request to work | none |
| B50_SENZING_URL | The location of the Senzing service | http://dbslp2266:8080/ |
| SENZING_KEY | The secret used to generate valid Senzing tokens | ask Kris or Chinh for the key |
| SENZING_ENABLED | enabled whether senzing or not | true |
| MONGO_BACKEND_ENABLED | enabled whether mongo or direct B50 API | true |
| PROVIDER_API_PORT | Server port if you want it to start on specific port | 8080 
| MEDISPAN_DB_URL | Medispan JDBC Connection String | jdbc:postgresql://dbslt0097:30021/dib |
| MEDISPAN_DB_USERNAME | Medispan DB User | TBP |
| MEDISPAN_DB_PASSWORD  | Medispan DB Password | TBP |
| API_SECURITY | API Security Profile: mock - Mock API, database - Mongo API | database |
| MONGOPORTAL_USERNAME | Mongo Portal Db User | runx_ihrpvdev |
| MONGOPORTAL_PASSWORD | Mongo Portal Db Password | ask Kris or Chinh for the password |
| MONGOPORTAL_SERVERWITHPORT_LIST | Mongo Portal Db Server with port | apvrt27933.uhc.com:27017 |

- select **Use Classpath of Module** `ihr-provider-api_main`

- Initialize local MongoDB for Provider Api by opening a terminal to the project's root path and running the following commands in order
```bash
cd support/docker/compose
docker-compose -f local-mongo-docker-compose.yml up &
```
**Default Provider**

If the default provider must be registered for testing purposes then run the Provider Api application, import the latest Postman collection found in `docs/B50 Provider API Local.postman_collection.json`, go to the `/profiles > Register Provider` request, and send the request to your local Provider Api. This will register the provider to your local MongoDB and ensure they are registered in B50 Api as well.

Resource Design/Formatting
-------------
All resources will be designed to be potentially separated into stand-alone
micro services.  As such, each resource will use their own versioning standard and
formatting using the following pattern:<br>

```
<resource>/<version>
```
<br>

Example: my-wonderful-resource/v1.0

The resources and API specifications must adhere to the [API Taxonomy](https://github.optum.com/API-Certification/Taxonomy-Review) 
guidelines and best practices.  
     
Swagger UI
-------------
To use the integrated Swagger-UI go to http://localhost:8080/swagger/views/swagger-ui/index.html

Swagger Editor
-------------
To edit the API specifications using Swagger, you can run the Swagger API via Docker using the following commands.

```
docker pull swaggerapi/swagger-editor
docker run -d -p 80:8080 swaggerapi/swagger-editor
```

Branch Naming Convention
-------------
  feature-JIRA-NUMBER (standard development for features)

  hotfix-JIRA-NUMBER (fix for production)

  wip-JIRA-NUMBER (experimental or long-term)

Jenkins
-------------
  This is being deprecated. Please refer to https://new-wiki.optum.com/display/IHRI/NEW+PIPELINE+FLOW

  https://jenkins.optum.com/ihr/job/ihr-api/job/ihr-api-pipeline/
  The job triggers automatically from a webhook in github. This goes from build through deployment to dev and is based on Jenkinsfile.

  JenkinsfileDeploy is the basis for all deploy jobs for the various environments related to this project.
  
Troubleshooting
-----------------
#### Swagger-UI
* If an endpoint's body doesn't contain what is expected check the method parameters for that endpoint and ensure the `@Body` annotation is applied to the correct parameter.
- temporary swagger [hyperlink](http://10.202.2.235:30839/swagger/views/swagger-ui/index.html#/default/search)


## Build Status
Develop<br>[![Build Status](https://jenkins.optum.com/ihr/buildStatus/icon?job=ihr-provider-portal%2FProvider_Portal_API_Pipeline%2FBuild&build=last,lastSuccessful:${params.BRANCH=develop}&subject=(${displayName}))](https://jenkins.optum.com/ihr/job/ihr-provider-portal/job/Provider_Portal_API_Pipeline/job/Build/)
