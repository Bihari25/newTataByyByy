#!/usr/bin/env groovy

def deploy(){
	def projectName = "default"
	def appName = "${APP}"

	if(!"${customer}"?.trim()) {
		// need this conditional because prod project naming convention is different from rest
		if (environment == 'prod')
		{
			projectName = "${APP}"
		}
		else
		{
			projectName = "${APP}-" + environment
		}
	}
	else
	{
		// need this conditional because prod project naming convention is different from rest
		if (environment == 'prod')
		{
			projectName = "${APP}-" + customer
		}
		else
		{
			projectName = "${APP}-" + customer + "-"+ environment
		}
	}

	sh "$OC login  --server=$cluster -u $user -p $pass --insecure-skip-tls-verify=true"
	sh "$OC project $projectName"
	// Delete F5 routes before deployment starts to remove traffic
	sh "$OC delete route ${APP}-gtm --ignore-not-found=true"
	sh "$OC delete route ${APP}-ltm --ignore-not-found=true"

	// deploy logs pvc if it does not exist
	sh "$OC get pvc/logs | grep logs | tail -1 | awk '{print \$1}' > logspvc"
	def logspvcName = readFile('logspvc').trim()
	if (logspvcName == 'logs')
	{
		echo "logs pvc exists"
	}
	else
	{
		echo "create logs pvc"
		sh "$OC new-app -f deploy/logspvc.yml -p APP_NAME=${APP}"
	}

	// deploy configs pvc if it does not exist
	sh "$OC get pvc/configs | grep configs | tail -1 | awk '{print \$1}' > configspvc"
	def configspvcName = readFile('configspvc').trim()
	if (configspvcName == 'configs')
	{
		echo "configs pvc exists"
	}
	else
	{
		echo "create configs pvc"
		sh "$OC new-app -f deploy/configspvc.yml -p APP_NAME=${APP}"
	}

	// deploy splunk if it does not exist
	sh "$OC get dc/splunk | grep splunk | tail -1 | awk '{print \$1}' > sdc"
	def sdcName = readFile('sdc').trim()
	if (sdcName == "splunk")
	{
		echo "splunk exists"
	}
	else
	{
		echo "creating splunk"
		sh "$OC new-app -f deploy/splunk.yml -p TAG=$splunkTag"
	}

	// deploy prometheus if it does not exist
	sh "$OC get dc/prometheus | grep prometheus | tail -1 | awk '{print \$1}' > pdc"
	def pdcName = readFile('pdc').trim()
	if (pdcName == "prometheus")
	{
		echo "prometheus exists"
	}
	else
	{
		echo "creating prometheus"
		sh "$OC delete configmap prometheus"
		sh "$OC new-app -f deploy/prometheus-template.yaml -p NAMESPACE=$projectName"
	}

	// deploy app
	def bn = "${APP}" + "-" + pom.version + "-" + "${BUILD_NUMBER}"
	sh "$OC get dc/$appName | grep $appName | tail -1 | awk '{print \$1}' > dc"
	def dcName = readFile('dc').trim()
	if (dcName == appName)
	{
		sh "$OC delete all -l app=$appName"
		sh "$OC get rc --no-headers -l app=$appName | awk '\$2 == 0 {system(\"$OC delete rc \"\$1)}'"
		echo "update deployment"
		sh "$OC apply -f deploy/app.yml"
		//sh "$OC process $appName -p TAG=$appTag -p BUILD_NUMBER=$bn -p ROUTE=$routing_url -p DC=$dc -p NODE_COUNT=$app_nodes -p NAMESPACE=$projectName -p LOG_LEVEL=$log_level -p ENVIRONMENT=$environment -p BOOTSTRAP_SERVERS=$boot_strap_servers -p CLUSTER=$cluster -p ROUTING_URL=$routing_url | $OC apply -f - ; $OC rollout status dc/$appName"
		sh "$OC process $appName -p DATA_URL=$data_url -p II_URL=$ii_url -p TAG=$appTag -p BUILD_NUMBER=$bn -p ROUTE=$routing_url -p DC=$dc -p NODE_COUNT=$app_nodes -p NAMESPACE=$projectName -p LOG_LEVEL=$log_level -p ENVIRONMENT=$environment -p BOOTSTRAP_SERVERS=$boot_strap_servers -p CLUSTER=$cluster -p ROUTING_URL=$routing_url | $OC apply -f - ; $OC rollout status dc/$appName"
	}
	else
	{
		echo "creating new app"
		sh "$OC apply -f deploy/app.yml"
		//sh "$OC process $appName -p TAG=$appTag -p BUILD_NUMBER=$bn -p ROUTE=$routing_url -p DC=$dc -p NODE_COUNT=$app_nodes -p NAMESPACE=$projectName -p LOG_LEVEL=$log_level -p ENVIRONMENT=$environment -p BOOTSTRAP_SERVERS=$boot_strap_servers -p CLUSTER=$cluster -p ROUTING_URL=$routing_url | $OC apply -f - ; $OC rollout status dc/$appName"
		sh "$OC process $appName -p DATA_URL=$data_url -p II_URL=$ii_url -p TAG=$appTag -p BUILD_NUMBER=$bn -p ROUTE=$routing_url -p DC=$dc -p NODE_COUNT=$app_nodes -p NAMESPACE=$projectName -p LOG_LEVEL=$log_level -p ENVIRONMENT=$environment -p BOOTSTRAP_SERVERS=$boot_strap_servers -p CLUSTER=$cluster -p ROUTING_URL=$routing_url | $OC apply -f - ; $OC rollout status dc/$appName"
	}

	// rsync configs files
	sh "sleep 20"
	sh "$OC get po | grep $appName | tail -1 | awk '{print \$1}' > po"
	def poName = readFile('po').trim()
	// checks if metadata dir exists
	def configs = fileExists 'ihr-metadata'
	if (!configs) {
		sh "git clone https://$CICD_USER:$CICD_PASS@github.optum.com/IHR/ihr-metadata.git"
	}
	sh "$OC rsync ihr-metadata/configs/ $poName:/configs"

	sh "$OC logout"
}
return this
