package com.imdm


import org.apache.spark.sql.{DataFrame, Row, SQLContext, SaveMode, SparkSession}


object imdmLoad {
  def main(args: Array[String]): Unit = {

    val spark = SparkSession.builder().appName("ImdmExtract").enableHiveSupport().config("spark.serializer", "org.apache.spark.serializer.KryoSerializer").getOrCreate().newSession()
    val input_file = commonVariables.input_file
    val mode = commonVariables.mode
    val parquet_file = commonVariables.parquet_file
    val hive_table = commonVariables.hive_table
    val drop_source_fields = commonVariables.drop_source_fields
    val drop_flat_fields = commonVariables.drop_flat_fields

    println(s"Running IMDM Kafka Load process")

    val df = spark.read.json(input_file).limit(100)
    val cnt = df.count
    println(s"Kafka topic source count :" + cnt + " will be loaded")

    //Drop the fields that are not required
    var newdf = df.drop(drop_source_fields: _*)
    newdf.printSchema()

    //Drop the nested array and struct fields that are not required

    var j = 0
    //for (i <- 0 to drop_flat_fields.length - 1)
     for (i  <- drop_flat_fields )
    {
     val dataframe = commonFunctions.dropColumn(newdf , drop_flat_fields(j))
      newdf = dataframe
      j +=  1

    }
    println(s"Dropped all extra columns")
    println(s"Source data flattening started")
    newdf.printSchema()

    //val flatdata = commonFunctions.flattenDataframe(newdf)
    val flatdata = commonFunctions.flattenDataframe(newdf)
    println(s"Source data flattened")

    //val newFlatdf = flatdata.drop(drop_flat_fields:_*)

    flatdata.write.format("parquet").mode(mode).options(Map("path" -> parquet_file)).saveAsTable(hive_table)
    println(s"Data loaded in table")
  }

}