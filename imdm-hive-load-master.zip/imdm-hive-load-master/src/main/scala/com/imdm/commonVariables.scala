package com.imdm

object commonVariables {

  val input_file = "hdfs:/datalake/optum/optumrx/p_optum/prd/irx/dsrx/users/irxetlsa/data/imdm/raw/imdm_kafka_hdfs.json"
  val parquet_file = "hdfs:/datalake/optum/optumrx/p_optum/prd/irx/dsrx/users/irxetlsa/data/imdm/hive/mil"
  val mode = "overwrite"
  val hive_table = "imdm_dev.dropped"
  val drop_source_fields = Seq("demographicInfo","electronicAddresses","partyLinks","personNames","postalAddresses","telephoneNumbers","socialSecurityNumber")
  val drop_flat_fields = Seq("masterIdentifiers.keyChainIdentifiers.allSaversAlternateMemberIds","masterIdentifiers.keyChainIdentifiers.briovaExchangeIds","masterIdentifiers.keyChainIdentifiers.camsAlternateMemberIds")
}
