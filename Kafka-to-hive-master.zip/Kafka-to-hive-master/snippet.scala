
import org.apache.spark.sql._
import org.apache.spark.rdd.RDD

import org.json4s.JsonAST.JValue
import org.json4s.jackson.JsonMethods._
import scala.util.{Failure, Success, Try}
import scala.util.control.Exception._

spark.sql("show databases").show()

val stringRDD: RDD[String] = sc.textFile("file:///Users/chrish/JavaProjects/jsonKafkaConsumer/src/main/resources/data/data.jsonl")
val parsedStringRDD = stringRDD.flatMap(record => allCatch opt parse(record))
val schema =  InferSchema.inferSchema(parsedStringRDD)
val rowRDD = parsedStringRDD.map(jsonValue => JSONParser.jsonValueToRow(jsonValue, schema, false))
val tableName = "hari_db.ccat_pps_drg"
val df = spark.createDataFrame(rowRDD, schema)
df.printSchema()
df.count()
df.write.mode(SaveMode.Append).format("hive").insertInto(tableName)
