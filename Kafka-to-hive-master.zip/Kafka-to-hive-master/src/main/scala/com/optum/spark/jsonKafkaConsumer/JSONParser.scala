package com.optum.spark.jsonKafkaConsumer

import org.apache.spark.sql.Row
import org.apache.spark.sql.types._
import org.json4s._
import org.json4s.jackson.JsonMethods._

import scala.util.{Try, Success, Failure}

object JSONParser {


  def jsonValueToRow(jValue: JValue, schema: StructType, isCorruptRecordSchema: Boolean = false): Row = {
    if (isCorruptRecordSchema) {
      Row.fromSeq(compact(render(jValue)))
    } else {
      Try {
        val jObject: JObject = jValue.asInstanceOf[JObject]
        unpackJsonObject(jObject, schema)
      } match {
        case Success(row) => row
        case Failure(e) => Row.fromSeq(schema.fields.map(_ => null)) //If it's not a jsonObject, return null fields
      }
    }
  }

  def unpackJsonObject(jObject: JObject, dt: DataType): Row = {
    val jsonValues: Map[String, JValue] = jObject
      .obj
      .map{ case (fieldName, fieldValue) => (fieldName.toLowerCase, fieldValue)}
      .toMap
    dt match {
      case (st: StringType) => Row(jObject.toString)
      case (schema: StructType) =>
        val convertedFields = schema.fields.map(field => {
          val name = field.name
          jsonValues.get(name) match {
            case None => null
            case Some(jsonValue: JValue) =>
              jsonValue match {
                case jObj: JObject => unpackJsonObject(jObj, field.dataType)
                case jArr: JArray => unpackJsonArray(jArr, field.dataType)
                case JInt(number) => number.toInt
                case primitiveValue => primitiveValue.values
              }
          }
        })
        Row.fromSeq(convertedFields)
      case _ => null
    }
  }

  def unpackJsonArray(jArray: JArray, dt: DataType): Seq[Any] = {
    dt.asInstanceOf[ArrayType].elementType match {
      case (schema: StructType) => jArray.arr.map(jValue => {
        val jObject: JObject = jValue.asInstanceOf[JObject]
        unpackJsonObject(jObject, schema)
      })
      case StringType => jArray.arr.map(jValue => compact(render(jValue)))
      case LongType => jArray.arr.map(jValue => jValue.values.asInstanceOf[BigInt].toLong)
      case IntegerType => jArray.arr.map(jValue => jValue.values.asInstanceOf[BigInt].toInt)
      case _ => jArray.values
    }
  }

}
