package com.optum.spark.jsonKafkaConsumer

import java.util.Comparator

import org.apache.spark.rdd.RDD
import org.apache.spark.sql.types._
import org.json4s._
import org.json4s.jackson.JsonMethods._

import scala.util.control.Exception.allCatch

object InferSchema {

  val CORRUPT_RECORD: String = "corrupt_record"
  /**
    * Copied from internal Spark api
    * [[org.apache.spark.sql.catalyst.analysis.TypeCoercion]]
    */
  private val numericPrecedence: IndexedSeq[DataType] =
    IndexedSeq[DataType](
      ByteType,
      ShortType,
      IntegerType,
      LongType,
      FloatType,
      DoubleType,
      TimestampType,
      DecimalType.SYSTEM_DEFAULT)

  private val findTightestCommonTypeOfTwo: (DataType, DataType) => Option[DataType] = {
    case (t1, t2) if t1 == t2 => Some(t1)

    // Promote numeric types to the highest of the two
    case (t1, t2) if Seq(t1, t2).forall(numericPrecedence.contains) =>
      val index = numericPrecedence.lastIndexWhere(t => t == t1 || t == t2)
      Some(numericPrecedence(index))

    case _ => None
  }

  private[this] val structFieldComparator = new Comparator[StructField] {
    override def compare(o1: StructField, o2: StructField): Int = {
      o1.name.compare(o2.name)
    }
  }

  def inferSchema(rdd: RDD[JValue]): StructType = {
    val rddDataType: DataType = rdd.mapPartitions(iter => {
      iter.flatMap(inferRowSchema)
    }).fold(StructType(Seq()))(mergeTypes)

    rddDataType match {
      case st: StructType => st
      case _ => StructType(Seq(StructField(CORRUPT_RECORD, StringType, true)))
    }
  }

  def inferRowSchema(jValue: JValue): Option[DataType] = {
    Some(inferDataType(jValue))
  }

  def inferStructType(fields: List[JField]): StructType = {
    val fieldTypesList: List[StructField] = fields.map{
      case (name, value) =>
        val dataType: DataType = inferDataType(value)
        StructField(name.toLowerCase, dataType, true)
    }.sortBy(_.name)
    StructType(fieldTypesList)
  }

  def inferArrayType(arr: List[JValue]): DataType = {
    val compatibleType = arr.map(inferDataType).reduce(mergeTypes)
    ArrayType(compatibleType, true)
  }

  def inferDataType(obj: JValue): DataType = {
    obj match {
      case JObject(fieldList) => inferStructType(fieldList)
      case JArray(arrayValue) => inferArrayType(arrayValue)
      case JInt(number) => if (number.isValidInt) {
        IntegerType
      } else {
        LongType
      }
      case JString(_) => StringType
      case JDouble(_) => DoubleType
      case JBool(_) => BooleanType
      case _ => StringType
    }
  }

  /**
    * Returns the most general data type for two given data types.
    */
  private def mergeTypes(t1: DataType, t2: DataType): DataType = {
    // TODO: Optimise this logic.
    findTightestCommonTypeOfTwo(t1, t2).getOrElse {
      // t1 or t2 is a StructType, ArrayType, or an unexpected type.
      (t1, t2) match {
        // Double support larger range than fixed decimal, DecimalType.Maximum should be enough
        // in most case, also have better precision.
        case (DoubleType, _: DecimalType) =>
          DoubleType
        case (_: DecimalType, DoubleType) =>
          DoubleType
        case (t1: DecimalType, t2: DecimalType) =>
          val scale = math.max(t1.scale, t2.scale)
          val range = math.max(t1.precision - t1.scale, t2.precision - t2.scale)
          if (range + scale > 38) {
            // DecimalType can't support precision > 38
            DoubleType
          } else {
            DecimalType(range + scale, scale)
          }

        case (StructType(fields1), StructType(fields2)) =>
          val newFields = (fields1 ++ fields2).groupBy(_.name).map {
            case (name, fieldTypes) =>
              val dataType = fieldTypes.view.map(_.dataType).reduce(mergeTypes)
              StructField(name, dataType, nullable = true)
          }
          val newFieldsArr = newFields.toArray
          java.util.Arrays.sort(newFieldsArr, structFieldComparator)
          StructType(newFieldsArr)

        case (ArrayType(elementType1, containsNull1), ArrayType(elementType2, containsNull2)) =>
          ArrayType(
            mergeTypes(elementType1, elementType2), containsNull1 || containsNull2)

        // In XML datasource, since StructType can be compared with ArrayType.
        // In this case, ArrayType wraps the StructType.
        case (ArrayType(ty1, _), ty2) =>
          ArrayType(mergeTypes(ty1, ty2))

        case (ty1, ArrayType(ty2, _)) =>
          ArrayType(mergeTypes(ty1, ty2))

        case (_, NullType) => t1
        case (NullType, _) => t2

        case (_, _) => StringType
      }
    }
  }

}
