package com.optum.spark.jsonKafkaConsumer

case class FalloutRecord(rawMessage: String, error: String, topic: String, id: String)
