package com.optum.spark.jsonKafkaConsumer

import java.lang.System.currentTimeMillis
import java.nio.charset.StandardCharsets

import org.apache.kafka.clients.consumer.ConsumerRecord
import org.apache.spark.rdd.RDD
import org.apache.spark.sql._
import org.apache.spark.sql.types.StructType
import org.apache.spark.streaming.StreamingContext
import org.apache.spark.streaming.dstream.InputDStream
import org.apache.spark.streaming.kafka010.KafkaUtils
import org.slf4j.{Logger, LoggerFactory}
import org.apache.spark.streaming.kafka010._
import org.apache.spark.streaming.kafka010.LocationStrategies.PreferConsistent
import org.apache.spark.streaming.kafka010.ConsumerStrategies.Subscribe
import org.json4s.JValue
import org.json4s.JsonAST.{JObject, JString}
import org.json4s.jackson.JsonMethods._

import scala.util.{Failure, Success, Try}
import scala.util.control.Exception._

object StreamingService {

  val LOGGER: Logger = LoggerFactory.getLogger(getClass)

  def createDStream(ssc: StreamingContext, kafkaParams: Map[String, Object], topicNames: Array[String]) = {
    KafkaUtils.createDirectStream(
      ssc,
      PreferConsistent,
      Subscribe[String, Array[Byte]](topicNames, kafkaParams))
  }

  def process(dstream: InputDStream[ConsumerRecord[String, Array[Byte]]],
              topics: Array[String])(implicit spark: SparkSession): Unit = {

    import spark.implicits._

    for { topic <- topics } {

      dstream.foreachRDD( foreachFunc = rdd => {
        val startRDD = currentTimeMillis()
        if (rdd.isEmpty()) {
          LOGGER.info(s"Empty RDD - $topic {}") //newEvent("Completed RDD").appName("spark-streaming").topicName(topic).recordCount(0).durationMillis(currentTimeMillis - startRdd))
        } else {

          val parsedJSONRDD: RDD[(String, Try[JValue])] = rdd.map((consumerRecord: ConsumerRecord[String, Array[Byte]]) => {
            val recordPayload: Array[Byte] = consumerRecord.value()
            val recordAsString: String = new String(recordPayload, StandardCharsets.UTF_8)

            //We wrap the json in a parse since we want to send a message if there is an error.
            (recordAsString, allCatch withTry parse(recordAsString))
          })

          val fallOutRecordsInvalidJSON: RDD[FalloutRecord] = parsedJSONRDD
            .filter(_._2.isFailure)
            .map { case (rawMessage, attempt) => {
              val failure = attempt.asInstanceOf[Failure[JValue]]
              val id = java.util.UUID.randomUUID.toString
              val error = failure.exception.toString
              FalloutRecord(rawMessage, error, topic, id)
            }
            }

          fallOutRecordsInvalidJSON.cache()
          fallOutRecordsInvalidJSON.count()

          if (!fallOutRecordsInvalidJSON.isEmpty()) {
            val falloutDS: Dataset[FalloutRecord] = spark.createDataset(fallOutRecordsInvalidJSON)
            falloutDS.count()
            insertFallout(topic, "fallout_records", falloutDS)
          }

          val successRecords: RDD[JValue] = parsedJSONRDD
            .filter(_._2.isSuccess)
            .map(_._2.get)

          successRecords.cache()
          successRecords.count()

          println(s"Nb of Successfull parsed Records : ${successRecords.count()}")
          println(s"Nb of Fallout Records : ${fallOutRecordsInvalidJSON.count()}")

          if (!successRecords.isEmpty()) {
            val inferredSchema: StructType = InferSchema.inferSchema(successRecords)

            val rowRDD: RDD[Row] = successRecords.map(jsonRecord => {
              val row = JSONParser.jsonValueToRow(jsonRecord, inferredSchema, false)
              row
            })

            rowRDD.count()

            val df: DataFrame = spark.createDataFrame(rowRDD, inferredSchema)
            df.count()
            df.printSchema()
            println(s"DF COUNT ${df.count()}")
            insertIntoHiveTransational(topic, "uhc_cosmos_1014_ingest.ccat_pps_drg_test", df)

          }

        }
      })
    }
  }

  def insertFallout(topicName: String, tableName: String, falloutDataset: Dataset[FalloutRecord])
                   (implicit spark: SparkSession): Unit = {
    LOGGER.debug("Writing to Fallout Table - {}", topicName)

    falloutDataset.write.mode(SaveMode.Append).saveAsTable(tableName)
    LOGGER.debug("Writing to Fallout Table - {} - Finished", topicName)
  }

  def insertIntoHiveTransational(topicName: String, tableName: String, df: DataFrame)
                                (implicit spark: SparkSession): Unit = {
    val startHive = currentTimeMillis
    df.write.mode(SaveMode.Append).format("hive").insertInto(tableName)
    LOGGER.info(s"Writing to Hive Tables - topicName - Finished {}", currentTimeMillis - startHive)
  }

}
