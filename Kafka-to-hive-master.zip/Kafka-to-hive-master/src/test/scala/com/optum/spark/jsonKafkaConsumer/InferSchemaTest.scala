package com.optum.spark.jsonKafkaConsumer

import org.apache.spark.sql.types._
import org.json4s.JsonAST._
import org.scalatest.{FunSuite, Matchers}
import org.scalatest.Matchers._
import org.json4s.jackson.JsonMethods._
import org.json4s.JsonDSL._

class InferSchemaTest extends FunSuite with Matchers {

  test("Test if simple Object with simple fields is inferred correctly"){
    val jsonObject =
        ("name" -> "Joe") ~
          ("age" -> 35)

    val expectedInferredSchema: StructType = StructType(
      StructField("name", StringType, true) ::
      StructField("age", LongType, true) ::
      Nil
    )
    val actualInferredSchema: StructType = InferSchema.inferStructType(jsonObject.obj)
    actualInferredSchema.fields should contain theSameElementsInOrderAs expectedInferredSchema.fields
  }

  test("Test if simple Object with Array values is inferred correctly"){
    val jsonObject =
      ("name" -> "Joe") ~
        ("age" -> 35) ~
        ("children" -> JArray(Seq('Sandra, 'Miguel, 'Paul).map(symbol2jvalue).toList))

    val expectedInferredSchema: StructType = StructType(
      StructField("name", StringType, true) ::
      StructField("age", LongType, true) ::
      StructField("children", ArrayType(StringType, true), true) ::
      Nil
    )

    val actualInferredSchema: StructType = InferSchema.inferStructType(jsonObject.obj)
    actualInferredSchema.fields should contain theSameElementsInOrderAs expectedInferredSchema.fields
  }

  test("Test if simple Object with Array of mixed Values is inferred correctly"){
    val jsonArray = JArray(
      List(
        JString("Sandra"),
        JInt(12),
        JString("Paul")
      )
    )

    val expectedDataType: DataType = ArrayType(StringType, true)
    val actualDataType: DataType = InferSchema.inferArrayType(jsonArray.arr)

    assertResult(expectedDataType)(actualDataType)
  }

  test("Test if Object with nested Objects is inferred correctly"){

  }

  test("Test if Object with array of Objects if inferred correctly"){

  }

}
