package com.optum.spark.jsonKafkaConsumer

import org.apache.spark.sql.SparkSession
import org.apache.spark.{SparkConf, SparkContext}

trait SharedSparkContext {

  // allowMultipleContexts only used as an aid for tests that cannot stop an existing context properly
  var conf = new SparkConf(false)
    .setMaster("local[8]")
    .set("spark.driver.allowMultipleContexts", "true")
    .set("spark.ui.enabled", "false")
    .set("spark.default.parallelism", "8")
    .set("spark.sql.shuffle.partitions", "8")

  @transient private val _sc: SparkContext = new SparkContext("local", "test", conf)

  implicit def sc: SparkContext = _sc

  @transient private val _spark: SparkSession = SparkSession.builder.config(conf).getOrCreate()

  implicit def spark: SparkSession = _spark
}
