import argparse
import json
import logging
import uuid
import os
from botocore.exceptions import ClientError
from logging.handlers import TimedRotatingFileHandler
import csv
import urllib.request
import ssl

from AWSLoginManager import AWSLoginManager

"""
Example Usage: python3.6 start_cdr_be_in_aws.py --client_id H303173 --environment prd --cdr_schema test --message_type <cdrbe|ecdr> 
--release 201809 --data_start_dt 20200101 --data_end_dt 20200131 --aws_profile saml 
--aws_user oap --aws_pwd test --aws_role role --send_notify true --skip_steps abc,def --is_current true --is_emr_daily true --client_type OPA
"""

parser = argparse.ArgumentParser(description='AWS Orchestration')
parser.add_argument("--client_id", required=True)
parser.add_argument("--client_type", required=False)
parser.add_argument("--cdr_schema", required=True)
parser.add_argument("--cdr_delta_schema", required=False, default=None)
parser.add_argument("--message_type", required=True)
parser.add_argument("--environment", required=True)
parser.add_argument("--release", required=True)
parser.add_argument("--tf_branch", required=True)
parser.add_argument("--data_start_dt", required=False, default=None)
parser.add_argument("--data_end_dt", required=False, default=None)
parser.add_argument("--send_notify", required=False, default=False)
parser.add_argument("--skip_steps", required=False, default="")
parser.add_argument("--is_current", required=False, default=False)
parser.add_argument("--ecdr_enabled", required=False, default=False)
parser.add_argument("--bpo_streams", required=False, default="all")
parser.add_argument("--acc_streams", required=False, default="ebm,sre,hedis")
parser.add_argument("--run_steps", required=False, default="")
parser.add_argument("--skip_send_files", required=False, default=False)
parser.add_argument("--bpo_extracts_log_path", required=False, default="")
parser.add_argument("--oracle_export_log_path", required=False, default="")
parser.add_argument("--enable_oracle_export", required=False, default="False")
parser.add_argument('--aws_profile', required=True)
parser.add_argument('--aws_account', required=True)
parser.add_argument('--aws_user', required=True)
parser.add_argument('--aws_role', required=True)
parser.add_argument('--aws_pwd', required=True)
parser.add_argument('--log_path', required=True)
parser.add_argument('--is_emr_daily', required=False)
parser.add_argument('--s3_jars_path', required=True)
parser.add_argument('--jar_version', required=True)
parser.add_argument('--core_instance_count_monthly', required=False)
parser.add_argument('--core_instance_count_daily', required=False)
parser.add_argument("--enable_restart_for_hedis", required=False, default=False)
parser.add_argument("--partition_multiplier", required=False, default="1")
parser.add_argument("--executor_threads", required=False, default=5)
parser.add_argument("--spark_configs", required=False, default=None)
parser.add_argument("--step_build_params", required=False, default=None)
parser.add_argument("--emr_label", required=False, default=None)

parsed_args = parser.parse_args()

log_path = parsed_args.log_path

logger = logging.getLogger(__name__)
logger.setLevel(logging.INFO)
formatter = logging.Formatter('%(asctime)s - %(levelname)s - %(message)s')
handler = TimedRotatingFileHandler(f"{log_path}/orchestration.log", when="midnight", backupCount=30, delay=True)
handler.setFormatter(formatter)
logger.addHandler(handler)

DAILY_LEVEL = 'delta'
MONTHLY_LEVEL = 'cdr_be'

parsed_args = parser.parse_args()
client_id = parsed_args.client_id.upper()
cdr_schema = parsed_args.cdr_schema
cdr_delta_schema = parsed_args.cdr_delta_schema
client_type = parsed_args.client_type
release = parsed_args.release
environment = parsed_args.environment
message_type = parsed_args.message_type
data_start_dt = parsed_args.data_start_dt
data_end_dt = parsed_args.data_end_dt
send_notify = parsed_args.send_notify
skip_steps = parsed_args.skip_steps
run_steps = parsed_args.run_steps
is_current = parsed_args.is_current
ecdr_enabled = parsed_args.ecdr_enabled
bpo_streams = parsed_args.bpo_streams
acc_streams = parsed_args.acc_streams
skip_send_files = parsed_args.skip_send_files
bpo_extracts_log_path = parsed_args.bpo_extracts_log_path
is_emr_daily = parsed_args.is_emr_daily
oracle_export_log_path = parsed_args.oracle_export_log_path
enable_oracle_export = parsed_args.enable_oracle_export
core_instance_count_monthly = parsed_args.core_instance_count_monthly
core_instance_count_daily = parsed_args.core_instance_count_daily
enable_restart_for_hedis = parsed_args.enable_restart_for_hedis
partition_multiplier = parsed_args.partition_multiplier
executor_threads = parsed_args.executor_threads
spark_configs = parsed_args.spark_configs
step_build_params = parsed_args.step_build_params
emr_label = parsed_args.emr_label

TF_BRANCH = parsed_args.tf_branch  # os.environ["CDRBE_TF_BRANCH"]
TF_BRANCH = TF_BRANCH.replace("-", "_").replace(".", "").lower()  # this substitution is done in TF code, duplicate it here to avoid branch name mismatches
AWS_USER = parsed_args.aws_user  # os.environ["CDRBE_AWS_SAML_USER"]
AWS_PASSWORD = parsed_args.aws_pwd  # os.environ["CDRBE_AWS_SAML_PASSWORD"]
AWS_ROLE = parsed_args.aws_role  # os.environ["CDRBE_AWS_SAML_ROLE"]
AWS_PROFILE = parsed_args.aws_profile  # os.environ["CDRBE_AWS_SAML_PROFILE"]
AWS_ACCOUNT = parsed_args.aws_account
s3_jars_path = parsed_args.s3_jars_path
jar_version = parsed_args.jar_version

uuid_str = str(uuid.uuid4())
correlation_id = f"{client_id}_{environment}_{message_type}_{release}_{uuid_str}"

logger.info(f'client_id: {client_id}')
logger.info(f'cdr_schema: {cdr_schema}')
logger.info(f'cdr_delta_schema: {cdr_delta_schema}')
logger.info(f'client_type: {client_type}')
logger.info(f'release: {release}')
logger.info(f'environment: {environment}')
logger.info(f'data_start_dt: {data_start_dt}')
logger.info(f'data_end_dt: {data_end_dt}')
logger.info(f'is_current: {is_current}')
logger.info(f'send_notify: {send_notify}')
logger.info(f'skip_steps: {skip_steps}')
logger.info(f'TF_BRANCH: {TF_BRANCH}')
logger.info(f'ecdr_enabled: {ecdr_enabled}')
logger.info(f'bpo_streams: {bpo_streams}')
logger.info(f'acc_streams: {acc_streams}')
logger.info(f'run_steps: {run_steps}')
logger.info(f'skip_send_files: {skip_send_files}')
logger.info(f'bpo_extracts_log_path: {bpo_extracts_log_path}')
logger.info(f'is_emr_daily: {is_emr_daily}')
logger.info(f'correlation_id: {correlation_id}')
logger.info(f'oracle_export_log_path: {oracle_export_log_path}')
logger.info(f'enable_oracle_export: {enable_oracle_export}')
logger.info(f's3_jars_path: {s3_jars_path}')
logger.info(f'jar_version: {jar_version}')
logger.info(f'core_instance_count_monthly: {core_instance_count_monthly}')
logger.info(f'core_instance_count_daily: {core_instance_count_daily}')
logger.info(f'partition_multiplier: {partition_multiplier}')
logger.info(f'executor_threads: {executor_threads}')
logger.info(f'spark_configs: {spark_configs}')
logger.info(f'step_build_params: {step_build_params}')


def parse_approved_config():
    """
    For each group, parses the approved configuration get approved value
    """
    context = ssl.create_default_context()
    context.check_hostname = False
    context.verify_mode = ssl.CERT_NONE

    config_url = f'https://github.optum.com/raw/OptumAnalyticsPlatform/oap-configs/master/CDRBE/config/{release}/cdrbe_approved_builds.csv'
    logger.info(f'Approved config url: {config_url}')
    is_approved = False

    try:
        reader = read_config(config_url, context)
        is_approved = get_group_approved_config(reader)
    except urllib.error.HTTPError as e:
        if e.getcode() == 404:
            logger.info("Client configuration file - cdrbe_approved_builds.csv is not found for the release.")
        pass
    return str(is_approved)


def get_group_approved_config(reader):
    is_approved = False
    group_specific_entry = 0
    
    for line in reader:
        if client_id == line["GROUP_ID"].upper():
            group_specific_entry += 1
            if group_specific_entry > 1:
                raise ValueError(f"Multiple entries for group {client_id} are noticed in approved config file. \
                                The number of entries noticed are: {group_specific_entry}")
            approved_status = line["IS_APPROVED"].lower()
            is_approved = True if approved_status is not None and approved_status == "true" else False

    return is_approved


def read_config(config_url, context):
    response = urllib.request.urlopen(config_url, context=context)
    return csv.DictReader(response.read().decode('utf-8').splitlines(), delimiter=',')


def main():
    logger.info('Using profile ' + AWS_PROFILE)

    sf_name = "cdr_be_load"
    sns_name = f"arn:aws:sns:us-east-1:{AWS_ACCOUNT}:cdrbe_aws_wf_{TF_BRANCH}_sfn_invoke".lower()
    logger.info('sns_name ' + sns_name)

    # only do aws related stuff when required
    AWS_LOGIN_MANAGER = AWSLoginManager(profile=AWS_PROFILE, aws_user=AWS_USER, aws_pwd=AWS_PASSWORD, aws_role=AWS_ROLE,
                                        logger=logger.getChild("_aws_login"))

    logger.info(f'sf_name: {sf_name}')

    is_approved = parse_approved_config()

    # enforce only run_steps or skip_steps can be non-empty
    global run_steps
    run_steps = None if run_steps == 'all' else run_steps
    if run_steps and skip_steps:
        raise Exception(f"Cannot specify both run_steps: '{run_steps}' and skip_steps: '{skip_steps}'")

    output_json = {
        "step_function": sf_name,
        "execution_prefix": f"{client_id}_{environment}_{cdr_schema}_{release}",
        "input": {
            "client_id": client_id,
            "cdr_schema": cdr_schema,
            "cdr_delta_schema": cdr_delta_schema,
            "client_type": client_type,
            "message_type": message_type,
            "environment": environment,
            "release": release,
            "s3_jars_path": s3_jars_path,
            "jar_version": jar_version,
            "skip_steps": skip_steps,
            "data_start_dt": data_start_dt,
            "data_end_dt": data_end_dt,
            "is_current": is_current,
            "send_notify": send_notify,
            "ecdr_enabled": ecdr_enabled,
            "bpo_streams": bpo_streams,
            "acc_streams": acc_streams,
            "run_steps": run_steps,
            "skip_send_files": skip_send_files,
            "is_approved": is_approved,
            "bpo_extracts_log_path": bpo_extracts_log_path,
            "is_emr_daily": is_emr_daily,
            "correlation_id": correlation_id,
            "oracle_export_log_path": oracle_export_log_path,
            "enable_oracle_export": enable_oracle_export,
            "core_instance_count_monthly": core_instance_count_monthly,
            "core_instance_count_daily": core_instance_count_daily,
            "enable_restart_for_hedis": enable_restart_for_hedis,
            "partition_multiplier": partition_multiplier,
            "executor_threads": executor_threads,
            "spark_configs": spark_configs,
            "step_build_params": step_build_params,
            "emr_release_label": emr_label
        }
    }

    sns = AWS_LOGIN_MANAGER.get_client("sns")

    json_message = json.dumps(output_json, indent=4, sort_keys=False)

    response = sns.publish(
        TopicArn=sns_name,
        Message=json_message
    )
    logger.info(response)


if __name__ == "__main__":
    main()
