import logging
import os
import threading
from typing import Optional

import boto3
import pwd
import time
import subprocess
from botocore.client import Config
from subprocess import TimeoutExpired
from typing import Optional, List, Tuple

CURRENT_USER = pwd.getpwuid(os.geteuid()).pw_name


class AWSLoginManager:
    # use a lock to prevent more than 1 AWS login at a time
    AWS_LOCK = threading.Condition()
    LAST_LOGIN = {}
    config = Config(connect_timeout=70, read_timeout=70)
    clients = {}
    resources = {}

    def __init__(self, profile: str, aws_user: str, aws_pwd: str, aws_role: str, logger: logging.Logger):
        self.profile = profile
        self.logger = logger
        self.aws_user = aws_user
        self.aws_pwd = aws_pwd
        self.aws_role = aws_role
        self.logger.info(f"Current user is " + CURRENT_USER)

    def get_resource(self, resource: str):
        self.log_in_user_to_aws(None)

        with self.AWS_LOCK:
            if resource not in self.resources:
                c = boto3.Session(profile_name=self.profile).resource(resource, region_name='us-east-1', config=self.config)
                self.resources[resource] = c
            return self.resources[resource]

    def get_client(self, client: str):
        self.log_in_user_to_aws(None)


        with self.AWS_LOCK:
            if client not in self.clients:
                c = boto3.Session(profile_name=self.profile).client(client, region_name='us-east-1', config=self.config)
                self.clients[client] = c
            return self.clients[client]

    def run_command(self, command: List[str], logger: logging.Logger, env: Optional[dict] = None,
                    timeout: Optional[int] = None) -> Tuple[int, str]:
        logger.info("Executing command: " + str(command))
        proc = subprocess.Popen(command, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, universal_newlines=True,
                                env=env)

        try:
            stdout, stderr = proc.communicate(str(command), timeout=timeout)
        except TimeoutExpired:
            proc.kill()
            stdout, stderr = proc.communicate()

        if len(stdout) != 0:
            logger.info("Begin command logs\n-----\n" + stdout + "\n-----\nEnd command logs")

        return proc.returncode, stdout

    def log_in_user_to_aws(self, local_user: Optional[str], local_profile: Optional[str] = None):

        with self.AWS_LOCK:
            if local_user is None:
                # login the current user
                local_user = CURRENT_USER

            if local_profile is None:
                profile = self.profile
            else:
                profile = local_profile

            # only run the login per user once an hour
            current_time = time.time()
            if local_user in self.LAST_LOGIN:
                last_time = self.LAST_LOGIN[local_user]
                elapsed_time = current_time - last_time
                do_login = elapsed_time > 3600
            else:
                do_login = True

            if do_login:
                # aws_user = os.environ["ORCH_AWS_SAML_USER"]
                # aws_password = os.environ["ORCH_AWS_SAML_PASSWORD"]
                # aws_role = os.environ["ORCH_AWS_SAML_ROLE"]

                if local_user == CURRENT_USER:
                    user_cmd = []
                    my_env = os.environ.copy()
                    my_env["AWS_SAML_PROFILE"] = profile
                    my_env["AWS_SAML_USER"] = self.aws_user
                    my_env["AWS_SAML_PASSWORD"] = self.aws_pwd
                    my_env["AWS_SAML_ROLE"] = self.aws_role
                else:
                    user_cmd = ["sudo", "-E", "-u", local_user]
                    my_env = {
                        "AWS_SAML_USER": self.aws_user,
                        "AWS_SAML_PASSWORD": self.aws_pwd,
                        "AWS_SAML_ROLE": self.aws_role,
                        "AWS_SAML_PROFILE": profile
                    }

                command = user_cmd + ["./authenticate.sh", "--skipStdIn"]

                self.logger.info(f"Logging in {local_user} as {self.aws_user} with role {self.aws_role}")
                code, stdout = self.run_command(command=command, logger=self.logger, env=my_env, timeout=180)

                if code != 0:
                    raise Exception(f"Could not log in {local_user} as {self.aws_user} with role {self.aws_role} in 180 seconds")

                self.LAST_LOGIN[local_user] = current_time

                if local_user == CURRENT_USER:
                    self.clients.clear()
                    self.resources.clear()
