#!/bin/bash

# create a new virtual env
python3.6 -m venv $HOME/auth_env

. $HOME/auth_env/bin/activate

# install requirements. pip3.6 may need to change for local use. this is correct on an EC2 instance
pip3.6 install --index-url=https://repo1.uhc.com/artifactory/api/pypi/pypi-simple/simple botocore==1.15.42 boto3==1.12.42 requests beautifulsoup4 lxml

# run authenticate
python3.6 authenticate.py $@
