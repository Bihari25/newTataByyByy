#!/usr/bin/env bash

python36=/opt/rh/rh-python36/root/bin/python
user=`whoami`
venvDirectory="/tmp/${user}/cdrbe_sns_notification"

if [[ -d "${venvDirectory}" ]]; then
    rm -rf ${venvDirectory}
fi

$python36 -m venv ${venvDirectory}

. ${venvDirectory}/bin/activate

pip install --index-url=https://repo1.uhc.com/artifactory/api/pypi/pypi-simple/simple --upgrade --force-reinstall botocore==1.12.239 boto3==1.9.239

${venvDirectory}/bin/python start_cdr_be_in_aws.py "$@"

