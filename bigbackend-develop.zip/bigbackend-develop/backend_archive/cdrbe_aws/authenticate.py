#!/usr/bin/python3
import sys
import boto3
import requests
import getpass
import os
from os import path
from pathlib import Path
import configparser
import base64
import re
import xml.etree.ElementTree as ET
import requests.packages.urllib3
from bs4 import BeautifulSoup
from urllib.parse import urlparse
from time import sleep
from argparse import ArgumentParser
from botocore import UNSIGNED
from botocore.config import Config
import json

# The main function calls all of the functions in order to authenticate
# a user in AWS and write their credentials to a SAML section in the
# .aws/credentials file with a temporary access token. This will allow the
# user to make calls programatically to AWS


def main():
    # gets the configurations like username, password, and role and sets them in a dictionary
    c = get_configuration()
    # None means an ENV was missing and the script cannot run
    if c == None:
        sys.exit(1)

    payload, formsoup, session, idpauthformsubmiturl = collect_saml_stuff_from_ping_federate(c)

    sleep(2)  # Remote server enforces rate limiting
    assertion = query_for_saml_assertion(
        c, payload, formsoup, session, idpauthformsubmiturl)

    role_arn, principal_arn = extract_authorized_roles(c, assertion)
    # None means the given role by the user doesn't match their existing roles
    if role_arn == None:
        print("\nERROR: The role specified does not match any of your current roles.\n")
        sys.exit(1)

    if not c['credential_process']:
        create_aws_config_file_if_none_exists(c)

    try:
        # In OFE, we have an issue with certificate validation. We get the CERTIFICATE_VERIFY_FAILED error.
        # The firewall team and the Venafi folks are looking at the issue. Once we get the resolution, we may be able to remove this.
        # Having this for internal OFE domain is potentially low risk
        validatecerts = not c['ofe']
        # Use the assertion to get an AWS STS token using Assume Role with SAML
        sts = boto3.client('sts', config=Config(signature_version=UNSIGNED))
        token = sts.assume_role_with_saml(
            RoleArn=role_arn,
            PrincipalArn=principal_arn,
            SAMLAssertion=assertion,
            DurationSeconds=c['duration'])
    except Exception as e:
        print("FATAL:  Problem getting temporary token from AWS.\n")
        print("Decrypted SAML Assertion Data:")
        root = ET.fromstring(base64.b64decode(assertion))
        for saml2attribute in root.iter(
                '{urn:oasis:names:tc:SAML:2.0:assertion}Attribute'):
            print("  " + saml2attribute.get('Name') + ":")
        for saml2attributevalue in saml2attribute.iter(
                '{urn:oasis:names:tc:SAML:2.0:assertion}AttributeValue'):
            print("    " + str(saml2attributevalue.text))
        print("\n\nThis error can also pertain to your [default] AWS profile\n"
              "not being set up correctly in your credentials file.\n\n")
        raise(e)

    if c['credential_process']:
        print_aws_credentials(token)
    else:
        rewrite_aws_credentials_to_include_temp_token(token,
                                                      c['awsconfigfile'],
                                                      c['profile'],
                                                      c['region'],
                                                      c['outputformat'])

# get_configuration function sets up the c dictionary with user login creds like username,
# password, role, and environment

def get_configuration():

    c = {}  # configurations
    # boolean to ensure everything is set and returned correctly
    cleanReturn = True

    # parser for command line arguments
    parser = ArgumentParser()
    parser.add_argument('-u', '--username', action='store', dest='username', type=str,
                        help='Username for AWS, could be your MSID')
    parser.add_argument('-p', '--password', action='store', dest='password', type=str,
                        help='Password for AWS, could be your MSID password')
    parser.add_argument('-r', '--role', action='store', dest='role', type=str,
                        help='Role for AWS, the format should be "arn:aws:iam::YOUR_ACCOUNT_NUMBER:role/YOUR_ROLE"')
    parser.add_argument('-e', '--environment', action='store', dest='environment', type=str,
                        help='Environment for AWS, either prod or sandbox. The default is prod.')
    parser.add_argument('--profile', action='store', dest='profile', type=str,
                        help='Desired name of the AWS CLI profile. Defaults to "saml"')
    parser.add_argument('--credential-process', action='store_true', dest='credential_process',
                        default=False, help='switch usage to be compatible with https://docs.aws.amazon.com/cli/latest/userguide/cli-configure-sourcing-external.html')
    parser.add_argument('--duration', action='store', type=int, default=3600,
                        help='Length of session in seconds, default 3600, min 900')
    parser.add_argument('--ofe', action='store_true', dest='ofe',
                        help='Specify this parameter if running in the Optum FISMA Environment (OFE)')
    (args, extras) = parser.parse_known_args()

    # checks if there is a command line argument for every parameter before checking
    # the environment variables and then asking for user input
    c['duration'] = args.duration

    if args.username != None:
        c['username'] = args.username
    else:
        try:
            c['username'] = os.environ["AWS_SAML_USER"]
        except:
            exc_info = sys.exc_info()
            cleanReturn = False
        if not cleanReturn:
            print("Username:")
            c['username'] = input()
            if not c['username']:
                cleanReturn = False
                print("Error:  Missing command line input or env variable {}".format(
                    exc_info[1]))
            else:
                cleanReturn = True

    if args.password != None:
        c['password'] = args.password
    else:
        try:
            c['password'] = os.environ["AWS_SAML_PASSWORD"]
        except:
            exc_info = sys.exc_info()
            cleanReturn = False
        if not cleanReturn:
            c['password'] = getpass.getpass()
            if not c['password']:
                cleanReturn = False
                print("Error:  Missing command line input or env variable {}".format(
                    exc_info[1]))
            else:
                cleanReturn = True

    if args.role != None:
        c['role'] = args.role
    else:
        try:
            c['role'] = os.environ["AWS_SAML_ROLE"]
        except:
            exc_info = sys.exc_info()
            c['role'] = None

    c['profile'] = args.profile or \
                   os.environ.get('AWS_SAML_PROFILE') or \
                   "saml"

    # sets the default cert file and url since the default is prod then checks if an environment is
    # specified via a command line argument, if something is specified and it is not equal to prod
    # we will set it as sandbox
    c['ofe'] = args.ofe
    tmpEnvironment = args.environment.upper() if args.environment != None else 'PROD'

    if c['ofe']:
        c['cert_file'] = 'prod.cer'
        c['idpentryurl'] = 'https://ofefederation.optum.com/idp/startSSO.ping?PartnerSpId=urn%3Aamazon%3Awebservices'
    else:
        if tmpEnvironment == 'PROD':
            c['cert_file'] = 'prod.cer'
            c['idpentryurl'] = 'https://authgateway1.entiam.uhg.com/idp/startSSO.ping?PartnerSpId=https%3A%2F%2Fsignin.aws.amazon.com%2Fsaml'
        else:
            c['cert_file'] = 'sandbox.cer'
            c['idpentryurl'] = 'https://authgateway1-stg.entiam.uhg.com/idp/startSSO.ping?PartnerSpId=https%3A%2F%2Fsignin.aws.amazon.com%2Fsaml'

    # normalize the path and remove redundant path segments
    c['cert_file'] = os.path.normpath(
        path.join(path.dirname(__file__), c['cert_file'])
    )

    # region: The default AWS region that this script will connect
    # to for all API calls
    c['region'] = 'us-east-1'

    # output format: The AWS CLI output format that will be configured in the
    # saml profile (affects subsequent CLI calls)
    c['outputformat'] = 'json'

    # awsconfigfile: The file where this script will store the temp
    # credentials under the saml profile
    c['awsconfigfile'] = '/.aws/credentials'

    c['credential_process'] = args.credential_process

    c['duration'] = args.duration

    # if there was an issue grabbing a neccessary arg then return none and error out in main
    if cleanReturn == False:
        c = None

    return c

# collect_saml_stuff_from_ping_federate function programmatically get the SAML assertion opens
# the initial IdP url and follows all of the HTTP302 redirects, and gets the resulting login page
# https://aws.amazon.com/blogs/security/how-to-implement-a-general-solution-for-federated-apicli-access-using-saml-2-0/


def collect_saml_stuff_from_ping_federate(c):
    # retries limit is how many times you want to try and connect
    retryLimit = 1
    # the count keeps track of retries
    count = 0
    # excepted boolean is true unless you connect
    excepted = True
    while(excepted):
        try:
            session = requests.Session()
            formresponse = session.get(c['idpentryurl'], verify=False)
            excepted = False
        except requests.exceptions.ConnectionError as e:
            exc_type, exc_obj, exc_tb = sys.exc_info()
            fname = os.path.split(exc_tb.tb_frame.f_code.co_filename)[1]
            print("FATAL:  Error on line " + fname + ":" + str(exc_tb.tb_lineno) + " connecting to...\n\n    " +
                  c['idpentryurl'] + "\n\nCan you connect to that resource manually?\n")
            excepted = True
            count += 1
            if count >= retryLimit:  # right now we try to connect 10 times and if we don't is raises an exception
                raise(e)

    # Capture the idpauthformsubmiturl, which is the final url after all the 302s
    idpauthformsubmiturl = formresponse.url

    formresponse = session.get(idpauthformsubmiturl, verify=False)

    # Parse the response and extract all the necessary values
    # in order to build a dictionary of all of the form values the IdP expects
    formsoup = BeautifulSoup(formresponse.text.encode(
        'ascii', 'ignore').decode('utf-8'), 'lxml')

    # Actual Collection Phase returning (Dict)payload
    payload = {}
    for inputtag in formsoup.find_all(re.compile('(INPUT|input)')):
        name = inputtag.get('name', '')
        value = inputtag.get('value', '')
        if "user" in name.lower():
            # Make an educated guess that this is correct field for username
            payload[name] = c['username']
        elif "email" in name.lower():
            # Some IdPs also label the username field as 'email'
            payload[name] = c['username']
        elif "pass" in name.lower():
            # Make an educated guess that this is correct field for password
            payload[name] = c['password']
        else:
            # Populate the parameter with existing value (picks up hidden fields
            # in the login form)
            payload[name] = value

    return payload, formsoup, session, idpauthformsubmiturl


# query_for_saml_assertion returns the assertion after posting to the signon url with the payload
def query_for_saml_assertion(c, payload, formsoup, session, idpauthformsubmiturl):
    assertion = ''
    # Some IdPs don't explicitly set a form action, but if one is set we should
    # build the idpauthformsubmiturl by combining the scheme and hostname
    # from the entry url with the form action target
    # If the action tag doesn't exist, we just stick with the
    # idpauthformsubmiturl above
    for inputtag in formsoup.find_all(re.compile('(FORM|form)')):
        action = inputtag.get('action')
        if action:
            parsedurl = urlparse(c['idpentryurl'])
            idpauthformsubmiturl = parsedurl.scheme + "://" \
                                                      "" + parsedurl.netloc + action

    #retry logic here
    # retries limit is how many times you want to try and connect
    retryLimit = 1
    # the count keeps track of retries
    count = 0
    # notPosted boolean changes to false if the post request returns a 200
    notPosted = True

    while(notPosted):
        response = session.post(
            idpauthformsubmiturl, data=payload)  # , verify=sslverification)

        samlsoup = BeautifulSoup(response.text.encode(
            'ascii', 'ignore').decode('utf-8'), 'lxml')
        for inputtag in samlsoup.find_all(re.compile('input')):
            if(inputtag.get('name') == 'SAMLResponse'):
                assertion = inputtag.get('value')

        if (response.status_code == 200 and assertion != ''):
            notPosted = False

        if (response.status_code != 200):
            print("FATAL:  Post request to " + idpauthformsubmiturl +
                  " did not return a 200 code.  This may mean the service is down.\n")
            print("Page response:\n" + response.text)
            print("Retrying again...")
            count +=1

        if (assertion == ''):
            print("FATAL:  Assertion was empty, from this url...\n\n " +
                  idpauthformsubmiturl + "\n\n")
            print("This may mean an incorrect username/ password was provided or that some connectivity issue exists for connecting to that resource or you're using this in the wrong environment (sandbox only?).\n")
            print("Page response:\n" + response.text)
            print("Retrying again...")
            count += 1

        if count >= retryLimit:  # right now we try to connect 10 times and if we don't is raises an exception
            print("END OF RETRIES")
            sys.exit(500)

    return assertion

# extract_authorized_roles function parses the returned assertion and extracts the authorized roles


def extract_authorized_roles(c, assertion):
    awsroles = []
    root = ET.fromstring(base64.b64decode(assertion))
    for saml2attribute in root.iter(
            '{urn:oasis:names:tc:SAML:2.0:assertion}Attribute'):
        if (saml2attribute.get('Name') ==
                'https://aws.amazon.com/SAML/Attributes/Role'):
            for saml2attributevalue in saml2attribute.iter(
                    '{urn:oasis:names:tc:SAML:2.0:assertion}AttributeValue'):
                awsroles.append(saml2attributevalue.text)

    # Note the format of the attribute value should be role_arn,principal_arn
    # but lots of blogs list it as principal_arn,role_arn so let's reverse
    # them if needed
    for awsrole in awsroles:
        chunks = awsrole.split(',')
        if'saml-provider' in chunks[0]:
            newawsrole = chunks[1] + ',' + chunks[0]
            index = awsroles.index(awsrole)
            awsroles.insert(index, newawsrole)
            awsroles.remove(awsrole)

    if len(awsroles) == 0:
        print("FATAL:  Could not find any usable AWS roles for this account.")
        print("Decrypted SAML Assertion Data")
        root = ET.fromstring(base64.b64decode(assertion))
        for saml2attribute in root.iter(
                '{urn:oasis:names:tc:SAML:2.0:assertion}Attribute'):
            print("  " + saml2attribute.get('Name') + ":")
        for saml2attributevalue in saml2attribute.iter(
                '{urn:oasis:names:tc:SAML:2.0:assertion}AttributeValue'):
            print("    " + str(saml2attributevalue.text))
        print("\n")
        return None, None  # returning None results in an error thrown in main
    else:
        if c['role']:
            for awsrole in awsroles:
                role_arn = awsrole.split(',')[0].strip()
                principal_arn = awsrole.split(',')[1].strip()
                if role_arn.lower() == c['role'].lower():
                    print("\nThe role " + c['role'] +
                          " MATCHED " + role_arn + "\n", file=sys.stderr)
                    return role_arn, principal_arn
                else:
                    print("\nThe role " + c['role'] +
                          " DID NOT MATCH " + role_arn + "\n", file=sys.stderr)
        else:
            # there is not a role set in c['role'] so prompt user for input
            print("Please choose the role you would like to assume:")
            i = 0
            for awsrole in awsroles:
                print('[', i, ']: ', awsrole.split(',')[0])
                i += 1

            print("Selection: ")
            selectedroleindex = input()
            # selectedroleindex = raw_input()
            # Basic sanity check of input
            if int(selectedroleindex) > (len(awsroles) - 1):
                print('You selected an invalid role index.')
                return None, None
            else:
                role_arn = awsroles[int(selectedroleindex)].split(',')[
                    0].strip()
                principal_arn = awsroles[int(selectedroleindex)].split(',')[
                    1].strip()
                return role_arn, principal_arn

    return None, None  # returning None results in an error thrown in main

def print_aws_credentials (token):
    print(json.dumps({
        'Version': 1,
        'AccessKeyId': token['Credentials']['AccessKeyId'],
        'SecretAccessKey': token['Credentials']['SecretAccessKey'],
        'SessionToken': token['Credentials']['SessionToken'],
        'Expiration': token['Credentials']['Expiration'].strftime("%Y-%m-%dT%H:%M:%SZ"),
    }))

# rewrite_aws_credentials_to_include_temp_token function Updates the saml section in the
# credentials file with a valid temp token

def rewrite_aws_credentials_to_include_temp_token(token, awsconfigfile, profile, region, outputformat):
    # Write the AWS STS token into the AWS credential file
    home = str(Path.home())
    filename = home + awsconfigfile

    # Read in the existing config file
    config = configparser.RawConfigParser()
    config.read(filename)

    # Put the credentials into a specific profile instead of clobbering
    # the default credentials

    if not config.has_section(profile):
        config.add_section(profile)

    config.set(profile, 'output', outputformat)
    config.set(profile, 'region', region)
    config.set(profile, 'aws_access_key_id', token['Credentials']['AccessKeyId'])
    config.set(profile, 'aws_secret_access_key',
               token['Credentials']['SecretAccessKey'])
    config.set(profile, 'aws_session_token',
               token['Credentials']['SessionToken'])

    # Write the updated config file
    with open(filename, 'w+') as configfile:
        config.write(configfile)

# create_aws_config_file_if_none_exists function creates an aws config file and writes a minimal configuration to the credentials file
def create_aws_config_file_if_none_exists(c):
    home = str(Path.home())
    filename = home + c['awsconfigfile']
    dirname = os.path.dirname(filename)
    minimal_configuration = "[default]\noutput = json\nregion = us-east-1\naws_access_key_id =\naws_secret_access_key ="
    if not os.path.exists(dirname):
        os.makedirs(dirname)
    if not os.path.isfile(filename):
        with open(filename, 'w+') as configfile:
            configfile.write(minimal_configuration)
    # if the file exists and doesn't have the minimal configuration, it needs it or else it errors out
    elif os.path.isfile(filename):
        readConfigFile = ""
        with open(filename, 'r+') as configfile:
            readConfigFile = configfile.read()
            if not "[default]" in readConfigFile:
                configfile.write(minimal_configuration)

# Calls main at the end of the class
if __name__ == '__main__':
    main()