#!/usr/bin/env bash

helpPrompt ()
{
    echo "Description: Deploys the CDR AWS activity executors on the edge node."
    echo "Usage: ./${0} --deploy-path {DEPLOY_EDGE_NODE_DIR} --branch-name {BRANCH_NAME} --log-path {LOG_PATH}"
}

scriptDir="$(dirname $(readlink -f $0))/.."
POSITIONAL=()
while [[ $# -gt 0 ]]
do
    P1=$1
    shift
    case $P1 in
        --help|-h)
            helpPrompt
            exit 0
            ;;
        --deploy-path|-p)
            DEPLOY_PATH=$1
            shift
            ;;
        --branch-name|-b)
            BRANCH_NAME=$1
            shift
            ;;
        --log-path|-l)
            LOG_PATH=$1
            shift
            ;;
        --restart-actitivity-executors|-r)
            RESTART_EXECUTORS=$1
            shift
            ;;
        *)
            >&2 echo "Unexpected parameter: $P1"
            exit 1
            ;;
    esac
done

if [[ -z "${RESTART_EXECUTORS}" ]]; then
    RESTART_EXECUTORS=false
fi

if [[ -z "${DEPLOY_PATH}" && "${RESTART_EXECUTORS}" = "false" ]]; then
    >&2 echo "Required parameter --deploy-path not specified"
    exit 1
else
    DEPLOY_PATH=${DEPLOY_PATH:-${scriptDir}}
    if [[ -f "${DEPLOY_PATH}/activity_executors/activity_executor_vars.cfg" ]]; then
        source "${DEPLOY_PATH}/activity_executors/activity_executor_vars.cfg"
    fi
fi
BRANCH_NAME=${BRANCH_NAME:-${TF_BRANCH_NAME}}
if [[ -z "${BRANCH_NAME}" ]]; then
    >&2 echo "Required parameter --branch-name not specified"
    exit 1
fi
if [[ -z "${LOG_PATH}" ]]; then
    >&2 echo "Required parameter --log-path not specified"
    exit 1
fi

EXECUTOR_DEPLOY_DIR="${DEPLOY_PATH}/activity_executors"
mkdir -p ${EXECUTOR_DEPLOY_DIR}
echo 'Deploy artifacts to Edge Node'

echo 'Killing any existing activity executor'
cd ${EXECUTOR_DEPLOY_DIR}
if [[ -f activity_executor.pid ]] && [[ "ps -p `cat activity_executor.pid`" > /dev/null ]]
then
    ./kill_activity_executor.sh
fi

while [[ -f activity_executor.pid ]] && [[ "ps -p `cat activity_executor.pid`" > /dev/null ]]
do
    echo "activity_executor is still alive"
    sleep 5
done
echo "activity_executor finally killed" | tee -a ${LOG_PATH}/activity_executor.log

cd ${DEPLOY_PATH}
pwd

echo 'Starting activity executor'

# Hopefully everything should start in 180 seconds or less
cd ${EXECUTOR_DEPLOY_DIR}
nohup ./launch_activity_executor.sh --debug --log_path ${LOG_PATH} --artifacts_path ${DEPLOY_PATH} ${BRANCH_NAME} &> launch_activity_exec.out 2>&1
sleep 60
cat launch_activity_exec.out

echo "=== Saving the configuration for future use..."
echo "DEPLOY_PATH=${DEPLOY_PATH}
LOG_PATH=${LOG_PATH}
TF_BRANCH_NAME=${BRANCH_NAME}" > ${EXECUTOR_DEPLOY_DIR}/activity_executor_vars.cfg

if [[ -f activity_executor.pid ]] && [[ "ps -p `cat activity_executor.pid`" > /dev/null ]]
then
    echo "activity_executor started successfully!"
    exit 0
else
    echo "Could not start activity_executor in the given time"
    rm activity_executor.pid activity_executor_vars.cfg
    exit 1
fi
