#!/usr/bin/env bash

python36=/opt/rh/rh-python36/root/bin/python

$python36 -m venv orchestration

. ./orchestration/bin/activate

pip install --index-url=https://repo1.uhc.com/artifactory/api/pypi/pypi-simple/simple  requests jsonschema pyinotify

./orchestration/bin/python orchestration.py "$@"
