#@IgnoreInspection BashAddShebang
set -x
set -e
echo " === Deploying BigCDR Orchestration"

helpPrompt ()
{
    echo "Description: Deploys the CDR orchestration process on the edge node."
    echo "Usage: ./orchestration_deploy.sh --watch-path-dir {WATCH_PATH_DIR} --deploy-path {DEPLOY_EDGE_NODE_DIR} --publish-watch-path [true|false]]"
    echo "Alternate usage: ./orchestration_deploy.sh --restart-orchestration true"
}

scriptDir=$(dirname $(readlink -f $0))
POSITIONAL=()
while [[ $# -gt 0 ]]
do
    P1=$1
    shift
    case $P1 in
        --help|-h)
            helpPrompt
            exit 0
            ;;
        --watch-path-dir)
            WATCH_PATH_DIR=$1
            shift
            ;;
        --deploy-path)
            DEPLOY_PATH=$1
            shift
            ;;
        --publish-watch-path)
            PUBLISH_WATCH_PATH=$1
            shift
            ;;
        --restart-orchestration)
            RESTART_ORCHESTRATION=$1
            shift
            ;;
        --orch-log-path)
            ORCHESTRATION_LOG_PATH=$1
            shift
            ;;
        --cdrbe_tf_branch)
            cdrbe_tf_branch=$1
            ;;
        --cdrbe_aws_saml_user)
            cdrbe_aws_saml_user=$1
            ;;
        --cdrbe_aws_saml_password)
            cdrbe_aws_saml_password=$1
            ;;
        --cdrbe_aws_saml_role)
            cdrbe_aws_saml_role=$1
            ;;
        --cdrbe_aws_profile)
            cdrbe_aws_profile=$1
            ;;
        --cdrbe_aws_account)
            cdrbe_aws_account=$1
            ;;
        --s3_jars_path)
            s3_jars_path=$1
            ;;
        --jar_version)
            jar_version=$1
            ;;
    esac
done

if [[ -z "${RESTART_ORCHESTRATION}" ]]; then
    RESTART_ORCHESTRATION=false
fi


if [[ -z "${DEPLOY_PATH}" && "${RESTART_ORCHESTRATION}" = "false" ]]; then
    >&2 echo "Required parameter --deploy-path not specified"
    exit 1
else
    # Deploy_path will always be the path of the current script
    DEPLOY_PATH=${DEPLOY_PATH:-${scriptDir}}
    if [[ -f "${DEPLOY_PATH}/orchestration_vars.cfg" ]]; then
        source "${DEPLOY_PATH}/orchestration_vars.cfg"
    fi
fi

if [[ -z "${WATCH_PATH_DIR}" ]]; then
    >&2 echo "Required parameter --watch-path-dir not specified"
    exit 1
fi

if [[ -z "${PUBLISH_WATCH_PATH}" ]]; then
    PUBLISH_WATCH_PATH=false
fi

if [[ ! -d "${DEPLOY_PATH}" ]]; then
    echo "Deploy Path - ${DEPLOY_PATH} not found!"
    exit 1
fi

if [[ ! -f "${WATCH_PATH_DIR}" ]]; then
    mkdir -p ${WATCH_PATH_DIR}
    chmod 777 ${WATCH_PATH_DIR}
fi

#1 get configuration
config_file=/opt/oap/bigcdr/config/orchestration_env.cfg
if [[ ! -e  ${config_file} ]]; then
    echo "${prog}: Unable to find config file:  \"${config_file}\" "
    exit 1
fi
source ${config_file}

WORKING_DIR=$(dirname $(readlink -f "$0"))

#2 Need to specifiy appropriate user/pwd for environment
ORACLE_CDR_USER=${ORACLE_CDR_IMPORT_USER}
ORACLE_ECDR_USER=${ORACLE_ECDR_IMPORT_USER}
ORACLE_PASS=${ORACLE_IMPORT_PASS}
ORACLE_PASSWORD_FILE=${ORACLE_IMPORT_PW_FILE}
ORACLE_CONN_STRING=${DATABASE_CONNECTION}
PUBLISHED_WATCH_PATH="/opt/bigcdr/bamboo/orchestration/watch_paths/latest"
PUBLISHED_CODE_PATH="/opt/bigcdr/bamboo/orchestration/latest"

echo "======= Variables Used ======"
echo "ORACLE_CDR_USER: ${ORACLE_CDR_USER}"
echo "ORACLE_ECDR_USER: ${ORACLE_ECDR_USER}"
echo "ORACLE_PASSWORD_FILE: ${ORACLE_PASSWORD_FILE}"
echo "CDR Release: ${DEPLOY_PATH}"
echo "Watch Path: ${WATCH_PATH_DIR}"
echo "Working dir: ${WORKING_DIR}"
echo "Date: `date`"
echo "hostname: `hostname`"
echo "Deploy path: ${DEPLOY_PATH}"
echo "Deploy path contents: `ls -al ${DEPLOY_PATH}`"

cd ${DEPLOY_PATH}
set +e
#3 - shutdown existing process(es)
echo " === Checking for currently listening orchestration processes..."

if [[ -f "${DEPLOY_PATH}/orchestration.pid" ]]; then
    PREVIOUS_PROCESS=$(cat ${DEPLOY_PATH}/orchestration.pid)
    if [[ -z ${PREVIOUS_PROCESS} ]]
    then
        echo " +++ No prior orchestration listeners to kill"
    else
        PROC_ID=`ps -ef | grep ${PREVIOUS_PROCESS} | awk "/[p]ython orchestration.py/ {print \$2}"`
        if [[ ! -z ${PROC_ID} ]]
        then
            echo " +++ Found prior running process(es): $PREVIOUS_PROCESS"
            echo " +++ RESTART_ORCHESTRATION  ==> ${RESTART_ORCHESTRATION}"
            if [[ "${RESTART_ORCHESTRATION}" == "true" ]]
            then
                echo " +++ Killing previous process ${PREVIOUS_PROCESS}..."
                kill ${PREVIOUS_PROCESS}
            else
                echo " +++ Not restarting the orchestration"
                exit 0
            fi
        fi
    fi
else
    echo "${DEPLOY_PATH}/orchestration.pid not found!"
fi

set -e

#4 - standup the new listener
echo " === Attempting to watch ${WATCH_PATH_DIR} for incoming JSON msgs..."
mkdir -p ${DEPLOY_PATH}/conf/historical_jsons
chmod 777 ${DEPLOY_PATH}/conf/historical_jsons
mkdir -p ${ORCHESTRATION_LOG_PATH}/bpo_extracts
chmod 777 ${ORCHESTRATION_LOG_PATH}/bpo_extracts
mkdir -p ${ORCHESTRATION_LOG_PATH}/oracle_export
chmod 777 ${ORCHESTRATION_LOG_PATH}/oracle_export
cd ${DEPLOY_PATH}; nohup ./orchestration.sh --log_path=${ORCHESTRATION_LOG_PATH} --watch_path=${WATCH_PATH_DIR} +oracle_conn_string=${ORACLE_CONN_STRING} +oracle_cdr_user=${ORACLE_CDR_USER} +oracle_ecdr_user=${ORACLE_ECDR_USER} +oracle_password=${ORACLE_PASS} +oracle_password_file=${ORACLE_PASSWORD_FILE} +schema_password=${SCHEMA_PASS} +ORCH_CDRBE_TF_BRANCH=${cdrbe_tf_branch} +ORCH_CDRBE_AWS_SAML_USER=${cdrbe_aws_saml_user} +ORCH_CDRBE_AWS_SAML_PASSWORD=${cdrbe_aws_saml_password} +ORCH_CDRBE_AWS_SAML_ROLE=${cdrbe_aws_saml_role} +ORCH_CDRBE_AWS_PROFILE=${cdrbe_aws_profile} +ORCH_CDRBE_AWS_ACCOUNT=${cdrbe_aws_account} +ORCH_LOG_PATH=${ORCHESTRATION_LOG_PATH} +S3_JARS_PATH=${s3_jars_path} +JAR_VERSION=${jar_version}>> ./orchestration_stdout.log 2>&1 &
ln -snfv ${WATCH_PATH_DIR} ${DEPLOY_PATH}/orchestration_watch_path
chmod 777 ${DEPLOY_PATH}/orchestration_watch_path
chmod 777 ${WATCH_PATH_DIR}

echo "=== Saving orchestration configuration for future use..."
echo "DEPLOY_PATH=${DEPLOY_PATH}
ORCHESTRATION_LOG_PATH=${ORCHESTRATION_LOG_PATH}
WATCH_PATH_DIR=${WATCH_PATH_DIR}
s3_jars_path=${s3_jars_path}
jar_version=${jar_version}" > ${DEPLOY_PATH}/orchestration_vars.cfg


echo " === Create symlinks for publish dir pointing at latest release..."  # first is for files pushed to queue, second is for direct calls to create workflow json
if [[ "${PUBLISH_WATCH_PATH}" == "true" ]]
then
  echo " === Create symlinks for publish dir pointing at latest release..."  # first is for files pushed to queue, second is for direct calls to create workflow json
  echo "ln -snfv ${WATCH_PATH_DIR} ${PUBLISHED_WATCH_PATH}; ln -snfv ${DEPLOY_PATH} ${PUBLISHED_CODE_PATH}  >> ./orchestration_stdout.log 2>&1"
  ln -snfv ${WATCH_PATH_DIR} ${PUBLISHED_WATCH_PATH}; ln -snfv ${DEPLOY_PATH} ${PUBLISHED_CODE_PATH}  >> ./orchestration_stdout.log 2>&1
fi
echo " +++ Launched application; If it doesn't seem to work, check logs on edgenode @ ${DEPLOY_PATH}/orchestration_stdout.log"


