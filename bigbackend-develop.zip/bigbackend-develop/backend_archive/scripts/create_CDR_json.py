import argparse
import re
import json
import os
from shutil import copyfile, move
from datetime import datetime
import urllib.request
import ssl


class IllegalArgumentException(Exception):
    pass


def is_aws_emr_run(cl_aws_onprem_run, cl_aws_emr_run, cdrbe_config, message_type):
    if cl_aws_onprem_run and cl_aws_emr_run:
        raise Exception("aws_onprem_run and aws_emr_run are mutually exclusive.")
    elif cl_aws_onprem_run or cl_aws_emr_run:
        # Override specified via command line has precedence
        return cl_aws_emr_run

    # Check the Github config
    # Monthlies will not be running on EMR
    # we need the aws_emr_run flag to decide whether or not to push
    # monthly and day 0 ECDR datasets to S3
    if cdrbe_config["aws_onprem_daily"] and cdrbe_config["aws_emr_daily"]:
        raise Exception("cdrbe_config['aws_onprem_daily'] and cdrbe_config['aws_emr_run'] are mutually exclusive.")
    elif cdrbe_config["aws_emr_daily"]:
        # Enable EMR builds for daily based on the Github config
        aws_emr_run = True
    else:
        # Default to AWS on-prem runs
        aws_emr_run = False

    return aws_emr_run


def parse_arguments():
    arg_parser = argparse.ArgumentParser(add_help=True)
    arg_parser.add_argument("-a", "--aws_onprem_run", help="Run builds on-prem using AWS workflows", required=False,
                            default=False, action='store_const', const=True)
    arg_parser.add_argument("--aws_emr_run", help="Run builds on EMR using AWS workflows", required=False,
                            default=False, action='store_const', const=True)
    arg_parser.add_argument("-A", "--acc_streams",
                            help="Comma or whitespace separated list of streams, eg ebm,sre to include in BPO/ACC processing",
                            required=False, default="ebm,sre,qme")
    arg_parser.add_argument("-b", "--bpo_streams",
                            help="Comma or whitespace separated list of streams, eg ebm,sre to include in BPO/ACC processing",
                            required=False, default="all")
    arg_parser.add_argument("-c", "--is_current", help="If enabled, causes EOADW build to kick off", default=False,
                            action='store_const', const=True)
    arg_parser.add_argument("-C", "--client_type",
                            help="Specifies the client type opa | opa_o1_monthly. This drives which tables will be \
                           exported back to Oracle",
                            required=False, choices=["o1", "opa", "opa_o1", "opa_o1_monthly", "O1", "OPA", "OPA_O1", "OPA_O1_MONTHLY"], default="")
    arg_parser.add_argument("-d", "--cdr_delta_schema",
                            help="specify this when running against non-production cdr monthly schemas, eg CDR_DEV_2",
                            required=False, default="")
    arg_parser.add_argument("-e", "--delta_end_dt",
                            help="End date of the data, used to denote the instance for delta runs (and logging to oracle)",
                            required=False, default="")
    arg_parser.add_argument("-E", "--ecdr_enabled",
                            help="Enable day 0 ECDR for monthly builds. Denotes client is configured for eOADW",
                            default=False, action='store_const',
                            const=True)
    arg_parser.add_argument("-f", "--skip_send_files", help="Flag to skip sending BPO extracts to ACC or II",
                            default=False,
                            action='store_const', const=True)
    arg_parser.add_argument("-l", "--emr_label", help="emr label such as emr-5.33.1",
                            default="emr-5.34.0",
                            action='store_const', const=True)
    arg_parser.add_argument("-n", "--do_not_notify", help="Do not move JSON to watch path", default=False,
                            action='store_const', const=True)
    arg_parser.add_argument("-O", "--enable_oracle_export", help="Enables export to Oracle", default=False,
                            action='store_const', const=True)
    arg_parser.add_argument("-r", "--run_steps", help="Whitespace separated steps to run", required=False,
                            default="all")
    arg_parser.add_argument("-s", "--delta_start_dt",
                            help="Start date of the data, used to denote the instance for delta runs (and logging to oracle)",
                            required=False, default="")
    arg_parser.add_argument("-S", "--skip_steps", help="Whitespace separated steps to skip", required=False, default="")
    arg_parser.add_argument("client_id", help="client H number", type=str)
    arg_parser.add_argument("cdr_schema", help="CDR Schema", type=str)
    arg_parser.add_argument("message_type", help="Message type (cdr_be | delta)", choices=["cdr_be", "delta"])
    arg_parser.add_argument("environment", help="Environment (prd | stg)", choices=["prod", "stg"])
    arg_parser.add_argument("release", help="CDR Release in the format yyyyMM", type=str)
    arg_parser.add_argument("-H", "--enable_restart_for_hedis", help="Flag to restart the hedis process if thers is any issue in any of the hedis engine QME or ACC-HEDIS",
                            required=False,default=False,
                            action='store_const', const=True)

    parsed_args = arg_parser.parse_args()
    validate_args(parsed_args)
    print(f"create_CDR_json started with arguments => \n{parsed_args}")
    return parsed_args


def is_empty_str(input):
    return f"{input}" == ""


def create_dir_if_not_exists(path):
    if not os.path.exists(path):
        print(f"Directory {path} does not exist, creating it")
        try:
            os.makedirs(path)
            os.chmod(path, 0o777)
        except Exception as e:
            print(f"Could not create directory: {path}")
            raise e


def validate_args(parsed_args):
    if parsed_args.enable_oracle_export and (
            not is_empty_str(parsed_args.skip_steps) or f"{parsed_args.run_steps}".lower() != "all"):
        raise IllegalArgumentException(
            "Cannot specify enable_oracle_export when either skip_steps or run_steps are specified. "
            "\nIts only required when running all steps, as export is disabled by default. \nWhen "
            "specifying either skip_steps or run_steps export will be enabled/disabled as appropriate.")

    if not is_empty_str(parsed_args.bpo_streams) and f"{parsed_args.bpo_streams}".lower() != "all":
        bpo_streams = re.sub(r"\s+", ' ', f"{parsed_args.bpo_streams}".lower().replace(",", " ")).split(" ")
        valid_bpo_streams = ["ebm", "sre", "ii", "qme"]
        if not all(item in valid_bpo_streams for item in bpo_streams):
            raise IllegalArgumentException(f"Invalid value of BPO stream {parsed_args.bpo_streams}. " +
                                           "Must be: 'ebm', 'sre', 'qme' or 'ii'")
        else:
            parsed_args.bpo_streams = ",".join(bpo_streams).upper()

    if not is_empty_str(parsed_args.acc_streams):
        acc_streams = re.sub(r"\s+", ' ', f"{parsed_args.acc_streams}".lower().replace(",", " ")).split(" ")
        valid_acc_streams = ["ebm", "sre", 'qme']
        if not all(item in valid_acc_streams for item in acc_streams):
            raise IllegalArgumentException(f"Invalid value of ACC stream {parsed_args.acc_streams}. " +
                                           "Must be: 'ebm', 'sre', 'qme'")
        else:
            parsed_args.acc_streams = ",".join(acc_streams)

    if f"{parsed_args.message_type}" == "delta" and (is_empty_str(parsed_args.delta_end_dt)
                                                     or is_empty_str(parsed_args.delta_start_dt)):
        raise IllegalArgumentException("Arguments delta_start_dt or delta_end_dt must be specified for delta builds")


def get_config_from_gh(context, config_url):
    with urllib.request.urlopen(config_url, context=context) as json_file:
        content = json.load(json_file)
    return content


def get_all_client_config(environment, config_url, override = False):
    context = ssl.create_default_context()
    context.check_hostname = False
    context.verify_mode = ssl.CERT_NONE
    try:
        content = get_config_from_gh(context, config_url)
    except urllib.error.HTTPError as e:
        if e.getcode() == 404:
            print(f"Could not find config in {config_url}.")
            if not override:
                print("Exception while getting configs from GitHub")
                raise e
            return {}

    client_configs = content[environment] if environment in content.keys() else None
    if 'default' in content.keys():
        client_configs["default"] = content['default']
    return client_configs


def get_client_config_for(client_id, client_configs, override = False):
    if client_id not in client_configs.keys():
        if override:
            return None
        return client_configs["default"]
    else:
        return client_configs[client_id]


def get_cdrbe_config(environment, release, client_id):
    specific_config_url = f"https://github.optum.com/raw/OptumAnalyticsPlatform/oap-configs/master/CDRBE/config/{release}/cdr_be_build_config.json"
    default_config_url = "https://github.optum.com/raw/OptumAnalyticsPlatform/oap-configs/master/CDRBE/config/cdr_be_build_config.json"
    client_configs = get_all_client_config(environment, default_config_url)
    cdrbe_config = get_client_config_for(client_id, client_configs)

    override_configs = get_all_client_config(environment, specific_config_url, override=True)
    if override_configs:
        override_config = get_client_config_for(client_id, override_configs, override=True)
        if override_config:
            return override_config

    return cdrbe_config


def get_env_var(variable_name):
    try:
        return os.environ[variable_name]
    except Exception as e:
        print(f"Variable: {variable_name} not initialized")
        raise e


def get_send_notify(do_not_notify):
    if f"{do_not_notify}" == "False":
        return "True"
    else:
        return "False"


def build_cdr_config(args):
    if f"{args.environment}" == "prd":
        service_account = "svc_merc_cdr_prod"
    else:
        service_account = f"svc_merc_cdr_{args.environment}".lower()

    if f"{args.environment}" == "prod":
        env = "prd"
    else:
        env = args.environment

    if not is_empty_str(args.cdr_delta_schema):
        cdr_delta_schema = args.cdr_delta_schema
    else:
        cdr_delta_schema = f"cdr_delta_{args.release}"

    cdr_schema = args.cdr_schema
    cdrbe_config = get_cdrbe_config(env, args.release, args.client_id)

    is_emr_build = is_aws_emr_run(args.aws_onprem_run, args.aws_emr_run, cdrbe_config, args.message_type)

    ip_spark_configs = cdrbe_config["spark_configs"] if "spark_configs" in cdrbe_config else []

    emr_build_params = json.dumps(cdrbe_config["step_build_params"]) if "step_build_params" in cdrbe_config else "{}"

    if f"{args.enable_restart_for_hedis}" == "True":
        acc_streams = args.bpo_streams.lower()
    else:
        acc_streams = args.acc_streams

    if "partition_multiplier" not in cdrbe_config:
        cdrbe_config["partition_multiplier"] = "1"

    if "executor_threads" not in cdrbe_config:
        cdrbe_config["executor_threads"] = 5

    cdr_config = {
        "workflow_name": f"{args.client_id}_{env}_{args.message_type}_{cdr_schema}",
        "account": service_account,
        "clientId": args.client_id.upper(),
        "environment": env,
        "message_type": args.message_type,
        "cdr_schema": cdr_schema.lower(),
        "cdr_delta_schema": cdr_delta_schema,
        "release": args.release,
        "client_type": args.client_type.lower(),
        "isCurrent": args.is_current,
        "is_emr_build": is_emr_build,
        "data_start_dt": args.delta_start_dt,
        "data_end_dt": args.delta_end_dt,
        "sendNotify": get_send_notify(args.do_not_notify),
        "ecdrEnabled": args.ecdr_enabled,
        "bpoStreams": args.bpo_streams,
        "accStreams": acc_streams,
        "workflow_steps": args.run_steps,
        "enable_oracle_export": args.enable_oracle_export,
        "skip_steps": args.skip_steps,
        "skipSendFiles": args.skip_send_files,
        "bpo_extracts_log_path": get_env_var('bpo_extracts_log_path'),
        "oracle_export_log_path": get_env_var('oracle_export_log_path'),
        "emailTo": get_env_var('cdrMailTo'),
        "core_instance_count_monthly": cdrbe_config["core_instance_count_monthly"],
        "core_instance_count_daily": cdrbe_config["core_instance_count_daily"],
        "enableRestartForHedis": args.enable_restart_for_hedis,
        "partition_multiplier": cdrbe_config["partition_multiplier"],
        "executor_threads": cdrbe_config["executor_threads"],
        "spark_configs": ip_spark_configs,
        "step_build_params": emr_build_params,
        "emr_label": args.emr_label
    }
    return cdr_config


def start_cdrbe_in_aws(conf):
    output_json = {
        "name": conf['workflow_name'],
        "variables": {
            "account": conf['account'],
            "clientId": conf['clientId'],
            "environment": conf['environment'],
            "message_type": conf['message_type'],
            "cdr_schema": conf['cdr_schema'],
            "cdr_delta_schema": conf['cdr_delta_schema'],
            "release": conf['release'],
            "client_type": conf['client_type'],
            "isCurrent": conf['isCurrent'],
            "is_emr_daily": conf['is_emr_build'],
            "data_start_dt": conf['data_start_dt'],
            "data_end_dt": conf['data_end_dt'],
            "sendNotify": conf['sendNotify'],
            "ecdrEnabled": conf['ecdrEnabled'],
            "bpoStreams": conf['bpoStreams'],
            "accStreams": conf['accStreams'],
            "workflow_steps": conf['workflow_steps'],
            "enable_oracle_export": conf['enable_oracle_export'],
            "skip_steps": conf['skip_steps'],
            "skipSendFiles": conf['skipSendFiles'],
            "bpo_extracts_log_path": conf['bpo_extracts_log_path'],
            "oracle_export_log_path": conf['oracle_export_log_path'],
            "emailTo": conf['emailTo'],
            "core_instance_count_monthly": conf["core_instance_count_monthly"],
            "core_instance_count_daily": conf["core_instance_count_daily"],
            "enableRestartForHedis" : conf['enableRestartForHedis'],
            "partition_multiplier": conf['partition_multiplier'],
            "executor_threads": conf['executor_threads'],
            "spark_configs": conf['spark_configs'],
            "step_build_params": conf['step_build_params']
        },
        "steps": [
            {
                "name": "sns_notification",
                "script": "start_cdr_be_in_aws",
                "active": "true",
                "user": "${account}",
                "parameters": [
                    "--client_id",
                    "${clientId}",
                    "--environment",
                    "${environment}",
                    "--message_type",
                    "${message_type}",
                    "--cdr_schema",
                    "${cdr_schema}",
                    "--cdr_delta_schema",
                    "${cdr_delta_schema}",
                    "--release",
                    "${release}",
                    "--is_emr_daily",
                    "${is_emr_daily}",
                    "--client_type",
                    "${client_type}",
                    "--data_start_dt",
                    "${data_start_dt}",
                    "--data_end_dt",
                    "${data_end_dt}",
                    "--is_current",
                    "${isCurrent}",
                    "--send_notify",
                    "${sendNotify}",
                    "--ecdr_enabled",
                    "${ecdrEnabled}",
                    "--bpo_streams",
                    "${bpoStreams}",
                    "--acc_streams",
                    "${accStreams}",
                    "--run_steps",
                    "${workflow_steps}",
                    "--skip_steps",
                    "${skip_steps}",
                    "--skip_send_files",
                    "${skipSendFiles}",
                    "--bpo_extracts_log_path",
                    "${bpo_extracts_log_path}",
                    "--oracle_export_log_path",
                    "${oracle_export_log_path}",
                    "--enable_oracle_export",
                    "${enable_oracle_export}",
                    "--aws_role",
                    "${ORCH_CDRBE_AWS_SAML_ROLE}",
                    "--aws_user",
                    "${ORCH_CDRBE_AWS_SAML_USER}",
                    "--aws_pwd",
                    "${ORCH_CDRBE_AWS_SAML_PASSWORD}",
                    "--aws_profile",
                    "${ORCH_CDRBE_AWS_PROFILE}",
                    "--aws_account",
                    "${ORCH_CDRBE_AWS_ACCOUNT}",
                    "--log_path",
                    "${ORCH_LOG_PATH}",
                    "--s3_jars_path",
                    "${S3_JARS_PATH}",
                    "--jar_version",
                    "${JAR_VERSION}",
                    "--tf_branch",
                    "${ORCH_CDRBE_TF_BRANCH}",
                    "--core_instance_count_monthly",
                    "${core_instance_count_monthly}",
                    "--core_instance_count_daily",
                    "${core_instance_count_daily}",
                    "--enable_restart_for_hedis",
                    "${enableRestartForHedis}",
                    "--partition_multiplier",
                    "${partition_multiplier}",
                    "--executor_threads",
                    "${executor_threads}",
                    "--spark_configs",
                    "${spark_configs}",
                    "--step_build_params",
                    "${step_build_params}",
                    "--emr_label",
                    conf['emr_label']
                ]
            }
        ],
        "notification": {
            "user": conf['account'],
            "emails": conf['emailTo']
        }
    }

    output_file_nm = f"{conf['workflow_name']}.json"
    output_dir = get_env_var("output_dir")
    create_dir_if_not_exists(output_dir)

    output_file = f"{output_dir}/{output_file_nm}"

    print("json to be sent: ", output_json)

    print(f"Writing json to {output_file}")
    if os.path.exists(output_file):
        os.remove(output_file)
    with open(output_file, 'w') as output_json_file:
        json.dump(output_json, output_json_file, indent=4)

    audit_dir = get_env_var("audit_dir")
    create_dir_if_not_exists(audit_dir)
    now = datetime.now()
    audit_file_nm = f"{output_file_nm}.{now.strftime('%Y%m%d%H%M%S')}"
    audit_file = f"{audit_dir}/{audit_file_nm}"
    print(f"Moving json to {audit_file}")
    copyfile(output_file, audit_file)

    if f"{conf['sendNotify']}" == "False":
        cdr_queue_dir = f"{get_env_var('test_cdr_queue_dir')}"
    else:
        cdr_queue_dir = f"{get_env_var('cdr_queue_dir')}"

    print(f"Moving {output_file} to {cdr_queue_dir}")

    move(output_file, os.path.join(cdr_queue_dir, output_file_nm))


def main():
    parsed_args = parse_arguments()

    json_config = build_cdr_config(parsed_args)
    start_cdrbe_in_aws(json_config)


if __name__ == '__main__':
    main()
