#!/usr/bin/env bash

set -e

helpPrompt ()
{
    echo "Description: Copies yarn-spark-archive-<env>-bin.zip to hdfs:///user/svc_merc_cdr_<env>/CDR-lib/yarn-spark-archive-<env>-bin.zip."
    echo "Usage: copy_spark_yarn_archive.sh --env env --spark-yarn-archive filename"
}

ENV=""
SPARK_YARN_ARCHIVE=""

POSITIONAL=()
while [[ $# -gt 0 ]]
do
    P1=$1
    shift
    case $P1 in
        --help|-h)
            helpPrompt
            exit 0
            ;;
        --env)
            ENV=$1
            shift
            ;;
        --spark-yarn-archive)
            SPARK_YARN_ARCHIVE=$1
            shift
            ;;
        *)
            >&2 echo "Unexpected parameter: $P1"
            exit 1
            ;;
    esac
done

if [ -z "$ENV" ]; then
    >&2 echo "--env is a required parameter."
    exit 1
fi

if [ -z "$SPARK_YARN_ARCHIVE" ]; then
    >&2 echo "--spark-yarn-archive is a required parameter."
    exit 1
fi

if [ ! -f "./$SPARK_YARN_ARCHIVE" ]; then
    >&2 echo "./$SPARK_YARN_ARCHIVE does not exist."
    exit 1
fi

ENV=$(echo $ENV | tr "[:upper:]" "[:lower:]")
SVC_CDR_USER_NAME="svc_merc_cdr_$ENV"
HDFS_CDR_LIB="hdfs:///user/${SVC_CDR_USER_NAME}/cdr-lib"
HDFS_SPARK_YARN_ARCHIVE="$HDFS_CDR_LIB/$SPARK_YARN_ARCHIVE"

sudo -u $SVC_CDR_USER_NAME kinit -ki

sudo -u $SVC_CDR_USER_NAME hdfs dfs -mkdir -p "$HDFS_CDR_LIB"

if (sudo -u $SVC_CDR_USER_NAME hdfs dfs -test -f $HDFS_SPARK_YARN_ARCHIVE); then
    REMOTE_HASH=$(sudo -u $SVC_CDR_USER_NAME hdfs dfs -cat $HDFS_SPARK_YARN_ARCHIVE | sha256sum)
else
    REMOTE_HASH=404
fi

LOCAL_HASH=$(cat $SPARK_YARN_ARCHIVE | sha256sum)

echo "REMOTE_HASH=$REMOTE_HASH"
echo "LOCAL_HASH=$LOCAL_HASH"
if [ "$LOCAL_HASH" != "$REMOTE_HASH" ]; then
    echo "Copying $SPARK_YARN_ARCHIVE to HDFS"
    sudo -u $SVC_CDR_USER_NAME hdfs dfs -cp -f "file://$(pwd)/$SPARK_YARN_ARCHIVE" "$HDFS_SPARK_YARN_ARCHIVE"
else
    echo "HDFS copy of $SPARK_YARN_ARCHIVE already exists. Skipping."
fi