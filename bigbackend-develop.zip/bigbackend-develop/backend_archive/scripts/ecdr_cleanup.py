import argparse
import logging
import os
import re
import subprocess
import sys
from datetime import datetime
from dateutil import relativedelta

from typing import List, Any, Union

MAX_LENGTH = 2000

argParser = argparse.ArgumentParser(add_help=False)
argParser.add_argument("-lF", "--logFilePath", help="Log file path.", required=True)
argParser.add_argument("-v", "--verbose", help="verbose logging", required=False, default=False, const=True, action='store_const')
argParser.add_argument("-x", "--dryrun", help="dry run only, show planned deletions instead of actually deleting", required=False, default=False, action='store_const', const=True)
argParser.add_argument("-c", "--clients", help="specify specific client(s) to clean in a comma separated list ex: H123456,H987654[....]", required=False, default="")
argParser.add_argument("-e", "--envs", help="specify specific environment(s) to clean in a comma separated list ex: stg,prd,dev", required=False, default="")
argParser.add_argument("-d", "--dirs", help="specify specific dir levels(s) to clean in a comma separated list ex: ecdr,oadw,cdr_be", required=False, default="")
argParser.add_argument("-du", "--diskUsage", help="Print disk usage of the directories", required=False, default="", action='store_const', const=True)
argParser.add_argument("-conf", "--config", help="Ignore the clients present in the config file", required=False)
argParser.add_argument("-cont", "--continueFrom", help = "Run the cleanup process from this group", required=False)

MAIL_IDS = ["pawan@optum.com", "arivoli@optum.com", "ian.crisp@optum.com", "bisharjan.pokharel@optum.com", "padma.avula@optum.com", "maddela_suresh@optum.com"]
parsed_args = argParser.parse_args()

LOG_FILE_PATH = parsed_args.logFilePath
if parsed_args.verbose:
    LOG_LEVEL = logging.DEBUG
else:
    LOG_LEVEL = logging.INFO
DRY_RUN = parsed_args.dryrun
DISK_USAGE = parsed_args.diskUsage

CLEARED_DBS = []

logging.basicConfig(filename=LOG_FILE_PATH, filemode='w', format='%(asctime)s - %(levelname)s - %(message)s', datefmt='%d-%b-%y %H:%M:%S', level=LOG_LEVEL)

def run_kinit(user, logger):
    command = create_command("kinit", ["-ki"], user)
    return launch_command(command, logger)

def create_command(command, parameters, user):
    user_part = [] if user is None else ['sudo', '-u', user]
    command = user_part + [command] + [str(x) for x in parameters]
    return command

def launch_command(command, logger, data_in=None) -> (str, str):
    logger.debug("Executing command: " + str(command))
    proc = subprocess.Popen(command, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, stdin=subprocess.PIPE, universal_newlines=True)

    if not data_in:
        stdout, stderr = proc.communicate()
    else:
        stdout, stderr = proc.communicate(input=data_in)
    if len(stdout) != 0:
        logger.debug("Begin command logs\n-----\n" + stdout + "\n-----\nEnd command logs")

    if proc.returncode != 0:
        message = (stdout[:MAX_LENGTH - 3] + '...') if len(stdout) > MAX_LENGTH else stdout
        #logger.error(f"Got non-zero return code from {str(command)}. Log follows:\n{message}")
        return False

    return stdout

def create_hive_query_command(query, env):
    return create_command("/usr/hdp/current/hive-client/bin/beeline", ["-u",
                                                                       "jdbc:hive2://som-horton-p1-m4.humedica.net:2181,som-horton-p1-m5.humedica.net:2181,som-horton-p1-m6.humedica.net:2181/;serviceDiscoveryMode=zooKeeper;zooKeeperNamespace=hiveserver2",
                                                                       '--silent=true',
                                                                       '--outputformat=csv2',
                                                                       '--fastConnect=true',
                                                                       "-e", query], get_service_account(env))

def launch_command_async(command):
    #logging.info("Executing command Asynchronously: " + str(command))
    subprocess.Popen(command, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, stdin=subprocess.PIPE, universal_newlines=True)

def get_service_account(env):
    if env == 'prd':
        return 'svc_merc_cdr_prod'
    else:
        return 'svc_merc_cdr_{0}'.format(env)

def get_all_dbs(env, group,logger):
    regex_filter = group.lower() + '_' + env.lower() + '_(ecdr|cdr_be)' + '_cdr_delta_[\d]{6}.*$'
    compiled_pattern = re.compile(regex_filter)
    command = create_hive_query_command("SHOW DATABASES;", env)
    ret_val = launch_command(command, logger)

    found_dbs = list([]) if type(ret_val) is bool else list(ret_val.splitlines())
    filtered_dbs = list(filter(compiled_pattern.search, found_dbs))
    # log_debug(f" DBs for drop consideration: {', '.join(filtered_dbs)}")

    return sorted(filtered_dbs)

def get_all_monthly_dbs(env, group, logger):
    regex_filter = group.lower() + '_' + env.lower() + '_(cdr_be)' + '_cdr_[\d]{6}.*$'
    compiled_pattern = re.compile(regex_filter)
    command = create_hive_query_command("SHOW DATABASES;", env)
    ret_val = launch_command(command, logger)

    found_dbs = list([]) if type(ret_val) is bool else list(ret_val.splitlines())
    filtered_dbs = list(filter(compiled_pattern.search, found_dbs))

    return sorted(filtered_dbs)

def send_mail(subject, message, email_ids):
    message = f'{message}\n\n'
    email_command = create_command("mail",[ "-s", subject, email_ids], None)
    launch_command(email_command, logging, message)

def read_log_file(log_file_path):
    with open(log_file_path) as log_file:
        return log_file.read()

def send_log_as_mail():
    subject = "ECDR cleanup running " + str(datetime.now())
    message = read_log_file(LOG_FILE_PATH)
    send_mail(subject, message,','.join(MAIL_IDS))

def get_release_cycle(hive_db):
    regex_filter = '^h[0-9]{6}_.*_(ecdr|cdr_be)_cdr_([0-9]{6}).*$'
    compiled_pattern = re.compile(regex_filter)
    matches = re.search(compiled_pattern, hive_db)
    return int(matches.groups()[1])

def get_x_months_from_today(x):
    d = datetime.now()
    d2 = d - relativedelta.relativedelta(months=x)
    return d2.strftime("%Y%m")

def filter_recent_dbs(all_dbs):
    recent_months = [get_x_months_from_today(i) for i in range(0, 4)]
    filtered_dbs = []
    for db in all_dbs:
        release_cycle = str(get_release_cycle(db))
        if release_cycle not in recent_months:
            filtered_dbs.append(db)

    return sorted(filtered_dbs)

def filter_recent_monthly_paths(paths):
    recent_months = [get_x_months_from_today(i) for i in range(0, 4)]
    filtered_paths = []
    for path in paths:
        cycle = path.split('/')[-1].strip('cdr_')
        if cycle not in recent_months:
            filtered_paths.append(path)

    return filtered_paths


def main():
    groups = get_all_groups()
    environments = get_environments()
    for env in environments:
        svc_user = get_service_account(env)
        run_kinit(svc_user, logging)
        for group in groups:
            if DISK_USAGE:
                print_disk_usage(svc_user, group.strip(), env, logging)
            else:
                remove_data(svc_user, group.strip(), env, logging)
                remove_monthly_data(svc_user, group.strip(), env, logging)
                #all_dbs = get_all_dbs(env, group.strip(),  logging)
                #clean_hive_db_with_no_hdfs_location(all_dbs, CLEARED_DBS, env, logging)
                #all_monthly_dbs = get_all_monthly_dbs(env,group.strip(), logging)
                #all_monthly_dbs = filter_recent_dbs(all_monthly_dbs)
                #clean_hive_db_with_no_hdfs_location(all_monthly_dbs, CLEARED_DBS, env, logging)
    send_log_as_mail()

def get_delta_paths(svc_user, group, env, dir, logger):
    hdfs_path_format = "/optum/data_factory/{0}/{1}/{2}/cdr_delta_*/"  # /optum/data_factory/<groupid>/<env>/<ecdr|oadw>/
    hdfs_formatted_command = hdfs_path_format.format(group, env, dir)
    command = create_command("hdfs", ["dfs", "-ls", "-C", hdfs_formatted_command], svc_user)
    ret_val = launch_command(command, logger)
    paths = [] if type(ret_val) is bool else ret_val.splitlines()
    return list(paths)

def get_hdfs_location(dbname, env, logger):
    command = create_hive_query_command(f"DESCRIBE FORMATTED {dbname}.schema_init;", env)
    ret_val = launch_command(command, logger)
    md_table_data = list([]) if type(ret_val) is bool else list(ret_val.splitlines())
    hdfs_location = "< not found! >" # if there was an error running the above command or if Location is not found in schema_init
    for row in md_table_data:
        if 'Location:' in row:
            # Remove /schema_init from the end
            hdfs_location = (row.split(',')[1].strip()).rpartition('/')[0]
            break
    return hdfs_location

def clean_hive_db_with_no_hdfs_location(all_dbs, cleared_dbs, env, logger):
    logger.info("Cleaning hive db with no hdfs location")
    dbs_to_check = set(all_dbs) - set(cleared_dbs)
    for db in dbs_to_check:
        hdfs_path = get_hdfs_location(db, env, logger)
        command = create_command("hdfs", ["dfs", "-ls", hdfs_path], get_service_account(env))
        if not launch_command(command, logger):
            delete_cdr_hive_db(db_name = db, all_dbs = all_dbs, env = env, logger = logger)

def delete_from_hdfs(path, svc_user):
    if DRY_RUN:
        logging.info(f" ++ [DRY_RUN] Deleting path: {path}")
    else:
        logging.info(f" ++ Deleting path: {path}")
        remove_command = create_command("hdfs", ["dfs", "-rm", "-R", "-skipTrash", path], svc_user)
        launch_command(remove_command, logging)

def get_unique_deltas(valid_paths, compiled_pattern):
    unique_deltas = set()
    for path in valid_paths: unique_deltas.add(re.findall(compiled_pattern, path).pop())
    return unique_deltas

def filter_recent_paths(paths, svc_user, logger):
    date_pattern = '(2\d{3}-(0[1-9]|1[0-2])-(0[1-9]|[12]\d|3[01]))'
    compiled_pattern = re.compile(date_pattern)
    filtered_paths = []
    for path in paths:
        print(path)
        command = create_command("hdfs", ["dfs", "-stat", "%y" ,path], svc_user)
        ret_val = launch_command(command, logger)
        print(ret_val)
        if not ret_val:
            continue
        creation_date = list(map(lambda x: int(x), re.search(compiled_pattern, ret_val).group(0).split('-')))
        date_created = datetime(*creation_date)
        current_date = list(map(lambda x: int(x), str(datetime.now()).split()[0].split('-')))
        check_date = datetime(*current_date)
        difference = check_date - date_created
        if difference.days > 8:
            filtered_paths.append(path)

    return filtered_paths


def construct_hive_db_from_path(hdfs_path):
    return hdfs_path.replace('/optum/data_factory/', '').replace('/', '_').rstrip('_').lower()

def delete_cdr_hive_db(all_dbs, env, logger, hdfs_path = None, db_name = None,):
    if db_name is None:
        hive_db = construct_hive_db_from_path(hdfs_path)
    else:
        hive_db = db_name

    if DRY_RUN:
        if hive_db in all_dbs:
            logger.info(f" ++ [DRY_RUN] Dropping Hive DB: {hive_db}")
            CLEARED_DBS.append(hive_db)
        else:
            logger.info(f" ++[DRY_RUN] Hive DB: {hive_db} does not exist")
    else:
        if hive_db in all_dbs:
            logger.info(f" ++ Dropping Hive DB: {hive_db}")
            query = f"DROP DATABASE {hive_db} CASCADE;"
            command = create_hive_query_command(query, env)
            launch_command_async(command)
            CLEARED_DBS.append(hive_db)
        else:
            logger.info(f" ++ Hive DB: {hive_db}does not exist")

def get_monthly_paths(svc_user, group, env, dir, logger):
    hdfs_path = f"/optum/data_factory/{group}/{env}/{dir}/"
    command = create_command("hdfs", ["dfs", "-ls", "-C", hdfs_path], svc_user)
    ret_val = launch_command(command, logger)
    paths = [] if type(ret_val) is bool else ret_val.splitlines()
    return list(paths)


def remove_monthly_data(svc_user, group, env, logger):
    cdr_monthly_pattern = "/optum/data_factory/H[0-9]*/\w+/\w+/(cdr_20[0-9]{4})"
    compiled_pattern = re.compile(cdr_monthly_pattern)
    dir_levels = get_dir_levels()
    #all_dbs = get_all_monthly_dbs(env,group.strip(), logger)
    #all_dbs = filter_recent_dbs(all_dbs)
    for dir in dir_levels:
        logging.info(f" ++ Processing group {group} - Environment {env} -Dir level {dir}")
        directory_size = get_disk_usage(svc_user, group, env, dir)
        logging.info(f" ++Size of directory before cleanup - {directory_size}")
        paths = get_monthly_paths(svc_user, group, env, dir, logger)
        valid_paths = list(filter(compiled_pattern.search, paths))
        unique_paths = sorted(valid_paths)
        old_monthly_paths = unique_paths[:len(unique_paths) - 4] if len(unique_paths) > 4 else []
        old_monthly_paths = filter_recent_paths(old_monthly_paths, svc_user, logger)
        old_monthly_paths = filter_recent_monthly_paths(old_monthly_paths)
        for old_monthly in old_monthly_paths:
            delete_from_hdfs(old_monthly, svc_user)
            #delete_cdr_hive_db(hdfs_path = old_monthly, all_dbs = all_dbs, env = env, logger = logger)
        directory_size_after = get_disk_usage(svc_user, group, env, dir)
        logging.info(f"++ Size of directory after cleanup - {directory_size_after}\n")


# For a given environment and group
## For a given level(ecdr or oadw)
### gather hdfs paths
### from those paths, extract unique cdr_delta_* values
#### sort the cdr_delta_* values in ascending order
#### identify stale delta(s) i.e. deltas older than 3 CDR cycle e.g. if last cycle is CDR_202005
###If the builds are
###         cdr_delta201911
###         cdr_delta201912
###         cdr_delta202001
###         cdr_delta202002
###         cdr_delta202003
###         cdr_delta202004
###         cdr_delta202005
### it keeps the last two builds and deletes from cdr_delta201911 to cdr_delta202002
### within cdr_detla202004 and cdr_delta202005 it keeps the recent 8 builds and deletes the older ones.
#### for each cdr delta value
#### identify old builds and issue hdfs rm+rmDir command
def remove_data(svc_user, group, env, logger):
    cdr_delta_pattern = "/optum/data_factory/H[0-9]*/\w+/\w+/(cdr_delta_[0-9]{6})/[0-9]{8}" # for extracting unique cdr_delta_ cycles paths ending in YYYYMMDD format
    compiled_pattern = re.compile(cdr_delta_pattern)
    dir_levels = get_dir_levels()
    #all_dbs = get_all_dbs(env,group.strip(),  logger)
    for dir in dir_levels:
        logging.info(f" ++ Processing group {group} - Environment {env} - Dir level {dir}")
        directory_size = get_disk_usage(svc_user, group, env, dir)
        logging.info(f" ++ Size of directory before cleanup - {directory_size}")
        paths = get_delta_paths(svc_user, group, env, dir, logger)
        valid_paths = list(filter(compiled_pattern.search, paths))
        unique_deltas = get_unique_deltas(valid_paths, compiled_pattern)
        converted_unique_deltas = sorted(unique_deltas)
        old_deltas = converted_unique_deltas[:len(converted_unique_deltas) - 4] if len(converted_unique_deltas) > 4 else []
        for oldDelta in old_deltas:
            path = "/optum/data_factory/{0}/{1}/{2}/{3}/".format(group, env, dir, oldDelta)
            delete_from_hdfs(path, svc_user)
            #delete_cdr_hive_db(hdfs_path = path, all_dbs = all_dbs, env = env, logger = logger)
        for delta in converted_unique_deltas:
            filtered_delta = sorted([path for path in valid_paths if delta in path])
            old_items = filtered_delta[:len(filtered_delta) - 8] if len(filtered_delta) > 8 else []
            old_items = filter_recent_paths(old_items, svc_user, logger)
            for item in old_items:
                delete_from_hdfs(item, svc_user)
                #delete_cdr_hive_db(hdfs_path = item, all_dbs = all_dbs, env = env, logger = logger)
        directory_size_after = get_disk_usage(svc_user, group, env, dir)
        logging.info(f" ++ Size of directory after cleanup - {directory_size_after}\n")

def get_disk_usage(svc_user, group, env, dir):
    hdfs_dir = f'/optum/data_factory/{group}/{env}/{dir}/'
    usage_command = create_command('hdfs', ['dfs', '-du', '-h', '-s', hdfs_dir], svc_user)
    directory_size = launch_command(usage_command, logging)
    if directory_size:
        return directory_size.split('/')[0]
    return '0'

def print_disk_usage(svc_user, group, env, logging):
    dir_levels = get_dir_levels()
    for dir in dir_levels:
        #logging.info(f" ++ Processing group {group} - Environment {env} - Dir level {dir}")
        path = "/optum/data_factory/{0}/{1}/{2}/".format(group, env, dir)
        usage_command = create_command("hdfs", ["dfs", "-du", "-h", path], svc_user)
        stdout = launch_command(usage_command, logging)
        logging.info(stdout)

# Extract all groups. Ignore G64 and default groups
def get_all_groups():
    if not parsed_args.clients:
        svc_user = "svc_merc_cdr_prod"
        run_kinit(svc_user, logging)
        command = create_command("hdfs", ["dfs", "-ls", "-C", "/optum/data_factory/"], get_service_account("prd"))
        ret_val = list(launch_command(command, logging).splitlines())
        groups = list(map(lambda path: path.replace("/optum/data_factory/", ""), ret_val))
        with open(parsed_args.config, 'r') as config:
            IGNORE_GROUPS = list(filter(lambda x: len(x) > 0, config.read().split('\n')))
        filtered_groups = [group for group in groups if str(group).startswith("H") and group not in IGNORE_GROUPS]
        if parsed_args.continueFrom:
            filtered_groups = filtered_groups[filtered_groups.index(parsed_args.continueFrom):]
        logging.info(f" ++ Clients to scan: {filtered_groups}")
    else:
        filtered_groups = parsed_args.clients.split(",")
        logging.info(f" ++ ONLY scanning: {filtered_groups}")
    return list(filtered_groups)

def get_environments():
    default = ["stg", "prd"]
    if not parsed_args.envs:
        envs = default
    else:
        envs = parsed_args.envs.split(",")

    logging.info(f" ++ Running environments {envs}")
    return envs


def get_dir_levels():
    default = ["ecdr", "oadw", "cdr_be", "cdr_fe"]
    if not parsed_args.dirs:
        dirs = default
    else:
        dirs = parsed_args.dirs.split(",")

    logging.info(f" ++ Processing dirs {dirs}")
    return dirs


if __name__ == '__main__':
    main()
