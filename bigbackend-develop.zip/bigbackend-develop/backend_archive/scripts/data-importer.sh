#!/usr/bin/env bash

###########################################
# Command : sudo -u svc_oadw_stg ./data-importer.sh cdrBE --clientId H743123 --jdbcHost som-racload03.humedica.net --userName pmishra --password pwd --dbName engr --schema CDR_201905 --level cdr_be --environment stg --instance pawan_test
###########################################

SCRIPT_ROOT=$( dirname "${BASH_SOURCE[0]}" )
DEFAULT_OJDBC_JAR="@@default-jdbc-jar@@"
DEFAULT_SPARK_HOME="@@default-spark-home@@"
DEFAULT_SPARK_EXECUTOR_MEMORY=12g
DEFAULT_SPARK_EXECUTOR_CORES=1
DEFAULT_SPARK_EXECUTOR_COUNT=24 # num_of_executor * num_of_cores_per_executor = num of concurrent connection
DEFAULT_DRIVER_CORES=8
YARN_ARCHIVE_CLAUSE="--conf spark.yarn.archive=@@spark-yarn-archive-path@@"
SPARK_MAX_ATTEMPTS=1

ARCHIVE_NAME=bigbackend_importer
ARCHIVE_VERSION=@@project.version@@
APP_JAR="${ARCHIVE_NAME}-${ARCHIVE_VERSION}.jar"

MAIN_CLASS="com.optum.oap.backend.importer.Main"
DO_WAIT="false"

## SPARK_HOME
if [[ -z "$SPARK_HOME" ]]
then
    if [[ -d "$DEFAULT_SPARK_HOME" ]]
    then
        SPARK_HOME=$DEFAULT_SPARK_HOME
    else
        echo "SPARK_HOME not set and $DEFAULT_SPARK_HOME does not exist."
        exit 1
    fi
fi

## SPARK_MASTER
if [[ -z "$SPARK_MASTER" ]]
then
    SPARK_MASTER=yarn
fi

## SPARK_EXECUTOR_MEMORY
if [[ -z "$SPARK_EXECUTOR_MEMORY" ]]
then
    SPARK_EXECUTOR_MEMORY=$DEFAULT_SPARK_EXECUTOR_MEMORY
fi

## SPARK_EXECUTOR_CORES
if [[ -z "$SPARK_EXECUTOR_CORES" ]]
then
    SPARK_EXECUTOR_CORES=$DEFAULT_SPARK_EXECUTOR_CORES
fi

## SPARK_EXECUTOR_COUNT
if [[ -z "$SPARK_EXECUTOR_COUNT" ]]
then
    SPARK_EXECUTOR_COUNT=$DEFAULT_SPARK_EXECUTOR_COUNT
fi

## SPARK_DEPLOY_MODE
if [[ -z "$SPARK_DEPLOY_MODE" ]]
then
    SPARK_DEPLOY_MODE=cluster
fi

## Find the app jar using a search path
SCRIPT_ROOT=$(dirname $(readlink -f $0))
SEARCH_ORDER=(
    .
    ./build/libs
    $SCRIPT_ROOT/../lib
    $SCRIPT_ROOT)
APP_LIB=""
for X in ${SEARCH_ORDER[@]}
do
    if [[ -f "$X/${APP_JAR}" ]]
    then
        APP_LIB=$X
        break
    fi
done
if [[ -z "$APP_LIB" ]]
then
    echo "Could not find the application jar in one of the search directories ${SEARCH_ORDER[@]}"
    # exit 1
fi

POSITIONAL=()
while [[ $# -gt 0 ]]
do
key="$1"

case $key in
    --clientId)
    CLIENT="$2"
    POSITIONAL+=("$1")
    POSITIONAL+=("$2")
    shift # past argument
    shift # past value
    ;;
    --schema)
    SCHEMA="$2"
    POSITIONAL+=("$1")
    POSITIONAL+=("$2")
    shift # past argument
    shift # past value
    ;;
    *)    # unknown option
    POSITIONAL+=("$1") # save it in an array for later
    shift # past argument
    ;;
esac
done
set -- "${POSITIONAL[@]}" # restore positional parameters

APPNAME="bigbackend_importer_${CLIENT}_${SCHEMA}"

echo "APPNAME=$APPNAME"
echo "SPARK_HOME=$SPARK_HOME"
echo "SPARK_MASTER=$SPARK_MASTER"
echo "SPARK_DEPLOY_MODE=$SPARK_DEPLOY_MODE"
echo "MAIN_CLASS=$MAIN_CLASS"
echo "SPARK_EXECUTOR_MEMORY=$SPARK_EXECUTOR_MEMORY"
echo "SPARK_EXECUTOR_CORES=$SPARK_EXECUTOR_CORES"
echo "SPARK_EXECUTOR_COUNT=$SPARK_EXECUTOR_COUNT"
echo "YARN_ARCHIVE_CLAUSE=$YARN_ARCHIVE_CLAUSE"
echo "APP_LIB=$APP_LIB"
echo "APP_JAR=$APP_JAR"

cmd='$SPARK_HOME/bin/spark-submit
  --class $MAIN_CLASS
  --name "$APPNAME"
  --master $SPARK_MASTER
  --deploy-mode $SPARK_DEPLOY_MODE
  --jars $DEFAULT_OJDBC_JAR

  --conf "spark.driver.maxResultSize=8g"

  --num-executors $SPARK_EXECUTOR_COUNT
  --executor-memory $SPARK_EXECUTOR_MEMORY
  --executor-cores $SPARK_EXECUTOR_CORES
  --driver-memory $SPARK_EXECUTOR_MEMORY
  --driver-cores $DEFAULT_DRIVER_CORES

  --conf "spark.yarn.maxAppAttempts=${SPARK_MAX_ATTEMPTS}"
  --conf "spark.yarn.submit.waitAppCompletion=${DO_WAIT}"
  --conf "spark.executor.memoryOverhead=2g"
  --conf "spark.scheduler.mode=FAIR"
  --conf "spark.home={SPARK_HOME}"
  --conf "spark.io.compression.codec=snappy"
  --conf spark.sql.parquet.compression.codec=gzip
  --conf "spark.kryo.unsafe=true"
  --conf "spark.kryoserializer.buffer.max=1024m"
  --conf "spark.sql.parquet.writeLegacyFormat=true"
  --conf "spark.serializer=org.apache.spark.serializer.KryoSerializer"
  --conf "spark.hadoop.mapreduce.fileoutputcommitter.algorithm.version=2"
  $YARN_ARCHIVE_CLAUSE
  ${APP_LIB}/${APP_JAR} $@'

eval $cmd
