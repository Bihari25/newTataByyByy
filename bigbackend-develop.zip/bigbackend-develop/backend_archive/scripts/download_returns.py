import logging
import argparse
import command_utils
import gzip
import os
import glob
import concurrent.futures

from pathlib import Path

"""
Download the acc returns from the azure blob to hdfs.

Can be used to run manually the downloads in case the processId and transactionId are not populated in the oracle tracker tables.
Or to run downloads for an older process or transactionIds.

The returns will be downloaded from https://oapcloudstoacc.blob.core.windows.net/oapcloudstocont/cdrbe/returns/{client_id}/{environment}/{cdr_cycle}/{extract_type}/{process_id}/{transaction_id}
and copied to /optum/data_factory/{client_id}/{environment}/cdr_be/{cdr_cycle}/{instance}/acc_returns/{extract_type}/{process_id}

To run:
1) Copy this script (download_returns.py) and (command_utils.py) to a directory in edgenode. both scripts must be at the same location.
2) Run the script from the directory 
Usage: python3 download_returns.py --clientId CLIENTID --user USER --env ENV
                           --cdrCycle CDRCYCLE --instance INSTANCE
                           --extractType EXTRACTTYPE --processId PROCESSID
                           --transId TRANSID
                           
Sample command:
svc python3 download_returns.py --clientId H302436 --user svc_merc_cdr_stg --env stg --cdrCycle cdr_202104 --instance 2 --extractType ebm --processId 45946 --transId e03b7f5a-9d66-4109-8e2d-a24bd49183bd

Note: Remove the directories from the temp location (data/cdrbe/temp/returns/{client_id}/{environment}/{cdr_cycle}/{extract_type}/{process_id}/) once download is complete.
"""


SAAS_TOKEN_FILE = 'azure_acc_saas_token.txt'

def read_content_from_hdfs_file(logger, user, file_path):
    cmd = "hdfs"
    parameters = ["dfs", "-cat", file_path]
    return command_utils.launch_command(cmd, parameters, logger, user)

def copy_from_azure_to_phiops(logger, user, source_path, destination_path):
    cmd = '/opt/bigcdr/azure_acc/azcopy'
    paramters = ['copy', source_path, destination_path, '--recursive']
    command_utils.launch_command(cmd, paramters, logger, user)

def copy_from_phiops_to_hdfs(logger, user, source_path, destination_path):
    cmd = 'hdfs'
    parameters = ['dfs', '-copyFromLocal', source_path, destination_path]
    create_hdfs_path_if_not_exists(logger, user, destination_path)
    command_utils.launch_command(cmd, parameters, logger, user)

def create_hdfs_path_if_not_exists(logger, user, path):
    cmd = 'hdfs'
    parameters = ['dfs', '-mkdir', '-p', path]
    command_utils.launch_command(cmd, parameters, logger, user)

def create_path_if_not_exists(logger, user, path):
    cmd = "mkdir"
    parameters = ['-p', path]
    command_utils.launch_command(cmd, parameters, logger, user)

def remove_directory(logger, user, path):
    cmd = 'rm'
    paramters = ['-r', path]
    command_utils.launch_command(cmd, paramters, logger, user)

def gz_files(model_path, files):
    for txt_file in files:
        with open(txt_file, 'rb') as txt_data:
            output = gzip.compress(txt_data.read())

        with open(f'{model_path}.gz', 'ab+') as gz_file:
            gz_file.write(output)



def chmod_folder(logger, user, path):
    cmd = 'chmod'
    parameters = ['-R',777,path]
    command_utils.launch_command(cmd, parameters, logger, user)


def gz_and_remove_file(logger, user, model):
    model_path = f'{model}'
    part_files = glob.glob(f'{model_path}/*.txt')
    gz_files(model_path, part_files)
    print(model_path)
    remove_directory(logger, user, f'{model_path}/')


def get_models_path(models_base_path):
    models = list(filter(lambda x: not x.endswith('.gz'), os.listdir(models_base_path)))
    return [models_base_path + model for model in models]



def gz_returns(logger, user, path, stream):
    models = []
    if stream == 'ebm':
        all_files = os.listdir(path)
        enddate_files = list(filter(lambda x: x.startswith('enddate'), all_files))
        for end_date in enddate_files:
            models_base_path = f'{path}/{end_date}/analytic=ebm/'
            print("Processing modes_base_path", models_base_path)
            models +=get_models_path(models_base_path)
    elif stream == 'sre':
        models_base_path = f'{path}/analytic=sre/'
        models += get_models_path(models_base_path)

    print(models)


    with concurrent.futures.ThreadPoolExecutor(max_workers = 4) as executor:
        futures = {executor.submit(gz_and_remove_file, logger, user, model): model for model in models}
        for future in concurrent.futures.as_completed(futures):
            try:
                model = futures[future]
                future.result()
            except Exception as ex:
                logger.error(f"Error in zipping {model}")
                logger.exception(ex)
            else:
                logger.info(f"zipping finished for {model}")



def main():
    logger = logging.getLogger(__name__)
    logger.setLevel(logging.INFO)
    parser = argparse.ArgumentParser(description="Copy returns from azure to hdfs")

    parser.add_argument('--clientId', required=True)
    parser.add_argument('--user', required = True)
    parser.add_argument('--env', required=True)
    parser.add_argument('--cdrCycle', required=True)
    parser.add_argument('--instance', required=True)
    parser.add_argument('--extractType', required=True)
    parser.add_argument('--processId', required=True)
    parser.add_argument('--transId', required = True)


    args = parser.parse_args()

    client_id = args.clientId
    environment = args.env
    cdr_cycle = args.cdrCycle
    instance = args.instance
    user = args.user
    _, saas_token = read_content_from_hdfs_file(logger, user, SAAS_TOKEN_FILE)
    saas_token = saas_token.rstrip('\n')

    process_id = args.processId
    extract_mapping = {'ebm':'bpo_pyr_ebm', 'sre': 'bpo_pyr_sre'}
    transaction_id  = args.transId
    extract_type = args.extractType
    source_path = f"https://oapcloudstoacc.blob.core.windows.net/oapcloudstocont/cdrbe/returns/{client_id}/{environment}/{cdr_cycle}/{extract_type}/{process_id}/{transaction_id}"
    destination_path = f'/data/cdrbe/temp/returns/{client_id}/{environment}/{cdr_cycle}/{extract_mapping[extract_type]}/{process_id}/'
    source_with_token = f'{source_path}?{saas_token}'
    create_path_if_not_exists(logger, user,destination_path)
    copy_from_azure_to_phiops(logger, user, source_with_token, destination_path)
    chmod_folder(logger, user, destination_path)
    if extract_type == 'ebm':
        gz_returns(logger, user,destination_path + transaction_id, "ebm")
    elif extract_type == 'sre':
        gz_returns(logger, user, destination_path + transaction_id, "sre")

    hdfs_path = f'/optum/data_factory/{client_id}/{environment}/cdr_be/{cdr_cycle}/{instance}/acc_returns/{extract_mapping[extract_type]}/{process_id}'
    copy_from_phiops_to_hdfs(logger, user, f'{destination_path}{transaction_id}',hdfs_path)

if __name__ == '__main__':
    main()

