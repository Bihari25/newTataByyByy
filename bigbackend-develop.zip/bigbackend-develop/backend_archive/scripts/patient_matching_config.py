import cx_Oracle
import json
import argparse


parser = argparse.ArgumentParser(description='Get mpi rules from oracle')
parser.add_argument('--oracleUser', required = True)
parser.add_argument('--oraclePassword', required = True)
parser.add_argument('--score', required = False, default = 90)
parser.add_argument('--outputPath', required = False, default = '')

arguments = parser.parse_args()

username = arguments.oracleUser
password = arguments.oraclePassword
connection = 'som-racload03.humedica.net:1521/engr'




connection = cx_Oracle.connect(username, password, connection)

cursor = connection.cursor()

sql = """
select distinct case when c.data_table_name is not null then upper(a.data_table_name || '_' || b.groupid) else upper(a.data_table_name) end,b.groupid,b.rule_fields, b.rule_nbr, b.score, b.uniq_fields from cdr_202011.mpi_data_table a

                        inner join cdr_202011.mpi_rule b on (a.data_table_name = b.rule_data_table)

                        left outer join cdr_202011.mpi_data_table_group c on (b.GROUPID = c.groupid AND b.RULE_DATA_TABLE = c.data_table_name)

                        where b.SCORE >= 90
"""

cursor.execute(sql)
x = []
res = cursor.fetchall()

active_score = arguments.score

config = {}

config['default'] = {'pat_match_rules': [{"etlName": "MPI_DOB", "ruleFieldNames": ["dob","adj_firstname","adj_lastname"],"uniqueFieldNames": [],"active": True,"rule_nbr": 22,"score": 100}]}


for row in res:
    etl_name = row[0]
    groupid = row[1]
    rule_fields = row[2].split(',')
    rule_nbr = row[3]
    score = row[4]
    uniq_fields = row[5]
    if uniq_fields == None:
        uniq_fields = []
    else:
        uniq_fields = uniq_fields.split(',')

    if groupid not in config.keys():
        config[groupid] = {'pat_match_rules':[]}

    active_cond = True if score >= active_score else False
    
    x = {"etlName": etl_name, "ruleFieldNames": rule_fields, "uniqueFieldNames": uniq_fields, "active": active_cond, "rule_nbr": rule_nbr, "score": score}
    config[groupid]['pat_match_rules'].append(x)


s = json.dumps(config)

with open(arguments.outputPath + 'client_config.json', 'w') as client_config:
    client_config.write(s)