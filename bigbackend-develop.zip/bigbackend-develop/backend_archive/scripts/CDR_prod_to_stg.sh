#! /bin/bash
#set -x

# Sample script to copy from production to stg environment
# ./CDR_prod_to_stg.sh --clientId H000166 --destInstance 2 --cdrLevel cdr_be --instance 2 --cdrCycle cdr_201908 --destCdrCycle cdr_mocs_dev

DRYRUN="N"
DESTINATION_INSTANCE=""

# Define a timestamp function
timestamp() {
  date "+%D %T"
}

# PARAM PARSING
POSITIONAL=()
while [[ $# -gt 0 ]]
do
key="$1"

case $key in
    --clientId)
    CLIENTID="$2"
    POSITIONAL+=("$1")
    POSITIONAL+=("$2")
    shift # past argument
    shift # past value
    ;;
    --destInstance)
    DESTINATION_INSTANCE="$2"
    POSITIONAL+=("$1")
    POSITIONAL+=("$2")
    shift # past argument
    shift # past value
    ;;
    --destCdrCycle)
    DESTINATION_CDRCYCLE="$2"
    POSITIONAL+=("$1")
    POSITIONAL+=("$2")
    shift # past argument
    shift # past value
    ;;
    --cdrLevel)
    CDRLEVEL="$2"
    POSITIONAL+=("$1")
    POSITIONAL+=("$2")
    shift # past argument
    shift # past value
    ;;
    --instance)
    INSTANCE="$2"
    POSITIONAL+=("$1")
    POSITIONAL+=("$2")
    shift # past argument
    shift # past value
    ;;
    --cdrCycle)
    CDRCYCLE="$2"
    POSITIONAL+=("$1")
    POSITIONAL+=("$2")
    shift # past argument
    shift # past value
    ;;
    --dryRun)
    DRYRUN="Y"
    POSITIONAL+=("$1")
    shift # past argument
    ;;
    *)    # unknown option
    echo " --- unknown parameter $1"
    exit 1
    ;;
esac
done
set -- "${POSITIONAL[@]}" # restore positional parameters

# PARAM VALIDATION
if [[ -z "$CLIENTID" ]]; then
    echo " --- Missing --clientId ?";
    exit 1;
fi
if [[ -z "$CDRLEVEL" ]]; then
    echo " --- Missing --cdrLevel ?";
    exit 1;
fi
if [[ -z "$CDRCYCLE" ]]; then
    echo " --- Missing --cdrCycle ?";
    exit 1;
fi
if [[ -z "$INSTANCE" ]]; then
    echo " --- Missing --instance ?";
    exit 1;
fi
if [[ -z "$DESTINATION_INSTANCE" ]]; then
    DESTINATION_INSTANCE=${INSTANCE}
fi
if [[ -z "$DESTINATION_CDRCYCLE" ]]; then
    DESTINATION_CDRCYCLE=${CDRCYCLE}
fi


TMPDIR="hdfs://somhorton1/tmp/cdr_transfer/$CLIENTID/$CDRLEVEL/$CDRCYCLE/$INSTANCE/default"
DESTINATION="hdfs://somhorton1/optum/data_factory/$CLIENTID/stg/$CDRLEVEL/$DESTINATION_CDRCYCLE/$DESTINATION_INSTANCE/default"
SOURCE="hdfs://somhorton1/optum/data_factory/$CLIENTID/prd/$CDRLEVEL/$CDRCYCLE/$INSTANCE/default"

echo " === $(timestamp) $CLIENTID/$CDRLEVEL/$CDRCYCLE/$INSTANCE CDR data copy from PRD to STG"
echo " SOURCE: $SOURCE"
echo " DESTINATION: $DESTINATION"

if [[ ${DRYRUN} != "Y" ]]; then
    echo " === $(timestamp) kinit svc_merc_cdr_prod"
    sudo -u svc_merc_cdr_prod kinit -ki
    echo " === $(timestamp) kinit svc_merc_cdr_stg"
    sudo -u svc_merc_cdr_stg kinit -ki
    echo " === $(timestamp) Preparing tmp dir: $TMPDIR"
    sudo -u svc_merc_cdr_prod hdfs dfs -rm -r -f -skipTrash ${TMPDIR}/*
    sudo -u svc_merc_cdr_prod hdfs dfs -mkdir -p ${TMPDIR}
    echo " === $(timestamp) Preparing destination: $DESTINATION"
    sudo -u svc_merc_cdr_stg hdfs dfs -rm -r -f -skipTrash ${DESTINATION}
    sudo -u svc_merc_cdr_stg hdfs dfs -mkdir -p ${DESTINATION}
    echo " === $(timestamp) cp $SOURCE/* $TMPDIR"
    sudo -u svc_merc_cdr_prod hdfs dfs -cp -f ${SOURCE}/* ${TMPDIR}
    echo " === $(timestamp) cp $TMPDIR/* $DESTINATION"
    sudo -u svc_merc_cdr_stg hdfs dfs -cp -f ${TMPDIR}/* ${DESTINATION}
    echo " === $(timestamp) cleanup"
    sudo -u svc_merc_cdr_prod hdfs dfs -rm -r -f -skipTrash ${TMPDIR}/*
else
    echo " +++ DRY-RUN!"
fi

echo " +++ $(timestamp) Done"