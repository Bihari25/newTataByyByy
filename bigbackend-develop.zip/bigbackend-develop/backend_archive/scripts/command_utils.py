import os
import pwd
import re
import signal
import subprocess
from subprocess import TimeoutExpired
from typing import Optional, List, Tuple

"""
This is util file from https://github.optum.com/DataFactoryEnablement/aws_orchestration_listener/blob/develop/aws_orchestration_listener/command_utils.py
Used in download_returns.py to run command line tools.
"""
MAX_LENGTH = 2000

CURRENT_USER = pwd.getpwuid(os.geteuid()).pw_name


def quote_string(input_str: str):
    return f"\"{input_str}\""


def create_command(command: str, parameters: List[str], user: Optional[str]):
    user_part = [] if user is None or user == CURRENT_USER else ['sudo', '-u', user]

    command = user_part + [command] + [str(x) for x in parameters if x is not None]
    return command


def run_kinit(user: str, logger):
    command = create_command("kinit", ["-ki"], user)

    code, stdout = run_command(command, logger)

    if code != 0:
        logger.warning(f"Could not run kinit for user {user}. Trying again.")
        code, stdout = run_command(command, logger)
        if code != 0:
            raise Exception(f"Could not run kinit for user {user}.")


def run_command(command: List[str], logger, env: Optional[dict] = None,
                timeout: Optional[int] = None) -> Tuple[int, str]:
    logger.info("event=START: Executing command: " + str(command))
    proc = subprocess.Popen(command, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, universal_newlines=True,
                            env=env, shell=False, preexec_fn=os.setsid)

    try:
        stdout, stderr = proc.communicate(str(command), timeout=timeout)
        return_code = proc.returncode
    except TimeoutExpired:
        # https://stackoverflow.com/questions/4789837/how-to-terminate-a-python-subprocess-launched-with-shell-true
        os.killpg(os.getpgid(proc.pid), signal.SIGTERM)
        stdout, stderr = proc.communicate()
        # should always be marked as a fail if we had to kill it
        return_code = 500

    if len(stdout) != 0:
        logger.info("Begin command logs\n-----\n" + stdout + "\n-----\nEnd command logs")

    return return_code, stdout


def launch_command(command: str, parameters: List[str], logger, user: Optional[str] = None,
                   raise_on_fail: bool = True) -> Tuple[int, str]:
    if user is not None:
        run_kinit(user, logger)

    command = create_command(command, parameters, user)
    code, stdout = run_command(command, logger)

    if raise_on_fail and code != 0:
        message = (stdout[:MAX_LENGTH - 3] + '...') if len(stdout) > MAX_LENGTH else stdout
        raise Exception(f"Got non-zero return code from {str(command)}. Log follows:\n{message}")

    return code, stdout


def launch_spark_submit(command: str, parameters: List[str], logger, user: Optional[str] = None, emr_host: Optional[str] = None) -> dict:

    code, stdout = launch_command(command, parameters, logger, user)

    application_id_regex = "Submitted application (?P<application_id>application_.*)"

    spark_match_obj = re.search(application_id_regex, stdout)
    if spark_match_obj:
        application_id = str(spark_match_obj.group('application_id'))
        logger.info("event=START: Successfully started application_id=" + application_id)
    else:
        raise Exception("Could not parse stdout to match regex " + application_id_regex)

    if emr_host is None:
        emr_host_regex = r"http://(?P<yarnHost>.*:\d*)"
        spark_match_obj = re.search(emr_host_regex, stdout)
        if spark_match_obj:
            emr_host = str(spark_match_obj.group('yarnHost'))
            logger.info("Setting EMR host to emr_host=" + emr_host)
        else:
            raise Exception("Could not parse stdout to match regex " + emr_host_regex)
    else:
        emr_host = emr_host

    output = dict(
        job_id=application_id,
        yarn_host=emr_host
    )

    return output

