#!/usr/bin/env bash

# deployment script should fail the build if any command returns non zero status
set -e
set -x
echo " === Deploying BigCDR Code"

helpPrompt ()
{
    echo "Description: Deploys the CDR code on the edge node."
    echo "Usage: ./code_deploy.sh --deploy-path {DEPLOY_EDGE_NODE_DIR} --deploy-user {DEPLOYMENT_USER}  --deploy-archive {DEPLOY_ARCHIVE} --spark-yarn-archive {SPARK_YARN_ARCHIVE} --clean-deploy-dir [true|false]"
}

POSITIONAL=()
while [[ $# -gt 0 ]]
do
    P1=$1
    shift
    case $P1 in
        --help|-h)
            helpPrompt
            exit 0
            ;;
        --clean-deploy-dir)
            CLEAN_DEPLOY_DIR=$1
            shift
            ;;
        --deploy-path)
            DEPLOY_PATH=$1
            shift
            ;;
        --deploy-user)
            DEPLOYMENT_USER=$1
            shift
            ;;
        --deploy-archive)
            DEPLOY_ARCHIVE=$1
            shift
            ;;
        --spark-yarn-archive)
            SPARK_YARN_ARCHIVE=$1
            shift
            ;;
        *)
            >&2 echo "Unexpected parameter: $P1"
            exit 1
            ;;
    esac
done

if [[ -z "${DEPLOY_PATH}" ]]; then
    >&2 echo "Required parameter --deploy-path not specified"
    exit 1
fi
if [[ -z "${DEPLOY_ARCHIVE}" ]]; then
    >&2 echo "Required parameter --deploy-archive not specified"
    exit 1
fi
if [[ -z "${DEPLOYMENT_USER}" ]]; then
    >&2 echo "Required parameter --deploy-user not specified"
    exit 1
fi
if [[ -z "${SPARK_YARN_ARCHIVE}" ]]; then
    >&2 echo "Required parameter --spark-yarn-archive not specified"
    exit 1
fi

set +e

echo "Processing copy to HDFS for environment user ${DEPLOYMENT_USER}"

if [[ "${CLEAN_DEPLOY_DIR}"  == "true" ]]; then
    if [[ -f "${DEPLOY_PATH}/orchestration.pid" ]]; then
        echo "Killing previous orchestration..."
        PREVIOUS_PROCESS=$(cat ${DEPLOY_PATH}/orchestration.pid)
        if [[ -z "${PREVIOUS_PROCESS}" ]]; then
            echo "No previous process information found!"
        else
            kill ${PREVIOUS_PROCESS}
        fi
    fi
    cd ${DEPLOY_PATH}
    zip required_files.zip conf/historical_jsons/* orchestration*.log* orchestration.pid code_deploy.sh activity_executors/activity_executor.pid
    find . -not \( -name '*.zip' \) -print0 | xargs -0 -I {} rm -rvf {}
    unzip -o required_files.zip
    rm required_files.zip

else
    #Clean all the files except the config files and the orchestration related files.
    cd ${DEPLOY_PATH}
    rm -f *.jar *.sh *.py
    rm -rf bpo_extracts
    rm -f conf/*.cfg
    rm -f conf/*.json
fi

cd ${DEPLOY_PATH}
unzip -o ${DEPLOY_ARCHIVE}
rm ${DEPLOY_ARCHIVE}
chmod 777 ${DEPLOY_PATH}/conf

SVC_CDR_USER_NAME="svc_merc_cdr_${DEPLOYMENT_USER}"
./copy_spark_yarn_archive.sh --env ${DEPLOYMENT_USER} --spark-yarn-archive ${SPARK_YARN_ARCHIVE}
sudo -u ${SVC_CDR_USER_NAME} ./bpo-acc/bin/copy_so_file_to_hdfs.sh --hdfsPath /user/${SVC_CDR_USER_NAME}/cdr_be/bpo-acc/lib_c

rm ${SPARK_YARN_ARCHIVE}
echo " === Deploying BigCDR Code, End code_deploy.sh "