#!/usr/bin/env bash

APP_LIB=$(dirname $(readlink -f $0))

ARCHIVE_VERSION=@@dfutils-version@@
java -Xmx2G -jar ${APP_LIB}/s3-downloader-${ARCHIVE_VERSION}.jar $@