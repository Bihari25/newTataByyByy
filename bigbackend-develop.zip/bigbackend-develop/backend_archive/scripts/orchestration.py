﻿import argparse
import json
import jsonschema
import logging
import os
import pyinotify
import re
import requests
import subprocess
import sys
import threading
import time

from collections import namedtuple
from logging.handlers import TimedRotatingFileHandler
from requests.adapters import HTTPAdapter
from requests.packages.urllib3.util.retry import Retry

SparkStatus = namedtuple("SparkStatus", ["is_good", "is_terminal"])

# Note: send sigint to kill loop

MAX_LENGTH = 2000

SPARK_STATUSES = {
    "ACCEPTED": SparkStatus(True, False),
    "RUNNING": SparkStatus(True, False),
    "KILLED": SparkStatus(False, True),
    "FAILED": SparkStatus(False, True),
    "SUCCEEDED": SparkStatus(True, True),
    "UNKNOWN": SparkStatus(False, False)
}

parser = argparse.ArgumentParser(description="Orchestration")
parser.add_argument("--watch_path")
parser.add_argument("--console", action="store_true")
parser.add_argument("--pid_file", default="orchestration.pid")
parser.add_argument("--log_path", default="")
orchestration_args, other_args = parser.parse_known_args()

run_parser = argparse.ArgumentParser(description="Orchestration", prefix_chars="+")
pattern = r"^\+(?P<var>[a-zA-Z\d\-_]*)(=|$)"

for other_arg in other_args:
    arg_match_obj = re.search(pattern, other_arg)
    if arg_match_obj:
        arg_name = str(arg_match_obj.group("var"))
        run_parser.add_argument(f"+{arg_name}")

run_args, ignore_args = run_parser.parse_known_args()

step_schema = {
    'type': 'object',
    'required': ['name'],
    'properties': {
        'name': {
            'type': 'string',
        },
        'script': {
            'type': 'string'
        },
        'active': {
            'type': ['string', 'boolean']
        },
        'yarnHost': {
            'type': 'string'
        },
        'user': {
            'type': 'string'
        },
        'parameters': {
            'type': 'array',
            "items": {
                'type': ['string', 'boolean', 'number', 'array']
            }
        }
    }
}

json_schema = {
    'type': 'object',
    'required': ['name', 'steps', 'notification'],
    'properties': {
        'name': {
            'type': 'string'
        },
        'variables': {
            'type': 'object',
            'additionalProperties': {
                'type': ['string', 'boolean', 'number', 'array']
            }
        },
        'steps': {
            'type': 'array',
            'items': step_schema
        },
        'failure_step': step_schema,
        'notification': {
            'type': 'object',
            'required': ['emails'],
            'properties': {
                'user': {
                    'type': 'string'
                },
                'emails': {
                    'type': 'string'
                }
            }
        }
    }
}


# key replacement for keys defined by ${}
def key_replace(variable, all_variables, logger, depth=0):
    # avoid neverending loops. max replacement depth of 10
    if depth > 10:
        logger.warning(f"reached depth of 10 during variable replacement, current string is {variable}, variables are {all_variables}")
        return variable

    replaced_string = variable
    if isinstance(replaced_string, str):
        for match_obj in re.finditer(r"\${(?P<key>[^${\}]*)}", variable):
            match = match_obj.group('key')
            to_replace = "${" + match + "}"
            if match in all_variables:
                replaced_string = replaced_string.replace(to_replace, str(all_variables[match]))
            else:
                logger.warning(f"{match} not in variables {', '.join(all_variables.keys())}")

    if replaced_string == variable:
        return replaced_string
    else:
        return key_replace(replaced_string, all_variables, logger, depth + 1)


def should_ignore_event(event):
    if event.dir or not event.pathname.endswith(".json"):
        return True

    return False


def create_command(command, parameters, user):
    user_part = [] if user is None else ['sudo', '-u', user]
    command = user_part + [command] + [str(x) for x in parameters]
    return command


def launch_command(command, logger, data_in=None) -> (str, str):
    logger.info("Executing command: " + str(command))
    proc = subprocess.Popen(command, stdout=subprocess.PIPE, stderr=subprocess.STDOUT, stdin=subprocess.PIPE, universal_newlines=True)

    if not data_in:
        stdout, stderr = proc.communicate()
    else:
        stdout, stderr = proc.communicate(input=data_in)
    if len(stdout) != 0:
        logger.info("Begin command logs\n-----\n" + stdout + "\n-----\nEnd command logs")

    if proc.returncode != 0:
        message = (stdout[:MAX_LENGTH - 3] + '...') if len(stdout) > MAX_LENGTH else stdout
        logger.error(f"Got non-zero return code from {str(command)}. Log follows:\n{message}")
        return False

    return stdout


def get_application_status(application_id, yarn_host, logger):
    if application_id == "UNKNOWN":
        return "UNKNOWN_APPLICATION_ID"

    logger.info("YARN Host: " + yarn_host)
    logger.info("Job ID: " + application_id)

    call_url = f"http://{yarn_host}:8088/ws/v1/cluster/apps/{application_id}"

    logger.info("Calling " + call_url)
    retries = Retry(total=5, backoff_factor=.5, status_forcelist=[500, 502, 503, 504])
    s = requests.session()
    s.mount('http://', HTTPAdapter(max_retries=retries))
    response = s.get(call_url, timeout=15)

    if response.status_code != 200:
        logger.error("Did not get a valid response from url " + call_url + ".\n" + str(response))
        return "UNKNOWN"

    status = response.json()['app']['state']

    if status == "FINISHED":
        status = response.json()['app']['finalStatus']

    return status


def wait_for_application_id(name, application_id, yarn_host, load_step, notification_info, logger) -> bool:
    keep_looping = True
    status = SPARK_STATUSES["UNKNOWN"]
    previous_status = "It will never be this."

    while keep_looping:
        status = get_application_status(application_id, yarn_host, logger)
        logger.info(f"Got status {status} for step {load_step} with app id {application_id}")
        if status != previous_status:
            send_email_for_status(name, status, yarn_host, application_id, load_step, notification_info, logger)
            previous_status = status

        keep_looping = not SPARK_STATUSES[status].is_terminal
        if keep_looping:
            time.sleep(300)  # sleep for 5 minutes

    return SPARK_STATUSES[status].is_good


def run_spark_command(name, script_name, parameters, user, step_name, yarn_host, notification_info, logger):
    command = create_command(f"./{script_name}.sh", parameters, user)
    ret_val = launch_command(command, logger)
    if not ret_val:
        return False
    else:
        stdout = str(ret_val)

    application_id_regex = "Submitted application (?P<application_id>application_.*)"

    spark_match_obj = re.search(application_id_regex, stdout)
    if spark_match_obj:
        application_id = str(spark_match_obj.group('application_id'))
        logger.info("Successfully started application id " + application_id)
        # sleep for 60 seconds. this gives the spark app time to fail out due to bad parameters if it is going to
        time.sleep(60)
    else:
        logger.error("Could not parse stdout to match regex " + application_id_regex + f" from {stdout}")
        return False

    return wait_for_application_id(name, application_id, yarn_host, step_name, notification_info, logger)


def run_kinit(user, logger):
    command = create_command("kinit", ["-ki"], user)
    return launch_command(command, logger)


def run_command(name, script_name, parameters, user, step_name, notification_info, logger):
    command = create_command(f"./{script_name}.sh", parameters, user)
    success = launch_command(command, logger)

    if success:
        send_email_for_status(name, "SUCCEEDED", None, None, step_name, notification_info, logger)
    else:
        send_email_for_status(name, "FAILED", None, None, step_name, notification_info, logger)

    return success


def send_email_for_status(name, status, yarn_host, application_id, step_name, notification_info, logger):
    if application_id:
        subject = f"{name}: Current status for {application_id} in step {step_name}: {status}"
    else:
        subject = f"{name}: Current status for step {step_name}: {status}"

    if status not in SPARK_STATUSES:
        message = f"Automation code does not recognize spark job status {status}.\n" \
                  f"This workflow will not continue.\n" \
                  f"Please check logs and update automation code to recognize spark job status {status}"
    else:
        spark_status = SPARK_STATUSES[status]
        if spark_status.is_good:
            if spark_status.is_terminal:
                message = f"{step_name} was successful. Will continue load."
            else:
                message = f"{step_name} is running."
        else:
            if spark_status.is_terminal:
                message = f"{step_name} failed. Workflow will not continue. Please check logs."
            else:
                message = f"{step_name} in an error state but still running. Please check logs."

    if yarn_host:
        send_email(subject, f"{message}\n\nYarn link: http://{yarn_host}:8088/cluster/app/{application_id}\n\n", notification_info, logger)
    else:
        send_email(subject, f"{message}\n\n", notification_info, logger)


def send_email(subject, message, notification_info, logger):

    user = None if 'user' not in notification_info else notification_info['user']
    notification_list = notification_info['emails']

    command = create_command("mail", ["-s", subject, notification_list], user)
    launch_command(command, logger, message)


def process_workflow(name, steps, variables, notification_info, logger, send_notification=True):
    previous_step = None
    for step in steps:
        step_name = key_replace(step['name'], variables, logger)
        if 'script' in step:
            script = key_replace(step['script'], variables, logger)
        else:
            script = name

        if 'active' in step:
            # this will work whether step['active'] is a boolean or a string
            active = key_replace(step['active'], variables, logger)

            # skip the step if active is a string and matches "false" or if not active
            if (isinstance(active, str) and active.lower() == "false") or not active:
                logger.warning(f"Skipping step {step_name} due to active=false")
                continue

        params = [] if "parameters" not in step else [key_replace(v, variables, logger) for v in step['parameters']]

        yarn_host = None if 'yarnHost' not in step else key_replace(step['yarnHost'], variables, logger)
        user = None if 'user' not in step else key_replace(step['user'], variables, logger)

        if send_notification:
            if previous_step:
                send_email(f"{name}: Continuing automated load with step {step_name}",
                           f"Finished step {previous_step}. Starting step {step_name}.\n\n",
                           notification_info,
                           logger)
            else:
                send_email(f"{name}: Starting load on step {step_name}",
                           f"Starting step {step_name}.\n\n",
                           notification_info,
                           logger)

        previous_step = step_name

        if user is not None:
            run_kinit(user, logger)

        if yarn_host:
            # is spark-submit, call yarn to get status
            success = run_spark_command(name, script, params, user, step_name, yarn_host, notification_info, logger)
        else:
            success = run_command(name, script, params, user, step_name, notification_info, logger)

        if not success:
            return False

    return True


def process_json(pathname, static_variables, logger):
    do_delete = True
    try:
        with open(pathname) as json_file:
            json_data = json.load(json_file)

        jsonschema.validate(json_data, json_schema)

        json_variables: dict = {} if 'variables' not in json_data else json_data['variables']
        run_variables = {**static_variables, **json_variables}
        # replace ${} in run variables
        for k in run_variables:
            result = key_replace(run_variables[k], run_variables, logger)
            run_variables[k] = result

        name = json_data['name']
        notification_info = json_data['notification']

        for k in notification_info:
            result = key_replace(notification_info[k], run_variables, logger)
            notification_info[k] = result

        steps = json_data['steps']

        failure_step: dict = {} if 'failure_step' not in json_data else json_data['failure_step']

        workflow_thread = WorkflowThread(pathname, json_data, name, steps, failure_step, run_variables, notification_info, logger)
        workflow_thread.setName(name)
        workflow_thread.start()
        do_delete = False
        # not joining back to the thread so that this thread can go back to processing files
    except jsonschema.ValidationError as e:
        logger.error(f"Invalid json from {pathname}" + str(e))
    except Exception as e:
        logger.error(f"Unable to process json from {pathname}" + str(e))
    finally:
        if do_delete:
            try:
                os.remove(pathname)
            except Exception as e:
                logger.error(f"Could not remove JSON file at {pathname}." + str(e))


ALTER_THREADMAP_LOCK = threading.Lock()
THREADMAP = {}


class WorkflowThread(threading.Thread):
    def __init__(self, pathname, json_data, name, steps, failure_step, run_variables, notification_info, logger):
        super().__init__()
        self.pathname = pathname
        self.json_data = json_data
        self.name = name
        self.steps = steps
        self.failure_step = failure_step
        self.run_variables = run_variables
        self.notification_info = notification_info
        self.logger = logger

    def run(self):
        ALTER_THREADMAP_LOCK.acquire()
        if self.name in THREADMAP:
            name_lock = THREADMAP[self.name]
        else:
            name_lock = threading.Lock()
            THREADMAP[self.name] = name_lock

        ALTER_THREADMAP_LOCK.release()

        self.logger.info(f"Waiting for threadlock for {self.name}")

        # if this is locked, there is another job running, notify that it has been queued
        # there may be a condition where 2 coming in at the same time see this as false,
        # but that should be rare enough to not worry about, the worst that will happen
        # is that a "queued" email won't go out
        if name_lock.locked():
            send_email(f"{self.name}: Automation job queued.",
                       f"--JSON config (from {self.pathname})--\n"
                       f"{json.dumps(self.json_data, indent=4)}\n\n",
                       self.notification_info,
                       self.logger)

        name_lock.acquire()
        send_email(f"{self.name}: Automation job started.",
                   f"--JSON config (from {self.pathname})--\n"
                   f"{json.dumps(self.json_data, indent=4)}\n\n",
                   self.notification_info,
                   self.logger)

        try:
            workflow_result = process_workflow(self.name, self.steps, self.run_variables, self.notification_info, self.logger)
        except Exception as e:
            workflow_result = False
            self.logger.error(f"Error running workflow {self.name}." + str(e))

        if workflow_result:
            send_email(f"{self.name} completed successfully", f"Automated load for {self.pathname} is complete.\n\n", self.notification_info, self.logger)
        else:
            if self.failure_step:
                send_email(f"{self.name} failed", f"Automated load for {self.pathname} failed. \nRunning failure_step {self.failure_step['name']}.\nPlease check logs.\n\n", self.notification_info, self.logger)
                failure_step_result = process_workflow(self.name, [self.failure_step], self.run_variables, self.notification_info, self.logger, send_notification=False)

                if failure_step_result:
                    send_email(f"{self.name} failed", f"Automated load for {self.pathname} failed but {self.failure_step['name']} succeeded. \nPlease check logs.\n\n", self.notification_info, self.logger)
                else:
                    send_email(f"{self.name} failed", f"Automated load for {self.pathname} failed and {self.failure_step['name']} also failed. \nPlease check logs.\n\n", self.notification_info, self.logger)
            else:
                send_email(f"{self.name} failed", f"Automated load for {self.pathname} failed. Please check logs.\n\n", self.notification_info, self.logger)

        try:
            os.remove(self.pathname)
        except Exception as e:
            self.logger.error(f"Could not remove JSON file at {self.pathname}." + str(e))
        name_lock.release()


class EventHandler(pyinotify.ProcessEvent):

    def __init__(self, logger, static_variables: dict):
        super().__init__()
        self.logger = logger
        self.static_variables: dict = static_variables

    def __process_json_file(self, pathname):
        time.sleep(1)  # sleep 1 second for content to arrive
        process_json(pathname, self.static_variables, self.logger)

    def process_IN_CREATE(self, event):
        if should_ignore_event(event):
            return
        self.__process_json_file(event.pathname)

    def process_IN_MOVED_TO(self, event):
        if should_ignore_event(event):
            return
        self.__process_json_file(event.pathname)


def main():
    logger = logging.getLogger(__name__)
    logger.setLevel(logging.INFO)

    formatter = logging.Formatter('%(asctime)s - %(threadName)s - %(levelname)s - %(message)s')

    orchestration_log_path = orchestration_args.log_path.rstrip("/")
    if orchestration_log_path:
        orchestration_log_path = orchestration_log_path + "/" + "orchestration.log"
    else:
        orchestration_log_path = "orchestration.log"

    if not orchestration_args.console:
        handler = TimedRotatingFileHandler(orchestration_log_path, when="midnight", backupCount=7, delay=True)
    else:
        handler = logging.StreamHandler(stream=sys.stdout)

    handler.setFormatter(formatter)
    logger.addHandler(handler)

    variables = run_args.__dict__

    logger.info(f"Started with variables [{', '.join(variables.keys())}]")

    os.chmod(orchestration_log_path, 0o777)

    # replace ${} in passed variables
    for k, v in variables.items():
        result = key_replace(v, variables, logger)
        variables[k] = result

    watch_path = orchestration_args.watch_path
    logger.info(f"Setting up watch on path: {watch_path}")

    eh = EventHandler(logger, variables)

    try:
        os.makedirs(watch_path, exist_ok=True)
        os.chmod(watch_path, 0o777)
    except Exception as e:
        logger.error("Could not create watch_dir" + str(e))
        raise e

    wm = pyinotify.WatchManager()
    wm.add_watch(watch_path, pyinotify.IN_CREATE | pyinotify.IN_MOVED_TO)

    notifier = pyinotify.Notifier(wm, eh)

    try:
        notifier.loop()
    except KeyboardInterrupt:
        logger.warning("Stopped via keyboard")
        notifier.stop()

    logger.info("Exiting")


if __name__ == '__main__':
    orchestration_pid_file = orchestration_args.pid_file
    pid = None
    try:
        with open(orchestration_pid_file) as pid_file:
            if os.stat(orchestration_pid_file).st_size > 0:
                pid = int(pid_file.readline())
    except IOError:
        pid = None

    if pid is not None:
        try:
            os.kill(pid, 0)
            raise Exception(f"Found running process {pid} from {orchestration_pid_file}. "
                            f"Please kill that process to procede.")
        except OSError:
            pass

    with open(orchestration_pid_file, "w") as pid_file:
        pid_file.write(str(os.getpid()))

    main()
    try:
        os.remove(orchestration_pid_file)
    except:
        pass
