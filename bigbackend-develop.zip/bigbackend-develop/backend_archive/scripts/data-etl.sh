#!/usr/bin/env bash

###########################################
# Command : ./data-etl.sh --jsonConfigPath hdfs://somhorton1/user/mfountain/matt_dm_1.json
###########################################

SCRIPT_ROOT=$( dirname "${BASH_SOURCE[0]}" )
DEFAULT_SPARK_HOME="@@default-spark-home@@"
DEFAULT_SPARK_EXECUTOR_MEMORY=24g
DEFAULT_SPARK_EXECUTOR_MEMORY_OVERHEAD=6g
DEFAULT_SPARK_EXECUTOR_CORES=8
DEFAULT_SPARK_EXECUTOR_COUNT=10
DEFAULT_DRIVER_CORES=8
DEFAULT_SPARK_YARN_ARCHIVE="@@spark-yarn-archive-path@@"

ORACLE_EXPORT_SPARK_EXECUTOR_MEMORY=8g
ORACLE_EXPORT_SPARK_EXECUTOR_MEMORY_OVERHEAD=3g
ORACLE_EXPORT_SPARK_EXECUTOR_COUNT=5

source /etc/profile.d/hdp_version.sh

ARCHIVE_NAME=data-etl
ARCHIVE_VERSION=@@dfutils-version@@
APP_JAR="${ARCHIVE_NAME}-${ARCHIVE_VERSION}-jar-with-dependencies.jar"

MAIN_CLASS="com.optum.oap.dataetl.Main"
DO_WAIT="false"

## SPARK_YARN_ARCHIVE
if [[ -z "$SPARK_YARN_ARCHIVE" ]]; then
  SPARK_YARN_ARCHIVE=$DEFAULT_SPARK_YARN_ARCHIVE
fi

## SPARK_HOME
if [[ -z "$SPARK_HOME" ]]
then
    if [[ -d "$DEFAULT_SPARK_HOME" ]]
    then
        SPARK_HOME=$DEFAULT_SPARK_HOME
    else
        echo "SPARK_HOME not set and $DEFAULT_SPARK_HOME does not exist."
        exit 1
    fi
fi

## SPARK_MASTER
if [[ -z "$SPARK_MASTER" ]]
then
    SPARK_MASTER=yarn
fi

## SPARK_EXECUTOR_MEMORY
if [[ -z "$SPARK_EXECUTOR_MEMORY" ]]
then
    SPARK_EXECUTOR_MEMORY=$DEFAULT_SPARK_EXECUTOR_MEMORY
fi

## SPARK_EXECUTOR_CORES
if [[ -z "$SPARK_EXECUTOR_CORES" ]]
then
    SPARK_EXECUTOR_CORES=$DEFAULT_SPARK_EXECUTOR_CORES
fi

## SPARK_EXECUTOR_COUNT
if [[ -z "$SPARK_EXECUTOR_COUNT" ]]
then
    SPARK_EXECUTOR_COUNT=$DEFAULT_SPARK_EXECUTOR_COUNT
fi

# read script arguments
POSITIONAL=()
while [[ $# -gt 0 ]]
do
    P1=$1
    case $P1 in
        --exportToOracle)
            SPARK_EXECUTOR_MEMORY=$ORACLE_EXPORT_SPARK_EXECUTOR_MEMORY
            DEFAULT_SPARK_EXECUTOR_MEMORY_OVERHEAD=$ORACLE_EXPORT_SPARK_EXECUTOR_MEMORY_OVERHEAD
            SPARK_EXECUTOR_COUNT=$ORACLE_EXPORT_SPARK_EXECUTOR_COUNT
            shift # past argument
            ;;
        *)    # unknown option
            POSITIONAL+=("$1")
            shift
        ;;
    esac
done
set -- "${POSITIONAL[@]}" # restore positional parameters

## SPARK_DEPLOY_MODE
if [[ -z "$SPARK_DEPLOY_MODE" ]]
then
    SPARK_DEPLOY_MODE=cluster
fi

## Find the app jar using a search path
SEARCH_ORDER=(
    .
    ./build/libs
    $SCRIPT_ROOT/../lib
    $SCRIPT_ROOT)
APP_LIB=""
for X in ${SEARCH_ORDER[@]}
do
    if [[ -f "$X/${APP_JAR}" ]]
    then
        APP_LIB=$X
        break
    fi
done
if [[ -z "$APP_LIB" ]]
then
    echo "Could not find the application jar in one of the search directories ${SEARCH_ORDER[@]}"
    exit 1
fi

#POSITIONAL=()
#while [[ $# -gt 0 ]]
#do
#key="$1"
#
#case $key in
#    --clientId)
#    CLIENT="$2"
#    POSITIONAL+=("$1")
#    POSITIONAL+=("$2")
#    shift # past argument
#    shift # past value
#    ;;
#    --environment)
#    ENVIRONMENT="$2"
#    POSITIONAL+=("$1")
#    POSITIONAL+=("$2")
#    shift # past argument
#    shift # past value
#    ;;
#    *)    # unknown option
#    POSITIONAL+=("$1") # save it in an array for later
#    shift # past argument
#    ;;
#esac
#done
#set -- "${POSITIONAL[@]}" # restore positional parameters

APPNAME="data-etl"

echo "APPNAME=$APPNAME"
echo "SPARK_HOME=$SPARK_HOME"
echo "SPARK_MASTER=$SPARK_MASTER"
echo "SPARK_DEPLOY_MODE=$SPARK_DEPLOY_MODE"
echo "MAIN_CLASS=$MAIN_CLASS"
echo "SPARK_EXECUTOR_MEMORY=$SPARK_EXECUTOR_MEMORY"
echo "SPARK_EXECUTOR_CORES=$SPARK_EXECUTOR_CORES"
echo "SPARK_EXECUTOR_COUNT=$SPARK_EXECUTOR_COUNT"
echo "SPARK_EXECUTOR_MEMORY_OVERHEAD=$DEFAULT_SPARK_EXECUTOR_MEMORY_OVERHEAD"
echo "SPARK_YARN_ARCHIVE=$SPARK_YARN_ARCHIVE"
echo "APP_LIB=$APP_LIB"
echo "APP_JAR=$APP_JAR"
echo "arguments=$@"

cmd='$SPARK_HOME/bin/spark-submit
  --class $MAIN_CLASS
  --name "$APPNAME"
  --master $SPARK_MASTER
  --deploy-mode $SPARK_DEPLOY_MODE

  --files /etc/spark2/conf/hive-site.xml

  --conf "spark.driver.maxResultSize=8g"
  --conf "spark.executor.memoryOverhead=$DEFAULT_SPARK_EXECUTOR_MEMORY_OVERHEAD"
  --num-executors $SPARK_EXECUTOR_COUNT
  --executor-memory $SPARK_EXECUTOR_MEMORY
  --executor-cores $SPARK_EXECUTOR_CORES
  --driver-memory $SPARK_EXECUTOR_MEMORY
  --driver-cores $DEFAULT_DRIVER_CORES

  --conf "spark.yarn.submit.waitAppCompletion=${DO_WAIT}"
  --conf "spark.yarn.maxAppAttempts=1"
  --conf "spark.home=${SPARK_HOME}"
  --conf "spark.io.compression.codec=snappy"
  --conf spark.sql.parquet.compression.codec=gzip
  --conf "spark.kryo.unsafe=true"
  --conf "spark.kryoserializer.buffer.max=1024m"
  --conf "spark.sql.parquet.writeLegacyFormat=true"
  --conf "spark.serializer=org.apache.spark.serializer.KryoSerializer"
  --conf "spark.hadoop.mapreduce.fileoutputcommitter.algorithm.version=2"
  --conf "spark.yarn.archive=$SPARK_YARN_ARCHIVE"
  ${APP_LIB}/${APP_JAR} $@'

eval $cmd
