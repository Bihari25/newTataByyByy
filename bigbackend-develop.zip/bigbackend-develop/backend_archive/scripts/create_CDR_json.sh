#!/usr/bin/env bash

user=`whoami`
hostname=`uname -n`
if [[ "${hostname}" == "som-horton-p1-e1.humedica.net" ]];
then
    python36=/opt/rh/rh-python36/root/bin/python
    venvDirectory="/tmp/${user}/create_cdr_json"
    fp=$(readlink -f $0)
    bp=$(dirname $fp)
    scripts_path=${bp}
    prog=$(basename ${fp} )
else
    DIR="${0%/*}"
    fp=`cd "$DIR" && echo "$(pwd -P)"`
    bp=$(dirname $fp)
    prog=$(basename ${fp})
    python36=python3
    venvDirectory="/tmp/create_cdr_json"
    bp="/tmp/create_cdr_json"
    scripts_path="../../backend_util/src/main/"
fi

watch_path="${bp}/orchestration_watch_path/"
export var_log_path=${bp#*"orchestration"}

source ${scripts_path}/conf/configure_json.cfg

if [[ -d "${venvDirectory}" ]]; then
    rm -rf ${venvDirectory}
fi

$python36 -m venv ${venvDirectory}

. ${venvDirectory}/bin/activate

# This is for backward command compatibility as the new create_CDR_json.sh uses the -r parameter to specify run steps
POSITIONAL=()
while [[ $# -gt 0 ]]
do
    key="$1"
    case ${key} in
        -w | --workflow_steps)
        steps="$2"
        POSITIONAL+=("-r")
        POSITIONAL+=("${steps}")
        shift # past argument
        shift # past value
        ;;
        *)
        POSITIONAL+=("${key}") # save it in an array for later
        shift # past argument
    esac
done

set -- "${POSITIONAL[@]}" # restore positional parameters

pip install --index-url=https://repo1.uhc.com/artifactory/api/pypi/pypi-simple/simple requests

${venvDirectory}/bin/python create_CDR_json.py "$@"

