#!/usr/bin/env bash

pkill -f ecdr_cleanup.py

python36=/opt/rh/rh-python36/root/bin/python

LOG_DIR=/opt/bigoadw/pmishra/ecdrCleanup

currentDate="`date "+%Y-%m-%d %H:%M:%S"`"

#log files
logfile=$LOG_DIR/ecdr_cleanup.log
if [[ ! -e $logfile ]]; then
    touch $logfile
    chmod 777 $logfile
fi
echo "Running ecdr_cleanup: $currentDate" >> $logfile

#remove any existing venv
rm -rf ecdr_cleanup

$python36 -m venv ecdr_cleanup

. ./ecdr_cleanup/bin/activate
./ecdr_cleanup/bin/pip3 install python-dateutil

pip install --index-url=https://repo1.uhc.com/artifactory/api/pypi/pypi-simple/simple python-dateutil

./ecdr_cleanup/bin/python ecdr_cleanup.py --logFilePath $logfile "$@"

rm -rf ecdr_cleanup