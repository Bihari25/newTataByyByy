# CDR bigbackend 
There are different modules in CDR bigbackend project, will try to describe the available modules and purpose of them.
Please refer to the script heading on how to invoke the script.
 
# backend_archive
This module create the zip backend_archive*.zip file by copying the required shell, python scripts and the all the module specific jar's.
This module has different shell scripts to run the project.
* CDR_prod_to_stg.sh 
   * Sometimes we will need to copy the prod data to stage for some comparision/testing. This script will help to copy data from prod to stage.
* code_deploy.sh
   * This script deploys the CDR code on the edge node.
* copy_spark_yarn_archive
   * Copies yarn-spark-archive-<env>-bin.zip to hdfs:///user/svc_merc_cdr_<env>/CDR-lib/yarn-spark-archive-<env>-bin.zip
* data-etl.sh
   * This script makes a call to data-etl main class in https://github.optum.com/OptumAnalyticsPlatform/dfutils/blob/develop/data-etl/src/main/scala/com/optum/oap/dataetl/Main.scala
   This is used in bpo_extracts module that sends the json file with the required parameters to generate the csv and compress it in gz format.
* data-importer.sh
   * The script will import the oracle data to hdfs to the given cdr be instance location.
* orchestration-deploy.sh
   * This script is used for deploying the orchestration to edge node and starts the process and logs the processid in orchestration.pid.
   For more information on how to start/restart the orchestration refer to 
   https://wiki.advisory.com/pages/viewpage.action?pageId=208770949#CDRBECI/CDPipeline-RestartingtheOrchestrationProcess 

# acc_returns
For information related to this module please refer to the README.md file in the module.

# backend_enrichments
This module has all the ETL's that like Patient Summary in summary folder, Encounter groups in encgrps, all bpo enrichments are in bpo folder,enrichment folder has the ETL's like Allergy, 
Claim etc.. We can either run all the enrichments or can only run individual enrichments by passing the parameter.
For Running BPO ETL'S
```$xslt
sudo -u svc_merc_cdr_stg ./cdr_be_enrichment.sh --cdrSchema H303173_stg_cdr_be_cdr_201906 --clientId H303173 --environment stg --cdrCycle CDR_MOCS_DEV2 --cdrLevel cdr_be --instance 2 --loadGroups bpo
```
For running all ETL's of Summary, Encounter groups, BPO
```$xslt
sudo -u svc_merc_cdr_stg ./cdr_be_enrichment.sh --cdrSchema H303173_stg_cdr_be_cdr_201906 --clientId H303173 --environment stg --cdrCycle CDR_MOCS_DEV2 --cdrLevel cdr_be --instance 2 --loadGroups all
```

# bpo_extract
Once the BPO ETL's are run we will extract these using spark sql and generate the csv files with compressed gz format and send them to ACC, II engines for processing.
This module has the all the extract sql's in their corresponding folders. EBM, HEDIS, SRE are sent to ACC and ii, ii_7_0, ii_xwlk.
* cdr_be_bpo_extract_config.cfg file has all the configuration related to each client, which will specify 
what client configured to run what extracts. Based on this configuration the extracts are generated for each client.
For eg. H303173 is configured for EBM, SRE, HEDIS and II_XWLK.
   ```$xslt
   Any client configuration changes related to what client can have what stream of extract goes to cdr_be_bpo_extract.cfg file
   ```
* The acc and ii configurations are in conf folder for each environment.
* bpo_extracts.py has all the logic and generates the bpo extracts, refer to https://wiki.advisory.com/display/OACA/CDR+BackEnd+-+ACC+Returns for details on how to invoke this script.
* send_files.sh generates the control file and gets the configuration details from the env specific configuration file and sends the files to ACC, II engines through sftp.

* sql folder has the oracle sql that tracks the bpo extracts sent in job_control.outbound_file_trackerv2 table.
```$xslt
The extracts that are successfully sent will be present in /misc/phiops/archive/{GROUPID}/out_cdr/ folder
```

# bigbackend_importer
This module is for importing data from oracle to hdfs in a given instance and cdr cycle location.
eg data-importer call
```$xslt
sudo -u svc_merc_cdr_stg ./cdr-importer.sh --oracleUser hadoop_ecdr --oraclePwdFile /user/svc_merc_cdr_stg/conf/oracle_import_users.pw --jdbcHost som-racload03.humedica.net --importType cdr_be --clientId H303173 --environment stg --level cdr_be --schema cdr_201906 --instance 2 --cdrCycle cdr_201906 --host somhorton1 
```

# cdr-deploy
This module is for hive deploy for for a given instance and cdr cycle.
eg script
```$xslt
sudo -u svc_merc_cdr_dev ./deploy-cdr.sh --clientId H303173 --schema cdr_201909 --host somhorton1 --environment stg --level cdr_be --instance 11 --instancedDbName h303173_stg_cdr_be_cdr_201909_11 --schemaType cdr_be 
```

# bpo_acc
Please refer to the readme.md file in the bpo_acc module.

# backend_util
@Ian or @Alpesh can update this section.

# ecdr
@Ian or @Alpesh can update this section.

# oracle_export
For information related to this module please refer to the README.md file in the module.
