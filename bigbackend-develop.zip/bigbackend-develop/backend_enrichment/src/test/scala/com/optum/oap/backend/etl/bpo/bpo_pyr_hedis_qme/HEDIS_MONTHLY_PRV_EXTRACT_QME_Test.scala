package com.optum.oap.backend.etl.bpo.bpo_pyr_hedis_qme

import com.optum.oap.backend.BEQueryTestFramework
import com.optum.oap.backend.cdrTempModel.hedis_monthly_prv_extract_qme
import com.optum.oap.cdr.models.{pp_bpo_provider_detail}
import org.apache.spark.sql.DataFrame

class HEDIS_MONTHLY_PRV_EXTRACT_QME_Test extends BEQueryTestFramework{

  import spark.implicits._


  val ppBpoProviderDetail: DataFrame = mkDataFrame(
    pp_bpo_provider_detail(groupid = "H000000", providerid = "prov 1", specialty = "specialty 1", npi = "1234"),
    pp_bpo_provider_detail(groupid = "H000000", providerid = "prov 2", specialty = "specialty 1", npi = "1234"),
    pp_bpo_provider_detail(groupid = "H000000", providerid = "prov 3", specialty = "831", npi = "3245"),
    pp_bpo_provider_detail(groupid = "H000000", providerid = "prov 4", specialty = "871", npi = "4567"),
    pp_bpo_provider_detail(groupid = "H000000", providerid = "prov 5", specialty = "833", npi = "5678")
  )

  val expectedOutput: Seq[hedis_monthly_prv_extract_qme] = Seq(
    hedis_monthly_prv_extract_qme(ProviderID = "prov 1", NationalProviderIdentifier = "1234", SpecialtyCode = "specialty 1"),
    hedis_monthly_prv_extract_qme(ProviderID = "prov 2", NationalProviderIdentifier = "1234", SpecialtyCode = "specialty 1"),
    hedis_monthly_prv_extract_qme(ProviderID = "prov 3", NationalProviderIdentifier = "3245", SpecialtyCode = "831", ThirdSpecialtyCode = "H10", FourthSpecialtyCode = "H01"),
    hedis_monthly_prv_extract_qme(ProviderID = "prov 4", NationalProviderIdentifier = "4567", SpecialtyCode = "871", ThirdSpecialtyCode = "H10"),
    hedis_monthly_prv_extract_qme(ProviderID = "prov 5", NationalProviderIdentifier = "5678", SpecialtyCode = "833", ThirdSpecialtyCode = "H10",  FourthSpecialtyCode = "H02")
  )



  testQuery(
    testName = "test HEDIS_MONTHLY_PRV_EXTRACT_QME",
    query = HEDIS_MONTHLY_PRV_EXTRACT_QME,
    inputs = Map(
      "PP_BPO_PROVIDER_DETAIL" -> ppBpoProviderDetail
    ),
    expectedOutput = expectedOutput
  )

}