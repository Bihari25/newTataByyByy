package com.optum.oap.backend.etl.common

import com.optum.oap.backend.BEQueryTestFramework
import com.optum.oap.backend.etl.common.ExtractUomRaw.extract_uom_raw
import org.apache.spark.sql.functions.lit
import org.junit.runner.RunWith
import org.scalatest.Matchers._
import org.scalatest.junit.JUnitRunner

@RunWith(classOf[JUnitRunner])
class ExtractUomRawTest extends BEQueryTestFramework{

  behavior of "extract_uom udf"

  it should "extract uom from given string" in {

    val actualOutcome = Seq(

      extract_uom_raw(lit("  testiU per LTesTIU per Cc  ")).expr.eval().toString
      , extract_uom_raw(lit("  testiU pEr LTesTIU pEr Cc  ")).expr.eval().toString
      , extract_uom_raw(lit(" test_no_regex_matches ")).expr.eval()

    )

    val expectedOutcome = Seq(

      "iu per l"
      , "iu/l"
      ,  null

    )

    actualOutcome shouldBe expectedOutcome
  }
}