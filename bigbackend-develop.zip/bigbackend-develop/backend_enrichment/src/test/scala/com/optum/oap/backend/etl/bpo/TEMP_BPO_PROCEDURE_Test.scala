package com.optum.oap.backend.etl.bpo

import java.sql.{Date, Timestamp}

import com.optum.oap.backend.BEQueryTestFramework
import com.optum.oap.backend.cdrTempModel.{temp_bpo_calculate_params, temp_bpo_patients, temp_bpo_procedure}
import com.optum.oap.cdr.models.{map_predicate_values, proceduredo, _}
import org.apache.spark.sql.DataFrame
import org.joda.time.{DateTime, DateTimeUtils}

/**
  *
  * Copyright 2019 Optum Analytics
  *
  * Date: 6/3/19
  *
  * Creator: bpokharel(bishu)
  */
class TEMP_BPO_PROCEDURE_Test extends BEQueryTestFramework {

  import spark.implicits._

  val proceduero_IN: DataFrame = mkDataFrame(
    proceduredo(groupid = "H000000", grp_mpi = "101", client_ds_id = 1, sourceid = "s1", encounterid = "1", codetype = "ICD10", mappedcode = "m1", performing_mstrprovid = "1", proceduredate = Timestamp.valueOf("2016-07-05 09:57:00"), procseq = 1),
    proceduredo(groupid = "H000000", grp_mpi = "101", client_ds_id = 1, sourceid = "s1", encounterid = "1", codetype = "ICD10", mappedcode = "m2", performing_mstrprovid = "1", proceduredate = Timestamp.valueOf("2016-07-05 10:57:00"), procseq = 1),
    proceduredo(groupid = "H000000", grp_mpi = "102", client_ds_id = 1, sourceid = "s2", encounterid = "2", codetype = "ICD10", mappedcode = "m2", performing_mstrprovid = "1", proceduredate = Timestamp.valueOf("2016-07-08 09:57:00"), procseq = 1),
    proceduredo(groupid = "H000000", grp_mpi = "102", client_ds_id = 1, sourceid = "s2", encounterid = "3", codetype = "ICD10", mappedcode = "m3", performing_mstrprovid = "1", proceduredate = Timestamp.valueOf("2016-07-09 10:57:00"), procseq = 1)
  )

  val temp_bpo_patients_IN: DataFrame = mkDataFrame(
    temp_bpo_patients(groupid = "H000000", grp_mpi = "101", payer = 1),
    temp_bpo_patients(groupid = "H000000", grp_mpi = "101", payer = 2),
    temp_bpo_patients(groupid = "H000000", grp_mpi = "102", payer = 1)
  )

  val clinicalencounter_IN: DataFrame = mkDataFrame(
    clinicalencounter(groupid = "H000000", client_ds_id = 1, grp_mpi = "101", encounterid = "1", arrivaltime = Timestamp.valueOf("2016-07-06 07:57:00")),
    clinicalencounter(groupid = "H000000", client_ds_id = 1, grp_mpi = "101", encounterid = "1", arrivaltime = Timestamp.valueOf("2016-07-07 07:57:00")),
    clinicalencounter(groupid = "H000000", client_ds_id = 1, grp_mpi = "102", encounterid = "2", arrivaltime = Timestamp.valueOf("2016-07-08 07:57:00")),
    clinicalencounter(groupid = "H000000", client_ds_id = 1, grp_mpi = "102", encounterid = "3", arrivaltime = Timestamp.valueOf("2016-07-09 07:57:00"))
  )

  val map_patient_type_IN: DataFrame = mkDataFrame(
    map_patient_type(groupid = "H000000", dts_version = 1)
  )

  val map_discharge_disposition_IN: DataFrame = mkDataFrame(
    map_discharge_disposition(groupid = "H000000", cui = "CH000090", dts_version = 1)
  )

  val map_drg_type_IN: DataFrame = mkDataFrame(
    map_drg_type(groupid = "H000000")
  )

  val map_predicate_values_IN: DataFrame = mkDataFrame(
    map_predicate_values(groupid = "H000000", client_ds_id = 1, entity = "PP_BPO_MEDICAL_CLAIMS", column_name = "PX_DX", data_src = "OADW")
  )

  val temp_bpo_calculate_params_IN: DataFrame = mkDataFrame(
    temp_bpo_calculate_params(engineStartDate = Date.valueOf("2015-04-01"), engineStartDate2 = Date.valueOf("2015-04-01"), engineStartDate3 = Date.valueOf("2015-04-01"), engineEndDate = Date.valueOf("2019-03-31"), startDate = Date.valueOf("2015-01-01"))
  )

  DateTimeUtils.setCurrentMillisFixed(10000)

  val temp_bpo_procedure_OUT: Seq[temp_bpo_procedure] = Seq(
    temp_bpo_procedure(groupid = "H000000", grp_mpi = "101", encounterid = "1", client_ds_id = 1, codetype = "ICD10", servicedate = Timestamp.valueOf("2016-07-05 00:00:00"), performing_mstrprovid = "1", quantity = 1, icdproc1 = "m1", icdproc2 = "m2", sourceid = "s1", db_create_dt_tm = new Timestamp(DateTime.now().getMillis)),
    temp_bpo_procedure(groupid = "H000000", grp_mpi = "102", encounterid = "2", client_ds_id = 1, codetype = "ICD10", servicedate = Timestamp.valueOf("2016-07-08 00:00:00"), performing_mstrprovid = "1", quantity = 1, icdproc1 = "m2", sourceid = "s2", db_create_dt_tm = new Timestamp(DateTime.now().getMillis)),
    temp_bpo_procedure(groupid = "H000000", grp_mpi = "102", encounterid = "3", client_ds_id = 1, codetype = "ICD10", servicedate = Timestamp.valueOf("2016-07-09 00:00:00"), performing_mstrprovid = "1", quantity = 1, icdproc1 = "m3", sourceid = "s2", db_create_dt_tm = new Timestamp(DateTime.now().getMillis))

  )
  testQuery(
    testName = "test TEMP_BPO_PROCEDURE",
    query = TEMP_BPO_PROCEDURE,
    inputs = Map(
      "PROCEDUREDO" -> proceduero_IN,
      "TEMP_BPO_PATIENTS" -> temp_bpo_patients_IN,
      "CLINICALENCOUNTER" -> clinicalencounter_IN,
      "MAP_PATIENT_TYPE" -> map_patient_type_IN,
      "MAP_DISCHARGE_DISPOSITION" -> map_discharge_disposition_IN,
      "MAP_DRG_TYPE" -> map_drg_type_IN,
      "MAP_PREDICATE_VALUES" -> map_predicate_values_IN,
      "TEMP_BPO_CALCULATE_PARAMS" -> temp_bpo_calculate_params_IN
    ),
    expectedOutput = temp_bpo_procedure_OUT
  )
}

