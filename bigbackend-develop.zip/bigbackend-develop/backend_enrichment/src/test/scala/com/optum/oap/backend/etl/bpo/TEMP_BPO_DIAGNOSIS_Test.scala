package com.optum.oap.backend.etl.bpo

import java.sql.{Date, Timestamp}

import com.optum.oap.backend.BEQueryTestFramework
import com.optum.oap.backend.cdrTempModel.{temp_bpo_calculate_params, temp_bpo_diagnosis, temp_bpo_patients}
import com.optum.oap.cdr.models.{diagnosis, map_predicate_values, _}
import org.apache.spark.sql.DataFrame
import org.joda.time.{DateTime, DateTimeUtils}

/**
  *
  * Copyright 2019 Optum Analytics
  *
  * Date: 6/3/19
  *
  * Creator: bpokharel(bishu)
  */
class TEMP_BPO_DIAGNOSIS_Test extends BEQueryTestFramework {

  import spark.implicits._

  val diagnosis_IN: DataFrame = mkDataFrame(
    diagnosis(groupid = "H000000", grp_mpi = "101",  client_ds_id = 1, encounterid = "1", localpresentonadmission = "code1", codetype = "ICD10", mappeddiagnosis = "d1", sourceid = "s1", dx_timestamp = Timestamp.valueOf("2018-07-06 07:57:00"), primarydiagnosis = 1),
    diagnosis(groupid = "H000000", grp_mpi = "101",  client_ds_id = 1, encounterid = "1", localpresentonadmission = "code1", codetype = "ICD10", mappeddiagnosis = "d1", sourceid = "s1", dx_timestamp = Timestamp.valueOf("2018-07-07 07:57:00"), primarydiagnosis = 1),
    diagnosis(groupid = "H000000", grp_mpi = "102",  client_ds_id = 1, encounterid = "1", localpresentonadmission = "code1", codetype = "ICD10", mappeddiagnosis = "d1", sourceid = "s2", dx_timestamp = Timestamp.valueOf("2018-07-07 06:57:00"), primarydiagnosis = 1),
    diagnosis(groupid = "H000000", grp_mpi = "103", seq=200,client_ds_id = 1, encounterid = "3", localpresentonadmission = "code1", codetype = "ICD10", mappeddiagnosis = "d3", sourceid = "s3", dx_timestamp = Timestamp.valueOf("2018-07-08 07:57:00"), primarydiagnosis = 1),
    diagnosis(groupid = "H000000", grp_mpi = "103", client_ds_id = 1, encounterid = "3", localpresentonadmission = "code1", codetype = "ICD10", mappeddiagnosis = "d4", sourceid = "s3", dx_timestamp = Timestamp.valueOf("2018-07-09 08:57:00"), primarydiagnosis = 1),
    diagnosis(groupid = "H000000", grp_mpi = "103", client_ds_id = 1, encounterid = "4", localpresentonadmission = "code1", codetype = "ICD10", mappeddiagnosis = "d5", sourceid = "s3", dx_timestamp = Timestamp.valueOf("2018-07-10 09:57:00"), primarydiagnosis = 2)
  )

  val temp_bpo_patients_IN: DataFrame = mkDataFrame(
    temp_bpo_patients(groupid = "H000000", grp_mpi = "101", payer = 1),
    temp_bpo_patients(groupid = "H000000", grp_mpi = "101", payer = 2),
    temp_bpo_patients(groupid = "H000000", grp_mpi = "102", payer = 1),
    temp_bpo_patients(groupid = "H000000", grp_mpi = "103", payer = 1)
  )

  val clinicalencounter_IN: DataFrame = mkDataFrame(
    clinicalencounter(groupid = "H000000", client_ds_id = 1, grp_mpi = "101", encounterid = "1", arrivaltime = Timestamp.valueOf("2016-07-06 07:57:00")),
    clinicalencounter(groupid = "H000000", client_ds_id = 1, grp_mpi = "101", encounterid = "1", arrivaltime = Timestamp.valueOf("2016-07-06 07:57:00")),
    clinicalencounter(groupid = "H000000", client_ds_id = 1, grp_mpi = "102", encounterid = "2", arrivaltime = Timestamp.valueOf("2016-07-06 07:57:00")),
    clinicalencounter(groupid = "H000000", client_ds_id = 1, grp_mpi = "103", encounterid = "3", arrivaltime = Timestamp.valueOf("2015-04-01 00:00:00")),
    clinicalencounter(groupid = "H000000", client_ds_id = 1, grp_mpi = "103", encounterid = "4", arrivaltime = Timestamp.valueOf("2015-04-01 00:00:00"))

  )

  val map_poa_IN: DataFrame = mkDataFrame(
    map_poa(groupid = "H000000", localcode = "code1", cui = "CH000090", dts_version = 1)
  )

  val zo_poa_IN: DataFrame = mkDataFrame(
    zo_poa(hts_cui = "CH000090", dts_version = 1, ii_code = "N"),
    zo_poa(hts_cui = "CH000090", dts_version = 1, ii_code = "Y"),
    zo_poa(hts_cui = "CH000090", dts_version = 1, ii_code = "U")
  )

  val map_predicate_values_IN: DataFrame = mkDataFrame(
    map_predicate_values(groupid = "H000000", client_ds_id = 1, entity = "PP_BPO_MEDICAL_CLAIMS", column_name = "PX_DX", data_src = "OADW", dts_version = 3)
  )

  val temp_bpo_calculate_params_IN: DataFrame = mkDataFrame(
    temp_bpo_calculate_params(engineStartDate = Date.valueOf("2015-04-01"), engineStartDate2 = Date.valueOf("2015-04-01"), engineStartDate3 = Date.valueOf("2015-04-01"), engineEndDate = Date.valueOf("2019-03-31"), startDate = Date.valueOf("2015-01-01"))
  )

  DateTimeUtils.setCurrentMillisFixed(10000)

  val temp_bpo_diagnosis_OUT: Seq[temp_bpo_diagnosis] = Seq(
    temp_bpo_diagnosis(groupid = "H000000", encounterid = "1", client_ds_id = 1, grp_mpi = "101", codetype = "ICD10", encounter_date = Timestamp.valueOf("2016-07-06 00:00:00"), icddiag1 = "d1", record_preference = 1, sourceid = "s1", icddiag1poa = "Y", db_create_dt_tm = new Timestamp(DateTime.now().getMillis)),
    temp_bpo_diagnosis(groupid = "H000000", encounterid = "3", client_ds_id = 1, grp_mpi = "103", codetype = "ICD10", encounter_date = Timestamp.valueOf("2015-04-01 00:00:00"), icddiag1 = "d4", icddiag2 = "d3", icddiag2poa = "Y", record_preference = 1, sourceid = "s3", icddiag1poa = "Y", db_create_dt_tm = new Timestamp(DateTime.now().getMillis)),
    temp_bpo_diagnosis(groupid = "H000000", encounterid = "4", client_ds_id = 1, grp_mpi = "103", codetype = "ICD10", encounter_date = Timestamp.valueOf("2015-04-01 00:00:00"), icddiag1 = "d5", record_preference = 1, sourceid = "s3", icddiag1poa = "Y", db_create_dt_tm = new Timestamp(DateTime.now().getMillis))

  )
  testQuery(
    testName = "test TEMP_BPO_DIAGNOSIS",
    query = TEMP_BPO_DIAGNOSIS,
    inputs = Map(
      "DIAGNOSIS" -> diagnosis_IN,
      "TEMP_BPO_PATIENTS" -> temp_bpo_patients_IN,
      "CLINICALENCOUNTER" -> clinicalencounter_IN,
      "MAP_POA" -> map_poa_IN,
      "TEMP_BPO_CALCULATE_PARAMS" -> temp_bpo_calculate_params_IN,
      "ZO_POA" -> zo_poa_IN,
      "MAP_PREDICATE_VALUES" -> map_predicate_values_IN,
      "TEMP_BPO_CALCULATE_PARAMS" -> temp_bpo_calculate_params_IN
    ),
    expectedOutput = temp_bpo_diagnosis_OUT
  )
}
