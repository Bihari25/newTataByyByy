package com.optum.oap.backend.etl.bpo.bpo_pyr_ii_7_2

import java.sql.Timestamp

import com.optum.oap.backend.BEQueryTestFramework
import com.optum.oap.backend.cdrTempModel.monthly_payer_servicerx_ii_7_2_extract
import com.optum.oap.cdr.models.{prov_status_rollup, _}
import org.apache.spark.sql.DataFrame

class MONTHLY_PAYER_SERVICERX_II_7_2_EXTRACT_Test extends BEQueryTestFramework {

  import spark.implicits._

  val originalSQL =
    """
      select
      |    clm.memberid as member,
      |    claimheader as clm_id_n,
      |    date_format(servicedate, 'yyyy-MM-dd') as dos,
      |    date_format(paymentdate, 'yyyy-MM-dd') as pay_dt,
      |    ndc as ndc,
      |    coalesce(quantity, 0) as met_qty,
      |    case when prescprovider = '0' then '999' else PRESCPROVIDER end as pres_prv,
      |    pharmacyid as provider,
      |    dea as dea,
      |    coalesce(dayssupply, 0) as day_sup,
      |    formulary as formulary,
      |    pharmacytype as channel,
      |    substring_index(claimheader, '.', -1) as uniq_rec_id,
      |    genericstatus as gbo,
      |    coalesce(coinsamount, 0) as amt_coin,
      |    coalesce(copayamount, 0) as amt_cop,
      |    coalesce(deductamount, 0) as amt_ded,
      |    coalesce(allowedamount, 0) as amt_eqv,
      |    round(coalesce(paidamount, 0), 2) as amt_pay,
      |    coalesce(requestedamount, 0) as amt_req,
      |    coalesce(patliabamount, 0) as amt_liab,
      |    cast(null as string) as amt_np,
      |    other_1_amt as amt_oth1,
      |    other_2_amt as amt_oth2,
      |    other_3_amt as amt_oth3,
      |    other_4_amt as amt_oth4,
      |    case when pseudoflag in ('Y','1') then 1
      |    when deniedflag in ('Y','1') then 1
      |    else 0 end as pseudo,
      |    case when network_paid_status_rollup in ('Y','1') then 1 else 0 end as network_status,
      |    clm.network_paid_status as network_paid_status,
      |    provider_status as provider_status,
      |    clm.contract_id as contract,
      |    denied_ind as denied_ind,
      |    spec_rx_ind as spec_rx_n,
      |    coalesce(daw, 0) as daw,
      |    coalesce(fillnum, 0) as refill_num,
      |    coalesce(coord_benefits_amt, 0) as amt_cob,
      |    coalesce(dispensingfee, 0) as amt_disp,
      |    coalesce(ingredientcost, 0) as amt_ingr,
      |    coalesce(not_covered_amt, 0) as amt_not_covered,
      |    coalesce(other_carrier_pay_amt, 0) as amt_other_carrier_pay,
      |    coalesce(admin_fee_amt, 0) as amt_admin_fee,
      |    coalesce(sales_tax_amt, 0) as amt_sales_tax,
      |    capitated_service_ind as cap_flag,
      |    coalesce(adjusted_rx_cnt, 0) as rx_count_n,
      |    '1' as map_srce_e,
      |    '1' as map_srce_p,
      |    '1' as map_srce_n,
      |    cust_attr_1 as cust_rx_1,
      |    cust_attr_2 as cust_rx_2,
      |    cust_attr_3 as cust_rx_3,
      |    cust_attr_4 as cust_rx_4,
      |    cust_attr_5 as cust_rx_5,
      |    cust_attr_6 as cust_rx_6,
      |    cust_attr_7 as cust_rx_7,
      |    cust_attr_8 as cust_rx_8,
      |    cust_attr_9 as cust_rx_9,
      |    cust_attr_10 as cust_rx_10,
      |    cust_attr_11 as cust_rx_11,
      |    cust_attr_12 as cust_rx_12,
      |    cust_attr_13 as cust_rx_13,
      |    cust_attr_14 as cust_rx_14,
      |    cust_attr_15 as cust_rx_15,
      |    cust_attr_16 as cust_rx_16,
      |    cust_attr_17 as cust_rx_17,
      |    cust_attr_18 as cust_rx_18,
      |    cust_attr_19 as cust_rx_19,
      |    cust_attr_20 as cust_rx_20,
      |    claimheader as cust_rx_pk_id
      |from pp_bpo_pharmacy_claims clm
      |left join
      |    pp_bpo_member_detail mbr
      |    on (
      |    mbr.memberid = clm.memberid
      |    and mbr.healthplansource = clm.healthplansource
      |    and clm.servicedate
      |    between mbr.effectivedate and mbr.enddate
      |    )
      |left outer join
      |    pp_bpo_member_detail_ii ii
      |    on (
      |    ii.memberid = clm.memberid
      |    and ii.healthplansource = clm.healthplansource
      |    and clm.servicedate
      |    between ii.effectivedate and ii.enddate
      |    and clm.employeraccountid = ii.employeraccountid
      |    )
      |left join (select distinct prov_status_rollup as prov_status_rollup, prov_status_id as prov_status_id from prov_status_rollup) psr on psr.prov_status_id = clm.provider_status
      |left join (select distinct network_paid_status_rollup, network_paid_status from netwrk_paid_status_rollup) npsr on npsr.network_paid_status = clm.network_paid_status
      |left join (select  distinct 'Y' as mpv_exists, groupid from map_predicate_values where data_Src = 'OADW'
      |                    and table_name = 'PP_BPO_MEDICAL_CLAIMS'  and entity = 'PP_BPO_MEDICAL_CLAIMS'  and column_name = 'CLM_PASS') mpv on mpv.groupid=clm.groupid
      |where clm.healthplansource = 'PAYER' and (mpv.mpv_exists = 'Y' or (clm.employeraccountid = mbr.employeraccountid or ii.memberid is not null))
    """.stripMargin

  val ppBpoPharmacyClaims: DataFrame = mkDataFrame(
    pp_bpo_pharmacy_claims(memberid = "m1", prescprovider = "0", other_carrier_pay_amt = 1.1d, paidamount = 12.123, healthplansource = "PAYER", quantity = 1, servicedate = Timestamp.valueOf("2020-01-01 00:00:00"), provider_status = "p1", network_paid_status = "n1", employeraccountid = "BCBS"),
    pp_bpo_pharmacy_claims(memberid = "m2", healthplansource = "PAYER1", servicedate = Timestamp.valueOf("2013-01-01 00:00:00"), provider_status = "p1", network_paid_status = "n1", employeraccountid = "BCBS"),
    pp_bpo_pharmacy_claims(memberid = "m3", healthplansource = "PAYER2", servicedate = Timestamp.valueOf("2020-02-01 00:00:00"), provider_status = "p3", network_paid_status = "n2", employeraccountid = "BCBS")
  )

  val ppBpoMemberDetail: DataFrame = mkDataFrame(
    pp_bpo_member_detail(healthplansource = "PAYER", groupid = "H000000", memberid = "m1", subscriberid = "123", effectivedate = java.sql.Timestamp.valueOf("2018-06-15 00:00:00"), enddate = java.sql.Timestamp.valueOf("2020-08-18 00:00:00"), employeraccountid = "BCBS"),
    pp_bpo_member_detail(healthplansource = "PAYER", groupid = "H000000", memberid = "m2", subscriberid = "m1", effectivedate = java.sql.Timestamp.valueOf("2019-06-13 00:00:00"), enddate = java.sql.Timestamp.valueOf("2019-07-20 00:00:00"), employeraccountid = "BCBS"),
    pp_bpo_member_detail(healthplansource = "PAYER", groupid = "H000000", memberid = "m3", subscriberid = "m2", effectivedate = java.sql.Timestamp.valueOf("2011-06-18 00:00:00"), enddate = java.sql.Timestamp.valueOf("2029-07-11 00:00:00"), employeraccountid = "BCBS")
  )

  val ppBpoMemberDetail_ii: DataFrame = mkDataFrame(
    pp_bpo_member_detail_ii(healthplansource = "PAYER", groupid = "H000000", memberid = "m1", effectivedate = java.sql.Timestamp.valueOf("2018-06-15 00:00:00"), enddate = java.sql.Timestamp.valueOf("2020-08-18 00:00:00"))
  )

  val provStatusRollUp: DataFrame = mkDataFrame(
    prov_status_rollup(client_ds_id = 999, datasrc = "testdatasrc", groupid = "g1", prov_status_desc = "prov_status_desc_1", prov_status_id = "p1", prov_status_lv1 = "prov_status_lv1_1", prov_status_lv1_desc = "prov_status_lv1_desc_1", prov_status_lv2 = "prov_status_lv2_1", prov_status_lv2_desc = "prov_status_lv2_desc_1", prov_status_rollup = "prov_status_rollup_1")
  )

  val netwrkPaidStatusRollupIn: DataFrame = mkDataFrame(
    netwrk_paid_status_rollup(network_paid_status_rollup = "status", network_paid_status = "n1"),
    netwrk_paid_status_rollup(network_paid_status_rollup = "status2", network_paid_status = "n2")
  )

  val mapPredicateValues: DataFrame = mkDataFrame(
    map_predicate_values(groupid = "H000000", data_src = "OADW", table_name = "PP_BPO_MEDICAL_CLAIMS", entity = "PP_BPO_MEDICAL_CLAIMS", column_name = "CLM_PASS")
  )

  val expectedOutput: Seq[monthly_payer_servicerx_ii_7_2_extract] = Seq(
    monthly_payer_servicerx_ii_7_2_extract(member = "m1", pres_prv = "999",  dos = "2020-01-01", met_qty = "1", day_sup = "0", amt_coin = "0.0", amt_cop = "0.0", amt_ded = "0.0", amt_eqv = "0.0", amt_pay = "12.12", amt_req = "0.0", amt_liab = "0.0", pseudo = "0", network_status = "0", network_paid_status = "n1", provider_status = "p1", daw = "0", refill_num = "0", amt_cob = "0.0", amt_disp = "0.0", amt_ingr = "0.0", amt_not_covered = "0.0", amt_other_carrier_pay = "1.1", amt_admin_fee = "0.0", amt_sales_tax = "0.0", rx_count_n = "0.0", map_srce_e = "1", map_srce_p = "1", map_srce_n = "1")
  )


  testQuery(
    testName = "test MONTHLY_PAYER_SERVICERX_II_7_2_EXTRACT",
    query = MONTHLY_PAYER_SERVICERX_II_7_2_EXTRACT,
    inputs = Map(
      "NETWRK_PAID_STATUS_ROLLUP" -> netwrkPaidStatusRollupIn,
      "PROV_STATUS_ROLLUP" -> provStatusRollUp,
      "MAP_PREDICATE_VALUES" -> mapPredicateValues,
      "PP_BPO_PHARMACY_CLAIMS" -> ppBpoPharmacyClaims,
      "PP_BPO_MEMBER_DETAIL" -> ppBpoMemberDetail,
      "PP_BPO_MEMBER_DETAIL_II" -> ppBpoMemberDetail_ii
    ),
    expectedOutput = expectedOutput
  )

  it should "output of new etl should match with original Spark SQL etl" in {
    ppBpoPharmacyClaims.createOrReplaceTempView("pp_bpo_pharmacy_claims")
    ppBpoMemberDetail.createOrReplaceTempView("pp_bpo_member_detail")
    ppBpoMemberDetail_ii.createOrReplaceTempView("pp_bpo_member_detail_ii")
    netwrkPaidStatusRollupIn.createOrReplaceTempView("netwrk_paid_status_rollup")
    mapPredicateValues.createOrReplaceTempView("map_predicate_values")
    provStatusRollUp.createOrReplaceTempView("prov_status_rollup")
    netwrkPaidStatusRollupIn.createOrReplaceTempView("netwrk_paid_status_rollup")
    mapPredicateValues.createOrReplaceTempView("map_predicate_values")

    val originalOutput = spark.sql(originalSQL)

    checkThatDataFramesAreEqual(originalOutput, expectedOutput)
  }
}
