package com.optum.oap.backend.etl.bpo

import java.sql.{Date, Timestamp}

import com.optum.oap.backend.BEQueryTestFramework
import com.optum.oap.backend.cdrTempModel.{temp_bpo_calculate_params, temp_bpo_patients}
import com.optum.oap.cdr.models._
import org.apache.spark.sql.DataFrame

/**
  *
  * Copyright 2019 Optum Analytics
  *
  * Date: 6/10/19
  *
  * Creator: pavula1
  */
class PP_BPO_PHARMACY_CLINICAL_Test extends BEQueryTestFramework {

  import spark.implicits._

  val immunization_init: DataFrame = mkDataFrame(
    immunization(groupid = "H000000", client_ds_id = 1, patientid = "P1", grp_mpi = "g1", dcc = "1", admindate = Timestamp.valueOf("2016-4-01 10:15:00"), documenteddate = Timestamp.valueOf("2017-4-01 00:00:00"))
  )

  val map_dcc: DataFrame = mkDataFrame(
    map_dcc_cvx(dcc = "1", cvx_code = "11", preferred = "Y"),
    map_dcc_cvx(dcc = "2", cvx_code = "12", preferred = "Y"),
    map_dcc_cvx(dcc = "3", cvx_code = "13", preferred = "Y")
  )

  val rx_init: DataFrame = mkDataFrame(
    rxorder(groupid = "H000000", client_ds_id = 1, grp_mpi = "g2", dcc = "2", issuedate = Timestamp.valueOf("2017-4-01 00:00:00"))
  )

  val rx_reported: DataFrame = mkDataFrame(
    rx_patient_reported(groupid = "H000000", client_ds_id = 1, grp_mpi = "g3", dcc = "3", medreportedtime = Timestamp.valueOf("2018-4-01 00:00:00")),
    rx_patient_reported(groupid = "H000000", client_ds_id = 1, grp_mpi = "g3", dcc = "3", actiontime = Timestamp.valueOf("2017-5-01 00:00:00"))
  )

  val params: DataFrame = mkDataFrame(
    temp_bpo_calculate_params(engineStartDate = Date.valueOf("2015-04-01"), engineStartDate2 = Date.valueOf("2015-04-01"), engineStartDate3 = Date.valueOf("2015-04-01"), engineEndDate = Date.valueOf("2019-03-31"), startDate = Date.valueOf("2015-01-01"))
  )

  val temp_patients_in: DataFrame = mkDataFrame(
    temp_bpo_patients(groupid = "H000000", grp_mpi = "g1", payer = 1),
    temp_bpo_patients(groupid = "H000000", grp_mpi = "g2"),
    temp_bpo_patients(groupid = "H000000", grp_mpi = "g3", payer = 1)
  )

  val expectedOutput: Seq[pp_bpo_pharmacy_clinical] = Seq(
    pp_bpo_pharmacy_clinical(groupid = "H000000", memberid = "g1", pharmacy_clinical_id = "PHC1.1", code_taxonomy = "CVX", code = "11", administration_date = Timestamp.valueOf("2016-4-01 00:00:00"), healthplansource = "PAYER"),
    pp_bpo_pharmacy_clinical(groupid = "H000000", memberid = "g2", pharmacy_clinical_id = "PHC1.2", code_taxonomy = "CVX", code = "12", administration_date = Timestamp.valueOf("2017-4-01 00:00:00"), healthplansource = "PROVIDER"),
    pp_bpo_pharmacy_clinical(groupid = "H000000", memberid = "g3", pharmacy_clinical_id = "PHC1.3", code_taxonomy = "CVX", code = "13", administration_date = Timestamp.valueOf("2018-4-01 00:00:00"), healthplansource = "PAYER"),
    pp_bpo_pharmacy_clinical(groupid = "H000000", memberid = "g3", pharmacy_clinical_id = "PHC1.4", code_taxonomy = "CVX", code = "13", administration_date = Timestamp.valueOf("2017-5-01 00:00:00"), healthplansource = "PAYER")
  )


  testQuery(
    testName = "test PP_BPO_PHARMACY_CLINICAL",
    query = PP_BPO_PHARMACY_CLINICAL,
    inputs = Map(
      "IMMUNIZATION" -> immunization_init,
      "MAP_DCC_CVX" -> map_dcc,
      "TEMP_BPO_CALCULATE_PARAMS" -> params,
      "RXORDER" -> rx_init,
      "RX_PATIENT_REPORTED" -> rx_reported,
      "TEMP_BPO_PATIENTS" -> temp_patients_in
    ),
    expectedOutput = expectedOutput
  )

}
