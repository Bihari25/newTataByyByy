package com.optum.oap.backend.etl.bpo.bpo_pyr_hedis_qme

import com.optum.oap.backend.BEQueryTestFramework
import com.optum.oap.backend.cdrTempModel.hedis_monthly_lab_extract_qme
import com.optum.oap.cdr.models.{pp_bpo_labresult_claims, pp_bpo_member_detail}
import org.apache.spark.sql.DataFrame

class HEDIS_MONTHLY_LAB_EXTRACT_QME_Test extends BEQueryTestFramework{

  import spark.implicits._

  val ppBpoLabresultClaims: DataFrame = mkDataFrame(
    pp_bpo_labresult_claims(groupid = "H000000", memberid = "m1", claimheader = "ch1", healthplansource = "PAYER",testresulttext = "N" , servicedate = java.sql.Timestamp.valueOf("2020-01-01 00:00:00")),
    pp_bpo_labresult_claims(groupid = "H000000", memberid = "m2", claimheader = "ch2",healthplansource = "PAYER", testresulttext = "Positive", servicedate = java.sql.Timestamp.valueOf("2011-01-01 00:00:00")),
    pp_bpo_labresult_claims(groupid = "H000000", memberid = "m3", healthplansource = "PAYER2", servicedate = java.sql.Timestamp.valueOf("2013-01-01 00:00:00"))
  )

  val ppBpoMemberDetail : DataFrame = mkDataFrame(
    pp_bpo_member_detail(memberid = "m1", groupid = "H000000", employeraccountid = "employer account id 1", healthplansource = "PAYER", lineofbusinessid = 1, enddate = java.sql.Timestamp.valueOf("2020-01-31 00:00:00"), effectivedate = java.sql.Timestamp.valueOf("2020-01-31 00:00:00"), dob = java.sql.Timestamp.valueOf("2020-02-20 00:00:00"), city = "city 1"),
    pp_bpo_member_detail(memberid = "m2", groupid = "H000000", employeraccountid = "employer account id 2", healthplansource = "PAYER", lineofbusinessid = 1, enddate = java.sql.Timestamp.valueOf("2020-02-20 00:00:00"), effectivedate = java.sql.Timestamp.valueOf("2020-03-30 00:00:00"), dob = java.sql.Timestamp.valueOf("2020-01-30 00:00:00"), city = "city 2"),
    pp_bpo_member_detail(memberid = "m3", groupid = "H000000", employeraccountid = "employer account id 3", healthplansource = "PAYER", lineofbusinessid = 1, enddate = java.sql.Timestamp.valueOf("2020-03-20 00:00:00"), effectivedate = java.sql.Timestamp.valueOf("2020-02-20 00:00:00"), dob = java.sql.Timestamp.valueOf("2020-03-20 00:00:00"), city = "city 3"),
    pp_bpo_member_detail(memberid = "m4", groupid = "H000000", employeraccountid = "employer account id 4", healthplansource = "PAYER", lineofbusinessid = 1, enddate = java.sql.Timestamp.valueOf("2020-01-20 00:00:00"), effectivedate = java.sql.Timestamp.valueOf("2020-01-20 00:00:00"), dob = java.sql.Timestamp.valueOf("2020-02-20 00:00:00"), city = "city 4"),
    pp_bpo_member_detail(memberid = "m5", groupid = "H000000", employeraccountid = "employer account id 4", healthplansource = "PAYER", lineofbusinessid = 1, enddate = java.sql.Timestamp.valueOf("2020-04-20 00:00:00"), effectivedate = java.sql.Timestamp.valueOf("2020-04-20 00:00:00"), dob = java.sql.Timestamp.valueOf("2020-03-20 00:00:00"), city = "city 5")
  )

  val expectedOutput: Seq[hedis_monthly_lab_extract_qme] = Seq(
    hedis_monthly_lab_extract_qme(MemberID = "m1", ClaimHeaderID = "ch1", ServiceDate = "2020-01-01", MapSource = "SS", HealthPlanSource = "PAYER", TestResultText = "Negative"),
    hedis_monthly_lab_extract_qme(MemberID = "m2", ClaimHeaderID = "ch2", ServiceDate = "2011-01-01", MapSource = "SS", HealthPlanSource = "PAYER", TestResultText = "Positive")
  )

  testQuery(
    testName = "test HEDIS_MONTHLY_LAB_EXTRACT_QME",
    query = HEDIS_MONTHLY_LAB_EXTRACT_QME,
    inputs = Map(
      "PP_BPO_MEMBER_DETAIL" -> ppBpoMemberDetail,
      "PP_BPO_LABRESULT_CLAIMS" -> ppBpoLabresultClaims
    ),
    expectedOutput = expectedOutput
  )

}
