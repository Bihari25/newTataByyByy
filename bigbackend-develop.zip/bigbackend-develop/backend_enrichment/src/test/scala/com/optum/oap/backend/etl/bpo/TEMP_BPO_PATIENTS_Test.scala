package com.optum.oap.backend.etl.bpo

import java.sql.{Date, Timestamp}

import com.optum.oap.backend.BEQueryTestFramework
import com.optum.oap.backend.cdrTempModel.{temp_bpo_calculate_params, temp_bpo_patients}
import com.optum.oap.cdr.models.{clinicalencounter, insurance, patient_summary, patient_summary_grp_mpi, _}
import org.apache.spark.sql.DataFrame

/**
  *
  * Copyright 2019 Optum Analytics
  *
  * Date: 5/16/19
  *
  * Creator: pavula1
  */
class TEMP_BPO_PATIENTS_Test extends BEQueryTestFramework {

  import spark.implicits._

  val clinicalencounterIn: DataFrame = mkDataFrame(
    clinicalencounter(groupid = "H000000", client_ds_id = 2, grp_mpi = "g1", encounterid = "123", arrivaltime = Timestamp.valueOf("2016-07-06 07:57:00")),

    //ArrivalTime is not in the range, so this record is not included.
    clinicalencounter(groupid = "H000000", client_ds_id = 1, grp_mpi = "g2", encounterid = "123", arrivaltime = Timestamp.valueOf("2014-07-06 07:57:00"))
  )

  val patientSummaryGrpIn: DataFrame = mkDataFrame(

    patient_summary_grp_mpi(groupid = "H000000", grp_mpi = "g1", dob = "20100816", mapped_gender = "CH000034", mapped_ethnicity = "CH999999", mapped_race = "CH999999", mapped_death_ind = "CH001138"),
    patient_summary_grp_mpi(groupid = "H000000", grp_mpi = "g2", dob = "20100816", mapped_gender = "CH000034", mapped_ethnicity = "CH999999", mapped_race = "CH999999", mapped_death_ind = "CH001138"),
    patient_summary_grp_mpi(groupid = "H000000", grp_mpi = "g3", dob = "20100816", mapped_gender = "CH000034", mapped_ethnicity = "CH999999", mapped_race = "CH999999", mapped_death_ind = "CH001138"),
    patient_summary_grp_mpi(groupid = "H000000", grp_mpi = "g4", dob = "20100816", mapped_gender = "CH000034", mapped_ethnicity = "CH999999", mapped_race = "CH999999", mapped_death_ind = "CH001138"),
    patient_summary_grp_mpi(groupid = "H000000", grp_mpi = "g5"),
    patient_summary_grp_mpi(groupid = "H000000", grp_mpi = "g6"),
    patient_summary_grp_mpi(groupid = "H000000", grp_mpi = "g7")
  )

  val insuranceIn: DataFrame = mkDataFrame(
    insurance(groupid = "H000000", grp_mpi = "g3", client_ds_id = 1, enrollstartdt = Timestamp.valueOf("2014-07-06 07:57:00"), ins_timestamp = Timestamp.valueOf("2014-07-06 07:57:00"), enrollenddt = Timestamp.valueOf("2016-07-06 07:57:00"), mappedplanfincode = "CH000099", pharmacy_benefit_flag = "N", dental_benefit_ind = 1, medical_benefit_ind = 1, mh_benefit_ind = 1, employee_type = "employee type 1", hra_ind = 1, hsa_ind = 1, product_code = "product_code 1"),
    insurance(groupid = "H000000", grp_mpi = "g4", client_ds_id = 1, plantype = "plan1", enrollstartdt = Timestamp.valueOf("2014-07-06 07:57:00"), ins_timestamp = Timestamp.valueOf("2014-07-06 07:57:00"), enrollenddt = Timestamp.valueOf("2016-07-06 07:57:00"), mappedplanfincode = "CH000099", pharmacy_benefit_flag = "N", dental_benefit_ind = 2, employee_type = "employee type 2", hra_ind = 2, hsa_ind = 2, product_code = "product_code 2"),
    insurance(groupid = "H000000", grp_mpi = "g5", client_ds_id = 1, plantype = "plan2", mappedplanfincode = "CH000100"),
    insurance(groupid = "H000000", grp_mpi = "g6", client_ds_id = 1, plantype = "plan3"),
    insurance(groupid = "H000000", grp_mpi = "g7", client_ds_id = 1, plantype = "plan4")

  )
  val patientSummaryIn: DataFrame = Seq.empty[patient_summary].toDF()

  val mapEmployerIn: DataFrame = mkDataFrame(
    zo_bpo_map_employer(groupid = "H000000", client_ds_id = 1, employeraccountid = "BCBS")
  )
  val mapFinancialClassIn: DataFrame = mkDataFrame(
    map_financial_class(groupid = "H000000", mnemonic = "plan1", cui = "CH000097"),
    map_financial_class(groupid = "H000000", mnemonic = "plan3", cui = "CH004570"),
    map_financial_class(groupid = "H000000", mnemonic = "plan4")
  )

  val mapPredicateValuesIn: DataFrame = mkDataFrame(
    map_predicate_values(groupid = "H000000",client_ds_id = 3, data_src = "BPO_ENROLL_EXCLUDE",entity = "BPO_TABLES",table_name = "PP_BPO_MEMBER_DETAIL",column_name = "ENDDATE",column_value = "Y"),
    map_predicate_values(groupid = "H000000",client_ds_id = 4, data_src = "BPO_ENROLL_EXCLUDE",entity = "BPO_TABLES",table_name = "PP_BPO_MEMBER_DETAIL",column_name = "ENDDATE",column_value = "Y"),
    map_predicate_values(groupid = "H000000",client_ds_id = 1, data_src = "BPO_NONPAYER",entity = "BPO_TABLES",table_name = "PP_BPO_MEMBER_DETAIL",column_name = "MEMBERID",column_value = "Yes")
  )

  val tempParamsIn: DataFrame = mkDataFrame(
    temp_bpo_calculate_params(engineStartDate = Date.valueOf("2015-04-01"), engineStartDate2 = Date.valueOf("2015-04-01"), engineStartDate3 = Date.valueOf("2015-04-01"), engineEndDate = Date.valueOf("2019-03-31"), startDate = Date.valueOf("2015-01-01"))
  )

  val expectedOutput: Seq[temp_bpo_patients] = Seq(
    temp_bpo_patients(groupid = "H000000", grp_mpi = "g1", dob = "20100816", employeraccountid = " ", mapped_gender = "CH000034", effective_date = Timestamp.valueOf("2015-04-01 00:00:00"),
      end_date = Timestamp.valueOf("2019-03-31 00:00:00"), payer = 0, productcode = "Other", pharmacy_benefit_flag = "N", mapped_race = "CH999999", mapped_ethnicity = "CH999999", contract_id = " ", subscriberid = "g1", subscriberflag = "Y", coverageclasscode =  "MED"),

   temp_bpo_patients(groupid = "H000000", grp_mpi = "g3", dob = "20100816", employeraccountid = "BCBS", mapped_gender = "CH000034", effective_date = Timestamp.valueOf("2014-07-06 07:57:00"),
    end_date = Timestamp.valueOf("2016-07-06 07:57:00"), payer = 1, productcode = "MLI", lineofbusinessid = 1, pharmacy_benefit_flag = "N", mapped_race = "CH999999", mapped_ethnicity = "CH999999", contract_id = "BCBS", subscriberid = "g3", subscriberflag = "Y", coverageclasscode =  "MED", dental_benefit_ind = 1, medical_benefit_ind = 1, mh_benefit_ind = 1, employee_type = "employee type 1", hra_ind = 1, hsa_ind = 1, product_dtl_code = "product_code 1"),

    temp_bpo_patients(groupid = "H000000", grp_mpi = "g4", dob = "20100816", employeraccountid = "BCBS", mapped_gender = "CH000034", effective_date = Timestamp.valueOf("2014-07-06 07:57:00"),
      end_date = Timestamp.valueOf("2016-07-06 07:57:00"), payer = 1, productcode = "HMO", lineofbusinessid = 0, pharmacy_benefit_flag = "N", mapped_race = "CH999999", mapped_ethnicity = "CH999999", contract_id = "BCBS", subscriberid = "g4", subscriberflag = "Y", coverageclasscode =  "MED", dental_benefit_ind = 2, employee_type = "employee type 2", hra_ind = 2, hsa_ind = 2, product_dtl_code = "product_code 2"),

    temp_bpo_patients(groupid = "H000000", grp_mpi = "g5", productcode = "MR", lineofbusinessid = 2, employeraccountid = "BCBS", payer = 1, pharmacy_benefit_flag = "Y", contract_id = "BCBS", subscriberid = "g5", subscriberflag = "Y", end_date = Timestamp.valueOf("2019-03-31 00:00:00"), coverageclasscode = "MED"),
    temp_bpo_patients(groupid = "H000000", grp_mpi = "g6", productcode = "MR", lineofbusinessid = 2, employeraccountid = "BCBS", payer = 1, pharmacy_benefit_flag = "Y", contract_id = "BCBS", subscriberid = "g6", subscriberflag = "Y", end_date = Timestamp.valueOf("2019-03-31 00:00:00"), coverageclasscode = "MED"),
    temp_bpo_patients(groupid = "H000000", grp_mpi = "g7", productcode = "Other", employeraccountid = "BCBS", payer = 1, pharmacy_benefit_flag = "Y", contract_id = "BCBS", subscriberid = "g7", subscriberflag = "Y", end_date = Timestamp.valueOf("2019-03-31 00:00:00"), coverageclasscode = "MED")
  )



  testQuery(
    testName = "test TEMP_BPO_PATIENTS",
    query = TEMP_BPO_PATIENTS,
    inputs = Map(
      "CLINICALENCOUNTER" -> clinicalencounterIn,
      "PATIENT_SUMMARY_GRP_MPI" -> patientSummaryGrpIn,
      "INSURANCE" -> insuranceIn,
      "PATIENT_SUMMARY" -> patientSummaryIn,
      "ZO_BPO_MAP_EMPLOYER" -> mapEmployerIn,
      "MAP_FINANCIAL_CLASS" -> mapFinancialClassIn,
      "MAP_PREDICATE_VALUES" -> mapPredicateValuesIn,
      "TEMP_BPO_CALCULATE_PARAMS" -> tempParamsIn
    ),
    expectedOutput = expectedOutput
  )

}
