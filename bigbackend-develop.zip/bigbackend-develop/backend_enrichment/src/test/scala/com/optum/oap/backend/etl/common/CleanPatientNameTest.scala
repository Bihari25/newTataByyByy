package com.optum.oap.backend.etl.common

import com.optum.oap.testutils.TestSparkSession
import org.apache.spark.sql.functions.lit
import org.junit.runner.RunWith
import org.scalatest.FlatSpec
import org.scalatest.Matchers._
import org.scalatest.junit.JUnitRunner


@RunWith(classOf[JUnitRunner])
class CleanPatientNameTest extends FlatSpec with TestSparkSession{
  private val spark = sparkSession

  import spark.implicits._

  behavior of "CleanName UDF"

  def cleanPatientNameTest(str: String, expectedResult: String): Unit = {

    it should s"clean $str to remove extraneous elements with result $expectedResult " in {

      val df = Seq(
        str
      ).toDF()

      val output = df.select(CleanPatientName.cleanPatientName(lit(str), lit(3))).as[String].collect().head
      output shouldEqual expectedResult
    }
  }

  cleanPatientNameTest(str = "John student", expectedResult = "JOHN STUDENT")
  cleanPatientNameTest(str = null, expectedResult = null)
  cleanPatientNameTest(str = "John Do Smith", expectedResult = "JOHN DO SMITH")
  cleanPatientNameTest(str = "John DO", expectedResult = "JOHN")
  cleanPatientNameTest(str = "do-a", expectedResult = "DO")
  cleanPatientNameTest(str = "JOHN MD PHD", expectedResult = "JOHN")
  cleanPatientNameTest(str = "JOHN C C", expectedResult = "JOHN")
  cleanPatientNameTest(str = "JOHN DO DO", expectedResult = "JOHN")

}
