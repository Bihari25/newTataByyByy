package com.optum.oap.backend.etl.cdrfe

import com.optum.oap.backend.BEQueryTestFramework
import com.optum.oap.backend.etl.common.OADefinedFunctionsRegistry
import com.optum.oap.backend.loader.EnrichmentRunTimeVariables
import com.optum.oap.cdr.models.{allergy, insurance}
import com.optum.oap.sparkdataloader.DataLoader
import com.optum.oap.testutils.TemporaryFolderForAll
import org.apache.spark.sql.functions.{expr, lit}
import org.junit.runner.RunWith
import org.scalatest.MustMatchers
import org.scalatest.junit.JUnitRunner

import scala.concurrent.ExecutionContext

@RunWith(classOf[JUnitRunner])
class CDRFE_ENTITYTest extends BEQueryTestFramework with MustMatchers with TemporaryFolderForAll {

  implicit val sparkession = spark
  import spark.implicits._

  private[this] implicit val ec: ExecutionContext = ExecutionContext.global

  private val clientDataSourceIds = Seq(100, 101)
  private val entities = Seq("ALLERGY", "DIAGNOSIS")
  private val runtimeVariables = EnrichmentRunTimeVariables(clientId = "H704847",
    environment = "dev",
    cdrSchema = "test",
    cdrLevel = "ecdr",
    cdrCycle = "integration_test",
    instance = "0",
    release = "integration_test",
    buildType = "Monthly",
    fullHiveDb = "ecdr")

  behavior of "CDRFE_ENTITY"

  it should "should return empty dataframe for entities that aren't present under the client_ds_ids" in {
    val loader = new DataLoader(tempFolder.newFolder().getAbsolutePath)
    val dataSources = clientDataSourceIds.map(id => CDRFEDataSource(id, tempFolder.newFolder(id.toString).getAbsolutePath))
    val cdrfeEntities = entities.map(entity => CDRFE_ENTITY(entity, dataSources))
    loader.loadData(cdrfeEntities, spark, OADefinedFunctionsRegistry.ALL_UDFS.toSeq, runtimeVariables)
    entities.foreach(entity => {
      val count = spark.read.parquet(s"${loader.basePath}/$entity").count()
      count mustBe 0L
    })
  }

  /**
    * This test validates the following
    * 1) Entity is present only under one of the client_ds_id
    * 2) Record filtering i.e. we are filtering records where groupid is H704847
    */
  it should "filter and return dataframe with data" in {
    val loader = new DataLoader(tempFolder.newFolder().getAbsolutePath)
    val dataSources = clientDataSourceIds.map(id => CDRFEDataSource(id, tempFolder.newFolder().getAbsolutePath))
    val sourceDf = mkDataFrame(
      allergy(client_ds_id = 100, groupid = "H704847", grp_mpi = "P1"),
      allergy(client_ds_id = 100, groupid = "H000166", grp_mpi = "P1"))
    sourceDf.write.parquet(s"${dataSources.head.dataSourcePath}/ALLERGIES")
    val cdrfeEntities = Seq(CDRFE_ENTITY("ALLERGY", dataSources, $"groupid" === lit("H704847")))
    loader.loadData(cdrfeEntities, spark, OADefinedFunctionsRegistry.ALL_UDFS.toSeq, runtimeVariables)
    val outputDf = spark.read.parquet(s"${loader.basePath}/ALLERGY")
    checkThatDataFramesAreEqual(outputDf, Seq(allergy(client_ds_id = 100, groupid = "H704847", grp_mpi = "P1")))
  }

  /**
    * This test validates the following
    * 1) Entity is present only under one of the client_ds_id
    * 2) Record filtering i.e. we are filtering records where groupid is H704847
    */
  it should "apply conditional logic to the CDRFE_Entity object" in {
    val loader = new DataLoader(tempFolder.newFolder().getAbsolutePath)
    val dataSources = clientDataSourceIds.map(id => CDRFEDataSource(id, tempFolder.newFolder().getAbsolutePath))
    val insuranceSourceDf = mkDataFrame(insurance(client_ds_id = 100, groupid = "H704847", grp_mpi = "I1"))
    val allergySourceDf = mkDataFrame(
      allergy(client_ds_id = 100, groupid = "H704847", grp_mpi = "P1"),
      allergy(client_ds_id = 100, groupid = "H000166", grp_mpi = "P1"))

    insuranceSourceDf.write.parquet(s"${dataSources.head.dataSourcePath}/INSURANCE")
    allergySourceDf.write.parquet(s"${dataSources.head.dataSourcePath}/ALLERGIES")

    val cdrfeEntities = Seq(
      CDRFE_ENTITY("INSURANCE", dataSources, $"groupid" === lit("H704847")),
      new CDRFE_ENTITY("ALLERGY", dataSources, $"groupid" === lit("H704847")) with DummyEntity)

    loader.loadData(cdrfeEntities, spark, OADefinedFunctionsRegistry.ALL_UDFS.toSeq, runtimeVariables)
    val outputDf = spark.read.parquet(s"${loader.basePath}/ALLERGY")
    checkThatDataFramesAreEqual(outputDf, Seq(
      allergy(client_ds_id = 100, groupid = "H704847", grp_mpi = "P1"),
      allergy(client_ds_id = 100, groupid = "H704847", grp_mpi = "P3")))
  }
}
