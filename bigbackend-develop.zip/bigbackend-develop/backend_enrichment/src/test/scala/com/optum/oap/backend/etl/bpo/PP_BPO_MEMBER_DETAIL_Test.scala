package com.optum.oap.backend.etl.bpo

import java.sql.{Date, Timestamp}

import com.optum.oap.backend.BEQueryTestFramework
import com.optum.oap.backend.cdrTempModel.{temp_bpo_calculate_params, temp_bpo_insurance}
import com.optum.oap.cdr.models.{patient_summary, pp_bpo_member_detail, zo_bpo_map_employer}
import org.apache.spark.sql.DataFrame

/**
  *
  * Copyright 2019 Optum Analytics
  *
  * Date: 5/31/19
  *
  * Creator: pavula1
  */
class PP_BPO_MEMBER_DETAIL_Test extends BEQueryTestFramework {

  import spark.implicits._

  val tempBpoInsurance: DataFrame = mkDataFrame(

    temp_bpo_insurance(groupid = "H000000", grp_mpi = "g1", dob = "20100816", mapped_gender = "CH000034", healthplansource = "PAYER", employeraccountid = "BCBS", member_start = Timestamp.valueOf("2016-08-01 00:00:00"), member_end = Timestamp.valueOf("2016-08-31 00:00:00"), productcode = "MDE", pcpid = "21", pharmacy = "N", product_source = "PA", lineofbusinessid = 1, mapped_race = "CH999999", mapped_ethnicity = "CH999999", mapped_language = "CH002130", prodrank = 1, payrank = 1, distinct_pyrcnt = 1,
      date_of_death = Timestamp.valueOf("2017-11-17 00:00:00"), contract_id = "CMS", at_risk_status = "Y", cust_mem_attr1 = "WA", subscriberid = "123", subscriberflag = "Y", coverage_status = "MED", emp_acct_id = "BCBS", contracttype = "c", benefitplan = "b", coverageclasscode = "code1"),
    temp_bpo_insurance(groupid = "H000000", grp_mpi = "g1", dob = "20100816", mapped_gender = "CH000034", healthplansource = "PAYER", employeraccountid = "BCBS", member_start = Timestamp.valueOf("2016-07-01 00:00:00"), member_end = Timestamp.valueOf("2016-07-31 00:00:00"), productcode = "MDE", pcpid = "21", pharmacy = "N", product_source = "PA", lineofbusinessid = 1, mapped_race = "CH999999", mapped_ethnicity = "CH999999", mapped_language = "CH002130", prodrank = 1, payrank = 1, distinct_pyrcnt = 1,
      date_of_death = Timestamp.valueOf("2017-11-17 00:00:00"), contract_id = "CMS", at_risk_status = "Y", cust_mem_attr1 = "WA", subscriberid = "123", subscriberflag = "Y", coverage_status = "MED", emp_acct_id = "BCBS", contracttype = "c", benefitplan = "b", coverageclasscode = "code1"),
    temp_bpo_insurance(groupid = "H000000", grp_mpi = "g1", dob = "20100816", mapped_gender = "CH000034", healthplansource = "PAYER", employeraccountid = "BCBS", member_start = Timestamp.valueOf("2016-09-01 00:00:00"), member_end = Timestamp.valueOf("2016-09-30 00:00:00"), productcode = "MDE", pcpid = "21", pharmacy = "N", product_source = "PA", lineofbusinessid = 1, mapped_race = "CH999999", mapped_ethnicity = "CH999999", mapped_language = "CH002130", prodrank = 1, payrank = 1, distinct_pyrcnt = 1,
      date_of_death = Timestamp.valueOf("2017-11-17 00:00:00"), contract_id = "CMS", at_risk_status = "Y", cust_mem_attr1 = "WA", subscriberid = "123", subscriberflag = "Y", coverage_status = "MED", emp_acct_id = "BCBS", contracttype = "c", benefitplan = "b", coverageclasscode = "code1"),
    //pcpid, employeraccountid changed
    temp_bpo_insurance(groupid = "H000000", grp_mpi = "g1", dob = "20100816", mapped_gender = "CH000034", healthplansource = "PAYER", employeraccountid = "ABC", member_start = Timestamp.valueOf("2016-10-01 00:00:00"), member_end = Timestamp.valueOf("2016-10-31 00:00:00"), productcode = "MDE", pcpid = "22", pharmacy = "N", product_source = "PA", lineofbusinessid = 1, mapped_race = "CH999999", mapped_ethnicity = "CH999999", mapped_language = "CH002130", prodrank = 1, payrank = 1, distinct_pyrcnt = 1,
      date_of_death = Timestamp.valueOf("2017-11-17 00:00:00"), contract_id = "CMS", at_risk_status = "Y", cust_mem_attr1 = "WA", subscriberid = "123", subscriberflag = "Y", coverage_status = "MED", emp_acct_id = "BCBS", contracttype = "c", benefitplan = "b", coverageclasscode = "code1"),
    // went back to the same insure and these 2 records will be combined.
    temp_bpo_insurance(groupid = "H000000", grp_mpi = "g1", dob = "20100816", mapped_gender = "CH000034", healthplansource = "PAYER", employeraccountid = "BCBS", member_start = Timestamp.valueOf("2016-11-01 00:00:00"), member_end = Timestamp.valueOf("2016-11-30 00:00:00"), productcode = "MDE", pcpid = "21", pharmacy = "N", product_source = "PA", lineofbusinessid = 1, mapped_race = "CH999999", mapped_ethnicity = "CH999999", mapped_language = "CH002130", prodrank = 1, payrank = 1, distinct_pyrcnt = 1,
      date_of_death = Timestamp.valueOf("2017-11-17 00:00:00"), contract_id = "CMS", at_risk_status = "Y", cust_mem_attr1 = "WA", subscriberid = "123", subscriberflag = "Y", coverage_status = "MED", emp_acct_id = "BCBS", contracttype = "c", benefitplan = "b", coverageclasscode = "code1"),
    temp_bpo_insurance(groupid = "H000000", grp_mpi = "g1", dob = "20100816", mapped_gender = "CH000034", healthplansource = "PAYER", employeraccountid = "BCBS", member_start = Timestamp.valueOf("2016-12-01 00:00:00"), member_end = Timestamp.valueOf("2016-12-31 00:00:00"), productcode = "MDE", pcpid = "21", pharmacy = "N", product_source = "PA", lineofbusinessid = 1, mapped_race = "CH999999", mapped_ethnicity = "CH999999", mapped_language = "CH002130", prodrank = 1, payrank = 1, distinct_pyrcnt = 1,
      date_of_death = Timestamp.valueOf("2017-11-17 00:00:00"), contract_id = "CMS", at_risk_status = "Y", cust_mem_attr1 = "WA", subscriberid = "123", subscriberflag = "Y", coverage_status = "MED", emp_acct_id = "BCBS", contracttype = "c", benefitplan = "b", coverageclasscode = "code1"),

    temp_bpo_insurance(groupid = "H000000", grp_mpi = "g2", dob = "20100816", mapped_gender = "CH000034", healthplansource = "PAYER", employeraccountid = "BCBS", member_start = Timestamp.valueOf("2016-08-01 00:00:00"), member_end = Timestamp.valueOf("2016-08-31 00:00:00"), productcode = "MDE", pcpid = "21", pharmacy = "N", product_source = "PA", lineofbusinessid = 1, mapped_race = "CH999999", mapped_ethnicity = "CH999999", mapped_language = "CH002130", prodrank = 1, payrank = 1, distinct_pyrcnt = 1,
      date_of_death = Timestamp.valueOf("2017-11-17 00:00:00"), contract_id = "CMS", at_risk_status = "Y", cust_mem_attr1 = "WA", subscriberid = "123", subscriberflag = "Y", coverage_status = "MED", emp_acct_id = "BCBS", contracttype = "x", benefitplan = "p", coverageclasscode = "code1")
  )

  val mapEmployer: DataFrame = mkDataFrame(
    zo_bpo_map_employer(groupid = "H000000", client_ds_id = 10, employeraccountid = "BCBS")
  )

  val patientSummary:DataFrame = mkDataFrame(
    patient_summary(client_ds_id = 1, dob = "19390330", first_name = "BRUCE", groupid = "H000000", grp_mpi= "g1"),
    patient_summary(client_ds_id = 3, dob = "19390330", first_name = "BRUCE", groupid = "H000000", grp_mpi= "g1")
  )


  val params: DataFrame =  mkDataFrame(
    temp_bpo_calculate_params(engineStartDate = Date.valueOf("2015-04-01"), engineStartDate2 = Date.valueOf("2015-04-01"), engineStartDate3 = Date.valueOf("2015-04-01"), engineEndDate = Date.valueOf("2019-03-31"), startDate = Date.valueOf("2015-01-01"))
  )

  val expectedOutput: Seq[pp_bpo_member_detail] = Seq(

    pp_bpo_member_detail(groupid = "H000000", memberid = "g1", effectivedate = Timestamp.valueOf("2016-07-01 00:00:00"), enddate = Timestamp.valueOf("2016-09-30 00:00:00"), dob = Timestamp.valueOf("2010-08-16 00:00:00"), gender = "M", pcpid = "21", pharmacy = "N", productcode = "MDE", subscriberid = "123", healthplansource = "PAYER", employeraccountid = "BCBS",
      medical = "Y", mentalhealth = "Y", coverageclasscode = "code1", subscriberflag ="Y", mapsource = "*", lineofbusinessid = 1, race = 9, race_datasrc = "29", ethnicity = 19, ethnicity_datasrc = "99", spoken_language = "31", spoken_language_datasrc ="49", dental_benefit ="Y", mh_inpatient_benefit = "Y", mh_intensive_benefit = "Y", mh_outpatient_benefit = "Y", cd_inpatient_benefit = "Y",
      cd_intensive_benefit = "Y", cd_outpatient_benefit = "Y", hospice_benefit = "N", date_of_death = Timestamp.valueOf("2017-11-17 00:00:00"), deceased_flag = "Y", ecds_flag = "Y", primary_coverage_flag = "Y", mcoid = "H000000", contract_id = "CMS", at_risk_status = "Y", cust_mem_attr1 = "WA", coveragestatus = "MED", emp_acct_id = "BCBS", contracttype = "c", benefitplan = "b", hra_ind = 0, hsa_ind = 0),

    pp_bpo_member_detail(groupid = "H000000", memberid = "g1", effectivedate = Timestamp.valueOf("2016-10-01 00:00:00"), enddate = Timestamp.valueOf("2016-10-31 00:00:00"), dob = Timestamp.valueOf("2010-08-16 00:00:00"), gender = "M", pcpid = "22", pharmacy = "N", productcode = "MDE", subscriberid = "123", healthplansource = "PAYER", employeraccountid = "ABC",
      medical = "Y", mentalhealth = "Y", coverageclasscode = "code1", subscriberflag ="Y", mapsource = "*", lineofbusinessid = 1, race = 9, race_datasrc = "29", ethnicity = 19, ethnicity_datasrc = "99", spoken_language = "31", spoken_language_datasrc ="49", dental_benefit ="Y", mh_inpatient_benefit = "Y", mh_intensive_benefit = "Y", mh_outpatient_benefit = "Y", cd_inpatient_benefit = "Y",
      cd_intensive_benefit = "Y", cd_outpatient_benefit = "Y", hospice_benefit = "N", date_of_death = Timestamp.valueOf("2017-11-17 00:00:00"), deceased_flag = "Y", ecds_flag = "Y", primary_coverage_flag = "Y", mcoid = "H000000", contract_id = "CMS", at_risk_status = "Y", cust_mem_attr1 = "WA", coveragestatus = "MED", emp_acct_id = "BCBS", contracttype = "c", benefitplan = "b", hra_ind = 0, hsa_ind = 0),

    pp_bpo_member_detail(groupid = "H000000", memberid = "g1", effectivedate = Timestamp.valueOf("2016-11-01 00:00:00"), enddate = Timestamp.valueOf("2016-12-31 00:00:00"), dob = Timestamp.valueOf("2010-08-16 00:00:00"), gender = "M", pcpid = "21", pharmacy = "N", productcode = "MDE", subscriberid = "123", healthplansource = "PAYER", employeraccountid = "BCBS",
      medical = "Y", mentalhealth = "Y", coverageclasscode = "code1", subscriberflag ="Y", mapsource = "*", lineofbusinessid = 1, race = 9, race_datasrc = "29", ethnicity = 19, ethnicity_datasrc = "99", spoken_language = "31", spoken_language_datasrc ="49", dental_benefit ="Y", mh_inpatient_benefit = "Y", mh_intensive_benefit = "Y", mh_outpatient_benefit = "Y", cd_inpatient_benefit = "Y",
      cd_intensive_benefit = "Y", cd_outpatient_benefit = "Y", hospice_benefit = "N", date_of_death = Timestamp.valueOf("2017-11-17 00:00:00"), deceased_flag = "Y", ecds_flag = "Y", primary_coverage_flag = "Y", mcoid = "H000000", contract_id = "CMS", at_risk_status = "Y", cust_mem_attr1 = "WA", coveragestatus = "MED", emp_acct_id = "BCBS", contracttype = "c", benefitplan = "b", hra_ind = 0, hsa_ind = 0),

    pp_bpo_member_detail(groupid = "H000000", memberid = "g2", effectivedate = Timestamp.valueOf("2016-08-01 00:00:00"), enddate = Timestamp.valueOf("2016-08-31 00:00:00"), dob = Timestamp.valueOf("2010-08-16 00:00:00"), gender = "M", pcpid = "21", pharmacy = "N", productcode = "MDE", subscriberid = "123", healthplansource = "PAYER", employeraccountid = "BCBS",
      medical = "Y", mentalhealth = "Y", coverageclasscode = "code1", subscriberflag ="Y", mapsource = "*", lineofbusinessid = 1, race = 9, race_datasrc = "29", ethnicity = 19, ethnicity_datasrc = "99", spoken_language = "31", spoken_language_datasrc ="49", dental_benefit ="Y", mh_inpatient_benefit = "Y", mh_intensive_benefit = "Y", mh_outpatient_benefit = "Y", cd_inpatient_benefit = "Y",
      cd_intensive_benefit = "Y", cd_outpatient_benefit = "Y", hospice_benefit = "N", date_of_death = Timestamp.valueOf("2017-11-17 00:00:00"), deceased_flag = "Y", ecds_flag = "N", primary_coverage_flag = "Y", mcoid = "H000000", contract_id = "CMS", at_risk_status = "Y", cust_mem_attr1 = "WA", coveragestatus = "MED", emp_acct_id = "BCBS", contracttype = "x", benefitplan = "p", hra_ind = 0, hsa_ind = 0)

  )

  testQuery(
    testName = "test PP_BPO_MEMBER_DETAIL",
    query = PP_BPO_MEMBER_DETAIL,
    inputs = Map(
      "TEMP_BPO_INSURANCE" -> tempBpoInsurance,
      "PATIENT_SUMMARY" -> patientSummary,
      "ZO_BPO_MAP_EMPLOYER" -> mapEmployer,
      "TEMP_BPO_CALCULATE_PARAMS" -> params
    ),
    expectedOutput = expectedOutput
  )

}
