package com.optum.oap.backend.etl.bpo.bpo_pyr_hedis_qme

import com.optum.oap.backend.BEQueryTestFramework
import com.optum.oap.backend.cdrTempModel.{hedis_monthly_mbr_extract_qme}
import com.optum.oap.cdr.models.pp_bpo_member_detail
import org.apache.spark.sql.DataFrame

class HEDIS_MONTHLY_MBR_EXTRACT_QME_Test extends BEQueryTestFramework{

  import spark.implicits._


  val ppBpoMemberDetail : DataFrame = mkDataFrame(
    pp_bpo_member_detail(memberid = "m1", groupid = "H000000", employeraccountid = "employer account id 1", healthplansource = "PAYER", lineofbusinessid = 1, enddate = java.sql.Timestamp.valueOf("2020-01-31 00:00:00"), effectivedate = java.sql.Timestamp.valueOf("2020-01-31 00:00:00"), dob = java.sql.Timestamp.valueOf("2020-02-20 00:00:00"), city = "city 1", gender = "gender1", firstname = "firstname1", lastname = "lastname1", address1 = "address1", address2 = "address2", state = "state1", zipcode = "zipcode1" ),
    pp_bpo_member_detail(memberid = "m2", groupid = "H000000", employeraccountid = "employer account id 2", healthplansource = "PAYER", lineofbusinessid = 1, enddate = java.sql.Timestamp.valueOf("2020-02-20 00:00:00"), effectivedate = java.sql.Timestamp.valueOf("2020-03-30 00:00:00"), dob = java.sql.Timestamp.valueOf("2020-01-30 00:00:00"), city = "city 2", gender = "gender1", firstname = "firstname1", lastname = "lastname1", address1 = "address1", address2 = "address2", state = "state1", zipcode = "zipcode1" ),
    pp_bpo_member_detail(memberid = "m3", groupid = "H000000", employeraccountid = "employer account id 3", healthplansource = "PAYER", lineofbusinessid = 1, enddate = java.sql.Timestamp.valueOf("2020-03-20 00:00:00"), effectivedate = java.sql.Timestamp.valueOf("2020-02-20 00:00:00"), dob = java.sql.Timestamp.valueOf("2020-03-20 00:00:00"), city = "city 3", gender = "gender1", firstname = "firstname1", lastname = "lastname1", address1 = "address1", address2 = "address2", state = "state1", zipcode = "zipcode1" ),
    pp_bpo_member_detail(memberid = "m4", groupid = "H000000", employeraccountid = "employer account id 4", healthplansource = "PAYER", lineofbusinessid = 1, enddate = java.sql.Timestamp.valueOf("2020-01-20 00:00:00"), effectivedate = java.sql.Timestamp.valueOf("2020-01-20 00:00:00"), dob = java.sql.Timestamp.valueOf("2020-02-20 00:00:00"), city = "city 4", gender = "gender1", firstname = "firstname1", lastname = "lastname1", address1 = "address1", address2 = "address2", state = "state1", zipcode = "zipcode1" ),
    pp_bpo_member_detail(memberid = "m5", groupid = "H000000", employeraccountid = "employer account id 4", healthplansource = "PAYER", lineofbusinessid = 1, enddate = java.sql.Timestamp.valueOf("2020-04-20 00:00:00"), effectivedate = java.sql.Timestamp.valueOf("2020-04-20 00:00:00"), dob = java.sql.Timestamp.valueOf("2020-03-20 00:00:00"), city = "city 5", gender = "gender1", firstname = "firstname1", lastname = "lastname1", address1 = "address1", address2 = "address2", state = "state1", zipcode = "zipcode1" ),
    pp_bpo_member_detail(memberid = "m6", groupid = "H000000", employeraccountid = "employer account id 3", healthplansource = "NOT PAYER", lineofbusinessid = 1, enddate = java.sql.Timestamp.valueOf("2020-05-20 00:00:00"))
  )

  val expectedOutput: Seq[hedis_monthly_mbr_extract_qme] = Seq(
    hedis_monthly_mbr_extract_qme(MemberID = "m1" , DateofBirth = "2020-02-20" , City = "city 1", GenderCode = "gender1", FirstName = "firstname1" , LastName = "lastname1", AddressLine1 = "address1", AddressLine2 = "address2", StateCode = "state1", ZipCode = "zipcode1"),
    hedis_monthly_mbr_extract_qme(MemberID = "m2" , DateofBirth = "2020-01-30" , City = "city 2", GenderCode = "gender1", FirstName = "firstname1" , LastName = "lastname1", AddressLine1 = "address1", AddressLine2 = "address2", StateCode = "state1", ZipCode = "zipcode1"),
    hedis_monthly_mbr_extract_qme(MemberID = "m3" , DateofBirth = "2020-03-20" , City = "city 3", GenderCode = "gender1", FirstName = "firstname1" , LastName = "lastname1", AddressLine1 = "address1", AddressLine2 = "address2", StateCode = "state1", ZipCode = "zipcode1"),
    hedis_monthly_mbr_extract_qme(MemberID = "m4" , DateofBirth = "2020-02-20" , City = "city 4", GenderCode = "gender1", FirstName = "firstname1" , LastName = "lastname1", AddressLine1 = "address1", AddressLine2 = "address2", StateCode = "state1", ZipCode = "zipcode1"),
    hedis_monthly_mbr_extract_qme(MemberID = "m5" , DateofBirth = "2020-03-20" , City = "city 5", GenderCode = "gender1", FirstName = "firstname1" , LastName = "lastname1", AddressLine1 = "address1", AddressLine2 = "address2", StateCode = "state1", ZipCode = "zipcode1")
  )

  testQuery(
    testName = "test HEDIS_MONTHLY_MBR_EXTRACT_QME",
    query = HEDIS_MONTHLY_MBR_EXTRACT_QME,
    inputs = Map(
      "PP_BPO_MEMBER_DETAIL" -> ppBpoMemberDetail
    ),
    expectedOutput = expectedOutput
  )

}
