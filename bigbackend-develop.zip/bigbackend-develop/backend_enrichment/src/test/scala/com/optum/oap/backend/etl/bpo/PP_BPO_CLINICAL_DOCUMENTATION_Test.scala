package com.optum.oap.backend.etl.bpo

import java.sql.{Date, Timestamp}

import com.optum.oap.backend.BEQueryTestFramework
import com.optum.oap.backend.cdrTempModel.{temp_bpo_calculate_params, temp_bpo_patients}
import com.optum.oap.cdr.models._
import org.apache.spark.sql.DataFrame

class PP_BPO_CLINICAL_DOCUMENTATION_Test extends BEQueryTestFramework {

  import spark.implicits._

  val tempBpoPatients: DataFrame = mkDataFrame(
    temp_bpo_patients(groupid = "group 1", grp_mpi = "member 1", payer = 1),
    temp_bpo_patients(groupid = "group 1", grp_mpi = "member 2", payer = 2),
    //following record will be ignored as only 1 payer will be considered per member per group
    temp_bpo_patients(groupid = "group 1", grp_mpi = "member 1", payer = 0)
  )

  val observations: DataFrame = mkDataFrame(
    observation(groupid = "group 1", client_ds_id = 123, grp_mpi = "member 1", obsdate = Timestamp.valueOf("2016-07-06 07:57:00"), obstype = "CH002805", obsresult = "1"),
    observation(groupid = "group 1", client_ds_id = 234, grp_mpi = "member 1", obsdate = Timestamp.valueOf("2017-04-01 01:45:00"), obstype = "CH001846", obsresult = "10"),
    observation(groupid = "group 1", client_ds_id = 456, grp_mpi = "member 2", obsdate = Timestamp.valueOf("2016-05-02 03:30:00"), obstype = "CH002998", obsresult = "20"),
    observation(groupid = "group 1", client_ds_id = 789, grp_mpi = "member 2", obsdate = Timestamp.valueOf("2016-01-06 03:30:00"), obstype = "CH001999", obsresult = "30"),
    //following record gets filtered because obsdate is outside extract start and end dates
    observation(groupid = "group 1", client_ds_id = 789, grp_mpi = "member 2", obsdate = Timestamp.valueOf("2015-01-06 03:30:00"), obstype = "CH001999", obsresult = "30")
  )

  val tempParamsIn: DataFrame = mkDataFrame(
    temp_bpo_calculate_params(engineStartDate = Date.valueOf("2015-04-01"), engineStartDate2 = Date.valueOf("2015-04-01"), engineStartDate3 = Date.valueOf("2015-04-01"), engineEndDate = Date.valueOf("2019-03-31"), startDate = Date.valueOf("2015-01-01"))
  )

  val expectedOutput: Seq[pp_bpo_clinical_documentation] = Seq(
    pp_bpo_clinical_documentation(groupid = "group 1", memberid = "member 1", clinical_document_id = "CLD123.1", code_taxonomy = "LOINC", code = "73831-0", documentation_date = Timestamp.valueOf("2016-07-06 07:57:00"), result = "1", phq9_version = "M", healthplansource = "PAYER"),
    pp_bpo_clinical_documentation(groupid = "group 1", memberid = "member 1", clinical_document_id = "CLD234.2", code_taxonomy = "LOINC", code = "44261-6", documentation_date = Timestamp.valueOf("2017-04-01 01:45:00"), result = "10", phq9_version = "9", healthplansource = "PAYER"),
    pp_bpo_clinical_documentation(groupid = "group 1", memberid = "member 2", clinical_document_id = "CLD789.4", code_taxonomy = "LOINC", code = "55758-7", documentation_date = Timestamp.valueOf("2016-01-06 03:30:00"), result = null, phq9_version = "9", healthplansource = "PROVIDER"),
    pp_bpo_clinical_documentation(groupid = "group 1", memberid = "member 2", clinical_document_id = "CLD456.3", code_taxonomy = "LOINC", code = "44261-6", documentation_date = Timestamp.valueOf("2016-05-02 03:30:00"), result = "20", phq9_version = "9", healthplansource = "PROVIDER")
  )

  testQuery(
    testName = "test PP_BPO_CLINICAL_DOCUMENTATION",
    query = PP_BPO_CLINICAL_DOCUMENTATION,
    inputs = Map(
      "TEMP_BPO_PATIENTS" -> tempBpoPatients,
      "OBSERVATION" -> observations,
      "TEMP_BPO_CALCULATE_PARAMS" -> tempParamsIn
    ),
    expectedOutput = expectedOutput
  )

}
