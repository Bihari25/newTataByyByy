package com.optum.oap.backend.etl.bpo.bpo_pyr_hedis_qme

import com.optum.oap.backend.BEQueryTestFramework
import com.optum.oap.backend.cdrTempModel.hedis_monthly_med_extract_qme
import com.optum.oap.cdr.models.{denied_ind_rollup, pp_bpo_medical_claims, pp_bpo_member_detail}
import org.apache.spark.sql.DataFrame

class HEDIS_MONTHLY_MED_EXTRACT_QME_Test extends BEQueryTestFramework{

  import spark.implicits._


  val ppBpoMemberDetail : DataFrame = mkDataFrame(
    pp_bpo_member_detail(memberid = "m1", groupid = "H000000", employeraccountid = "employer account id 1", healthplansource = "PAYER", lineofbusinessid = 1, enddate = java.sql.Timestamp.valueOf("2020-01-31 00:00:00"), effectivedate = java.sql.Timestamp.valueOf("2020-01-31 00:00:00"), dob = java.sql.Timestamp.valueOf("2020-02-20 00:00:00"), city = "city 1", gender = "gender1", firstname = "firstname1", lastname = "lastname1", address1 = "address1", address2 = "address2", state = "state1", zipcode = "zipcode1" ),
    pp_bpo_member_detail(memberid = "m2", groupid = "H000000", employeraccountid = "employer account id 2", healthplansource = "PAYER", lineofbusinessid = 1, enddate = java.sql.Timestamp.valueOf("2020-02-20 00:00:00"), effectivedate = java.sql.Timestamp.valueOf("2020-03-30 00:00:00"), dob = java.sql.Timestamp.valueOf("2020-01-30 00:00:00"), city = "city 2", gender = "gender1", firstname = "firstname1", lastname = "lastname1", address1 = "address1", address2 = "address2", state = "state1", zipcode = "zipcode1" ),
    pp_bpo_member_detail(memberid = "m3", groupid = "H000000", employeraccountid = "employer account id 3", healthplansource = "PAYER", lineofbusinessid = 1, enddate = java.sql.Timestamp.valueOf("2020-03-20 00:00:00"), effectivedate = java.sql.Timestamp.valueOf("2020-02-20 00:00:00"), dob = java.sql.Timestamp.valueOf("2020-03-20 00:00:00"), city = "city 3", gender = "gender1", firstname = "firstname1", lastname = "lastname1", address1 = "address1", address2 = "address2", state = "state1", zipcode = "zipcode1" ),
    pp_bpo_member_detail(memberid = "m4", groupid = "H000000", employeraccountid = "employer account id 4", healthplansource = "PAYER", lineofbusinessid = 1, enddate = java.sql.Timestamp.valueOf("2020-01-20 00:00:00"), effectivedate = java.sql.Timestamp.valueOf("2020-01-20 00:00:00"), dob = java.sql.Timestamp.valueOf("2020-02-20 00:00:00"), city = "city 4", gender = "gender1", firstname = "firstname1", lastname = "lastname1", address1 = "address1", address2 = "address2", state = "state1", zipcode = "zipcode1" ),
    pp_bpo_member_detail(memberid = "m5", groupid = "H000000", employeraccountid = "employer account id 4", healthplansource = "PAYER", lineofbusinessid = 1, enddate = java.sql.Timestamp.valueOf("2020-04-20 00:00:00"), effectivedate = java.sql.Timestamp.valueOf("2020-04-20 00:00:00"), dob = java.sql.Timestamp.valueOf("2020-03-20 00:00:00"), city = "city 5", gender = "gender1", firstname = "firstname1", lastname = "lastname1", address1 = "address1", address2 = "address2", state = "state1", zipcode = "zipcode1" ),
    pp_bpo_member_detail(memberid = "m6", groupid = "H000000", employeraccountid = "employer account id 3", healthplansource = "NOT PAYER", lineofbusinessid = 1, enddate = java.sql.Timestamp.valueOf("2020-05-20 00:00:00"))
  )

  val ppBpoMedicalClaims : DataFrame = mkDataFrame(
    pp_bpo_medical_claims(groupid = "H000000", memberid = "m1", healthplansource = "PAYER", servicedate = java.sql.Timestamp.valueOf("2019-06-06 00:00:00"), poa = "poa"),
    pp_bpo_medical_claims(groupid = "H000000", memberid = "m2", healthplansource = "PAYER", servicedate = java.sql.Timestamp.valueOf("2020-07-07 00:00:00")),
    pp_bpo_medical_claims(groupid = "H000000", memberid = "m3", healthplansource = "PAYER", servicedate = java.sql.Timestamp.valueOf("2020-07-07 00:00:00"))
  )

  val deniedIndRollup: DataFrame = mkDataFrame(
    denied_ind_rollup(groupid = "H000000", denied_flag = "Y", denied_ind_rollup = "Y"),
    denied_ind_rollup(groupid = "H000000", denied_flag = "N", denied_ind_rollup = "N")
  )

  val expectedOutput: Seq[hedis_monthly_med_extract_qme] = Seq(
    hedis_monthly_med_extract_qme(MemberID = "m1", ServiceDate = "2019-06-06", HealthPlanSource = "PAYER" ,  IsDenied = "N"),
    hedis_monthly_med_extract_qme(MemberID = "m2", ServiceDate = "2020-07-07", HealthPlanSource = "PAYER" ,  IsDenied = "N"),
    hedis_monthly_med_extract_qme(MemberID = "m3", ServiceDate = "2020-07-07", HealthPlanSource = "PAYER" ,  IsDenied = "N")

  )

  testQuery(
    testName = "test HEDIS_MONTHLY_MED_EXTRACT_QME",
    query = HEDIS_MONTHLY_MED_EXTRACT_QME,
    inputs = Map(
      "PP_BPO_MEMBER_DETAIL" -> ppBpoMemberDetail,
      "PP_BPO_MEDICAL_CLAIMS" -> ppBpoMedicalClaims,
      "DENIED_IND_ROLLUP" -> deniedIndRollup
    ),
    expectedOutput = expectedOutput
  )

}
