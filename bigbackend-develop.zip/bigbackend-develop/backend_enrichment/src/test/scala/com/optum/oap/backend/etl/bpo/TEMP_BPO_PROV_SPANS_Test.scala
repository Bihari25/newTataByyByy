package com.optum.oap.backend.etl.bpo

import com.optum.oap.backend.BEQueryTestFramework
import com.optum.oap.cdr.models.{map_predicate_values, map_provider_taxonomy, map_specialty, map_specialty_ii, pp_bpo_member_detail, prov_client_rel, ref_primaryspecialty, zh_provider, zh_provider_master, zh_provider_master_xref, zo_bpo_map_employer, zo_specialty}
import org.apache.spark.sql.DataFrame
import org.junit.runner.RunWith
import com.optum.oap.sparkdataloader.{RuntimeVariables, TableInfo, UserDefinedFunctionForDataLoader}
import com.optum.oap.backend.loader.EnrichmentRunTimeVariables
import java.sql.Timestamp

import com.optum.oap.backend.cdrTempModel.{temp_bpo_prov_affil_spans, temp_bpo_prov_attr_spans, temp_bpo_prov_client_rel_spans, temp_bpo_prov_spans, temp_bpo_provider_detail}
import org.scalatest.junit.JUnitRunner

@RunWith(classOf[JUnitRunner])
class TEMP_BPO_PROV_SPANS_Test extends BEQueryTestFramework {

  import spark.implicits._

  val grpid = "grpid"

  val ppBpoMemberDetail : DataFrame = mkDataFrame(
    pp_bpo_member_detail(healthplansource = "PAYER", effectivedate = java.sql.Timestamp.valueOf("2019-06-15 00:00:00"), enddate = java.sql.Timestamp.valueOf("2019-08-18 00:00:00")),
    pp_bpo_member_detail(healthplansource = "PAYER", effectivedate = java.sql.Timestamp.valueOf("2019-06-13 00:00:00"), enddate = java.sql.Timestamp.valueOf("2019-07-20 00:00:00")),
    pp_bpo_member_detail(healthplansource = "health plan source 1", effectivedate = java.sql.Timestamp.valueOf("2019-06-18 00:00:00"), enddate = java.sql.Timestamp.valueOf("2019-07-11 00:00:00"))
  )

  val tempBpoProvAffilSpans : DataFrame = mkDataFrame(
    temp_bpo_prov_affil_spans(master_hgprovid = "123", start_date = java.sql.Timestamp.valueOf("2019-06-13 00:00:00"), end_date = java.sql.Timestamp.valueOf("2019-07-13 00:00:00"), provaffiliationid = "provaffiliation id 1"),
    temp_bpo_prov_affil_spans(master_hgprovid = "234", start_date = java.sql.Timestamp.valueOf("2019-07-13 00:00:00"), end_date = java.sql.Timestamp.valueOf("2019-08-13 00:00:00"), provaffiliationid = "provaffiliation id 1")
  )

  val tempBpoProvAttrSpans : DataFrame = mkDataFrame(
    temp_bpo_prov_attr_spans(master_hgprovid = "234", start_date = java.sql.Timestamp.valueOf("2019-08-22 00:00:00"), end_date = java.sql.Timestamp.valueOf("2019-06-12 00:00:00"), cust_prov_attr1 = "cust prov attr 1",cust_prov_attr2 = "cust prov attr 2" ,cust_prov_attr3 = "cust prov attr 3", cust_prov_attr4 = "cust prov attr 4", cust_prov_attr5 = "cust prov attr 5", cust_prov_attr6 = "cust prov attr 6", cust_prov_attr7 = "cust prov attr 7", cust_prov_attr8 = "cust prov attr 8", cust_prov_attr9 = "cust prov attr 9", cust_prov_attr10 = "cust prov attr 10", cust_prov_attr11 = "cust prov attr 11", cust_prov_attr12 = "cust prov attr 12", cust_prov_attr13 = "cust prov attr 13", cust_prov_attr14 = "cust prov attr 14", cust_prov_attr15 = "cust prov attr 15", cust_prov_attr16 = 3.14, cust_prov_attr17 = 3.14, cust_prov_attr18 = 3.14, cust_prov_attr19 = 3.14, cust_prov_attr20 = 3.14, prov_userdef_1 = "prov user def 1", prov_userdef_2 = "prov user def 2")
  )

  val tempBpoProvClientRelSpans : DataFrame = mkDataFrame(
    temp_bpo_prov_client_rel_spans(master_hgprovid = "123", start_date = java.sql.Timestamp.valueOf("2019-04-12 00:00:00"), end_date = java.sql.Timestamp.valueOf("2019-05-10 00:00:00"), provider_status = "provider status 1")
  )

  val tempBpoProviderDetail : DataFrame = mkDataFrame(
    temp_bpo_provider_detail(groupid = "group id 1", npi = "npi 1", providerid = "123", providername = "provider, name 1", providerfirstname = "name 1", providerlastname = "provider", specialty = "specialty 1", secondaryspecialty = "secondary specialty 1", providertype = "provider type 1", pcpflag = "N", healthplansource = "health plan source 1", mapsource = "*"),
    temp_bpo_provider_detail(groupid = "group id 2", npi = "npi 2", providerid = "234", providername = "provider, name 2", providerfirstname = "name 2", providerlastname = "provider", specialty = "specialty 2", secondaryspecialty = "secondary specialty 2", providertype = "provider type 2", pcpflag = "Y", healthplansource = "health plan source 2", mapsource = "*")
  )

  val expectedOutput : Seq[temp_bpo_prov_spans] = Seq(
    temp_bpo_prov_spans(groupid = grpid, master_hgprovid = "123", prov_effective_dt = java.sql.Timestamp.valueOf("2019-04-12 00:00:00"), prov_end_dt = java.sql.Timestamp.valueOf("2019-05-31 00:00:00"),provider_status = "provider status 1"),
    temp_bpo_prov_spans(groupid = grpid, master_hgprovid = "123", prov_effective_dt = java.sql.Timestamp.valueOf("2019-06-13 00:00:00"), prov_end_dt = java.sql.Timestamp.valueOf("2019-07-13 00:00:00"),provaffiliationid = "provaffiliation id 1"),
    temp_bpo_prov_spans(groupid = grpid, master_hgprovid = "123", prov_effective_dt = java.sql.Timestamp.valueOf("2019-07-14 00:00:00"), prov_end_dt = java.sql.Timestamp.valueOf("2019-08-31 00:00:00")),
    temp_bpo_prov_spans(groupid = grpid, master_hgprovid = "234", prov_effective_dt = java.sql.Timestamp.valueOf("2019-07-13 00:00:00"), prov_end_dt = java.sql.Timestamp.valueOf("2019-07-31 00:00:00"),provaffiliationid = "provaffiliation id 1"),
    temp_bpo_prov_spans(groupid = grpid, master_hgprovid = "234", prov_effective_dt = java.sql.Timestamp.valueOf("2019-08-14 00:00:00"), prov_end_dt = java.sql.Timestamp.valueOf("2019-08-31 00:00:00"), cust_prov_attr1 = "cust prov attr 1",cust_prov_attr2 = "cust prov attr 2" ,cust_prov_attr3 = "cust prov attr 3", cust_prov_attr4 = "cust prov attr 4", cust_prov_attr5 = "cust prov attr 5", cust_prov_attr6 = "cust prov attr 6", cust_prov_attr7 = "cust prov attr 7", cust_prov_attr8 = "cust prov attr 8", cust_prov_attr9 = "cust prov attr 9", cust_prov_attr10 = "cust prov attr 10", cust_prov_attr11 = "cust prov attr 11", cust_prov_attr12 = "cust prov attr 12", cust_prov_attr13 = "cust prov attr 13", cust_prov_attr14 = "cust prov attr 14", cust_prov_attr15 = "cust prov attr 15", cust_prov_attr16 = 3.14, cust_prov_attr17 = 3.14, cust_prov_attr18 = 3.14, cust_prov_attr19 = 3.14, cust_prov_attr20 = 3.14, prov_userdef_1 = "prov user def 1", prov_userdef_2 = "prov user def 2"),
    temp_bpo_prov_spans(groupid = grpid, master_hgprovid = "234", prov_effective_dt = java.sql.Timestamp.valueOf("2019-08-22 00:00:00"), prov_end_dt = java.sql.Timestamp.valueOf("2019-08-13 00:00:00"), provaffiliationid = "provaffiliation id 1")
  )

  val runTimeVariables = EnrichmentRunTimeVariables(clientId = grpid, environment = "env", cdrCycle = "cdr cycle", cdrLevel = "cdr level", cdrSchema = "cdr schema", instance = "instance", release = "release", buildType = "buildType", fullHiveDb = "ecdr").asInstanceOf[RuntimeVariables]
  testQuery(
    testName = "test TEMP_BPO_PROV_SPANS",
    query = TEMP_BPO_PROV_SPANS,
    inputs = Map(
      "PP_BPO_MEMBER_DETAIL" -> ppBpoMemberDetail,
      "TEMP_BPO_PROV_AFFIL_SPANS" -> tempBpoProvAffilSpans,
      "TEMP_BPO_PROV_ATTR_SPANS" -> tempBpoProvAttrSpans,
      "TEMP_BPO_PROV_CLIENT_REL_SPANS" -> tempBpoProvClientRelSpans,
      "TEMP_BPO_PROVIDER_DETAIL" -> tempBpoProviderDetail
    ),
    expectedOutput = expectedOutput,
    mapRuntimeVariables = runTimeVariables
  )

  val expectedOutput1 : Seq[temp_bpo_prov_spans] = Seq(
    temp_bpo_prov_spans(groupid = "H623", master_hgprovid = "6690", prov_effective_dt = java.sql.Timestamp.valueOf("2016-01-01 00:00:00"), prov_end_dt = java.sql.Timestamp.valueOf("2019-12-31 00:00:00"),provider_status = "D28U0N80U2", provaffiliationid = "D28U0N80U2"),
    temp_bpo_prov_spans(groupid = "H623", master_hgprovid = "6690", prov_effective_dt = java.sql.Timestamp.valueOf("2020-01-01 00:00:00"), prov_end_dt = java.sql.Timestamp.valueOf("2020-03-31 00:00:00"))
  )

  testQuery(
    testName = "test with provaffiliation null",
    query = TEMP_BPO_PROV_SPANS,
    inputs = Map(
      "PP_BPO_MEMBER_DETAIL" -> mkDataFrame(
        pp_bpo_member_detail(healthplansource = "PAYER", effectivedate = java.sql.Timestamp.valueOf("2016-04-01 00:00:00"), enddate = java.sql.Timestamp.valueOf("2020-03-31 00:00:00"))
      ),
      "TEMP_BPO_PROV_AFFIL_SPANS" -> mkDataFrame(
        temp_bpo_prov_affil_spans(master_hgprovid = "6690", start_date = java.sql.Timestamp.valueOf("2016-01-01 00:00:00"), end_date = java.sql.Timestamp.valueOf("2019-12-31 00:00:00"), provaffiliationid = "D28U0N80U2")
      ),
      "TEMP_BPO_PROV_ATTR_SPANS" ->  mkDataFrame(
        temp_bpo_prov_attr_spans(master_hgprovid = "6690", start_date = java.sql.Timestamp.valueOf("2016-01-01 00:00:00"), end_date = java.sql.Timestamp.valueOf("2019-12-31 00:00:00"))
      ),
      "TEMP_BPO_PROV_CLIENT_REL_SPANS" -> mkDataFrame(
        temp_bpo_prov_client_rel_spans(master_hgprovid = "6690", groupid = "H623", start_date = java.sql.Timestamp.valueOf("2016-01-01 00:00:00"), end_date = java.sql.Timestamp.valueOf("2019-12-31 00:00:00"), provider_status = "D28U0N80U2")
      ),
      "TEMP_BPO_PROVIDER_DETAIL" -> mkDataFrame(
        temp_bpo_provider_detail(groupid = "H623", npi = "1689665739", providerid = "6690", providername = "provider, name 1", providerfirstname = "name 1", providerlastname = "provider", specialty = "specialty 1", secondaryspecialty = "secondary specialty 1", providertype = "provider type 1", pcpflag = "Y", healthplansource = "health plan source 1", mapsource = "*")
      )
    ),
    expectedOutput = expectedOutput1,
    mapRuntimeVariables = EnrichmentRunTimeVariables(clientId = "H623", environment = "env", cdrCycle = "cdr cycle", cdrLevel = "cdr level", cdrSchema = "cdr schema", instance = "instance", release = "release", buildType = "buildType", fullHiveDb = "ecdr").asInstanceOf[RuntimeVariables]
  )

  val expectedOutput2 : Seq[temp_bpo_prov_spans] = Seq(
    temp_bpo_prov_spans(groupid = "H623", master_hgprovid = "6691", prov_effective_dt = java.sql.Timestamp.valueOf("2016-04-01 00:00:00"), prov_end_dt = java.sql.Timestamp.valueOf("2018-06-30 00:00:00")),
    temp_bpo_prov_spans(groupid = "H623", master_hgprovid = "6691", prov_effective_dt = java.sql.Timestamp.valueOf("2018-07-01 00:00:00"), prov_end_dt = java.sql.Timestamp.valueOf("2020-01-31 00:00:00"),provider_status = "T3LW0KUON2", provaffiliationid = "T3LW0KUON2"),
    temp_bpo_prov_spans(groupid = "H623", master_hgprovid = "6691", prov_effective_dt = java.sql.Timestamp.valueOf("2020-02-01 00:00:00"), prov_end_dt = java.sql.Timestamp.valueOf("2020-02-29 00:00:00"),provider_status = "T3LW0KUON2", provaffiliationid = "000DWZOK5")
  )

  testQuery(
    testName = "test when one of the affiliation ends the payer end date",
    query = TEMP_BPO_PROV_SPANS,
    inputs = Map(
      "PP_BPO_MEMBER_DETAIL" -> mkDataFrame(
        pp_bpo_member_detail(healthplansource = "PAYER", effectivedate = java.sql.Timestamp.valueOf("2016-04-01 00:00:00"), enddate = java.sql.Timestamp.valueOf("2020-02-29 00:00:00"))
      ),
      "TEMP_BPO_PROV_AFFIL_SPANS" -> mkDataFrame(
        temp_bpo_prov_affil_spans(master_hgprovid = "6691", start_date = java.sql.Timestamp.valueOf("2016-04-01 00:00:00"), end_date = java.sql.Timestamp.valueOf("2018-06-30 00:00:00")),
        temp_bpo_prov_affil_spans(master_hgprovid = "6691", start_date = java.sql.Timestamp.valueOf("2018-07-01 00:00:00"), end_date = java.sql.Timestamp.valueOf("2020-01-31 00:00:00"), provaffiliationid = "T3LW0KUON2"),
        temp_bpo_prov_affil_spans(master_hgprovid = "6691", start_date = java.sql.Timestamp.valueOf("2020-02-01 00:00:00"), end_date = java.sql.Timestamp.valueOf("2020-02-29 00:00:00"), provaffiliationid = "000DWZOK5")
      ),
      "TEMP_BPO_PROV_ATTR_SPANS" ->  mkDataFrame(
        temp_bpo_prov_attr_spans(master_hgprovid = "6691", start_date = java.sql.Timestamp.valueOf("2016-04-01 00:00:00"), end_date = java.sql.Timestamp.valueOf("2018-6-30 00:00:00")),
        temp_bpo_prov_attr_spans(master_hgprovid = "6691", start_date = java.sql.Timestamp.valueOf("2018-07-01 00:00:00"), end_date = java.sql.Timestamp.valueOf("2020-02-29 00:00:00"))
      ),
      "TEMP_BPO_PROV_CLIENT_REL_SPANS" -> mkDataFrame(
        temp_bpo_prov_client_rel_spans(master_hgprovid = "6691", groupid = "H623", start_date = java.sql.Timestamp.valueOf("2016-04-01 00:00:00"), end_date = java.sql.Timestamp.valueOf("2018-06-30 00:00:00")),
        temp_bpo_prov_client_rel_spans(master_hgprovid = "6691", groupid = "H623", start_date = java.sql.Timestamp.valueOf("2018-07-01 00:00:00"), end_date = java.sql.Timestamp.valueOf("2020-02-29 00:00:00"), provider_status = "T3LW0KUON2")
      ),
      "TEMP_BPO_PROVIDER_DETAIL" -> mkDataFrame(
        temp_bpo_provider_detail(groupid = "H623", npi = "1689665739", providerid = "6691", providername = "provider, name 1", providerfirstname = "name 1", providerlastname = "provider", specialty = "specialty 1", secondaryspecialty = "secondary specialty 1", providertype = "provider type 1", pcpflag = "N", healthplansource = "health plan source 1", mapsource = "*")
      )
    ),
    expectedOutput = expectedOutput2,
    mapRuntimeVariables = EnrichmentRunTimeVariables(clientId = "H623", environment = "env", cdrCycle = "cdr cycle", cdrLevel = "cdr level", cdrSchema = "cdr schema", instance = "instance", release = "release", buildType = "buildType", fullHiveDb = "ecdr").asInstanceOf[RuntimeVariables]
  )
}
