package com.optum.oap.backend.etl.common

import com.optum.oap.testutils.TestSparkSession
import org.junit.runner.RunWith
import org.scalatest.FlatSpec
import org.scalatest.junit.JUnitRunner

/**
  * Creator: bishu
  * Date: 11/30/20
  */

@RunWith(classOf[JUnitRunner])
class EnrichmentUtilsTest extends FlatSpec with TestSparkSession {

  behavior of "EnrichmentUtils.getPreviousRelease"
  it should "generate expected previous release given current release" in {
    assert(EnrichmentUtils.getPreviousRelease("202012").get.equals("202011"), "last month")
    assert(EnrichmentUtils.getPreviousRelease("202101").get.equals("202012"), "first month")
    assert(EnrichmentUtils.getPreviousRelease("202006").get.equals("202005"), "normal month")
    assert(EnrichmentUtils.getPreviousRelease("s23455").isEmpty, "invalid release")
    assert(EnrichmentUtils.getPreviousRelease("20201212").isEmpty, "non 6 digit")
    assert(EnrichmentUtils.getPreviousRelease("202104", -1).get.equals("202103"))
    assert(EnrichmentUtils.getPreviousRelease("202104", -2).get.equals("202102"))
  }
}

