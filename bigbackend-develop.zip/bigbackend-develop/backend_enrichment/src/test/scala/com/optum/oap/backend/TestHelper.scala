package com.optum.oap.backend

import com.optum.oap.backend.cdrTempModel.monthly_payer_elg_ii

object TestHelper {

  def main(args: Array[String]): Unit = {
    generateCaseClassInstanceWithDummyData()
  }

  /**
    * Replace the pp_bpo_provider_detail_spans case class with the case class you are interested in.
    * Extend the match class to cover missing datatype
    * Run the main method. Copy the generated case class value from console.
    */
  private def generateCaseClassInstanceWithDummyData(): Unit = {
    val limitColumns = Set("memberid",
      "effectivedate",
      "enddate",
      "dob",
      "gender",
      "firstname",
      "lastname",
      "address1",
      "address2",
      "city",
      "state",
      "zipcode",
      "phone",
      "email",
      "pcpid",
      "pharmacy",
      "medical",
      "healthplansource",
      "healthplanname",
      "coverageclasscode",
      "employeraccountid",
      "productcode",
      "contracttype",
      "benefitplan",
      "coveragestatus",
      "subscriberid",
      "subscriberflag",
      "lineofbusinessid").map(_.toLowerCase)
    val aa = classOf[monthly_payer_elg_ii].getDeclaredFields.filter(f => limitColumns.contains(f.getName.toLowerCase)).toList.withFilter(!_.isSynthetic())

    val r = new scala.util.Random() // replace seed value if you would like to generate consistent output
    val data = aa.map(f => {
      f.getType.toString match {
        case "class java.lang.String" => s"""${f.getName} = \"${f.getName.take(r.nextInt(f.getName.length))}${r.nextInt(10)}\""""
        case "class java.lang.Double" => s"${f.getName} = ${r.nextDouble().formatted("%.2f")}"
        case "class java.sql.Timestamp" => s"""${f.getName} = java.sql.Timestamp.valueOf(\"2020-01-31 00:00:00\")"""
        case "class java.lang.Integer" => s"${f.getName} = ${r.nextInt(20)}"
      }
    }).mkString(", ")

    println(s"monthly_payer_elg_ii($data)")

  }
}
