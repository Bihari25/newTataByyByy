package com.optum.oap.backend.etl.bpo

import com.optum.oap.backend.BEQueryTestFramework
import com.optum.oap.backend.loader.EnrichmentRunTimeVariables
import com.optum.oap.sparkdataloader.{EmptyRuntimeVariables, RuntimeVariables}
import org.junit.runner.RunWith
import org.scalatest.Matchers._
import org.scalatest.junit.JUnitRunner

@RunWith(classOf[JUnitRunner])
class IMAP_MS_DRG_Test extends BEQueryTestFramework {

  val runTimeVariables: RuntimeVariables = EnrichmentRunTimeVariables(clientId = "H000000", environment = "env", cdrCycle = "cdr cycle", cdrLevel = "cdr level", cdrSchema = "cdr schema", instance = "instance", release = "release", buildType = "Monthly", fullHiveDb = "ecdr").asInstanceOf[RuntimeVariables]

  it should "Test IMAP_MS_DRG" in {
    val df = IMAP_MS_DRG.createDataFrame(
      spark,
      Map.empty,
      udfsMap,
      runTimeVariables
    )

    val firstRec = df.first()

    firstRec.get(0) shouldBe "001"
    firstRec.get(1) shouldBe "Heart Transplant or Implant of Heart Assist System with MCC"
    df.first().get(2) shouldBe "99"
    df.first().get(3) shouldBe "SRG"
    df.first().get(4) shouldBe "MS"
    df.first().get(5) shouldBe ""

    df.collect().length shouldBe 4782
  }
}
