package com.optum.oap.backend.etl.bpo

import com.optum.oap.backend.BEQueryTestFramework
import com.optum.oap.cdr.models._
import org.apache.spark.sql.DataFrame

/**
  *
  * Copyright 2019 Optum Analytics
  *
  * Date: 5/20/19
  *
  * Creator: bpokharel(bishu)
  */
class PP_BPO_PATIENT_XWALK_Test extends BEQueryTestFramework {

  behavior of "translated query PP_BPO_PATIENT_XWALK"

  import spark.implicits._

  val patinet_mpi_IN: DataFrame = mkDataFrame(
    patient_mpi(groupid = "H000000", client_ds_id = 1, patientid = "P1", grp_mpi = "G001", hgpid = 100L),
    patient_mpi(groupid = "H000000", client_ds_id = 1, patientid = "P2", grp_mpi = "G002", hgpid = 200L),
    patient_mpi(groupid = "H000000", client_ds_id = 2, patientid = "P3", grp_mpi = "G003", hgpid = 300L),
    patient_mpi(groupid = "H000000", client_ds_id = 3, patientid = "P4", grp_mpi = "G004", hgpid = 400L)
  )

  val zo_bpo_map_employer_IN: DataFrame = mkDataFrame(
    zo_bpo_map_employer(groupid = "H000000", client_ds_id = 1, employeraccountid = "BCBS"),
    zo_bpo_map_employer(groupid = "H000000", client_ds_id = 2, employeraccountid = "CEE")
  )

  val bpo_patient_xwlk_OUT: Seq[pp_bpo_patient_xwalk] = Seq(
    pp_bpo_patient_xwalk(groupid = "H000000", client_ds_id = 1, patientid = "P1", grp_mpi = "G001", o1_plan_source = "BCBS"),
    pp_bpo_patient_xwalk(groupid = "H000000", client_ds_id = 1, patientid = "P2", grp_mpi = "G002", o1_plan_source = "BCBS"),
    pp_bpo_patient_xwalk(groupid = "H000000", client_ds_id = 2, patientid = "P3", grp_mpi = "G003", o1_plan_source = "CEE")
  )

  testQuery(
    testName = "test PP_BPO_PATIENT_XWALK",
    query = PP_BPO_PATIENT_XWALK,
    inputs = Map(
      "PATIENT_MPI" -> patinet_mpi_IN,
      "ZO_BPO_MAP_EMPLOYER" -> zo_bpo_map_employer_IN
    ),
    expectedOutput = bpo_patient_xwlk_OUT
  )
}
