package com.optum.oap.backend.etl.cdrfe

import com.optum.oap.cdr.models.{allergy, insurance}
import com.optum.oap.sparkdataloader.{RuntimeVariables, TableInfo, UserDefinedFunctionForDataLoader}
import org.apache.spark.sql.{DataFrame, SparkSession}

/**
  * This is a dummy CDRFE entity trait used in the CDRFE_Entity unit test.
  * This trait is used to test the scenario wherein we would like to extend the
  * default behaviour of [[com.optum.oap.backend.etl.cdrfe.CDRFE_ENTITY]] class
  */
trait DummyEntity {
  self: TableInfo[_ <: Product] =>

  override val dependsOn: Set[String] = Set("INSURANCE")

  override def createDF(sparkSession: SparkSession,
                        loadedDependencies: Map[String, DataFrame],
                        udfMap: Map[String, UserDefinedFunctionForDataLoader],
                        runtimeVariables: RuntimeVariables): DataFrame = {
    import sparkSession.implicits._
    implicit val spark = sparkSession

    val insurance = loadedDependencies("INSURANCE").as[insurance]

    val dataframe = self.createDataFrame(sparkSession, loadedDependencies, udfMap, runtimeVariables)
    val sourceDf = self.dataframe(allergy(client_ds_id = 100, groupid = "H704847", grp_mpi = "P3"),
      allergy(client_ds_id = 100, groupid = "H000166", grp_mpi = "P3"))
    val processedDf = sourceDf.as("s")
      .join(insurance.as("i"), $"s.groupid" === $"i.groupid")
      .select($"s.*")
    dataframe.unionByName(processedDf)
  }
}
