package com.optum.oap.backend.etl.bpo

import java.sql.Timestamp

import com.optum.oap.backend.BEQueryTestFramework
import com.optum.oap.cdr.models.{rxorder, zo_bpo_map_employer, _}
import org.apache.spark.sql.DataFrame
import org.joda.time.{DateTime, DateTimeUtils}

/**
  *
  * Copyright 2019 Optum Analytics
  *
  * Date: 5/13/19
  *
  * Creator: pavula1
  */
class CLAIM_MEMBER_MONTHS_Test extends BEQueryTestFramework {

  import spark.implicits._

  val claimIn: DataFrame = mkDataFrame(

    //The below 2 records are for the same patient within the same year, month service date so the paidamount will be combined.
    claim(groupid = "H000000", client_ds_id = 1, patientid = "P1", grp_mpi = "grp1", paidamount = 100.0, servicedate = Timestamp.valueOf("1988-08-04 12:00:00"), mappedcpt = "D1234"),
    claim(groupid = "H000000", client_ds_id = 1, patientid = "P1", grp_mpi = "grp1", paidamount = 200.0, servicedate = Timestamp.valueOf("1988-08-15 12:00:00"), mappedhcpcs = "D1234"),
    claim(groupid = "H000000", client_ds_id = 1, patientid = "P1", grp_mpi = "grp1", paidamount = 300.0, servicedate = Timestamp.valueOf("1988-08-24 12:00:00"), mappedcpt = "CPT1234", mappedhcpcs = "HCPCS1"),
    //When Service date is null
    claim(groupid = "H000000", client_ds_id = 1, patientid = "P2", grp_mpi = "grp2", paidamount = 500.0, servicedate = null),
    //When Service date and rxorder.issuedate are different(month or year)
    claim(groupid = "H000000", client_ds_id = 1, patientid = "P3", grp_mpi = "grp3", paidamount = 15.14922, servicedate = Timestamp.valueOf("2012-09-04 12:00:00"), mappedcpt = "CPT1234"),
    claim(groupid = "H000000", client_ds_id = 1, patientid = "P3", grp_mpi = "grp3", paidamount = 10.0, servicedate = Timestamp.valueOf("2012-09-15 12:00:00"), mappedcpt = "D2345", mappedhcpcs = "HCPS")
  )
  val zo_bpo_map_employerIn: DataFrame = mkDataFrame(
    zo_bpo_map_employer(groupid = "H000000", client_ds_id = 1, employeraccountid = "BCBS")

  )
  val rxorderIn: DataFrame = mkDataFrame(
    rxorder(groupid = "H000000", client_ds_id = 1, patientid = "P1", grp_mpi = "grp1", paidamount = 200.0, issuedate = Timestamp.valueOf("1988-08-04 12:00:00")),
    rxorder(groupid = "H000000", client_ds_id = 1, patientid = "P1", grp_mpi = "grp1", paidamount = 400.0, issuedate = Timestamp.valueOf("1988-08-25 12:00:00")),
    //This record has issue date where as claim.servicedate is null for the same patinet so this patient will have 2 records in the cliam_member_months table.
    rxorder(groupid = "H000000", client_ds_id = 1, patientid = "P2", grp_mpi = "grp2", paidamount = 300.0, issuedate = Timestamp.valueOf("2001-10-04 12:00:00")),
    rxorder(groupid = "H000000", client_ds_id = 1, patientid = "P3", grp_mpi = "grp3", paidamount = 50.126, issuedate = Timestamp.valueOf("2012-10-04 12:00:00"))
  )

  DateTimeUtils.setCurrentMillisFixed(10000)

  val expectedOutput: Seq[claim_member_months] = Seq(
    claim_member_months(groupid = "H000000", client_ds_id = 1, grp_mpi = "grp1", claims_year = 1988, claims_month = 8, claim_paid_amount = 600.0, rx_paid_amount = 600.0, claim_count = 3, rx_count = 2, product_code = "BCBS", effective_date = Timestamp.valueOf("1988-08-01 00:00:00"), db_create_dt_tm = new Timestamp(DateTime.now().getMillis), dental_count = 2),

    claim_member_months(groupid = "H000000", client_ds_id = 1, grp_mpi = "grp2", claims_year = 1900, claims_month = 1, claim_paid_amount = 500.0, rx_paid_amount = 0.0, claim_count = 1, rx_count = 0, product_code = "BCBS", effective_date = Timestamp.valueOf("1900-01-01 00:00:00"), db_create_dt_tm = new Timestamp(DateTime.now().getMillis), dental_count = 0),
    claim_member_months(groupid = "H000000", client_ds_id = 1, grp_mpi = "grp2", claims_year = 2001, claims_month = 10, claim_paid_amount = 0.0, rx_paid_amount = 300.0, claim_count = 0, rx_count = 1, product_code = "BCBS", effective_date = Timestamp.valueOf("2001-10-01 00:00:00"), db_create_dt_tm = new Timestamp(DateTime.now().getMillis), dental_count = 0),

    claim_member_months(groupid = "H000000", client_ds_id = 1, grp_mpi = "grp3", claims_year = 2012, claims_month = 9, claim_paid_amount = 25.15, rx_paid_amount = 0.0, claim_count = 2, rx_count = 0, product_code = "BCBS", effective_date = Timestamp.valueOf("2012-09-01 00:00:00"), db_create_dt_tm = new Timestamp(DateTime.now().getMillis), dental_count = 1),
    claim_member_months(groupid = "H000000", client_ds_id = 1, grp_mpi = "grp3", claims_year = 2012, claims_month = 10, claim_paid_amount = 0.0, rx_paid_amount = 50.13, claim_count = 0, rx_count = 1, product_code = "BCBS", effective_date = Timestamp.valueOf("2012-10-01 00:00:00"), db_create_dt_tm = new Timestamp(DateTime.now().getMillis), dental_count = 0)

  )

  testQuery(
    testName = "test CLAIM_MEMBER_MONTHS",
    query = CLAIM_MEMBER_MONTHS,
    inputs = Map(
      "CLAIM" -> claimIn,
      "ZO_BPO_MAP_EMPLOYER" -> zo_bpo_map_employerIn,
      "RXORDER" -> rxorderIn
    ),
    expectedOutput = expectedOutput
  )

}
