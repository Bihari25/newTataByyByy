package com.optum.oap.backend.etl.bpo.bpo_pyr_sre

import com.optum.oap.backend.BEQueryTestFramework
import com.optum.oap.backend.cdrTempModel.monthly_payer_phm_sre
import com.optum.oap.cdr.models.{pp_bpo_member_detail, pp_bpo_pharmacy_claims}
import org.apache.spark.sql.DataFrame

class MONTHLY_PAYER_PHM_SRE_EXTRACT_TEST extends BEQueryTestFramework {

  import spark.implicits._

  val originalSQL =
    """
      |SELECT
      |    rx.memberid
      |,   date_format  (paymentdate,'yyyy-MM-dd')
      |                                AS paymentdate
      |,   date_format  (servicedate,'yyyy-MM-dd')
      |                                AS servicedate
      |,   pharmacyid
      |,   pharmacyname
      |,   pharmacytype
      |,   ndc
      |,   genericstatus
      |,   dayssupply
      |,   quantity
      |,   formulary
      |,   allowedamount
      |,   requestedamount
      |,   paidamount
      |,   copayamount
      |,   coinsamount
      |,   deductamount
      |,   patliabamount
      |,   ingredientcost
      |,   dispensingfee
      |,   rx.healthplansource
      |,   rx.coverageclasscode
      |,   'N' as deniedflag
      |,   deniedreason
      |,   pseudoflag
      |,   networkstatus
      |,   claimsource
      |,   claimheader
      |,   prescprovider
      |,   dea
      |,   rx.mapsource
      |,   quantity_dispensed
      |,   supply_flag
      |,  cast(null as string) as Unique_Rec_ID
      |,  cast(null as string) as Code_Type
      |,  cast(null as string) as Diagnosis_Code
      |,  cast(null as string) as POS
      |,  cast(null as string) as Prov_Type_Code
      |,  cast(null as string) as Prov_Specialty_Code
      |,  cast(null as string) as Prov_NPI
      |,  cast(null as string) as Pharmacy_NPI
      |FROM
      |    pp_bpo_pharmacy_claims rx
      |INNER JOIN
      |    pp_bpo_member_detail elig
      |    ON
      |    (   elig.groupid=rx.groupid
      |    AND elig.memberid = rx.memberid
      |    AND elig.healthplansource = rx.healthplansource
      |    )
      |WHERE
      |    rx.healthplansource='PAYER'
      |AND
      |    rx.servicedate BETWEEN elig.effectivedate AND elig.enddate
    """.stripMargin

  val ppBpoMemberDetail: DataFrame = mkDataFrame(
    pp_bpo_member_detail(groupid = "H000000", memberid = "m1", healthplansource = "PAYER", effectivedate = java.sql.Timestamp.valueOf("2014-01-01 00:00:00"), enddate = java.sql.Timestamp.valueOf("2029-04-30 00:00:00")),
    pp_bpo_member_detail(groupid = "H000000", memberid = "m2", healthplansource = "PAYER1", effectivedate = java.sql.Timestamp.valueOf("2019-06-18 00:00:00"), enddate = java.sql.Timestamp.valueOf("2019-07-11 00:00:00"))
  )

  val ppBpoPharmacyClaims: DataFrame = mkDataFrame(
    pp_bpo_pharmacy_claims(groupid = "H000000", memberid = "m1", paidamount = 12.21, healthplansource = "PAYER", servicedate = java.sql.Timestamp.valueOf("2020-01-01 00:00:00")),
    pp_bpo_pharmacy_claims(groupid = "H000000", memberid = "m2", healthplansource = "PAYER1", servicedate = java.sql.Timestamp.valueOf("2018-01-01 00:00:00")),
    pp_bpo_pharmacy_claims(groupid = "H000000", memberid = "m3", healthplansource = "PAYER2", servicedate = java.sql.Timestamp.valueOf("2013-01-01 00:00:00"))
  )

  val expectedOutput: Seq[monthly_payer_phm_sre] = Seq(
    monthly_payer_phm_sre(memberid = "m1", servicedate = "2020-01-01", paidamount = "12.21", deniedflag = "N", healthplansource = "PAYER")
  )

  testQuery(
    testName = "test MONTHLY_PAYER_PHM_SRE_EXTRACT",
    query = MONTHLY_PAYER_PHM_SRE_EXTRACT,
    inputs = Map(
      "PP_BPO_MEMBER_DETAIL" -> ppBpoMemberDetail,
      "PP_BPO_PHARMACY_CLAIMS" -> ppBpoPharmacyClaims
    ),
    expectedOutput = expectedOutput
  )

  it should "output of new etl should match with original Spark SQL etl" in {
    ppBpoMemberDetail.createOrReplaceTempView("pp_bpo_member_detail")
    ppBpoPharmacyClaims.createOrReplaceTempView("pp_bpo_pharmacy_claims")

    val originalOutput = spark.sql(originalSQL)

    checkThatDataFramesAreEqual(originalOutput, expectedOutput)
  }

}
