package com.optum.oap.backend.etl.bpo

import java.sql.{Date, Timestamp}

import com.optum.oap.backend.BEQueryTestFramework
import com.optum.oap.backend.cdrTempModel._
import com.optum.oap.cdr.models.{map_patient_type, _}
import org.apache.spark.sql.DataFrame

/**
  *
  * Copyright 2019 Optum Analytics
  *
  * Date: 6/3/19
  *
  * Creator: bpokharel(bishu)
  */
class PP_BPO_MEDICAL_CLAIMS_Test extends BEQueryTestFramework {

  import spark.implicits._


  val temp_bpo_claim_IN: DataFrame = mkDataFrame(
    temp_bpo_claim(groupid = "H000000", cust_attr_1="attr1", amt_oth2=200.00, amt_oth3=300.00, amt_oth4=400.00, amt_oth1=100.00, claim_prov_status_id="c1", prov_svc_ii_spec=1, admitsourcecui="CH11", encounterid = "1", client_ds_id = 1, grp_mpi = "101", sourceid = "s1", servicedate = Timestamp.valueOf("2016-07-06 11:11:11"), patienttype = "CH000106", disposition = "CH000106", revenuecode = "r1", localdrggrouper = "CH001334", localdrg = "004", min_svc_date = Timestamp.valueOf("2016-07-06 10:10:10"), max_svc_date = Timestamp.valueOf("2016-07-07 11:11:11"), claim_mstrprovid = "1", refer_prov_id = "refer prov id 1", inp_admit_type = "inp admit type 1"),
    temp_bpo_claim(groupid = "H000000", encounterid = "1", cust_attr_16=16.00, cust_attr_17=17.00, cust_attr_18=18.00, cust_attr_19=19.00, claim_prov_status_id="c1", provider_status="p1", client_ds_id = 1, grp_mpi = "102", sourceid = "s1", servicedate = Timestamp.valueOf("2016-07-06 11:11:11"), patienttype = "CH000110", disposition = "CH000106", localdrggrouper = "CH001334", localdrg = "004", pos = "102", min_svc_date = Timestamp.valueOf("2016-07-06 10:10:10"), max_svc_date = Timestamp.valueOf("2016-07-07 11:11:11"), refer_prov_id = "refer prov id 2", inp_admit_type = "inp admit type 2"
    )
  )

  val temp_bpo_diagnosis_IN: DataFrame = mkDataFrame(
    temp_bpo_diagnosis(groupid = "H000000", grp_mpi = "101", encounterid = "1", sourceid = "s1", client_ds_id = 1, record_preference = 1, codetype = "ICD10", icddiag1poa = "d1", icddiag1 = "diag1"),
    temp_bpo_diagnosis(groupid = "H000000", grp_mpi = "102", encounterid = "1", sourceid = "s1", client_ds_id = 1, record_preference = 1, codetype = "ICD10", icddiag1poa = "d1", icddiag1 = "diag1")

  )

  val temp_bpo_procedure_IN: DataFrame = mkDataFrame(
    temp_bpo_procedure(groupid = "H000000", encounterid = "1", client_ds_id = 1, grp_mpi = "101", servicedate = Timestamp.valueOf("2016-07-06 11:11:11"), sourceid = "s1", codetype = "ICD10")
  )

  val zo_place_of_service_IN: DataFrame = mkDataFrame(
    zo_place_of_service(hts_cui = "CH000106", ii_code = "11")
  )

  val zo_discharge_disposition_IN: DataFrame = mkDataFrame(
    zo_discharge_disposition(hts_cui = "CH000106", ii_code = "11")
  )

  val zo_bpo_map_employer_IN: DataFrame = mkDataFrame(
    zo_bpo_map_employer(groupid = "H000000", dts_version = 1, client_ds_id = 1, employeraccountid = "e1")
  )

  val pp_bpo_provider_detail_IN: DataFrame = mkDataFrame(
    pp_bpo_provider_detail(groupid = "H000000", providerid = "1", specialty = "123")
  )

  val zo_admit_source_IN: DataFrame = mkDataFrame(
    zo_admit_source(cui="CH11", as_code="t")
  )

  val temp_pp_bpo_custom_procedure_IN: DataFrame = Seq.empty[pp_bpo_medical_claims].toDF()

  val pp_bpo_medical_claims_OUT: Seq[pp_bpo_medical_claims] = Seq(
    pp_bpo_medical_claims(groupid = "H000000", amt_oth1=100.00, amt_oth2=200.00, amt_oth3=300.00, amt_oth4=400.00, memberid = "101", cust_med_attr1="attr1", admitsource="t", provider_status="c1", servicedate = Timestamp.valueOf("2016-07-06 11:11:11"), specialty = "1", providertype = "1", serviceproviderid = "1", placeofservice = "11", poa = "d1", poa_2 = "U", poa_3 = "U", poa_4 = "U", poa_5 = "U", poa_6 = "U", poa_7 = "U", poa_8 = "U", poa_9 = "U", poa_10 = "U", poa_11 = "U", poa_12 = "U", poa_13 = "U", claimheader = "MED1.1", claimline = "1", networkstatus = "N", mapsource = "AD", provider_key = "1", tos = null, coverageclasscode = "MED", healthplansource = "PAYER", fromdate = Timestamp.valueOf("2016-07-06 10:10:10"), todate = Timestamp.valueOf("2016-07-07 11:11:11"), icddiag1 = "diag1", drg = "004", drggrouper = "MS", dischargestatus = "11", contract_id = "e1", employeraccountid = "e1", revenuecode = "r1", icdcodetype = "10",  refer_prov_id = "refer prov id 1", inp_admit_type = "inp admit type 1"),
    pp_bpo_medical_claims(groupid = "H000000", cust_med_attr16=16.00, cust_med_attr17=17.00, cust_med_attr18=18.00, cust_med_attr19=19.00, provider_status="c1", memberid = "102", servicedate = Timestamp.valueOf("2016-07-06 11:11:11"), serviceproviderid = "0", specialty = "999", providertype = "999", placeofservice = "102", poa = "d1", poa_2 = "U", poa_3 = "U", poa_4 = "U", poa_5 = "U", poa_6 = "U", poa_7 = "U", poa_8 = "U", poa_9 = "U", poa_10 = "U", poa_11 = "U", poa_12 = "U", poa_13 = "U", claimheader = "MED1.2", claimline = "1", networkstatus = "N", mapsource = "AD", provider_key = "0", tos = "1", coverageclasscode = "MED", healthplansource = "PAYER", fromdate = Timestamp.valueOf("2016-07-06 10:10:10"), todate = Timestamp.valueOf("2016-07-07 11:11:11"), icddiag1 = "diag1", drg = "004", drggrouper = "MS", dischargestatus = "11", contract_id = "e1", employeraccountid = "e1", icdcodetype = "10", refer_prov_id = "refer prov id 2", inp_admit_type = "inp admit type 2"
    )
  )

  val temp_bpo_calculate_params_IN: DataFrame = mkDataFrame(
    temp_bpo_calculate_params(engineStartDate = Date.valueOf("2015-04-01"), engineStartDate2 = Date.valueOf("2015-04-01"), engineStartDate3 = Date.valueOf("2015-04-01"), engineEndDate = Date.valueOf("2019-03-31"), startDate = Date.valueOf("2015-01-01"))
  )

  val proceduredo_IN: DataFrame = mkDataFrame(
    proceduredo(actualprocdate = Timestamp.valueOf("2018-01-01 12:00:00.0"), client_ds_id = 3141, codetype = "CUSTOM", datasrc = "encountervisit", encounterid = "9A22F0D625164490", facilityid = "test", groupid = "H000000", grp_mpi = "cus1", hgpid = 1L, hosp_px_flag = "test", localbillingproviderid = "test", localcode = "test", localname = "test", localprincipleindicator = "test", mappedcode = "custom", orderingproviderid = "test", orig_codetype = "test", orig_mappedcode = "test", patientid = "test", performing_mstrprovid = "1", performingproviderid = "test", proc_end_date = Timestamp.valueOf("2018-01-01 12:00:00.0"), procedurecodesourcetable = "test", proceduredate = Timestamp.valueOf("2018-01-01 12:00:00.0"), procseq = 1, referproviderid = "test", sourceid = "test")
  )

  val temp_bpo_patients_IN: DataFrame = mkDataFrame(
    temp_bpo_patients(groupid = "H000000", grp_mpi = "cus1", payer = 1),
    temp_bpo_patients(groupid = "H000000", grp_mpi = "cus1", payer = 2),
    temp_bpo_patients(groupid = "H000000", grp_mpi = "cus1", payer = 1)
  )

  val clinicalencounter_IN: DataFrame = mkDataFrame(
    clinicalencounter(groupid = "H000000", client_ds_id = 3141, patientid = "P1", encounterid = "9A22F0D625164490", grp_mpi = "cus1", localpatienttype = "I", localdrg = "Encounter", facilityid = "CLINIC 3195376142"),
    clinicalencounter(groupid = "H000000", client_ds_id = 3141, patientid = "P2", encounterid = "9A22F0D625164490", grp_mpi = "cus1", localpatienttype = "POS.MED",localdrg = "Encounter", facilityid = "CLINIC 1975343153")
  )

  val map_patient_type_IN: DataFrame = mkDataFrame(
    map_patient_type(cui = "CH000106", description = "Inpatient", dts_version = 0, groupid = "H000000", local_code = "I"),
    map_patient_type(cui = "CH003038", description = "Orders Only", dts_version = 0, groupid = "H000000", local_code = "e3141.111"),
    map_patient_type(cui = "CH003034", description = "Telephone", dts_version = 0, groupid = "H000000", local_code = "e3141.70"),
    map_patient_type(cui = "CH000924", description = "", dts_version = 0, groupid = "H000000", local_code = "e3141.50"),
    map_patient_type(cui = "CH000937", description = "Ancillary Orders", dts_version = 0, groupid = "H000000", local_code = "e3141.117"),
    map_patient_type(cui = "CH000937", description = "", dts_version = 0, groupid = "H000000", local_code = "e3141.109"),
    map_patient_type(cui = "CH000110", description = "Office", dts_version = 0, groupid = "H000000", local_code = "POS.11"),
    map_patient_type(cui = "CH000939", description = "Pharmacy", dts_version = 0, groupid = "H000000", local_code = "POS.MED")
  )

  val ref_custom_proc_mapped_values_IN = mkDataFrame(
    ref_custom_proc_mapped_values(description = "Inpatient", mappedvalue = "custom", preferred_proc_cd = "custom", preferred_proc_codetype = "I")
  )

  val pp_bpo_medical_claims_cus_OUT: Seq[pp_bpo_medical_claims] = Seq(
    pp_bpo_medical_claims(groupid = "H000000", memberid = "cus1", paymentdate = Timestamp.valueOf("2018-01-01 00:00:00"), servicedate = Timestamp.valueOf("2018-01-01 00:00:00"), serviceproviderid = "1", specialty = "123", providertype = "123", placeofservice = "11", poa = "U", poa_2 = "U", poa_3 = "U", poa_4 = "U", poa_5 = "U", poa_6 = "U", poa_7 = "U", poa_8 = "U", poa_9 = "U", poa_10 = "U", poa_11 = "U", poa_12 = "U", poa_13 = "U", claimheader = "CUS3141.2", claimline = "1", networkstatus = "Y", mapsource = "SS", provider_key = "1", tos = null, coverageclasscode = "MED", healthplansource = "PROVIDER", fromdate = Timestamp.valueOf("2018-01-01 00:00:00"), todate = Timestamp.valueOf("2018-01-01 00:00:00"), icdcodetype = "10", quantity = 1, deniedflag = "N", pseudoflag = "N", denied_ind = "N"),
    pp_bpo_medical_claims(groupid = "H000000", memberid = "cus1", paymentdate = Timestamp.valueOf("2018-01-01 00:00:00"), servicedate = Timestamp.valueOf("2018-01-01 00:00:00"), serviceproviderid = "1", specialty = "123", providertype = "123", placeofservice = "99", poa = "U", poa_2 = "U", poa_3 = "U", poa_4 = "U", poa_5 = "U", poa_6 = "U", poa_7 = "U", poa_8 = "U", poa_9 = "U", poa_10 = "U", poa_11 = "U", poa_12 = "U", poa_13 = "U", claimheader = "CUS3141.1", claimline = "1", networkstatus = "Y", mapsource = "SS", provider_key = "1", tos = null, coverageclasscode = "MED", healthplansource = "PROVIDER", fromdate = Timestamp.valueOf("2018-01-01 00:00:00"), todate = Timestamp.valueOf("2018-01-01 00:00:00"), icdcodetype = "10", quantity = 1, deniedflag = "N", pseudoflag = "N", denied_ind = "N")
  )

  testQuery(
    testName = "test PP_BPO_MEDICAL_CLAIMS",
    query = PP_BPO_MEDICAL_CLAIMS,
    inputs = Map(
      "TEMP_BPO_CLAIM" -> temp_bpo_claim_IN,
      "TEMP_BPO_DIAGNOSIS" -> temp_bpo_diagnosis_IN,
      "TEMP_BPO_PROCEDURE" -> temp_bpo_procedure_IN,
      "ZO_PLACE_OF_SERVICE" -> zo_place_of_service_IN,
      "ZO_DISCHARGE_DISPOSITION" -> zo_discharge_disposition_IN,
      "ZO_BPO_MAP_EMPLOYER" -> zo_bpo_map_employer_IN,
      "TEMP_PP_BPO_PROVIDER_DETAIL" -> pp_bpo_provider_detail_IN,
      "ZO_ADMIT_SOURCE" -> zo_admit_source_IN,
      "TEMP_BPO_CALCULATE_PARAMS" -> temp_bpo_calculate_params_IN,
      "PROCEDUREDO" -> proceduredo_IN,
      "TEMP_BPO_PATIENTS" -> temp_bpo_patients_IN,
      "CLINICALENCOUNTER" -> clinicalencounter_IN,
      "MAP_PATIENT_TYPE" -> map_patient_type_IN,
      "REF_CUSTOM_PROC_MAPPED_VALUES" -> ref_custom_proc_mapped_values_IN
    ),
    expectedOutput = pp_bpo_medical_claims_OUT ++ pp_bpo_medical_claims_cus_OUT
  )
}
