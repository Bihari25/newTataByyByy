package com.optum.oap.backend

import com.optum.oap.backend.etl.common.OADefinedFunctionsRegistry
import com.optum.oap.backend.util.{ResourceConverter, ResourceInput}
import com.optum.oap.sparkdataloader.{EmptyRuntimeVariables, RuntimeVariables, TableInfo, UserDefinedFunctionForDataLoader}
import com.optum.oap.testutils.TestSparkSession
import org.apache.spark.SparkConf
import org.apache.spark.sql.{DataFrame, SparkSession}
import org.scalatest.FlatSpec
import org.scalatest.Matchers._


abstract class HiveSQLTestFramework extends FlatSpec with TestSparkSession {

  val conf = new SparkConf()
  conf.set("spark.broadcast.compress", "false")
  conf.set("spark.shuffle.compress", "false")
  conf.set("spark.shuffle.spill.compress", "false")
  conf.set("spark.io.compression.codec", "lzf")
  val spark: SparkSession = SparkSession.builder
    .config(conf)
    .enableHiveSupport()
    .getOrCreate()


  val udfsMap: Map[String, UserDefinedFunctionForDataLoader] = OADefinedFunctionsRegistry.getUdfsMap(spark)

  /**
    *
    * @param testName       name of the unit test
    * @param query          reference to the QueryAndMetadata object to test
    * @param inputs         Map of table name to a DataFrame containing the data
    * @param expectedOutput Seq of a case class that represents the required output
    */
  def testQuery(testName: String, query: TableInfo[_ <: Product], inputs: Map[String, DataFrame], expectedOutput: DataFrame, runtimeVariables: RuntimeVariables = EmptyRuntimeVariables()): Unit = {
    it should testName in {
      inputs.keys.toSeq.sorted should contain theSameElementsAs query.dependsOn

      val resultDF = query.runTableETL(sparkSession, inputs, udfsMap, runtimeVariables)

      val convertedResultSet = resultDF.collect().toSeq

      convertedResultSet should contain theSameElementsAs expectedOutput.collect().toSeq
    }
  }


  def hiveTableFromResource(resourceName: String) : DataFrame = {
    val config = this.getClass.getClassLoader.getResource("CDRExternalDataTypeMap.txt").getPath

    ResourceConverter(ResourceInput(resourceName,config,spark)).convert

    val resPath = this.getClass.getClassLoader.getResource(resourceName).getPath
    val tbl = spark.sqlContext.read.format("com.databricks.spark.csv").option("header", "true").option("delimiter", '|').load(resPath)
    tbl.createOrReplaceTempView("test")
    tbl
  }
}