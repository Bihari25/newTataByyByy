package com.optum.oap.backend.etl.common

import com.optum.oap.backend.BEQueryTestFramework
import com.optum.oap.backend.etl.common.ExtractRelativeindicator.extract_relativeindicator
import org.apache.spark.sql.functions.lit
import org.junit.runner.RunWith
import org.scalatest.Matchers._
import org.scalatest.junit.JUnitRunner

@RunWith(classOf[JUnitRunner])
class ExtractRelativeindicatorTest extends BEQueryTestFramework{

  behavior of "extract_relativeindicator udf"

  it should "extract relativeindicator from given string" in {

    val actualOutcome = Seq(

      extract_relativeindicator(lit("<0.3")).expr.eval().toString
      , extract_relativeindicator(lit("thiS UNDER That")).expr.eval().toString
      , extract_relativeindicator(lit("this + that")).expr.eval().toString
      , extract_relativeindicator(lit("thiS GREATERTHAN THat")).expr.eval()

    )

    val expectedOutcome = Seq(

      "<"
      , "<"
      , ">"
      , null

    )

    actualOutcome shouldBe expectedOutcome
  }
}
