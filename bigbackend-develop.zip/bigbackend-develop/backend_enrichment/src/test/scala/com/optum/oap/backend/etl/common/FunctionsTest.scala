package com.optum.oap.backend.etl.common

import com.optum.oap.cdr.models.map_predicate_values
import org.apache.spark.sql.DataFrame
import com.optum.oap.testutils.TestSparkSession
import org.junit.runner.RunWith
import org.scalatest.FlatSpec
import org.scalatest.Matchers._
import org.scalatest.junit.JUnitRunner

@RunWith(classOf[JUnitRunner])
class FunctionsTest extends FlatSpec with TestSparkSession {
  private val spark = sparkSession

  import spark.implicits._

  behavior of "Functions"

  val mpvDf: DataFrame = mkDataFrame(
    map_predicate_values(groupid = "H000000", client_ds_id = 1, data_src = "data1", entity = "E1", table_name
      = "A1", column_name = "name1", column_value = "val1"),
    map_predicate_values(groupid = "H000000", client_ds_id = 1, data_src = "data1", entity = "E1", table_name
      = "A1", column_name = "name1", column_value = "val2"),
    map_predicate_values(groupid = "H000000", client_ds_id = 2, data_src = "data2", entity = "E2", table_name
      = "A2", column_name = "name2", column_value = "val3"),
    map_predicate_values(groupid = "H000000", client_ds_id = 3, data_src = "data2", entity = "E2", table_name
      = "A2", column_name = "name2", column_value = "val4")
  )

  it should "test mpvList" in {
    Functions.mpvList(mpvDf, "H000000", 1, "data1", "E1", "A1", "name1") shouldBe List("'val1'", "'val2'")
    Functions.mpvList(mpvDf, "H000000", null, "data2", "E2", "A2", "name2") shouldBe List("'val3'", "'val4'")
    Functions.mpvList(mpvDf, "H000001", 4, "data4", "E4", "A4", "name4") shouldBe List()
  }

  behavior of "ObsResult.regexParse"
  it should "generate expected result given regex string and value passed in" in {
    assert(Functions.regexParse("[0-9]+",Some("1778")).contains("1778"), "should return whole value")
    assert(Functions.regexParse("^[0-7]{1}\\b",Some("no pain")).isEmpty, "should be None since it doesn't match")
    assert(Functions.regexParse("[^/]*$",Some("100/52")).contains("52"), "should return everything after slash")
    assert(Functions.regexParse("[0-9]{2,3}$",Some("81193.034|2864")).contains("864"), "should return last 3 digits")
    assert(Functions.regexParse("[0-9]{2,3}\\.?[0-9]{0,2}",Some("365")).contains("365"), "should return whole value")
    assert(Functions.regexParse("[0-9]{2,3}\\.?[0-9]{0,2}",Some("365.7")).contains("365.7"), "should return whole value")
    assert(Functions.regexParse("[0-9]{2,3}\\.?[0-9]{0,2}", None).isEmpty, "shouldn't NPE")
  }
}

