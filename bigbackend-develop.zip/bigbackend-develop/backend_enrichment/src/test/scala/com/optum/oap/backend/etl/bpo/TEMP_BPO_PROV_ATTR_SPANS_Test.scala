package com.optum.oap.backend.etl.bpo

import com.optum.oap.backend.BEQueryTestFramework
import com.optum.oap.cdr.models.{map_predicate_values, map_provider_taxonomy, map_specialty, map_specialty_ii, pp_bpo_member_detail, prov_client_rel, ref_primaryspecialty, zh_prov_attribute, zh_provider, zh_provider_master, zh_provider_master_xref, zo_bpo_map_employer, zo_specialty}
import org.apache.spark.sql.DataFrame
import org.junit.runner.RunWith
import java.sql.Timestamp

import com.optum.oap.backend.cdrTempModel.{temp_bpo_prov_affil_spans, temp_bpo_prov_attr_spans, temp_bpo_provider_detail, temp_prov_affil}
import com.optum.oap.backend.loader.EnrichmentRunTimeVariables
import com.optum.oap.sparkdataloader.RuntimeVariables
import org.scalatest.junit.JUnitRunner

@RunWith(classOf[JUnitRunner])
class TEMP_BPO_PROV_ATTR_SPANS_Test extends BEQueryTestFramework {
  import spark.implicits._

  val grpid = "group id"

  val ppBpoMemberDetail : DataFrame = mkDataFrame(
    pp_bpo_member_detail(healthplansource = "PAYER", effectivedate = java.sql.Timestamp.valueOf("2019-06-15 00:00:00"), enddate = java.sql.Timestamp.valueOf("2019-08-18 00:00:00")),
    pp_bpo_member_detail(healthplansource = "PAYER", effectivedate = java.sql.Timestamp.valueOf("2019-06-13 00:00:00"), enddate = java.sql.Timestamp.valueOf("2019-07-20 00:00:00")),
    pp_bpo_member_detail(healthplansource = "health plan source 1", effectivedate = java.sql.Timestamp.valueOf("2019-06-18 00:00:00"), enddate = java.sql.Timestamp.valueOf("2019-07-11 00:00:00"))
  )


  val tempBpoProviderDetail : DataFrame = mkDataFrame(
    temp_bpo_provider_detail(groupid = "group id 1", npi = "npi 1", providerid = "123", providername = "provider name 1", providerfirstname = "name 1", providerlastname = "provider", specialty = "specialty 1"),
    temp_bpo_provider_detail(groupid = "group id 2", npi = "npi 2", providerid = "provider id 2", providername = "provider name 2", providerfirstname = "name 2", providerlastname = "provider", specialty = "specialty 2"),
    temp_bpo_provider_detail(groupid = "group id 2", npi = "npi 3", providerid = "234", providername ="provider name 3", providerfirstname = "name 3",providerlastname = "provider", specialty = "specialty 3"),
    temp_bpo_provider_detail(groupid = "group id 3", npi = "npi 4", providerid = "345", providername = "provider name 4", providerfirstname = "name 4", providerlastname = "provider", specialty = "specialty 4"),
    temp_bpo_provider_detail(groupid = "group id 4", npi = "npi 5", providerid = "567", providername = "provider name 5", providerfirstname = "name 5", providerlastname = "provider", specialty = "specialty 5")
  )

  val tempZhProvAttribute : DataFrame = mkDataFrame(
    zh_prov_attribute(groupid = grpid, client_ds_id = 111, localproviderid = "local provider id 1", master_hgprovid = "123", attribute_type_cui = "CH002486", attribute_value = "1", eff_date = java.sql.Timestamp.valueOf("2019-06-20 00:00:00"), end_date = java.sql.Timestamp.valueOf("2019-08-10 00:00:00")),
    zh_prov_attribute(groupid = grpid, client_ds_id = 222, localproviderid = "local provider id 2", master_hgprovid = "234", attribute_type_cui = "CH002487", attribute_value = "2", eff_date = java.sql.Timestamp.valueOf("2019-05-26 00:00:00"), end_date = java.sql.Timestamp.valueOf("2019-07-15 00:00:00")),
    zh_prov_attribute(groupid = grpid, client_ds_id = 222, localproviderid = "local provider id 3", master_hgprovid = "123", attribute_type_cui = "CH002488", attribute_value = "3", eff_date = java.sql.Timestamp.valueOf("2019-04-22 00:00:00"), end_date = java.sql.Timestamp.valueOf("2019-07-15 00:00:00")),
    zh_prov_attribute(groupid = grpid, client_ds_id = 222, localproviderid = "local provider id 4", master_hgprovid = "234", attribute_type_cui = "CH002489", attribute_value = "4", eff_date = java.sql.Timestamp.valueOf("2019-04-17 00:00:00"), end_date = java.sql.Timestamp.valueOf("2019-07-15 00:00:00")),
    zh_prov_attribute(groupid = grpid, client_ds_id = 222, localproviderid = "local provider id 5", master_hgprovid = "234", attribute_type_cui = "CH002987", attribute_value = "5", eff_date = java.sql.Timestamp.valueOf("2019-05-23 00:00:00"), end_date = java.sql.Timestamp.valueOf("2019-07-15 00:00:00")),
    zh_prov_attribute(groupid = grpid, client_ds_id = 222, localproviderid = "local provider id 6", master_hgprovid = "234", attribute_type_cui = "CH002988", attribute_value = "6", eff_date = java.sql.Timestamp.valueOf("2019-05-26 00:00:00"), end_date = java.sql.Timestamp.valueOf("2019-07-15 00:00:00")),
    zh_prov_attribute(groupid = grpid, client_ds_id = 222, localproviderid = "local provider id 7", master_hgprovid = "234", attribute_type_cui = "CH003906", attribute_value = "7", eff_date = java.sql.Timestamp.valueOf("2019-05-26 00:00:00"), end_date = java.sql.Timestamp.valueOf("2019-07-15 00:00:00")),
    zh_prov_attribute(groupid = grpid, client_ds_id = 222, localproviderid = "local provider id 8", master_hgprovid = "234", attribute_type_cui = "CH003907", attribute_value = "8", eff_date = java.sql.Timestamp.valueOf("2019-05-26 00:00:00"), end_date = java.sql.Timestamp.valueOf("2019-07-15 00:00:00")),
    zh_prov_attribute(groupid = grpid, client_ds_id = 222, localproviderid = "local provider id 9", master_hgprovid = "234", attribute_type_cui = "CH003908", attribute_value = "9", eff_date = java.sql.Timestamp.valueOf("2019-05-26 00:00:00"), end_date = java.sql.Timestamp.valueOf("2019-07-15 00:00:00")),
    zh_prov_attribute(groupid = grpid, client_ds_id = 222, localproviderid = "local provider id 10", master_hgprovid = "234", attribute_type_cui = "CH003909", attribute_value = "10", eff_date = java.sql.Timestamp.valueOf("2019-05-26 00:00:00"), end_date = java.sql.Timestamp.valueOf("2019-07-15 00:00:00")),
    zh_prov_attribute(groupid = grpid, client_ds_id = 222, localproviderid = "local provider id 11", master_hgprovid = "234", attribute_type_cui = "CH003910", attribute_value = "11", eff_date = java.sql.Timestamp.valueOf("2019-05-26 00:00:00"), end_date = java.sql.Timestamp.valueOf("2019-07-15 00:00:00")),
    zh_prov_attribute(groupid = grpid, client_ds_id = 222, localproviderid = "local provider id 12", master_hgprovid = "234", attribute_type_cui = "CH003911", attribute_value = "12", eff_date = java.sql.Timestamp.valueOf("2019-05-26 00:00:00"), end_date = java.sql.Timestamp.valueOf("2019-07-15 00:00:00")),
    zh_prov_attribute(groupid = grpid, client_ds_id = 222, localproviderid = "local provider id 13", master_hgprovid = "234", attribute_type_cui = "CH003912", attribute_value = "13", eff_date = java.sql.Timestamp.valueOf("2019-05-26 00:00:00"), end_date = java.sql.Timestamp.valueOf("2019-07-15 00:00:00")),
    zh_prov_attribute(groupid = grpid, client_ds_id = 222, localproviderid = "local provider id 14", master_hgprovid = "234", attribute_type_cui = "CH003913", attribute_value = "14", eff_date = java.sql.Timestamp.valueOf("2019-05-26 00:00:00"), end_date = java.sql.Timestamp.valueOf("2019-07-15 00:00:00")),
    zh_prov_attribute(groupid = grpid, client_ds_id = 222, localproviderid = "local provider id 15", master_hgprovid = "234", attribute_type_cui = "CH003914", attribute_value = "15", eff_date = java.sql.Timestamp.valueOf("2019-05-26 00:00:00"), end_date = java.sql.Timestamp.valueOf("2019-07-15 00:00:00")),
    zh_prov_attribute(groupid = grpid, client_ds_id = 222, localproviderid = "local provider id 16", master_hgprovid = "234", attribute_type_cui = "CH003915", attribute_value = "16", eff_date = java.sql.Timestamp.valueOf("2019-05-26 00:00:00"), end_date = java.sql.Timestamp.valueOf("2019-07-15 00:00:00")),
    zh_prov_attribute(groupid = grpid, client_ds_id = 222, localproviderid = "local provider id 17", master_hgprovid = "234", attribute_type_cui = "CH003916", attribute_value = "17", eff_date = java.sql.Timestamp.valueOf("2019-05-26 00:00:00"), end_date = java.sql.Timestamp.valueOf("2019-07-15 00:00:00")),
    zh_prov_attribute(groupid = grpid, client_ds_id = 222, localproviderid = "local provider id 18", master_hgprovid = "234", attribute_type_cui = "CH003917", attribute_value = "18", eff_date = java.sql.Timestamp.valueOf("2019-05-26 00:00:00"), end_date = java.sql.Timestamp.valueOf("2019-07-15 00:00:00")),
    zh_prov_attribute(groupid = grpid, client_ds_id = 222, localproviderid = "local provider id 19", master_hgprovid = "234", attribute_type_cui = "CH003918", attribute_value = "19", eff_date = java.sql.Timestamp.valueOf("2019-05-26 00:00:00"), end_date = java.sql.Timestamp.valueOf("2019-07-15 00:00:00")),
    zh_prov_attribute(groupid = grpid, client_ds_id = 222, localproviderid = "local provider id 20", master_hgprovid = "234", attribute_type_cui = "CH003919", attribute_value = "20", eff_date = java.sql.Timestamp.valueOf("2019-05-26 00:00:00"), end_date = java.sql.Timestamp.valueOf("2019-07-15 00:00:00")),
    zh_prov_attribute(groupid = grpid, client_ds_id = 222, localproviderid = "local provider id 21", master_hgprovid = "234", attribute_type_cui = "CH004048", attribute_value = "21", eff_date = java.sql.Timestamp.valueOf("2019-05-26 00:00:00"), end_date = java.sql.Timestamp.valueOf("2019-07-15 00:00:00")),
    zh_prov_attribute(groupid = grpid, client_ds_id = 222, localproviderid = "local provider id 22", master_hgprovid = "234", attribute_type_cui = "CH004049", attribute_value = "2" * 31, eff_date = java.sql.Timestamp.valueOf("2019-05-26 00:00:00"), end_date = java.sql.Timestamp.valueOf("2019-07-15 00:00:00")),
    zh_prov_attribute(groupid = grpid, client_ds_id = 222, localproviderid = "local provider id 23", master_hgprovid = "345", attribute_type_cui = "CH004048", attribute_value = "1" * 100, eff_date = java.sql.Timestamp.valueOf("2019-06-26 00:00:00"), end_date = java.sql.Timestamp.valueOf("2019-08-15 00:00:00")),
    zh_prov_attribute(groupid = grpid, client_ds_id = 222, localproviderid = "local provider id 24", master_hgprovid = "345", attribute_type_cui = "CH004049", attribute_value = "2" * 30, eff_date = java.sql.Timestamp.valueOf("2019-06-26 00:00:00"), end_date = java.sql.Timestamp.valueOf("2019-08-15 00:00:00")),
    zh_prov_attribute(groupid = grpid, client_ds_id = 222, localproviderid = "local provider id 25", master_hgprovid = "567", attribute_type_cui = "CH002488", attribute_value = "3", eff_date = java.sql.Timestamp.valueOf("2019-06-30 00:00:00"), end_date = java.sql.Timestamp.valueOf("2019-07-30 00:00:00")),
    zh_prov_attribute(groupid = grpid, client_ds_id = 222, localproviderid = "local provider id 26", master_hgprovid = "567", attribute_type_cui = "CH003917", attribute_value = "attribute vale 1", eff_date = java.sql.Timestamp.valueOf("2019-06-30 00:00:00"), end_date = java.sql.Timestamp.valueOf("2019-07-30 00:00:00")),
    zh_prov_attribute(groupid = grpid, client_ds_id = 222, localproviderid = "local provider id 27", master_hgprovid = "567", attribute_type_cui = "CH003918", attribute_value = "18", eff_date = java.sql.Timestamp.valueOf("2019-06-30 00:00:00"), end_date = java.sql.Timestamp.valueOf("2019-07-30 00:00:00")),
    zh_prov_attribute(groupid = grpid, client_ds_id = 222, localproviderid = "local provider id 28", master_hgprovid = "567", attribute_type_cui = "CH004049", attribute_value = "24", eff_date = java.sql.Timestamp.valueOf("2019-06-30 00:00:00"), end_date = java.sql.Timestamp.valueOf("2019-07-30 00:00:00"))

  )

  val expectedOutput : Seq[temp_bpo_prov_attr_spans] = Seq(
    temp_bpo_prov_attr_spans(groupid = grpid, master_hgprovid = "123", start_date = java.sql.Timestamp.valueOf("2019-06-01 00:00:00"), end_date = java.sql.Timestamp.valueOf("2019-07-31 00:00:00"), cust_prov_attr1 = "1", cust_prov_attr3 = "3"),
    temp_bpo_prov_attr_spans(groupid = grpid, master_hgprovid = "123", start_date = java.sql.Timestamp.valueOf("2019-08-01 00:00:00"), end_date = java.sql.Timestamp.valueOf("2019-08-31 00:00:00"), cust_prov_attr1 = "1"),
    temp_bpo_prov_attr_spans(groupid = grpid, master_hgprovid = "234", start_date = java.sql.Timestamp.valueOf("2019-04-01 00:00:00"), end_date = java.sql.Timestamp.valueOf("2019-04-30 00:00:00"), cust_prov_attr4 = "4"),
    temp_bpo_prov_attr_spans(groupid = grpid, master_hgprovid = "234", start_date = java.sql.Timestamp.valueOf("2019-05-01 00:00:00"), end_date = java.sql.Timestamp.valueOf("2019-07-31 00:00:00"), cust_prov_attr2 = "2", cust_prov_attr4 = "4", cust_prov_attr5 = "5", cust_prov_attr6 = "6", cust_prov_attr7 = "7", cust_prov_attr8 = "8", cust_prov_attr9 = "9", cust_prov_attr10 = "10", cust_prov_attr11 = "11", cust_prov_attr12 = "12", cust_prov_attr13 = "13", cust_prov_attr14 = "14", cust_prov_attr15 = "15", cust_prov_attr16 = 16.0, cust_prov_attr17 = 17.0, cust_prov_attr18 = 18.0, cust_prov_attr19 = 19.0, cust_prov_attr20 = 20.0, prov_userdef_1 = "21"),
    temp_bpo_prov_attr_spans(groupid = grpid, master_hgprovid = "123", start_date = java.sql.Timestamp.valueOf("2019-04-01 00:00:00"), end_date = java.sql.Timestamp.valueOf("2019-05-31 00:00:00"), cust_prov_attr3 = "3"),
    temp_bpo_prov_attr_spans(groupid = grpid, master_hgprovid = "345", start_date = java.sql.Timestamp.valueOf("2019-06-01 00:00:00"), end_date = java.sql.Timestamp.valueOf("2019-08-31 00:00:00"), prov_userdef_1 = "1" * 100, prov_userdef_2 = "2" * 30),
    temp_bpo_prov_attr_spans(groupid = grpid, master_hgprovid = "567", start_date = java.sql.Timestamp.valueOf("2019-06-01 00:00:00"), end_date = java.sql.Timestamp.valueOf("2019-07-31 00:00:00"), cust_prov_attr3 = "3", cust_prov_attr19 = 18.0, prov_userdef_2 = "24")
  )

  val runTimeVariables = EnrichmentRunTimeVariables(clientId = grpid, environment = "env", cdrCycle = "cdr cycle", cdrLevel = "cdr level", cdrSchema = "cdr schema", instance = "instance", release = "release", buildType = "buildType", fullHiveDb = "ecdr").asInstanceOf[RuntimeVariables]

  testQuery(
    testName = "test TEMP_BPO_PROV_ATTR_SPANS",
    query = TEMP_BPO_PROV_ATTR_SPANS,
    inputs = Map(
      "PP_BPO_MEMBER_DETAIL" -> ppBpoMemberDetail,
      "TEMP_BPO_PROVIDER_DETAIL" -> tempBpoProviderDetail,
      "ZH_PROV_ATTRIBUTE" -> tempZhProvAttribute
    ),
    expectedOutput = expectedOutput,
    mapRuntimeVariables = runTimeVariables
  )

  val expectedOutput1 : Seq[temp_bpo_prov_attr_spans] = Seq(
    temp_bpo_prov_attr_spans(groupid = "H623622", master_hgprovid = "6691", start_date = java.sql.Timestamp.valueOf("2016-04-01 00:00:00"), end_date = java.sql.Timestamp.valueOf("2018-06-30 00:00:00")),
    temp_bpo_prov_attr_spans(groupid = "H623622", master_hgprovid = "6691", start_date = java.sql.Timestamp.valueOf("2018-07-01 00:00:00"), end_date = java.sql.Timestamp.valueOf("2020-02-29 00:00:00"), prov_userdef_2 = "24")
  )

  testQuery(
    testName = "test BPO with same month end date of the payer",
    query = TEMP_BPO_PROV_ATTR_SPANS,
    inputs = Map(
      "PP_BPO_MEMBER_DETAIL" -> mkDataFrame(
        pp_bpo_member_detail(healthplansource = "PAYER", effectivedate = java.sql.Timestamp.valueOf("2016-04-01 00:00:00"), enddate = java.sql.Timestamp.valueOf("2020-02-29 00:00:00"))
      ),
      "TEMP_BPO_PROVIDER_DETAIL" -> mkDataFrame(
        temp_bpo_provider_detail(groupid = "H623622",npi = "1588950075",providerid = "6691",providername = "Hello, World",providerfirstname= " Hello",providerlastname= "World",specialty= "210")
      ),
      "ZH_PROV_ATTRIBUTE" -> mkDataFrame(
        zh_prov_attribute(groupid = "H623622", client_ds_id = 222, localproviderid = "local provider id 28", master_hgprovid = "6691", attribute_type_cui = "CH004049", attribute_value = "24", eff_date = java.sql.Timestamp.valueOf("2018-07-02 00:00:00")),
        zh_prov_attribute(groupid = "H623622", client_ds_id = 222, localproviderid = "local provider id 28", master_hgprovid = "6691", attribute_type_cui = "CH004047", attribute_value = "24", eff_date = java.sql.Timestamp.valueOf("2018-07-02 00:00:00")),
        zh_prov_attribute(groupid = "H623622", client_ds_id = 222, localproviderid = "local provider id 28", master_hgprovid = "6691", attribute_type_cui = "CH004049", attribute_value = "24", eff_date = java.sql.Timestamp.valueOf("2020-02-20 00:00:00"), end_date = java.sql.Timestamp.valueOf("2020-02-19 00:00:00")),
        zh_prov_attribute(groupid = "H623622", client_ds_id = 222, localproviderid = "local provider id 28", master_hgprovid = "6691", attribute_type_cui = "CH004047", attribute_value = "24", eff_date = java.sql.Timestamp.valueOf("2020-02-20 00:00:00"), end_date = java.sql.Timestamp.valueOf("2020-02-19 00:00:00"))

      )

    ),
    expectedOutput = expectedOutput1,
    mapRuntimeVariables = EnrichmentRunTimeVariables(clientId = "H623622", environment = "env", cdrCycle = "cdr cycle", cdrLevel = "cdr level", cdrSchema = "cdr schema", instance = "instance", release = "release", buildType = "buildType", fullHiveDb = "ecdr").asInstanceOf[RuntimeVariables]
  )

  val tempZhProvAttribute2 : DataFrame = mkDataFrame(
    zh_prov_attribute(groupid = grpid, client_ds_id = 123, localproviderid = "abc123", master_hgprovid = "1234", attribute_type_cui = "CH002486", attribute_value = "blue", eff_date = java.sql.Timestamp.valueOf("2019-06-01 00:00:00"), end_date = java.sql.Timestamp.valueOf("2019-06-30 00:00:00"), primary_span = "Y"),
    zh_prov_attribute(groupid = grpid, client_ds_id = 456, localproviderid = "def123", master_hgprovid = "1234", attribute_type_cui = "CH002486", attribute_value = "red", eff_date = java.sql.Timestamp.valueOf("2019-06-01 00:00:00"), end_date = java.sql.Timestamp.valueOf("2019-06-30 00:00:00"), primary_span = "N"),
    zh_prov_attribute(groupid = grpid, client_ds_id = 123, localproviderid = "abc123", master_hgprovid = "1234", attribute_type_cui = "CH002487", attribute_value = "two", eff_date = java.sql.Timestamp.valueOf("2019-06-01 00:00:00"), end_date = java.sql.Timestamp.valueOf("2019-06-30 00:00:00"), primary_span = "N"),
    zh_prov_attribute(groupid = grpid, client_ds_id = 456, localproviderid = "def123", master_hgprovid = "1234", attribute_type_cui = "CH002487", attribute_value = "one", eff_date = java.sql.Timestamp.valueOf("2019-06-01 00:00:00"), end_date = java.sql.Timestamp.valueOf("2019-06-30 00:00:00")),
    zh_prov_attribute(groupid = grpid, client_ds_id = 123, localproviderid = "abc123", master_hgprovid = "1234", attribute_type_cui = "CH002488", attribute_value = "abc", eff_date = java.sql.Timestamp.valueOf("2019-06-01 00:00:00"), end_date = java.sql.Timestamp.valueOf("2019-06-30 00:00:00"), primary_span = "Y"),
    zh_prov_attribute(groupid = grpid, client_ds_id = 456, localproviderid = "def123", master_hgprovid = "1234", attribute_type_cui = "CH002488", attribute_value = "def", eff_date = java.sql.Timestamp.valueOf("2019-06-01 00:00:00"), end_date = java.sql.Timestamp.valueOf("2019-06-30 00:00:00")),
    zh_prov_attribute(groupid = grpid, client_ds_id = 123, localproviderid = "abc123", master_hgprovid = "1234", attribute_type_cui = "CH002489", attribute_value = "abc", eff_date = java.sql.Timestamp.valueOf("2019-06-01 00:00:00"), end_date = java.sql.Timestamp.valueOf("2019-06-30 00:00:00"), primary_span = "Y"),
    zh_prov_attribute(groupid = grpid, client_ds_id = 456, localproviderid = "def123", master_hgprovid = "1234", attribute_type_cui = "CH002489", attribute_value = "def", eff_date = java.sql.Timestamp.valueOf("2019-06-01 00:00:00"), end_date = java.sql.Timestamp.valueOf("2019-06-30 00:00:00"), primary_span = "Y"),
    zh_prov_attribute(groupid = grpid, client_ds_id = 123, localproviderid = "abc123", master_hgprovid = "1234", attribute_type_cui = "CH002987", attribute_value = "abc", eff_date = java.sql.Timestamp.valueOf("2019-06-01 00:00:00"), end_date = java.sql.Timestamp.valueOf("2019-06-30 00:00:00")),
    zh_prov_attribute(groupid = grpid, client_ds_id = 456, localproviderid = "def123", master_hgprovid = "1234", attribute_type_cui = "CH002987", attribute_value = "def", eff_date = java.sql.Timestamp.valueOf("2019-06-01 00:00:00"), end_date = java.sql.Timestamp.valueOf("2019-06-30 00:00:00")),
    zh_prov_attribute(groupid = grpid, client_ds_id = 123, localproviderid = "abc123", master_hgprovid = "1234", attribute_type_cui = "CH002988", attribute_value = "abc", eff_date = java.sql.Timestamp.valueOf("2019-06-01 00:00:00"), end_date = java.sql.Timestamp.valueOf("2019-06-30 00:00:00"),primary_span = "Y"),
    zh_prov_attribute(groupid = grpid, client_ds_id = 456, localproviderid = "def123", master_hgprovid = "1234", attribute_type_cui = "CH002988", attribute_value = "def", eff_date = java.sql.Timestamp.valueOf("2019-06-01 00:00:00"), end_date = java.sql.Timestamp.valueOf("2019-06-30 00:00:00"), primary_span = "N"),
    zh_prov_attribute(groupid = grpid, client_ds_id = 456, localproviderid = "def123", master_hgprovid = "1234", attribute_type_cui = "CH002988", attribute_value = "def", eff_date = java.sql.Timestamp.valueOf("2019-06-01 00:00:00"), end_date = java.sql.Timestamp.valueOf("2019-06-30 00:00:00")),
    zh_prov_attribute(groupid = grpid, client_ds_id = 123, localproviderid = "abc123", master_hgprovid = "1234", attribute_type_cui = "CH004048", attribute_value = "abc", eff_date = java.sql.Timestamp.valueOf("2019-06-01 00:00:00"), end_date = java.sql.Timestamp.valueOf("2019-06-30 00:00:00"),primary_span = "Y"),
    zh_prov_attribute(groupid = grpid, client_ds_id = 456, localproviderid = "def123", master_hgprovid = "1234", attribute_type_cui = "CH004048", attribute_value = "def", eff_date = java.sql.Timestamp.valueOf("2019-06-01 00:00:00"), end_date = java.sql.Timestamp.valueOf("2019-06-30 00:00:00"), primary_span = "N"),
    zh_prov_attribute(groupid = grpid, client_ds_id = 123, localproviderid = "abc123", master_hgprovid = "1234", attribute_type_cui = "CH004049", attribute_value = "abc", eff_date = java.sql.Timestamp.valueOf("2019-06-01 00:00:00"), end_date = java.sql.Timestamp.valueOf("2019-06-30 00:00:00"),primary_span = "Y"),
    zh_prov_attribute(groupid = grpid, client_ds_id = 456, localproviderid = "def123", master_hgprovid = "1234", attribute_type_cui = "CH004049", attribute_value = "def", eff_date = java.sql.Timestamp.valueOf("2019-06-01 00:00:00"), end_date = java.sql.Timestamp.valueOf("2019-06-30 00:00:00"), primary_span = "N")
  )

  val tempBpoProviderDetail2 : DataFrame = mkDataFrame(
    temp_bpo_provider_detail(groupid = "group id 1", npi = "npi 1", providerid = "1234", providername = "provider name 1", providerfirstname = "name 1", providerlastname = "provider", specialty = "specialty 1")
  )

  val expectedOutput2 : Seq[temp_bpo_prov_attr_spans] = Seq(
    temp_bpo_prov_attr_spans(groupid = grpid, master_hgprovid = "1234", start_date = java.sql.Timestamp.valueOf("2019-06-01 00:00:00"), end_date = java.sql.Timestamp.valueOf("2019-06-30 00:00:00"), cust_prov_attr1 = "blue", cust_prov_attr2 = "one", cust_prov_attr3 = "abc", cust_prov_attr4 = "def", cust_prov_attr5 = "def", cust_prov_attr6 = "abc", prov_userdef_1 = "abc", prov_userdef_2 = "abc")
  )

  testQuery(
    testName = "test TEMP_BPO_PROV_ATTR_SPANS primary span order change",
    query = TEMP_BPO_PROV_ATTR_SPANS,
    inputs = Map(
      "PP_BPO_MEMBER_DETAIL" -> ppBpoMemberDetail,
      "TEMP_BPO_PROVIDER_DETAIL" -> tempBpoProviderDetail2,
      "ZH_PROV_ATTRIBUTE" -> tempZhProvAttribute2
    ),
    expectedOutput = expectedOutput2,
    mapRuntimeVariables = runTimeVariables
  )


}
