package com.optum.oap.backend.etl.bpo

import com.optum.oap.backend.BEQueryTestFramework
import com.optum.oap.backend.cdrTempModel.temp_pid
import com.optum.oap.cdr.models.{mv_client_data_src, zh_provider, zo_bpo_map_employer}
import org.apache.spark.sql.DataFrame
import org.junit.runner.RunWith
import org.scalatest.junit.JUnitRunner

@RunWith(classOf[JUnitRunner])
class TEMP_PID_TEST  extends BEQueryTestFramework {
  import spark.implicits._

  behavior of "translated query TEMP_PID"


  val zhProvider: DataFrame = mkDataFrame(
    zh_provider(groupid = "group id 1", client_ds_id = 1, master_hgprovid = "123", localproviderid = "local provider 1"),
    zh_provider(groupid = "group id 2", client_ds_id = 2, master_hgprovid = "123", localproviderid = "local provider 2"),
    zh_provider(groupid = "group id 3", client_ds_id = 3, master_hgprovid = "123", localproviderid = "local provider 3"),
    zh_provider(groupid = "group id 4", client_ds_id = 4, master_hgprovid = "234", localproviderid = "local provider 4"),
    zh_provider(groupid = "group id 5", client_ds_id = 5, master_hgprovid = "345", localproviderid = "local provider 5"),
    zh_provider(groupid = "group id 6", client_ds_id = 6, master_hgprovid = "456", localproviderid = "local provider 6"),
    zh_provider(groupid = "group id 7", client_ds_id = 7, master_hgprovid = "567", localproviderid = "local provider 7")
  )
  val mvClientDataSrc :DataFrame = mkDataFrame(
    mv_client_data_src(client_id = "group id 1", client_data_src_id = 1),
    mv_client_data_src(client_id = "group id 2", client_data_src_id = 2, data_src_id = 3683),
    mv_client_data_src(client_id = "group id 3", client_data_src_id = 3),
    mv_client_data_src(client_id = "group id 5", client_data_src_id = 5),
    mv_client_data_src(client_id = "group id 7", client_data_src_id = 7)
  )
  val zoBpoMapEmployer :DataFrame = mkDataFrame(
    zo_bpo_map_employer(groupid = "group id 3", client_ds_id = 3)
  )

  val expectedOutput : Seq[temp_pid] = Seq(
    temp_pid(master_hgprovid = "123", sec_provider_id = "local provider 2"),
    temp_pid(master_hgprovid = "345", sec_provider_id = "local provider 5"),
    temp_pid(master_hgprovid = "567", sec_provider_id = "local provider 7")
  )

  testQuery(
    testName = "test TEMP_PID",
    query = TEMP_PID,
    inputs = Map(
      "ZH_PROVIDER" -> zhProvider,
      "MV_CLIENT_DATA_SRC" -> mvClientDataSrc,
      "ZO_BPO_MAP_EMPLOYER" -> zoBpoMapEmployer
    ),
    expectedOutput = expectedOutput
  )
}
