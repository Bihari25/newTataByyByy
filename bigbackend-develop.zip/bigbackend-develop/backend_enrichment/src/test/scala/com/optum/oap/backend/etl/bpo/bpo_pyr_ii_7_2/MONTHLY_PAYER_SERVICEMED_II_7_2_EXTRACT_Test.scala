package com.optum.oap.backend.etl.bpo.bpo_pyr_ii_7_2

import java.sql.Timestamp

import com.optum.oap.backend.BEQueryTestFramework
import com.optum.oap.backend.cdrTempModel.monthly_payer_servicemed
import com.optum.oap.cdr.models._
import org.apache.spark.sql.DataFrame


class MONTHLY_PAYER_SERVICEMED_II_7_2_EXTRACT_Test extends BEQueryTestFramework {

  import spark.implicits._

  val netwrkPaidStatusRollupIn: DataFrame = mkDataFrame(
    netwrk_paid_status_rollup(network_paid_status_rollup = "status", network_paid_status = "jjj"),
    netwrk_paid_status_rollup(network_paid_status_rollup = "status2", network_paid_status = "iii")
  )

  val mapPredicateValuesIn: DataFrame = mkDataFrame(
    map_predicate_values(groupid = "H000000", client_ds_id = 1),
    map_predicate_values(groupid = "H000000", client_ds_id = 2)
  )

  val ppBpoMedicalClaimsIn: DataFrame = mkDataFrame(
    pp_bpo_medical_claims(memberid = "1000085132", claimheader = "MED6627.138092906", claimline = "1", servicedate = Timestamp.valueOf("2018-07-22 05:22:52"), fromdate = Timestamp.valueOf("2016-04-22 05:22:52"), todate = Timestamp.valueOf("2080-04-22 05:22:52"), paymentdate = Timestamp.valueOf("2016-04-22 05:22:52"),
      icdcodetype = "10", icddiag1 = "628.13", icddiag2 = "Z24", icddiag3 = "F25", icddiag4 = null, icddiag5 = null, icddiag6 = null,  icddiag7 = null, icddiag8 = null, icddiag9 = null, icddiag10 = null, icdproc1 = null, icdproc2 = null, icdproc3 = null, icdproc4 = null, icdproc5 = null, icdproc6 = null, icd_proc_7 = null,
      icd_proc_8 = null, icd_proc_9 = null, icd_proc_10 = null, procedurecode = "90744", revenuecode = null, proceduremodifier = "SL", dischargestatus = null, placeofservice = "11", poa = "U", quantity = 1, serviceproviderid = "0", specialty = "220", cobamount = null, coinsamount = null, copayamount = null,
      deductamount = null, allowedamount = 15.36, paidamount = 12.456, requestedamount = 0.01, withamount = null, patliabamount = 11.563, capamount = null, pseudoflag = "Y", deniedflag = "1", orderingproviderid = null, typeofbill = "0031", network_paid_status = null, provider_status = null, contract_id = null,
      billingproviderid = "34778235", drg = "790", drggrouper = "MS", drgseverity = null, drgoutlier = null, proc_code_modifier2 = null, proc_code_modifier3 = null, proc_code_modifier4 = null, icd_diag_11 = null, icd_proc_11 = null, capsvcflag = null, admitsource = null, amt_oth1 = null, amt_oth2 = null, amt_oth3 = null,
      amt_oth4 = null, denied_ind = null, spec_rx_ind = null, not_covered_amt = null, other_carrier_pay_amt = null, admin_fee_amt = null, cust_med_attr1 = null, healthplansource = "PAYER", employeraccountid = "BCBS"),

    pp_bpo_medical_claims(memberid = "1000085133", claimheader = "MED6627.138092906", claimline = "1", servicedate = Timestamp.valueOf("2019-06-22 05:22:52"), fromdate = Timestamp.valueOf("2019-06-22 05:22:52"), todate = Timestamp.valueOf("2016-04-22 05:22:52"), paymentdate = Timestamp.valueOf("2016-04-22 05:22:52"),
      icdcodetype = "9", icddiag1 = "Z23.44", icddiag2 = "Z24", icddiag3 = "F25", icddiag4 = null, icddiag5 = null, icddiag6 = null,  icddiag7 = null, icddiag8 = null, icddiag9 = null, icddiag10 = null, icdproc1 = null, icdproc2 = null, icdproc3 = null, icdproc4 = null, icdproc5 = null, icdproc6 = null, icd_proc_7 = null,
      icd_proc_8 = null, icd_proc_9 = null, icd_proc_10 = null, procedurecode = "90744", revenuecode = null, proceduremodifier = "SL", dischargestatus = null, placeofservice = "11", poa = "U", quantity = 1, serviceproviderid = "1234", specialty = "220", cobamount = null, coinsamount = null, copayamount = null,
      deductamount = null, allowedamount = null, paidamount = null, requestedamount = 0.01, withamount = null, patliabamount = null, capamount = null, pseudoflag = "Y", deniedflag = "1", orderingproviderid = null, typeofbill = "9999", network_paid_status = null, provider_status = null, contract_id = null,
      billingproviderid = "34778235", drg = "790", drggrouper = "MS", drgseverity = null, drgoutlier = null, proc_code_modifier2 = null, proc_code_modifier3 = null, proc_code_modifier4 = null, icd_diag_11 = null, icd_proc_11 = null, capsvcflag = null, admitsource = null, healthplansource = "PAYER", employeraccountid = "BCBS"),

    pp_bpo_medical_claims(memberid = "1000085138", claimheader = "MED6627.138092906", claimline = "1", servicedate = Timestamp.valueOf("2019-06-22 05:22:52"), fromdate = Timestamp.valueOf("2019-06-22 05:22:52"), todate = Timestamp.valueOf("2016-04-22 05:22:52"), paymentdate = Timestamp.valueOf("2016-04-22 05:22:52"),
      icdcodetype = "9", icddiag1 = "Z23.44", icddiag2 = "Z24", icddiag3 = "F25", icddiag4 = null, icddiag5 = null, icddiag6 = null,  icddiag7 = null, icddiag8 = null, icddiag9 = null, icddiag10 = null, icdproc1 = null, icdproc2 = null, icdproc3 = null, icdproc4 = null, icdproc5 = null, icdproc6 = null, icd_proc_7 = null,
      icd_proc_8 = null, icd_proc_9 = null, icd_proc_10 = null, procedurecode = "90744", revenuecode = null, proceduremodifier = "SL", dischargestatus = null, placeofservice = "11", poa = "U", quantity = 1, serviceproviderid = "1234", specialty = "220", cobamount = null, coinsamount = null, copayamount = null,
      deductamount = null, allowedamount = null, paidamount = null, requestedamount = 0.01, withamount = null, patliabamount = null, capamount = null, pseudoflag = "Y", deniedflag = "1", orderingproviderid = null, typeofbill = "99", network_paid_status = null, provider_status = null, contract_id = null,
      billingproviderid = "34778235", drg = "790", drggrouper = "MS", drgseverity = null, drgoutlier = null, proc_code_modifier2 = null, proc_code_modifier3 = null, proc_code_modifier4 = null, icd_diag_11 = null, icd_proc_11 = null, capsvcflag = null, admitsource = null, healthplansource = "PAYER", employeraccountid = "BCBS"),

    pp_bpo_medical_claims(memberid = "1000085136", claimheader = "MED6627.138092906", claimline = "1", servicedate = Timestamp.valueOf("2017-06-22 05:22:52"), fromdate = Timestamp.valueOf("2019-06-22 05:22:52"), todate = Timestamp.valueOf("2016-04-22 05:22:52"), paymentdate = Timestamp.valueOf("2016-04-22 05:22:52"),
      icddiag1 = "Z23.77", icddiag2 = "Z24", icddiag3 = "F25", icddiag4 = null, icddiag5 = null, icddiag6 = null,  icddiag7 = null, icddiag8 = null, icddiag9 = null, icddiag10 = null, icdproc1 = null, icdproc2 = null, icdproc3 = null, icdproc4 = null, icdproc5 = null, icdproc6 = null, icd_proc_7 = null,
      icd_proc_8 = null, icd_proc_9 = null, icd_proc_10 = null, procedurecode = "90744", revenuecode = null, proceduremodifier = "SL", dischargestatus = null, placeofservice = "11", poa = "U", quantity = 1, serviceproviderid = "0", specialty = "220", cobamount = null, coinsamount = null, copayamount = null,
      deductamount = null, allowedamount = null, paidamount = null, requestedamount = 0.01, withamount = null, patliabamount = null, capamount = null, pseudoflag = "Y", deniedflag = "1", orderingproviderid = null, typeofbill = "01325", network_paid_status = null, provider_status = null, contract_id = null,
      billingproviderid = "34778235", drg = "790", drggrouper = "MS", drgseverity = null, drgoutlier = null, proc_code_modifier2 = null, proc_code_modifier3 = null, proc_code_modifier4 = null, icd_diag_11 = null, icd_proc_11 = null, capsvcflag = null, admitsource = null, healthplansource = "PAYER", employeraccountid = "BCBS"),

    pp_bpo_medical_claims(memberid = "1000085135", claimheader = "MED6627.138092906", claimline = "1", servicedate = Timestamp.valueOf("2017-06-22 05:22:52"), fromdate = Timestamp.valueOf("2019-06-22 05:22:52"), todate = Timestamp.valueOf("2016-04-22 05:22:52"), paymentdate = Timestamp.valueOf("2016-04-22 05:22:52"),
      icddiag1 = "Z23.77", icddiag2 = "Z24", icddiag3 = "F25", icddiag4 = null, icddiag5 = null, icddiag6 = null,  icddiag7 = null, icddiag8 = null, icddiag9 = null, icddiag10 = null, icdproc1 = null, icdproc2 = null, icdproc3 = null, icdproc4 = null, icdproc5 = null, icdproc6 = null, icd_proc_7 = null,
      icd_proc_8 = null, icd_proc_9 = null, icd_proc_10 = null, procedurecode = "90744", revenuecode = null, proceduremodifier = "SL", dischargestatus = null, placeofservice = "11", poa = "U", quantity = 1, serviceproviderid = "0", specialty = "220", cobamount = null, coinsamount = null, copayamount = null,
      deductamount = null, allowedamount = null, paidamount = null, requestedamount = 0.01, withamount = null, patliabamount = null, capamount = null, pseudoflag = "Y", deniedflag = "1", orderingproviderid = null, typeofbill = "0132", network_paid_status = null, provider_status = null, contract_id = null,
      billingproviderid = "34778235", drg = "790", drggrouper = "MS", drgseverity = null, drgoutlier = null, proc_code_modifier2 = null, proc_code_modifier3 = null, proc_code_modifier4 = null, icd_diag_11 = null, icd_proc_11 = null, capsvcflag = null, admitsource = null, healthplansource = "PAYER", employeraccountid = "BCBS")
  )

  val ppBpoMemberDetail : DataFrame = mkDataFrame(
    pp_bpo_member_detail(healthplansource = "PAYER", groupid = "H000000", memberid = "1000085132", subscriberid="123", effectivedate = java.sql.Timestamp.valueOf("2018-06-15 00:00:00"), enddate = java.sql.Timestamp.valueOf("2018-08-18 00:00:00"), employeraccountid = "BCBS"),
    pp_bpo_member_detail(healthplansource = "PAYER", groupid = "H000000", memberid = "1000085133",  subscriberid="m1", effectivedate = java.sql.Timestamp.valueOf("2019-06-13 00:00:00"), enddate = java.sql.Timestamp.valueOf("2019-07-20 00:00:00"), employeraccountid = "BCBS"),
    pp_bpo_member_detail(healthplansource = "PAYER", groupid = "H000000", memberid = "1000085134",  subscriberid="m2", effectivedate = java.sql.Timestamp.valueOf("2019-06-18 00:00:00"), enddate = java.sql.Timestamp.valueOf("2019-07-11 00:00:00"), employeraccountid = "BCBS"),
    pp_bpo_member_detail(healthplansource = "PAYER", groupid = "H000000", memberid = "1000085138",  subscriberid="m2", effectivedate = java.sql.Timestamp.valueOf("2019-06-18 00:00:00"), enddate = java.sql.Timestamp.valueOf("2019-07-11 00:00:00"), employeraccountid = "BCBS")
  )

  val ppBpoMemberDetail_ii: DataFrame = mkDataFrame(

    pp_bpo_member_detail_ii(groupid = "H000000", memberid = "1000085135", effectivedate = Timestamp.valueOf("2017-01-01 00:00:00"), enddate = Timestamp.valueOf("2017-09-30 00:00:00"), dob = Timestamp.valueOf("2018-08-16 00:00:00"), gender = "M", pcpid = "21", pharmacy = "N", productcode = "MDE", subscriberid = "123", healthplansource = "PAYER", employeraccountid = "BCBS",
      medical = "Y", mentalhealth = "Y", coverageclasscode = "code1", subscriberflag ="Y", mapsource = "*", lineofbusinessid = 1, race = 9, race_datasrc = "29", ethnicity = 19, ethnicity_datasrc = "99", spoken_language = "31", spoken_language_datasrc ="49", dental_benefit ="Y", mh_inpatient_benefit = "Y", mh_intensive_benefit = "Y", mh_outpatient_benefit = "Y", cd_inpatient_benefit = "Y",
      cd_intensive_benefit = "Y", cd_outpatient_benefit = "Y", hospice_benefit = "N", date_of_death = Timestamp.valueOf("2017-11-17 00:00:00"), deceased_flag = "Y", ecds_flag = "Y", primary_coverage_flag = "Y", mcoid = "H000000", contract_id = "CMS", at_risk_status = "Y", cust_mem_attr1 = "WA", coveragestatus = "MED", emp_acct_id = "BCBS", contracttype = "c", benefitplan = "b", hra_ind = 0, hsa_ind = 0),

    pp_bpo_member_detail_ii(groupid = "H000000", memberid = "1000085136", effectivedate = Timestamp.valueOf("2017-01-01 00:00:00"), enddate = Timestamp.valueOf("2017-09-30 00:00:00"), dob = Timestamp.valueOf("2018-08-16 00:00:00"), gender = "M", pcpid = "21", pharmacy = "N", productcode = "MDE", subscriberid = "123", healthplansource = "PAYER", employeraccountid = "BCBS",
      medical = "Y", mentalhealth = "Y", coverageclasscode = "code1", subscriberflag ="Y", mapsource = "*", lineofbusinessid = 1, race = 9, race_datasrc = "29", ethnicity = 19, ethnicity_datasrc = "99", spoken_language = "31", spoken_language_datasrc ="49", dental_benefit ="Y", mh_inpatient_benefit = "Y", mh_intensive_benefit = "Y", mh_outpatient_benefit = "Y", cd_inpatient_benefit = "Y",
      cd_intensive_benefit = "Y", cd_outpatient_benefit = "Y", hospice_benefit = "N", date_of_death = Timestamp.valueOf("2017-11-17 00:00:00"), deceased_flag = "Y", ecds_flag = "Y", primary_coverage_flag = "Y", mcoid = "H000000", contract_id = "CMS", at_risk_status = "Y", cust_mem_attr1 = "WA", coveragestatus = "MED", emp_acct_id = "BCBS", contracttype = "c", benefitplan = "b", hra_ind = 0, hsa_ind = 0),

    pp_bpo_member_detail_ii(groupid = "H000000", memberid = "g1", effectivedate = Timestamp.valueOf("2016-10-01 00:00:00"), enddate = Timestamp.valueOf("2016-10-31 00:00:00"), dob = Timestamp.valueOf("2010-08-16 00:00:00"), gender = "M", pcpid = "22", pharmacy = "N", productcode = "MDE", subscriberid = "324", healthplansource = "PAYER", employeraccountid = "BCBS",
      medical = "Y", mentalhealth = "Y", coverageclasscode = "code1", subscriberflag ="Y", mapsource = "*", lineofbusinessid = 1, race = 9, race_datasrc = "29", ethnicity = 19, ethnicity_datasrc = "99", spoken_language = "31", spoken_language_datasrc ="49", dental_benefit ="Y", mh_inpatient_benefit = "Y", mh_intensive_benefit = "Y", mh_outpatient_benefit = "Y", cd_inpatient_benefit = "Y",
      cd_intensive_benefit = "Y", cd_outpatient_benefit = "Y", hospice_benefit = "N", date_of_death = Timestamp.valueOf("2017-11-17 00:00:00"), deceased_flag = "Y", ecds_flag = "Y", primary_coverage_flag = "Y", mcoid = "H000000", contract_id = "CMS", at_risk_status = "Y", cust_mem_attr1 = "WA", coveragestatus = "MED", emp_acct_id = "BCBS", contracttype = "c", benefitplan = "b", hra_ind = 0, hsa_ind = 0)

  )

  val expectedOutput: Seq[monthly_payer_servicemed] = Seq(
    monthly_payer_servicemed(member = "1000085132", bill_type = "031", network_status = 0, clm_id_n = "MED6627.138092906", line_nat = "1", dos = "2018-07-22", from_dt = "2016-04-22", to_dt = null, pay_dt = "2016-04-22", icd_version = "0", diag1 = "62813", diag2 = "Z24", diag3 = "F25", proccode = "90744", mod_n = "SL", pos_n = "11", poa = "U", qty = 1, provider = "999", prv_sp_n = "220", amt_req = 0.01, pseudo = 1, uniq_rec_id = "138092906", bill_provider = "34778235", bill_drg_n = "790", bill_drg_version = "MS", cap_flag = 0, cust_med_pk_id = "MED6627.138092906", map_srce_e = "1", map_srce_p = "1", map_srce_n = "1",
      amt_cob = 0.0, amt_coin = 0.0, amt_cop = 0.0, amt_ded = 0.0, amt_eqv = 15.36, amt_pay = 12.46, amt_wth = 0.0, amt_liab = 11.56, amt_cap_pay = 0.0, amt_not_covered = 0.0, amt_other_carrier_pay = 0.0, amt_admin_fee = 0.0),
    monthly_payer_servicemed(member = "1000085133", network_status = 0, clm_id_n = "MED6627.138092906", line_nat = "1", dos = "2019-06-22", from_dt = "2019-06-22", to_dt = "2016-04-22", pay_dt = "2016-04-22", icd_version = "9", diag1 = "Z2344", diag2 = "Z24", diag3 = "F25", proccode = "90744", mod_n = "SL", pos_n = "11", poa = "U", qty = 1, provider = "1234", prv_sp_n = "220", amt_req = 0.01, pseudo = 1, uniq_rec_id = "138092906", bill_provider = "34778235", bill_drg_n = "790", bill_drg_version = "MS", cap_flag = 0, cust_med_pk_id = "MED6627.138092906", map_srce_e = "1", map_srce_p = "1", map_srce_n = "1",
      amt_cob = 0.0, amt_coin = 0.0, amt_cop = 0.0, amt_ded = 0.0, amt_eqv = 0.0, amt_pay = 0.0, amt_wth = 0.0, amt_liab = 0.0, amt_cap_pay = 0.0, amt_not_covered = 0.0, amt_other_carrier_pay = 0.0, amt_admin_fee = 0.0),
    monthly_payer_servicemed(member = "1000085135", network_status = 0, clm_id_n = "MED6627.138092906", line_nat = "1", dos = "2017-06-22", from_dt = "2019-06-22", to_dt = "2016-04-22", pay_dt = "2016-04-22", icd_version = "0", diag1 = "Z2377", diag2 = "Z24", diag3 = "F25", proccode = "90744", mod_n = "SL", pos_n = "11", poa = "U", qty = 1, provider = "999", prv_sp_n = "220", amt_req = 0.01, pseudo = 1, uniq_rec_id = "138092906", bill_provider = "34778235", bill_drg_n = "790", bill_drg_version = "MS", cap_flag = 0, cust_med_pk_id = "MED6627.138092906", map_srce_e = "1", map_srce_p = "1", map_srce_n = "1",
      amt_cob = 0.0, amt_coin = 0.0, amt_cop = 0.0, bill_type = "132", amt_ded = 0.0, amt_eqv = 0.0, amt_pay = 0.0, amt_wth = 0.0, amt_liab = 0.0, amt_cap_pay = 0.0, amt_not_covered = 0.0, amt_other_carrier_pay = 0.0, amt_admin_fee = 0.0),
    monthly_payer_servicemed(member = "1000085136", network_status = 0, clm_id_n = "MED6627.138092906", line_nat = "1", dos = "2017-06-22", from_dt = "2019-06-22", to_dt = "2016-04-22", pay_dt = "2016-04-22", icd_version = "0", diag1 = "Z2377", diag2 = "Z24", diag3 = "F25", proccode = "90744", mod_n = "SL", pos_n = "11", poa = "U", qty = 1, provider = "999", prv_sp_n = "220", amt_req = 0.01, pseudo = 1, uniq_rec_id = "138092906", bill_provider = "34778235", bill_drg_n = "790", bill_drg_version = "MS", cap_flag = 0, cust_med_pk_id = "MED6627.138092906", map_srce_e = "1", map_srce_p = "1", map_srce_n = "1",
      amt_cob = 0.0, amt_coin = 0.0, amt_cop = 0.0, amt_ded = 0.0, amt_eqv = 0.0, amt_pay = 0.0, amt_wth = 0.0, amt_liab = 0.0, amt_cap_pay = 0.0, amt_not_covered = 0.0, amt_other_carrier_pay = 0.0, amt_admin_fee = 0.0),
    monthly_payer_servicemed(member = "1000085138", network_status = 0, clm_id_n = "MED6627.138092906", line_nat = "1", dos = "2019-06-22", from_dt = "2019-06-22", to_dt = "2016-04-22", pay_dt = "2016-04-22", icd_version = "9", diag1 = "Z2344", diag2 = "Z24", diag3 = "F25", proccode = "90744", mod_n = "SL", pos_n = "11", poa = "U", qty = 1, provider = "1234", prv_sp_n = "220", amt_req = 0.01, pseudo = 1, uniq_rec_id = "138092906", bill_provider = "34778235", bill_drg_n = "790", bill_drg_version = "MS", cap_flag = 0, cust_med_pk_id = "MED6627.138092906", map_srce_e = "1", map_srce_p = "1", map_srce_n = "1",
      amt_cob = 0.0, amt_coin = 0.0, amt_cop = 0.0, amt_ded = 0.0, amt_eqv = 0.0, amt_pay = 0.0, amt_wth = 0.0, amt_liab = 0.0, amt_cap_pay = 0.0, amt_not_covered = 0.0, amt_other_carrier_pay = 0.0, amt_admin_fee = 0.0)
  )

  testQuery(
    testName = "test MONTHLY_PAYER_SERVICEMED_II_7_2_EXTRACT_Test",
    query = MONTHLY_PAYER_SERVICEMED_II_7_2_EXTRACT,
    inputs = Map(
      "NETWRK_PAID_STATUS_ROLLUP" -> netwrkPaidStatusRollupIn,
      "MAP_PREDICATE_VALUES" -> mapPredicateValuesIn,
      "PP_BPO_MEDICAL_CLAIMS" -> ppBpoMedicalClaimsIn,
      "PP_BPO_MEMBER_DETAIL" -> ppBpoMemberDetail,
      "PP_BPO_MEMBER_DETAIL_II" -> ppBpoMemberDetail_ii
    ),
    expectedOutput = expectedOutput
  )
}
