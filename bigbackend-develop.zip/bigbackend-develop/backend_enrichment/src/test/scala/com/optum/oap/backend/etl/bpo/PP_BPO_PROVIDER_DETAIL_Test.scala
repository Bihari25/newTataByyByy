package com.optum.oap.backend.etl.bpo

import com.optum.oap.backend.BEQueryTestFramework
import com.optum.oap.backend.cdrTempModel.{temp_bpo_prov_spans, temp_bpo_provider_detail}
import com.optum.oap.backend.loader.EnrichmentRunTimeVariables
import com.optum.oap.cdr.models.{pp_bpo_medical_claims, pp_bpo_member_detail, pp_bpo_pharmacy_claims, pp_bpo_provider_detail, pp_bpo_provider_detail_spans}
import com.optum.oap.sparkdataloader.RuntimeVariables
import org.apache.spark.sql.DataFrame
import org.junit.runner.RunWith
import org.scalatest.junit.JUnitRunner


@RunWith(classOf[JUnitRunner])
class PP_BPO_PROVIDER_DETAIL_Test extends BEQueryTestFramework {

  import spark.implicits._

  behavior of "translated query PP_BPO_PROVIDER_DETAIL"

  val ppBpoProviderDetail: DataFrame = mkDataFrame(
    pp_bpo_provider_detail(groupid = "group id 1", providerid = "provider id 1", npi = "npi 1"),
    pp_bpo_provider_detail(groupid = "group id 3", providerid = "provider id 3", npi = "npi 3"),
    pp_bpo_provider_detail(groupid = "group id 2", providerid = "provider id 2", npi = "npi 2"),
    pp_bpo_provider_detail(groupid = "group id 4", providerid = "provider id 4", npi = "npi 4"),
    pp_bpo_provider_detail(groupid = "group id 5", providerid = "provider id 5", npi = "npi 5"),
    pp_bpo_provider_detail(groupid = "group id 6", providerid = "provider id 6", npi = "npi 6"),
    pp_bpo_provider_detail(groupid = "group id 7", providerid = "provider id 7", npi = "npi 7"),
    pp_bpo_provider_detail(groupid = "group id 8", providerid = "provider id 8", npi = "npi 8"),
    pp_bpo_provider_detail(groupid = "group id 9", providerid = "provider id 9", npi = "npi 9"),
    pp_bpo_provider_detail(groupid = "group id 10", providerid = "provider id 10", npi = "npi 10"),
    pp_bpo_provider_detail(groupid = "group id 11", providerid = "refer prov id 1", npi = "npi 11"),
    pp_bpo_provider_detail(groupid = "group id 12", providerid = "refer prov id 2", npi = "npi 12"),
    pp_bpo_provider_detail(groupid = "group id 12", providerid = "refer prov id 4", npi = "npi 12")
  )

  val ppBpoMemberDetailsSpans: DataFrame = mkDataFrame(
    pp_bpo_provider_detail_spans(providerid = "provider id 9"),
    pp_bpo_provider_detail_spans(providerid = "provider id 10", provaffiliationid = "prov affil id 2"),
    pp_bpo_provider_detail_spans(providerid = "provider id 11", provaffiliationid = "prov affil id 3"),
    pp_bpo_provider_detail_spans(providerid = "provider id 12", provaffiliationid = "prov affil id 4")
  )

  val ppBpoPharmacyClaims: DataFrame = mkDataFrame(
    pp_bpo_pharmacy_claims(prescprovider = "provider id 1"),
    pp_bpo_pharmacy_claims(prescprovider = "presc provider 2"),
    pp_bpo_pharmacy_claims(pharmacyid = "provider id 5"),
    pp_bpo_pharmacy_claims(pharmacyid = "pharmacy id 1")
  )

  val ppBpoMedicalClaims: DataFrame = mkDataFrame(
    pp_bpo_medical_claims(serviceproviderid = "service provider id 1"),
    pp_bpo_medical_claims(serviceproviderid = "service provider id 2"),
    pp_bpo_medical_claims(billingproviderid = "provider id 7"),
    pp_bpo_medical_claims(billingproviderid = "billing provider id 1"),
    pp_bpo_medical_claims(orderingproviderid = "ordering provider id 1"),
    pp_bpo_medical_claims(orderingproviderid = "provider id 8"),
    pp_bpo_medical_claims(refer_prov_id = "refer prov id 1"),
    pp_bpo_medical_claims(refer_prov_id = "refer prov id 2"),
    pp_bpo_medical_claims(refer_prov_id = "refer prov id 3")
  )

  val ppBpoMemberDetail: DataFrame = mkDataFrame(
    pp_bpo_member_detail(pcpid = "pcp id 1"),
    pp_bpo_member_detail(pcpid = "provider id 3")
  )

  val expectedOutput: Seq[pp_bpo_provider_detail] = Seq(
    pp_bpo_provider_detail(groupid = "group id 1", providerid = "provider id 1", npi = "npi 1"),
    pp_bpo_provider_detail(groupid = "group id 3", providerid = "provider id 3", npi = "npi 3"),
    pp_bpo_provider_detail(groupid = "group id 5", providerid = "provider id 5", npi = "npi 5"),
    pp_bpo_provider_detail(groupid = "group id 7", providerid = "provider id 7", npi = "npi 7"),
    pp_bpo_provider_detail(groupid = "group id 8", providerid = "provider id 8", npi = "npi 8"),
    pp_bpo_provider_detail(groupid = "group id 10", providerid = "provider id 10", npi = "npi 10"),
    pp_bpo_provider_detail(groupid = "group id 11", providerid = "refer prov id 1", npi = "npi 11"),
    pp_bpo_provider_detail(groupid = "group id 12", providerid = "refer prov id 2", npi = "npi 12")
  )

  testQuery(
    testName = "test PP_BPO_PROVIDER_DETAIL",
    query = PP_BPO_PROVIDER_DETAIL,
    inputs = Map(
      "TEMP_PP_BPO_PROVIDER_DETAIL" -> ppBpoProviderDetail,
      "PP_BPO_PHARMACY_CLAIMS" -> ppBpoPharmacyClaims,
      "PP_BPO_MEDICAL_CLAIMS" -> ppBpoMedicalClaims,
      "PP_BPO_MEMBER_DETAIL" -> ppBpoMemberDetail,
      "PP_BPO_PROVIDER_DETAIL_SPANS" -> ppBpoMemberDetailsSpans
    ),
    expectedOutput = expectedOutput
  )
}
