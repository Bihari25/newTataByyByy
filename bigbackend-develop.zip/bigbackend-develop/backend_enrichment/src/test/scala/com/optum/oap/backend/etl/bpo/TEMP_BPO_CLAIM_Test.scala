package com.optum.oap.backend.etl.bpo

import java.sql.{Date, Timestamp}

import com.optum.oap.backend.BEQueryTestFramework
import com.optum.oap.backend.cdrTempModel.{temp_bpo_calculate_params, temp_bpo_claim, temp_bpo_patients}
import com.optum.oap.backend.loader.EnrichmentRunTimeVariables
import com.optum.oap.cdr.models.{map_predicate_values, _}
import org.apache.spark.sql.DataFrame
import org.joda.time.{DateTime, DateTimeUtils}

/**
  *
  * Copyright 2019 Optum Analytics
  *
  * Date: 6/3/19
  *
  * Creator: bpokharel(bishu)
  */
class TEMP_BPO_CLAIM_Test extends BEQueryTestFramework {

  import spark.implicits._

  val claim_IN: DataFrame = mkDataFrame(
    claim(groupid = "H000000", grp_mpi = "101", claimid = "123", client_ds_id = 1, encounterid = "1", servicedate = Timestamp.valueOf("2016-07-06 07:57:00"), post_dt = Timestamp.valueOf("2016-09-06 07:57:00"), claim_mstrprovid = "1", mappedcpt = "abcde", mappedhcpcs = "fg", capitated_service_flag = "N", referring_prov_id = "refer prov 1", admit_type_code = "admit code 1"),
    claim(groupid = "H000000", grp_mpi = "102", prov_svc_ii_spec=1, other_1_amt=100.30, cust_attr_1="attr1", denied_flag="Y", client_ds_id = 1, encounterid = "2", servicedate = Timestamp.valueOf("2016-07-07 08:57:00"), post_dt = Timestamp.valueOf("2016-07-07 08:57:00"), claim_mstrprovid = "1", capitated_service_flag = "Y", localbillingproviderid = "123", referring_prov_id = "refer prov 2", admit_type_code = "1"),
    claim(groupid = "H000000", grp_mpi = "103", client_ds_id = 1, referring_prov_id = "refer prov id 2", admit_type_code = "admit code 3", servicedate = Timestamp.valueOf("2016-06-06 08:57:00")),
    claim(groupid = "H000000", grp_mpi = "104", client_ds_id = 1, referring_prov_id = "refer prov id 3", admit_type_code = "5", servicedate = Timestamp.valueOf("2016-06-06 08:57:00")),
    claim(groupid = "H000000", grp_mpi = "105", client_ds_id = 1, referring_prov_id = "refer prov id 4", admit_type_code = "admit 5", servicedate = Timestamp.valueOf("2016-06-06 08:57:00"))
  )

  val temp_bpo_patients_IN: DataFrame = mkDataFrame(
    temp_bpo_patients(groupid = "H000000", grp_mpi = "101", payer = 1),
    temp_bpo_patients(groupid = "H000000", grp_mpi = "101", payer = 2),
    temp_bpo_patients(groupid = "H000000", grp_mpi = "102", payer = 1),
    temp_bpo_patients(groupid = "H000000", grp_mpi = "103"),
    temp_bpo_patients(groupid = "H000000", grp_mpi = "104"),
    temp_bpo_patients(groupid = "H000000", grp_mpi = "105")
  )

  val map_predicate_values_IN: DataFrame = mkDataFrame(
    map_predicate_values(groupid = "H000000", client_ds_id = 1, entity = "PP_BPO_MEDICAL_CLAIMS", column_name = "PX_DX", data_src = "OADW")
  )

  val pp_bpo_provider_detail_spans_IN: DataFrame = mkDataFrame(
    pp_bpo_provider_detail_spans(groupid = "H000000", providerid = "1", provider_status = "ps1", prov_effective_dt = Timestamp.valueOf("2012-07-06 07:57:00"), prov_end_dt = Timestamp.valueOf("2019-07-06 07:57:00"))
  )

  val clinicalencounter_IN: DataFrame = mkDataFrame(
    clinicalencounter(groupid = "H000000", client_ds_id = 1, grp_mpi = "101", encounterid = "1", arrivaltime = Timestamp.valueOf("2016-07-06 07:57:00"), facilityid = "f1", localadmitsource = "U"),
    clinicalencounter(groupid = "H000000", client_ds_id = 1, grp_mpi = "101", encounterid = "2", arrivaltime = Timestamp.valueOf("2016-07-06 07:57:00"), facilityid = "f1"),
    clinicalencounter(groupid = "H000000", client_ds_id = 1, grp_mpi = "102", encounterid = "2", arrivaltime = Timestamp.valueOf("2016-07-06 07:57:00"), facilityid = "f1")
  )

  val map_patient_type_IN: DataFrame = mkDataFrame(
    map_patient_type(groupid = "H000000", dts_version = 1, local_code = "100", cui = "CH1000")
  )

  val map_discharge_disposition_IN: DataFrame = mkDataFrame(
    map_discharge_disposition(groupid = "H000000", cui = "CH000090", dts_version = 1, mnemonic = "M100")
  )

  val map_drg_type_IN: DataFrame = mkDataFrame(
    map_drg_type(groupid = "H000000", code = "D100", cui = "CHD100")
  )

  val temp_bpo_calculate_params_IN: DataFrame = mkDataFrame(
    temp_bpo_calculate_params(engineStartDate = Date.valueOf("2015-04-01"), engineStartDate2 = Date.valueOf("2015-04-01"), engineStartDate3 = Date.valueOf("2015-04-01"), engineEndDate = Date.valueOf("2019-03-31"), startDate = Date.valueOf("2015-01-01"))
  )

  DateTimeUtils.setCurrentMillisFixed(10000)

  val temp_bpo_claim_OUT: Seq[temp_bpo_claim] = Seq(
    temp_bpo_claim(groupid = "H000000", claimid="123",  admitsourcecui="CH000622", grp_mpi = "101", encounterid = "1", client_ds_id = 1, facilityid = "f1", servicedate = Timestamp.valueOf("2016-07-06 07:57:00"), claim_mstrprovid = "1", min_svc_date = Timestamp.valueOf("2016-07-06 07:57:00"), max_svc_date = Timestamp.valueOf("2016-07-06 07:57:00"), procedurecode = "abcde", capsvcflag = "N", provider_status = "ps1", paymentdate = Timestamp.valueOf("2016-09-06 07:57:00"), db_create_dt_tm = new Timestamp(DateTime.now().getMillis), refer_prov_id = "456", inp_admit_type = "7"),
    temp_bpo_claim(groupid = "H000000", prov_svc_ii_spec=1, amt_oth1=100.30, billingproviderid="123", cust_attr_1="attr1", denied_ind="Y", deniedflag="Y", grp_mpi = "102", encounterid = "2", client_ds_id = 1, facilityid = "f1", servicedate = Timestamp.valueOf("2016-07-07 08:57:00"), claim_mstrprovid = "1", min_svc_date = Timestamp.valueOf("2016-07-07 08:57:00"), max_svc_date = Timestamp.valueOf("2016-07-07 08:57:00"), procedurecode = null, capsvcflag = "Y", provider_status = "ps1", paymentdate = Timestamp.valueOf("2016-07-07 08:57:00"), db_create_dt_tm = new Timestamp(DateTime.now().getMillis), inp_admit_type = "1"),
    temp_bpo_claim(groupid = "H000000", grp_mpi = "103", client_ds_id = 1, servicedate = Timestamp.valueOf("2016-06-06 08:57:00"), paymentdate = Timestamp.valueOf("2016-06-06 08:57:00"), min_svc_date = Timestamp.valueOf("2016-06-06 08:57:00"), max_svc_date = Timestamp.valueOf("2016-06-06 08:57:00"), db_create_dt_tm = Timestamp.valueOf("1970-01-01 05:30:10")),
    temp_bpo_claim(groupid = "H000000", grp_mpi = "104", client_ds_id = 1, servicedate = Timestamp.valueOf("2016-06-06 08:57:00"), paymentdate = Timestamp.valueOf("2016-06-06 08:57:00"), min_svc_date = Timestamp.valueOf("2016-06-06 08:57:00"), max_svc_date = Timestamp.valueOf("2016-06-06 08:57:00"), db_create_dt_tm = Timestamp.valueOf("1970-01-01 05:30:10"), refer_prov_id = "789", inp_admit_type = "5"),
    temp_bpo_claim(groupid = "H000000", grp_mpi = "105", client_ds_id = 1, servicedate = Timestamp.valueOf("2016-06-06 08:57:00"), paymentdate = Timestamp.valueOf("2016-06-06 08:57:00"), min_svc_date = Timestamp.valueOf("2016-06-06 08:57:00"), max_svc_date = Timestamp.valueOf("2016-06-06 08:57:00"), db_create_dt_tm = Timestamp.valueOf("1970-01-01 05:30:10"), inp_admit_type = "3")
  )

  val deniedIndRollup: DataFrame = mkDataFrame(
    denied_ind_rollup(groupid = "H000000", denied_flag = "Y", denied_ind_rollup = "Y"),
    denied_ind_rollup(groupid = "H000000", denied_flag = "N", denied_ind_rollup = "N")
  )

  val zhProvider: DataFrame = mkDataFrame(
    zh_provider(client_ds_id = 1, groupid = "H000000", localproviderid = "123", master_hgprovid = "123"),
    zh_provider(client_ds_id = 1, groupid = "H000000", localproviderid = "refer prov 1", master_hgprovid = "456"),
    zh_provider(client_ds_id = 1, groupid = "H000000", localproviderid = "refer prov id 3", master_hgprovid = "789")
  )

  val mapAdmitSource: DataFrame = mkDataFrame(
    map_admit_source(cui = "CH000622", dts_version = 0, groupid = "H000000", localcode = "U")
  )

  val mapInpAdmitType : DataFrame = mkDataFrame(
    map_inp_admit_type(groupid = "H000000", local_code = "admit code 1", inp_admit_type = "7"),
    map_inp_admit_type(groupid = "H000000", local_code = "admit code 3", inp_admit_type = "inp admit 1"),
    map_inp_admit_type(groupid = "H000000", local_code = "admit 5", inp_admit_type = "3")
  )
  val testRuntimeVariables: EnrichmentRunTimeVariables = EnrichmentRunTimeVariables("H000000", "dev", "test", "cdr_be", "0", "1", "202001", "Monthly", "test")

  testQuery(
    testName = "test TEMP_BPO_CLAIM",
    query = TEMP_BPO_CLAIM,
    inputs = Map(
      "CLAIM" -> claim_IN,
      "TEMP_BPO_PATIENTS" -> temp_bpo_patients_IN,
      "MAP_PREDICATE_VALUES" -> map_predicate_values_IN,
      "TEMP_PP_BPO_PROVIDER_DETAIL_SPANS" -> pp_bpo_provider_detail_spans_IN,
      "CLINICALENCOUNTER" -> clinicalencounter_IN,
      "MAP_PATIENT_TYPE" -> map_patient_type_IN,
      "MAP_DISCHARGE_DISPOSITION" -> map_discharge_disposition_IN,
      "MAP_DRG_TYPE" -> map_drg_type_IN,
      "TEMP_BPO_CALCULATE_PARAMS" -> temp_bpo_calculate_params_IN,
      "DENIED_IND_ROLLUP" -> deniedIndRollup,
      "ZH_PROVIDER" -> zhProvider,
      "MAP_ADMIT_SOURCE" -> mapAdmitSource,
      "MAP_INP_ADMIT_TYPE" -> mapInpAdmitType
    ),
    mapRuntimeVariables = testRuntimeVariables,
    expectedOutput = temp_bpo_claim_OUT
  )
}