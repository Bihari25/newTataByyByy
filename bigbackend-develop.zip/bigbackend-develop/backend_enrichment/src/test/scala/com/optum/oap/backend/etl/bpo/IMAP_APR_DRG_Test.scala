package com.optum.oap.backend.etl.bpo

import com.optum.oap.backend.BEQueryTestFramework
import com.optum.oap.backend.cdrTempModel.imap_drg
import com.optum.oap.backend.loader.EnrichmentRunTimeVariables
import com.optum.oap.sparkdataloader.{EmptyRuntimeVariables, RuntimeVariables}
import org.junit.runner.RunWith
import org.scalatest.junit.JUnitRunner
import org.scalatest.Matchers._
@RunWith(classOf[JUnitRunner])
class IMAP_APR_DRG_Test extends BEQueryTestFramework {

  val runTimeVariables: RuntimeVariables = EnrichmentRunTimeVariables(clientId = "H000000", environment = "env", cdrCycle = "cdr cycle", cdrLevel = "cdr level", cdrSchema = "cdr schema", instance = "instance", release = "release", buildType = "Monthly", fullHiveDb = "ecdr").asInstanceOf[RuntimeVariables]

  it should "Test IMAP_APR_DRG" in {
    val df = IMAP_APR_DRG.createDataFrame(
      spark,
      Map.empty,
      udfsMap,
      runTimeVariables
    )

    val firstRec = df.first()

    firstRec.get(0) shouldBe "001"
    firstRec.get(1) shouldBe "LIVER TRANSPLANT AND/OR INTESTINAL TRANSPLANT"
    firstRec.get(2) shouldBe "99"
    df.first().get(3) shouldBe "SRG"
    df.first().get(4) shouldBe "APR"

    val total = df.collect()

    total.length shouldBe 2130
  }
}
