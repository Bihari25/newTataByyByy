package com.optum.oap.backend.etl.bpo

import com.optum.oap.backend.BEQueryTestFramework
import com.optum.oap.backend.cdrTempModel.temp_bpo_patients
import com.optum.oap.cdr.models.pp_bpo_member_dtl_addendum
import java.sql.Timestamp
import org.apache.spark.sql.DataFrame
import org.joda.time.{DateTime, DateTimeUtils}
import org.junit.runner.RunWith
import org.scalatest.junit.JUnitRunner


@RunWith(classOf[JUnitRunner])
class PP_BPO_MEMBER_DTL_ADDENDUM_Test extends BEQueryTestFramework {

  import spark.implicits._

  behavior of "translated query PP_BPO_MEMBER_DTL_ADDENDUM"

  val ppBpoMemberDtlAddendum: DataFrame = mkDataFrame(
    temp_bpo_patients(groupid = "group 1", grp_mpi = "member 1", payer = 1)
  )

  DateTimeUtils.setCurrentMillisFixed(10000)

  val expectedOutput = Seq(
    pp_bpo_member_dtl_addendum(
      groupid = "group 1"
      , memberid = "member 1"
      , ergexpthreshold = 0D
      , ergriskoutcome = 0D
      , erginputdata = 0D
      , ergcommmcaid = 0D
      , riskinputtype = 0D
      , prg_expd_tshld = "0"
      , prg_risk_outcome = "0"
      , prg_problty_tshld = "0"
      , db_create_dt_tm = new Timestamp(DateTime.now().getMillis())
    )
  )

  testQuery(
    testName = "test BPO_PHYSICIAN_KEY_FINAL",
    query = PP_BPO_MEMBER_DTL_ADDENDUM,
    inputs = Map(
      "TEMP_BPO_PATIENTS" -> ppBpoMemberDtlAddendum
    ),
    expectedOutput = expectedOutput
  )

}
