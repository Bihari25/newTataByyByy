package com.optum.oap.backend.etl.bpo

import com.optum.oap.backend.BEQueryTestFramework
import com.optum.oap.backend.cdrTempModel.{temp_bpo_prov_client_rel_spans, temp_bpo_provider_detail, temp_prov_affil}
import com.optum.oap.backend.loader.EnrichmentRunTimeVariables
import com.optum.oap.cdr.models.{pp_bpo_member_detail, prov_client_rel, prov_status_rollup}
import com.optum.oap.sparkdataloader.RuntimeVariables
import org.apache.spark.sql.DataFrame
import org.junit.runner.RunWith
import org.scalatest.junit.JUnitRunner

@RunWith(classOf[JUnitRunner])
class TEMP_BPO_PROV_CLIENT_REL_SPANS_Test extends BEQueryTestFramework {

  import spark.implicits._

  behavior of "translated query TEMP_BPO_PROVIDER_DETAIL"

  val grpid = "H000000"

  val ppBpoMemberDetail: DataFrame = mkDataFrame(
    pp_bpo_member_detail(healthplansource = "PAYER", effectivedate = java.sql.Timestamp.valueOf("2014-01-01 00:00:00"), enddate = java.sql.Timestamp.valueOf("2019-04-30 00:00:00")),
    pp_bpo_member_detail(healthplansource = "health plan source 1", effectivedate = java.sql.Timestamp.valueOf("2019-06-18 00:00:00"), enddate = java.sql.Timestamp.valueOf("2019-07-11 00:00:00"))
  )

  val tempProvClientRel: DataFrame = mkDataFrame(
    prov_client_rel(groupid = grpid, datasrc = "ipm", providerid = "101", localrelshipcode = "c1", startdate = java.sql.Timestamp.valueOf("2018-08-13 00:00:00"), enddate = java.sql.Timestamp.valueOf("2099-12-31 00:00:00"), mstrprovid = "101", client_ds_id = 108, prov_status_id = null),
    prov_client_rel(groupid = grpid, datasrc = "ipm", providerid = "102", localrelshipcode = "c1", startdate = java.sql.Timestamp.valueOf("2018-08-13 00:00:00"), enddate = java.sql.Timestamp.valueOf("2099-12-31 00:00:00"), mstrprovid = "101", client_ds_id = 108, prov_status_id = null),
    prov_client_rel(groupid = grpid, datasrc = "ipm", providerid = "102", localrelshipcode = "c1", startdate = java.sql.Timestamp.valueOf("2018-08-13 00:00:00"), enddate = java.sql.Timestamp.valueOf("2099-12-31 00:00:00"), mstrprovid = "101", client_ds_id = 110, prov_status_id = null),
    prov_client_rel(groupid = grpid, datasrc = "ipm", providerid = "101", localrelshipcode = "c1", startdate = java.sql.Timestamp.valueOf("2018-08-13 00:00:00"), enddate = java.sql.Timestamp.valueOf("2099-12-31 00:00:00"), mstrprovid = "101", client_ds_id = 110, prov_status_id = null)
  )

  val tempBpoProviderDetail: DataFrame = mkDataFrame(
    temp_bpo_provider_detail(groupid = grpid, npi = "npi1", providerid = "101", providername = "TESTLNAME, TESTFNAME", providerfirstname = "TESTLNAME", providerlastname = "TESTLNAME", specialty = "220", secondaryspecialty = "999", providertype = "220", pcpflag = "Y", healthplansource = "PROVIDER")
  )

  val provStatusRollUp: DataFrame = mkDataFrame(
    prov_status_rollup(client_ds_id = 999, datasrc = "testdatasrc", groupid = "g1", prov_status_desc = "prov_status_desc_1", prov_status_id = "prov_status_id_1", prov_status_lv1 = "prov_status_lv1_1", prov_status_lv1_desc = "prov_status_lv1_desc_1", prov_status_lv2 = "prov_status_lv2_1", prov_status_lv2_desc = "prov_status_lv2_desc_1", prov_status_rollup = "prov_status_rollup_1")
  )

  val expectedOutput: Seq[temp_bpo_prov_client_rel_spans] = Seq(
    temp_bpo_prov_client_rel_spans(groupid = grpid, master_hgprovid = "101", start_date = java.sql.Timestamp.valueOf("2014-01-01 00:00:00"), end_date = java.sql.Timestamp.valueOf("2018-07-31 00:00:00"), provider_status = null),
    temp_bpo_prov_client_rel_spans(groupid = grpid, master_hgprovid = "101", start_date = java.sql.Timestamp.valueOf("2018-08-01 00:00:00"), end_date = java.sql.Timestamp.valueOf("2099-11-30 00:00:00"), provider_status = null),
    temp_bpo_prov_client_rel_spans(groupid = grpid, master_hgprovid = "101", start_date = java.sql.Timestamp.valueOf("2099-12-01 00:00:00"), end_date = java.sql.Timestamp.valueOf("2099-12-31 00:00:00"), provider_status = null)
  )

  val runTimeVariables = EnrichmentRunTimeVariables(clientId = grpid, environment = "env", cdrCycle = "cdr cycle", cdrLevel = "cdr level", cdrSchema = "cdr schema", instance = "instance", release = "release", buildType = "buildType", fullHiveDb = "ecdr").asInstanceOf[RuntimeVariables]

  // TEST CASE 1

  testQuery(
    testName = "test TEMP_BPO_PROV_CLIENT_REL_SPANS",
    query = TEMP_BPO_PROV_CLIENT_REL_SPANS,
    inputs = Map(
      "PP_BPO_MEMBER_DETAIL" -> ppBpoMemberDetail,
      "PROV_CLIENT_REL" -> tempProvClientRel,
      "TEMP_BPO_PROVIDER_DETAIL" -> tempBpoProviderDetail,
      "PROV_STATUS_ROLLUP" -> provStatusRollUp
    ),
    expectedOutput = expectedOutput,
    mapRuntimeVariables = runTimeVariables
  )


  // TEST CASE 2
  val tempProvClientRel_1: DataFrame = mkDataFrame(
    prov_client_rel(groupid = grpid, datasrc = "ipm", providerid = "101", localrelshipcode = "c1", startdate = java.sql.Timestamp.valueOf("2018-08-13 00:00:00"), enddate = java.sql.Timestamp.valueOf("2099-12-31 00:00:00"), mstrprovid = "101", client_ds_id = 108, prov_status_id = "c1"),
    prov_client_rel(groupid = grpid, datasrc = "ipm", providerid = "102", localrelshipcode = "c1", startdate = java.sql.Timestamp.valueOf("2018-08-13 00:00:00"), enddate = java.sql.Timestamp.valueOf("2099-12-31 00:00:00"), mstrprovid = "101", client_ds_id = 108, prov_status_id = "c1"),
    prov_client_rel(groupid = grpid, datasrc = "ipm", providerid = "102", localrelshipcode = "c1", startdate = java.sql.Timestamp.valueOf("2018-08-13 00:00:00"), enddate = java.sql.Timestamp.valueOf("2099-12-31 00:00:00"), mstrprovid = "101", client_ds_id = 110, prov_status_id = "c1"),
    prov_client_rel(groupid = grpid, datasrc = "ipm", providerid = "101", localrelshipcode = "c1", startdate = java.sql.Timestamp.valueOf("2018-08-13 00:00:00"), enddate = java.sql.Timestamp.valueOf("2099-12-31 00:00:00"), mstrprovid = "101", client_ds_id = 110, prov_status_id = "c1")
  )

  val provStatusRollUp_1: DataFrame = mkDataFrame(
    prov_status_rollup(client_ds_id = 999, datasrc = "testdatasrc", groupid = grpid, prov_status_desc = "prov_status_desc_1", prov_status_id = "c1", prov_status_lv1 = "prov_status_lv1_1", prov_status_lv1_desc = "prov_status_lv1_desc_1", prov_status_lv2 = "prov_status_lv2_1", prov_status_lv2_desc = "prov_status_lv2_desc_1", prov_status_rollup = "prov_status_rollup_1")
  )

  val expectedOutput_1: Seq[temp_bpo_prov_client_rel_spans] = Seq(
    temp_bpo_prov_client_rel_spans(groupid = grpid, master_hgprovid = "101", start_date = java.sql.Timestamp.valueOf("2014-01-01 00:00:00"), end_date = java.sql.Timestamp.valueOf("2018-07-31 00:00:00"), provider_status = null),
    temp_bpo_prov_client_rel_spans(groupid = grpid, master_hgprovid = "101", start_date = java.sql.Timestamp.valueOf("2018-08-01 00:00:00"), end_date = java.sql.Timestamp.valueOf("2099-12-31 00:00:00"), provider_status = "c1")
  )


  testQuery(
    testName = "test TEMP_BPO_PROV_CLIENT_REL_SPANS_1",
    query = TEMP_BPO_PROV_CLIENT_REL_SPANS,
    inputs = Map(
      "PP_BPO_MEMBER_DETAIL" -> ppBpoMemberDetail,
      "PROV_CLIENT_REL" -> tempProvClientRel_1,
      "TEMP_BPO_PROVIDER_DETAIL" -> tempBpoProviderDetail,
      "PROV_STATUS_ROLLUP" -> provStatusRollUp_1
    ),
    expectedOutput = expectedOutput_1,
    mapRuntimeVariables = runTimeVariables
  )

  val expectedOutput1: Seq[temp_bpo_prov_client_rel_spans] = Seq(
    temp_bpo_prov_client_rel_spans(groupid = "H000000", master_hgprovid = "66915981", start_date = java.sql.Timestamp.valueOf("2016-04-01 00:00:00"), end_date = java.sql.Timestamp.valueOf("2018-06-30 00:00:00"), provider_status = null),
    temp_bpo_prov_client_rel_spans(groupid = "H000000", master_hgprovid = "66915981", start_date = java.sql.Timestamp.valueOf("2018-07-01 00:00:00"), end_date = java.sql.Timestamp.valueOf("2020-02-29 00:00:00"), provider_status = "c1")
  )

  testQuery(
    testName = "test when ends at same payer end month and have another with end date empty",
    query = TEMP_BPO_PROV_CLIENT_REL_SPANS,
    inputs = Map(
    "PP_BPO_MEMBER_DETAIL" -> mkDataFrame(
      pp_bpo_member_detail(healthplansource = "PAYER", effectivedate = java.sql.Timestamp.valueOf("2016-04-01 00:00:00"), enddate = java.sql.Timestamp.valueOf("2020-03-31 00:00:00"))
    ),
    "TEMP_BPO_PROVIDER_DETAIL" -> mkDataFrame(
      temp_bpo_provider_detail(groupid = "H000000",npi = "1588950075",providerid = "66915981",providername = "Hello, World",providerfirstname= " Hello",providerlastname= "World",specialty= "210")
    ),
    "PROV_CLIENT_REL" -> mkDataFrame(
      prov_client_rel(groupid = "H000000", datasrc = "ipm", providerid = "66915981", localrelshipcode = "c1", startdate = java.sql.Timestamp.valueOf("2018-07-01 00:00:00"), enddate = java.sql.Timestamp.valueOf("2020-02-19 00:00:00"), mstrprovid = "66915981", client_ds_id = 999, prov_status_id = "c1")
    ),
    "PROV_STATUS_ROLLUP" -> mkDataFrame(
      prov_status_rollup(client_ds_id = 999, datasrc = "testdatasrc", groupid = "H000000", prov_status_desc = "prov_status_desc_1", prov_status_id = "c1", prov_status_lv1 = "prov_status_lv1_1", prov_status_lv1_desc = "prov_status_lv1_desc_1", prov_status_lv2 = "prov_status_lv2_1", prov_status_lv2_desc = "prov_status_lv2_desc_1", prov_status_rollup = "prov_status_rollup_1")
    )
    ),
    expectedOutput = expectedOutput1,
    mapRuntimeVariables = runTimeVariables
  )

  val tempProvClientRel3: DataFrame = mkDataFrame(
    prov_client_rel(groupid = grpid, datasrc = "ipm", providerid = "101", localrelshipcode = "c1", startdate = java.sql.Timestamp.valueOf("2018-08-13 00:00:00"), enddate = java.sql.Timestamp.valueOf("2099-12-31 00:00:00"), mstrprovid = "101", client_ds_id = 108, prov_status_id = "prov status 1"),
    prov_client_rel(groupid = grpid, datasrc = "ipm", providerid = "102", localrelshipcode = "c1", startdate = java.sql.Timestamp.valueOf("2018-08-13 00:00:00"), enddate = java.sql.Timestamp.valueOf("2099-12-31 00:00:00"), mstrprovid = "101", client_ds_id = 108, prov_status_id = "prov status 2", primary_span = "Y"),
    prov_client_rel(groupid = grpid, datasrc = "ipm", providerid = "102", localrelshipcode = "c1", startdate = java.sql.Timestamp.valueOf("2018-08-13 00:00:00"), enddate = java.sql.Timestamp.valueOf("2099-12-31 00:00:00"), mstrprovid = "101", client_ds_id = 110, prov_status_id = null),
    prov_client_rel(groupid = grpid, datasrc = "ipm", providerid = "103", localrelshipcode = "c1", startdate = java.sql.Timestamp.valueOf("2018-08-13 00:00:00"), enddate = java.sql.Timestamp.valueOf("2099-12-31 00:00:00"), mstrprovid = "101", client_ds_id = 110, prov_status_id = "prov status 3", primary_span = "Y"),
    prov_client_rel(groupid = grpid, datasrc = "ipm", providerid = "103", localrelshipcode = "c1", startdate = java.sql.Timestamp.valueOf("2018-08-13 00:00:00"), enddate = java.sql.Timestamp.valueOf("2099-12-31 00:00:00"), mstrprovid = "101", client_ds_id = 110, prov_status_id = "prov status 4", primary_span = "N"),
    prov_client_rel(groupid = grpid, datasrc = "ipm", providerid = "103", localrelshipcode = "c1", startdate = java.sql.Timestamp.valueOf("2018-08-13 00:00:00"), enddate = java.sql.Timestamp.valueOf("2099-12-31 00:00:00"), mstrprovid = "101", client_ds_id = 110, prov_status_id = null)

  )

  val expectedOutput3: Seq[temp_bpo_prov_client_rel_spans] = Seq(
    temp_bpo_prov_client_rel_spans(groupid = grpid, master_hgprovid = "101", start_date = java.sql.Timestamp.valueOf("2014-01-01 00:00:00"), end_date = java.sql.Timestamp.valueOf("2018-07-31 00:00:00"), provider_status = null),
    temp_bpo_prov_client_rel_spans(groupid = grpid, master_hgprovid = "101", start_date = java.sql.Timestamp.valueOf("2018-08-01 00:00:00"), end_date = java.sql.Timestamp.valueOf("2099-12-31 00:00:00"), provider_status = "prov status 3")
  )

  testQuery(
    testName = "test TEMP_BPO_PROV_CLIENT_REL_SPANS primary_span order change",
    query = TEMP_BPO_PROV_CLIENT_REL_SPANS,
    inputs = Map(
      "PP_BPO_MEMBER_DETAIL" -> ppBpoMemberDetail,
      "PROV_CLIENT_REL" -> tempProvClientRel3,
      "TEMP_BPO_PROVIDER_DETAIL" -> tempBpoProviderDetail,
      "PROV_STATUS_ROLLUP" -> provStatusRollUp
    ),
    expectedOutput = expectedOutput3,
    mapRuntimeVariables = runTimeVariables
  )
}
