package com.optum.oap.backend.etl.bpo.bpo_pyr_sre

import com.optum.oap.backend.BEQueryTestFramework
import com.optum.oap.backend.cdrTempModel.monthly_payer_phc_sre
import com.optum.oap.cdr.models.{pp_bpo_member_detail, pp_bpo_pharmacy_clinical}
import org.apache.spark.sql.DataFrame

class MONTHLY_PAYER_PHC_SRE_EXTRACT_TEST extends BEQueryTestFramework {

  import spark.implicits._

  val originalSQL =
    """
      |SELECT
      |    phc.memberid
      |,   phc.pharmacy_clinical_id
      |,   phc.code_taxonomy
      |,   phc.code
      |,   date_format  (phc.administration_date,'yyyy-MM-dd') as administration_date
      |,  cast(null as string) as healthplansource
      |,  '*' as MapSource
      |FROM
      |    pp_bpo_pharmacy_clinical phc
      |INNER JOIN
      |    pp_bpo_member_detail elig
      |    ON
      |    (   elig.groupid = phc.groupid
      |    AND elig.memberid = phc.memberid
      |    AND elig.healthplansource = phc.healthplansource
      |    )
      |WHERE
      |    phc.healthplansource='PAYER'
      |AND
      |    phc.administration_date BETWEEN elig.effectivedate AND elig.enddate
    """.stripMargin

  val ppBpoMemberDetail: DataFrame = mkDataFrame(
    pp_bpo_member_detail(groupid = "H000000", memberid = "m1", healthplansource = "PAYER", effectivedate = java.sql.Timestamp.valueOf("2014-01-01 00:00:00"), enddate = java.sql.Timestamp.valueOf("2029-04-30 00:00:00")),
    pp_bpo_member_detail(groupid = "H000000", memberid = "m2", healthplansource = "PAYER", effectivedate = java.sql.Timestamp.valueOf("2019-06-18 00:00:00"), enddate = java.sql.Timestamp.valueOf("2019-07-11 00:00:00")),
    pp_bpo_member_detail(groupid = "H000000", memberid = "m3", healthplansource = "NOT_PAYER", effectivedate = java.sql.Timestamp.valueOf("2019-06-18 00:00:00"), enddate = java.sql.Timestamp.valueOf("2019-07-11 00:00:00"))
  )

  val ppBpoPharmacyClinical: DataFrame = mkDataFrame(
    pp_bpo_pharmacy_clinical(groupid = "H000000", memberid = "m1", code = "c11", code_taxonomy = "ct11", healthplansource = "PAYER", administration_date = java.sql.Timestamp.valueOf("2020-01-01 00:00:00"), pharmacy_clinical_id = "p11"),
    pp_bpo_pharmacy_clinical(groupid = "H000000", memberid = "m2", code = "c21", code_taxonomy = "ct21", healthplansource = "PAYER", administration_date = java.sql.Timestamp.valueOf("2019-06-19 00:00:00"), pharmacy_clinical_id = "p21"),
    pp_bpo_pharmacy_clinical(groupid = "H000000", memberid = "m2", code = "c22", code_taxonomy = "ct22", healthplansource = "PAYER", administration_date = java.sql.Timestamp.valueOf("2020-01-01 00:00:00"), pharmacy_clinical_id = "p22"),
    pp_bpo_pharmacy_clinical(groupid = "H000000", memberid = "m3", code = "c31", code_taxonomy = "ct31", healthplansource = "NOT_PAYER", administration_date = java.sql.Timestamp.valueOf("2020-01-01 00:00:00"), pharmacy_clinical_id = "p31")
  )

  val expectedOutput: Seq[monthly_payer_phc_sre] = Seq(
    monthly_payer_phc_sre(memberid = "m1", pharmacy_clinical_id= "p11", administration_date = "2020-01-01", code = "c11", code_taxonomy = "ct11", healthplansource = null, mapsource = "*"),
    monthly_payer_phc_sre(memberid = "m2", pharmacy_clinical_id= "p21", administration_date = "2019-06-19", code = "c21", code_taxonomy = "ct21", healthplansource = null, mapsource = "*")
  )

  testQuery(
    testName = "test MONTHLY_PAYER_PHC_SRE_EXTRACT",
    query = MONTHLY_PAYER_PHC_SRE_EXTRACT,
    inputs = Map(
      "PP_BPO_MEMBER_DETAIL" -> ppBpoMemberDetail,
      "PP_BPO_PHARMACY_CLINICAL" -> ppBpoPharmacyClinical
    ),
    expectedOutput = expectedOutput
  )

  it should "output of new etl should match with original Spark SQL etl" in {
    ppBpoMemberDetail.createOrReplaceTempView("pp_bpo_member_detail")
    ppBpoPharmacyClinical.createOrReplaceTempView("pp_bpo_pharmacy_clinical")

    val originalOutput = spark.sql(originalSQL)

    checkThatDataFramesAreEqual(originalOutput, expectedOutput)
  }

}
