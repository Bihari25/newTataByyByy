package com.optum.oap.backend.etl.bpo.bpo_pyr_ii_8_1

import com.optum.oap.backend.BEQueryTestFramework
import com.optum.oap.backend.cdrTempModel.{monthly_payer_subscriber, temp_bpo_insurance}
import com.optum.oap.cdr.models.{pp_bpo_member_detail, pp_bpo_member_detail_ii, zo_bpo_map_employer}
import org.apache.spark.sql.DataFrame

class MONTHLY_PAYER_SUBSCRIBER_II_8_1_EXTRACT_Test extends BEQueryTestFramework {

  import spark.implicits._

  val ppBpoMemberDetail : DataFrame = mkDataFrame(
    pp_bpo_member_detail(healthplansource = "PAYER", groupid = "H000000", memberid = "123", subscriberid="123", effectivedate = java.sql.Timestamp.valueOf("2018-06-15 00:00:00"), enddate = java.sql.Timestamp.valueOf("2018-08-18 00:00:00"), employeraccountid = "BCBS"),
    pp_bpo_member_detail(healthplansource = "PAYER", groupid = "H000000", memberid = "m1",  subscriberid="m1", effectivedate = java.sql.Timestamp.valueOf("2019-06-13 00:00:00"), enddate = java.sql.Timestamp.valueOf("2019-07-20 00:00:00"), employeraccountid = "BCBS"),
    pp_bpo_member_detail(healthplansource = "PAYER", groupid = "H000000", memberid = "m2",  subscriberid="m2", effectivedate = java.sql.Timestamp.valueOf("2019-06-18 00:00:00"), enddate = java.sql.Timestamp.valueOf("2019-07-11 00:00:00"), employeraccountid = "BCBS")
  )
  val zo_bpo_map_employerIn: DataFrame = mkDataFrame(
    zo_bpo_map_employer(groupid = "H000000", client_ds_id = 1, employeraccountid = "BCBS"),
    zo_bpo_map_employer(groupid = "H000000", client_ds_id = 2, employeraccountid = "BCBS")

  )
  val ppBpoMemberDetail_ii: DataFrame = mkDataFrame(

    pp_bpo_member_detail_ii(groupid = "H000000", memberid = "123", effectivedate = java.sql.Timestamp.valueOf("2016-07-01 00:00:00"), enddate = java.sql.Timestamp.valueOf("2016-09-30 00:00:00"), dob = java.sql.Timestamp.valueOf("2010-08-16 00:00:00"), gender = "M", pcpid = "21", pharmacy = "N", productcode = "MDE", subscriberid = "123", healthplansource = "PAYER", employeraccountid = "BCBS",
      medical = "Y", mentalhealth = "Y", coverageclasscode = "code1", subscriberflag ="Y", mapsource = "*", lineofbusinessid = 1, race = 9, race_datasrc = "29", ethnicity = 19, ethnicity_datasrc = "99", spoken_language = "31", spoken_language_datasrc ="49", dental_benefit ="Y", mh_inpatient_benefit = "Y", mh_intensive_benefit = "Y", mh_outpatient_benefit = "Y", cd_inpatient_benefit = "Y",
      cd_intensive_benefit = "Y", cd_outpatient_benefit = "Y", hospice_benefit = "N", date_of_death = java.sql.Timestamp.valueOf("2017-11-17 00:00:00"), deceased_flag = "Y", ecds_flag = "Y", primary_coverage_flag = "Y", mcoid = "H000000", contract_id = "CMS", at_risk_status = "Y", cust_mem_attr1 = "WA", coveragestatus = "MED", emp_acct_id = "BCBS", contracttype = "c", benefitplan = "b", hra_ind = 0, hsa_ind = 0),

    pp_bpo_member_detail_ii(groupid = "H000000", memberid = "g1", effectivedate = java.sql.Timestamp.valueOf("2016-10-01 00:00:00"), enddate = java.sql.Timestamp.valueOf("2016-10-31 00:00:00"), dob = java.sql.Timestamp.valueOf("2010-08-16 00:00:00"), gender = "M", pcpid = "22", pharmacy = "N", productcode = "MDE", subscriberid = "324", healthplansource = "PAYER", employeraccountid = "BCBS",
      medical = "Y", mentalhealth = "Y", coverageclasscode = "code1", subscriberflag ="Y", mapsource = "*", lineofbusinessid = 1, race = 9, race_datasrc = "29", ethnicity = 19, ethnicity_datasrc = "99", spoken_language = "31", spoken_language_datasrc ="49", dental_benefit ="Y", mh_inpatient_benefit = "Y", mh_intensive_benefit = "Y", mh_outpatient_benefit = "Y", cd_inpatient_benefit = "Y",
      cd_intensive_benefit = "Y", cd_outpatient_benefit = "Y", hospice_benefit = "N", date_of_death = java.sql.Timestamp.valueOf("2017-11-17 00:00:00"), deceased_flag = "Y", ecds_flag = "Y", primary_coverage_flag = "Y", mcoid = "H000000", contract_id = "CMS", at_risk_status = "Y", cust_mem_attr1 = "WA", coveragestatus = "MED", emp_acct_id = "BCBS", contracttype = "c", benefitplan = "b", hra_ind = 0, hsa_ind = 0)

  )

  val tempBpoInsurance: DataFrame = mkDataFrame(
    temp_bpo_insurance(groupid = "H000000", subscriberid = null, grp_mpi = "000", employeraccountid = "BCBS", member_start = java.sql.Timestamp.valueOf("2016-10-01 00:00:00"), payrank = 1, healthplansource = "PAYER", member_end =  java.sql.Timestamp.valueOf("2016-11-01 00:00:00")),
    temp_bpo_insurance(groupid = "H000000", subscriberid = "000", grp_mpi = null, employeraccountid = "BCBS", member_start = java.sql.Timestamp.valueOf("2016-10-01 00:00:00"), payrank = 1, healthplansource = "PAYER", member_end =  java.sql.Timestamp.valueOf("2016-11-01 00:00:00")),
    temp_bpo_insurance(groupid = "H000000", subscriberid = null, grp_mpi = "123", employeraccountid = "BCBS", member_start = java.sql.Timestamp.valueOf("2016-10-01 00:00:00"), payrank = 1, healthplansource = "PAYER", member_end =  java.sql.Timestamp.valueOf("2016-11-01 00:00:00")),
    temp_bpo_insurance(groupid = "H000000", subscriberid = "123", grp_mpi = null, employeraccountid = "BCBS", member_start = java.sql.Timestamp.valueOf("2016-10-01 00:00:00"), payrank = 1, healthplansource = "PAYER", member_end =  java.sql.Timestamp.valueOf("2016-11-01 00:00:00")),
    temp_bpo_insurance(groupid = "H000000", subscriberid = "345", grp_mpi = null, employeraccountid = "BCBS", member_start = java.sql.Timestamp.valueOf("2016-10-01 00:00:00"), payrank = 1, healthplansource = "PAYER", member_end =  java.sql.Timestamp.valueOf("2016-11-01 00:00:00")),
    temp_bpo_insurance(groupid = "H000000", subscriberid = "567", grp_mpi = "678", employeraccountid = "BCBS", member_start = java.sql.Timestamp.valueOf("2016-10-01 00:00:00"), payrank = 1, healthplansource = "PAYER", member_end =  java.sql.Timestamp.valueOf("2016-11-01 00:00:00"))
  )

  val expectedOutput: Seq[monthly_payer_subscriber] = Seq(
    monthly_payer_subscriber(subscriber_id="123_2", eff_dt="2016-07-01",end_dt="2016-09-30", map_srce_e="1", account="BCBS", contract_type="c", benefit_plan = "b", contract="CMS", cust_sub_1="WA", cust_sub_pk_id="123_2_1"),
    monthly_payer_subscriber(subscriber_id = "567_2", eff_dt= "2016-10-01", end_dt = "2016-11-01", map_srce_e = "1", cust_sub_1 = "",  cust_sub_2 = "",  cust_sub_3 = "",  cust_sub_4 = "",  cust_sub_5 = "",  cust_sub_6 = "",  cust_sub_7 = "",  cust_sub_8 = "",  cust_sub_9 = "",  cust_sub_10 = "",  cust_sub_11 = "",  cust_sub_12 = "",  cust_sub_13 = "",  cust_sub_14 = "",  cust_sub_15 = "", cust_sub_pk_id = "567_2_201610"), // check on this logic
    monthly_payer_subscriber(subscriber_id="m1_2", eff_dt="2019-06-13", end_dt="2019-07-20", map_srce_e="1", cust_sub_pk_id="m1_2_1"),
    monthly_payer_subscriber(subscriber_id="m2_2", eff_dt="2019-06-18", end_dt="2019-07-11", map_srce_e="1", cust_sub_pk_id="m2_2_1")

  )

  testQuery(
    testName = "test MONTHLY_PAYER_SUBSCRIBER_II_8_1_EXTRACT_Test",
    query = MONTHLY_PAYER_SUBSCRIBER_II_8_1_EXTRACT,
    inputs = Map(
      "PP_BPO_MEMBER_DETAIL" -> ppBpoMemberDetail,
      "ZO_BPO_MAP_EMPLOYER" -> zo_bpo_map_employerIn,
      "PP_BPO_MEMBER_DETAIL_II" -> ppBpoMemberDetail_ii,
      "TEMP_BPO_INSURANCE" -> tempBpoInsurance
    ),
    expectedOutput = expectedOutput
  )

}
