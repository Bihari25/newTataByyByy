package com.optum.oap.backend.etl.bpo

import com.optum.oap.backend.BEQueryTestFramework
import com.optum.oap.cdr.models.{pp_bpo_member_detail, v_pp_bpo_report_month_hedis}
import org.apache.spark.sql.DataFrame
import org.junit.runner.RunWith
import org.scalatest.junit.JUnitRunner

@RunWith(classOf[JUnitRunner])
class V_PP_BPO_REPORT_MONTH_HEDIS_Test extends BEQueryTestFramework {
  import spark.implicits._

  val ppBpoMemberDetail : DataFrame = mkDataFrame(
    pp_bpo_member_detail(healthplansource = "PAYER", groupid = "H000000", effectivedate = java.sql.Timestamp.valueOf("2018-06-15 00:00:00"), enddate = java.sql.Timestamp.valueOf("2018-08-18 00:00:00")),
    pp_bpo_member_detail(healthplansource = "PAYER", groupid = "H000000", effectivedate = java.sql.Timestamp.valueOf("2019-06-13 00:00:00"), enddate = java.sql.Timestamp.valueOf("2019-07-20 00:00:00")),
    pp_bpo_member_detail(healthplansource = "health plan source 1", groupid = "H000000", effectivedate = java.sql.Timestamp.valueOf("2019-06-18 00:00:00"), enddate = java.sql.Timestamp.valueOf("2019-07-11 00:00:00"))
  )

  val expectedOutput : Seq[v_pp_bpo_report_month_hedis] = Seq(
    v_pp_bpo_report_month_hedis(groupid = "H000000", yr0_date = java.sql.Timestamp.valueOf("2019-12-31 00:00:00"), yr1_date = java.sql.Timestamp.valueOf("2018-12-31 00:00:00"), yr2_date = java.sql.Timestamp.valueOf("2017-12-31 00:00:00"), yr3_date = java.sql.Timestamp.valueOf("2016-12-31 00:00:00"), min_eff_date = java.sql.Timestamp.valueOf("2018-06-15 00:00:00"))
  )


  testQuery(
    testName = "test V_PP_BPO_REPORT_MONTH_HEDIS",
    query = V_PP_BPO_REPORT_MONTH_HEDIS,
    inputs = Map(
      "PP_BPO_MEMBER_DETAIL" -> ppBpoMemberDetail
    ),
    expectedOutput = expectedOutput
  )



}
