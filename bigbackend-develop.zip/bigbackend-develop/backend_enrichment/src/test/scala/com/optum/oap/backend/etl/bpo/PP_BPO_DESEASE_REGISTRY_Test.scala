package com.optum.oap.backend.etl.bpo

import com.optum.oap.backend.BEQueryTestFramework
import com.optum.oap.cdr.models.pp_bpo_disease_registry
import org.junit.runner.RunWith
import org.scalatest.junit.JUnitRunner

/**
  *
  * Copyright 2019 Optum Analytics
  *
  * Date: 6/20/19
  *
  * Creator: bpokharel(bishu)
  */
@RunWith(classOf[JUnitRunner])
class PP_BPO_DESEASE_REGISTRY_Test extends BEQueryTestFramework {

  import spark.implicits._

  behavior of "translated query PP_BPO_DISEASE_REGISTRY"

  val expectedOutput: Seq[pp_bpo_disease_registry] = Seq()

  testQuery(
    testName = "test PP_BPO_DISEASE_REGISTRY",
    query = PP_BPO_DISEASE_REGISTRY,
    inputs = Map(),
    expectedOutput = expectedOutput
  )

}
