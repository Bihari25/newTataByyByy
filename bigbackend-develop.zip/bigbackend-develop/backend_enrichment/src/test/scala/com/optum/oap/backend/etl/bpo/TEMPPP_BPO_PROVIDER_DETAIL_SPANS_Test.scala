package com.optum.oap.backend.etl.bpo

import com.optum.oap.backend.BEQueryTestFramework
import com.optum.oap.backend.cdrTempModel.{temp_bpo_prov_spans, temp_bpo_provider_detail, temp_pid, temp_zip}
import com.optum.oap.backend.loader.EnrichmentRunTimeVariables
import com.optum.oap.cdr.models.{pp_bpo_medical_claims, pp_bpo_member_detail, pp_bpo_pharmacy_claims, pp_bpo_provider_detail_spans, zh_prov_contact_summary}
import com.optum.oap.sparkdataloader.RuntimeVariables
import org.apache.spark.sql.DataFrame
import org.junit.runner.RunWith
import org.scalatest.junit.JUnitRunner

@RunWith(classOf[JUnitRunner])
class TEMPPP_BPO_PROVIDER_DETAIL_SPANS_Test extends BEQueryTestFramework {

  import spark.implicits._

  behavior of "translated query TEMP_PP_BPO_PROVIDER_DETAIL_SPANS"

  val grpid = "group id"

  val tempBpoProvSpans : DataFrame = mkDataFrame(
    temp_bpo_prov_spans(groupid = "group id 1", master_hgprovid = "123", prov_end_dt = java.sql.Timestamp.valueOf("2019-06-06 00:00:00"), prov_userdef_1 = "prov user def 1", prov_userdef_2 = "prov user def 2"),
    temp_bpo_prov_spans(groupid = "group id 2", master_hgprovid = "234", prov_end_dt = java.sql.Timestamp.valueOf("2019-07-07 00:00:00")),
    temp_bpo_prov_spans(groupid = "group id 4", master_hgprovid = "234", prov_end_dt = java.sql.Timestamp.valueOf("2019-08-08 00:00:00")),
    temp_bpo_prov_spans(groupid = "group id 3", master_hgprovid = "345", prov_end_dt = java.sql.Timestamp.valueOf("2019-08-08 00:00:00"), prov_userdef_1 = "prov user def1 2", prov_userdef_2 = "prov user def2 2")
  )

  val tempBpoProviderDetail : DataFrame = mkDataFrame(
    temp_bpo_provider_detail(groupid = "group id 1", npi = "npi 1", providerid = "123"),
    temp_bpo_provider_detail(groupid = "group id 2", npi = "npi 2", providerid = "234"),
    temp_bpo_provider_detail(groupid = "group id 3", npi = "npi 3", providerid = "345")
  )

  val zhProvContactSummary : DataFrame = mkDataFrame(
    zh_prov_contact_summary(master_hgprovid = "123", mapped_contact_type="CH003087", address_line1 = "address line1 1", address_line2 = "address line2 1", city = "city 1", state = "ST", zipcode = "zip 1", work_phone = "work phone 1", email_address = "e" * 51),
    zh_prov_contact_summary(master_hgprovid = "234", mapped_contact_type="CH003087", address_line1 = "address line1 2", address_line2 = "address line2 2", city = "city 2", state = "state 2", zipcode = "zip code 2", work_phone = "work phone 2", email_address = "email address 2")
  )
  val tempPid : DataFrame = mkDataFrame(
    temp_pid(master_hgprovid = "123", sec_provider_id = "sec provider 1"),
    temp_pid(master_hgprovid = "545", sec_provider_id = "sec provider 2")
  )
  val tempZip : DataFrame = mkDataFrame(
    temp_zip(zipcode = "zip 1", latitude = 2.0, longitude = 3.0)
  )

  val expectedOutput : Seq[pp_bpo_provider_detail_spans] = Seq(
    pp_bpo_provider_detail_spans(groupid = "group id 2", npi = "npi 2", providerid = "234", prov_end_dt = java.sql.Timestamp.valueOf("2019-08-08 00:00:00"), final_flag = "Y", final_network_flag = "Y", provaddress1 = "address line1 2", provaddress2 = "address line2 2", provcity = "city 2", provzip = "zip code 2", provphone = "work phone 2",provemail = "email address 2"),
    pp_bpo_provider_detail_spans(groupid = "group id 2", npi = "npi 2", providerid = "234", prov_end_dt = java.sql.Timestamp.valueOf("2019-07-07 00:00:00"), final_flag = "N", final_network_flag = "N", provaddress1 = "address line1 2", provaddress2 = "address line2 2", provcity = "city 2", provzip = "zip code 2", provphone = "work phone 2",provemail = "email address 2"),
    pp_bpo_provider_detail_spans(groupid = "group id 3", npi = "npi 3", providerid = "345", prov_end_dt = java.sql.Timestamp.valueOf("2019-08-08 00:00:00"), final_flag = "Y", final_network_flag = "Y", prov_userdef_1 = "prov user def1 2", prov_userdef_2 = "prov user def2 2"),
    pp_bpo_provider_detail_spans(groupid = "group id 1", npi = "npi 1", providerid = "123", prov_end_dt = java.sql.Timestamp.valueOf("2019-06-06 00:00:00"), final_flag = "Y", final_network_flag = "Y", provaddress1 = "address line1 1", provaddress2 = "address line2 1", provcity = "city 1", provstate = "ST", provzip = "zip 1", provphone = "work phone 1", prov_geo_lat = 2.0, prov_geo_lon = 3.0, prov_userdef_1 = "prov user def 1", prov_userdef_2 = "prov user def 2", sec_provider_id = "sec provider 1")
  )


  val runTimeVariables = EnrichmentRunTimeVariables(clientId = grpid, environment = "env", cdrCycle = "cdr cycle", cdrLevel = "cdr level", cdrSchema = "cdr schema", instance = "instance", release = "release", buildType = "buildType", fullHiveDb = "ecdr").asInstanceOf[RuntimeVariables]
  testQuery (
    testName = "test TEMP_PP_BPO_PROVIDER_DETAIL_SPANS",
    query = TEMP_PP_BPO_PROVIDER_DETAIL_SPANS,
    inputs = Map (
      "TEMP_BPO_PROV_SPANS" -> tempBpoProvSpans,
      "TEMP_BPO_PROVIDER_DETAIL" -> tempBpoProviderDetail,
      "ZH_PROV_CONTACT_SUMMARY" -> zhProvContactSummary,
      "TEMP_PID" -> tempPid,
      "TEMP_ZIP" -> tempZip
    ),
    expectedOutput =  expectedOutput,
    mapRuntimeVariables = runTimeVariables
  )
}
