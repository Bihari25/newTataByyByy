package com.optum.oap.backend.etl.common


import com.optum.oap.backend.BEQueryTestFramework
import com.optum.oap.backend.etl.common.ExtractUom.extract_uom
import org.apache.spark.sql.functions.lit
import org.junit.runner.RunWith
import org.scalatest.Matchers._
import org.scalatest.junit.JUnitRunner

@RunWith(classOf[JUnitRunner])
class ExtractUomTest extends BEQueryTestFramework{

  behavior of "extract_uom udf"

  it should "extract uom from given string" in {

    val actualOutcome = Seq(

      extract_uom(lit("  testiU pEr LTesTIU pEr Cc  ")).expr.eval().toString
      , extract_uom(lit(" test_no_regex_matches ")).expr.eval()
      , extract_uom(lit("nmol/l")).expr.eval().toString
      , extract_uom(lit("gm/dl")).expr.eval().toString
      , extract_uom(lit("mg/wk")).expr.eval().toString
      , extract_uom(lit("g/dl")).expr.eval().toString
      , extract_uom(lit("lpg per mlion dollar")).expr.eval().toString

    )

    val expectedOutcome = Seq(

      "iu/l"
      , null
      , "nmol/l"
      , "gm/dl"
      , "mg/wk"
      , "g/dl"
      , "pg/ml"

    )

    actualOutcome shouldBe expectedOutcome
  }
}