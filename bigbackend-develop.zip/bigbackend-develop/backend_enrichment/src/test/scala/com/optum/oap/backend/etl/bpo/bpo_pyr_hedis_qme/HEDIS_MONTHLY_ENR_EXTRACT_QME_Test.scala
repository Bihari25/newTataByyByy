package com.optum.oap.backend.etl.bpo.bpo_pyr_hedis_qme

import com.optum.oap.backend.BEQueryTestFramework
import com.optum.oap.backend.cdrTempModel.hedis_monthly_enr_extract_qme
import com.optum.oap.cdr.models.pp_bpo_member_detail
import org.apache.spark.sql.DataFrame

class HEDIS_MONTHLY_ENR_EXTRACT_QME_Test extends BEQueryTestFramework{

  import spark.implicits._


  val ppBpoMemberDetail : DataFrame = mkDataFrame(
    pp_bpo_member_detail(memberid = "m1", groupid = "H000000", employeraccountid = "employer account id 1", productcode = "P1" ,pcpid="pcp1",healthplanname = "healthplan1",coverageclasscode = "c1",contracttype = "contacttype1",benefitplan = "benifitplan1",coveragestatus = "coveragestatus1",subscriberid = "1",subscriberflag = "Y",healthplansource = "PAYER", lineofbusinessid = 1, enddate = java.sql.Timestamp.valueOf("2020-01-31 00:00:00"), effectivedate = java.sql.Timestamp.valueOf("2020-01-31 00:00:00"), dob = java.sql.Timestamp.valueOf("2020-02-20 00:00:00"), city = "city 1"),
    pp_bpo_member_detail(memberid = "m2", groupid = "H000000", employeraccountid = "employer account id 2", productcode = "P1" ,pcpid="pcp1",healthplanname = "healthplan1",coverageclasscode = "c1",contracttype = "contacttype1",benefitplan = "benifitplan1",coveragestatus = "coveragestatus1",subscriberid = "1",subscriberflag = "Y",healthplansource = "PAYER", lineofbusinessid = 1, enddate = java.sql.Timestamp.valueOf("2020-02-20 00:00:00"), effectivedate = java.sql.Timestamp.valueOf("2020-03-30 00:00:00"), dob = java.sql.Timestamp.valueOf("2020-01-30 00:00:00"), city = "city 2"),
    pp_bpo_member_detail(memberid = "m3", groupid = "H000000", employeraccountid = "employer account id 3", productcode = "P1" ,pcpid="pcp1",healthplanname = "healthplan1",coverageclasscode = "c1",contracttype = "contacttype1",benefitplan = "benifitplan1",coveragestatus = "coveragestatus1",subscriberid = "1",subscriberflag = "Y",healthplansource = "PAYER", lineofbusinessid = 1, enddate = java.sql.Timestamp.valueOf("2020-03-20 00:00:00"), effectivedate = java.sql.Timestamp.valueOf("2020-02-20 00:00:00"), dob = java.sql.Timestamp.valueOf("2020-03-20 00:00:00"), city = "city 3"),
    pp_bpo_member_detail(memberid = "m4", groupid = "H000000", employeraccountid = "employer account id 4", productcode = "P1" ,pcpid="pcp1",healthplanname = "healthplan1",coverageclasscode = "c1",contracttype = "contacttype1",benefitplan = "benifitplan1",coveragestatus = "coveragestatus1",subscriberid = "1",subscriberflag = "Y",healthplansource = "PAYER", lineofbusinessid = 1, enddate = java.sql.Timestamp.valueOf("2020-01-20 00:00:00"), effectivedate = java.sql.Timestamp.valueOf("2020-01-20 00:00:00"), dob = java.sql.Timestamp.valueOf("2020-02-20 00:00:00"), city = "city 4"),
    pp_bpo_member_detail(memberid = "m5", groupid = "H000000", employeraccountid = "employer account id 4", productcode = "P1" ,pcpid="pcp1",healthplanname = "healthplan1",coverageclasscode = "c1",contracttype = "contacttype1",benefitplan = "benifitplan1",coveragestatus = "coveragestatus1",subscriberid = "1",subscriberflag = "Y",healthplansource = "PAYER", lineofbusinessid = 1, enddate = java.sql.Timestamp.valueOf("2020-04-20 00:00:00"), effectivedate = java.sql.Timestamp.valueOf("2020-04-20 00:00:00"), dob = java.sql.Timestamp.valueOf("2020-03-20 00:00:00"), city = "city 5"),
    pp_bpo_member_detail(memberid = "m6", groupid = "H000000", employeraccountid = "employer account id 3", productcode = "P1" ,pcpid="pcp1",healthplanname = "healthplan1",coverageclasscode = "c1",contracttype = "contacttype1",benefitplan = "benifitplan1",coveragestatus = "coveragestatus1",subscriberid = "1",subscriberflag = "Y",healthplansource = "NOT PAYER", lineofbusinessid = 1, enddate = java.sql.Timestamp.valueOf("2020-05-20 00:00:00")),
    pp_bpo_member_detail(memberid = "m7", groupid = "H000000", employeraccountid = "employer account id 3", productcode = "P1" ,pcpid="pcp1",healthplanname = "healthplan1",coverageclasscode = "c1",contracttype = "contacttype1",benefitplan = "benifitplan1",coveragestatus = "coveragestatus1",subscriberid = "1",subscriberflag = "Y",healthplansource = "PAYER", lineofbusinessid = null, enddate = java.sql.Timestamp.valueOf("2020-05-20 00:00:00"))
  )

  val expectedOutput: Seq[hedis_monthly_enr_extract_qme] = Seq(
    hedis_monthly_enr_extract_qme(MemberID = "m1", EffectiveDate = "2020-02-20", EndDate = "2020-12-31" , ProductCode = "P1" , LineofBusinessID = "1", PCPID = "pcp1", HealthPlanSource = "PAYER", HealthPlanName = "healthplan1" , CoverageClassCode = "c1" , ContractType = "contacttype1" , BenefitPlan = "benifitplan1" , CoverageStatus = "coveragestatus1", SubscriberID = "1", IsSubscriber = "Y", MapSourceCode = "AD", ECDSDataAvailableforMemberCode = "4"),
    hedis_monthly_enr_extract_qme(MemberID = "m2", EffectiveDate = "2020-03-30", EndDate = "2020-12-31" , ProductCode = "P1" , LineofBusinessID = "1", PCPID = "pcp1", HealthPlanSource = "PAYER", HealthPlanName = "healthplan1" , CoverageClassCode = "c1" , ContractType = "contacttype1" , BenefitPlan = "benifitplan1" , CoverageStatus = "coveragestatus1", SubscriberID = "1", IsSubscriber = "Y", MapSourceCode = "AD", ECDSDataAvailableforMemberCode = "4"),
    hedis_monthly_enr_extract_qme(MemberID = "m3", EffectiveDate = "2020-03-20", EndDate = "2020-03-20" , ProductCode = "P1" , LineofBusinessID = "1", PCPID = "pcp1", HealthPlanSource = "PAYER", HealthPlanName = "healthplan1" , CoverageClassCode = "c1" , ContractType = "contacttype1" , BenefitPlan = "benifitplan1" , CoverageStatus = "coveragestatus1", SubscriberID = "1", IsSubscriber = "Y", MapSourceCode = "AD", ECDSDataAvailableforMemberCode = "4"),
    hedis_monthly_enr_extract_qme(MemberID = "m4", EffectiveDate = "2020-02-20", EndDate = "2020-01-20" , ProductCode = "P1" , LineofBusinessID = "1", PCPID = "pcp1", HealthPlanSource = "PAYER", HealthPlanName = "healthplan1" , CoverageClassCode = "c1" , ContractType = "contacttype1" , BenefitPlan = "benifitplan1" , CoverageStatus = "coveragestatus1", SubscriberID = "1", IsSubscriber = "Y", MapSourceCode = "AD", ECDSDataAvailableforMemberCode = "4"),
    hedis_monthly_enr_extract_qme(MemberID = "m5", EffectiveDate = "2020-04-20", EndDate = "2020-12-31" , ProductCode = "P1" , LineofBusinessID = "1", PCPID = "pcp1", HealthPlanSource = "PAYER", HealthPlanName = "healthplan1" , CoverageClassCode = "c1" , ContractType = "contacttype1" , BenefitPlan = "benifitplan1" , CoverageStatus = "coveragestatus1", SubscriberID = "1", IsSubscriber = "Y", MapSourceCode = "AD", ECDSDataAvailableforMemberCode = "4")
  )

  testQuery(
    testName = "test HEDIS_MONTHLY_ENR_EXTRACT_QME",
    query = HEDIS_MONTHLY_ENR_EXTRACT_QME,
    inputs = Map(
      "PP_BPO_MEMBER_DETAIL" -> ppBpoMemberDetail
    ),
    expectedOutput = expectedOutput
  )
}
