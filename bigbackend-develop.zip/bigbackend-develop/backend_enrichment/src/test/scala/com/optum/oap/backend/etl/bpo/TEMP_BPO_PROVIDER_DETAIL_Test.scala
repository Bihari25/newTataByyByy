package com.optum.oap.backend.etl.bpo

import com.optum.oap.backend.BEQueryTestFramework
import com.optum.oap.cdr.models.{map_predicate_values, map_provider_taxonomy, map_specialty, map_specialty_ii, prov_client_rel, ref_primaryspecialty, zh_provider, zh_provider_master, zh_provider_master_xref, zo_bpo_map_employer, zo_specialty}
import org.apache.spark.sql.DataFrame
import org.junit.runner.RunWith
import java.sql.Timestamp

import com.optum.oap.backend.cdrTempModel.temp_bpo_provider_detail
import com.optum.oap.backend.loader.EnrichmentRunTimeVariables
import com.optum.oap.sparkdataloader.RuntimeVariables
import org.scalatest.junit.JUnitRunner

@RunWith(classOf[JUnitRunner])
class TEMP_BPO_PROVIDER_DETAIL_Test extends BEQueryTestFramework {
  import spark.implicits._

  behavior of "translated query TEMP_BPO_PROVIDER_DETAIL"


  val grpid = "H984216"

  val mapPredicateValue: DataFrame = mkDataFrame(
    map_predicate_values(entity = "PP_BPO_PROVIDER_DETAIL", column_name = "II_SPECIALTY", data_src = "OADW", groupid = "H984216")
  )

  val provClientRel : DataFrame = mkDataFrame(
    prov_client_rel(client_ds_id = 1, datasrc = "data src 1", enddate = java.sql.Timestamp.valueOf("2019-06-12 00:00:00"), groupid = "H984216", localrelshipcode = "emr provider", mstrprovid = "12345", prov_status_id = "prov status id 1", providerid = "provider id 1", startdate = java.sql.Timestamp.valueOf("2019-06-12 00:00:00")),
    prov_client_rel(client_ds_id = 2, datasrc = "data src 2", enddate = java.sql.Timestamp.valueOf("2019-07-12 00:00:00"), groupid = "group id 2", localrelshipcode = "local rel ship code 2", mstrprovid = "23456", prov_status_id = "prov status id 2", providerid = "provider id 2", startdate = java.sql.Timestamp.valueOf("2019-06-12 00:00:00")),
    prov_client_rel(client_ds_id = 3, datasrc = "data src 3", enddate = java.sql.Timestamp.valueOf("2019-06-12 00:00:00"), groupid = "H984216", localrelshipcode = "emr provider", mstrprovid = "4342", prov_status_id = "prov status id 3", providerid = "provider id 3", startdate = java.sql.Timestamp.valueOf("2019-06-12 00:00:00")),
    prov_client_rel(client_ds_id = 4, datasrc = "data src 4", enddate = java.sql.Timestamp.valueOf("2019-06-12 00:00:00"), groupid = "H984216", localrelshipcode = "emr provider", mstrprovid = "3341", prov_status_id = "prov status id 4", providerid = "provider id 4", startdate = java.sql.Timestamp.valueOf("2019-06-12 00:00:00"))
  )

  val zhProviderMasterXref : DataFrame = mkDataFrame(
    zh_provider_master_xref(client_ds_id = 1, groupid = "H984216", hgprovid = 123l, localproviderid = "provider id 1", master_hgprovid = "12345", match_cnt = 123),
    zh_provider_master_xref(client_ds_id = 3, groupid = "H984216", hgprovid = 123l, localproviderid = "provider id 3", master_hgprovid = "4342", match_cnt = 123),
    zh_provider_master_xref(client_ds_id = 4, groupid = "H984216", hgprovid = 123l, localproviderid = "provider id 4", master_hgprovid = "3341", match_cnt = 123)
  )

  val mapSpecialty : DataFrame = mkDataFrame(
    map_specialty(cui = "cui 1", dts_version = 1, groupid = "H984216", mnemonic = "mnemonic 1"),
    map_specialty(cui = "cui 2", dts_version = 2, groupid = "group id 2", mnemonic = "mnemonic 2")
  )

  val zhProviderMaster : DataFrame = mkDataFrame(
    zh_provider_master(emailaddress = "email address 1", groupid = "H984216", localclassification = "local classification 1", localprimaryspecialty = "local primary specialty 1", mappedcredentialtype = "mapped credential type 1", master_hgprovid = "12345", match_cnt = 2, npi = "npi 1", primaryfacilityid = "primary facility id 1", providerexclusionflag = "provider exclusion flag 1", providername = "provider ,name 1"),
    zh_provider_master(emailaddress = "email address 2", groupid = "group id 2", localclassification = "local classification 2", localprimaryspecialty = "local primary specialty 2", mappedcredentialtype = "mapped credential type 2", master_hgprovid = "2345", match_cnt = 5, npi = "npi 2", primaryfacilityid = "primary facility id 2", providerexclusionflag = "provider exclusion flag 2", providername = "provider name 2"),
    zh_provider_master(emailaddress = "email address 3", groupid = "H984216", localclassification = "local classification 3", localprimaryspecialty = "local primary specialty 3", mappedcredentialtype = "mapped credential type 3", master_hgprovid = "4342", match_cnt = 5, npi = "npi 3", primaryfacilityid = "primary facility id 3", providerexclusionflag = "provider exclusion flag 3", providername = "last name only,"),
    zh_provider_master(emailaddress = "email address 4", groupid = "H984216", localclassification = "local classification 4", localprimaryspecialty = "local primary specialty 4", mappedcredentialtype = "mapped credential type 4", master_hgprovid = "3341", match_cnt = 5, npi = "npi 4", primaryfacilityid = "primary facility id 4", providerexclusionflag = "provider exclusion flag 4", providername = ",first name only")
  )

  val zoBpoMapEmployer : DataFrame = mkDataFrame(
    zo_bpo_map_employer(client_ds_id = 1, groupid = "H984216"),
    zo_bpo_map_employer(client_ds_id = 2, groupid = "H984216"),
    zo_bpo_map_employer(client_ds_id = 3, groupid = "H984216"),
    zo_bpo_map_employer(client_ds_id = 4, groupid = "H984216")
  )

  val zhProvider : DataFrame = mkDataFrame(
    zh_provider(client_ds_id = 1, credentials = "credentials 1", datasrc = "data src 1", dob = java.sql.Timestamp.valueOf("2019-06-12 00:00:00"), emailaddress = "email address 1", first_name = "first name 1", gender = "M", groupid = "H984216", last_name = "last name 1", localclassification = "local classification 1", localprimaryspecialty = "local primary specialty 1", localproviderid = "provider id 1", mappedcredentialtype = "mapped credential type 1", master_hgprovid = "12345", middle_name = "middle name 1", npi = "npi 1", pcp_flag = "pcp flag 1", primaryfacilityid = "primary facility id 1", providerexclusionflag = "provider exclusion flag 1", providername = "provider name 1", suffix = "suffix 1"),
    zh_provider(client_ds_id = 2, credentials = "credentials 2", datasrc = "data src 2", dob = java.sql.Timestamp.valueOf("2019-05-11 00:00:00"), emailaddress = "email address 2", first_name = "first name 2", gender = "M", groupid = "group id 2", last_name = "last name 2", localclassification = "local classification 2", localprimaryspecialty = "local primary specialty 2", localproviderid = "local provider id 2", mappedcredentialtype = "mapped credential type 2", master_hgprovid = "4352", middle_name = "middle name 2", npi = "npi 2", pcp_flag = "pcp flag 1", primaryfacilityid = "primary facility id 2", providerexclusionflag = "provider exclusion flag 2", providername = "provider name 2", suffix = "suffix 2"),
    zh_provider(client_ds_id = 3, credentials = "credentials 3", datasrc = "data src 3", dob = java.sql.Timestamp.valueOf("2019-05-11 00:00:00"), emailaddress = "email address 3", first_name = "first name 3", gender = "M", groupid = "H984216", last_name = "last name 3", localclassification = "local classification 3", localprimaryspecialty = "local primary specialty 3", localproviderid = "provider id 3", mappedcredentialtype = "mapped credential type 3", master_hgprovid = "4342", middle_name = "middle name 3", npi = "npi 3", pcp_flag = "pcp flag 3", primaryfacilityid = "primary facility id 3", providerexclusionflag = "provider exclusion flag 3", providername = "provider name 3", suffix = "suffix 3"),
    zh_provider(client_ds_id = 4, credentials = "credentials 4", datasrc = "data src 4", dob = java.sql.Timestamp.valueOf("2019-05-11 00:00:00"), emailaddress = "email address 4", first_name = "first name 4", gender = "M", groupid = "H984216", last_name = "last name 4", localclassification = "local classification 4", localprimaryspecialty = "local primary specialty 4", localproviderid = "provider id 4", mappedcredentialtype = "mapped credential type 4", master_hgprovid = "3341", middle_name = "middle name 4", npi = "npi 4", pcp_flag = "pcp flag 4", primaryfacilityid = "primary facility id 4", providerexclusionflag = "provider exclusion flag 4", providername = "provider name 4", suffix = "suffix 4")
  )

  val mapSpecialtyII : DataFrame = mkDataFrame(
    map_specialty_ii(dts_version = 1, groupid = "H984216", ii_code = "ii code 1", local_code = "local code 1"),
    map_specialty_ii(dts_version = 2, groupid = "group id 2", ii_code = "ii code 2", local_code = "local code 2")
  )

  val refPrimarySpecialty : DataFrame = mkDataFrame(
    ref_primaryspecialty(npi = "npi 1", primarycode = "primary code 1"),
    ref_primaryspecialty(npi = "npi 2", primarycode = "primary code 2"),
    ref_primaryspecialty(npi = "npi 3", primarycode = "primary code 3"),
    ref_primaryspecialty(npi = "npi 4", primarycode = "primary code 4")
  )

  val mapProviderTaxonomy : DataFrame = mkDataFrame(
    map_provider_taxonomy(dts_version = 1, ii_code = "ii code 1", specialty_cui = "specialty cui 1", taxonomy_code = "taxonomy code 1"),
    map_provider_taxonomy(dts_version = 2, ii_code = "ii code 2", specialty_cui = "specialty cui 2", taxonomy_code = "taxonomy code 2")
  )

  val zoSpecialty : DataFrame = mkDataFrame(
    zo_specialty(cc_code = "cc code 1", cc_name = "cc name 1", dts_version = 1, hts_cui = "hts cui 1", ii_code = "ii code 1", ii_name = "ii name 1", pe_cc_code = "pe cc code 1", pe_cc_name = "pe cc name 1"),
    zo_specialty(cc_code= "cc code 2", cc_name = "cc name 2", dts_version = 2, hts_cui = "hts cui 2", ii_code = "ii code 2", ii_name = "ii name 2", pe_cc_code = "pe cc code 2", pe_cc_name = "pe cc name 2")
  )

  val expectedOutput :Seq[temp_bpo_provider_detail] = Seq(
    temp_bpo_provider_detail(groupid = "H984216", npi = "npi 1", providerid = "12345", providername = "provider ,name 1", providerfirstname = "name 1", providerlastname = "provider ", specialty = "999", secondaryspecialty = "999", providertype = "999",pcpflag = "N", healthplansource ="PROVIDER", mapsource = "*"),
    temp_bpo_provider_detail(groupid = "H984216", npi = null,providerid = "0", providername = "Provider Unknown", providerfirstname = "Provider", providerlastname = "Unknown", specialty = "999", secondaryspecialty = "999", providertype = "999", pcpflag = "N", healthplansource = "PAYER", mapsource = "*"),
    temp_bpo_provider_detail(groupid = "H984216", npi = null, providerid = "ACHOSPOUT", providername = "Acute Care Hospital Non " + "H984216", providerfirstname = "Acute Care", providerlastname = "Hospital Non " + "H984216", specialty = "100", secondaryspecialty = "100", providertype = "100", pcpflag = "N", healthplansource = "PAYER", mapsource = "*"),
    temp_bpo_provider_detail(groupid = "H984216", npi = null, providerid = "ACHOSPIN", providername = "Acute Care Hospital " + "H984216", providerfirstname = "Acute Care", providerlastname = "Hospital " + "H984216", specialty = "100", secondaryspecialty = "100", providertype = "100", pcpflag = "N", healthplansource = "PROVIDER", mapsource = "*"),
    temp_bpo_provider_detail(groupid = "H984216", npi = "npi 3", providerid = "4342", providername = "last name only,", providerfirstname = "No Provider First Name", providerlastname = "last name only", specialty = "999", secondaryspecialty = "999", providertype = "999", pcpflag = "N", healthplansource = "PROVIDER", mapsource = "*"),
    temp_bpo_provider_detail(groupid = "H984216", npi = "npi 4", providerid = "3341", providername = ",first name only", providerfirstname = "first name only", providerlastname = "No Provider Last Name", specialty = "999", secondaryspecialty = "999", providertype = "999", pcpflag = "N", healthplansource = "PROVIDER", mapsource = "*")
  )

  val runTimeVariables = EnrichmentRunTimeVariables(clientId = grpid, environment = "env", cdrCycle = "cdr cycle", cdrLevel = "cdr level", cdrSchema = "cdr schema", instance = "instance", release = "release", buildType = "buildType", fullHiveDb = "ecdr").asInstanceOf[RuntimeVariables]

  testQuery (
    testName = "test TEMP_BPO_PROVIDER_DETAIL",
    query = TEMP_BPO_PROVIDER_DETAIL,
    inputs = Map(
      "MAP_PREDICATE_VALUES" -> mapPredicateValue,
      "PROV_CLIENT_REL" -> provClientRel,
      "ZH_PROVIDER_MASTER_XREF" -> zhProviderMasterXref,
      "ZO_BPO_MAP_EMPLOYER" -> zoBpoMapEmployer,
      "ZH_PROVIDER" -> zhProvider,
      "MAP_SPECIALTY_II" -> mapSpecialtyII,
      "MAP_SPECIALTY" -> mapSpecialty,
      "ZH_PROVIDER_MASTER" -> zhProviderMaster,
      "REF_PRIMARYSPECIALTY" -> refPrimarySpecialty,
      "MAP_PROVIDER_TAXONOMY" -> mapProviderTaxonomy,
      "ZO_SPECIALTY" -> zoSpecialty
    ),
    expectedOutput =  expectedOutput,
    mapRuntimeVariables = runTimeVariables
  )
}
