package com.optum.oap.backend

import com.optum.oap.backend.etl.common.OADefinedFunctionsRegistry
import com.optum.oap.backend.util.{ResourceConverter, ResourceInput}
import com.optum.oap.sparkdataloader.{EmptyRuntimeVariables, RuntimeVariables, TableInfo, UserDefinedFunctionForDataLoader}
import com.optum.oap.testutils.TestSparkSession
import org.apache.spark.sql.{DataFrame, Encoder}
import org.scalatest.FlatSpec
import org.scalatest.Matchers._

abstract class BEQueryTestFramework extends FlatSpec with TestSparkSession {

  val spark = sparkSession

  val udfsMap: Map[String, UserDefinedFunctionForDataLoader] = OADefinedFunctionsRegistry.getUdfsMap(spark)

  def testQuery[A: Encoder](testName: String,
                            query: TableInfo[_ <: Product],
                            inputs: Map[String, DataFrame],
                            expectedOutput: Seq[A],
                            mapRuntimeVariables: RuntimeVariables = EmptyRuntimeVariables(),
                            overrideToBigDecimal: Set[String] = Set.empty): Unit = {
    it should testName in {

      inputs.keys.toSeq.sorted should contain theSameElementsAs query.dependsOn.toSeq.sorted

      val resultDF = query.runTableETL(sparkSession, inputs, udfsMap, mapRuntimeVariables)

      val convertedResultSet = resultDF.as[A].collect().toSeq

      checkThatDataFramesAreEqual(resultDF, expectedOutput)

      convertedResultSet should contain theSameElementsAs expectedOutput
    }
  }

  def dfFromResource (resourceName: String) : DataFrame = {
    val config = this.getClass.getClassLoader.getResource("CDRExternalDataTypeMap.txt").getPath

    ResourceConverter(ResourceInput(resourceName,config,spark)).convert
  }
}