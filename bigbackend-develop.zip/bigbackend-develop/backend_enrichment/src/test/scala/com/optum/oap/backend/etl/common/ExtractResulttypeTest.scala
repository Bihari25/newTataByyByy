package com.optum.oap.backend.etl.common

import com.optum.oap.backend.BEQueryTestFramework
import com.optum.oap.backend.etl.common.ExtractResulttype.extract_resulttype
import org.apache.spark.sql.functions.lit
import org.junit.runner.RunWith
import org.scalatest.Matchers._
import org.scalatest.junit.JUnitRunner

@RunWith(classOf[JUnitRunner])
class ExtractResulttypeTest extends BEQueryTestFramework{

  behavior of "extract_resulttype udf"

  it should "extract resulttype from given string" in {

    val actualOutcome = Seq(

      extract_resulttype(lit("Positive")).expr.eval().toString
      , extract_resulttype(lit("Negative")).expr.eval().toString
      , extract_resulttype(lit("Moderate")).expr.eval().toString
      , extract_resulttype(lit(":Normal")).expr.eval().toString
      , extract_resulttype(lit("abnormal")).expr.eval()

    )

    val expectedOutcome = Seq(

      "CH000651"
      , "CH000652"
      , "CH000MOD"
      , "CH001203"
      , null

    )

    actualOutcome shouldBe expectedOutcome
  }
}