package com.optum.oap.backend.etl.bpo.bpo_pyr_ii_8_1

import java.sql.Timestamp

import com.optum.oap.backend.BEQueryTestFramework
import com.optum.oap.backend.cdrTempModel.monthly_payer_member_ii_8_1
import com.optum.oap.cdr.models.{zo_bpo_map_employer, _}
import org.apache.spark.sql.DataFrame


class MONTHLY_PAYER_MEMBER_II_8_1_EXTRACT_Test extends BEQueryTestFramework {

  import spark.implicits._

  val ppBpoMemberDetail: DataFrame = mkDataFrame(
    pp_bpo_member_detail(memberid = "123", healthplansource = "PAYER", groupid = "H000000", firstname = "fname", lastname = "lname", address1 = "address1", address2 = "address2", subscriberid = "123", effectivedate = java.sql.Timestamp.valueOf("2018-06-15 00:00:00"), enddate = java.sql.Timestamp.valueOf("2018-08-18 00:00:00"), employeraccountid = "BCBS"),
    pp_bpo_member_detail(memberid = "m1", healthplansource = "PAYER", groupid = "H000000", address1 = "address1", address2 = "this is a long long long long long long long long long long long long long long long long ", subscriberid = "m1", effectivedate = java.sql.Timestamp.valueOf("2019-06-13 00:00:00"), enddate = java.sql.Timestamp.valueOf("2019-07-20 00:00:00"), employeraccountid = "BCBS"),
    pp_bpo_member_detail(memberid = "m2", healthplansource = "PAYER", groupid = "H000000", address1 = "address1", address2 = "address2", subscriberid = "m2", effectivedate = java.sql.Timestamp.valueOf("2019-06-18 00:00:00"), enddate = java.sql.Timestamp.valueOf("2019-07-11 00:00:00"), employeraccountid = "BCBS" , date_of_death = java.sql.Timestamp.valueOf("2020-10-26 00:00:00")),
    pp_bpo_member_detail(memberid = "m3", healthplansource = "plan source", groupid = "H000000", address1 = "address1", address2 = "address2", subscriberid = "m2", effectivedate = java.sql.Timestamp.valueOf("2019-06-18 00:00:00"), enddate = java.sql.Timestamp.valueOf("2019-07-11 00:00:00"), employeraccountid = "BCBS" , date_of_death = java.sql.Timestamp.valueOf("2020-10-26 00:00:00"))
  )
  val zo_bpo_map_employerIn: DataFrame = mkDataFrame(
    zo_bpo_map_employer(groupid = "H000000", client_ds_id = 1, employeraccountid = "BCBS"),
    zo_bpo_map_employer(groupid = "H000000", client_ds_id = 2, employeraccountid = "BCBS")

  )
  val ppBpoMemberDetail_ii: DataFrame = mkDataFrame(

    pp_bpo_member_detail_ii(groupid = "H000000", memberid = "123", firstname = "fn", lastname = "ln", pharmacy = "Y", effectivedate = Timestamp.valueOf("2016-07-01 00:00:00"), enddate = Timestamp.valueOf("2016-09-30 00:00:00"), dob = Timestamp.valueOf("2010-08-16 00:00:00"), gender = "F", pcpid = "21", productcode = "MDE", subscriberid = "123", healthplansource = "PAYER", employeraccountid = "BCBS",
      medical = "Y", mentalhealth = "Y", coverageclasscode = "code1", subscriberflag = "Y", mapsource = "*", lineofbusinessid = 1, race = 9, race_datasrc = "29", ethnicity = 19, ethnicity_datasrc = "99", spoken_language = "31", spoken_language_datasrc = "49", dental_benefit = "Y", mh_inpatient_benefit = "Y", mh_intensive_benefit = "Y", mh_outpatient_benefit = "Y", cd_inpatient_benefit = "Y",
      cd_intensive_benefit = "Y", cd_outpatient_benefit = "Y", hospice_benefit = "N", date_of_death = Timestamp.valueOf("2020-02-18 00:00:00"), deceased_flag = "Y", ecds_flag = "Y", primary_coverage_flag = "Y", mcoid = "H000000", contract_id = "CMS", at_risk_status = "Y", cust_mem_attr1 = "WA", coveragestatus = "MED", emp_acct_id = "BCBS", contracttype = "c", benefitplan = "b", hra_ind = 0, hsa_ind = 0),

    pp_bpo_member_detail_ii(groupid = "H000000", memberid = "g1", state = "MA", zipcode = "00111", effectivedate = Timestamp.valueOf("2016-10-01 00:00:00"), enddate = Timestamp.valueOf("2016-10-31 00:00:00"), dob = Timestamp.valueOf("2010-08-16 00:00:00"), gender = "M", pcpid = "22", pharmacy = "N", productcode = "MDE", subscriberid = "324", healthplansource = "PAYER", employeraccountid = "BCBS",
      medical = "Y", mentalhealth = "Y", coverageclasscode = "code1", subscriberflag = "Y", mapsource = "*", lineofbusinessid = 1, race = 9, race_datasrc = "29", ethnicity = 19, ethnicity_datasrc = "99", spoken_language = "31", spoken_language_datasrc = "49", dental_benefit = "Y", mh_inpatient_benefit = "Y", mh_intensive_benefit = "Y", mh_outpatient_benefit = "Y", cd_inpatient_benefit = "Y",
      cd_intensive_benefit = "Y", cd_outpatient_benefit = "Y", hospice_benefit = "N", date_of_death = Timestamp.valueOf("2017-11-17 00:00:00"), deceased_flag = "Y", ecds_flag = "Y", primary_coverage_flag = "Y", mcoid = "H000000", contract_id = "CMS", at_risk_status = "Y", cust_mem_attr1 = "WA", coveragestatus = "MED", emp_acct_id = "BCBS", contracttype = "c", benefitplan = "b", hra_ind = 0, hsa_ind = 0),

    pp_bpo_member_detail_ii(groupid = "H000000", memberid = "g1", state = "MA", zipcode = "00111", effectivedate = Timestamp.valueOf("2016-10-01 00:00:00"), enddate = Timestamp.valueOf("2016-10-31 00:00:00"), dob = Timestamp.valueOf("2010-08-16 00:00:00"), gender = "M", pcpid = "22", pharmacy = "N", productcode = "MDE", subscriberid = "324", healthplansource = "source", employeraccountid = "BCBS",
      medical = "Y", mentalhealth = "Y", coverageclasscode = "code1", subscriberflag = "Y", mapsource = "*", lineofbusinessid = 1, race = 9, race_datasrc = "29", ethnicity = 19, ethnicity_datasrc = "99", spoken_language = "31", spoken_language_datasrc = "49", dental_benefit = "Y", mh_inpatient_benefit = "Y", mh_intensive_benefit = "Y", mh_outpatient_benefit = "Y", cd_inpatient_benefit = "Y",
      cd_intensive_benefit = "Y", cd_outpatient_benefit = "Y", hospice_benefit = "N", date_of_death = Timestamp.valueOf("2017-11-17 00:00:00"), deceased_flag = "Y", ecds_flag = "Y", primary_coverage_flag = "Y", mcoid = "H000000", contract_id = "CMS", at_risk_status = "Y", cust_mem_attr1 = "WA", coveragestatus = "MED", emp_acct_id = "BCBS", contracttype = "c", benefitplan = "b", hra_ind = 0, hsa_ind = 0)

  )

  val expectedOutput: Seq[monthly_payer_member_ii_8_1] = Seq(
    monthly_payer_member_ii_8_1(member = "123", geo_lat = "", geo_lon = "", coverage_status = "MED", pcp_id = "21", sex = "1", rx = "1", med = "1", eff_dt = "2016-07-01", dob = "2010-08-16", subscriber_id = "123_2", end_dt = "2016-09-30", map_srce_e = "1", last_name = "ln", first_name = "fn", full_name = "ln,fn", cust_mem_pk_id = "123001", at_risk_status = "Y", den = "1", mh = "1", hsa_ind = "0", hra_ind = "0", cust_mem_1 = "WA", date_of_death
      = "2020-02-18"),
    monthly_payer_member_ii_8_1(member = "g1", geo_lat = "", geo_lon = "", coverage_status = "MED", pcp_id = "22", sex = "0", rx = "0", med = "1", state_n = "MA", zip_n = "00111", dob = "2010-08-16", subscriber_id = "324_2", eff_dt = "2016-10-01", end_dt = "2016-10-31", map_srce_e = "1", cust_mem_pk_id = "g1001", at_risk_status = "Y", den = "1", mh = "1", hsa_ind = "0", hra_ind = "0", cust_mem_1 = "WA", date_of_death = "2017-11-17"),
    monthly_payer_member_ii_8_1(member = "m1", geo_lat = "", geo_lon = "", sex = "0", subscriber_id = "m1_2", rx = "0", med = "0", eff_dt = "2019-06-13", end_dt = "2019-07-20", map_srce_e = "1", cust_mem_pk_id = "m1001", address = "address1 this is a long long long long long long long long long long long long long long long long ", den = "0", mh = "0"),
    monthly_payer_member_ii_8_1(member = "m2", geo_lat = "", geo_lon = "", sex = "0", subscriber_id = "m2_2", rx = "0", med = "0", eff_dt = "2019-06-18", end_dt = "2019-07-11", map_srce_e = "1", cust_mem_pk_id = "m2001", address = "address1 address2", den = "0", mh = "0", date_of_death = "2020-10-26")
  )

  testQuery(
    testName = "test MONTHLY_PAYER_MEMBER_II_8_1_EXTRACT_Test",
    query = MONTHLY_PAYER_MEMBER_II_8_1_EXTRACT,
    inputs = Map(
      "PP_BPO_MEMBER_DETAIL" -> ppBpoMemberDetail,
      "ZO_BPO_MAP_EMPLOYER" -> zo_bpo_map_employerIn,
      "PP_BPO_MEMBER_DETAIL_II" -> ppBpoMemberDetail_ii
    ),
    expectedOutput = expectedOutput
  )

}
