package com.optum.oap.backend.etl.bpo.bpo_pyr_hedis_qme

import com.optum.oap.backend.BEQueryTestFramework
import com.optum.oap.backend.cdrTempModel.hedis_monthly_phm_extract_qme
import com.optum.oap.cdr.models.{denied_ind_rollup, pp_bpo_member_detail, pp_bpo_pharmacy_claims, pp_bpo_provider_detail}
import org.apache.spark.sql.DataFrame

class HEDIS_MONTHLY_PHM_EXTRACT_QME_Test extends BEQueryTestFramework{

  import spark.implicits._


  val ppBpoMemberDetail : DataFrame = mkDataFrame(
    pp_bpo_member_detail(memberid = "m1", groupid = "H000000", employeraccountid = "employer account id 1", healthplansource = "PAYER", lineofbusinessid = 1, enddate = java.sql.Timestamp.valueOf("2020-01-31 00:00:00"), effectivedate = java.sql.Timestamp.valueOf("2020-01-31 00:00:00"), dob = java.sql.Timestamp.valueOf("2020-02-20 00:00:00"), city = "city 1", gender = "gender1", firstname = "firstname1", lastname = "lastname1", address1 = "address1", address2 = "address2", state = "state1", zipcode = "zipcode1" ),
    pp_bpo_member_detail(memberid = "m2", groupid = "H000000", employeraccountid = "employer account id 2", healthplansource = "PAYER", lineofbusinessid = 1, enddate = java.sql.Timestamp.valueOf("2020-02-20 00:00:00"), effectivedate = java.sql.Timestamp.valueOf("2020-03-30 00:00:00"), dob = java.sql.Timestamp.valueOf("2020-01-30 00:00:00"), city = "city 2", gender = "gender1", firstname = "firstname1", lastname = "lastname1", address1 = "address1", address2 = "address2", state = "state1", zipcode = "zipcode1" ),
    pp_bpo_member_detail(memberid = "m3", groupid = "H000000", employeraccountid = "employer account id 3", healthplansource = "PAYER", lineofbusinessid = 1, enddate = java.sql.Timestamp.valueOf("2020-03-20 00:00:00"), effectivedate = java.sql.Timestamp.valueOf("2020-02-20 00:00:00"), dob = java.sql.Timestamp.valueOf("2020-03-20 00:00:00"), city = "city 3", gender = "gender1", firstname = "firstname1", lastname = "lastname1", address1 = "address1", address2 = "address2", state = "state1", zipcode = "zipcode1" ),
    pp_bpo_member_detail(memberid = "m4", groupid = "H000000", employeraccountid = "employer account id 4", healthplansource = "PAYER", lineofbusinessid = 1, enddate = java.sql.Timestamp.valueOf("2020-01-20 00:00:00"), effectivedate = java.sql.Timestamp.valueOf("2020-01-20 00:00:00"), dob = java.sql.Timestamp.valueOf("2020-02-20 00:00:00"), city = "city 4", gender = "gender1", firstname = "firstname1", lastname = "lastname1", address1 = "address1", address2 = "address2", state = "state1", zipcode = "zipcode1" ),
    pp_bpo_member_detail(memberid = "m5", groupid = "H000000", employeraccountid = "employer account id 4", healthplansource = "PAYER", lineofbusinessid = 1, enddate = java.sql.Timestamp.valueOf("2020-04-20 00:00:00"), effectivedate = java.sql.Timestamp.valueOf("2020-04-20 00:00:00"), dob = java.sql.Timestamp.valueOf("2020-03-20 00:00:00"), city = "city 5", gender = "gender1", firstname = "firstname1", lastname = "lastname1", address1 = "address1", address2 = "address2", state = "state1", zipcode = "zipcode1" ),
    pp_bpo_member_detail(memberid = "m6", groupid = "H000000", employeraccountid = "employer account id 3", healthplansource = "NOT PAYER", lineofbusinessid = 1, enddate = java.sql.Timestamp.valueOf("2020-05-20 00:00:00"))
  )


  val deniedIndRollup: DataFrame = mkDataFrame(
    denied_ind_rollup(groupid = "H000000", denied_flag = "Y", denied_ind_rollup = "Y"),
    denied_ind_rollup(groupid = "H000000", denied_flag = "N", denied_ind_rollup = "N")
  )

  val ppBpoPharmacyClaims: DataFrame = mkDataFrame(
    pp_bpo_pharmacy_claims(groupid = "H000000", memberid = "m1", prescprovider = "prov 1",paidamount = 12.21, healthplansource = "PAYER", servicedate = java.sql.Timestamp.valueOf("2020-01-01 00:00:00"), deniedflag = "Y"),
    pp_bpo_pharmacy_claims(groupid = "H000000", memberid = "m2", pharmacyid = "prov 2",healthplansource = "PAYER", servicedate = java.sql.Timestamp.valueOf("2018-01-01 00:00:00")),
    pp_bpo_pharmacy_claims(groupid = "H000000", memberid = "m3", healthplansource = "PAYER", servicedate = java.sql.Timestamp.valueOf("2013-01-01 00:00:00"))
  )

  val ppBpoProviderDetail: DataFrame = mkDataFrame(
    pp_bpo_provider_detail(groupid = "H000000", providerid = "prov 1", specialty = "specialty 1", npi = "1234"),
    pp_bpo_provider_detail(groupid = "H000000", providerid = "prov 2", specialty = "specialty 1", npi = "1234")
  )


  val expectedOutput: Seq[hedis_monthly_phm_extract_qme] = Seq(
    hedis_monthly_phm_extract_qme(MemberID = "m1", ServiceDate = "2020-01-01", HealthPlanSource = "PAYER", IsDenied = "Y" , PrescribingProviderID = "prov 1", ProviderNPI = "1234", PharmacyNPI = null),
    hedis_monthly_phm_extract_qme(MemberID = "m2", ServiceDate = "2018-01-01", HealthPlanSource = "PAYER", IsDenied = "N" , PrescribingProviderID = null, ProviderNPI = null, PharmacyNPI = "1234"),
    hedis_monthly_phm_extract_qme(MemberID = "m3", ServiceDate = "2013-01-01", HealthPlanSource = "PAYER", IsDenied = "N" , PrescribingProviderID = null, ProviderNPI = null, PharmacyNPI = null)
  )

  testQuery(
    testName = "test HEDIS_MONTHLY_PHM_EXTRACT_QME",
    query = HEDIS_MONTHLY_PHM_EXTRACT_QME,
    inputs = Map(
      "PP_BPO_MEMBER_DETAIL" -> ppBpoMemberDetail,
      "DENIED_IND_ROLLUP" -> deniedIndRollup,
      "PP_BPO_PHARMACY_CLAIMS" -> ppBpoPharmacyClaims,
      "PP_BPO_PROVIDER_DETAIL" -> ppBpoProviderDetail
    ),
    expectedOutput = expectedOutput
  )

}
