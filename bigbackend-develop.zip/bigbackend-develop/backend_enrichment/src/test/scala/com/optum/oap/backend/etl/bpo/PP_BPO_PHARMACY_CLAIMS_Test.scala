package com.optum.oap.backend.etl.bpo

import java.sql.{Date, Timestamp}

import com.optum.oap.backend.BEQueryTestFramework
import com.optum.oap.backend.cdrTempModel.{temp_bpo_calculate_params, temp_bpo_patients}
import com.optum.oap.cdr.models.{denied_ind_rollup, _}
import org.apache.spark.sql.DataFrame

/**
  *
  * Copyright 2019 Optum Analytics
  *
  * Date: 6/13/19
  *
  * Creator: pavula1
  */
class PP_BPO_PHARMACY_CLAIMS_Test extends BEQueryTestFramework {

  import spark.implicits._

  val rxOrderIn: DataFrame = mkDataFrame(
    rxorder(groupid = "H000000", client_ds_id = 1, cust_attr_1 = "1", cust_attr_17 = 2.0, grp_mpi = "g1", dcc = "2", ndc11 = "n1", sales_tax_amt = 12.23, capitated_service_ind = 1, adjusted_rx_cnt = 3, coord_benefits_amt = 23.98, network_paid_status = "In", coinsurance_amt = 30.0, deductable_amt = 1000.0, pat_liability_amt = 250.0, fillnum = 1, denied_flag = "Y", pseudo_flag = "N", copay_amt = 20.0, localdaysupplied = 1, quantityperfill = "2", paidamount = 200.0, allowedamount = 200.0, charge = 300.0, post_dt = Timestamp.valueOf("2017-4-02 00:00:00"), issuedate = Timestamp.valueOf("2017-4-02 00:00:00"), mstrprovid = "12", generic_status = "s1", formulary_indicator = "l1", spec_rx_ind = "s1", pharmacy_id = "123", fulfillment_type_cd = "c1", localdaw = "c1", rxid = "r1", other_1_amt = 2.0),
    rxorder(groupid = "H000000", client_ds_id = 1, grp_mpi = "g2", dcc = "3", ndc11 = "n2", admin_fee_amt = 23.34, dispensing_fee = 22.12, network_paid_status = "Out", coinsurance_amt = 50.0, deductable_amt = 2000.0, pat_liability_amt = 200.0, denied_flag = "N", pseudo_flag = "Y", copay_amt = 50.0, localdaysupplied = 2, quantityperfill = "4", paidamount = 400.0, allowedamount = 400.0, charge = 200.0, issuedate = Timestamp.valueOf("2016-6-01 00:00:00"), mstrprovid = "11", generic_status = "s2", formulary_indicator = "l2", pharmacy_id = "123", fulfillment_type_cd = "c2", localdaw = "c1", rxid = "r2", presc_prov_affil_id = "prov affil id 1"),
    rxorder(groupid = "H000000", client_ds_id = 1, not_covered_amt = 23.45, other_carrier_pay_amt = 12.23, ingredient_cost_paid = 101.234, grp_mpi = "g3", dcc = "4", ndc11 = "n3", network_paid_status = "Out", coinsurance_amt = 50.0, deductable_amt = 2000.0, pat_liability_amt = 200.0, denied_flag = "N", pseudo_flag = "Y", copay_amt = 50.0, localdaysupplied = 2, quantityperfill = "4", paidamount = 400.0, allowedamount = 400.0, charge = 200.0, issuedate = Timestamp.valueOf("2016-6-01 00:00:00"), pharmacy_id = "123", fulfillment_type_cd = "c1", localdaw = "c1", rxid = "r3", presc_prov_status_id = "status3")
  )

  val zo_bpo_map_employerIn: DataFrame = mkDataFrame(
    zo_bpo_map_employer(groupid = "H000000", client_ds_id = 1, employeraccountid = "BCBS")
  )

  val temp_patients_in: DataFrame = mkDataFrame(
    temp_bpo_patients(groupid = "H000000", grp_mpi = "g1", payer = 1),
    temp_bpo_patients(groupid = "H000000", grp_mpi = "g2", payer = 1),
    temp_bpo_patients(groupid = "H000000", grp_mpi = "g3", payer = 1)
  )

  val mapStatus: DataFrame = mkDataFrame(
    map_generic_status(localcode = "s1", groupid = "H000000", cui = "CH003870"),
    map_generic_status(localcode = "s2", groupid = "H000000", cui = "CH003872")
  )

  val params: DataFrame = mkDataFrame(
    temp_bpo_calculate_params(engineStartDate = Date.valueOf("2015-04-01"), engineStartDate2 = Date.valueOf("2015-04-01"), engineStartDate3 = Date.valueOf("2015-04-01"), engineEndDate = Date.valueOf("2019-03-31"), startDate = Date.valueOf("2015-01-01"))
  )

  val mapIndicator: DataFrame = mkDataFrame(
    map_formulary_indicator(groupid = "H000000", localcode = "l1", cui = "CH003875"),
    map_formulary_indicator(groupid = "H000000", localcode = "l2", cui = "CH003873")
  )

  val providerSpans: DataFrame = mkDataFrame(
    pp_bpo_provider_detail_spans(providerid = "12", prov_effective_dt = Timestamp.valueOf("2015-4-01 00:00:00"), prov_end_dt = Timestamp.valueOf("2018-4-01 00:00:00"), provider_status = "status", provaffiliationid = "prov affialiation id 1"),
    pp_bpo_provider_detail_spans(providerid = "11", prov_effective_dt = Timestamp.valueOf("2015-8-01 00:00:00"), prov_end_dt = Timestamp.valueOf("2018-4-01 00:00:00"), provider_status = "status2")
  )

  val zhProvider: DataFrame = mkDataFrame(
    zh_provider(client_ds_id = 1, groupid = "H000000", localproviderid = "123",master_hgprovid = "123")
  )

  val refHtsNdcCurrent: DataFrame = mkDataFrame(
    ref_hts_ndc_current(hum_gen_med_key = "M.233.02.01.0662", dcc = "00002", hts_generic = "Metronidazole", hum_med_key = "M.233.02.01", hts_generic_ext = null, ndc = "n1", gbo_ind = "1"),
    ref_hts_ndc_current(hum_gen_med_key = "M.233.02.01.0662", dcc = "00002", hts_generic = "Metronidazole", hum_med_key = "M.233.02.01", hts_generic_ext = null, ndc = "n2", gbo_ind = "10")
  )

  val mapRxFulfillmentType: DataFrame = mkDataFrame(
    map_rx_fulfillment_type(groupid = "H000000", localcode = "c1", cui = "CH004108")
  )

  val mapDaw: DataFrame = mkDataFrame(
    map_daw(groupid = "H000000", mnemonic = "c1", cui = "c11")
  )

  val zoDaw: DataFrame = mkDataFrame(
    zo_daw(hts_cui = "c11",daw_code = "1")
  )
  val deniedIndRollup: DataFrame = mkDataFrame(
    denied_ind_rollup(groupid = "H000000", denied_flag = "Y", denied_ind_rollup = "Y"),
    denied_ind_rollup(groupid = "H000000", denied_flag = "N", denied_ind_rollup = "N")
  )

  val expectedOutput: Seq[pp_bpo_pharmacy_claims] = Seq(
    pp_bpo_pharmacy_claims(groupid = "H000000", memberid = "g1", other_1_amt = 2.0, cust_attr_1 = "1", cust_attr_17 = 2.0, coord_benefits_amt = 23.98, daw = 1, sales_tax_amt = 12.23, capitated_service_ind = 1, adjusted_rx_cnt = 3, paymentdate = Timestamp.valueOf("2017-4-02 00:00:00"), spec_rx_ind = "s1", servicedate = Timestamp.valueOf("2017-4-02 00:00:00"), ndc = "n1", dayssupply = 1, quantity = 2, prescprovider = "12", coverageclasscode = "MED", healthplansource = "PAYER", claimheader = "PHM1.2", networkstatus = "Y", mapsource = "AD", paidamount = 200.0, allowedamount = 200.0, denied_ind = "Y",
      requestedamount = 300.0, quantity_dispensed = 2, employeraccountid = "BCBS", fillnum = 1, contract_id = "BCBS", network_paid_status = "In", pharmacytype = "0", copayamount = 20.0, coinsamount = 30.0, deductamount = 1000.0, patliabamount = 250.0, deniedflag = "Y", pseudoflag = "N", provider_status = "status", genericstatus = "2", formulary = "3", rxid = "r1", pharmacyid = "123", presc_prov_affil_id = "prov affialiation id 1"),
    pp_bpo_pharmacy_claims(groupid = "H000000", dispensingfee = 22.12, memberid = "g2", admin_fee_amt = 23.34, daw = 1, paymentdate = Timestamp.valueOf("2016-6-01 00:00:00"), pharmacytype = "2", servicedate = Timestamp.valueOf("2016-6-01 00:00:00"), ndc = "n2", dayssupply = 2, quantity = 4, prescprovider = "11", coverageclasscode = "MED", healthplansource = "PAYER", claimheader = "PHM1.1", networkstatus = "Y", mapsource = "AD", paidamount = 400.0, allowedamount = 400.0, denied_ind = "N",
      requestedamount = 200.0, quantity_dispensed = 4, employeraccountid = "BCBS", contract_id = "BCBS", network_paid_status = "Out", copayamount = 50.0, coinsamount = 50.0, deductamount = 2000.0, patliabamount = 200.0, deniedflag = "N", pseudoflag = "Y", provider_status = "status2", genericstatus = "9", formulary = "0", rxid = "r2",pharmacyid = "123", presc_prov_affil_id = "prov affil id 1"),
    pp_bpo_pharmacy_claims(groupid = "H000000", ingredientcost = 101.234, memberid = "g3", daw = 1, paymentdate = Timestamp.valueOf("2016-6-01 00:00:00"), pharmacytype = "0", servicedate = Timestamp.valueOf("2016-6-01 00:00:00"), ndc = "n3", dayssupply = 2, quantity = 4, coverageclasscode = "MED", healthplansource = "PAYER", claimheader = "PHM1.3", networkstatus = "Y", mapsource = "AD", paidamount = 400.0, allowedamount = 400.0, denied_ind = "N",
      requestedamount = 200.0, quantity_dispensed = 4, not_covered_amt = 23.45, other_carrier_pay_amt = 12.23, employeraccountid = "BCBS", contract_id = "BCBS", network_paid_status = "Out", copayamount = 50.0, coinsamount = 50.0, deductamount = 2000.0, patliabamount = 200.0, deniedflag = "N", pseudoflag = "Y", provider_status = "status3", formulary = "5", rxid = "r3", pharmacyid = "123")
  )

  testQuery(
    testName = "test PP_BPO_PHARMACY_CLAIMS",
    query = PP_BPO_PHARMACY_CLAIMS,
    inputs = Map(
      "RXORDER" -> rxOrderIn,
      "ZO_BPO_MAP_EMPLOYER" -> zo_bpo_map_employerIn,
      "TEMP_BPO_CALCULATE_PARAMS" -> params,
      "MAP_GENERIC_STATUS" -> mapStatus,
      "TEMP_BPO_PATIENTS" -> temp_patients_in,
      "MAP_FORMULARY_INDICATOR" -> mapIndicator,
      "TEMP_PP_BPO_PROVIDER_DETAIL_SPANS" -> providerSpans,
      "ZH_PROVIDER" -> zhProvider,
      "REF_HTS_NDC_CURRENT" -> refHtsNdcCurrent,
      "MAP_RX_FULFILLMENT_TYPE" -> mapRxFulfillmentType,
      "MAP_DAW" -> mapDaw,
      "ZO_DAW" -> zoDaw,
      "DENIED_IND_ROLLUP" -> deniedIndRollup
    ),
    expectedOutput = expectedOutput
  )

  val rxOrderIn1: DataFrame = mkDataFrame(
    rxorder(groupid = "H000000", client_ds_id = 1, cust_attr_1 = "1", cust_attr_17 = 2.0, grp_mpi = "g1", dcc = "2", ndc11 = "n1", sales_tax_amt = 12.23, capitated_service_ind = 1, adjusted_rx_cnt = 3, coord_benefits_amt = 23.98, network_paid_status = "In", coinsurance_amt = 30.0, deductable_amt = 1000.0, pat_liability_amt = 250.0, fillnum = 1, denied_flag = "Y", pseudo_flag = "N", copay_amt = 20.0, localdaysupplied = 1, quantityperfill = "2", paidamount = 200.0, allowedamount = 200.0, charge = 300.0, post_dt = Timestamp.valueOf("2017-4-02 00:00:00"), issuedate = Timestamp.valueOf("2017-4-02 00:00:00"), mstrprovid = "12", generic_status = "s1", formulary_indicator = "l1", spec_rx_ind = "s1", pharmacy_id = "123", fulfillment_type_cd = "c1", localdaw = "c1", rxid = "r1", other_1_amt = 2.0),
    rxorder(groupid = "H000000", client_ds_id = 1, grp_mpi = "g2", dcc = "3", ndc11 = "n2", admin_fee_amt = 23.34, dispensing_fee = 22.12, network_paid_status = "Out", coinsurance_amt = 50.0, deductable_amt = 2000.0, pat_liability_amt = 200.0, denied_flag = "N", pseudo_flag = "Y", copay_amt = 50.0, localdaysupplied = 2, quantityperfill = "4", paidamount = 400.0, allowedamount = 400.0, charge = 200.0, issuedate = Timestamp.valueOf("2016-6-01 00:00:00"), mstrprovid = "11", generic_status = "s2", formulary_indicator = "l2", pharmacy_id = "123", fulfillment_type_cd = "c2", localdaw = "c1", rxid = "r2", presc_prov_affil_id = "prov affil id 1"),
    rxorder(groupid = "H000000", client_ds_id = 1, not_covered_amt = 23.45, other_carrier_pay_amt = 12.23, ingredient_cost_paid = 101.234, grp_mpi = "g3", dcc = "4", ndc11 = "n3", network_paid_status = "Out", coinsurance_amt = 50.0, deductable_amt = 2000.0, pat_liability_amt = 200.0, denied_flag = "N", pseudo_flag = "Y", copay_amt = 50.0, localdaysupplied = 2, quantityperfill = "4", paidamount = 400.0, allowedamount = 400.0, charge = 200.0, issuedate = Timestamp.valueOf("2016-6-01 00:00:00"), pharmacy_id = "123", fulfillment_type_cd = "c1", localdaw = "c1", rxid = "r3", presc_prov_status_id = "status3")
  )

  val providerSpans1: DataFrame = mkDataFrame(
    pp_bpo_provider_detail_spans(providerid = "12", prov_effective_dt = Timestamp.valueOf("2015-4-01 00:00:00"), prov_end_dt = Timestamp.valueOf("2018-4-01 00:00:00"), provider_status = "status", provaffiliationid = "prov affialiation id 1"),
    pp_bpo_provider_detail_spans(providerid = "11", prov_effective_dt = Timestamp.valueOf("2015-8-01 00:00:00"), prov_end_dt = Timestamp.valueOf("2018-4-01 00:00:00"), provider_status = "status2")
  )

  val expectedOutput1: Seq[pp_bpo_pharmacy_claims] = Seq(
    pp_bpo_pharmacy_claims(groupid = "H000000", memberid = "g1", other_1_amt = 2.0, cust_attr_1 = "1", cust_attr_17 = 2.0, coord_benefits_amt = 23.98, daw = 1, sales_tax_amt = 12.23, capitated_service_ind = 1, adjusted_rx_cnt = 3, paymentdate = Timestamp.valueOf("2017-4-02 00:00:00"), spec_rx_ind = "s1", servicedate = Timestamp.valueOf("2017-4-02 00:00:00"), ndc = "n1", dayssupply = 1, quantity = 2, prescprovider = "12", coverageclasscode = "MED", healthplansource = "PAYER", claimheader = "PHM1.2", networkstatus = "Y", mapsource = "AD", paidamount = 200.0, allowedamount = 200.0, denied_ind = "Y",
      requestedamount = 300.0, quantity_dispensed = 2, employeraccountid = "BCBS", fillnum = 1, contract_id = "BCBS", network_paid_status = "In", pharmacytype = "0", copayamount = 20.0, coinsamount = 30.0, deductamount = 1000.0, patliabamount = 250.0, deniedflag = "Y", pseudoflag = "N", provider_status = "status", genericstatus = "2", formulary = "3", rxid = "r1", pharmacyid = "123", presc_prov_affil_id = "prov affialiation id 1"),
    pp_bpo_pharmacy_claims(groupid = "H000000", dispensingfee = 22.12, memberid = "g2", admin_fee_amt = 23.34, daw = 1, paymentdate = Timestamp.valueOf("2016-6-01 00:00:00"), pharmacytype = "2", servicedate = Timestamp.valueOf("2016-6-01 00:00:00"), ndc = "n2", dayssupply = 2, quantity = 4, prescprovider = "11", coverageclasscode = "MED", healthplansource = "PAYER", claimheader = "PHM1.1", networkstatus = "Y", mapsource = "AD", paidamount = 400.0, allowedamount = 400.0, denied_ind = "N",
      requestedamount = 200.0, quantity_dispensed = 4, employeraccountid = "BCBS", contract_id = "BCBS", network_paid_status = "Out", copayamount = 50.0, coinsamount = 50.0, deductamount = 2000.0, patliabamount = 200.0, deniedflag = "N", pseudoflag = "Y", provider_status = "status2", genericstatus = "9", formulary = "0", rxid = "r2",pharmacyid = "123", presc_prov_affil_id = "prov affil id 1"),
    pp_bpo_pharmacy_claims(groupid = "H000000", ingredientcost = 101.234, memberid = "g3", daw = 1, paymentdate = Timestamp.valueOf("2016-6-01 00:00:00"), pharmacytype = "0", servicedate = Timestamp.valueOf("2016-6-01 00:00:00"), ndc = "n3", dayssupply = 2, quantity = 4, coverageclasscode = "MED", healthplansource = "PAYER", claimheader = "PHM1.3", networkstatus = "Y", mapsource = "AD", paidamount = 400.0, allowedamount = 400.0, denied_ind = "N",
      requestedamount = 200.0, quantity_dispensed = 4, not_covered_amt = 23.45, other_carrier_pay_amt = 12.23, employeraccountid = "BCBS", contract_id = "BCBS", network_paid_status = "Out", copayamount = 50.0, coinsamount = 50.0, deductamount = 2000.0, patliabamount = 200.0, deniedflag = "N", pseudoflag = "Y", provider_status = "status3", formulary = "5", rxid = "r3", pharmacyid = "123")
  )

  testQuery(
    testName = "test PP_BPO_PHARMACY_CLAIMS presc_prov_affil_id",
    query = PP_BPO_PHARMACY_CLAIMS,
    inputs = Map(
      "RXORDER" -> rxOrderIn1,
      "ZO_BPO_MAP_EMPLOYER" -> zo_bpo_map_employerIn,
      "TEMP_BPO_CALCULATE_PARAMS" -> params,
      "MAP_GENERIC_STATUS" -> mapStatus,
      "TEMP_BPO_PATIENTS" -> temp_patients_in,
      "MAP_FORMULARY_INDICATOR" -> mapIndicator,
      "TEMP_PP_BPO_PROVIDER_DETAIL_SPANS" -> providerSpans1,
      "ZH_PROVIDER" -> zhProvider,
      "REF_HTS_NDC_CURRENT" -> refHtsNdcCurrent,
      "MAP_RX_FULFILLMENT_TYPE" -> mapRxFulfillmentType,
      "MAP_DAW" -> mapDaw,
      "ZO_DAW" -> zoDaw,
      "DENIED_IND_ROLLUP" -> deniedIndRollup
    ),
    expectedOutput = expectedOutput1
  )

}

