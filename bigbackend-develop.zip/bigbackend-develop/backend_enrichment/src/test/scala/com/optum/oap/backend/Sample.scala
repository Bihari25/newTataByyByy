package com.optum.oap.backend

import java.sql.Timestamp
import java.time.Year

import com.optum.oap.cdr.models._

object Sample {

  val groupid = "H000000"
  val grp_mpi = "123456789"
  val dt = Timestamp.valueOf( "2006-08-04 12:00:00" )
  val dt_yr = "2006"
  val dt_month = "08"
  val dt_qtr = "3"
  val mappedcode = "CH000636"
  val codetype = "ICD9"
  val hum_med_key = "M.232.01.04"
  val diag = "146.0"
  val zip5 = "32327"
  val client_ds_id = 12345

  def get_pat_rx_summary: pat_rx_summary = {
    pat_rx_summary( cnt = 1, dt_month = dt_month, dt_qtr = dt_qtr, dt_yr = dt_yr, groupid = groupid, grp_mpi = grp_mpi
      , hum_med_key = hum_med_key )
  }

  def get_pat_labresult_summary: pat_labresult_summary = {
    pat_labresult_summary( cnt = 1, dt_month = dt_month, dt_qtr = dt_qtr, dt_yr = dt_yr, groupid = groupid, grp_mpi = grp_mpi
      , labcui = mappedcode, min_val = 1.0, max_val = 1.0 )
  }

  def get_pat_diag_summary: pat_diag_summary = {
    pat_diag_summary( cnt = 1, dt_month = dt_month, dt_qtr = dt_qtr, dt_yr = dt_yr, groupid = groupid, grp_mpi = grp_mpi
      , codetype = codetype, diag = diag )
  }

  def get_pat_proc_summary: pat_proc_summary = {
    pat_proc_summary( cnt = 1, dt_month = dt_month, dt_qtr = dt_qtr, dt_yr = dt_yr, groupid = groupid, grp_mpi = grp_mpi
      , mappedcode = mappedcode, codetype = codetype )
  }

  def get_patient_summary_grp_mpi: patient_summary_grp_mpi = {
    patient_summary_grp_mpi( groupid = groupid, grp_mpi = grp_mpi, mapped_gender = "CH000033", mapped_zipcode = zip5
      , dob = "19820628", yob = Year.now.getValue().toString() )
  }

  def get_ref_imap_region: ref_imap_region = {
    ref_imap_region(state_desc = "FL", zip = zip5 )
  }

  def get_patient_count: patient_count = {
    patient_count( age = 0, datasource = "ERX", dob = "19820628", gender = "F", groupid = groupid, grp_mpi = grp_mpi
      , state = "FL", year = 2006, yearmo = 200608, zipcode = zip5 )
  }

  def get_zip3_pat_cnt: zip3_pat_cnt = {
    zip3_pat_cnt( groupid = groupid, pat_count = 1, zip3 = "323" )
  }

  def get_diagnosis: diagnosis = {
    diagnosis( groupid = groupid, grp_mpi = grp_mpi, codetype = codetype, mappeddiagnosis = diag
      , dx_timestamp = dt )
  }

  def get_labresult: labresult = {
    labresult( groupid = groupid, grp_mpi = grp_mpi, mappedcode = mappedcode
      , datecollected = dt, normalizedvalue = 1.0 )
  }

  def get_proceduredo: proceduredo = {
    proceduredo( groupid = groupid, grp_mpi = grp_mpi, mappedcode = mappedcode, codetype = codetype
      , proceduredate = dt )
  }

  def get_rxorder: rxorder = {
    rxorder( groupid = groupid, grp_mpi = grp_mpi, issuedate = dt
      , hum_med_key = hum_med_key, map_used = "ndc" )
  }

  def get_zh_lab_dict: zh_lab_dict = {
    zh_lab_dict( groupid = groupid, client_ds_id = client_ds_id )
  }

  def get_v_labcode_results: v_labcode_results = {
    v_labcode_results( groupid = groupid, client_ds_id = client_ds_id, code_value = "local_code", dict_name = "LOCAL NAME"
      , dict_def = "LOCAL DESC", ref_range = "NORMAL RANGE", order_name = "LOCAL TEST NAME", data_type = "LOCAL DATATYPE 1"
      , specimen_name = "local spec type", bodysite_name = "LOCAL BODY SITE 1", local_loinc_code = "code", unit_name = "local units"
      , local_result_inferred = 1.0, localresult = "local result" )
  }

  def get_v_labcode_summary: v_labcode_summary = {
    v_labcode_summary( groupid = groupid, client_ds_id = client_ds_id, code_value = "local_code", dict_name = "LOCAL NAME"
      , dict_def = "LOCAL DESC", ref_range = "NORMAL RANGE", order_name = "LOCAL TEST NAME", data_type = "LOCAL DATATYPE 1"
      , specimen_name = "local spec type", bodysite_name = "LOCAL BODY SITE 1", local_loinc_code = "code", unit_name = "local units"
      , cnt = 1, localresult_text = null
      , percent_num = 0.0, percent_null = 0.0, percent_text = 0.0, cnt_localinf_notnull = 0, cnt_localres_null = 0
      , cnt_num = 0, cnt_null = 0, cnt_text = 0 )
  }
}