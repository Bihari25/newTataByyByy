package com.optum.oap.backend.etl.bpo

import com.optum.oap.backend.BEQueryTestFramework
import com.optum.oap.backend.cdrTempModel.temp_zip
import com.optum.oap.cdr.models.ref_commercial_zipcodes
import org.apache.spark.sql.DataFrame
import org.junit.runner.RunWith
import org.scalatest.junit.JUnitRunner

@RunWith(classOf[JUnitRunner])
class TEMP_ZIP_TEST  extends BEQueryTestFramework {
  import spark.implicits._

  behavior of "translated query TEMP_ZIP"

  val refCommercialZipCodes : DataFrame = mkDataFrame(
    ref_commercial_zipcodes(zipcode = "zip code 1", latitude = 1.0, longitude = 2.0),
    ref_commercial_zipcodes(zipcode = "zip code 1", latitude = 2.0, longitude = 3.0),
    ref_commercial_zipcodes(zipcode = "zip code 2", latitude = 2.0, longitude = 3.0),
    ref_commercial_zipcodes(zipcode = "zip code 3", latitude = 3.0, longitude = 4.0),
    ref_commercial_zipcodes(zipcode = "zip code 4", latitude = 7.0, longitude = 5.0),
    ref_commercial_zipcodes(zipcode = "zip code 4", latitude = 5.0, longitude = 6.0)
  )

  val expectedOutput : Seq[temp_zip] = Seq(
    temp_zip(zipcode = "zip code 1", latitude = 2.0, longitude = 3.0),
    temp_zip(zipcode = "zip code 2", latitude = 2.0, longitude = 3.0),
    temp_zip(zipcode = "zip code 3", latitude = 3.0, longitude = 4.0),
    temp_zip(zipcode = "zip code 4", latitude = 7.0, longitude = 6.0)
  )

  testQuery(
    testName = "test TEMP_ZIP",
    query = TEMP_ZIP,
    inputs = Map(
      "REF_COMMERCIAL_ZIPCODES" -> refCommercialZipCodes
    ),
    expectedOutput = expectedOutput
  )
}
