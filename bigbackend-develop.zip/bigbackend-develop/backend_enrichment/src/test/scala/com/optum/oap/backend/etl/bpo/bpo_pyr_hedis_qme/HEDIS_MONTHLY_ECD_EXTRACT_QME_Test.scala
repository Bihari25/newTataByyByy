package com.optum.oap.backend.etl.bpo.bpo_pyr_hedis_qme

import com.optum.oap.backend.BEQueryTestFramework
import com.optum.oap.backend.cdrTempModel.{hedis_monthly_ecd_extract_qme}
import com.optum.oap.cdr.models.{pp_bpo_clinical_documentation, pp_bpo_member_detail, pp_bpo_pharmacy_clinical}
import org.apache.spark.sql.DataFrame

class HEDIS_MONTHLY_ECD_EXTRACT_QME_Test extends BEQueryTestFramework{

  import spark.implicits._


  val ppBpoMemberDetail : DataFrame = mkDataFrame(
    pp_bpo_member_detail(memberid = "m1", groupid = "H000000", employeraccountid = "employer account id 1", healthplansource = "PAYER", lineofbusinessid = 1, enddate = java.sql.Timestamp.valueOf("2020-01-31 00:00:00"), effectivedate = java.sql.Timestamp.valueOf("2020-01-31 00:00:00"), dob = java.sql.Timestamp.valueOf("2020-02-20 00:00:00"), city = "city 1"),
    pp_bpo_member_detail(memberid = "m2", groupid = "H000000", employeraccountid = "employer account id 2", healthplansource = "PAYER", lineofbusinessid = 1, enddate = java.sql.Timestamp.valueOf("2020-02-20 00:00:00"), effectivedate = java.sql.Timestamp.valueOf("2020-03-30 00:00:00"), dob = java.sql.Timestamp.valueOf("2020-01-30 00:00:00"), city = "city 2"),
    pp_bpo_member_detail(memberid = "m3", groupid = "H000000", employeraccountid = "employer account id 3", healthplansource = "PAYER", lineofbusinessid = 1, enddate = java.sql.Timestamp.valueOf("2020-03-20 00:00:00"), effectivedate = java.sql.Timestamp.valueOf("2020-02-20 00:00:00"), dob = java.sql.Timestamp.valueOf("2020-03-20 00:00:00"), city = "city 3"),
    pp_bpo_member_detail(memberid = "m4", groupid = "H000000", employeraccountid = "employer account id 4", healthplansource = "PAYER", lineofbusinessid = 1, enddate = java.sql.Timestamp.valueOf("2020-01-20 00:00:00"), effectivedate = java.sql.Timestamp.valueOf("2020-01-20 00:00:00"), dob = java.sql.Timestamp.valueOf("2020-02-20 00:00:00"), city = "city 4"),
    pp_bpo_member_detail(memberid = "m5", groupid = "H000000", employeraccountid = "employer account id 4", healthplansource = "PAYER", lineofbusinessid = 1, enddate = java.sql.Timestamp.valueOf("2020-04-20 00:00:00"), effectivedate = java.sql.Timestamp.valueOf("2020-04-20 00:00:00"), dob = java.sql.Timestamp.valueOf("2020-03-20 00:00:00"), city = "city 5"),
    pp_bpo_member_detail(memberid = "m6", groupid = "H000000", employeraccountid = "employer account id 3", healthplansource = "NOT PAYER", lineofbusinessid = 1, enddate = java.sql.Timestamp.valueOf("2020-05-20 00:00:00"))
  )

  val ppBpoPharmacyClinical: DataFrame = mkDataFrame(
    pp_bpo_pharmacy_clinical(groupid = "H000000", memberid = "m1", code = "c11", code_taxonomy = "ct11", healthplansource = "PAYER", administration_date = java.sql.Timestamp.valueOf("2020-01-01 00:00:00"), pharmacy_clinical_id = "p11"),
    pp_bpo_pharmacy_clinical(groupid = "H000000", memberid = "m2", code = "c21", code_taxonomy = "ct21", healthplansource = "PAYER", administration_date = java.sql.Timestamp.valueOf("2019-06-19 00:00:00"), pharmacy_clinical_id = "p21"),
    pp_bpo_pharmacy_clinical(groupid = "H000000", memberid = "m3", code = "c31", code_taxonomy = "ct31", healthplansource = "NOT_PAYER", administration_date = java.sql.Timestamp.valueOf("2020-01-01 00:00:00"), pharmacy_clinical_id = "p31")
  )

  val ppBpoClinicalDocumentation: DataFrame = mkDataFrame(
    pp_bpo_clinical_documentation(groupid = "H000000", memberid = "m1", code = "c11", code_taxonomy = "ct11", healthplansource = "PAYER", documentation_date= java.sql.Timestamp.valueOf("2020-01-01 00:00:00"), clinical_document_id = "p11" , phq9_version = "1", result = "1"),
    pp_bpo_clinical_documentation(groupid = "H000000", memberid = "m2", code = "c21", code_taxonomy = "ct21", healthplansource = "PAYER", documentation_date = java.sql.Timestamp.valueOf("2019-06-19 00:00:00"), clinical_document_id = "p21", phq9_version = "1", result = "1"),
    pp_bpo_clinical_documentation(groupid = "H000000", memberid = "m3", code = "c31", code_taxonomy = "ct31", healthplansource = "NOT_PAYER", documentation_date = java.sql.Timestamp.valueOf("2020-01-01 00:00:00"), clinical_document_id = "p31", phq9_version = "1",result = "1")

  )

  val expectedOutput: Seq[hedis_monthly_ecd_extract_qme] = Seq(
    hedis_monthly_ecd_extract_qme(MemberID = "m1", RecordID = "p11" , RecordType = "C" , CodeTaxonomy = "ct11", Code = "c11" , CodeStartDate = "2020-01-01" , Result = "1" , PHQ9Version = "1" , HealthPlanSource = "PAYER" , MapSource = "SS" ),
    hedis_monthly_ecd_extract_qme(MemberID = "m1", RecordID = "p11" , RecordType = "R" , CodeTaxonomy = "ct11", Code = "c11" , CodeStartDate = "2020-01-01" , Result = null , PHQ9Version = null , HealthPlanSource = "PAYER" , MapSource = "SS" ),
    hedis_monthly_ecd_extract_qme(MemberID = "m2", RecordID = "p21" , RecordType = "C" , CodeTaxonomy = "ct21", Code = "c21" , CodeStartDate = "2019-06-19" , Result = "1" , PHQ9Version = "1" , HealthPlanSource = "PAYER" , MapSource = "SS" ),
    hedis_monthly_ecd_extract_qme(MemberID = "m2", RecordID = "p21" , RecordType = "R" , CodeTaxonomy = "ct21", Code = "c21" , CodeStartDate = "2019-06-19" , Result = null , PHQ9Version = null , HealthPlanSource = "PAYER" , MapSource = "SS" )

  )

  testQuery(
    testName = "test HEDIS_MONTHLY_ECD_EXTRACT_QME",
    query = HEDIS_MONTHLY_ECD_EXTRACT_QME,
    inputs = Map(
      "PP_BPO_MEMBER_DETAIL" -> ppBpoMemberDetail,
      "PP_BPO_PHARMACY_CLINICAL" -> ppBpoPharmacyClinical,
      "PP_BPO_CLINICAL_DOCUMENTATION" -> ppBpoClinicalDocumentation
    ),
    expectedOutput = expectedOutput
  )

}
