package com.optum.oap.backend.etl.bpo

import com.optum.oap.backend.BEQueryTestFramework
import com.optum.oap.cdr.models.{map_predicate_values, map_provider_taxonomy, map_specialty, map_specialty_ii, pp_bpo_member_detail, prov_client_rel, ref_primaryspecialty, zh_provider, zh_provider_master, zh_provider_master_xref, zo_bpo_map_employer, zo_specialty}
import org.apache.spark.sql.DataFrame
import org.junit.runner.RunWith
import java.sql.Timestamp

import com.optum.oap.backend.cdrTempModel.{temp_bpo_prov_affil_spans, temp_bpo_provider_detail, temp_prov_affil}
import com.optum.oap.backend.loader.EnrichmentRunTimeVariables
import com.optum.oap.sparkdataloader.RuntimeVariables
import org.scalatest.junit.JUnitRunner

@RunWith(classOf[JUnitRunner])
class TEMP_BPO_PROV_AFFIL_SPANS_Test extends BEQueryTestFramework {

  import spark.implicits._

  val grpid = "H123456"

  val ppBpoMemberDetail : DataFrame = mkDataFrame(
    pp_bpo_member_detail(healthplansource = "PAYER", effectivedate = java.sql.Timestamp.valueOf("2014-01-01 00:00:00"), enddate = java.sql.Timestamp.valueOf("2019-04-30 00:00:00"))
  )


  val tempBpoProviderDetail : DataFrame = mkDataFrame(
    temp_bpo_provider_detail(groupid = grpid,npi = "1770725467",providerid = "34713532",providername = "LANGE, BENJAMIN",providerfirstname= " BENJAMIN",providerlastname= "LANGE",specialty= "520")
  )

  val tempProvAffil : DataFrame = mkDataFrame(
    temp_prov_affil(prov_affil_id= "PI_PL_MONTPELIER",localproviderid= "AA449005",eff_date=java.sql.Timestamp.valueOf("2016-08-01 00:00:00"),end_date=java.sql.Timestamp.valueOf("2099-12-31 00:00:00"),client_ds_id= 9010,datasrc= "provider",master_hgprovid=34713532L, primary_span = "Y"),
    temp_prov_affil(prov_affil_id= "PI_PL_MONTPELIER",localproviderid= "AA449005",eff_date=java.sql.Timestamp.valueOf("2015-09-01 00:00:00"),end_date=java.sql.Timestamp.valueOf("2016-06-30 00:00:00"),client_ds_id= 9010,datasrc= "provider",master_hgprovid=34713532L),
    temp_prov_affil(prov_affil_id= "HG_IA_CONCORD",localproviderid= "AA513458",eff_date=java.sql.Timestamp.valueOf("2016-08-01 00:00:00"),end_date=java.sql.Timestamp.valueOf("2017-01-31 00:00:00"),client_ds_id= 9010,datasrc= "provider",master_hgprovid=34713532L, primary_span = "N"),
    temp_prov_affil(prov_affil_id= "HG_IA_CONCORD",localproviderid= "AA513458",eff_date=java.sql.Timestamp.valueOf("2017-04-01 00:00:00"),end_date=java.sql.Timestamp.valueOf("2099-12-31 00:00:00"),client_ds_id= 9010,datasrc= "provider",master_hgprovid=34713532L, primary_span = "Other"),
    temp_prov_affil(prov_affil_id= "HG_IA_CONCORD",localproviderid= "AA513456",eff_date=java.sql.Timestamp.valueOf("2016-08-01 00:00:00"),end_date=java.sql.Timestamp.valueOf("2099-12-31 00:00:00"),client_ds_id= 9010,datasrc= "provider",master_hgprovid=34713532L),
    temp_prov_affil(prov_affil_id= "01_XX_CONCORD",localproviderid= "AA513458",eff_date=java.sql.Timestamp.valueOf("2017-02-01 00:00:00"),end_date=java.sql.Timestamp.valueOf("2017-03-31 00:00:00"),client_ds_id= 9010,datasrc= "provider",master_hgprovid=34713532L, primary_span = "Other 1")
  )

  val expectedOutput : Seq[temp_bpo_prov_affil_spans] = Seq(
    temp_bpo_prov_affil_spans(groupid= grpid,master_hgprovid= "34713532",start_date=java.sql.Timestamp.valueOf("2014-01-01 00:00:00"),end_date=java.sql.Timestamp.valueOf("2015-08-31 00:00:00"),provaffiliationid= null),
    temp_bpo_prov_affil_spans(groupid= grpid,master_hgprovid= "34713532",start_date=java.sql.Timestamp.valueOf("2015-09-01 00:00:00"),end_date=java.sql.Timestamp.valueOf("2016-06-30 00:00:00"),provaffiliationid= "PI_PL_MONTPELIER"),
    temp_bpo_prov_affil_spans(groupid= grpid,master_hgprovid= "34713532",start_date=java.sql.Timestamp.valueOf("2016-07-01 00:00:00"),end_date=java.sql.Timestamp.valueOf("2016-07-31 00:00:00"),provaffiliationid= null),
    temp_bpo_prov_affil_spans(groupid= grpid,master_hgprovid= "34713532",start_date=java.sql.Timestamp.valueOf("2016-08-01 00:00:00"),end_date=java.sql.Timestamp.valueOf("2017-03-31 00:00:00"),provaffiliationid= "PI_PL_MONTPELIER"),
    temp_bpo_prov_affil_spans(groupid= grpid,master_hgprovid= "34713532",start_date=java.sql.Timestamp.valueOf("2017-04-01 00:00:00"),end_date=java.sql.Timestamp.valueOf("2099-12-31 00:00:00"),provaffiliationid= "HG_IA_CONCORD")
  )

  val runTimeVariables = EnrichmentRunTimeVariables(clientId = grpid, environment = "env", cdrCycle = "cdr cycle", cdrLevel = "cdr level", cdrSchema = "cdr schema", instance = "instance", release = "release", buildType = "buildType", fullHiveDb = "ecdr").asInstanceOf[RuntimeVariables]

  testQuery(
    testName = "test TEMP_BPO_PROV_AFFIL_SPANS",
    query = TEMP_BPO_PROV_AFFIL_SPANS,
    inputs = Map(
      "PP_BPO_MEMBER_DETAIL" -> ppBpoMemberDetail,
      "TEMP_BPO_PROVIDER_DETAIL" -> tempBpoProviderDetail,
      "PROV_AFFIL" -> tempProvAffil
    ),
    expectedOutput = expectedOutput,
    mapRuntimeVariables = runTimeVariables
  )

  val expectedOutput1 : Seq[temp_bpo_prov_affil_spans] = Seq(
    temp_bpo_prov_affil_spans(groupid= "H623622",master_hgprovid= "6691",start_date=java.sql.Timestamp.valueOf("2016-04-01 00:00:00"),end_date=java.sql.Timestamp.valueOf("2018-06-30 00:00:00"),provaffiliationid= null),
    temp_bpo_prov_affil_spans(groupid= "H623622",master_hgprovid= "6691",start_date=java.sql.Timestamp.valueOf("2018-07-01 00:00:00"),end_date=java.sql.Timestamp.valueOf("2020-01-31 00:00:00"),provaffiliationid= "T3LW0KUON2"),
    temp_bpo_prov_affil_spans(groupid= "H623622",master_hgprovid= "6691",start_date=java.sql.Timestamp.valueOf("2020-02-01 00:00:00"),end_date=java.sql.Timestamp.valueOf("2020-02-29 00:00:00"),provaffiliationid= "000DWZOK5")
  )

  testQuery(
    testName = "test BPO with same month end date of the payer",
    query = TEMP_BPO_PROV_AFFIL_SPANS,
    inputs = Map(
      "PP_BPO_MEMBER_DETAIL" -> mkDataFrame(
        pp_bpo_member_detail(healthplansource = "PAYER", effectivedate = java.sql.Timestamp.valueOf("2016-04-01 00:00:00"), enddate = java.sql.Timestamp.valueOf("2020-02-29 00:00:00"))
      ),
      "TEMP_BPO_PROVIDER_DETAIL" -> mkDataFrame(
        temp_bpo_provider_detail(groupid = "H623622",npi = "1588950075",providerid = "6691",providername = "Hello, World",providerfirstname= " Hello",providerlastname= "World",specialty= "210")
      ),
      "PROV_AFFIL" -> mkDataFrame(
        temp_prov_affil(prov_affil_id= "000DWZOK5", localproviderid= "1588950075", eff_date=java.sql.Timestamp.valueOf("2020-02-20 00:00:00"),end_date=null,client_ds_id= 9468,datasrc= "int_claim_prov",master_hgprovid=6691L),
        temp_prov_affil(prov_affil_id= "T3LW0KUON2",localproviderid= "1588950075", eff_date=java.sql.Timestamp.valueOf("2018-07-02 00:00:00"),end_date=java.sql.Timestamp.valueOf("2020-02-19 00:00:00"),client_ds_id= 9468,datasrc= "int_claim_prov",master_hgprovid=6691L)
      )
    ),
    expectedOutput = expectedOutput1,
    mapRuntimeVariables = EnrichmentRunTimeVariables(clientId = "H623622", environment = "env", cdrCycle = "cdr cycle", cdrLevel = "cdr level", cdrSchema = "cdr schema", instance = "instance", release = "release", buildType = "buildType", fullHiveDb = "ecdr").asInstanceOf[RuntimeVariables]
  )

  val expectedOutput2 : Seq[temp_bpo_prov_affil_spans] = Seq(
    temp_bpo_prov_affil_spans(groupid= "H623622",master_hgprovid= "6691",start_date=java.sql.Timestamp.valueOf("2016-04-01 00:00:00"),end_date=java.sql.Timestamp.valueOf("2018-06-30 00:00:00"),provaffiliationid= null),
    temp_bpo_prov_affil_spans(groupid= "H623622",master_hgprovid= "6691",start_date=java.sql.Timestamp.valueOf("2018-07-01 00:00:00"),end_date=java.sql.Timestamp.valueOf("2020-01-31 00:00:00"),provaffiliationid= "T3LW0KUON2"),
    temp_bpo_prov_affil_spans(groupid= "H623622",master_hgprovid= "6691",start_date=java.sql.Timestamp.valueOf("2020-02-01 00:00:00"),end_date=java.sql.Timestamp.valueOf("2020-03-31 00:00:00"),provaffiliationid= "000DWZOK5")
  )

  testQuery(
    testName = "test BPO with end date of null",
    query = TEMP_BPO_PROV_AFFIL_SPANS,
    inputs = Map(
      "PP_BPO_MEMBER_DETAIL" -> mkDataFrame(
        pp_bpo_member_detail(healthplansource = "PAYER", effectivedate = java.sql.Timestamp.valueOf("2016-04-01 00:00:00"), enddate = java.sql.Timestamp.valueOf("2020-03-31 00:00:00"))
      ),
      "TEMP_BPO_PROVIDER_DETAIL" -> mkDataFrame(
        temp_bpo_provider_detail(groupid = "H623622",npi = "1588950075",providerid = "6691",providername = "Hello, World",providerfirstname= " Hello",providerlastname= "World",specialty= "210")
      ),
      "PROV_AFFIL" -> mkDataFrame(
        temp_prov_affil(prov_affil_id= "000DWZOK5", localproviderid= "1588950075", eff_date=java.sql.Timestamp.valueOf("2020-02-20 00:00:00"),end_date=null,client_ds_id= 9468,datasrc= "int_claim_prov",master_hgprovid=6691L),
        temp_prov_affil(prov_affil_id= "T3LW0KUON2",localproviderid= "1588950075", eff_date=java.sql.Timestamp.valueOf("2018-07-02 00:00:00"),end_date=java.sql.Timestamp.valueOf("2020-02-19 00:00:00"),client_ds_id= 9468,datasrc= "int_claim_prov",master_hgprovid=6691L)
      )
    ),
    expectedOutput = expectedOutput2,
    mapRuntimeVariables = EnrichmentRunTimeVariables(clientId = "H623622", environment = "env", cdrCycle = "cdr cycle", cdrLevel = "cdr level", cdrSchema = "cdr schema", instance = "instance", release = "release", buildType = "buildType", fullHiveDb = "ecdr").asInstanceOf[RuntimeVariables]
  )


  val expectedOutput3 : Seq[temp_bpo_prov_affil_spans] = Seq(
    temp_bpo_prov_affil_spans(groupid= "H623622",master_hgprovid= "6691",start_date=java.sql.Timestamp.valueOf("2016-01-01 00:00:00"),end_date=java.sql.Timestamp.valueOf("2019-12-31 00:00:00"),provaffiliationid= "T3LW0KUON2")
  )

  testQuery(
    testName = "test BPO with assigning null provider",
    query = TEMP_BPO_PROV_AFFIL_SPANS,
    inputs = Map(
      "PP_BPO_MEMBER_DETAIL" -> mkDataFrame(
        pp_bpo_member_detail(healthplansource = "PAYER", effectivedate = java.sql.Timestamp.valueOf("2016-04-01 00:00:00"), enddate = java.sql.Timestamp.valueOf("2020-03-31 00:00:00"))
      ),
      "TEMP_BPO_PROVIDER_DETAIL" -> mkDataFrame(
        temp_bpo_provider_detail(groupid = "H623622",npi = "1588950075",providerid = "6691",providername = "Hello, World",providerfirstname= " Hello",providerlastname= "World",specialty= "210")
      ),
      "PROV_AFFIL" -> mkDataFrame(
        temp_prov_affil(prov_affil_id= "T3LW0KUON2",localproviderid= "1588950075", eff_date=java.sql.Timestamp.valueOf("2016-01-01 00:00:00"),end_date=java.sql.Timestamp.valueOf("2019-12-19 00:00:00"),client_ds_id= 9468,datasrc= "int_claim_prov",master_hgprovid=6691L)
      )
    ),
    expectedOutput = expectedOutput3,
    mapRuntimeVariables = EnrichmentRunTimeVariables(clientId = "H623622", environment = "env", cdrCycle = "cdr cycle", cdrLevel = "cdr level", cdrSchema = "cdr schema", instance = "instance", release = "release", buildType = "buildType", fullHiveDb = "ecdr").asInstanceOf[RuntimeVariables]
  )

  val expectedOutput4 : Seq[temp_bpo_prov_affil_spans] = Seq(
    temp_bpo_prov_affil_spans(groupid= "H623622",master_hgprovid= "6691",start_date=java.sql.Timestamp.valueOf("2016-04-01 00:00:00"),end_date=java.sql.Timestamp.valueOf("2018-06-30 00:00:00"),provaffiliationid= null),
    temp_bpo_prov_affil_spans(groupid= "H623622",master_hgprovid= "6691",start_date=java.sql.Timestamp.valueOf("2018-07-01 00:00:00"),end_date=java.sql.Timestamp.valueOf("2020-03-31 00:00:00"),provaffiliationid= "000DWZOK5")
  )

  testQuery(
    testName = "test BPO with assigning null Future",
    query = TEMP_BPO_PROV_AFFIL_SPANS,
    inputs = Map(
      "PP_BPO_MEMBER_DETAIL" -> mkDataFrame(
        pp_bpo_member_detail(healthplansource = "PAYER", effectivedate = java.sql.Timestamp.valueOf("2016-04-01 00:00:00"), enddate = java.sql.Timestamp.valueOf("2020-01-31 00:00:00"))
      ),
      "TEMP_BPO_PROVIDER_DETAIL" -> mkDataFrame(
        temp_bpo_provider_detail(groupid = "H623622",npi = "1588950075",providerid = "6691",providername = "Hello, World",providerfirstname= " Hello",providerlastname= "World",specialty= "210")
      ),
      "PROV_AFFIL" -> mkDataFrame(
        temp_prov_affil(prov_affil_id= "000DWZOK5", localproviderid= "1588950075", eff_date=java.sql.Timestamp.valueOf("2020-03-20 00:00:00"),end_date=null,client_ds_id= 9468,datasrc= "int_claim_prov",master_hgprovid=6691L),
        temp_prov_affil(prov_affil_id= "T3LW0KUON2",localproviderid= "1588950075", eff_date=java.sql.Timestamp.valueOf("2018-07-02 00:00:00"),end_date=java.sql.Timestamp.valueOf("2020-3-19 00:00:00"),client_ds_id= 9468,datasrc= "int_claim_prov",master_hgprovid=6691L)
      )
    ),
    expectedOutput = expectedOutput4,
    mapRuntimeVariables = EnrichmentRunTimeVariables(clientId = "H623622", environment = "env", cdrCycle = "cdr cycle", cdrLevel = "cdr level", cdrSchema = "cdr schema", instance = "instance", release = "release", buildType = "buildType", fullHiveDb = "ecdr").asInstanceOf[RuntimeVariables]
  )

  val expectedOutput5 : Seq[temp_bpo_prov_affil_spans] = Seq.empty

  testQuery(
    testName = "test BPO Future starting date",
    query = TEMP_BPO_PROV_AFFIL_SPANS,
    inputs = Map(
      "PP_BPO_MEMBER_DETAIL" -> mkDataFrame(
        pp_bpo_member_detail(healthplansource = "PAYER", effectivedate = java.sql.Timestamp.valueOf("2016-04-01 00:00:00"), enddate = java.sql.Timestamp.valueOf("2020-03-31 00:00:00"))
      ),
      "TEMP_BPO_PROVIDER_DETAIL" -> mkDataFrame(
        temp_bpo_provider_detail(groupid = "H623622",npi = "1588950075",providerid = "6691",providername = "Hello, World",providerfirstname= " Hello",providerlastname= "World",specialty= "210")
      ),
      "PROV_AFFIL" -> mkDataFrame(
        temp_prov_affil(prov_affil_id= "T3LW0KUON2",localproviderid= "1588950075", eff_date=java.sql.Timestamp.valueOf("2020-04-20 00:00:00"),end_date=null,client_ds_id= 9468,datasrc= "int_claim_prov",master_hgprovid=6691L)
      )
    ),
    expectedOutput = expectedOutput5,
    mapRuntimeVariables = EnrichmentRunTimeVariables(clientId = "H623622", environment = "env", cdrCycle = "cdr cycle", cdrLevel = "cdr level", cdrSchema = "cdr schema", instance = "instance", release = "release", buildType = "buildType", fullHiveDb = "ecdr").asInstanceOf[RuntimeVariables]
  )

  val tempProvAffil6 : DataFrame = mkDataFrame(
    temp_prov_affil(prov_affil_id= "HG_IA_CONCORD",localproviderid= "AA513458",eff_date=java.sql.Timestamp.valueOf("2016-08-01 00:00:00"),end_date=java.sql.Timestamp.valueOf("2099-12-31 00:00:00"),client_ds_id= 9010,datasrc= "provider",master_hgprovid=34713532L, primary_span = "Y"),
    temp_prov_affil(prov_affil_id= "PI_PL_MONTPELIER",localproviderid= "AA449005",eff_date=java.sql.Timestamp.valueOf("2016-08-01 00:00:00"),end_date=java.sql.Timestamp.valueOf("2099-12-31 00:00:00"),client_ds_id= 9010,datasrc= "provider",master_hgprovid=34713532L, primary_span = "N"),
    temp_prov_affil(prov_affil_id= "PI_PL_MONTPELIER",localproviderid= "AA449005",eff_date=java.sql.Timestamp.valueOf("2015-09-01 00:00:00"),end_date=java.sql.Timestamp.valueOf("2016-06-30 00:00:00"),client_ds_id= 9010,datasrc= "provider",master_hgprovid=34713532L),
    temp_prov_affil(prov_affil_id= "HG_IA_CONCORD",localproviderid= "AA513458",eff_date=java.sql.Timestamp.valueOf("2016-08-01 00:00:00"),end_date=java.sql.Timestamp.valueOf("2017-01-31 00:00:00"),client_ds_id= 9010,datasrc= "provider",master_hgprovid=34713532L, primary_span = "N"),
    temp_prov_affil(prov_affil_id= "HG_IA_CONCORD",localproviderid= "AA513458",eff_date=java.sql.Timestamp.valueOf("2017-04-01 00:00:00"),end_date=java.sql.Timestamp.valueOf("2099-12-31 00:00:00"),client_ds_id= 9010,datasrc= "provider",master_hgprovid=34713532L, primary_span = "Other"),
    temp_prov_affil(prov_affil_id= "HG_IA_CONCORD",localproviderid= "AA513456",eff_date=java.sql.Timestamp.valueOf("2016-08-01 00:00:00"),end_date=java.sql.Timestamp.valueOf("2099-12-31 00:00:00"),client_ds_id= 9010,datasrc= "provider",master_hgprovid=34713532L),
    temp_prov_affil(prov_affil_id= "01_XX_CONCORD",localproviderid= "AA513458",eff_date=java.sql.Timestamp.valueOf("2017-02-01 00:00:00"),end_date=java.sql.Timestamp.valueOf("2017-03-31 00:00:00"),client_ds_id= 9010,datasrc= "provider",master_hgprovid=34713532L, primary_span = "Other 1")
  )

  val expectedOutput6 : Seq[temp_bpo_prov_affil_spans] = Seq(
    temp_bpo_prov_affil_spans(groupid= grpid,master_hgprovid= "34713532",start_date=java.sql.Timestamp.valueOf("2014-01-01 00:00:00"),end_date=java.sql.Timestamp.valueOf("2015-08-31 00:00:00"),provaffiliationid= null),
    temp_bpo_prov_affil_spans(groupid= grpid,master_hgprovid= "34713532",start_date=java.sql.Timestamp.valueOf("2015-09-01 00:00:00"),end_date=java.sql.Timestamp.valueOf("2016-06-30 00:00:00"),provaffiliationid= "PI_PL_MONTPELIER"),
    temp_bpo_prov_affil_spans(groupid= grpid,master_hgprovid= "34713532",start_date=java.sql.Timestamp.valueOf("2016-07-01 00:00:00"),end_date=java.sql.Timestamp.valueOf("2016-07-31 00:00:00"),provaffiliationid= null),
    temp_bpo_prov_affil_spans(groupid= grpid,master_hgprovid= "34713532",start_date=java.sql.Timestamp.valueOf("2016-08-01 00:00:00"),end_date=java.sql.Timestamp.valueOf("2099-12-31 00:00:00"),provaffiliationid= "HG_IA_CONCORD")
  )


  testQuery(
    testName = "test TEMP_BPO_PROV_AFFIL_SPANS primary span order change",
    query = TEMP_BPO_PROV_AFFIL_SPANS,
    inputs = Map(
      "PP_BPO_MEMBER_DETAIL" -> ppBpoMemberDetail,
      "TEMP_BPO_PROVIDER_DETAIL" -> tempBpoProviderDetail,
      "PROV_AFFIL" -> tempProvAffil6
    ),
    expectedOutput = expectedOutput6,
    mapRuntimeVariables = runTimeVariables
  )
}
