package com.optum.oap.backend.etl.bpo

import java.sql.{Date, Timestamp}

import com.optum.oap.backend.BEQueryTestFramework
import com.optum.oap.backend.cdrTempModel.{temp_bpo_calculate_params, temp_bpo_insurance, temp_bpo_patients}
import com.optum.oap.backend.etl.common.CALENDAR
import com.optum.oap.backend.loader.EnrichmentRunTimeVariables
import com.optum.oap.cdr.models._
import com.optum.oap.sparkdataloader.{EmptyRuntimeVariables, RuntimeVariables}
import org.apache.spark.sql.DataFrame

/**
  *
  * Copyright 2019 Optum Analytics
  *
  * Date: 5/23/19
  *
  * Creator: pavula1
  */
class TEMP_BPO_INSURANCE_Test extends BEQueryTestFramework {

  import spark.implicits._

  val runTimeVariables = EnrichmentRunTimeVariables(clientId = "H000000", environment = "env", cdrCycle = "cdr cycle", cdrLevel = "cdr level", cdrSchema = "cdr schema", instance = "instance", release = "release", buildType = "buildType", fullHiveDb = "ecdr", partitionMultiplier = 1).asInstanceOf[RuntimeVariables]

  val patientID: DataFrame = mkDataFrame(
    patient_id(idtype = "NAT_ID", groupid = "H000000", grp_mpi = "g1", client_ds_id = 1, patientid = "patient id 1"),
    patient_id(idtype = "NAT2_ID", groupid = "H000000", grp_mpi = "g2", client_ds_id = 1, patientid = "patient id 2"),
    patient_id(idtype = "NAT2_ID", groupid = "H000000", grp_mpi = "g2", client_ds_id = 2, patientid = "patient id 3"),
    patient_id(idtype = "NAT_ID", groupid = "H000000", grp_mpi = "g2", client_ds_id = 2, patientid = "patient id 4")
  )

  val provPatRel: DataFrame = mkDataFrame(
    prov_pat_rel(client_ds_id = 1, groupid = "H000000", grp_mpi = "g1", mstrprovid = "21", startdate = Timestamp.valueOf("2016-4-01 00:00:00"), localrelshipcode = "PCP", enddate = Timestamp.valueOf("2017-11-17 00:00:00"), prov_affil_id = "pcp affil id 1"),
    prov_pat_rel(client_ds_id = 1, groupid = "H000000", grp_mpi = "g2", mstrprovid = "21", startdate = Timestamp.valueOf("2016-4-01 00:00:00"), localrelshipcode = "PCP", enddate = Timestamp.valueOf("2017-11-17 00:00:00"), prov_affil_id = "pcp affil id 2")
  )
  val mapEmployer: DataFrame = mkDataFrame(
    zo_bpo_map_employer(groupid = "H000000", client_ds_id = 1, employeraccountid = "BCBS"),
    zo_bpo_map_employer(groupid = "H000000", client_ds_id = 2, employeraccountid = "product code 2")
  )
  val patRiskAttrib: DataFrame = mkDataFrame(
    pat_risk_attrib(groupid = "H000000", client_ds_id = 1, patientid = "P1", grp_mpi = "g1", providerid = "PR1", start_date = Timestamp.valueOf("2016-4-01 00:00:00"), end_date = Timestamp.valueOf("2017-11-17 00:00:00"), at_risk_status = "Y", risk_type = "risk type 1"),
    pat_risk_attrib(groupid = "H000000", client_ds_id = 1, patientid = "P2", grp_mpi = "g2", providerid = "PR2", start_date = Timestamp.valueOf("2016-7-01 00:00:00"), end_date = Timestamp.valueOf("2016-11-17 00:00:00"), at_risk_status = "N" , risk_type = "risk type 2")
  )
  val patientAttribute: DataFrame = mkDataFrame(
    patient_attribute(groupid = "H000000", client_ds_id = 1, patientid = "P1", grp_mpi = "g1", hgpid = null, attribute_type_cui = "CH004044", attribute_value = "WA", eff_date = Timestamp.valueOf("2016-04-01 00:00:00"), end_date = Timestamp.valueOf("2017-04-01 00:00:00")),
    patient_attribute(groupid = "H000000", client_ds_id = 1, patientid = "P2", grp_mpi = "g2", hgpid = null, attribute_type_cui = "CH004026", attribute_value = "MA", eff_date = Timestamp.valueOf("2016-07-01 00:00:00"), end_date = Timestamp.valueOf("2017-11-01 00:00:00"))
  )
  val memberMonths: DataFrame = mkDataFrame(
    claim_member_months(groupid = "H000000", client_ds_id = 1, grp_mpi = "g1", claims_year = 2016, claims_month = 8, claim_paid_amount = 300.0, rx_paid_amount = 600.0, claim_count = 2, rx_count = 2, product_code = "BCBS", effective_date = Timestamp.valueOf("2016-08-01 00:00:00"), dental_count = 2),
    claim_member_months(groupid = "H000000", client_ds_id = 1, grp_mpi = "g2", claims_year = 2017, claims_month = 8, claim_paid_amount = 300.0, rx_paid_amount = 600.0, claim_count = 2, rx_count = 2, product_code = "product code 2", effective_date = Timestamp.valueOf("2017-01-01 00:00:00"), dental_count = 2)
  )

  val tempBpoPatients: DataFrame = mkDataFrame(
    temp_bpo_patients(groupid = "H000000", grp_mpi = "g1", productcode = "MDE", subscriberid = "123", subscriberflag = "Y", coverage_status = "MED", lineofbusinessid = 1, contracttype = "contracttype", employeraccountid = "BCBS", dob = "20100816", mapped_language = "CH002130", date_of_death = Timestamp.valueOf("2017-11-17 00:00:00"), mapped_gender = "CH000034", mapped_race = "CH999999", mapped_ethnicity = "CH999999", effective_date = Timestamp.valueOf("2016-08-25 00:00:00"), payer = 1, end_date = Timestamp.valueOf("2017-04-01 00:00:00"), contract_id = "CMS", pharmacy_benefit_flag = "N", benefitplan = "benefitPlan", coverageclasscode = "code1", emp_acct_id = "BCBS"),
    temp_bpo_patients(groupid = "H000000", grp_mpi = "g2", productcode = "MDE", subscriberid = "345", subscriberflag = "Y", coverage_status = "MED", lineofbusinessid = 1, contracttype = "contracttype", employeraccountid = "product code 2", dob = "19970816", mapped_language = "CH002130", mapped_gender = "CH000034", mapped_race = "CH999999", mapped_ethnicity = "CH999999", effective_date = Timestamp.valueOf("2016-04-01 00:00:00"), payer = 1, end_date = Timestamp.valueOf("2017-04-01 00:00:00"), contract_id = "CMS", pharmacy_benefit_flag = "N", benefitplan = "benefitPlan", coverageclasscode = "code1", emp_acct_id = "BCBS")
  )

  val contractRollup: DataFrame = mkDataFrame(
    contract_rollup(groupid = "H000000", contract_id = "CMS", contract_hier = 10),
    contract_rollup(groupid = "H000000", contract_id = "CMS", contract_hier = null)
  )

  val params: DataFrame =  mkDataFrame(
    temp_bpo_calculate_params(engineStartDate = Date.valueOf("2015-04-01"), engineStartDate2 = Date.valueOf("2015-04-01"), engineStartDate3 = Date.valueOf("2019-02-01"), engineEndDate = Date.valueOf("2019-03-31"), startDate = Date.valueOf("2015-01-01"))
  )

  val expectedOutput: Seq[temp_bpo_insurance] = Seq(
    temp_bpo_insurance(groupid = "H000000", grp_mpi = "g1", dob = "20100816", mapped_gender = "CH000034", healthplansource = "PAYER", employeraccountid = "BCBS", member_start = Timestamp.valueOf("2016-08-01 00:00:00"), member_end = Timestamp.valueOf("2016-08-31 00:00:00"), productcode = "MDE", pcpid = "21", pharmacy = "N", product_source = "PA", lineofbusinessid = 1, mapped_race = "CH999999", mapped_ethnicity = "CH999999", mapped_language = "CH002130", prodrank = 1, payrank = 1, distinct_pyrcnt = 1,
      date_of_death = Timestamp.valueOf("2017-11-17 00:00:00"), contract_id = "CMS", at_risk_status = "Y", subscriberid = "123", subscriberflag = "Y", coverage_status = "MED", emp_acct_id = "BCBS", contracttype = "contracttype", benefitplan = "benefitPlan", coverageclasscode = "code1", mem_userdef_1 = "WA", dental_benefit = "Y", pcp_affil = "pcp affil id 1", risk_type = "risk type 1", sec_member_id_1 = "patient id 1"),
    temp_bpo_insurance(groupid = "H000000", grp_mpi = "g1", dob = "20100816", mapped_gender = "CH000034", healthplansource = "PAYER", employeraccountid = "BCBS", member_start = Timestamp.valueOf("2016-08-01 00:00:00"), member_end = Timestamp.valueOf("2016-08-31 00:00:00"), productcode = "MDE", pcpid = "21", pharmacy = "N", product_source = "PA", lineofbusinessid = 1, mapped_race = "CH999999", mapped_ethnicity = "CH999999", mapped_language = "CH002130", prodrank = 2, payrank = 2, distinct_pyrcnt = 1,
      date_of_death = Timestamp.valueOf("2017-11-17 00:00:00"), contract_id = "CMS", at_risk_status = "Y", subscriberid = "123", subscriberflag = "Y", coverage_status = "MED", emp_acct_id = "BCBS", contracttype = "contracttype", benefitplan = "benefitPlan", coverageclasscode = "code1", mem_userdef_1 = "WA", dental_benefit = "Y", pcp_affil = "pcp affil id 1", risk_type = "risk type 1", sec_member_id_1 = "patient id 1"),

    temp_bpo_insurance(groupid = "H000000", grp_mpi = "g2", dob = "19970816", mapped_gender = "CH000034", healthplansource = "PAYER", employeraccountid = "product code 2", member_start = Timestamp.valueOf("2017-01-01 00:00:00"), member_end = Timestamp.valueOf("2017-01-31 00:00:00"), productcode = "MDE", pharmacy = "N", product_source = "PA", lineofbusinessid = 1, mapped_race = "CH999999", mapped_ethnicity = "CH999999", mapped_language = "CH002130", prodrank = 1, payrank = 1, distinct_pyrcnt = 1,
      contract_id = "CMS", subscriberid = "345", subscriberflag = "Y", coverage_status = "MED", emp_acct_id = "BCBS", contracttype = "contracttype", benefitplan = "benefitPlan", coverageclasscode = "code1", cust_mem_attr3 = "MA", dental_benefit = "Y", sec_member_id_1 = "patient id 4"),
    temp_bpo_insurance(groupid = "H000000", grp_mpi = "g2", dob = "19970816", mapped_gender = "CH000034", healthplansource = "PAYER", employeraccountid = "product code 2", member_start = Timestamp.valueOf("2017-01-01 00:00:00"), member_end = Timestamp.valueOf("2017-01-31 00:00:00"), productcode = "MDE", pharmacy = "N", product_source = "PA", lineofbusinessid = 1, mapped_race = "CH999999", mapped_ethnicity = "CH999999", mapped_language = "CH002130", prodrank = 2, payrank = 2, distinct_pyrcnt = 1,
      contract_id = "CMS", subscriberid = "345", subscriberflag = "Y", coverage_status = "MED", emp_acct_id = "BCBS", contracttype = "contracttype", benefitplan = "benefitPlan", coverageclasscode = "code1", cust_mem_attr3 = "MA", dental_benefit = "Y", sec_member_id_2 = "patient id 4"),
    temp_bpo_insurance(groupid = "H000000", grp_mpi = "g2", dob = "19970816", mapped_gender = "CH000034", healthplansource = "PAYER", employeraccountid = "product code 2", member_start = Timestamp.valueOf("2017-01-01 00:00:00"), member_end = Timestamp.valueOf("2017-01-31 00:00:00"), productcode = "MDE",  pharmacy = "N", product_source = "PA", lineofbusinessid = 1, mapped_race = "CH999999", mapped_ethnicity = "CH999999", mapped_language = "CH002130", prodrank = 3, payrank = 3, distinct_pyrcnt = 1,
      contract_id = "CMS", subscriberid = "345", subscriberflag = "Y", coverage_status = "MED", emp_acct_id = "BCBS", contracttype = "contracttype", benefitplan = "benefitPlan", coverageclasscode = "code1", cust_mem_attr3 = "MA", dental_benefit = "Y", sec_member_id_1 = "patient id 4"),
    temp_bpo_insurance(groupid = "H000000", grp_mpi = "g2", dob = "19970816", mapped_gender = "CH000034", healthplansource = "PAYER", employeraccountid = "product code 2", member_start = Timestamp.valueOf("2017-01-01 00:00:00"), member_end = Timestamp.valueOf("2017-01-31 00:00:00"), productcode = "MDE",  pharmacy = "N", product_source = "PA", lineofbusinessid = 1, mapped_race = "CH999999", mapped_ethnicity = "CH999999", mapped_language = "CH002130", prodrank = 4, payrank = 4, distinct_pyrcnt = 1,
      contract_id = "CMS", subscriberid = "345", subscriberflag = "Y", coverage_status = "MED", emp_acct_id = "BCBS", contracttype = "contracttype", benefitplan = "benefitPlan", coverageclasscode = "code1", cust_mem_attr3 = "MA", dental_benefit = "Y", sec_member_id_2 = "patient id 4"),

    temp_bpo_insurance(groupid = "H000000", grp_mpi = "g1", dob = "20100816", mapped_gender = "CH000034", healthplansource = "PROVIDER",  member_start = Timestamp.valueOf("2019-02-01 00:00:00"), member_end = Timestamp.valueOf("2019-02-28 00:00:00"), pharmacy = "N", mapped_race = "CH999999", mapped_ethnicity = "CH999999", mapped_language = "CH002130", prodrank = 1, date_of_death = Timestamp.valueOf("2017-11-17 00:00:00")),
    temp_bpo_insurance(groupid = "H000000", grp_mpi = "g1", dob = "20100816", mapped_gender = "CH000034", healthplansource = "PROVIDER",  member_start = Timestamp.valueOf("2019-03-01 00:00:00"), member_end = Timestamp.valueOf("2019-03-31 00:00:00"), pharmacy = "Y", mapped_race = "CH999999", mapped_ethnicity = "CH999999", mapped_language = "CH002130", prodrank = 1, date_of_death = Timestamp.valueOf("2017-11-17 00:00:00")),

    temp_bpo_insurance(groupid = "H000000", grp_mpi = "g2", dob = "19970816", mapped_gender = "CH000034", healthplansource = "PROVIDER",  member_start = Timestamp.valueOf("2019-02-01 00:00:00"), member_end = Timestamp.valueOf("2019-02-28 00:00:00"), pharmacy = "N", mapped_race = "CH999999", mapped_ethnicity = "CH999999", mapped_language = "CH002130", prodrank = 1),
    temp_bpo_insurance(groupid = "H000000", grp_mpi = "g2", dob = "19970816", mapped_gender = "CH000034", healthplansource = "PROVIDER",  member_start = Timestamp.valueOf("2019-03-01 00:00:00"), member_end = Timestamp.valueOf("2019-03-31 00:00:00"), pharmacy = "Y", mapped_race = "CH999999", mapped_ethnicity = "CH999999", mapped_language = "CH002130", prodrank = 1)
  )

  private val tCalendar = CALENDAR.createDataFrame(spark, Map.empty, udfsMap, EmptyRuntimeVariables())


  testQuery(
    testName = "test TEMP_BPO_INSURANCE",
    query = TEMP_BPO_INSURANCE,
    inputs = Map(
      "PROV_PAT_REL" -> provPatRel,
      "ZO_BPO_MAP_EMPLOYER" -> mapEmployer,
      "PAT_RISK_ATTRIB" -> patRiskAttrib,
      "PATIENT_ATTRIBUTE" -> patientAttribute,
      "CLAIM_MEMBER_MONTHS" -> memberMonths,
      "TEMP_BPO_PATIENTS" -> tempBpoPatients,
      "TEMP_BPO_CALCULATE_PARAMS" -> params,
      "CALENDAR" -> tCalendar,
      "PATIENT_ID" -> patientID,
      "CONTRACT_ROLLUP" -> contractRollup
    ),
    expectedOutput = expectedOutput
    , mapRuntimeVariables = runTimeVariables
  )

}
