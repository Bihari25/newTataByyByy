package com.optum.oap.backend.etl.bpo.bpo_pyr_sre

import com.optum.oap.backend.BEQueryTestFramework
import com.optum.oap.backend.cdrTempModel.monthly_payer_med_sre_extract
import com.optum.oap.cdr.models.{pp_bpo_medical_claims, pp_bpo_member_detail}
import org.apache.spark.sql.DataFrame
import org.junit.runner.RunWith
import org.scalatest.junit.JUnitRunner

@RunWith(classOf[JUnitRunner])
class MONTHLY_PAYER_MED_SRE_EXTRACT_TEST extends BEQueryTestFramework{
  import spark.implicits._

  val originalSQL =
    """
      |SELECT
      |    med.memberid
      |,   date_format  (paymentdate,'yyyy-MM-dd') AS  paymentdate
      |,   date_format  (servicedate,'yyyy-MM-dd') AS  servicedate
      |,   date_format  (fromdate,'yyyy-MM-dd')    AS  fromdate
      |,   date_format  (todate,'yyyy-MM-dd')      AS todate
      |,   serviceproviderid
      |,   specialty
      |,   providertype
      |,   placeofservice
      |,   revenuecode
      |,   procedurecode
      |,   proceduremodifier
      |,   tos
      |,   icdcodetype
      |,   icdproc1
      |,   icdproc2
      |,   icdproc3
      |,   icdproc4
      |,   icdproc5
      |,   icdproc6
      |,   icddiag1
      |,   icddiag2
      |,   icddiag3
      |,   icddiag4
      |,   icddiag5
      |,   icddiag6
      |,   icddiag7
      |,   icddiag8
      |,   icddiag9
      |,   icddiag10
      |,   drg
      |,   drggrouper
      |,   drgseverity
      |,   drgoutlier
      |,   poa
      |,   dischargestatus
      |,   quantity
      |,   allowedamount
      |,   requestedamount
      |,   paidamount
      |,   copayamount
      |,   coinsamount
      |,   deductamount
      |,   patliabamount
      |,   cobamount
      |,   ffsamount
      |,   withamount
      |,   capamount
      |,   capsvcflag
      |,   'N' as deniedflag
      |,   deniedreason
      |,   pseudoflag
      |,   claimsource
      |,   claimheader
      |,   claimline
      |,   med.healthplansource
      |,   med.coverageclasscode
      |,   networkstatus
      |,   typeofbill
      |,   billingproviderid
      |,   orderingproviderid
      |,   med.mapsource
      |,  covered_days
      |,  proc_code_modifier2
      |,  hcpcs_code
      |,  cpt2_code
      |,  icd_diag_11
      |,  icd_proc_7
      |,  icd_proc_8
      |,  icd_proc_9
      |,  icd_proc_10
      |,  icd_proc_11
      |,  icd_proc_12
      |,  icd_proc_13
      |,  icd_diag_12
      |,  icd_diag_13
      |,  proc_code_modifier3
      |,  proc_code_modifier4
      |,  attend_prov_id
      |,  provider_key
      |,  poa_2
      |,  poa_3
      |,  poa_4
      |,  poa_5
      |,  poa_6
      |,  poa_7
      |,  poa_8
      |,  poa_9
      |,  poa_10
      |,  poa_11
      |,  poa_12
      |,  poa_13
      |,  icd_diag_14
      |,  icd_diag_15
      |,  icd_diag_16
      |,  icd_diag_17
      |,  icd_diag_18
      |,  icd_diag_19
      |,  icd_diag_20
      |,  icd_diag_21
      |,  icd_diag_22
      |,  icd_diag_23
      |,  icd_diag_24
      |,  icd_diag_25
      |,  icd_proc_14
      |,  icd_proc_15
      |,  icd_proc_16
      |,  icd_proc_17
      |,  icd_proc_18
      |,  icd_proc_19
      |,  icd_proc_20
      |,  icd_proc_21
      |,  icd_proc_22
      |,  icd_proc_23
      |,  icd_proc_24
      |,  icd_proc_25
      |,  cast(null as string) as facility_type
      |,  cast(null as string) as bed_type
      |,  cast(null as string) as point_of_origin
      |,  cast(null as string) as type_of_admission
      |,  cast(null as string) as adjudicated_claim_flag
      |,  cast(null as string) as Med_Discount_Amt
      |,  cast(null as string) as Med_NonCovered_Charge_Amt
      |,  cast(null as string) as Payer_ID
      |,  cast(null as string) as Med_Benefit_Plan_Ind
      |,  cast(null as string) as Prov_Flag
      |,  cast(null as string) as Prov_Tier
      |,  cast(null as string) as Premium_Prov_Ind
      |,  cast(null as string) as Medicare_Involved_Ind
      |,  cast(null as string) as Cobra_Claim_Ind
      |,  cast(null as string) as Relationship
      |,  cast(null as string) as Med_Group_Nmbr
      |,  cast(null as string) as Med_Account_Nmbr
      |,  cast(null as string) as Med_Branch_Nmbr
      |,  cast(null as string) as Domestic_Ind
      |,  cast(null as string) as NDC
      |FROM
      |    pp_bpo_medical_claims med
      |INNER JOIN
      |    pp_bpo_member_detail elig
      |    ON
      |    (   elig.groupid=med.groupid
      |    AND elig.memberid = med.memberid
      |    AND elig.healthplansource = med.healthplansource
      |    )
      |WHERE
      |    med.healthplansource='PAYER'
      |AND
      |    med.servicedate BETWEEN elig.effectivedate AND elig.enddate
    """.stripMargin

  val ppBpoMedicalClaims : DataFrame = mkDataFrame(
    pp_bpo_medical_claims(groupid = "group id 1", memberid = "member id 1", healthplansource = "PAYER", servicedate = java.sql.Timestamp.valueOf("2019-06-06 00:00:00"), poa = "poa"),
    pp_bpo_medical_claims(groupid = "group id 2", memberid = "member id 2", healthplansource = "PAYER", servicedate = java.sql.Timestamp.valueOf("2020-07-07 00:00:00")),
    pp_bpo_medical_claims(groupid = "group id 3", memberid = "member id 3", healthplansource = "PAYER")
  )

  val ppBpoMemberDetail : DataFrame = mkDataFrame(
    pp_bpo_member_detail(groupid = "group id 1", memberid = "member id 1", healthplansource = "PAYER", effectivedate = java.sql.Timestamp.valueOf("2019-05-05 00:00:00"), enddate = java.sql.Timestamp.valueOf("2019-08-08 00:00:00")),
    pp_bpo_member_detail(groupid = "group id 2", memberid = "member id 2", healthplansource = "PAYER", effectivedate = java.sql.Timestamp.valueOf("2019-07-07 00:00:00"), enddate = java.sql.Timestamp.valueOf("2019-08-08 00:00:00"))
  )

  val expectedOutput : Seq[monthly_payer_med_sre_extract] = Seq(
    monthly_payer_med_sre_extract(memberid = "member id 1", healthplansource = "PAYER", deniedflag = "N", servicedate = "2019-06-06", poa = "poa")
  )

  testQuery(
    testName = "TEST MONTHLY_PAYER_MED_SRE_EXTRACT",
    query = MONTHLY_PAYER_MED_SRE_EXTRACT,
    inputs = Map(
      "PP_BPO_MEDICAL_CLAIMS" -> ppBpoMedicalClaims,
      "PP_BPO_MEMBER_DETAIL" -> ppBpoMemberDetail
    ),
    expectedOutput = expectedOutput
  )

  it should "output of new etl should match with original Spark SQL etl" in {
    ppBpoMemberDetail.createOrReplaceTempView("pp_bpo_member_detail")
    ppBpoMedicalClaims.createOrReplaceTempView("pp_bpo_medical_claims")

    val originalOutput = spark.sql(originalSQL)

    checkThatDataFramesAreEqual(originalOutput, expectedOutput)
  }

}
