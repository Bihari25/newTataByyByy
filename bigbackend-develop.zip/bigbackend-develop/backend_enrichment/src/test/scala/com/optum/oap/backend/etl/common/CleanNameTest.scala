package com.optum.oap.backend.etl.common

import com.optum.oap.testutils.TestSparkSession
import org.apache.spark.sql.functions.lit
import org.junit.runner.RunWith
import org.scalatest.FlatSpec
import org.scalatest.Matchers._
import org.scalatest.junit.JUnitRunner

/**
  *
  * Copyright 2019 Optum Analytics
  *
  * Date: 9/18/2019
  *
  * Creator: rrogers2
  */
@RunWith(classOf[JUnitRunner])
class CleanNameTest extends FlatSpec with TestSparkSession {

  private val spark = sparkSession

  import spark.implicits._

  behavior of "CleanName UDF"

  def cleanNameTest(str: String, expectedResult: String): Unit = {

    it should s"clean $str to remove extraneous elements with result $expectedResult " in {

      val df = Seq(
        str
      ).toDF()

      val output = df.select(CleanName.cleanPersonName(lit(str), lit(3))).as[String].collect().head
      output shouldEqual expectedResult
    }
  }

  cleanNameTest(str = "Allen, Christopher, MD", expectedResult = "ALLEN CHRISTOPHER")
  cleanNameTest(str = null, expectedResult = null)
  cleanNameTest(str = "*", expectedResult = null)
  cleanNameTest("Jones, Rocky R", expectedResult = "JONES ROCKY")
  cleanNameTest("John PRESIDENT", expectedResult = "JOHN PRESIDENT")
  cleanNameTest("RESIDENT JOHN DOE", expectedResult = "JOHN DOE")
  cleanNameTest("SMITH, ADAM", expectedResult = "SMITH ADAM")
  cleanNameTest("ADAM SMITH IV MD", expectedResult = "ADAM SMITH")
  cleanNameTest("(EXCLUDED PROVIDER) THOMPSON JR, ROBERT J", expectedResult = "THOMPSON ROBERT")
  cleanNameTest("KATZ                LISA     E, ", expectedResult = "KATZ LISA")
  cleanNameTest("ESU H", expectedResult = "ESU")
  cleanNameTest("RUPERT JR., ROBERT DEAN", expectedResult = "RUPERT ROBERT DEAN")

}

//case class testString(str: String)
