package com.optum.oap.backend.etl.bpo

import com.optum.oap.backend.BEQueryTestFramework
import com.optum.oap.cdr.models.{prov_spec, _}
import org.apache.spark.sql.DataFrame
import org.junit.runner.RunWith
import org.scalatest.junit.JUnitRunner


@RunWith(classOf[JUnitRunner])
class PP_BPO_PHYSICIAN_KEY_Test extends BEQueryTestFramework {

  import spark.implicits._

  behavior of "translated query PP_BPO_PHYSICIAN_KEY"

  val provSpec: DataFrame = mkDataFrame(
    prov_spec(groupid = "group 2", localproviderid = "prov 1", client_ds_id = 1),
    prov_spec(groupid = "group 1", localproviderid = "prov 2", client_ds_id = 1),
    prov_spec(groupid = "group 1", localproviderid = "prov 1", client_ds_id = 2),
    prov_spec(groupid = "group 3", localproviderid = "prov 3", client_ds_id = 3, localspecialtycode = "local code 3"),
    prov_spec(groupid = "group 4", localproviderid = "prov 4", client_ds_id = 4, localspecialtycode = "local code 4"),
    prov_spec(groupid = "group 5", localproviderid = "prov 5", client_ds_id = 5, localspecialtycode = "local code 5"),
    prov_spec(groupid = "group 6", localproviderid = "prov 6", client_ds_id = 6, localspecialtycode = "local code 6")
  )

  val zhProviderMasterXRef: DataFrame = mkDataFrame(
    zh_provider_master_xref(groupid = "group 2", localproviderid = "prov 1", client_ds_id = 1),
    zh_provider_master_xref(groupid = "group 1", localproviderid = "prov 2", client_ds_id = 1),
    zh_provider_master_xref(groupid = "group 1", localproviderid = "prov 1", client_ds_id = 2),
    zh_provider_master_xref(groupid = "group 3", localproviderid = "prov 3", client_ds_id = 3, master_hgprovid = "1234"),
    zh_provider_master_xref(groupid = "group 4", localproviderid = "prov 4", client_ds_id = 4, master_hgprovid = "4567"),
    zh_provider_master_xref(groupid = "group 5", localproviderid = "prov 5", client_ds_id = 5, master_hgprovid = "6789"),
    zh_provider_master_xref(groupid = "group 6", localproviderid = "prov 6", client_ds_id = 6, master_hgprovid = "5789")
  )

  val mapSpecialty: DataFrame = mkDataFrame(
    map_specialty(mnemonic = "specialty 1", groupid = "group 1", cui = "123"),
    map_specialty(mnemonic = "local code 4", groupid = "group 4", cui = "345")
  )

  val zoSpecialty: DataFrame = mkDataFrame(
    zo_specialty(hts_cui = "123", ii_code = "specialty 1"),
    zo_specialty(hts_cui = "345", ii_code = "specialty 4")
  )

  val mapSpecialtyII: DataFrame = mkDataFrame(
    map_specialty_ii(groupid = "group 3", local_code = "local code 3", ii_code = "specialty 3"),
    map_specialty_ii(groupid = "group 4", local_code = "local code 4"),
    map_specialty_ii(groupid = "group 5", local_code = "local code 5", ii_code = "specialty 5"),
    map_specialty_ii(groupid = "group 6", local_code = "local code 6", ii_code = "specialty 6")
  )

  val ppBpoProviderDetail: DataFrame = mkDataFrame(
    pp_bpo_provider_detail(groupid = "group 1", providerid = "prov 1", specialty = "specialty 1")
  )

  val ppBpoPhysicianKey: DataFrame = mkDataFrame(
    pp_bpo_physician_key(providerid = "prov 1", groupid = "group 1")
  )

  val ppBpoPharmacyClaims: DataFrame = mkDataFrame(
    pp_bpo_pharmacy_claims(prescprovider = "prov 1"),
    pp_bpo_pharmacy_claims(prescprovider = "prov 2"),
    pp_bpo_pharmacy_claims(prescprovider = "prov 3"),
    pp_bpo_pharmacy_claims(prescprovider = "1234"),
    pp_bpo_pharmacy_claims(pharmacyid = "pharmacy id 1")
  )

  val ppBpoMedicalClaims: DataFrame = mkDataFrame(
    pp_bpo_medical_claims(serviceproviderid = "svc prov 1"),
    pp_bpo_medical_claims(billingproviderid = "4567"),
    pp_bpo_medical_claims(orderingproviderid = "5789")
  )

  val ppBpoMemberDetail: DataFrame = mkDataFrame(
    pp_bpo_member_detail(pcpid = "pcp 1")
  )

  val ppBpoProviderDetailSpans: DataFrame = mkDataFrame(
    pp_bpo_provider_detail_spans(providerid = "6789", provaffiliationid = "prov affil id 1"),
    pp_bpo_provider_detail_spans(providerid = "provider 2")
  )


  val expectedOutput: Seq[pp_bpo_physician_key] = Seq(
    pp_bpo_physician_key(
      groupid = "group 1",
      providerid = "prov 1",
      providerkey = "prov 1",
      specialty = "specialty 1"
    ),
    pp_bpo_physician_key(
      groupid = "group 3",
      providerid = "1234",
      providerkey = "1234",
      specialty = "specialty 3"
    ),
    pp_bpo_physician_key(
      groupid = "group 4",
      providerid = "4567",
      providerkey = "4567",
      specialty = "specialty 4"
    ),
    pp_bpo_physician_key(
      groupid = "group 6",
      providerid = "5789",
      providerkey = "5789",
      specialty = "specialty 6"
    ),
    pp_bpo_physician_key(
      groupid = "group 5",
      providerid = "6789",
      providerkey = "6789",
      specialty = "specialty 5"
    )
  )

  testQuery(
    testName = "test PP_BPO_PHYSICIAN_KEY",
    query = PP_BPO_PHYSICIAN_KEY,
    inputs = Map(
      "PROV_SPEC" -> provSpec,
      "ZH_PROVIDER_MASTER_XREF" -> zhProviderMasterXRef,
      "MAP_SPECIALTY" -> mapSpecialty,
      "ZO_SPECIALTY" -> zoSpecialty,
      "MAP_SPECIALTY_II" -> mapSpecialtyII,
      "PP_BPO_PROVIDER_DETAIL" -> ppBpoProviderDetail,
      "PP_BPO_PHARMACY_CLAIMS" -> ppBpoPharmacyClaims,
      "PP_BPO_MEDICAL_CLAIMS" -> ppBpoMedicalClaims,
      "PP_BPO_MEMBER_DETAIL" -> ppBpoMemberDetail,
      "PP_BPO_PROVIDER_DETAIL_SPANS" -> ppBpoProviderDetailSpans
    ),
    expectedOutput = expectedOutput
  )

}
