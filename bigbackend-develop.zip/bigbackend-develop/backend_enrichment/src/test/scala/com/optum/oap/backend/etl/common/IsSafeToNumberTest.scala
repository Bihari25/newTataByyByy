package com.optum.oap.backend.etl.common

import com.optum.oap.testutils.TestSparkSession
import org.apache.spark.sql.functions._
import org.junit.runner.RunWith
import org.scalatest.FlatSpec
import org.scalatest.Matchers._
import org.scalatest.junit.JUnitRunner

/**
  *
  * Copyright 2019 Optum Analytics
  *
  * Date: 5/6/19
  *
  * Creator: bpokharel(bishu)
  */
@RunWith(classOf[JUnitRunner])
class IsSafeToNumberTest extends FlatSpec with TestSparkSession {
  private val spark = sparkSession

  import spark.implicits._

  behavior of "IsSafeToNumber"

  def safeToNumberTest(str: String, expectedResult: Boolean): Unit = {

    it should s"check if $str is convertable to number with result $expectedResult " in {

      val df = Seq(
        SafeToNumberTest(str)
      ).toDF()

      val output = df.select(IsSafeToNumber.isSafeToNumber(lit(str))).as[Boolean].collect().head
      output shouldEqual expectedResult
    }
  }

  //  positive cases
  safeToNumberTest("99", expectedResult = true)
  safeToNumberTest("3", expectedResult = true)
  safeToNumberTest("-3", expectedResult = true)
  safeToNumberTest("-99", expectedResult = true)
  safeToNumberTest("01.99", expectedResult = true)
  safeToNumberTest("-1.0", expectedResult = true)
  safeToNumberTest("12", expectedResult = true)
  safeToNumberTest("12.45", expectedResult = true)
  safeToNumberTest("45.0", expectedResult = true)
  safeToNumberTest("0.12", expectedResult = true)
  safeToNumberTest("02.34", expectedResult = true)
  safeToNumberTest("-02.34", expectedResult = true)
  safeToNumberTest("0.0", expectedResult = true)
  safeToNumberTest("0.10", expectedResult = true)

  // negative cases
  safeToNumberTest("sdf", expectedResult = false)
  safeToNumberTest("1w.12", expectedResult = false)
  safeToNumberTest("12 34", expectedResult = false)
  safeToNumberTest(".", expectedResult = false)

}

case class SafeToNumberTest(str: String)

