package com.optum.oap.backend.etl.common

import com.optum.oap.testutils.TestSparkSession
import org.junit.runner.RunWith
import org.scalatest.FlatSpec
import org.scalatest.Matchers._
import org.scalatest.junit.JUnitRunner

@RunWith(classOf[JUnitRunner])
class EscapeSqlLikeStringTest extends FlatSpec with TestSparkSession{

  private val spark = sparkSession

  import spark.implicits._

  behavior of "EscapeSqlLikeString"

  it should "correctly escape ( in the pattern" in {
    val data = Seq(
      SampleValue("children's care group, inc - (dayton chi,")
    ).toDF()

    val output = data.select(EscapeSqlLikeString.escapeString($"value")).as[String].collect().head

    output shouldEqual "children's care group, inc - \\(dayton chi,"
  }

  it should "escape } in the pattern" in {
    val data = Seq(
      SampleValue("testing.hospital}")
    ).toDF()

    val output = data.select(EscapeSqlLikeString.escapeString($"value")).as[String].collect().head

    output shouldEqual "testing\\.hospital\\}"
  }

  it should "correctly escape special characters" in {
    val data = Seq(
      SampleValue("testing string (compare) {string")
    ).toDF()

    val output = data.select(EscapeSqlLikeString.escapeString($"value")).as[String].collect().head

    output shouldEqual "testing string \\(compare\\) \\{string"
  }

}
