package com.optum.oap.backend.etl.bpo

import com.optum.oap.backend.BEQueryTestFramework
import com.optum.oap.cdr.models.{zh_provider_master, _}
import org.apache.spark.sql.DataFrame

/**
  *
  * Copyright 2019 Optum Analytics
  *
  * Date: 5/20/19
  *
  * Creator: bpokharel(bishu)
  */
class PP_BPO_PROVIDER_XWALK_Test extends BEQueryTestFramework {

  behavior of "translated query PP_BPO_PROVIDER_XWALK"

  import spark.implicits._

  val zh_provider_master_xref_IN: DataFrame = mkDataFrame(
    zh_provider_master_xref(groupid = "H000000", client_ds_id = 1, localproviderid = "PR1", hgprovid = 1000l, master_hgprovid = "1000"),
    zh_provider_master_xref(groupid = "H000000", client_ds_id = 2, localproviderid = "PR2", hgprovid = 2000l, master_hgprovid = "2000"),
    zh_provider_master_xref(groupid = "H000000", client_ds_id = 3, localproviderid = "PR3", hgprovid = 3000l, master_hgprovid = "3000")
  )

  val zh_provider_master_IN: DataFrame = mkDataFrame(
    zh_provider_master(groupid = "H000000", master_hgprovid = "1000", npi = "n1", providerexclusionflag = "N", providername = "name1"),
    zh_provider_master(groupid = "H000000", master_hgprovid = "2000", npi = "n2", providerexclusionflag = "N", providername = "name2"),
    zh_provider_master(groupid = "H000000", master_hgprovid = "3000", npi = "n3", providerexclusionflag = "N", providername = "name3")
  )

  val zo_bpo_map_employer_IN: DataFrame = mkDataFrame(
    zo_bpo_map_employer(groupid = "H000000", client_ds_id = 1, employeraccountid = "BCBS"),
    zo_bpo_map_employer(groupid = "H000000", client_ds_id = 2, employeraccountid = "CEE")
  )

  val bpo_provider_xwlk_OUT: Seq[pp_bpo_provider_xwalk] = Seq(
    pp_bpo_provider_xwalk(groupid = "H000000", client_ds_id = 1, providerid = "PR1", master_hgprovid = "1000", npi = "n1", o1_plan_source = "BCBS"),
    pp_bpo_provider_xwalk(groupid = "H000000", client_ds_id = 2, providerid = "PR2", master_hgprovid = "2000", npi = "n2", o1_plan_source = "CEE")
  )


  testQuery(
    testName = "test PP_BPO_PROVIDER_XWALK",
    query = PP_BPO_PROVIDER_XWALK,
    inputs = Map(
      "ZH_PROVIDER_MASTER_XREF" -> zh_provider_master_xref_IN,
      "ZO_BPO_MAP_EMPLOYER" -> zo_bpo_map_employer_IN,
      "ZH_PROVIDER_MASTER" -> zh_provider_master_IN
    ),
    expectedOutput = bpo_provider_xwlk_OUT
  )
}
