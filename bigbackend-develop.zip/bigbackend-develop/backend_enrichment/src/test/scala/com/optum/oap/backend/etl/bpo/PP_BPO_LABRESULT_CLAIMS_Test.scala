package com.optum.oap.backend.etl.bpo

import java.sql.Timestamp
import java.sql.Date

import com.optum.oap.backend.BEQueryTestFramework
import com.optum.oap.backend.cdrTempModel.{temp_bpo_calculate_params, temp_bpo_patients}
import com.optum.oap.cdr.models.{observation, pp_bpo_labresult_claims, _}
import org.apache.spark.sql.DataFrame

/**
  *
  * Copyright 2019 Optum Analytics
  *
  * Date: 5/23/19
  *
  * Creator: bpokharel(bishu)
  */
class PP_BPO_LABRESULT_CLAIMS_Test extends BEQueryTestFramework {

  import spark.implicits._

  val temp_bpo_patients_IN: DataFrame = mkDataFrame(
    temp_bpo_patients(groupid = "H000000", grp_mpi = "101", payer = 3),
    temp_bpo_patients(groupid = "H000000", grp_mpi = "101", payer = 2),
    temp_bpo_patients(groupid = "H000000", grp_mpi = "101", payer = 1),
    temp_bpo_patients(groupid = "H000000", grp_mpi = "101", payer = 2),
    temp_bpo_patients(groupid = "H000000", grp_mpi = "102", payer = 1)
  )

  val labresult_IN: DataFrame = mkDataFrame(
    labresult(groupid = "H000000", grp_mpi = "101", datasrc = "results", datecollected = Timestamp.valueOf("2016-10-24 16:02:00"), dateavailable = Timestamp.valueOf("2016-10-24 16:02:00"), localresult = "0.85", localcode = "1071", mappedcode = "CH000660", resulttype = null, mappedunits = "CH000150", normalizedvalue = 0.85, client_ds_id = 1),
    labresult(groupid = "H000000", grp_mpi = "101", datasrc = "results", datecollected = Timestamp.valueOf("2018-02-04 21:53:00"), dateavailable = Timestamp.valueOf("2018-02-04 21:53:00"), localresult = "91", localcode = "3658", mappedcode = "CH000660", resulttype = null, mappedunits = "CH000893", normalizedvalue = 91.0, client_ds_id = 1),
    labresult(groupid = "H000000", grp_mpi = "101", datasrc = "results", datecollected = null, dateavailable = Timestamp.valueOf("2018-02-04 22:10:00"), localresult = "126", localcode = "1076", mappedcode = "CH000660", resulttype = null, mappedunits = "CH000162", normalizedvalue = 126.0, client_ds_id = 1)
  )

  val observation_IN: DataFrame = mkDataFrame(
    observation(grp_mpi = "102", client_ds_id = 1, localresult = "183", obstype = "DBP", obsresult = ".18", groupid = "H000000", local_obs_unit = "ml", localcode = "4664.653398_293", obsdate = Timestamp.valueOf("2018-06-05 13:38:00"), datasrc = "clinical_event"),
    observation(grp_mpi = "102", client_ds_id = 1, localresult = "183", obstype = "DBP", obsresult = ".18", groupid = "H000000", local_obs_unit = "ml", localcode = "4664.653398_293", obsdate = null, datasrc = "clinical_event"),
    observation(grp_mpi = "101", client_ds_id = 1, localresult = "183", obstype = "DBP", obsresult = ".98", groupid = "H000000", local_obs_unit = "gl", localcode = "4664.654398_293", obsdate = Timestamp.valueOf("2010-07-05 13:38:00"), datasrc = "clinical_event"), // outside date range
    observation(grp_mpi = "102", client_ds_id = 1, localresult = "183", obstype = "DBP", obsresult = ".98", groupid = "H000000", local_obs_unit = "gl", localcode = "4664.654398_293", obsdate = Timestamp.valueOf("2018-06-01 13:38:00"), datasrc = "foam"),  // datasrc = foam, which is excluded
    observation(grp_mpi = "101", client_ds_id = 1, localresult = "183", obstype = "CH004625", obsresult = ".98", groupid = "H000000", local_obs_unit = "gl", localcode = "4664.654398_293", obsdate = Timestamp.valueOf("2010-07-05 13:38:00"), datasrc = "clinical_event") // outside date range, CH004625
  )

  val temp_bpo_calculate_params_IN: DataFrame = mkDataFrame(
    temp_bpo_calculate_params(engineStartDate = Date.valueOf("2015-04-01"), engineStartDate2 = Date.valueOf("2015-04-01"), engineStartDate3 = Date.valueOf("2015-04-01"), engineEndDate = Date.valueOf("2019-03-31"), startDate = Date.valueOf("2015-01-01"))
  )

  val mv_hts_domain_concept_IN: DataFrame = mkDataFrame(
    mv_hts_domain_concept(concept_cui = "CH000663", domain_cui = "CH001300", concept_name = "AK", domain_name = "State", is_valid = "Y")
  )

  val map_hts_term_IN: DataFrame = mkDataFrame(
    map_hts_term(hts_cui = "CH000660", term_code = "1111-2222", terminology_cui = "CH002050", preferred = "Y", dts_version = 1)
  )

  val map_smoking_status_IN: DataFrame = mkDataFrame(
    map_smoking_status(groupid = "H000000", mnemonic = "7009.use.8", cui = "CH000038", dts_version = 1)
  )

  val map_tobacco_use_IN: DataFrame = mkDataFrame(
    map_tobacco_use(groupid = "H000000", localcode = "6525.tobuser.2", cui = "CH000038", dts_version = 1)
  )

  val map_smoking_cessation_IN: DataFrame = mkDataFrame(
    map_smoking_cessation(groupid = "H000000", local_code = "5423.221", cui = "CH000038", dts_version = 1)
  )

  val map_tobacco_cessation_IN: DataFrame = mkDataFrame(
    map_tobacco_cessation(groupid = "H000000", localcode = "3461.21911", cui = "CH000038", dts_version = 1)
  )

  val zo_bpo_loinc_units_IN: DataFrame = mkDataFrame(
    zo_bpo_loinc_units(loinc = "1111-2222", units = "ng/mL", dts_version = 1),
    zo_bpo_loinc_units(loinc = "8462-4", units = "mg/mL", dts_version = 1)
  )

  val pp_bpo_labresult_claims_OUT: Seq[pp_bpo_labresult_claims] = Seq(
    pp_bpo_labresult_claims(groupid = "H000000", memberid = "101", servicedate = Timestamp.valueOf("2016-10-24 00:00:00"), loinc = "1111-2222", testresultnumber = 0.85, testresulttext = null, testresultunits = "ng/mL", fastingstatus = "Y", claimheader = "LAB1.1", labsource = "AD", healthplansource = "PROVIDER", coverageclasscode = "MED"),
    pp_bpo_labresult_claims(groupid = "H000000", memberid = "101", servicedate = Timestamp.valueOf("2018-02-04 00:00:00"), loinc = "1111-2222", testresultnumber = 126.0, testresulttext = null, testresultunits = "ng/mL", fastingstatus = "Y", claimheader = "LAB1.2", labsource = "AD", healthplansource = "PROVIDER", coverageclasscode = "MED"),
    pp_bpo_labresult_claims(groupid = "H000000", memberid = "102", servicedate = Timestamp.valueOf("2018-06-05 00:00:00"), loinc = "8462-4", testresultnumber = 0.18, testresulttext = null, testresultunits = "mg/mL", fastingstatus = "Y", claimheader = "LAB1.3", labsource = "AD", healthplansource = "PAYER", coverageclasscode = "MED")
  )

  testQuery(
    testName = "test PP_BPO_LABRESULT_CLAIMS",
    query = PP_BPO_LABRESULT_CLAIMS,
    inputs = Map(
      "TEMP_BPO_PATIENTS" -> temp_bpo_patients_IN,
      "LABRESULT" -> labresult_IN,
      "OBSERVATION" -> observation_IN,
      "TEMP_BPO_CALCULATE_PARAMS" -> temp_bpo_calculate_params_IN,
      "MV_HTS_DOMAIN_CONCEPT" -> mv_hts_domain_concept_IN,
      "MAP_HTS_TERM" -> map_hts_term_IN,
      "MAP_SMOKING_STATUS" -> map_smoking_status_IN,
      "MAP_TOBACCO_USE" -> map_tobacco_use_IN,
      "MAP_SMOKING_CESSATION" -> map_smoking_cessation_IN,
      "MAP_TOBACCO_CESSATION" -> map_tobacco_cessation_IN,
      "ZO_BPO_LOINC_UNITS" -> zo_bpo_loinc_units_IN
    ),
    expectedOutput = pp_bpo_labresult_claims_OUT
  )

}
