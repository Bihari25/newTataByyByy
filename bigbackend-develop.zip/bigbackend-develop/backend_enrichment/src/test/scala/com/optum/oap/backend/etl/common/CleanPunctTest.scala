package com.optum.oap.backend.etl.common

import com.optum.oap.testutils.TestSparkSession
import org.apache.spark.sql.functions.lit
import org.junit.runner.RunWith
import org.scalatest.FlatSpec
import org.scalatest.Matchers._
import org.scalatest.junit.JUnitRunner


/**
  *
  * Copyright 2019 Optum Analytics
  *
  * Date: 10/10/2019
  *
  * Creator: rrogers2
  */
@RunWith(classOf[JUnitRunner])
class CleanPunctTest extends FlatSpec with TestSparkSession {

  private val spark = sparkSession

  import spark.implicits._

  behavior of "CleanPunct UDF"

  def cleanPunctTest(str: String, expectedResult: String): Unit = {

    it should s"clean $str to remove extraneous elements with result $expectedResult " in {

      val df = Seq(
        str
      ).toDF()

      val output = df.select(CleanPunct.cleanPunctUDF(lit(str))).as[String].collect().head
      output shouldEqual expectedResult
    }
  }

  cleanPunctTest(str = "JR", expectedResult = "JR")
  cleanPunctTest(str = null, expectedResult = null)
  cleanPunctTest("Jones, Rocky R", expectedResult = "JONES ROCKY R")
  cleanPunctTest("J.R.", expectedResult = "JR")
  cleanPunctTest("KATZ                LISA     E, ", expectedResult = "KATZ LISA E")

}