package com.optum.oap.backend.etl.bpo

import java.sql.{Date, Timestamp}

import com.optum.oap.backend.BEQueryTestFramework
import com.optum.oap.backend.cdrTempModel.{temp_bpo_calculate_params, temp_bpo_patients}
import com.optum.oap.cdr.models._
import org.apache.spark.sql.DataFrame

class PP_BPO_PROBLIST_DOCUMENTATION_Test extends BEQueryTestFramework {

  import spark.implicits._

  //Test 1: Happy flow with Payer as healthplansource
  {
    val tempBpoPatients: DataFrame = mkDataFrame(
      temp_bpo_patients(groupid = "group 1", grp_mpi = "member 1", payer = 1)
    )

    val diag: DataFrame = mkDataFrame(
      diagnosis(groupid = "group 1", grp_mpi = "member 1", client_ds_id = 123, codetype = "ICD10", mappeddiagnosis = "Diag 1", dx_timestamp = Timestamp.valueOf("2016-05-03 1:00:00"), resolutiondate = Timestamp.valueOf("2016-05-04 11:00:00"), datasrc = "datasource 1")
    )

    val mapProbList: DataFrame = mkDataFrame(
      map_prob_list(groupid = "group 1", datasrc = "datasource 1", is_problemlist = "Y")
    )

    val tempParamsIn: DataFrame = mkDataFrame(
        temp_bpo_calculate_params(engineStartDate = Date.valueOf("2015-04-01"), engineStartDate2 = Date.valueOf("2015-04-01"), engineStartDate3 = Date.valueOf("2015-04-01"), engineEndDate = Date.valueOf("2019-03-31"), startDate = Date.valueOf("2015-01-01"))
    )

    val expectedOutput: Seq[pp_bpo_problist_documentation] = Seq(
      pp_bpo_problist_documentation(
        groupid = "group 1",
        memberid = "member 1",
        problem_list_id = "PBL123.1",
        diagnosis_taxonomy = "ICD-10-CM",
        diagnosis_code = "Diag 1",
        problem_start_date = Timestamp.valueOf("2016-05-03 1:00:00"),
        problem_resolved_date = Timestamp.valueOf("2016-05-04 11:00:00"),
        healthplansource = "PAYER"
      )
    )

    testQuery(
      testName = "test PP_BPO_PROBLIST_DOCUMENTATION with Payer as healthplansource",
      query = PP_BPO_PROBLIST_DOCUMENTATION,
      inputs = Map(
        "TEMP_BPO_PATIENTS" -> tempBpoPatients,
        "DIAGNOSIS" -> diag,
        "MAP_PROB_LIST" -> mapProbList,
        "TEMP_BPO_CALCULATE_PARAMS" -> tempParamsIn
      ),
      expectedOutput = expectedOutput
    )
  }

  //Test 2: Happy flow with Provider as healthplansource
  {
    val tempBpoPatients: DataFrame = mkDataFrame(
      temp_bpo_patients(groupid = "group 1", grp_mpi = "member 1", payer = 2)
    )

    val diag: DataFrame = mkDataFrame(
      diagnosis(groupid = "group 1", grp_mpi = "member 1", client_ds_id = 123, codetype = "ICD10", mappeddiagnosis = "Diag 1", dx_timestamp = Timestamp.valueOf("2016-05-03 1:00:00"), resolutiondate = Timestamp.valueOf("2016-05-04 11:00:00"), datasrc = "datasource 1")
    )

    val mapProbList: DataFrame = mkDataFrame(
      map_prob_list(groupid = "group 1", datasrc = "datasource 1", is_problemlist = "Y")
    )

    val tempParamsIn: DataFrame = mkDataFrame(
        temp_bpo_calculate_params(engineStartDate = Date.valueOf("2015-04-01"), engineStartDate2 = Date.valueOf("2015-04-01"), engineStartDate3 = Date.valueOf("2015-04-01"), engineEndDate = Date.valueOf("2019-03-31"), startDate = Date.valueOf("2015-01-01"))
    )

    val expectedOutput: Seq[pp_bpo_problist_documentation] = Seq(
      pp_bpo_problist_documentation(
        groupid = "group 1",
        memberid = "member 1",
        problem_list_id = "PBL123.1",
        diagnosis_taxonomy = "ICD-10-CM",
        diagnosis_code = "Diag 1",
        problem_start_date = Timestamp.valueOf("2016-05-03 1:00:00"),
        problem_resolved_date = Timestamp.valueOf("2016-05-04 11:00:00"),
        healthplansource = "PROVIDER"
      )
    )

    testQuery(
      testName = "test PP_BPO_PROBLIST_DOCUMENTATION",
      query = PP_BPO_PROBLIST_DOCUMENTATION,
      inputs = Map(
        "TEMP_BPO_PATIENTS" -> tempBpoPatients,
        "DIAGNOSIS" -> diag,
        "MAP_PROB_LIST" -> mapProbList,
        "TEMP_BPO_CALCULATE_PARAMS" -> tempParamsIn
      ),
      expectedOutput = expectedOutput
    )
  }

  //Test 3: Happy flow with more data
  {
    val tempBpoPatients: DataFrame = mkDataFrame(
      temp_bpo_patients(groupid = "group 1", grp_mpi = "member 1", payer = 0),
      temp_bpo_patients(groupid = "group 1", grp_mpi = "member 1", payer = 1)
    )

    val diag: DataFrame = mkDataFrame(
      diagnosis(groupid = "group 1", grp_mpi = "member 1", client_ds_id = 123, codetype = "ICD10", mappeddiagnosis = "Diag 1", dx_timestamp = Timestamp.valueOf("2016-05-03 1:00:00"), resolutiondate = Timestamp.valueOf("2016-05-04 11:00:00"), datasrc = "datasource 1"),
      diagnosis(groupid = "group 1", grp_mpi = "member 1", client_ds_id = 456, codetype = "ICD9", mappeddiagnosis = "Diag 3", dx_timestamp = Timestamp.valueOf("2017-05-03 1:00:00"), resolutiondate = Timestamp.valueOf("2017-05-04 11:00:00"), datasrc = "datasource 1"),
      //Following record should not be loaded as datasource has is_problemlist != Y
      diagnosis(groupid = "group 1", grp_mpi = "member 1", client_ds_id = 234, codetype = "ICD10", mappeddiagnosis = "Diag 2", dx_timestamp = Timestamp.valueOf("2016-07-03 1:00:00"), resolutiondate = Timestamp.valueOf("2016-07-04 11:00:00"), datasrc = "datasource 2"),
      //Following record should not be loaded as dx_timestamp is not between extract start and end dates
      diagnosis(groupid = "group 1", grp_mpi = "member 1", client_ds_id = 456, codetype = "ICD9", mappeddiagnosis = "Diag 4", dx_timestamp = Timestamp.valueOf("2015-03-01 10:00:00"), resolutiondate = Timestamp.valueOf("2015-03-01 11:00:00"), datasrc = "datasource 1"),
      //Following record should not be loaded as codetype is not ICD9 or ICD10
      diagnosis(groupid = "group 1", grp_mpi = "member 1", client_ds_id = 456, codetype = "ICD", mappeddiagnosis = "Diag", dx_timestamp = Timestamp.valueOf("2016-03-01 10:00:00"), resolutiondate = Timestamp.valueOf("2016-03-01 11:00:00"), datasrc = "datasource 1"),
      //Following records should not be loaded as mappeddiagnosis code length is not between 3 and 8
      diagnosis(groupid = "group 1", grp_mpi = "member 1", client_ds_id = 456, codetype = "ICD9", mappeddiagnosis = "Di", dx_timestamp = Timestamp.valueOf("2016-03-01 10:00:00"), resolutiondate = Timestamp.valueOf("2016-03-01 11:00:00"), datasrc = "datasource 1"),
      diagnosis(groupid = "group 1", grp_mpi = "member 1", client_ds_id = 456, codetype = "ICD9", mappeddiagnosis = "Diagnois 10", dx_timestamp = Timestamp.valueOf("2016-03-01 10:00:00"), resolutiondate = Timestamp.valueOf("2016-03-01 11:00:00"), datasrc = "datasource 1")
    )

    val mapProbList: DataFrame = mkDataFrame(
      map_prob_list(groupid = "group 1", datasrc = "datasource 1", is_problemlist = "Y"),
      map_prob_list(groupid = "group 1", datasrc = "datasource 2", is_problemlist = "N")
    )

    val tempParamsIn: DataFrame = mkDataFrame(
      temp_bpo_calculate_params(engineStartDate = Date.valueOf("2015-04-01"), engineStartDate2 = Date.valueOf("2015-04-01"), engineStartDate3 = Date.valueOf("2015-04-01"), engineEndDate = Date.valueOf("2019-03-31"), startDate = Date.valueOf("2015-01-01"))
    )

    val expectedOutput: Seq[pp_bpo_problist_documentation] = Seq(
      pp_bpo_problist_documentation(
        groupid = "group 1",
        memberid = "member 1",
        problem_list_id = "PBL123.1",
        diagnosis_taxonomy = "ICD-10-CM",
        diagnosis_code = "Diag 1",
        problem_start_date = Timestamp.valueOf("2016-05-03 1:00:00"),
        problem_resolved_date = Timestamp.valueOf("2016-05-04 11:00:00"),
        healthplansource = "PAYER"
      ),
      pp_bpo_problist_documentation(
        groupid = "group 1",
        memberid = "member 1",
        problem_list_id = "PBL456.2",
        diagnosis_taxonomy = "ICD-9-CM",
        diagnosis_code = "Diag 3",
        problem_start_date = Timestamp.valueOf("2017-05-03 1:00:00"),
        problem_resolved_date = Timestamp.valueOf("2017-05-04 11:00:00"),
        healthplansource = "PAYER"
      )
    )

    testQuery(
      testName = "test PP_BPO_PROBLIST_DOCUMENTATION with Provider as healthplansource",
      query = PP_BPO_PROBLIST_DOCUMENTATION,
      inputs = Map(
        "TEMP_BPO_PATIENTS" -> tempBpoPatients,
        "DIAGNOSIS" -> diag,
        "MAP_PROB_LIST" -> mapProbList,
        "TEMP_BPO_CALCULATE_PARAMS" -> tempParamsIn
      ),
      expectedOutput = expectedOutput
    )
  }
}
