package com.optum.oap.backend.etl.common

import com.optum.oap.backend.BEQueryTestFramework
import com.optum.oap.backend.etl.common.ExtractValue.extract_value
import org.apache.spark.sql.functions._
import org.junit.runner.RunWith
import org.scalatest.Matchers._
import org.scalatest.junit.JUnitRunner

@RunWith(classOf[JUnitRunner])
class ExtractValueTest extends BEQueryTestFramework{

  behavior of "extract_value udf"

  it should "extract value from given string" in {

    val actualOutcome = Seq(

      // Empty string, should return null after trim
      extract_value(lit("   "), lit(null)).expr.eval()

      /* length > 25 and there is space after 25th character, so filtered at space and "123" is omitted
         Should return 12345678912345678912
       */
      , extract_value(lit("12345678912345678912iu/l 123"), lit(null)).expr.eval().toString

      /* length > 25 and no space after 25th character, so full string is taken without filtering at space
         "contaminated" is filtered and returned as 123456789123456789iu/l c
         For 1st iteration, v_nbr becomes 123456789123456789iu/l
         "iu/l" is filtered and returned as 123456789123456789
       */
      , extract_value(lit("123456789123456789iu/l contaminated"), lit(null)).expr.eval().toString

      /* Should not return 123456
         "a1c" gets filtered in 1st pass and "contaminated 123456 a" would be the result
         "contaminated" gets filtered in 2nd pass "c" would be the result
         So, should return -2000
       */
      , extract_value(lit("contaminated 123456 a1c"), lit(null)).expr.eval()

      // Should return -2000 + p_debug = -1998, because v_nbr becomes null due to v_pos exceeding the no.of occurrence
      , extract_value(lit("01 02"), lit(2)).expr.eval().toString

      // Should return -2000 + p_debug = -2000, because v_nbr becomes null due to v_pos exceeding the no.of occurrence and p_debug is 0
      , extract_value(lit("01 02"), lit(null)).expr.eval()

      // Should return -4000 + p_debug = -3998, because v_match becomes null after replace and regexp_replace
      , extract_value(lit("sample|sample"), lit(2)).expr.eval().toString

      // Should return -4000 + p_debug = -4000, because v_match becomes null after replace and regexp_replace and p_debug is 0
      , extract_value(lit("sample|sample"), lit(null)).expr.eval()

      // Should return 23 after v_uom removal and v_numeric is null filter is true
      , extract_value(lit("2+3=iU/LTesTIU"), lit(2)).expr.eval().toString

      // Should return 2345 after v_uom removal and v_numeric is null filter is false
      , extract_value(lit("2+3=iU/L4567"), lit(2)).expr.eval().toString

      // Should return 23, because both condition_1 and condition_3 fails and returns v_numeric
      , extract_value(lit("23"), lit(2)).expr.eval().toString

      /* Should not return 123, because v_nbr becomes null in the 3rd iteration after replacing ","
         So, should return -2000 + p_debug = -1998
       */
      , extract_value(lit("01 02 ,,, 123"), lit(2)).expr.eval().toString

      /* Should not return 123, because v_pos exceeds 5
         So, should return -2000 + p_debug = -1998
       */
      , extract_value(lit("01 02 03 04 05 123"), lit(2)).expr.eval().toString

      /* Should not return 23, because condition_2 will be true in 2nd iteration
         So, should return 123
       */
      , extract_value(lit("01 23  jan  04 123"), lit(2)).expr.eval().toString

      , extract_value(lit("123.321"), lit(null)).expr.eval().toString

    )

    val expectedOutcome = Seq(

      null
      , "12345678912345678912"
      , "123456789123456789"
      , null
      , "-1998"
      , null
      , "-3998"
      , null
      , "23"
      , "2345"
      , "23"
      , "-1998"
      , "-1998"
      , "123"
      , "123.321"

    )

    actualOutcome shouldBe expectedOutcome
  }
}