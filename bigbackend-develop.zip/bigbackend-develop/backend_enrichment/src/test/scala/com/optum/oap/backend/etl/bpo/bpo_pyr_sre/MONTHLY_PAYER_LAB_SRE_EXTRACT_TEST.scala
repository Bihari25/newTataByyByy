package com.optum.oap.backend.etl.bpo.bpo_pyr_sre

import com.optum.oap.backend.BEQueryTestFramework
import com.optum.oap.backend.cdrTempModel.monthly_payer_lab_sre
import com.optum.oap.cdr.models.{pp_bpo_labresult_claims, pp_bpo_member_detail}
import org.apache.spark.sql.DataFrame

class MONTHLY_PAYER_LAB_SRE_EXTRACT_TEST extends BEQueryTestFramework {

  import spark.implicits._

  val originalSQL =
    """
      |SELECT
      |    lab.memberid
      |,   date_format (lab.servicedate,'yyyy-MM-dd')
      |                                AS servicedate
      |,   lab.loinc
      |,   lab.testresultnumber
      |,   lab.testresultunits
      |,   lab.testresulttext
      |,   lab.fastingstatus
      |,   lab.claimheader
      |,   lab.labsource
      |,   lab.healthplansource
      |,   lab.coverageclasscode
      |,   lab.cpt_code
      |,  cast(null as string) as POS
      |,  cast(null as string) as Prov_Type_Code
      |,  cast(null as string) as Prov_Specialty_Code
      |,  cast(null as string) as Prov_Key
      |FROM
      |    pp_bpo_labresult_claims lab
      |INNER JOIN
      |    pp_bpo_member_detail elig
      |    ON
      |    (   elig.groupid = lab.groupid
      |    AND elig.memberid = lab.memberid
      |    AND elig.healthplansource = lab.healthplansource
      |    )
      |WHERE
      |    lab.healthplansource='PAYER'
      |AND
      |    lab.servicedate BETWEEN elig.effectivedate AND elig.enddate
    """.stripMargin

  val ppBpoLabresultClaims: DataFrame = mkDataFrame(
    pp_bpo_labresult_claims(groupid = "H000000", memberid = "m1", claimheader = "ch1", healthplansource = "PAYER", servicedate = java.sql.Timestamp.valueOf("2020-01-01 00:00:00")),
    pp_bpo_labresult_claims(groupid = "H000000", memberid = "m2", healthplansource = "PAYER", servicedate = java.sql.Timestamp.valueOf("2011-01-01 00:00:00")),
    pp_bpo_labresult_claims(groupid = "H000000", memberid = "m3", healthplansource = "PAYER2", servicedate = java.sql.Timestamp.valueOf("2013-01-01 00:00:00"))
  )

  val ppBpoMemberDetail: DataFrame = mkDataFrame(
    pp_bpo_member_detail(groupid = "H000000", memberid = "m1", healthplansource = "PAYER", effectivedate = java.sql.Timestamp.valueOf("2014-01-01 00:00:00"), enddate = java.sql.Timestamp.valueOf("2029-04-30 00:00:00")),
    pp_bpo_member_detail(groupid = "H000000", memberid = "m2", healthplansource = "PAYER", effectivedate = java.sql.Timestamp.valueOf("2011-06-18 00:00:00"), enddate = java.sql.Timestamp.valueOf("2019-07-11 00:00:00"))
  )

  val expectedOutput: Seq[monthly_payer_lab_sre] = Seq(
    monthly_payer_lab_sre(memberid = "m1", claimheader = "ch1", servicedate = "2020-01-01", healthplansource = "PAYER")
  )

  testQuery(
    testName = "test MONTHLY_PAYER_LAB_SRE_EXTRACT",
    query = MONTHLY_PAYER_LAB_SRE_EXTRACT,
    inputs = Map(
      "PP_BPO_MEMBER_DETAIL" -> ppBpoMemberDetail,
      "PP_BPO_LABRESULT_CLAIMS" -> ppBpoLabresultClaims
    ),
    expectedOutput = expectedOutput
  )

  it should "output of new etl should match with original Spark SQL etl" in {
    ppBpoMemberDetail.createOrReplaceTempView("pp_bpo_member_detail")
    ppBpoLabresultClaims.createOrReplaceTempView("pp_bpo_labresult_claims")

    val originalOutput = spark.sql(originalSQL)

    checkThatDataFramesAreEqual(originalOutput, expectedOutput)
  }

}