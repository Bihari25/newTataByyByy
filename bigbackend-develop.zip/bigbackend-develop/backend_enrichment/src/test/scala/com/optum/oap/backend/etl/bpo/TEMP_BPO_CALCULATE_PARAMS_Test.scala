package com.optum.oap.backend.etl.bpo

import java.sql.Date

import com.optum.oap.backend.BEQueryTestFramework
import com.optum.oap.backend.cdrTempModel.temp_bpo_calculate_params
import com.optum.oap.cdr.models.{map_predicate_values, schema_init}
import org.apache.spark.sql.DataFrame

/**
  *
  * Copyright 2019 Optum Analytics
  *
  * Date: 5/17/19
  *
  * Creator: pavula1
  */
class TEMP_BPO_CALCULATE_PARAMS_Test extends BEQueryTestFramework {

  import spark.implicits._

  val schemaInit: DataFrame = mkDataFrame(
    schema_init(value = "201905", attribute = "release_cycle")
  )
  val mapPredicate: DataFrame = mkDataFrame(
    map_predicate_values(data_src = "BPO_START_DATE", entity = "BPO_TABLES", column_name = "EFFECTIVEDATE", column_value = "No", groupid="H000000")
  )

  val expectedOutput: Seq[temp_bpo_calculate_params] = Seq(
    temp_bpo_calculate_params(engineStartDate = Date.valueOf("2015-04-01"), engineStartDate2 = Date.valueOf("2015-04-01"), engineStartDate3 = Date.valueOf("2015-04-01"), engineEndDate = Date.valueOf("2019-03-31"), startDate = Date.valueOf("2015-01-01"))
  )


  testQuery(
    testName = "test TEMP_CALCULATE_PARAMS",
    query = TEMP_BPO_CALCULATE_PARAMS,
    inputs = Map(
      "SCHEMA_INIT" -> schemaInit,
      "MAP_PREDICATE_VALUES" -> mapPredicate
    ),
    expectedOutput = expectedOutput
  )

  val mapPredicate1: DataFrame = mkDataFrame(

    map_predicate_values(data_src = "BPO_START_DATE", entity = "BPO_TABLES", column_name = "EFFECTIVEDATE", column_value = "Yes", groupid="H000000"),

    //Just making sure if there is a group with No for 1 record still Yes is considered.
    map_predicate_values(data_src = "BPO_START_DATE", entity = "BPO_TABLES", column_name = "EFFECTIVEDATE", column_value = "No", groupid="H000000")
  )

  val expectedOutput1: Seq[temp_bpo_calculate_params] = Seq(
    temp_bpo_calculate_params(engineStartDate = Date.valueOf("1900-01-01"), engineStartDate2 = Date.valueOf("2015-04-01"), engineStartDate3 = Date.valueOf("2013-10-01"), engineEndDate = Date.valueOf("2019-03-31"), startDate = Date.valueOf("2015-01-01"))
  )

  testQuery(
    testName = "test with YES COLUMN_VALUE FOR TEMP_CALCULATE_PARAMS",
    query = TEMP_BPO_CALCULATE_PARAMS,
    inputs = Map(
      "SCHEMA_INIT" -> schemaInit,
      "MAP_PREDICATE_VALUES" -> mapPredicate1
    ),
    expectedOutput = expectedOutput1
  )

}
