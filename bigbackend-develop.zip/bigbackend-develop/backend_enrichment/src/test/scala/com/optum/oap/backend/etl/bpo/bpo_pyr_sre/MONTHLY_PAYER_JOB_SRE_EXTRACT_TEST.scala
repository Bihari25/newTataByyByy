package com.optum.oap.backend.etl.bpo.bpo_pyr_sre

import com.optum.oap.backend.BEQueryTestFramework
import com.optum.oap.backend.cdrTempModel.monthly_payer_job_sre_extract
import com.optum.oap.cdr.models.{mv_client_data_src, pp_bpo_member_detail, schema_init, zo_bpo_map_employer}
import com.optum.oap.sparkdataloader.EmptyRuntimeVariables
import org.apache.spark.sql.DataFrame

class MONTHLY_PAYER_JOB_SRE_EXTRACT_TEST extends BEQueryTestFramework {
  import spark.implicits._
  
  private val groupId = "H000000"

  private val originalSQL =
    """
      |select 'package.name' as key, 'Symmetry' as value
      |union all
      |select 'package.version' as key, '10.1.4' as value
      |union all
      |select 'sre.enable' as key, '1' as value
      |union all
      |select 'input.handler' as key, 'IBPOV22' as value
      |union all
      |select 'start.date' as key, (select date_format((to_date(date_add(add_months(add_months(last_day(from_unixtime(unix_timestamp(value,'yyyyMM'))),-2),-48),1))), "yyyy/MM/dd") as value from schema_init where attribute='release_cycle')
      |union all
      |select 'end.date' as key, (WITH mths AS
      |                  (select
      |  date_format(add_months(enddate, 0-rownum), 'yyyyMM') as month_yr,
      |  date_format(last_day(add_months(enddate, 0-rownum)), 'yyyy-MM-dd') as month_end
      |from (
      |    select row_number() over (order by groupid) as rownum, max(enddate) over (order by groupid) as enddate from pp_bpo_member_detail limit 100
      |    ))
      |    SELECT date_format(month_end, 'yyyy/MM/dd')
      |from ( SELECT  z.*
      |       ,row_number() over (partition by groupid order by good_payer_cnt desc, month_end desc) as best_row
      |FROM(
      |SELECT groupId,
      |        month_end,
      |        SUM(num_patients) as patients,
      |        COUNT(payer_nm) as num_payers,
      |        sum(case when w.change_percent > 0.05 then 1 else 0 end) as good_payer_cnt,
      |        row_number() over (partition by groupid order by month_end desc) as rownbr
      |        FROM
      |            (
      |                select x.*
      |       ,nvl2(last_month_pats,round(num_patients / last_month_pats,2),1) as change_percent
      |from (
      |select v.*
      |       ,lag(num_patients) over (partition by groupid,payer_nm order by month_end) as last_month_pats
      |FROM (
      |SELECT mem.groupId,
      |    month_end,
      |    COUNT(*) AS num_patients,
      |    mem.EMPLOYERACCOUNTID AS payer_nm
      |    FROM pp_bpo_member_detail  mem
      |    inner join zo_bpo_map_employer b on (mem.groupid = b.groupid AND mem.employeraccountid = b.employeraccountid)
      |    inner join mv_client_data_src c on (b.groupid = c.client_id AND b.client_ds_id = c.client_data_src_id)
      |    INNER JOIN mths   ON ( mths.month_yr BETWEEN date_format(effectivedate,'yyyyMM') AND date_format(enddate,'yyyyMM'))
      |    WHERE mem.healthplansource = 'PAYER'
      |    and nvl(status_cd,'NULL') not in ('OBS','HIST')
      |    GROUP BY mem.groupId,
      |            month_end,
      |            mem.EMPLOYERACCOUNTID
      |) v
      |) x
      |) w
      |                    GROUP BY groupId,
      |                    month_end) z
      |                    WHERE rownbr <= 10 ) where best_row = 1)
      |union all
      |select 'merge.output' as key, '1' as value
      |union all
      |select 'claim.size.max.limit' as key, '40000' as value
    """.stripMargin

  private val schemaInit05: DataFrame = mkDataFrame(
    schema_init(attribute="release_cycle", value = "202005")
  )

  private val schemaInit12: DataFrame = mkDataFrame(
    schema_init(attribute="release_cycle", value = "202012")
  )

  private val schemaInit01: DataFrame = mkDataFrame(
    schema_init(attribute="release_cycle", value = "202001")
  )

  private val schemaInitLeapYear: DataFrame = mkDataFrame(
    schema_init(attribute="release_cycle", value = "202002")
  )

  private val schemaInitNonLeapYear: DataFrame = mkDataFrame(
    schema_init(attribute="release_cycle", value = "201902")
  )

  private val schemaInitMissingReleaseCycle: DataFrame = mkDataFrame(
    schema_init(attribute="not_release_cycle", value = "202001")
  )

  private val ppBpoMemberDetailMakeMinimum100Rows = (1 to 94).toList.map(value =>
    pp_bpo_member_detail(groupid = groupId, memberid = s"DUMMY_$value", healthplansource = s"DUMMY_$value", effectivedate = java.sql.Timestamp.valueOf("2011-06-18 00:00:00"), enddate = java.sql.Timestamp.valueOf("2012-07-11 00:00:00"), employeraccountid = s"DUMMY_$value")
  )

  private val ppBpoMemberDetail: DataFrame = mkDataFrame(
    Seq(
      pp_bpo_member_detail(groupid = groupId, memberid = "m1", healthplansource = "PAYER", effectivedate = java.sql.Timestamp.valueOf("2011-06-18 00:00:00"), enddate = java.sql.Timestamp.valueOf("2019-07-11 00:00:00"), employeraccountid = "eai1"),
      pp_bpo_member_detail(groupid = groupId, memberid = "m2", healthplansource = "PAYER", effectivedate = java.sql.Timestamp.valueOf("2011-06-18 00:00:00"), enddate = java.sql.Timestamp.valueOf("2019-07-11 00:00:00"), employeraccountid = "eai2"),
      pp_bpo_member_detail(groupid = groupId, memberid = "m3", healthplansource = "PAYER", effectivedate = java.sql.Timestamp.valueOf("2011-06-18 00:00:00"), enddate = java.sql.Timestamp.valueOf("2019-07-11 00:00:00"), employeraccountid = "eai3"),
      pp_bpo_member_detail(groupid = groupId, memberid = "m4", healthplansource = "PAYER", effectivedate = java.sql.Timestamp.valueOf("2011-06-18 00:00:00"), enddate = java.sql.Timestamp.valueOf("2019-07-11 00:00:00"), employeraccountid = "eai4"),
      pp_bpo_member_detail(groupid = groupId, memberid = "m5", healthplansource = "PAYER", effectivedate = java.sql.Timestamp.valueOf("2011-06-18 00:00:00"), enddate = java.sql.Timestamp.valueOf("2019-07-11 00:00:00"), employeraccountid = "eai5"),
      pp_bpo_member_detail(groupid = groupId, memberid = "m6", healthplansource = "NONPAYER", effectivedate = java.sql.Timestamp.valueOf("2011-06-18 00:00:00"), enddate = java.sql.Timestamp.valueOf("2019-07-11 00:00:00"), employeraccountid = "eai6")
    ) ++ ppBpoMemberDetailMakeMinimum100Rows: _*
  )

  private val ppBpoMemberDetail20190831Outcome: DataFrame = mkDataFrame(
    Seq(
      pp_bpo_member_detail(groupid = groupId, memberid = "m1", healthplansource = "PAYER", effectivedate = java.sql.Timestamp.valueOf("2019-01-18 00:00:00"), enddate = java.sql.Timestamp.valueOf("2019-07-11 00:00:00"), employeraccountid = "eai1"),
      pp_bpo_member_detail(groupid = groupId, memberid = "m2", healthplansource = "PAYER", effectivedate = java.sql.Timestamp.valueOf("2019-08-01 00:00:00"), enddate = java.sql.Timestamp.valueOf("2019-09-30 00:00:00"), employeraccountid = "eai1"),
      pp_bpo_member_detail(groupid = groupId, memberid = "m3", healthplansource = "PAYER", effectivedate = java.sql.Timestamp.valueOf("2019-06-01 00:00:00"), enddate = java.sql.Timestamp.valueOf("2019-07-31 00:00:00"), employeraccountid = "eai2"),
      pp_bpo_member_detail(groupid = groupId, memberid = "m4", healthplansource = "PAYER", effectivedate = java.sql.Timestamp.valueOf("2019-04-01 00:00:00"), enddate = java.sql.Timestamp.valueOf("2019-08-31 00:00:00"), employeraccountid = "eai2"),
      pp_bpo_member_detail(groupid = groupId, memberid = "m5", healthplansource = "PAYER", effectivedate = java.sql.Timestamp.valueOf("2019-06-18 00:00:00"), enddate = java.sql.Timestamp.valueOf("2019-09-30 00:00:00"), employeraccountid = "eai3"),
      pp_bpo_member_detail(groupid = groupId, memberid = "m6", healthplansource = "NONPAYER", effectivedate = java.sql.Timestamp.valueOf("2019-06-18 00:00:00"), enddate = java.sql.Timestamp.valueOf("2019-11-30 00:00:00"), employeraccountid = "eai4")
    ) ++ ppBpoMemberDetailMakeMinimum100Rows: _*
  )

  private val ppBpoMemberDetail20200229Outcome: DataFrame = mkDataFrame(
    Seq(
      pp_bpo_member_detail(groupid = groupId, memberid = "m1", healthplansource = "PAYER", effectivedate = java.sql.Timestamp.valueOf("2019-02-01 00:00:00"), enddate = java.sql.Timestamp.valueOf("2020-02-29 00:00:00"), employeraccountid = "eai1"),
      pp_bpo_member_detail(groupid = groupId, memberid = "m2", healthplansource = "PAYER", effectivedate = java.sql.Timestamp.valueOf("2019-08-01 00:00:00"), enddate = java.sql.Timestamp.valueOf("2019-09-30 00:00:00"), employeraccountid = "eai1"),
      pp_bpo_member_detail(groupid = groupId, memberid = "m3", healthplansource = "PAYER", effectivedate = java.sql.Timestamp.valueOf("2019-06-01 00:00:00"), enddate = java.sql.Timestamp.valueOf("2020-04-30 00:00:00"), employeraccountid = "eai2"),
      pp_bpo_member_detail(groupid = groupId, memberid = "m4", healthplansource = "PAYER", effectivedate = java.sql.Timestamp.valueOf("2019-04-01 00:00:00"), enddate = java.sql.Timestamp.valueOf("2019-08-31 00:00:00"), employeraccountid = "eai2"),
      pp_bpo_member_detail(groupid = groupId, memberid = "m5", healthplansource = "PAYER", effectivedate = java.sql.Timestamp.valueOf("2019-06-18 00:00:00"), enddate = java.sql.Timestamp.valueOf("2019-03-31 00:00:00"), employeraccountid = "eai3"),
      pp_bpo_member_detail(groupid = groupId, memberid = "m6", healthplansource = "NONPAYER", effectivedate = java.sql.Timestamp.valueOf("2019-06-18 00:00:00"), enddate = java.sql.Timestamp.valueOf("2019-11-30 00:00:00"), employeraccountid = "eai4")
    ) ++ ppBpoMemberDetailMakeMinimum100Rows: _*
  )

  private val ppBpoMemberDetail20190228Outcome: DataFrame = mkDataFrame(
    Seq(
      pp_bpo_member_detail(groupid = groupId, memberid = "m1", healthplansource = "PAYER", effectivedate = java.sql.Timestamp.valueOf("2018-03-01 00:00:00"), enddate = java.sql.Timestamp.valueOf("2019-02-28 00:00:00"), employeraccountid = "eai1"),
      pp_bpo_member_detail(groupid = groupId, memberid = "m2", healthplansource = "PAYER", effectivedate = java.sql.Timestamp.valueOf("2018-08-01 00:00:00"), enddate = java.sql.Timestamp.valueOf("2018-09-30 00:00:00"), employeraccountid = "eai1"),
      pp_bpo_member_detail(groupid = groupId, memberid = "m3", healthplansource = "PAYER", effectivedate = java.sql.Timestamp.valueOf("2018-06-01 00:00:00"), enddate = java.sql.Timestamp.valueOf("2019-04-30 00:00:00"), employeraccountid = "eai2"),
      pp_bpo_member_detail(groupid = groupId, memberid = "m4", healthplansource = "PAYER", effectivedate = java.sql.Timestamp.valueOf("2018-04-01 00:00:00"), enddate = java.sql.Timestamp.valueOf("2018-08-31 00:00:00"), employeraccountid = "eai2"),
      pp_bpo_member_detail(groupid = groupId, memberid = "m5", healthplansource = "PAYER", effectivedate = java.sql.Timestamp.valueOf("2018-06-18 00:00:00"), enddate = java.sql.Timestamp.valueOf("2019-03-31 00:00:00"), employeraccountid = "eai3"),
      pp_bpo_member_detail(groupid = groupId, memberid = "m6", healthplansource = "NONPAYER", effectivedate = java.sql.Timestamp.valueOf("2018-04-01 00:00:00"), enddate = java.sql.Timestamp.valueOf("2019-03-31 00:00:00"), employeraccountid = "eai4")
    ) ++ ppBpoMemberDetailMakeMinimum100Rows: _*
  )

  private val zoBpoMapEmployer: DataFrame = mkDataFrame(
    zo_bpo_map_employer(client_ds_id = 1, dts_version = 0, employeraccountid = "eai1", groupid = groupId, highemployeraccount = "hea1"),
    zo_bpo_map_employer(client_ds_id = 2, dts_version = 0, employeraccountid = "eai2", groupid = groupId, highemployeraccount = "hea2"),
    zo_bpo_map_employer(client_ds_id = 4, dts_version = 0, employeraccountid = "eai3", groupid = groupId, highemployeraccount = "hea3"),
    zo_bpo_map_employer(client_ds_id = 8, dts_version = 0, employeraccountid = "eai4", groupid = groupId, highemployeraccount = "hea4"),
    zo_bpo_map_employer(client_ds_id = 16, dts_version = 0, employeraccountid = "eai5", groupid = groupId, highemployeraccount = "hea5")
  )

  private val mvClientDataSrc: DataFrame = mkDataFrame(
    mv_client_data_src(alias_of_id = 0, client_data_src_id = 1, client_id = groupId, data_src_id = 0, included_data_types = 0, included_domains = 0, initial_release = "", is_shared = "", priority = 0, status_cd = "NOTOBS"),
    mv_client_data_src(alias_of_id = 0, client_data_src_id = 2, client_id = groupId, data_src_id = 0, included_data_types = 0, included_domains = 0, initial_release = "", is_shared = "", priority = 0, status_cd = "NOTHIST"),
    mv_client_data_src(alias_of_id = 0, client_data_src_id = 4, client_id = groupId, data_src_id = 0, included_data_types = 0, included_domains = 0, initial_release = "", is_shared = "", priority = 0, status_cd = "NOTHIST"),
    mv_client_data_src(alias_of_id = 0, client_data_src_id = 8, client_id = groupId, data_src_id = 0, included_data_types = 0, included_domains = 0, initial_release = "", is_shared = "", priority = 0, status_cd = "NOTHIST"),
    mv_client_data_src(alias_of_id = 0, client_data_src_id = 16, client_id = groupId, data_src_id = 0, included_data_types = 0, included_domains = 0, initial_release = "", is_shared = "", priority = 0, status_cd = "OBS")
  )

  private val staticExpectedOutput: Seq[monthly_payer_job_sre_extract] = Seq(
    monthly_payer_job_sre_extract(key = "package.name", "Symmetry"),
    monthly_payer_job_sre_extract(key = "package.version", "10.1.4"),
    monthly_payer_job_sre_extract(key = "sre.enable", "1"),
    monthly_payer_job_sre_extract(key = "input.handler", "IBPOV22"),
    monthly_payer_job_sre_extract(key = "merge.output", "1"),
    monthly_payer_job_sre_extract(key = "claim.size.max.limit", "40000")
  )

  private val expectedOutput05: Seq[monthly_payer_job_sre_extract] = Seq(
    monthly_payer_job_sre_extract(key = "start.date", "2016/04/01"),
    monthly_payer_job_sre_extract(key = "end.date", "2019/06/30")
  ) ++ staticExpectedOutput

  private val expectedOutput12: Seq[monthly_payer_job_sre_extract] = Seq(
    monthly_payer_job_sre_extract(key = "start.date", "2016/11/01"),
    monthly_payer_job_sre_extract(key = "end.date", "2019/06/30")
  ) ++ staticExpectedOutput

  private val expectedOutput01: Seq[monthly_payer_job_sre_extract] = Seq(
    monthly_payer_job_sre_extract(key = "start.date", "2015/12/01"),
    monthly_payer_job_sre_extract(key = "end.date", "2019/06/30")
  ) ++ staticExpectedOutput

  private val expectedOutputLeapYear: Seq[monthly_payer_job_sre_extract] = Seq(
    monthly_payer_job_sre_extract(key = "start.date", "2016/01/01"),
    monthly_payer_job_sre_extract(key = "end.date", "2019/06/30")
  ) ++ staticExpectedOutput

  private val expectedOutputNonLeapYear: Seq[monthly_payer_job_sre_extract] = Seq(
    monthly_payer_job_sre_extract(key = "start.date", "2015/01/01"),
    monthly_payer_job_sre_extract(key = "end.date", "2019/06/30")
  ) ++ staticExpectedOutput

  private val expectedOutput20190831Outcome: Seq[monthly_payer_job_sre_extract] = Seq(
    monthly_payer_job_sre_extract(key = "start.date", "2016/04/01"),
    monthly_payer_job_sre_extract(key = "end.date", "2019/08/31")
  ) ++ staticExpectedOutput

  private val expectedOutput20200229Outcome: Seq[monthly_payer_job_sre_extract] = Seq(
    monthly_payer_job_sre_extract(key = "start.date", "2016/04/01"),
    monthly_payer_job_sre_extract(key = "end.date", "2020/02/29")
  ) ++ staticExpectedOutput

  private val expectedOutput20190228Outcome: Seq[monthly_payer_job_sre_extract] = Seq(
    monthly_payer_job_sre_extract(key = "start.date", "2016/04/01"),
    monthly_payer_job_sre_extract(key = "end.date", "2019/02/28")
  ) ++ staticExpectedOutput

  testQuery(
    testName = "should return 2019/06/30 enddate given input",
    query = MONTHLY_PAYER_JOB_SRE_EXTRACT,
    inputs = Map(
      "PP_BPO_MEMBER_DETAIL" -> ppBpoMemberDetail20190831Outcome,
      "SCHEMA_INIT" -> schemaInit05,
      "ZO_BPO_MAP_EMPLOYER" -> zoBpoMapEmployer,
      "MV_CLIENT_DATA_SRC" -> mvClientDataSrc
    ),
    expectedOutput = expectedOutput20190831Outcome
  )

  testQuery(
    testName = "should return 2020/02/29 enddate given input",
    query = MONTHLY_PAYER_JOB_SRE_EXTRACT,
    inputs = Map(
      "PP_BPO_MEMBER_DETAIL" -> ppBpoMemberDetail20200229Outcome,
      "SCHEMA_INIT" -> schemaInit05,
      "ZO_BPO_MAP_EMPLOYER" -> zoBpoMapEmployer,
      "MV_CLIENT_DATA_SRC" -> mvClientDataSrc
    ),
    expectedOutput = expectedOutput20200229Outcome
  )

  testQuery(
    testName = "should return 2019/02/28 enddate given input",
    query = MONTHLY_PAYER_JOB_SRE_EXTRACT,
    inputs = Map(
      "PP_BPO_MEMBER_DETAIL" -> ppBpoMemberDetail20190228Outcome,
      "SCHEMA_INIT" -> schemaInit05,
      "ZO_BPO_MAP_EMPLOYER" -> zoBpoMapEmployer,
      "MV_CLIENT_DATA_SRC" -> mvClientDataSrc
    ),
    expectedOutput = expectedOutput20190228Outcome
  )

  testQuery(
    testName = "should return expected values given input with releaseCycle = 202005",
    query = MONTHLY_PAYER_JOB_SRE_EXTRACT,
    inputs = Map(
      "PP_BPO_MEMBER_DETAIL" -> ppBpoMemberDetail,
      "SCHEMA_INIT" -> schemaInit05,
      "ZO_BPO_MAP_EMPLOYER" -> zoBpoMapEmployer,
      "MV_CLIENT_DATA_SRC" -> mvClientDataSrc
    ),
    expectedOutput = expectedOutput05
  )

  testQuery(
    testName = "should return expected values given input with releaseCycle = 202012",
    query = MONTHLY_PAYER_JOB_SRE_EXTRACT,
    inputs = Map(
      "PP_BPO_MEMBER_DETAIL" -> ppBpoMemberDetail,
      "SCHEMA_INIT" -> schemaInit12,
      "ZO_BPO_MAP_EMPLOYER" -> zoBpoMapEmployer,
      "MV_CLIENT_DATA_SRC" -> mvClientDataSrc
    ),
    expectedOutput = expectedOutput12
  )

  testQuery(
    testName = "should return expected values given input with releaseCycle = 202001",
    query = MONTHLY_PAYER_JOB_SRE_EXTRACT,
    inputs = Map(
      "PP_BPO_MEMBER_DETAIL" -> ppBpoMemberDetail,
      "SCHEMA_INIT" -> schemaInit01,
      "ZO_BPO_MAP_EMPLOYER" -> zoBpoMapEmployer,
      "MV_CLIENT_DATA_SRC" -> mvClientDataSrc
    ),
    expectedOutput = expectedOutput01
  )

  testQuery(
    testName = "should return expected values given input with releaseCycle = 202002 (NON LEAP YEAR)",
    query = MONTHLY_PAYER_JOB_SRE_EXTRACT,
    inputs = Map(
      "PP_BPO_MEMBER_DETAIL" -> ppBpoMemberDetail,
      "SCHEMA_INIT" -> schemaInitNonLeapYear,
      "ZO_BPO_MAP_EMPLOYER" -> zoBpoMapEmployer,
      "MV_CLIENT_DATA_SRC" -> mvClientDataSrc
    ),
    expectedOutput = expectedOutputNonLeapYear
  )

  testQuery(
    testName = "should return expected values given input with releaseCycle = 201902 (LEAP YEAR)",
    query = MONTHLY_PAYER_JOB_SRE_EXTRACT,
    inputs = Map(
      "PP_BPO_MEMBER_DETAIL" -> ppBpoMemberDetail,
      "SCHEMA_INIT" -> schemaInitLeapYear,
      "ZO_BPO_MAP_EMPLOYER" -> zoBpoMapEmployer,
      "MV_CLIENT_DATA_SRC" -> mvClientDataSrc
    ),
    expectedOutput = expectedOutputLeapYear
  )

  it should "throw a meaningful exception when SCHEMA_INIT release_cycle attribute missing" in {
    val inputs = Map(
      "PP_BPO_MEMBER_DETAIL" -> ppBpoMemberDetail,
      "SCHEMA_INIT" -> schemaInitMissingReleaseCycle,
      "ZO_BPO_MAP_EMPLOYER" -> zoBpoMapEmployer,
      "MV_CLIENT_DATA_SRC" -> mvClientDataSrc
    )
    assertThrows[IllegalStateException] {
      MONTHLY_PAYER_JOB_SRE_EXTRACT.runTableETL(sparkSession, inputs, udfsMap, EmptyRuntimeVariables())
    }
  }

  it should "insert error message when end.date derivation returns 0 rows" in {
    val inputs = Map(
      "PP_BPO_MEMBER_DETAIL" -> Seq.empty[pp_bpo_member_detail].toDF,
      "SCHEMA_INIT" -> schemaInit01,
      "ZO_BPO_MAP_EMPLOYER" -> zoBpoMapEmployer,
      "MV_CLIENT_DATA_SRC" -> mvClientDataSrc
    )
    val output = MONTHLY_PAYER_JOB_SRE_EXTRACT.runTableETL(sparkSession, inputs, udfsMap, EmptyRuntimeVariables())
    assert(
      output.where($"key" === "end.date").first.getAs[String]("value").contains("ERROR"),
      "Error message expected in value when end.date is not derivable"
    )
  }

  it should "match outcomes with original Spark SQL etl" in {
    ppBpoMemberDetail .createOrReplaceTempView("pp_bpo_member_detail")
    schemaInit05.createOrReplaceTempView("schema_init")
    zoBpoMapEmployer.createOrReplaceTempView("zo_bpo_map_employer")
    mvClientDataSrc.createOrReplaceTempView("mv_client_data_src")

    val originalOutput = spark.sql(originalSQL)

    checkThatDataFramesAreEqual(originalOutput, expectedOutput05)
  }

  it should "calculate start.date properly given specific releaseCycle in deriveStartDateFromReleaseCycle" in {
    assert(MONTHLY_PAYER_JOB_SRE_EXTRACT.deriveStartDateFromReleaseCycle("200406") == "2000/05/01",
      "200406 release cycle should yield 2020/05/01"
    )
    assert(MONTHLY_PAYER_JOB_SRE_EXTRACT.deriveStartDateFromReleaseCycle("200001") == "1995/12/01",
      "200001 release cycle should yield 1995/12/01"
    )
    assert(MONTHLY_PAYER_JOB_SRE_EXTRACT.deriveStartDateFromReleaseCycle("202012") == "2016/11/01",
      "202012 release cycle should yield 2016/11/01"
    )
  }
}