package com.optum.oap.backend.etl.common

import java.sql.Timestamp

import com.optum.oap.sparkdataloader.UserDefinedFunctionForDataLoader
import org.apache.spark.sql.SparkSession
import org.apache.spark.sql.expressions.UserDefinedFunction
import org.apache.spark.sql.functions.udf

object TimestampAddDays extends UserDefinedFunctionForDataLoader {
	val timestampAddDays: UserDefinedFunction = udf {
		(ts: Timestamp, days: Long) => {
			if (ts == null) {
				null
			} else {
				val ldt = ts.toLocalDateTime

				Timestamp.valueOf(ldt.plusDays(days))
			}
		}
	}

	override def name: String = "TimestampAddDays"

	override def registerMe(sparkSession: SparkSession): Unit = {
		sparkSession.udf.register(name, timestampAddDays)
	}
}
