package com.optum.oap.backend.etl.bpo.bpo_pyr_sre

import com.optum.oap.backend.cdrTempModel.monthly_payer_phm_sre
import com.optum.oap.cdr.models.{pp_bpo_member_detail, pp_bpo_pharmacy_claims}
import com.optum.oap.sparkdataloader.{RuntimeVariables, TableInfo, UserDefinedFunctionForDataLoader}
import org.apache.spark.sql.functions.{date_format, lit}
import org.apache.spark.sql.types.StringType
import org.apache.spark.sql.{DataFrame, SparkSession}

/**
  *
  * Copyright 2020 Optum Analytics
  *
  * Date: 2/18/20
  *
  * Creator: pavula1
  */
object MONTHLY_PAYER_PHM_SRE_EXTRACT extends TableInfo[monthly_payer_phm_sre] {

  override def dependsOn = Set("PP_BPO_PHARMACY_CLAIMS", "PP_BPO_MEMBER_DETAIL")

  override def name = "MONTHLY_PAYER_PHM_SRE_EXTRACT"

  override def createDataFrame(sparkSession: SparkSession,
                               loadedDependencies: Map[String, DataFrame],
                               udfMap: Map[String, UserDefinedFunctionForDataLoader],
                               runtimeVariables: RuntimeVariables): DataFrame = {

    import sparkSession.implicits._

    val ppBpoMemberDetail = loadedDependencies("PP_BPO_MEMBER_DETAIL").as[pp_bpo_member_detail]
    val ppBpoPharmacyClaims = loadedDependencies("PP_BPO_PHARMACY_CLAIMS").as[pp_bpo_pharmacy_claims]

    val result_df = ppBpoPharmacyClaims.as("rx")
      .where($"healthplansource" === "PAYER")
      .join(ppBpoMemberDetail.as("elig"), Seq("groupid", "memberid", "healthplansource"), "inner")
      .where($"rx.servicedate".between($"elig.effectivedate", $"elig.enddate"))
      .select(
        $"rx.memberid".as("memberid"),
        date_format($"paymentdate", "yyyy-MM-dd").as("paymentdate"),
        date_format($"servicedate", "yyyy-MM-dd").as("servicedate"),
        $"pharmacyid".as("pharmacyid"),
        $"pharmacyname".as("pharmacyname"),
        $"pharmacytype".as("pharmacytype"),
        $"ndc".as("ndc"),
        $"genericstatus".as("genericstatus"),
        $"dayssupply".as("dayssupply").cast(StringType),
        $"quantity".as("quantity").cast(StringType),
        $"formulary".as("formulary"),
        $"allowedamount".as("allowedamount").cast(StringType),
        $"requestedamount".as("requestedamount").cast(StringType),
        $"paidamount".as("paidamount").cast(StringType),
        $"copayamount".as("copayamount").cast(StringType),
        $"coinsamount".as("coinsamount").cast(StringType),
        $"deductamount".as("deductamount").cast(StringType),
        $"patliabamount".as("patliabamount").cast(StringType),
        $"ingredientcost".as("ingredientcost").cast(StringType),
        $"dispensingfee".as("dispensingfee").cast(StringType),
        $"rx.healthplansource".as("healthplansource"),
        $"rx.coverageclasscode".as("coverageclasscode"),
        lit("N").as("deniedflag"),
        $"deniedreason".as("deniedreason"),
        $"pseudoflag".as("pseudoflag"),
        $"networkstatus".as("networkstatus"),
        $"claimsource".as("claimsource"),
        $"claimheader".as("claimheader"),
        $"prescprovider".as("prescprovider"),
        $"dea".as("dea"),
        $"rx.mapsource".as("mapsource").cast(StringType),
        $"quantity_dispensed".as("quantity_dispensed").cast(StringType),
        $"supply_flag".as("supply_flag"),
        lit(null).cast(StringType).as("unique_rec_id"),
        lit(null).cast(StringType).as("code_type"),
        lit(null).cast(StringType).as("diagnosis_code"),
        lit(null).cast(StringType).as("pos"),
        lit(null).cast(StringType).as("prov_type_code"),
        lit(null).cast(StringType).as("prov_specialty_code"),
        lit(null).cast(StringType).as("prov_npi"),
        lit(null).cast(StringType).as("pharmacy_npi")
      )

    result_df.as[monthly_payer_phm_sre].toDF()
  }

}
