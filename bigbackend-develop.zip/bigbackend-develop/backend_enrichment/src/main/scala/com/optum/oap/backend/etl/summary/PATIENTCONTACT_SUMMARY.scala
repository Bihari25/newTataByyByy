package com.optum.oap.backend.etl.summary

import com.optum.oap.cdr.models.patientcontact_summary
import com.optum.oap.sparkdataloader.{RuntimeVariables, TableInfo, UserDefinedFunctionForDataLoader}
import org.apache.spark.sql.expressions.Window
import org.apache.spark.sql.functions._
import org.apache.spark.sql.types.IntegerType
import org.apache.spark.sql.{DataFrame, SparkSession}
import org.slf4j.LoggerFactory

object PATIENTCONTACT_SUMMARY extends TableInfo[patientcontact_summary] {
      val log = LoggerFactory.getLogger(this.getClass)
  override def dependsOn =  Set("PATIENTCONTACT","MAP_CONTACT_SRC")

  override def name = "PATIENTCONTACT_SUMMARY"

  override def saveDataFrameToParquet: Boolean = true
  override def partitions: Int = 64
  override def skipTable: Boolean = false
  override def ignoreExtraColumnsInDataFrame: Boolean = false

  override def createDataFrame (sparkSession: SparkSession,
                                loadedDependencies: Map[String, DataFrame],
                                udfMap: Map[String, UserDefinedFunctionForDataLoader],
                                runtimeVariables: RuntimeVariables): DataFrame = {

    val patcontactFirstDF = loadedDependencies("PATIENTCONTACT")
    val contact_srcFirstDF =loadedDependencies("MAP_CONTACT_SRC")



  //script equivalent to oracle starts from here
  val patcontact = patcontactFirstDF.filter("grp_mpi is not null")
  val joindf = patcontact
    .join(broadcast(contact_srcFirstDF), Seq("groupid", "client_ds_id"), "inner")

  val group1 =

    Window.partitionBy(joindf("GRP_MPI"))
      .orderBy(
        when(joindf("HOME_PHONE").isNotNull,
          lit("0"))
          .otherwise(lit("1"))
        , joindf("PRIORITY_ORDER"), joindf("UPDATE_DT").desc
      )

  val df1 = joindf.withColumn("DATERANKHOME", rank().over(group1))

  val group2 =

    Window.partitionBy(df1("GRP_MPI"))
      .orderBy(
        when(df1("WORK_PHONE").isNotNull,
          lit("0"))
          .otherwise(lit("1"))
        , df1("PRIORITY_ORDER"), df1("UPDATE_DT").desc
      )

  val df2 = df1.withColumn("DATERANKWORK", rank().over(group2))


  val group3 =

    Window.partitionBy(df2("GRP_MPI"))
      .orderBy(
        when(df2("CELL_PHONE").isNotNull,
          lit("0"))
          .otherwise(lit("1"))
        , df2("PRIORITY_ORDER"), df2("UPDATE_DT").desc
      )

  val dfv = df2.withColumn("DATERANKCELL", rank().over(group3))


  val group4 = Window.partitionBy(dfv("GRP_MPI"))
    .orderBy(
      dfv("PRIORITY_ORDER"), dfv("CLIENT_DS_ID")
    )

  val dfv2 = dfv.withColumn("CLIENT_DS_ID", first("CLIENT_DS_ID").over(group4))

  val group5 = Window.partitionBy(dfv2("GRP_MPI"))
    .orderBy(
      dfv2("DATERANKHOME"), dfv2("CLIENT_DS_ID"), dfv2("DATASRC"), dfv2("HOME_PHONE").desc_nulls_last
    )

  val dfv3 = dfv2.withColumn("BEST_HOME", first("HOME_PHONE").over(group5))


  val groupbw = Window.partitionBy(dfv3("GRP_MPI"))
    .orderBy(
      dfv3("DATERANKWORK"), dfv3("CLIENT_DS_ID"), dfv3("DATASRC"), dfv3("WORK_PHONE").desc_nulls_last
    )
  val dfvbw = dfv3.withColumn("BEST_WORK", first("WORK_PHONE").over(groupbw))


  val groupbc = Window.partitionBy(dfvbw("GRP_MPI"))
    .orderBy(
      dfvbw("DATERANKCELL"), dfvbw("CLIENT_DS_ID"), dfvbw("DATASRC"), dfvbw("CELL_PHONE").desc_nulls_last
    )
  val dfvbc = dfvbw.withColumn("BEST_CELL", first("CELL_PHONE").over(groupbc))


  val dfCNTS = dfvbc.
    withColumn("HOMEPHONE_CT",
      when(dfvbc("DATERANKHOME") === 1, dfvbc("HOME_PHONE"))
        .otherwise(null))
    .withColumn("WORKPHONE_CT",
      when(dfvbc("DATERANKWORK") === 1, dfvbc("WORK_PHONE"))
        .otherwise(null))
    .withColumn("CELLPHONE_CT",
      when(dfvbc("DATERANKCELL") === 1, dfvbc("CELL_PHONE"))
        .otherwise(null))
    .groupBy("grp_mpi")

  val cnts1 = dfCNTS.agg(
    countDistinct("HOMEPHONE_CT").as("HOME_CNT")
    , countDistinct("WORKPHONE_CT").as("WORK_CNT")
    , countDistinct("CELLPHONE_CT").as("CELL_CNT"))

  val dfv4 = dfvbc.join(cnts1, Seq("grp_mpi"), "inner")


  val group6 = Window.partitionBy(dfv4("GRP_MPI"))
    .orderBy(
      when(dfv4("WORK_EMAIL").isNotNull, lit("0")).otherwise(lit("1")),
      dfv4("PRIORITY_ORDER"), dfv4("UPDATE_DT").desc, dfv4("CLIENT_DS_ID"), dfv4("DATASRC"), dfv4("WORK_EMAIL").desc_nulls_last
    )

  val dfv5 = dfv4.withColumn("BEST_WORK_EMAIL", first("WORK_EMAIL").over(group6))


  val group7 = Window.partitionBy(dfv5("GRP_MPI"))
    .orderBy(
      when(dfv5("PERSONAL_EMAIL").isNotNull, lit("0")).otherwise(lit("1")),
      dfv5("PRIORITY_ORDER"), dfv5("UPDATE_DT").desc, dfv5("CLIENT_DS_ID"), dfv5("DATASRC"), dfv5("PERSONAL_EMAIL").desc_nulls_last
    )

  val dfv6 = dfv5.withColumn("BEST_PERS_EMAIL", first("PERSONAL_EMAIL").over(group7))
    .withColumn("MULTIPLE_VALUES", greatest("HOME_CNT", "WORK_CNT", "CELL_CNT"))


  val groupall = dfv6.groupBy("GROUPID", "CLIENT_DS_ID", "GRP_MPI", "BEST_HOME",
    "BEST_WORK", "BEST_CELL", "BEST_WORK_EMAIL", "BEST_PERS_EMAIL")


  val dfgroupall = groupall.agg(max("MULTIPLE_VALUES").cast(IntegerType).as("MULTIPLE_VALUES"), max("UPDATE_DT").as("RECORD_DATE"))

  dfgroupall.withColumnRenamed("BEST_HOME", "home_phone")
    .withColumnRenamed("BEST_WORK", "work_phone")
    .withColumnRenamed("BEST_CELL", "cell_phone")
    .withColumnRenamed("BEST_WORK_EMAIL", "work_email")
    .withColumnRenamed("BEST_PERS_EMAIL", "personal_email")

  }
}
