package com.optum.oap.backend.etl.metrics

import com.optum.oap.backend.cdrTempModel.etl_concurrent_runs
import com.optum.oap.sparkdataloader.TableInfo
import org.apache.spark.sql.{SaveMode, SparkSession}
import com.optum.oap.backend.loader.EnrichmentRunTimeVariables
import org.apache.spark.sql.functions._
import com.optum.oap.sparkdataloader.{RuntimeVariables, TableInfo, UserDefinedFunctionForDataLoader}
import org.apache.spark.sql.types.LongType
import org.apache.spark.sql.{DataFrame, SaveMode, SparkSession}

object ETL_CONCURRENT_RUNS extends TableInfo[etl_concurrent_runs]{

  override def dependsOn = Set.empty[String]

  override def name = "ETL_CONCURRENT_RUNS"

  override def saveMode: SaveMode = SaveMode.Append

  override def createDataFrame(sparkSession: SparkSession, loadedDependencies: Map[String, DataFrame], udfMap: Map[String, UserDefinedFunctionForDataLoader], runtimeVariables: RuntimeVariables): DataFrame = {
    import sparkSession.implicits._

    val buildMetrics = runtimeVariables.asInstanceOf[EnrichmentRunTimeVariables].buildMetrics

    buildMetrics match {
      case Some(metrics) => {

        val log: Seq[String] = metrics.split("\\n")
        val buildType: String = runtimeVariables.asInstanceOf[EnrichmentRunTimeVariables].buildType
        val cdrCycle: String = runtimeVariables.asInstanceOf[EnrichmentRunTimeVariables].cdrCycle
        val enrichmentStep : String = runtimeVariables.asInstanceOf[EnrichmentRunTimeVariables].loadGroups

        val runningPattern = ".*there were (\\d*) running tables.*".r

        val result = log.filter(line => runningPattern.findAllIn(line).nonEmpty).map(line => {
          val runningTables = runningPattern.findFirstMatchIn(line).get.group(1)

          val tablesList = line.substring(line.lastIndexOf(':') + 2)
          etl_concurrent_runs(build_type = buildType, cdr_cycle = cdrCycle, enrichment_step = enrichmentStep,num_of_table_running = runningTables.toInt, list_of_tables = tablesList )
        })

        result.toDF()
      }
      case _ => Seq.empty[etl_concurrent_runs].toDF
    }
  }
}
