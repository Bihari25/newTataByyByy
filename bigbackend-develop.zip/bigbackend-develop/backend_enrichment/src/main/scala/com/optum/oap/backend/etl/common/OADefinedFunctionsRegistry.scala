package com.optum.oap.backend.etl.common

import com.optum.oap.backend.etl.common.OADefinedFunctionsRegistry.EXTRACT_RESULT_TYPE
import com.optum.oap.sparkdataloader.UserDefinedFunctionForDataLoader
import org.apache.spark.sql.SparkSession

object OADefinedFunctionsRegistry {

  val TIMESTAMP_TRUNCATE = TimestampTruncate

  val TIMESTAMP_ADD_DAYS = TimestampAddDays

  val IS_SAFE_TO_NUMBER = IsSafeToNumber

  val NORMALIZE_NDC = NormalizeNDC

  val SAFE_TO_DATE = SafeToDate

  val SAFE_TO_DATE_LENGTH = SafeToDateLength

  val EXTRACT_RELATIVE_INDICATOR = ExtractRelativeindicator

  val EXTRACT_RESULT_TYPE = ExtractResulttype

  val EXTRACT_UOM = ExtractUom

  val EXTRACT_UOM_RAW = ExtractUomRaw

  val EXTRACT_VALUE = ExtractValue

  val CALENDAR: CalendarUDF.type = CalendarUDF

  val CLEAN_PUNT = CleanPunct

  val CLEAN_NAME = CleanName

  val ALL_UDFS: Set[UserDefinedFunctionForDataLoader] = Set(TIMESTAMP_TRUNCATE, TIMESTAMP_ADD_DAYS, IS_SAFE_TO_NUMBER, NORMALIZE_NDC, CALENDAR, CLEAN_PUNT, CLEAN_NAME,
    IS_SAFE_TO_NUMBER, NORMALIZE_NDC, CALENDAR, SAFE_TO_DATE, SAFE_TO_DATE_LENGTH, EXTRACT_RELATIVE_INDICATOR,
    EXTRACT_RESULT_TYPE, EXTRACT_UOM, EXTRACT_UOM_RAW, EXTRACT_VALUE)


  def getUdfsMap(sparkSession: SparkSession): Map[String, UserDefinedFunctionForDataLoader] = {
    OADefinedFunctionsRegistry.ALL_UDFS.map(oa => {
      oa.registerMe(sparkSession)
      oa.name -> oa
    }).toMap
  }
}
