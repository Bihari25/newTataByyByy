package com.optum.oap.backend.etl.bpo

import com.optum.oap.backend.cdrTempModel.temp_bpo_calculate_params
import com.optum.oap.backend.etl.common.CDRConstants
import com.optum.oap.cdr.models.{map_predicate_values, schema_init}
import com.optum.oap.sparkdataloader.{RuntimeVariables, TableInfo, UserDefinedFunctionForDataLoader}
import org.apache.spark.sql.functions._
import org.apache.spark.sql.{DataFrame, SparkSession}

/**
  *
  * Copyright 2019 Optum Analytics
  *
  * Date: 5/17/19
  *
  * Creator: pavula1
  */
object TEMP_BPO_CALCULATE_PARAMS extends TableInfo[temp_bpo_calculate_params] {
  override def dependsOn = Set("SCHEMA_INIT", "MAP_PREDICATE_VALUES")

  override def name = "TEMP_BPO_CALCULATE_PARAMS"

  override def createDataFrame(sparkSession: SparkSession,
                               loadedDependencies: Map[String, DataFrame],
                               udfMap: Map[String, UserDefinedFunctionForDataLoader],
                               runtimeVariables: RuntimeVariables): DataFrame = {

    import sparkSession.implicits._

    val schemaInit = broadcast(loadedDependencies("SCHEMA_INIT")).as[schema_init]

    val mapPredicateValues = broadcast(loadedDependencies("MAP_PREDICATE_VALUES")).as[map_predicate_values]

    val extract_end_date = schemaInit.where($"attribute" === "release_cycle")
      .select(
        date_sub(add_months(to_date($"value", "yyyyMM"), -1), 1).alias("extract_end_date"),
        add_months(to_date($"value", "yyyyMM"), -1).alias("extract_end_date1")
      )

    val mapPredicate = mapPredicateValues
      .where(upper($"data_Src") === "BPO_START_DATE" && upper($"entity") === "BPO_TABLES" && upper($"column_name") === "EFFECTIVEDATE")
      .select(upper($"COLUMN_VALUE").alias("COLUMN_VALUE")).distinct()

    val result = mapPredicate.select($"COLUMN_VALUE").collect().map(_(0)).toList.contains("YES")

    extract_end_date.select(
      when(lit(result), to_date(lit("19000101"), CDRConstants.DATE_FORMAT_4Y2M2D))
        .otherwise(add_months($"extract_end_date1", -48))
        .alias("engineStartDate"),
      add_months($"extract_end_date1", -48).alias("engineStartDate2"),
      when(lit(result), add_months($"extract_end_date1", -66))
        .otherwise(add_months($"extract_end_date1", -48))
        .alias("engineStartDate3"),
      $"extract_end_date".alias("engineEndDate"),
      to_date(concat(year(add_months($"extract_end_date1", -48)), lit("0101")), CDRConstants.DATE_FORMAT_4Y2M2D).alias("startDate")
    )

  }

}
