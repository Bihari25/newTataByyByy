package com.optum.oap.backend.etl.common

object UnitConversionFunction extends Enumeration {
  type UnitConversionFunction = Value
  val LINEAR, LOG10, LOG2, TEMPTOC, TEMP_60_LOGIC = Value
}