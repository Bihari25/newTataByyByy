package com.optum.oap.backend.loader

object GitHubBpoConfigReader {
  def apply(): BpoConfigReader = new GitHubBpoConfigReader()

  private class GitHubBpoConfigReader() extends BpoConfigReader {

    override def constructLines(clientId: String, release: String, cdrCycle: String, isOverride: Boolean): Set[String] = {

      val release_url = s"https://github.optum.com/raw/OptumAnalyticsPlatform/oap-configs/master/CDRBE/BPO/$release/cdr_be_bpo_extract_config.csv"
      val override_config_url = s"https://github.optum.com/raw/OptumAnalyticsPlatform/oap-configs/master/CDRBE/BPO/override_cdr_be_bpo_extract_config.csv"
      val config_url = if (isOverride) override_config_url else release_url
      val source = scala.io.Source.fromURL(config_url)
      try {
        source.getLines()
          .toSeq
          .filter(line =>
            line.startsWith(clientId) && ((isOverride && line.endsWith(cdrCycle)) || !isOverride)
          ).toSet
      } finally {
        if (source != null) source.close()
      }
    }
  }

}

