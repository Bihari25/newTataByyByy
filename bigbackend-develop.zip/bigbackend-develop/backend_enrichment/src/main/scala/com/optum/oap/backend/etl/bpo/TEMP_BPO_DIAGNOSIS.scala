package com.optum.oap.backend.etl.bpo

import java.sql.Timestamp

import com.optum.oap.backend.cdrTempModel.{temp_bpo_calculate_params, temp_bpo_diagnosis, temp_bpo_patients}
import com.optum.oap.backend.etl.bpo.BpoUtil.getBpoInputParameters
import com.optum.oap.backend.etl.common.CDRConstants
import com.optum.oap.cdr.models._
import com.optum.oap.sparkdataloader.{RuntimeVariables, TableInfo, UserDefinedFunctionForDataLoader}
import org.apache.spark.sql.expressions.Window
import org.apache.spark.sql.functions.{lit, when, _}
import org.apache.spark.sql.types.{StringType, TimestampType}
import org.apache.spark.sql.{DataFrame, SparkSession}
import org.joda.time.DateTime

/**
  *
  * Copyright 2019 Optum Analytics
  *
  * Date: 5/31/19
  *
  * Creator: bpokharel(bishu)
  */
object TEMP_BPO_DIAGNOSIS extends TableInfo[temp_bpo_diagnosis] {

  override def dependsOn = Set(
    "DIAGNOSIS",
    "TEMP_BPO_PATIENTS",
    "CLINICALENCOUNTER",
    "MAP_POA",
    "ZO_POA",
    "MAP_PREDICATE_VALUES",
    "TEMP_BPO_CALCULATE_PARAMS"
  )

  override def name = "TEMP_BPO_DIAGNOSIS"

  override def createDataFrame(sparkSession: SparkSession,
                               loadedDependencies: Map[String, DataFrame],
                               udfMap: Map[String, UserDefinedFunctionForDataLoader],
                               runtimeVariables: RuntimeVariables): DataFrame = {
    import sparkSession.implicits._

    val diagnosis_DS = loadedDependencies("DIAGNOSIS").as[diagnosis]
    val temp_bpo_patients_DS = loadedDependencies("TEMP_BPO_PATIENTS").as[temp_bpo_patients]
    val clinicalencounter_DS = loadedDependencies("CLINICALENCOUNTER").as[clinicalencounter]
    val map_poa_DS = broadcast(loadedDependencies("MAP_POA")).as[map_poa]
    val zo_poa_DS = broadcast(loadedDependencies("ZO_POA")).as[zo_poa]
    val map_predicate_values_DS = broadcast(loadedDependencies("MAP_PREDICATE_VALUES")).as[map_predicate_values]
    val temp_bpo_calculate_params_DS = broadcast(loadedDependencies("TEMP_BPO_CALCULATE_PARAMS")).as[temp_bpo_calculate_params]

    val bpoInputParameters = getBpoInputParameters(sparkSession, temp_bpo_calculate_params_DS)
    val extractStartDate = bpoInputParameters.engineStartDate

    val patDf = temp_bpo_patients_DS
      .select(
        $"groupid",
        $"grp_mpi"
      ).distinct()

    val joinedDf = diagnosis_DS.as("a")
      .join(patDf.as("pat"),
        ($"a.groupid" === $"pat.groupid")
          && ($"a.grp_mpi" === $"pat.grp_mpi")
      )
      .join(clinicalencounter_DS.as("ce"),
        ($"ce.groupid" === $"a.groupid")
          && ($"ce.encounterid" === $"a.encounterid")
          && ($"ce.client_ds_id" === $"a.client_ds_id")
          && ($"ce.grp_mpi" === $"a.grp_mpi")
      )
      .join(map_poa_DS.as("mp"),
        ($"a.groupid" === $"mp.groupid")
          && ($"a.localpresentonadmission" === $"mp.localcode"),
        "left_outer"
      )
      .join(zo_poa_DS.as("zopoa"),
        $"mp.cui" === $"zopoa.hts_cui",
        "left_outer"
      )
      .join(map_predicate_values_DS.as("m"),
        ($"m.groupid" === $"a.groupid")
          && ($"m.client_ds_id" === $"a.client_ds_id")
          && ($"m.entity" === lit("PP_BPO_MEDICAL_CLAIMS"))
          && ($"m.column_name" === lit("PX_DX"))
          && ($"m.data_src" === lit("OADW"))
        , "left_outer"
      )
      .where(to_date($"a.dx_timestamp").geq(extractStartDate))
      .where(coalesce($"a.codetype", lit("ICD9")).isin(lit("ICD9"), lit("ICD10")))
      .where($"a.mappeddiagnosis".isNotNull)
      .where($"a.grp_mpi".isNotNull)
      .withColumn("sourceid",
        when(
          $"m.client_ds_id".isNull, lit("NA"))
          .otherwise($"a.sourceid")
      )
      .withColumn("codetype", coalesce($"a.codetype", lit("ICD9")))
      .groupBy(
        $"a.groupid",
        $"a.encounterid",
        $"a.client_ds_id",
        $"a.grp_mpi",
        $"a.mappeddiagnosis",
        $"codetype",
        $"sourceid"
      )
      .agg(
        when(max($"a.primarydiagnosis") === lit(1), lit(1)).otherwise(lit(2)).as("prindx"),
        when(max($"a.hosp_dx_flag") === lit("Y"), lit(1)).otherwise(lit(2)).as("hosp_dx_flag"),
        max($"zopoa.ii_code").as("poa"),
        max(to_date(coalesce($"ce.dischargetime", $"ce.arrivaltime"))).as("encounter_date"),
        min(coalesce($"a.seq", lit(99))).as("seq")
      )
      .select(
        $"a.groupid",
        $"a.encounterid",
        $"a.client_ds_id",
        $"a.grp_mpi",
        $"a.mappeddiagnosis",
        $"codetype",
        $"prindx",
        $"hosp_dx_flag",
        $"poa",
        $"encounter_date",
        $"sourceid",
        $"seq"
      )

    val joinedDf1 = joinedDf.as("p")
      .withColumn("dxseq",
        row_number().over(
          Window.partitionBy($"p.groupid", $"p.encounterid", $"p.client_ds_id", $"p.grp_mpi", $"p.codetype", $"p.sourceid")
            .orderBy($"p.prindx", $"p.seq", $"p.hosp_dx_flag", $"p.mappeddiagnosis")
        )
      )
      .withColumn("cdtype_cnt",
        size(collect_set("p.codetype").over(
          Window.partitionBy($"p.groupid", $"p.encounterid", $"p.client_ds_id", $"p.grp_mpi", $"p.sourceid"))
        )
      )

    val joinedDf2 = joinedDf1
      .where($"dxseq".leq(lit(25)))
      .groupBy(
        $"groupid",
        $"encounterid",
        $"client_ds_id",
        $"grp_mpi",
        $"codetype",
        $"encounter_date",
        $"sourceid"
      )
      .agg(
        max(when($"dxseq" === lit(1) && length($"mappeddiagnosis").leq(lit(8)), $"mappeddiagnosis").otherwise(lit(null).cast(StringType))).as("icddiag1"),
        max(when($"dxseq" === lit(2) && length($"mappeddiagnosis").leq(lit(8)), $"mappeddiagnosis").otherwise(lit(null).cast(StringType))).as("icddiag2"),
        max(when($"dxseq" === lit(3) && length($"mappeddiagnosis").leq(lit(8)), $"mappeddiagnosis").otherwise(lit(null).cast(StringType))).as("icddiag3"),
        max(when($"dxseq" === lit(4) && length($"mappeddiagnosis").leq(lit(8)), $"mappeddiagnosis").otherwise(lit(null).cast(StringType))).as("icddiag4"),
        max(when($"dxseq" === lit(5) && length($"mappeddiagnosis").leq(lit(8)), $"mappeddiagnosis").otherwise(lit(null).cast(StringType))).as("icddiag5"),
        max(when($"dxseq" === lit(6) && length($"mappeddiagnosis").leq(lit(8)), $"mappeddiagnosis").otherwise(lit(null).cast(StringType))).as("icddiag6"),
        max(when($"dxseq" === lit(7) && length($"mappeddiagnosis").leq(lit(8)), $"mappeddiagnosis").otherwise(lit(null).cast(StringType))).as("icddiag7"),
        max(when($"dxseq" === lit(8) && length($"mappeddiagnosis").leq(lit(8)), $"mappeddiagnosis").otherwise(lit(null).cast(StringType))).as("icddiag8"),
        max(when($"dxseq" === lit(9) && length($"mappeddiagnosis").leq(lit(8)), $"mappeddiagnosis").otherwise(lit(null).cast(StringType))).as("icddiag9"),
        max(when($"dxseq" === lit(10) && length($"mappeddiagnosis").leq(lit(8)), $"mappeddiagnosis").otherwise(lit(null).cast(StringType))).as("icddiag10"),
        max(when($"dxseq" === lit(11) && length($"mappeddiagnosis").leq(lit(8)), $"mappeddiagnosis").otherwise(lit(null).cast(StringType))).as("icd_diag_11"),
        max(when($"dxseq" === lit(12) && length($"mappeddiagnosis").leq(lit(8)), $"mappeddiagnosis").otherwise(lit(null).cast(StringType))).as("icd_diag_12"),
        max(when($"dxseq" === lit(13) && length($"mappeddiagnosis").leq(lit(8)), $"mappeddiagnosis").otherwise(lit(null).cast(StringType))).as("icd_diag_13"),
        max(when($"dxseq" === lit(14) && length($"mappeddiagnosis").leq(lit(8)), $"mappeddiagnosis").otherwise(lit(null).cast(StringType))).as("icd_diag_14"),
        max(when($"dxseq" === lit(15) && length($"mappeddiagnosis").leq(lit(8)), $"mappeddiagnosis").otherwise(lit(null).cast(StringType))).as("icd_diag_15"),
        max(when($"dxseq" === lit(16) && length($"mappeddiagnosis").leq(lit(8)), $"mappeddiagnosis").otherwise(lit(null).cast(StringType))).as("icd_diag_16"),
        max(when($"dxseq" === lit(17) && length($"mappeddiagnosis").leq(lit(8)), $"mappeddiagnosis").otherwise(lit(null).cast(StringType))).as("icd_diag_17"),
        max(when($"dxseq" === lit(18) && length($"mappeddiagnosis").leq(lit(8)), $"mappeddiagnosis").otherwise(lit(null).cast(StringType))).as("icd_diag_18"),
        max(when($"dxseq" === lit(19) && length($"mappeddiagnosis").leq(lit(8)), $"mappeddiagnosis").otherwise(lit(null).cast(StringType))).as("icd_diag_19"),
        max(when($"dxseq" === lit(20) && length($"mappeddiagnosis").leq(lit(8)), $"mappeddiagnosis").otherwise(lit(null).cast(StringType))).as("icd_diag_20"),
        max(when($"dxseq" === lit(21) && length($"mappeddiagnosis").leq(lit(8)), $"mappeddiagnosis").otherwise(lit(null).cast(StringType))).as("icd_diag_21"),
        max(when($"dxseq" === lit(22) && length($"mappeddiagnosis").leq(lit(8)), $"mappeddiagnosis").otherwise(lit(null).cast(StringType))).as("icd_diag_22"),
        max(when($"dxseq" === lit(23) && length($"mappeddiagnosis").leq(lit(8)), $"mappeddiagnosis").otherwise(lit(null).cast(StringType))).as("icd_diag_23"),
        max(when($"dxseq" === lit(24) && length($"mappeddiagnosis").leq(lit(8)), $"mappeddiagnosis").otherwise(lit(null).cast(StringType))).as("icd_diag_24"),
        max(when($"dxseq" === lit(25) && length($"mappeddiagnosis").leq(lit(8)), $"mappeddiagnosis").otherwise(lit(null).cast(StringType))).as("icd_diag_25"),
        max(when($"dxseq" === lit(1), $"poa").otherwise(lit(null).cast(StringType))).as("icddiag1poa"),
        max(when($"dxseq" === lit(2), $"poa").otherwise(lit(null).cast(StringType))).as("icddiag2poa"),
        max(when($"dxseq" === lit(3), $"poa").otherwise(lit(null).cast(StringType))).as("icddiag3poa"),
        max(when($"dxseq" === lit(4), $"poa").otherwise(lit(null).cast(StringType))).as("icddiag4poa"),
        max(when($"dxseq" === lit(5), $"poa").otherwise(lit(null).cast(StringType))).as("icddiag5poa"),
        max(when($"dxseq" === lit(6), $"poa").otherwise(lit(null).cast(StringType))).as("icddiag6poa"),
        max(when($"dxseq" === lit(7), $"poa").otherwise(lit(null).cast(StringType))).as("icddiag7poa"),
        max(when($"dxseq" === lit(8), $"poa").otherwise(lit(null).cast(StringType))).as("icddiag8poa"),
        max(when($"dxseq" === lit(9), $"poa").otherwise(lit(null).cast(StringType))).as("icddiag9poa"),
        max(when($"dxseq" === lit(10), $"poa").otherwise(lit(null).cast(StringType))).as("icddiag10poa"),
        max(when($"dxseq" === lit(11), $"poa").otherwise(lit(null).cast(StringType))).as("icddiag11poa"),
        max(when($"dxseq" === lit(12), $"poa").otherwise(lit(null).cast(StringType))).as("icddiag12poa"),
        max(when($"dxseq" === lit(13), $"poa").otherwise(lit(null).cast(StringType))).as("icddiag13poa"),
        max(
          when($"cdtype_cnt" === lit(1), lit(1))
            .when($"encounter_date".geq(to_date(lit("20151001"), CDRConstants.DATE_FORMAT_4Y2M2D)) && $"codetype" === lit("ICD10"), lit(1))
            .when($"encounter_date".lt(to_date(lit("20151001"), CDRConstants.DATE_FORMAT_4Y2M2D)) && $"codetype" === lit("ICD9"), lit(1))
            .otherwise(lit(2))
        ).as("record_preference")
      )
      .select(
        $"groupid",
        $"encounterid",
        $"client_ds_id",
        $"grp_mpi",
        $"codetype",
        $"encounter_date".cast(TimestampType),
        $"icddiag1",
        $"icddiag2",
        $"icddiag3",
        $"icddiag4",
        $"icddiag5",
        $"icddiag6",
        $"icddiag7",
        $"icddiag8",
        $"icddiag9",
        $"icddiag10",
        $"icd_diag_11",
        $"icd_diag_12",
        $"icd_diag_13",
        $"icd_diag_14",
        $"icd_diag_15",
        $"icd_diag_16",
        $"icd_diag_17",
        $"icd_diag_18",
        $"icd_diag_19",
        $"icd_diag_20",
        $"icd_diag_21",
        $"icd_diag_22",
        $"icd_diag_23",
        $"icd_diag_24",
        $"icd_diag_25",
        $"icddiag1poa",
        $"icddiag2poa",
        $"icddiag3poa",
        $"icddiag4poa",
        $"icddiag5poa",
        $"icddiag6poa",
        $"icddiag7poa",
        $"icddiag8poa",
        $"icddiag9poa",
        $"icddiag10poa",
        $"icddiag11poa",
        $"icddiag12poa",
        $"icddiag13poa",
        $"record_preference",
        $"sourceid",
        lit(null).cast(TimestampType).alias("primary_dx_timestamp"),
        lit(null).cast(StringType).alias("hosp_dx_flag"),
        lit(new Timestamp(DateTime.now().getMillis)).as("db_create_dt_tm")

      )

    joinedDf2.as[temp_bpo_diagnosis].toDF()

  }
}