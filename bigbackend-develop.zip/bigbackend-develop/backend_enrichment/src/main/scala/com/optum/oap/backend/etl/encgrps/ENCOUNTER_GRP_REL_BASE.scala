package com.optum.oap.backend.etl.encgrps

import com.optum.oap.backend.cdrTempModel.temp_encounter_grp_rel_base
import com.optum.oap.cdr.models.encounter_grp
import com.optum.oap.sparkdataloader.{RuntimeVariables, TableInfo, UserDefinedFunctionForDataLoader}
import org.apache.spark.sql.functions._
import org.apache.spark.sql.{DataFrame, SparkSession}

object ENCOUNTER_GRP_REL_BASE extends TableInfo[temp_encounter_grp_rel_base] {

  override def name: String = "ENCOUNTER_GRP_REL_BASE"

  override def dependsOn: Set[String] = Set("ENCOUNTER_GRP")

  override def partitions: Int = 64

  override protected def createDataFrame(sparkSession: SparkSession,
                                         loadedDependencies: Map[String, DataFrame],
                                         udfMap: Map[String, UserDefinedFunctionForDataLoader],
                                         runtimeVariables: RuntimeVariables): DataFrame = {
    import sparkSession.implicits._

    val encounterGrp = loadedDependencies("ENCOUNTER_GRP").where($"encounter_grp_type".isin("CH000113", "CH000106", "CH000107", "CH000109")).as[encounter_grp]

    val result = encounterGrp.as("idx")
      .join(encounterGrp.as("readm"), $"idx.grp_mpi" === $"readm.grp_mpi", "inner")
      .where(to_date($"readm.admittime") > to_date($"idx.dischargetime"))
      .select(
        $"idx.groupid".as("idxGroupId"),
        $"readm.groupid".as("readmGroupId"),
        $"idx.grp_mpi".as("idxGrpMpi"),
        $"readm.grp_mpi".as("readmGrpMpi"),
        $"idx.ENCOUNTER_GRP_NUM".as("idxEncounterGrpNum"),
        $"readm.ENCOUNTER_GRP_NUM".as("readmEncounterGrpNum"),
        $"idx.encounter_grp_type".as("idxEncounterGrpType"),
        $"readm.encounter_grp_type".as("readmEncounterGrpType"),
        $"idx.admittime".as("idxAdmitTime"),
        $"readm.admittime".as("readmAdmitTime"),
        $"idx.dischargetime".as("idxDischargeTime"),
        $"readm.dischargetime".as("readmDischargeTime"),
        $"idx.baseinclude".as("idxBaseInclude"),
        $"readm.baseinclude".as("readmBaseInclude"),
        $"idx.drg".as("idxDrg"),
        $"readm.drg".as("readmDrg"),
        $"idx.prindx".as("idxPrindx"),
        $"readm.prindx".as("readmPrindx"),
        $"idx.cmsinclude".as("idxCMSInclude"),
        $"readm.cmsinclude".as("readmCMSInclude"),
        $"idx.clientPlanned".as("idxClientPlanned"),
        $"readm.clientPlanned".as("readmClientPlanned"),
        $"idx.MDC".as("idxMDC"),
        $"readm.MDC".as("readmMDC"),
        $"idx.cmsPlanned".as("idxCMSPlanned"),
        $"readm.cmsPlanned".as("readmCMSPlanned"),
        $"idx.aprdrg".as("idxAPRDrg"),
        $"readm.aprdrg".as("readmAPRDrg")
      ).as[temp_encounter_grp_rel_base]

    result.toDF()
  }
}
