package com.optum.oap.backend.etl.summary

import com.optum.oap.backend.etl.common.CDRConstants
import com.optum.oap.cdr.models.{pat_rx_summary, rxorder}
import com.optum.oap.sparkdataloader.{RuntimeVariables, TableInfo, UserDefinedFunctionForDataLoader}
import org.apache.spark.sql.functions._
import org.apache.spark.sql.types.{IntegerType, StringType}
import org.apache.spark.sql.{DataFrame, SparkSession}
import org.slf4j.LoggerFactory

object PAT_RX_SUMMARY extends TableInfo[pat_rx_summary] {

  val log = LoggerFactory.getLogger( this.getClass )

  override def dependsOn = Set( "RXORDER" )

  override def name = "PAT_RX_SUMMARY"

  override def saveDataFrameToParquet: Boolean = true

  override def partitions: Int = 256

  override def skipTable: Boolean = false

  override def ignoreExtraColumnsInDataFrame: Boolean = false

  override def createDataFrame( sparkSession: SparkSession,
                                loadedDependencies: Map[String, DataFrame],
                                udfMap: Map[String, UserDefinedFunctionForDataLoader],
                                runtimeVariables: RuntimeVariables ): DataFrame = {

    import sparkSession.implicits._

    val rxorder = loadedDependencies( "RXORDER" ).as[rxorder]

    val summary = rxorder
      .filter( 'issuedate.isNotNull && 'grp_mpi.isNotNull )
      .withColumn( "hum_med_key",
        when( 'map_used.isNull, lit( "NOMAP" ) ).otherwise( coalesce( 'hum_med_key, lit( "HMK00.00.00" ) ) )
      )
      .select(
        'groupid,
        'grp_mpi,
        'map_used,
        'hum_med_key,
        date_format( 'issuedate, "yyyy" ).alias( "dt_yr" ),
        quarter( 'issuedate ).cast( StringType ).alias( "dt_qtr" ),
        date_format( 'issuedate, "MM" ).alias( "dt_month" ),
        date_format( 'issuedate, CDRConstants.DATE_FORMAT_4Y2M2D ).alias( "dt_yyyymmdd" )
      )
      .groupBy( "groupid", "grp_mpi", "hum_med_key", "dt_yr", "dt_qtr", "dt_month" )
      .agg( countDistinct( 'dt_yyyymmdd ).cast( IntegerType ).alias( "cnt" ) )

    summary.select( "groupid", "grp_mpi", "hum_med_key", "dt_yr", "dt_qtr", "dt_month", "cnt" )
  }
}
