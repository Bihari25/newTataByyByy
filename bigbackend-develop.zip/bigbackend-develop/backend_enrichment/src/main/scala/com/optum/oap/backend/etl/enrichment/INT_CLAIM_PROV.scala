package com.optum.oap.backend.etl.enrichment

import com.optum.oap.backend.loader.EnrichmentRunTimeVariables
import com.optum.oap.cdr.models.{int_claim_prov, map_predicate_values}
import com.optum.oap.sparkdataloader.{RuntimeVariables, TableInfo, UserDefinedFunctionForDataLoader}
import org.apache.spark.sql.{DataFrame, SparkSession}
import org.slf4j.LoggerFactory


object INT_CLAIM_PROV extends TableInfo[int_claim_prov] with INT_CLAIM_CLEANUP {

  private val log = LoggerFactory.getLogger(this.getClass)

  override def dependsOn = Set("CDR_FE_INT_CLAIM_PROV", "MAP_PREDICATE_VALUES")

  override def name = "INT_CLAIM_PROV"

  override def ignoreExtraColumnsInDataFrame: Boolean = true

  override def regexReplaceColumns: Set[String] = Set("prov_affil_id", "prov_status_id", "ii_prov_userdef_1", "ii_prov_userdef_2")

  override def createDataFrame(sparkSession: SparkSession,
                               loadedDependencies: Map[String, DataFrame],
                               udfMap: Map[String, UserDefinedFunctionForDataLoader],
                               runtimeVariables: RuntimeVariables): DataFrame = {
    import sparkSession.implicits._

    val provIn = loadedDependencies("CDR_FE_INT_CLAIM_PROV")
    val mapPredicateValues = loadedDependencies("MAP_PREDICATE_VALUES").as[map_predicate_values]
    val groupId = runtimeVariables.asInstanceOf[EnrichmentRunTimeVariables].clientId
    cleanUp(groupId, mapPredicateValues.toDF(), provIn)
  }
}