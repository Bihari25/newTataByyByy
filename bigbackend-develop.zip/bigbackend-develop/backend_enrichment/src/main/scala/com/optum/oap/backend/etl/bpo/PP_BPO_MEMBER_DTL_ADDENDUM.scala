package com.optum.oap.backend.etl.bpo

import java.sql.Timestamp

import com.optum.oap.backend.cdrTempModel.temp_bpo_patients
import com.optum.oap.cdr.models._
import com.optum.oap.sparkdataloader.{RuntimeVariables, TableInfo, UserDefinedFunctionForDataLoader}
import org.apache.spark.sql.functions._
import org.apache.spark.sql.types.DoubleType
import org.apache.spark.sql.{DataFrame, SparkSession}
import org.joda.time.{DateTime, LocalDateTime}

object PP_BPO_MEMBER_DTL_ADDENDUM extends TableInfo[pp_bpo_member_dtl_addendum] {

  override def dependsOn = Set("TEMP_BPO_PATIENTS")

  override def name = "PP_BPO_MEMBER_DTL_ADDENDUM"

  override def createDataFrame(sparkSession: SparkSession,
                               loadedDependencies: Map[String, DataFrame],
                               udfMap: Map[String, UserDefinedFunctionForDataLoader],
                               runtimeVariables: RuntimeVariables): DataFrame = {

    import sparkSession.implicits._

    val tempBpoPatients = loadedDependencies("TEMP_BPO_PATIENTS").as[temp_bpo_patients]

    tempBpoPatients
      .where('payer === 1)
      .select('groupid, 'grp_mpi.as("memberid"))
      .distinct()
      .select(
        'groupid
        , 'memberid
        , lit(0D).as("ergexpthreshold")
        , lit(0D).as("ergriskoutcome")
        , lit(0D).as("erginputdata")
        , lit(0D).as("ergcommmcaid")
        , lit(0D).as("riskinputtype")
        , lit("0").as("prg_expd_tshld")
        , lit("0").as("prg_risk_outcome")
        , lit("0").as("prg_problty_tshld")
        , lit(new Timestamp(DateTime.now().getMillis())).as("db_create_dt_tm")
      )
  }
}
