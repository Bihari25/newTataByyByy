package com.optum.oap.backend.etl.patient_matching.quality_gates

import com.optum.oap.backend.cdrTempModel.pat_match_prep
import com.optum.oap.backend.etl.common.{CDRConstants, SSNValidation}
import com.optum.oap.backend.etl.patient_matching.PATIENT_MPI_UTILS
import com.optum.oap.cdr.models._
import com.optum.oap.sparkdataloader.{RuntimeVariables, TableInfo, UserDefinedFunctionForDataLoader}
import org.apache.spark.sql.functions._
import org.apache.spark.sql.{DataFrame, Dataset, Row, SparkSession}

object QGATE_PERSON_ID_SUSPECTS extends TableInfo[qgate_person_id_suspects] {

  override def dependsOn: Set[String] = Set("PAT_MATCH_PREP", "PRE_PATIENT_MPI", "CDR_FE_PATIENTADDR", "PATIENTDETAIL_PREMATCH", "MAP_GENDER", "PATIENT_ID_PREMATCH", "ICPM_PATIENTADDR")

  override def name = "QGATE_PERSON_ID_SUSPECTS"

  override def createDataFrame(sparkSession: SparkSession,
                               loadedDependencies: Map[String, DataFrame],
                               udfMap: Map[String, UserDefinedFunctionForDataLoader],
                               runtimeVariables: RuntimeVariables): DataFrame = {

    import sparkSession.implicits._

    val patMatchPrep = loadedDependencies("PAT_MATCH_PREP").drop("row_source","modified_date").as[pat_match_prep]
    val patientMpi = loadedDependencies("PRE_PATIENT_MPI").drop("row_source","modified_date").as[patient_mpi]
    val patientAddr1 = loadedDependencies("CDR_FE_PATIENTADDR").as[patientaddr]
      .drop("row_source","modified_date").as[patientaddr]
    val icpmpatientAddr = loadedDependencies("ICPM_PATIENTADDR").drop("row_source","modified_date").as[patientaddr]
    val patientAddr = patientAddr1.unionByName(icpmpatientAddr)
    val patientDetail = loadedDependencies("PATIENTDETAIL_PREMATCH").drop("row_source","modified_date").as[patientdetail]
    val mapGender = broadcast(loadedDependencies("MAP_GENDER").drop("row_source","modified_date").as[map_gender])
    val patientId = loadedDependencies("PATIENT_ID_PREMATCH").drop("row_source","modified_date").as[patient_id]

    val temp = patMatchPrep.as("pts")
      .join(patientMpi.as("mpi"), Seq("groupid", "client_ds_id", "patientid", "hgpid"), "inner")
      .join(patientAddr.as("pad"), Seq("groupid", "patientid", "client_ds_id"), "left")
      .join(patientDetail.as("pdet").where($"pdet.patientdetailtype" === lit("GENDER")), Seq("groupid", "patientid", "client_ds_id"), "left")
      .join(mapGender.as("mg"),$"pdet.localvalue" === $"mg.mnemonic", "left")
      .groupBy($"pts.groupid", $"mpi.grp_mpi".as("personid"))
      .agg(
        when(countDistinct(regexp_replace(lower($"pts.lname"), "[^a-z]", "")) > 1 &&
          countDistinct($"pts.dob") > 1, lit(1)
        ).otherwise(null).as("gate1"),
        when(countDistinct(lower($"pts.fname")) > 1 &&
          countDistinct(when($"mg.cui".isInCollection(CDRConstants.MALE_AND_FEMALE_CUIS), $"mg.cui").otherwise(null)) > 1 &&
          countDistinct(lower($"address_line1")) > 1 &&
          countDistinct($"pts.dob") > 1, lit(1)
        ).otherwise(null).as("gate2")
      )

    temp
      .where($"gate1" === lit(1) || $"gate2" === lit(1))
      .flatMap(gates1and2)
      .union(gate3(sparkSession, patientId, patientMpi))
      .toDF

  }

  private def gates1and2(row: Row): Seq[qgate_person_id_suspects] = {
    val groupId = row.getAs[String]("groupid")
    val personId = row.getAs[String]("personid")
    val gate1: Option[qgate_person_id_suspects] = if (row.getAs[Integer]("gate1") == 1)
      Some(qgate_person_id_suspects(1, groupId, personId)) else None
    val gate2: Option[qgate_person_id_suspects] = if (row.getAs[Integer]("gate2") == 1)
      Some(qgate_person_id_suspects(2, groupId, personId)) else None

    Seq(gate1, gate2).flatten
  }


  private def gate3(sparkSession: SparkSession, patientId: Dataset[patient_id], patientMpi: Dataset[patient_mpi]): Dataset[qgate_person_id_suspects] = {
    import sparkSession.implicits._

    val ssnDetails = patientId.as("a")
      .join(patientMpi.as("mpi"), Seq("groupid", "client_ds_id", "patientid","hgpid"), "inner")
      .where($"idtype" === lit("SSN")
        && !SSNValidation.cleanAndValidate($"idvalue").isin(SSNValidation.INVALID_OUTCOMES: _*)
        && $"mpi.grp_mpi".isNotNull && $"a.groupid" === lit("H542284"))
      .select(
        $"a.groupid",
        $"mpi.grp_mpi".as("mpi_grp_mpi"),
        trim(substring(regexp_replace($"idvalue", "-", ""), 0, 9)).as("cleaned_ssn")
      )

    ssnDetails
      .where(!$"cleaned_ssn".isin(PATIENT_MPI_UTILS.getBadSSNs: _*))
      .groupBy($"groupid", $"mpi_grp_mpi")
      .agg(
        countDistinct($"cleaned_ssn").as("cleaned_ssn_count")
      )
      .where($"cleaned_ssn_count" > lit(1))
      .select(
        lit(3).as("gate_id"),
        $"groupid",
        $"mpi_grp_mpi".as("personid")
      ).as[qgate_person_id_suspects]
  }
}
