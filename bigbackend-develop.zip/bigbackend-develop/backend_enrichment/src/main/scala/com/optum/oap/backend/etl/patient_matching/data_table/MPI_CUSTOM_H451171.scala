package com.optum.oap.backend.etl.patient_matching.data_table

import com.optum.oap.backend.cdrTempModel.pat_match_prep
import com.optum.oap.backend.etl.common.{CDRConstants, CleanPatientName, EnrichmentUtils, SSNValidation}
import com.optum.oap.backend.etl.patient_matching.PATIENT_MPI_UTILS
import com.optum.oap.backend.loader.EnrichmentRunTimeVariables
import com.optum.oap.cdr.models.{map_gender, mpi_custom, patient_id, patientdetail}
import com.optum.oap.sparkdataloader.{RuntimeVariables, TableInfo, UserDefinedFunctionForDataLoader}
import org.apache.spark.sql.expressions.Window
import org.apache.spark.sql.functions._
import org.apache.spark.sql.types.LongType
import org.apache.spark.sql.{DataFrame, SparkSession}

object MPI_CUSTOM_H451171 extends TableInfo[mpi_custom] {

  override def dependsOn = Set("PAT_MATCH_PREP", "PATIENTDETAIL_PREMATCH", "MAP_GENDER", "PATIENT_ID_PREMATCH", "ECDR_MPI_CUSTOM_H451171")

  override def name = "MPI_CUSTOM_H451171"

  override def createDataFrame(sparkSession: SparkSession,
                               loadedDependencies: Map[String, DataFrame],
                               udfMap: Map[String, UserDefinedFunctionForDataLoader],
                               runtimeVariables: RuntimeVariables): DataFrame = {
    import sparkSession.implicits._
    val dailyBuild = if (runtimeVariables.asInstanceOf[EnrichmentRunTimeVariables].buildType == CDRConstants.DELTA_BUILD_TYPE) true else false


    val tempPatMatchPrep = loadedDependencies("PAT_MATCH_PREP").as[pat_match_prep]
    val tempPatientId = loadedDependencies("PATIENT_ID_PREMATCH").as[patient_id]
    val patientdetailIn = loadedDependencies("PATIENTDETAIL_PREMATCH").as[patientdetail]
    val mapGender = broadcast(loadedDependencies("MAP_GENDER").as[map_gender])

    val tempPatAttrs_DF = tempPatMatchPrep
      .where($"dob".isNotNull)
      .select(
        $"groupid",
        $"client_ds_id",
        $"patientid",
        $"hgpid",
        $"dob",
        CleanPatientName.cleanPatientName($"fname", lit(3)).as("fname"),
        CleanPatientName.cleanPatientName($"lname", lit(3)).as("lname")
      ).distinct

    val tempPatientId_SSN_DF = tempPatientId.as("tpi")
      .where(!trim(substring(regexp_replace($"idvalue", "-", ""), 1, 9)).isin(PATIENT_MPI_UTILS.getBadSSNs: _*))
      .where($"tpi.idtype" === lit("SSN"))
      .where(!SSNValidation.cleanAndValidate($"tpi.idvalue").isin(SSNValidation.INVALID_OUTCOMES: _*))
      .select(
        $"groupid",
        $"client_ds_id",
        $"patientid",
        trim(substring(regexp_replace($"idvalue", "-", ""), 1, 9)).as("ssn")
      ).distinct

    val tempPatientId_MRN_DF = tempPatientId.as("tpi")
      .where($"tpi.idtype" === lit("MRN"))
      .select(
        $"groupid",
        $"client_ds_id",
        $"patientid",
        trim(substring(regexp_replace($"idvalue", "-", ""), 1, 9)).as("mrn")
      ).distinct

    val dobWindow = Window.partitionBy($"dob")
    val dataDf = tempPatAttrs_DF.as("p")
      .join(tempPatientId_SSN_DF.as("pid"), Seq("groupid", "client_ds_id", "patientid"), "left")
      .join(tempPatientId_MRN_DF.as("mrn"), Seq("groupid", "client_ds_id", "patientid"), "left")
      .join(patientdetailIn.as("pd"),
        $"p.client_ds_id" === $"pd.client_ds_id"
          && $"p.patientid" === $"pd.patientid"
          && $"pd.patientdetailtype" === lit("GENDER"),
        "left")
      .join(mapGender.as("mg"),
        $"pd.localvalue" === $"mg.mnemonic"
          && $"pd.groupid" === $"mg.groupid"
          && $"mg.cui".isInCollection(CDRConstants.MALE_AND_FEMALE_CUIS),
        "left")
      .join(patientdetailIn.as("pz"),
        $"p.client_ds_id" === $"pz.client_ds_id"
          && $"p.patientid" === $"pz.patientid"
          && $"pz.patientdetailtype" === lit("ZIPCODE"),
        "left")
      .select(
        $"p.groupid",
        $"p.client_ds_id",
        $"p.patientid",
        $"p.hgpid",
        $"p.dob".as("key_attr"),
        $"p.fname".as("attr_2"),
        $"p.lname".as("attr_3"),
        upper(regexp_extract($"fname", "^([^ ,]{1,})", 1)).as("attr_4"),
        substring($"lname", 1, 7).as("attr_5"),
        substring($"fname", 1, 7).as("attr_6"),
        $"mrn.mrn".as("attr_7"),
        $"mg.cui".as("attr_8"),
        $"pid.ssn".as("attr_9"),
        substring($"pz.localvalue", 1, 5).as("attr_10"),
        substring($"lname", 1, 3).as("attr_11"),
        substring($"lname", 1, 5).as("attr_12"),
        size(collect_set("p.groupid").over(dobWindow)).as("group_cnt"),
        size(collect_set("p.hgpid").over(dobWindow)).cast(LongType).as("hgpids")
      )


    val ecdrDf = {
      if (dailyBuild) EnrichmentUtils.removeRowSourceAndModifiedDate(loadedDependencies("ECDR_MPI_CUSTOM_H451171")).as[mpi_custom]
      else sparkSession.emptyDataset[mpi_custom].as[mpi_custom]
    }.as("e")
      .select($"e.*")

    dataDf.unionByName(ecdrDf).distinct()

  }
}
