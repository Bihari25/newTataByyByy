package com.optum.oap.backend.etl.enrichment

import com.optum.oap.backend.cdrTempModel.{acri_drg_file_facilities, ascension_drg, infer_pat_type}
import com.optum.oap.backend.etl.common.MapMasterIds
import com.optum.oap.backend.loader.EnrichmentRunTimeVariables
import com.optum.oap.cdr.models.{clinicalencounter, map_pat_type_order, map_patient_type, map_predicate_values, patient_mpi}
import com.optum.oap.sparkdataloader.{RuntimeVariables, TableInfo, UserDefinedFunctionForDataLoader}
import org.apache.spark.sql.expressions.Window
import org.apache.spark.sql.{DataFrame, Dataset, SparkSession}
import org.slf4j.LoggerFactory
import org.apache.spark.sql.functions._
import org.apache.spark.sql.types.DataTypes


object CLINICALENCOUNTER extends TableInfo[clinicalencounter] {

  val log = LoggerFactory.getLogger(this.getClass)

  override def dependsOn: Set[String] = Set("CDR_FE_CLINICALENCOUNTER", "PATIENT_MPI", "INFER_PAT_TYPE", "MAP_PREDICATE_VALUES", "MAP_PATIENT_TYPE", "MAP_PAT_TYPE_ORDER", "ICPM_CLINICALENCOUNTER")

  override def name = "CLINICALENCOUNTER"

  override def saveDataFrameToParquet: Boolean = true

  override def partitions: Int = 32

  override def skipTable: Boolean = false

  override def ignoreExtraColumnsInDataFrame: Boolean = true

  override def createDataFrame(sparkSession: SparkSession,
                               loadedDependencies: Map[String, DataFrame],
                               udfMap: Map[String, UserDefinedFunctionForDataLoader],
                               runtimeVariables: RuntimeVariables): DataFrame = {
    import sparkSession.implicits._

    val clinicalencounterIn = loadedDependencies("CDR_FE_CLINICALENCOUNTER").drop(
      "row_source", "modified_date").as[clinicalencounter]
    val icpmClinicalEncounter = loadedDependencies("ICPM_CLINICALENCOUNTER").as[clinicalencounter]
    val clinicalEncounterUnion = clinicalencounterIn.unionByName(icpmClinicalEncounter)
    val patXref = loadedDependencies("PATIENT_MPI").as[patient_mpi]
    val map_predicate_values = loadedDependencies("MAP_PREDICATE_VALUES").as[map_predicate_values]


    val grpid = EnrichmentRunTimeVariables(runtimeVariables).clientId
    val clientBucket = EnrichmentRunTimeVariables(runtimeVariables).clientBucket
    val env = EnrichmentRunTimeVariables(runtimeVariables).environment


    val mapPredicateValues = map_predicate_values.as("b")
      .where($"b.column_name" === "CLIENT_DS_ID"
        && upper($"b.column_value") === "YES"
        && $"b.entity" === "CLINICALENCOUNTER"
        && $"b.table_name" === "CLINICALENCOUNTER"
        && $"b.data_src" === "CDR_INFERPT").collect()

    val clinicalencounter = MapMasterIds.mapPatientIds(clinicalEncounterUnion.toDF, patXref.toDF, false)

    val result = if (mapPredicateValues.nonEmpty) {
      val mapPatientType = broadcast(loadedDependencies("MAP_PATIENT_TYPE").as[map_patient_type].select($"cui", $"groupid", $"local_code"))
      val mapPatTypeOrder = broadcast(loadedDependencies("MAP_PAT_TYPE_ORDER")).as[map_pat_type_order]
      val inferPatType = loadedDependencies("INFER_PAT_TYPE").as[infer_pat_type]

      val tempCePt = clinicalencounter.as("ce")
        .join(inferPatType.as("pti"), $"ce.groupid" === $"pti.groupid"
          && $"ce.client_ds_id" === $"pti.client_ds_id"
          && $"ce.encounterid" === $"pti.encounterid", "left_outer")
        .join(mapPatientType.as("mpt"), $"ce.groupid" === $"mpt.groupid"
          && $"ce.localpatienttype" === $"mpt.local_code", "left_outer")
        .join(mapPatTypeOrder.as("pto"), $"mpt.cui" === $"pto.pat_type_cui", "left_outer")
        .withColumn("inferred_pat_type"
          , when($"pto.pat_type_order" < $"pti.inferred_order", $"mpt.cui")
            .otherwise(coalesce($"pti.inferred_ptype", $"mpt.cui")))
        .select($"ce.*", $"inferred_pat_type")

      tempCePt
    } else {
      clinicalencounter
    }
    if (grpid.equalsIgnoreCase("H984216")) {

      val custH984DrgPath = s"s3://datalake.h-984000.e1.78bd.phi/$env/history/7287/"

      val ascensionDRG = sparkSession.read.parquet(s"$custH984DrgPath/ASCENSION_DRG/*").as[ascension_drg]
      val acriDrgFileFacilities = broadcast(sparkSession.read.parquet(s"$custH984DrgPath/ACRI_DRG_FILE_FACILITIES/*").as[acri_drg_file_facilities])

      updateDrgClinEnc(sparkSession, result, ascensionDRG, acriDrgFileFacilities)

    } else {
      result
    }
  }

  def updateDrgClinEnc(sparkSession: SparkSession,clinicalEnc: DataFrame, ascensionDRG: Dataset[ascension_drg], acriDrgFileFacilities: Dataset[acri_drg_file_facilities])  =  {
    import sparkSession.implicits._
    val dateWindow = Window.partitionBy($"F.DS_ID".cast(DataTypes.IntegerType), $"D.ENCOUNTER").orderBy($"D.SYSTEM_DATE".desc_nulls_last)

    val filteredAcriDrgFileFacilities = acriDrgFileFacilities
      .where(length(trim(translate($"DS_ID", " 0123456789", " "))) === 0)
    val drug = ascensionDRG.as("D")
      .join(filteredAcriDrgFileFacilities.as("F"), $"D.FACILITY" === $"F.FACILITY_CODE", "inner")
      .select(
        $"F.DS_ID".cast(DataTypes.IntegerType).as("ds_id"),
        $"D.ENCOUNTER".as("encounter"),
        $"D.APR_DRG".as("apr_drg"),
        $"D.APR_ROM".as("apr_rom"),
        $"D.APR_SOI".as("apr_soi"),
        $"D.MS_DRG".as("ms_drg"),
        when($"D.MS_DRG".isNotNull, lit("MS-DRG")).otherwise(null).as("localdrgtype"),
        $"D.DISCHARGE_DISPOSITION_CD".as("discharge_disposition_cd"),
        row_number().over(dateWindow).as("row_number")
      )
      .where($"row_number" === lit(1))

    val facility = filteredAcriDrgFileFacilities
      .groupBy($"DS_ID".cast(DataTypes.IntegerType).as("ds_id"))
      .agg(
        max($"update_drgs").as("update_drgs"),
        max($"update_discharge_dispos").as("update_discharge_dispos")
      )

    clinicalEnc.as("E")
      .join(drug.as("D"),
      $"D.ds_id" === $"E.client_ds_id" &&  $"D.encounter" === ltrim(coalesce($"E.alt_encounterid", $"E.encounterid"), "0"), "left_outer")
      .join(facility.as("F"),
        $"F.ds_id" === $"E.client_ds_id", "left_outer"
      )
      .select($"E.*",
        when($"D.encounter".isNotNull &&  substring(upper($"F.update_discharge_dispos"), 0,1) === lit("Y"), $"D.discharge_disposition_cd")
          .when($"D.encounter".isNull && substring(upper($"F.update_discharge_dispos"), 0, 1) === lit("Y"),  lit(null))
          .otherwise($"E.localdischargedisposition").as("LOCAL_DD_MOD"),
        when($"D.encounter".isNotNull && substring(upper($"F.update_drgs"), 0, 1) === lit("Y"), $"D.ms_drg")
          .when($"D.encounter".isNull && substring(upper($"F.update_drgs"), 0, 1) === lit("Y"), lit(null))
          .otherwise($"E.localdrg").as("LOCALDRG_MOD"),
        when($"D.encounter".isNotNull && substring(upper($"F.update_drgs"), 0, 1) === lit("Y") &&  $"D.ms_drg".isNotNull, lit("MS-DRG"))
          .when($"D.encounter".isNull && substring(upper($"F.update_drgs"), 0, 1) === lit("Y"), lit(null))
          .otherwise($"E.localdrgtype").as("LDRT_MOD"),
        when($"D.encounter".isNotNull && substring(upper($"F.update_drgs"), 0, 1)  === lit("Y"), $"D.apr_drg")
          .when($"D.encounter".isNull && substring(upper($"F.update_drgs"), 0, 1) === lit("Y"), lit(null))
          .otherwise($"E.aprdrg_cd").as("APRDRG_CD_MOD"),
        when($"D.encounter".isNotNull && substring(upper($"F.update_drgs"), 0, 1) === lit("Y"), $"D.apr_soi")
          .when($"D.encounter".isNull && substring(upper($"F.update_drgs"), 0, 1) === lit("Y"), lit(null))
          .otherwise($"E.aprdrg_soi").as("APRDRG_SOI_MOD"),
        when($"D.encounter".isNotNull && substring(upper($"F.update_drgs"), 0, 1) === lit("Y"), $"D.apr_rom")
          .when($"D.encounter".isNull && substring(upper($"F.update_drgs"), 0, 1) === lit("Y"), lit(null))
          .otherwise($"E.aprdrg_rom").as("APRDRG_ROM_MOD")
      )
      .drop("localdischargedisposition", "localdrg", "localdrgtype", "aprdrg_cd", "aprdrg_soi", "aprdrg_rom")
      .withColumnRenamed("LOCAL_DD_MOD", "localdischargedisposition")
      .withColumnRenamed("LOCALDRG_MOD", "localdrg")
      .withColumnRenamed("LDRT_MOD", "localdrgtype")
      .withColumnRenamed("APRDRG_CD_MOD", "aprdrg_cd")
      .withColumnRenamed("APRDRG_SOI_MOD", "aprdrg_soi")
      .withColumnRenamed("APRDRG_ROM_MOD", "aprdrg_rom")

  }
}
