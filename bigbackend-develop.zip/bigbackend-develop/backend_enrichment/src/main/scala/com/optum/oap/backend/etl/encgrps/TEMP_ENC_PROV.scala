package com.optum.oap.backend.etl.encgrps
import com.optum.oap.backend.cdrTempModel.temp_enc_prov
import com.optum.oap.cdr.models.{encounter_encounter_grp, encounterprovider}
import com.optum.oap.sparkdataloader.{RuntimeVariables, TableInfo, UserDefinedFunctionForDataLoader}
import org.apache.spark.sql.{DataFrame, SparkSession}

object TEMP_ENC_PROV extends TableInfo[temp_enc_prov] {
  override def dependsOn: Set[String] = Set("ENCOUNTERPROVIDER","ENCOUNTER_ENCOUNTER_GRP")
  override def name = "TEMP_ENC_PROV"

  override def createDataFrame(sparkSession: SparkSession, loadedDependencies: Map[String, DataFrame], udfMap: Map[String, UserDefinedFunctionForDataLoader], runtimeVariables: RuntimeVariables): DataFrame = {
    import sparkSession.implicits._

    val encounterProvider = loadedDependencies("ENCOUNTERPROVIDER").as[encounterprovider]
    val encounterEncounterGrp = loadedDependencies("ENCOUNTER_ENCOUNTER_GRP").as[encounter_encounter_grp]

    encounterProvider.as("px").where($"px.providerid".isNotNull)
      .join(encounterEncounterGrp.as("eeg"), $"px.groupid" === $"eeg.groupid" && $"px.encounterid" === $"eeg.encounterid" && $"px.client_ds_id" === $"eeg.client_ds_id", "INNER")
      .select($"px.groupid",
      $"eeg.grp_mpi",
        $"px.datasrc",
        $"ENCOUNTER_GRP_NUM",
        $"px.providerid",
        $"px.client_ds_id",
        $"px.encounterid",
        $"px.providerrole",
        $"px.encountertime",
        $"eeg.patienttype",
        $"eeg.encounteridtype"
      ).distinct
  }
}