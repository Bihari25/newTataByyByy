package com.optum.oap.backend.etl.common

object CDRConstants {
  val DATE_FORMAT_4Y2M2D: String = "yyyyMMdd"
  val DELTA_BUILD_TYPE: String = "Delta"
  val MONTHLY_BUILD_TYPE : String = "Monthly"
  val CLEARED_AND_REFFERED_2_CLIENT_STATUS_IDS: Set[String] = Set("P", "R")
  val MALE_AND_FEMALE_CUIS: Set[String] = Set("CH000034", "CH000033")
  val STL_DS_IDS: Set[Integer] = Set(2201, 2421, 2422, 2423, 2424, 2521, 2741, 3241, 3242, 3243, 3244, 3245, 3246, 3247, 3248, 3249, 3250, 3251, 3252, 3253, 3254, 3255, 3256, 3258, 3259, 3541, 4521, 4703, 4987, 4988, 4989)
  val WIS_DS_IDS: Set[Integer] = Set(2281, 2522, 3257, 4344)
  val MPI_RULE_SCORE_MIN: Integer = 90
  val BABY_INDICATORS:Set[String] = Set("BABY", "BABYBOY", "BABYGIRL", "BB", "BG", "BABY-BOY", "BABY-GIRL", "TWIN")
  val PATIENT_MPI_MAX_ITERATION = 100
  val PATIENT_XWALK_MAX_ITERATION = 100
  val OAPCONFIG_BUCKET_NAME = "oap-configs-754417584131"
  val metricTables = Seq("ETL_RUN_TIME", "ETL_CONCURRENT_RUNS")
}
