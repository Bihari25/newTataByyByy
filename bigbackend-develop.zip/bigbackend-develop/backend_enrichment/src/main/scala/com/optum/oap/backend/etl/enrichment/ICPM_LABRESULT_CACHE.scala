package com.optum.oap.backend.etl.enrichment

import com.optum.oap.backend.cdrTempModel.ref_term_dict_loinc_partial
import com.optum.oap.backend.etl.common.IsSafeToNumber
import com.optum.oap.cdr.models.{int_claim_labresult, labresult}
import com.optum.oap.sparkdataloader.{RuntimeVariables, TableInfo, UserDefinedFunctionForDataLoader}
import org.apache.spark.sql.expressions.Window
import org.apache.spark.sql.{DataFrame, SparkSession}
import org.slf4j.LoggerFactory
import org.apache.spark.sql.functions._
import org.apache.spark.sql.types.DataTypes

object ICPM_LABRESULT_CACHE extends TableInfo[labresult] {

  private val log = LoggerFactory.getLogger(this.getClass)

  override def dependsOn = Set("INT_CLAIM_LABRESULT", "REF_TERM_DICT_LOINC")

  override def name = "ICPM_LABRESULT_CACHE"

  override def createDataFrame(sparkSession: SparkSession,
                               loadedDependencies: Map[String, DataFrame],
                               udfMap: Map[String, UserDefinedFunctionForDataLoader],
                               runtimeVariables: RuntimeVariables): DataFrame = {

    import sparkSession.implicits._

    val cdrFeIntClaimLabresult = loadedDependencies("INT_CLAIM_LABRESULT").as[int_claim_labresult]

    val refTermDictLoinc = loadedDependencies("REF_TERM_DICT_LOINC").as[ref_term_dict_loinc_partial]

    cdrFeIntClaimLabresult.as("lab").join(refTermDictLoinc.as("tdl")
    , $"lab.loinc_code" === $"tdl.loinc_num", "left").select(
      $"groupid"
      , $"client_ds_id"
      , lit("int_claim_labresult").as("datasrc")
      , coalesce($"labresult_id",
        concat($"client_ds_id"
          , lit(".")
          , coalesce(
            $"labresult_id"
            , expr("nullif(concat_ws('', member_id, to_date(result_date, 'yyyyMMdd'), result_code),'')")
          ))).as("labresultid")
      , $"lab.result_code".as("localcode")
      , coalesce($"lab.test_result_number".cast(DataTypes.StringType), $"lab.test_result_text").as("localresult")
      , $"lab.member_id".as("patientid")
      , $"lab.collection_date".as("datecollected")
      , $"lab.order_date".as("labordereddate")
      , $"lab.result_date".as("dateavailable")
      , $"lab.result_date".as("labresult_date")
      , coalesce($"labresult_id", coalesce($"lab.encounterid", $"lab.claim_header_id")).as("encounterid")
      , $"lab.loinc_code".as("local_loinc_code")
      , lower(coalesce($"tdl.Long_Common_Name"
        ,$"lab.Loinc_Name"
        ,$"lab.Result_Name"
        ,$"lab.test_order_name")
      ).as("localname")
      , $"lab.Specimen_Source".as("localspecimentype")
      , $"lab.test_order_name".as("localtestname")
      , $"lab.test_result_units".as("localunits")
      , $"lab.reference_range".as("normalrange")
      , $"lab.abnormal_flag".as("resulttype")
    ).filter($"patientid".isNotNull
      && $"labresult_date".isNotNull
      && $"labresultid".isNotNull
    ).select( $"*"
      , when(IsSafeToNumber.isSafeToNumber($"localresult"),$"localresult")
        .otherwise(null).cast(DataTypes.DoubleType).as("localresult_numeric")
      , row_number().over(Window.partitionBy($"client_ds_id", $"labresultid")
        //Comparing to Oracle script, localunits and normalrange are added in addition to other orderBy columns to avoid non-deterministic issue.
        .orderBy($"labordereddate".desc_nulls_last,$"localunits".desc_nulls_last, $"normalrange".desc_nulls_last)).as("rank_labresult")
      , lit(null).cast(DataTypes.StringType).as("facilityid")
      , lit(null).cast(DataTypes.StringType).as("grp_mpi")
      , lit(null).cast(DataTypes.LongType).as("hgpid")
      , lit(null).cast(DataTypes.StringType).as("laborderid")
      , lit(null).cast(DataTypes.StringType).as("locallisresource")
      , lit(null).cast(DataTypes.DoubleType).as("localresult_inferred")
      , lit(null).cast(DataTypes.StringType).as("localunits_inferred")
      , lit(null).cast(DataTypes.StringType).as("mapped_qual_code")
      , lit(null).cast(DataTypes.StringType).as("mappedcode")
      , lit(null).cast(DataTypes.StringType).as("mappedloinc")
      , lit(null).cast(DataTypes.StringType).as("mappedname")
      , lit(null).cast(DataTypes.StringType).as("mappedunits")
      , lit(null).cast(DataTypes.DoubleType).as("normalizedvalue")
      , lit(null).cast(DataTypes.StringType).as("relativeindicator")
      , lit(null).cast(DataTypes.StringType).as("resultstatus")
      , lit(null).cast(DataTypes.StringType).as("statuscode")
    ).filter($"rank_labresult" === 1).drop("rank_labresult")

  }
}

