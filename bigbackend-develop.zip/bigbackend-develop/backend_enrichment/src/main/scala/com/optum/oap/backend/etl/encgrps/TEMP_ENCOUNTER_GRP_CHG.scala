package com.optum.oap.backend.etl.encgrps

import com.optum.oap.backend.cdrTempModel.temp_encounter_grp_chg
import com.optum.oap.sparkdataloader.QueryAndMetadata


object TEMP_ENCOUNTER_GRP_CHG extends QueryAndMetadata[temp_encounter_grp_chg] {
  override def name: String = "TEMP_ENCOUNTER_GRP_CHG"

  override def sparkSql: String = """select   groupid, grp_mpi, ENCOUNTER_GRP_NUM, round(sum(totchg), 2) as totchg
from
(select  distinct ve.groupid, ve.grp_mpi, eeg.ENCOUNTER_GRP_NUM, coalesce(ve.totalcharge,px.totchg) as totchg
from
temp_visit_enctr ve
inner join ENCOUNTER_ENCOUNTER_GRP  eeg on (ve.groupid = eeg.groupid and ve.encounterid = eeg.encounterid and ve.client_ds_id = eeg.client_ds_id)
left outer join TEMP_ENCOUNTER_CLM_CHG px on (px.groupid = eeg.groupid and px.encounterid = eeg.encounterid and px.client_ds_id = eeg.client_ds_id and px.ENCOUNTER_GRP_NUM=eeg.ENCOUNTER_GRP_NUM)
where eeg.encounteridtype not in ('ADD ER','ADD OB','ADD SD')
)
group by groupid, grp_mpi, ENCOUNTER_GRP_NUM"""

  override def dependsOn: Set[String] = Set("TEMP_VISIT_ENCTR","ENCOUNTER_ENCOUNTER_GRP","TEMP_ENCOUNTER_CLM_CHG")
}
