package com.optum.oap.backend.etl.bpo.bpo_pyr_sre

import com.optum.oap.backend.cdrTempModel.monthly_payer_lab_sre
import com.optum.oap.cdr.models.{pp_bpo_labresult_claims, pp_bpo_member_detail}
import com.optum.oap.sparkdataloader.{RuntimeVariables, TableInfo, UserDefinedFunctionForDataLoader}
import org.apache.spark.sql.functions.{date_format, lit}
import org.apache.spark.sql.types.StringType
import org.apache.spark.sql.{DataFrame, SparkSession}

object MONTHLY_PAYER_LAB_SRE_EXTRACT extends TableInfo[monthly_payer_lab_sre] {

  override def dependsOn = Set("PP_BPO_LABRESULT_CLAIMS", "PP_BPO_MEMBER_DETAIL")

  override def name = "MONTHLY_PAYER_LAB_SRE_EXTRACT"

  override def createDataFrame(sparkSession: SparkSession,
                               loadedDependencies: Map[String, DataFrame],
                               udfMap: Map[String, UserDefinedFunctionForDataLoader],
                               runtimeVariables: RuntimeVariables): DataFrame = {
    import sparkSession.implicits._

    val ppBpoLabresultClaims = loadedDependencies("PP_BPO_LABRESULT_CLAIMS").as[pp_bpo_labresult_claims]
    val ppBpoMemberDetail = loadedDependencies("PP_BPO_MEMBER_DETAIL").as[pp_bpo_member_detail]

    val result_df = ppBpoLabresultClaims.as("lab")
      .where($"healthplansource" === "PAYER")
      .join(ppBpoMemberDetail.as("elig"), Seq("groupid", "memberid", "healthplansource"), "inner")
      .where($"lab.servicedate".between($"elig.effectivedate", $"elig.enddate"))
      .select(
        $"lab.memberid".as("memberid"),
        date_format($"lab.servicedate", "yyyy-MM-dd").as("servicedate"),
        $"lab.loinc".as("loinc"),
        $"lab.testresultnumber".cast(StringType).as("testresultnumber"),
        $"lab.testresultunits".as("testresultunits"),
        $"lab.testresulttext".as("testresulttext"),
        $"lab.fastingstatus".as("fastingstatus"),
        $"lab.claimheader".as("claimheader"),
        $"lab.labsource".as("labsource"),
        $"lab.healthplansource".as("healthplansource"),
        $"lab.coverageclasscode".as("coverageclasscode"),
        $"lab.cpt_code".as("cpt_code"),
        lit(null).cast(StringType).as("pos"),
        lit(null).cast(StringType).as("prov_type_code"),
        lit(null).cast(StringType).as("prov_specialty_code"),
        lit(null).cast(StringType).as("prov_key")
      )
    result_df.as[monthly_payer_lab_sre].toDF()
  }
}
