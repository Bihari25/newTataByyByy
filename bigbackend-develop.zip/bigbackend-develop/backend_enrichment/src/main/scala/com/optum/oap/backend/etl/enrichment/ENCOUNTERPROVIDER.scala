package com.optum.oap.backend.etl.enrichment

import com.optum.oap.backend.etl.common.MapMasterIds
import com.optum.oap.cdr.models.{encounterprovider, patient_mpi, zh_provider_master_xref}
import com.optum.oap.sparkdataloader.{RuntimeVariables, TableInfo, UserDefinedFunctionForDataLoader}
import org.apache.spark.sql.functions.broadcast
import org.apache.spark.sql.{DataFrame, SparkSession}
import org.slf4j.LoggerFactory

object ENCOUNTERPROVIDER extends TableInfo[encounterprovider] {

  val log = LoggerFactory.getLogger(this.getClass)

  override def dependsOn = Set("PATIENT_MPI", "ZH_PROVIDER_MASTER_XREF", "CDR_FE_ENCOUNTERPROVIDER", "ICPM_ENCOUNTERPROVIDER")

  override def name = "ENCOUNTERPROVIDER"

  override def saveDataFrameToParquet: Boolean = true

  override def partitions: Int = 32

  override def skipTable: Boolean = false

  override def ignoreExtraColumnsInDataFrame: Boolean = true

  override def createDataFrame(sparkSession: SparkSession,
                               loadedDependencies: Map[String, DataFrame],
                               udfMap: Map[String, UserDefinedFunctionForDataLoader],
                               runtimeVariables: RuntimeVariables): DataFrame = {
    import sparkSession.implicits._

    val encounterproviderIn = loadedDependencies("CDR_FE_ENCOUNTERPROVIDER").drop("row_source","modified_date").as[encounterprovider]
    val icpmEncounterpoviderIn = loadedDependencies("ICPM_ENCOUNTERPROVIDER").as[encounterprovider]

    val unionEncp = encounterproviderIn.unionByName(icpmEncounterpoviderIn)

    val provXref = broadcast(loadedDependencies("ZH_PROVIDER_MASTER_XREF")).as[zh_provider_master_xref]
    val patXref = loadedDependencies("PATIENT_MPI").as[patient_mpi]

    MapMasterIds.mapProviderIds(MapMasterIds.mapPatientIds(unionEncp.toDF, patXref.toDF, false), provXref.toDF(), "providerid", "mstrprovid")
  }
}
