package com.optum.oap.backend.etl.encgrps

import com.optum.oap.cdr.models.diag_ccs_encgrp
import com.optum.oap.sparkdataloader.QueryAndMetadata

object DIAG_CCS_ENCGRP extends QueryAndMetadata[diag_ccs_encgrp] {
  override def name: String = "DIAG_CCS_ENCGRP"

  override def partitions: Int = 32

  override def sparkSql: String =
    """
      |select distinct codetype
      |       ,mappeddiagnosis
      |       ,CUI,is_ambulatory
      |       ,cnt
      |from MAPDIAG
    """.stripMargin

  override def dependsOn: Set[String] = Set("MAPDIAG")
}