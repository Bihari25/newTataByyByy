package com.optum.oap.backend.etl.bpo.bpo_pyr_hedis_qme

import com.optum.oap.backend.cdrTempModel.{hedis_monthly_ecd_extract_qme, hedis_monthly_med_extract_qme}
import com.optum.oap.cdr.models.{denied_ind_rollup, pp_bpo_clinical_documentation, pp_bpo_medical_claims, pp_bpo_member_detail, pp_bpo_pharmacy_clinical}
import com.optum.oap.sparkdataloader.{RuntimeVariables, TableInfo, UserDefinedFunctionForDataLoader}
import org.apache.spark.sql.functions._
import org.apache.spark.sql.types.StringType
import org.apache.spark.sql.{DataFrame, SparkSession}

object HEDIS_MONTHLY_MED_EXTRACT_QME extends TableInfo[hedis_monthly_med_extract_qme] {

  override def dependsOn: Set[String] = Set("PP_BPO_MEMBER_DETAIL","DENIED_IND_ROLLUP","PP_BPO_MEDICAL_CLAIMS")

  override def name = "HEDIS_MONTHLY_MED_EXTRACT_QME"

  override def createDataFrame(sparkSession: SparkSession,
                               loadedDependencies: Map[String, DataFrame],
                               udfMap: Map[String, UserDefinedFunctionForDataLoader],
                               runtimeVariables: RuntimeVariables): DataFrame = {

      import sparkSession.implicits._

      val hedis_patients = loadedDependencies("PP_BPO_MEMBER_DETAIL").as[pp_bpo_member_detail]
      val denied_ind_rollup = broadcast(loadedDependencies("DENIED_IND_ROLLUP")).as[denied_ind_rollup]
      val pp_bpo_medical_claims= loadedDependencies("PP_BPO_MEDICAL_CLAIMS").as[pp_bpo_medical_claims]

      val denied= denied_ind_rollup.groupBy($"groupid", $"denied_flag").agg(max($"denied_ind_rollup").as("denied_ind_rollup")).select($"denied_flag", $"denied_ind_rollup").dropDuplicates(Seq("denied_flag"))

      val hedis_patients_final= hedis_patients.where($"lineofbusinessid".isNotNull && $"healthplansource" === lit("PAYER")).select($"memberid").distinct

      pp_bpo_medical_claims.alias("mc").join(hedis_patients_final.as("hp"), $"mc.MEMBERID" === $"hp.MEMBERID", "inner").join(denied.as("dr"), $"mc.DENIEDFLAG" === $"dr.DENIED_FLAG", "left").where($"mc.healthplansource" === lit("PAYER")).select(
          $"mc.memberid".as("MemberID"),
          $"CLAIMHEADER".as("ClaimHeaderID"),
          $"CLAIMLINE".as("ClaimLineID"),
          date_format($"SERVICEDATE", "yyyy-MM-dd").cast(StringType).as("ServiceDate"),
          date_format($"FROMDATE",  "yyyy-MM-dd").cast(StringType).as("FromDate"),
          date_format($"TODATE",  "yyyy-MM-dd").cast(StringType).as("ToDate"),
          $"SERVICEPROVIDERID".as("ServicingProviderID"),
          $"SPECIALTY".as("SpecialtyCode"),
          $"PLACEOFSERVICE".as("PlaceofServiceCode"),
          $"REVENUECODE".as("RevenueCode"),
          $"HCPCS_CODE".as("HCPCSCode"),
          $"CPT2_CODE".as("CPT2Code"),
          $"PROCEDURECODE".as("ProcedureCode"),
          $"PROCEDUREMODIFIER".as("ProcedureCodeModifier"),
          $"PROC_CODE_MODIFIER2".as("ProcedureCodeModifier2"),
          $"PROC_CODE_MODIFIER3".as("ProcedureCodeModifier3"),
          $"PROC_CODE_MODIFIER4".as("ProcedureCodeModifier4"),
          $"ICDCODETYPE".as("ICDCodeType"),
          $"ICDPROC1".as("ICDProcedureCode1"),
          $"ICDPROC2".as("ICDProcedureCode2"),
          $"ICDPROC3".as("ICDProcedureCode3"),
          $"ICDPROC4".as("ICDProcedureCode4"),
          $"ICDPROC5".as("ICDProcedureCode5"),
          $"ICDPROC6".as("ICDProcedureCode6"),
          $"ICD_PROC_7".as("ICDProcedureCode7"),
          $"ICD_PROC_8".as("ICDProcedureCode8"),
          $"ICD_PROC_9".as("ICDProcedureCode9"),
          $"ICD_PROC_10".as("ICDProcedureCode10"),
          $"ICD_PROC_11".as("ICDProcedureCode11"),
          $"ICD_PROC_12".as("ICDProcedureCode12"),
          $"ICD_PROC_13".as("ICDProcedureCode13"),
          $"ICD_PROC_14".as("ICDProcedureCode14"),
          $"ICD_PROC_15".as("ICDProcedureCode15"),
          $"ICD_PROC_16".as("ICDProcedureCode16"),
          $"ICD_PROC_17".as("ICDProcedureCode17"),
          $"ICD_PROC_18".as("ICDProcedureCode18"),
          $"ICD_PROC_19".as("ICDProcedureCode19"),
          $"ICD_PROC_20".as("ICDProcedureCode20"),
          $"ICD_PROC_21".as("ICDProcedureCode21"),
          $"ICD_PROC_22".as("ICDProcedureCode22"),
          $"ICD_PROC_23".as("ICDProcedureCode23"),
          $"ICD_PROC_24".as("ICDProcedureCode24"),
          $"ICD_PROC_25".as("ICDProcedureCode25"),
          $"ICDDIAG1".as("ICDDiagnosisCode1"),
          $"ICDDIAG2".as("ICDDiagnosisCode2"),
          $"ICDDIAG3".as("ICDDiagnosisCode3"),
          $"ICDDIAG4".as("ICDDiagnosisCode4"),
          $"ICDDIAG5".as("ICDDiagnosisCode5"),
          $"ICDDIAG6".as("ICDDiagnosisCode6"),
          $"ICDDIAG7".as("ICDDiagnosisCode7"),
          $"ICDDIAG8".as("ICDDiagnosisCode8"),
          $"ICDDIAG9".as("ICDDiagnosisCode9"),
          $"ICDDIAG10".as("ICDDiagnosisCode10"),
          $"ICD_DIAG_11".as("ICDDiagnosisCode11"),
          $"ICD_DIAG_12".as("ICDDiagnosisCode12"),
          $"ICD_DIAG_13".as("ICDDiagnosisCode13"),
          $"ICD_DIAG_14".as("ICDDiagnosisCode14"),
          $"ICD_DIAG_15".as("ICDDiagnosisCode15"),
          $"ICD_DIAG_16".as("ICDDiagnosisCode16"),
          $"ICD_DIAG_17".as("ICDDiagnosisCode17"),
          $"ICD_DIAG_18".as("ICDDiagnosisCode18"),
          $"ICD_DIAG_19".as("ICDDiagnosisCode19"),
          $"ICD_DIAG_20".as("ICDDiagnosisCode20"),
          $"ICD_DIAG_21".as("ICDDiagnosisCode21"),
          $"ICD_DIAG_22".as("ICDDiagnosisCode22"),
          $"ICD_DIAG_23".as("ICDDiagnosisCode23"),
          $"ICD_DIAG_24".as("ICDDiagnosisCode24"),
          $"ICD_DIAG_25".as("ICDDiagnosisCode25"),
          $"DRG".as("DiagnosisRelatedGroupCode"),
          $"DRGGROUPER".as("DiagnosisRelatedGroupGrouper"),
          $"DISCHARGESTATUS".as("DischargeStatusCode"),
          $"mc.MAPSOURCE".as("MapSource"),
          $"mc.HEALTHPLANSOURCE".as("HealthPlanSource"),
          when(coalesce($"dr.DENIED_IND_ROLLUP", $"mc.DENIEDFLAG").isin("Y","Yes","YES","1"), lit("Y")).otherwise(lit("N")).as("IsDenied"),
          $"TYPEOFBILL".as("TypeofBillCode"),
          $"COVERED_DAYS".cast(StringType).as("CoveredDays")
      )
  }

}
