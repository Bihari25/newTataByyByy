package com.optum.oap.backend.etl.common

import com.optum.oap.backend.etl.common.CleanName.cleanPersonName
import com.optum.oap.sparkdataloader.UserDefinedFunctionForDataLoader
import org.apache.spark.sql.SparkSession
import org.apache.spark.sql.functions.udf

object EscapeSqlLikeString extends UserDefinedFunctionForDataLoader {

 val specialChars : List[String] = List("{","}","[","]","(",")", ".")

 val escapeString = udf {
  inStr: String => {
   var escapedString = inStr
   for (s <- specialChars) {
     escapedString = escapedString.replace(s, "\\" + s)
   }
  escapedString
  }
 }


 override def registerMe(sparkSession: SparkSession): Unit = {
  sparkSession.udf.register(name, escapeString)
 }

 override def name: String = "EscapeSqlLikeString"

}
