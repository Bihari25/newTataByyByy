package com.optum.oap.backend.etl.enrichment

import com.optum.oap.cdr.models.{int_claim_prov, int_claim_member, int_claim_pharm, int_claim_labresult, prov_spec}
import com.optum.oap.sparkdataloader.{RuntimeVariables, TableInfo, UserDefinedFunctionForDataLoader}
import org.apache.spark.sql.functions._
import org.apache.spark.sql.expressions.Window
import org.apache.spark.sql.types.DataTypes
import org.apache.spark.sql.{DataFrame, SparkSession}
import org.slf4j.LoggerFactory

object ICPM_PROV_SPEC extends TableInfo[prov_spec] {

  private val log = LoggerFactory.getLogger(this.getClass)

  override def dependsOn = Set("INT_CLAIM_PROV", "INT_CLAIM_MEDICAL", "INT_CLAIM_MEMBER", "INT_CLAIM_PHARM",
    "INT_CLAIM_LABRESULT")

  override def name = "ICPM_PROV_SPEC"

  override def createDataFrame(sparkSession: SparkSession,
                               loadedDependencies: Map[String, DataFrame],
                               udfMap: Map[String, UserDefinedFunctionForDataLoader],
                               runtimeVariables: RuntimeVariables): DataFrame = {
    import sparkSession.implicits._

    val intClaimProvIn = loadedDependencies("INT_CLAIM_PROV").as[int_claim_prov]

    val intClaimMedicalIn = loadedDependencies("INT_CLAIM_MEDICAL")

    val intClaimMemberIn = loadedDependencies("INT_CLAIM_MEMBER").as[int_claim_member]

    val intClaimPharmIn = loadedDependencies("INT_CLAIM_PHARM").as[int_claim_pharm]

    val intClaimLabresultIn = loadedDependencies("INT_CLAIM_LABRESULT").as[int_claim_labresult]

    val srcIntClaimProv = intClaimProvIn.select($"groupid",
        $"client_ds_id",
        $"prov_id".as("localproviderid"),
        expr("stack(2, prov_spclty_cd, 1 , prov_sec_spclty_cd, 2) as (localspecialtycode, local_code_order)"),
        lit("IntClaimProv").as("localcodesource"),
        $"update_dt".as("lastupdatedate"),
        lit(1).as("source")
      ).filter($"localspecialtycode".isNotNull)

    val srcIntClaimMedical = intClaimMedicalIn.select($"groupid",
        $"client_ds_id",
        expr("stack(4, admit_prov_id, admit_prov_spclty_cd, 'ADMIT', " +
          "attnd_prov_id, attnd_prov_spclty_cd, 'ATTND', " +
          "billing_prov_id, billing_prov_spclty_cd, 'BILL', " +
          "servicing_prov_id, servicing_prov_spclty_cd, 'SERV') as (localproviderid, localspecialtycode, srcdata)"),
        lit(null).cast(DataTypes.IntegerType).as("local_code_order"),
        lit("intClaimMedical").as("localcodesource"),
        $"service_date".as("lastupdatedate"),
        lit(2).as("source")
      ).filter($"localspecialtycode".isNotNull).drop($"srcdata")

    val srcIntClaimMember = intClaimMemberIn.filter($"pcp_spclty_cd".isNotNull)
      .select($"groupid",
        $"client_ds_id",
        $"pcp_id".as("localproviderid"),
        $"pcp_spclty_cd".as("localspecialtycode"),
        lit(null).cast(DataTypes.IntegerType).as("local_code_order"),
        lit("intClaimMember").as("localcodesource"),
        coalesce($"member_eff_date", to_date($"eligibile_member_month", "yyyyMM")).as("lastupdatedate"),
        lit(3).as("source")
      )

    val srcIntClaimPharm = intClaimPharmIn.select($"groupid",
      $"client_ds_id",
      expr("stack(2, pcp_id, pcp_spclty_cd, 'PCP', " +
        "presc_prov_id, presc_prov_spclty_cd, 'PRESC') as (localproviderid, localspecialtycode, srcdata)"),
      lit(null).cast(DataTypes.IntegerType).as("local_code_order"),
      lit("intClaimPharm").as("localcodesource"),
      $"service_date".as("lastupdatedate"),
      lit(4).as("source")
    ).filter($"localspecialtycode".isNotNull).drop($"srcdata")

    val srcIntClaimLabresult = intClaimLabresultIn.select($"groupid",
      $"client_ds_id",
      expr("stack(2, pcp_id, pcp_spclty_cd, 'PCP', " +
        "ordering_prov_id, ordering_prov_spclty_cd, 'ORD') as (localproviderid, localspecialtycode, srcdata)"),
      lit(null).cast(DataTypes.IntegerType).as("local_code_order"),
      lit("intClaimLabres").as("localcodesource"),
      $"result_date".as("lastupdatedate"),
      lit(5).as("source")
    ).filter($"localspecialtycode".isNotNull).drop($"srcdata")

    val cdrFeProvSpec = srcIntClaimProv.unionByName(srcIntClaimMedical).unionByName(srcIntClaimMember)
      .unionByName(srcIntClaimPharm).unionByName(srcIntClaimLabresult)

    val window = Window.partitionBy($"ps.client_ds_id", $"ps.localproviderid", $"ps.local_code_order",
      $"ps.localspecialtycode").orderBy($"ps.source", $"ps.lastupdatedate".desc_nulls_last)

    cdrFeProvSpec.as("ps")
      .withColumn("rank", row_number.over(window))
      .filter($"rank" === 1 && $"localproviderid".isNotNull)
      .select($"groupid",
        $"client_ds_id",
        $"localproviderid",
        $"local_code_order",
        $"localspecialtycode",
        $"localcodesource",
        lit(null).cast(DataTypes.StringType).as("mstrprovid")
      )
  }
}
