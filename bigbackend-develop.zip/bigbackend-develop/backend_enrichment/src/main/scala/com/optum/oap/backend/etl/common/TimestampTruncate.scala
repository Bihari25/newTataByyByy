package com.optum.oap.backend.etl.common

import java.sql.Timestamp
import java.time.temporal.ChronoUnit

import com.optum.oap.sparkdataloader.UserDefinedFunctionForDataLoader
import org.apache.spark.sql.SparkSession
import org.apache.spark.sql.expressions.UserDefinedFunction
import org.apache.spark.sql.functions.udf

object TimestampTruncate extends UserDefinedFunctionForDataLoader {
	val truncate: UserDefinedFunction = udf {
		(truncateTo: String, ts: Timestamp) => {
			if (ts == null) {
				null
			} else {
				val ldt = ts.toLocalDateTime

				Timestamp.valueOf(Option(truncateTo).map(_.toUpperCase) match {
					case Some("DD") | Some("DAY") => ldt.truncatedTo(ChronoUnit.DAYS)
					case Some("HOUR") => ldt.truncatedTo(ChronoUnit.HOURS)
					case Some("MIN") | Some("MINUTE") => ldt.truncatedTo(ChronoUnit.MINUTES)
					case _ => throw new IllegalArgumentException(s"Unknown argument for TimestampTruncate: $truncateTo")
				})
			}
		}
	}

	override def name: String = "TimestampTruncate"

	override def registerMe(sparkSession: SparkSession): Unit = {
		sparkSession.udf.register(name, truncate)
	}
}
