package com.optum.oap.backend.etl.common

import com.optum.oap.sparkdataloader.UserDefinedFunctionForDataLoader
import org.apache.spark.sql.SparkSession
import org.apache.spark.sql.expressions.UserDefinedFunction
import org.apache.spark.sql.functions.udf

/**
  *
  * Copyright 2019 Optum Analytics
  *
  * Date: 5/9/19
  *
  * Creator: bpokharel(bishu)
  */
object NormalizeNDC extends UserDefinedFunctionForDataLoader {

  /**
    * Validate / Format localNDC values into standard NDC 11 character, no dash format
    */
  val normalize: UserDefinedFunction = udf {
    str: String => {

      if (str == null || str.length > 13) {
        null
    } else {
        val normal_ndc = str.replaceAll("[^-0-9]", "")
        val ndc: Option[String] = {
          // if 11 digits, no dashes, already good, just return it
          if (str.equals(normal_ndc) && !str.contains("-") && str.length == 11) {
            //in the oracle implementation, there is extra logic (replace(v_normal_ndc,'-');) but looks it is redundant and thus not needed
            Option(normal_ndc)
          } else if (normal_ndc.replaceAll("[^-]", "").length == 2) {

            val substr1 = ("^[0-9]{4,5}".r findFirstIn normal_ndc).orNull
            val substr2 = ("-[0-9]{3,4}-".r findFirstIn normal_ndc).orNull
            val substr3 = ("-([0-9]{1,2})$".r findFirstIn normal_ndc).orNull
            if (substr1 != null && substr2 != null && substr3 != null) {

              val lpad1 = substr1.reverse.padTo(5, '0').reverse // work around for leftpad

              val lpad2 = substr2.replaceAll("-", "").reverse.padTo(4, '0').reverse
              val lpad3 = substr3.replaceAll("-", "").reverse.padTo(2, '0').reverse

              Option(lpad1 + lpad2 + lpad3)
            } else {
              None
            }
          } else {
            Option(normal_ndc)
          }
        }
        if (ndc.isDefined && (ndc.get.length == 10 || ndc.get.length == 11)) {
          ndc.get.reverse.padTo(11, 0).reverse.mkString
        } else {
          null
        }
      }
    }
  }

  override def name: String = "NormalizeNdc"

  override def registerMe(sparkSession: SparkSession): Unit = {
    sparkSession.udf.register(name, normalize)
  }
}
