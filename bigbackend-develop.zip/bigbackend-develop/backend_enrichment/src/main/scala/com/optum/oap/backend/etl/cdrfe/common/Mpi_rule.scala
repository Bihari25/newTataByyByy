package com.optum.oap.backend.etl.cdrfe.common

import com.optum.oap.backend.loader.EnrichmentRunTimeVariables
import com.optum.oap.cdr.models.{client_attribute, mpi_grp_rule, mpi_hum_rule}
import com.optum.oap.sparkdataloader.{RuntimeVariables, TableInfo, UserDefinedFunctionForDataLoader}
import org.apache.spark.sql.functions.{broadcast, coalesce, lit}
import org.apache.spark.sql.types.DataTypes
import org.apache.spark.sql.{DataFrame, SparkSession}

trait Mpi_rule {
  self: TableInfo[_ <: Product] =>

  override val dependsOn: Set[String] = Set(
    "MPI_HUM_RULE",
    "CLIENT_ATTRIBUTE",
    "MPI_GRP_RULE"
  )

  override def createDF(sparkSession: SparkSession,
                        loadedDependencies: Map[String, DataFrame],
                        udfMap: Map[String, UserDefinedFunctionForDataLoader],
                        runtimeVariables: RuntimeVariables): DataFrame = {
    implicit val spark = sparkSession


    val df = self.createDataFrame(sparkSession, loadedDependencies, udfMap, runtimeVariables)

    import sparkSession.implicits._

    val mpiHumRule = broadcast(loadedDependencies("MPI_HUM_RULE").as[mpi_hum_rule])
    val clientAttribute = broadcast(loadedDependencies("CLIENT_ATTRIBUTE").as[client_attribute])
    val mpiGrpRule = broadcast(loadedDependencies("MPI_GRP_RULE").as[mpi_grp_rule])

    val joinedDataset = mpiHumRule.as("b")
      .crossJoin(clientAttribute.as("c").where($"c.is_retired" === lit("No")))
      .select($"c.client_id", $"b.*")

    joinedDataset.as("a")
      .join(mpiGrpRule.as("d"), $"a.rule_nbr" === $"d.rule_nbr" && $"a.client_id" === $"d.groupid", "full_outer")
      .select(
        coalesce($"client_id", $"d.groupid").as("groupid"),
        coalesce($"a.rule_nbr", $"d.rule_nbr").as("rule_nbr"),
        coalesce($"d.rule_data_table", $"a.rule_data_table").as("rule_data_table"),
        coalesce($"d.rule_fields", $"a.rule_fields").as("rule_fields"),
        coalesce($"d.uniq_fields", $"a.uniq_fields").as("uniq_fields"),
        coalesce($"d.score", $"a.score").cast(DataTypes.DoubleType).as("score")
      )
      .where($"score" > 0)
  }

}
