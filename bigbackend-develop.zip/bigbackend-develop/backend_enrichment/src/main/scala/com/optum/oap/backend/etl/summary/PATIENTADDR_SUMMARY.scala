package com.optum.oap.backend.etl.summary

import com.optum.oap.backend.etl.common.Functions
import com.optum.oap.cdr.models.patientaddr_summary
import com.optum.oap.sparkdataloader.{RuntimeVariables, TableInfo, UserDefinedFunctionForDataLoader}
import org.apache.spark.sql.expressions.Window
import org.apache.spark.sql.functions._
import org.apache.spark.sql.types.IntegerType
import org.apache.spark.sql.{DataFrame, SparkSession}
import org.slf4j.LoggerFactory

object PATIENTADDR_SUMMARY extends TableInfo[patientaddr_summary] {
  val log = LoggerFactory.getLogger(this.getClass)
  override def dependsOn =  Set("PATIENTADDR","MAP_CONTACT_SRC")

  override def name = "PATIENTADDR_SUMMARY"

  override def saveDataFrameToParquet: Boolean = true
  override def partitions: Int = 64
  override def skipTable: Boolean = false
  override def ignoreExtraColumnsInDataFrame: Boolean = false

  override def createDataFrame (sparkSession: SparkSession,
                                loadedDependencies: Map[String, DataFrame],
                                udfMap: Map[String, UserDefinedFunctionForDataLoader],
                                runtimeVariables: RuntimeVariables): DataFrame = {

    val df_pat_add = loadedDependencies("PATIENTADDR")
    val df_map =loadedDependencies("MAP_CONTACT_SRC")

    val dft = df_pat_add.join(broadcast(df_map), Seq("groupid", "client_ds_id"), "inner")
      .withColumn("zipcode_orig", df_pat_add("zipcode"))

    val df1 = Functions.standardizeZip("zipcode", dft, true)

    //DATA-9029 get most relevant row by: non-null essential address elements (line1,city,state) then priority/cdsid/datasrc and as tie-breaker order by all elements favouring non-null
    val partitionWindow = Window.partitionBy("grp_mpi").orderBy(
      when(df1("address_line1").isNotNull, lit("0")).otherwise(lit("1")),
      when(df1("city").isNotNull, lit("0")).otherwise(lit("1")),
      when(df1("state").isNotNull, lit("0")).otherwise(lit("1")),
      df1("priority_order").asc, df1("address_date").desc, df1("client_ds_id"), df1("datasrc"),
      df1("address_line1").desc_nulls_last, df1("address_line2").desc_nulls_last, df1("city").desc_nulls_last, df1("state").desc_nulls_last, df1("zipcode_orig").desc_nulls_last
    )

    val df2 = df1.withColumn("ROWNUMBER", row_number().over(partitionWindow))
      .withColumn("CNT", concat_ws("", lower(df1("address_line1")), lower(df1("address_line2")), lower(df1("city")), lower(df1("state")), df1("zipcode_orig")))

    val df_count = df2.groupBy(df2("grp_mpi"), df2("client_ds_id"), df2("address_date"))
      .agg(countDistinct(df2("CNT")).cast(IntegerType).as("multiple_values"))
        .withColumnRenamed("grp_mpi","count_grp_mpi")
        .withColumnRenamed("client_ds_id","count_client_ds_id")
        .withColumnRenamed("address_date","count_address_date")

    val df = df2.join(df_count, df2.col("grp_mpi") <=> df_count.col("count_grp_mpi") and
      df2.col("client_ds_id") === df_count.col("count_client_ds_id") and
      df2.col("address_date") === df_count.col("count_address_date") , joinType = "inner")
      .filter("rownumber = 1")
      .withColumnRenamed("address_date", "record_date")
      .select("groupid", "client_ds_id", "grp_mpi", "address_type", "address_line1", "address_line2", "city", "state", "zipcode", "record_date", "multiple_values", "address_latitude", "address_longitude")

    df
  }

}
