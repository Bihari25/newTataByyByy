package com.optum.oap.backend.etl.bpo


import com.optum.oap.backend.cdrTempModel.{temp_bpo_prov_affil_spans, temp_bpo_provider_detail}
import com.optum.oap.backend.etl.common.Functions._
import com.optum.oap.backend.etl.common.IsSafeToNumber
import com.optum.oap.backend.loader.EnrichmentRunTimeVariables
import com.optum.oap.cdr.models._
import com.optum.oap.sparkdataloader.{RuntimeVariables, TableInfo, UserDefinedFunctionForDataLoader}
import org.apache.spark.sql.expressions.Window
import org.apache.spark.sql.functions._
import org.apache.spark.sql.{DataFrame, SparkSession}

object TEMP_BPO_PROV_AFFIL_SPANS extends TableInfo[temp_bpo_prov_affil_spans] {
  override def name = "TEMP_BPO_PROV_AFFIL_SPANS"

  override def dependsOn: Set[String] = Set("PP_BPO_MEMBER_DETAIL", "PROV_AFFIL", "TEMP_BPO_PROVIDER_DETAIL")

  override def createDataFrame(sparkSession: SparkSession, loadedDependencies: Map[String, DataFrame], udfMap: Map[String, UserDefinedFunctionForDataLoader], runtimeVariables: RuntimeVariables): DataFrame = {
    import sparkSession.implicits._

    val ppBpoMemberDetail = loadedDependencies("PP_BPO_MEMBER_DETAIL").as[pp_bpo_member_detail]
    val tempProvAffil = loadedDependencies("PROV_AFFIL").as[prov_affil]
    val tempBpoProviderDetail = loadedDependencies("TEMP_BPO_PROVIDER_DETAIL").as[temp_bpo_provider_detail]
    val grpid = EnrichmentRunTimeVariables(runtimeVariables).clientId

    val dflt_dates = ppBpoMemberDetail
      .where($"healthplansource" === lit("PAYER"))
      .select(to_timestamp(trunc(min($"effectivedate"), "MONTH")).as("eff_date"),
        to_timestamp(last_day(max($"enddate"))).as("end_date"))

    val spanWindow = Window.partitionBy($"pa.master_hgprovid")

    val intermediateDf = tempProvAffil.as("pa")
      .crossJoin(dflt_dates.as("dd"))
      .where($"pa.eff_date" <= coalesce($"pa.end_date", $"dd.end_date"))
      .join(tempBpoProviderDetail.as("tmp"), when(IsSafeToNumber.isSafeToNumber($"tmp.providerid"), $"tmp.providerid")
        .otherwise(null) === $"pa.master_hgprovid", "inner")
      .select(
        $"pa.master_hgprovid",
        to_timestamp($"dd.eff_date").as("init_date"),
        to_timestamp($"pa.eff_date").as("eff_date"),
        to_timestamp(coalesce($"pa.end_date", $"dd.end_date")).as("end_date"),
        max(coalesce($"pa.end_date", $"dd.end_date")).over(spanWindow).as("max_end_date")
      ).distinct()

    val dateList = List("init_date", "eff_date", "end_date")

    val allDates = intermediateDf
      .select($"master_hgprovid",
        expr("stack(4,'init_date', init_date, 'eff_date', eff_date, 'end_date', end_date, 'next_start_date', end_date) as (date_type, date_value) "))
      .where($"date_type".isin(dateList: _*) || ($"date_type" === lit("next_start_date") && month(to_date($"date_value")) < month(to_date($"max_end_date"))))
      .select(
        $"master_hgprovid",
        when($"date_type" === lit("next_start_date"), to_timestamp(date_add(last_day($"date_value"), 1)))
          .otherwise(to_timestamp(trunc($"date_value", "MONTH"))).as("date_value")
      ).distinct()

    val spanWindowDate = Window.partitionBy($"al.master_hgprovid").orderBy($"al.date_value")

    val allSpans = allDates.as("al")
      .select($"al.master_hgprovid",
        $"al.date_value".as("start_date"),
        to_timestamp(coalesce(add_months(last_day(lead($"al.date_value", 1).over(spanWindowDate)), -1), last_day($"al.date_value"))).as("end_date"))

    val intermediateRsltSet1 = allSpans.as("sp")
      .crossJoin(dflt_dates.as("dd"))
      .join(tempProvAffil.as("pa"), $"pa.master_hgprovid" === $"sp.master_hgprovid"
        && $"pa.eff_date" <= coalesce($"pa.end_date", current_date())
        && $"pa.eff_date".between($"sp.start_date", $"sp.end_date"), "left")
      .select(
        $"sp.master_hgprovid",
        $"sp.start_date",
        $"sp.end_date",
        $"pa.prov_affil_id".as("provaffiliationid"),
        $"pa.end_date".as("enddate"),
        $"pa.eff_date".as("effdate"),
        $"pa.master_hgprovid".as("pa_master_hgprovid"),
        $"pa.primary_span".as("primary_span")
      )

    val intermediateRsltSet2 = allSpans.as("sp")
      .crossJoin(dflt_dates.as("dd"))
      .join(tempProvAffil.as("pa"), $"pa.master_hgprovid" === $"sp.master_hgprovid" && $"pa.eff_date" <= coalesce($"pa.end_date", current_date()) && coalesce($"pa.end_date", $"dd.end_date").between($"sp.start_date", $"sp.end_date"), "left")
      .select(
        $"sp.master_hgprovid",
        $"sp.start_date",
        $"sp.end_date",
        $"pa.prov_affil_id".as("provaffiliationid"),
        $"pa.end_date".as("enddate"),
        $"pa.eff_date".as("effdate"),
        $"pa.master_hgprovid".as("pa_master_hgprovid"),
        $"pa.primary_span".as("primary_span")
      )

    val intermediateRsltSet3 = allSpans.as("sp")
      .crossJoin(dflt_dates.as("dd"))
      .join(tempProvAffil.as("pa"), $"pa.master_hgprovid" === $"sp.master_hgprovid" && $"pa.eff_date" <= coalesce($"pa.end_date", current_date) && $"sp.start_date" > $"pa.eff_date" && $"sp.end_date" <= coalesce($"pa.end_date", $"dd.end_date"), "left")
      .select(
        $"sp.master_hgprovid",
        $"sp.start_date",
        $"sp.end_date",
        $"pa.prov_affil_id".as("provaffiliationid"),
        $"pa.end_date".as("enddate"),
        $"pa.eff_date".as("effdate"),
        $"pa.master_hgprovid".as("pa_master_hgprovid"),
        $"pa.primary_span".as("primary_span")
      )

    val resultSetWindow = Window.partitionBy($"master_hgprovid", $"start_date", $"end_date")
      .orderBy($"pa_master_hgprovid".desc_nulls_last,
        $"enddate".desc_nulls_first,
        $"effdate".desc,
        when(upper($"primary_span") === lit("Y"), lit(1))
        .when(upper($"primary_span") === lit("N"), lit(3))
        .otherwise(lit(2)),
        $"provaffiliationid".desc_nulls_last
      )

    val intermediateRsltSet4 = intermediateRsltSet1
      .union(intermediateRsltSet2)
      .union(intermediateRsltSet3)
      .withColumn("rw_id", row_number().over(resultSetWindow))
      .where($"rw_id" === lit(1))
      .select(
        lit(grpid).as("groupid"),
        $"master_hgprovid",
        $"start_date",
        $"end_date",
        $"provaffiliationid"
      )

    val windowedRsltSet = intermediateRsltSet4
      .groupBy($"master_hgprovid")
      .agg(
        collectListFromType[temp_bpo_prov_affil_spans](sparkSession).as("affilSpansList")
      )
      .as[AffilSpansPerHgProvId]
      .flatMap(affilSpansDoc => {
        val sortedByStartDate = affilSpansDoc.affilSpansList.sortWith {
          case (left, right) =>
            if(left.start_date == null) {
               false
            } else if(right.start_date == null) {
              true
            } else {
              left.start_date.before(right.start_date)
            }

        }

        val window = sortedByStartDate.foldLeft((Option.empty[temp_bpo_prov_affil_spans], Seq.empty[temp_bpo_prov_affil_spans])) {
          case ((prevOption, finished), current) =>
            if (prevOption.isEmpty) {
              (Some(current), finished)
            } else {
              val prev = prevOption.get

              if (current.provaffiliationid == prev.provaffiliationid) {
                (Some(prev.copy(end_date = current.end_date)), finished)
              } else {
                (Some(current), finished :+ prev)
              }
            }
        }

        val result = window._1 match {
          case Some(lastWindow) => window._2 :+ lastWindow
          case None => window._2
        }

        result
      })

    windowedRsltSet.select(
      $"master_hgprovid",
      $"groupid", $"start_date", $"end_date", $"provaffiliationid"
    ).distinct


  }
}

case class AffilSpansPerHgProvId(master_hgprovid: String, affilSpansList: Seq[temp_bpo_prov_affil_spans])