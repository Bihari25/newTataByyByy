package com.optum.oap.backend.etl.summary

import com.optum.oap.cdr.models.zh_prov_contact_summary
import com.optum.oap.sparkdataloader.{RuntimeVariables, TableInfo, UserDefinedFunctionForDataLoader}
import org.apache.spark.sql.expressions.Window
import org.apache.spark.sql.functions._
import org.apache.spark.sql.types.IntegerType
import org.apache.spark.sql.{DataFrame, SparkSession}
import org.slf4j.LoggerFactory


object  ZH_PROV_CONTACT_SUMMARY extends TableInfo[zh_prov_contact_summary] {
  val log = LoggerFactory.getLogger(this.getClass)
  override def dependsOn =  Set(
 "ZH_PROVIDER_CONTACT","ZH_PROVIDER_MASTER", "REF_CMSNPI", "REF_PRIMARYSPECIALTY"
    ,"MAP_PROVIDER_TAXONOMY","ZO_SPECIALTY","MAP_CONTACT_SRC"
  )

  override def name = "ZH_PROV_CONTACT_SUMMARY"

  override def saveDataFrameToParquet: Boolean = true
  override def partitions: Int = 32
  override def skipTable: Boolean = false
  override def ignoreExtraColumnsInDataFrame: Boolean = false

  override def createDataFrame (sparkSession: SparkSession,
                                loadedDependencies: Map[String, DataFrame],
                                udfMap: Map[String, UserDefinedFunctionForDataLoader],
                                runtimeVariables: RuntimeVariables): DataFrame = {

    val ZPC_DF = loadedDependencies("ZH_PROVIDER_CONTACT")

    val ZPM_DF = loadedDependencies("ZH_PROVIDER_MASTER")
      .select("npi", "LOCALPRIMARYSPECIALTY", "master_hgprovid")

    val cmsDF = loadedDependencies("REF_CMSNPI")
      .select("npi", "PROV_FIRST_LINE_BUS_PRAC_LOC", "PROV_BUS_PRAC_LOC_ADDR_CITY", "PROV_BUS_PRAC_LOC_ADDR_STATE"
        , "PROV_BUS_PRAC_LOC_ADDR_POSTAL", "PROV_BUS_PRAC_LOC_ADDR_TEL")


    val RDP_DF = loadedDependencies("REF_PRIMARYSPECIALTY")
      .select("npi", "Primarycode")

    val MPT_DF = broadcast(
      loadedDependencies("MAP_PROVIDER_TAXONOMY")
      .select("Taxonomy_Code", "SPECIALTY_CUI")
    )

    val ZOS_DF = broadcast(
      loadedDependencies("ZO_SPECIALTY")
      .select("Hts_Cui", "Cc_Code", "cc_name")
    )

    val MCS_DF = broadcast(
      loadedDependencies("MAP_CONTACT_SRC")
      .select("priority_order", "groupid", "client_ds_id")
    )

    val joinedDF =
      ZPC_DF
        .join(ZPM_DF, Seq("master_hgprovid"), "left_outer")
        .join(cmsDF, Seq("npi"), "left_outer")
        .join(RDP_DF, Seq("npi"), "left_outer")
        .join(MPT_DF, MPT_DF("Taxonomy_Code") === coalesce(ZPM_DF("LOCALPRIMARYSPECIALTY"), RDP_DF("Primarycode")), "left_outer")
        .join(ZOS_DF, ZOS_DF("Hts_Cui") === MPT_DF("specialty_cui"), "left_outer")
        .join(MCS_DF, Seq("groupid", "client_ds_id"), "left_outer")

    val df1 = joinedDF
      .withColumn("ADDRESS_LINE1", coalesce(joinedDF("address_line1"), joinedDF("PROV_FIRST_LINE_BUS_PRAC_LOC")))
      .withColumn("CITY", coalesce(joinedDF("CITY"), joinedDF("PROV_BUS_PRAC_LOC_ADDR_CITY")))
      .withColumn("STATE", coalesce(joinedDF("STATE"), joinedDF("PROV_BUS_PRAC_LOC_ADDR_STATE")))
      .withColumn("ZIPCODE", coalesce(joinedDF("ZIPCODE"), joinedDF("PROV_BUS_PRAC_LOC_ADDR_POSTAL")))
      .withColumn("WORK_PHONE", coalesce(joinedDF("WORK_PHONE"), joinedDF("PROV_BUS_PRAC_LOC_ADDR_TEL")))
      .withColumn("primary_specialty", coalesce(joinedDF("LOCALPRIMARYSPECIALTY"), joinedDF("Primarycode")))

      .withColumnRenamed("Cc_Code", "specialty_code")
      .withColumnRenamed("cc_name", "specialty_name")

      .withColumn("MAPPED_CONTACT_TYPE", coalesce(joinedDF("MAPPED_CONTACT_TYPE"), lit("CH003203")))

    val group = Window.partitionBy(df1("groupid"), df1("masteR_hgprovid"), df1("MAPPED_CONTACT_TYPE"))
      .orderBy(df1("groupid"), df1("masteR_hgprovid"), df1("MAPPED_CONTACT_TYPE"),
        df1("priority_order").asc, df1("update_date").desc)

    val df2 = df1.withColumn("rn", row_number.over(group))
    val df3 = df2.filter(" rn = 1 ")
    df3.select("groupid", "master_hgprovid", "npi", "specialty_code", "specialty_name",
      "ADDRESS_LINE1", "ADDRESS_LINE2", "city", "state", "zipcode", "work_phone",
      "email_Address", "local_contact_type", "mapped_contact_type", "address_latitude", "address_longitude")
      .withColumn("client_ds_id_addr", lit(null).cast(IntegerType))
      .withColumn("client_ds_id_email", lit(null).cast(IntegerType))
      .withColumn("client_ds_id_phone", lit(null).cast(IntegerType))
  }
}