package com.optum.oap.backend.etl.enrichment

import com.optum.oap.backend.loader.EnrichmentRunTimeVariables
import com.optum.oap.cdr.models.{denied_ind_rollup, int_claim_pharm, map_denied_ind}
import com.optum.oap.sparkdataloader.{RuntimeVariables, TableInfo, UserDefinedFunctionForDataLoader}
import org.apache.spark.sql.expressions.Window
import org.apache.spark.sql.functions.{coalesce, lit, _}
import org.apache.spark.sql.types._
import org.apache.spark.sql.{DataFrame, SparkSession}
import org.slf4j.LoggerFactory

object DENIED_IND_ROLLUP extends TableInfo[denied_ind_rollup] {

  private val log = LoggerFactory.getLogger(this.getClass)

  override def dependsOn = Set("CDR_FE_DENIED_IND_ROLLUP", "INT_CLAIM_MEDICAL", "INT_CLAIM_PHARM", "MAP_DENIED_IND")

  override def name = "DENIED_IND_ROLLUP"

  override def partitions: Int = 32

  override def createDataFrame(sparkSession: SparkSession,
                               loadedDependencies: Map[String, DataFrame],
                               udfMap: Map[String, UserDefinedFunctionForDataLoader],
                               runtimeVariables: RuntimeVariables): DataFrame = {

    import sparkSession.implicits._

    val deniedIndRollup = loadedDependencies("CDR_FE_DENIED_IND_ROLLUP").as[denied_ind_rollup]
    val intClaimMedical = loadedDependencies("INT_CLAIM_MEDICAL")
    val intClaimPharm = loadedDependencies("INT_CLAIM_PHARM").as[int_claim_pharm]
    val mapDeniedInd = broadcast(loadedDependencies("MAP_DENIED_IND")).as[map_denied_ind]

    val groupId = runtimeVariables.asInstanceOf[EnrichmentRunTimeVariables].clientId
    logger.warn(s"Running DENIED_IND_ROLLUP for group $groupId")


    //Origin Front end <DENIED_IND_ROLLUP> Table
    val cdrDeniedIndRollup = deniedIndRollup.select($"client_ds_id",
      $"datasrc",
      $"denied_ind_desc",
      $"denied_ind_rollup",
      $"denied_ind_lv1",
      $"denied_ind_lv1_desc",
      $"denied_ind_lv2",
      $"denied_ind_lv2_desc",
      $"denied_flag",
      $"groupid")

    //TAKING DISTINCT <denied_flag> from the <DENIED_IND_ROLLUP> TABLE #1
    val distinctDeniedIndRollup = cdrDeniedIndRollup.dropDuplicates("denied_flag")

    //SELECTING RECORDS OF <INT_CLAIM_MEDICAL> TABLE WHOSE <denied_flag> are not in <DENIED_IND_ROLLUP> TABLE
    val intClaimMedical1 = intClaimMedical.alias("icm").join(distinctDeniedIndRollup.alias("cdr"),
      $"icm.denied_flag" === $"cdr.denied_flag", "left")
      .select(
        $"icm.groupid"
        , $"icm.client_ds_id"
        , $"icm.denied_flag"
        , lit("int_claim_medical").cast(StringType).as("datasrc")
        , substring(concat(lit("UNDEFINED ("), $"icm.denied_flag",
          lit(")")), 1, 150).cast(StringType).as("denied_ind_desc")
        , $"cdr.denied_ind_lv2", $"cdr.denied_ind_lv2_desc"
        , $"cdr.denied_ind_lv1", $"cdr.denied_ind_lv1_desc", $"denied_ind_rollup")
      .where($"icm.denied_flag".isNotNull
        && length($"icm.denied_flag") <= 30
        && $"cdr.denied_flag".isNull)
      .groupBy($"groupid", $"icm.denied_flag", $"datasrc"
        , $"denied_ind_desc", $"denied_ind_rollup"
        , $"cdr.denied_ind_lv2", $"cdr.denied_ind_lv2_desc"
        , $"cdr.denied_ind_lv1", $"cdr.denied_ind_lv1_desc")
      .agg(min($"client_ds_id").as("client_ds_id"))

    //NOW UNION THE MISSING RECORDS FETCHED FROM <INT_CLAIM_MEDICAL> WITH <DENIED_IND_ROLLUP> TABLE
    val cdrDeniedIndRollup1 = cdrDeniedIndRollup.unionByName(intClaimMedical1)

    //TAKING DISTINCT <denied_flag> from the <DENIED_IND_ROLLUP> TABLE #2
    val distinctDeniedIndRollup1 = cdrDeniedIndRollup1.dropDuplicates("denied_flag")

    //SELECTING RECORDS OF <INT_CLAIM_PHARM> TABLE WHOSE <denied_flag> are not in <DENIED_IND_ROLLUP> TABLE
    val intClaimPharm1 = intClaimPharm.alias("icp").join(distinctDeniedIndRollup1.alias("cdr"),
      $"icp.denied_flag" === $"cdr.denied_flag", "left")
      .select(
        $"icp.groupid"
        , $"icp.client_ds_id"
        , $"icp.denied_flag"
        , lit("int_claim_pharm").cast(StringType).as("datasrc")
        , substring(concat(lit("UNDEFINED ("), $"icp.denied_flag",
          lit(")")), 1, 150).cast(StringType).as("denied_ind_desc")
        , $"cdr.denied_ind_lv2", $"cdr.denied_ind_lv2_desc"
        , $"cdr.denied_ind_lv1", $"cdr.denied_ind_lv1_desc", $"denied_ind_rollup")
      .where($"icp.denied_flag".isNotNull
        && length($"icp.denied_flag") <= 30
        && $"cdr.denied_flag".isNull)
      .groupBy($"groupid", $"icp.denied_flag", $"datasrc"
        , $"denied_ind_desc", $"denied_ind_rollup"
        , $"cdr.denied_ind_lv2", $"cdr.denied_ind_lv2_desc"
        , $"cdr.denied_ind_lv1", $"cdr.denied_ind_lv1_desc")
      .agg(min($"client_ds_id").as("client_ds_id"))

    //NOW UNION THE MISSING RECORDS FETCHED FROM <INT_CLAIM_PHARM> WITH <DENIED_IND_ROLLUP> TABLE
    val cdrDeniedIndRollup2 = cdrDeniedIndRollup1.unionByName(intClaimPharm1)

    //APPLYING ADDITIONAL TRANSFORMATIONS ON THE UNION
    val rollup = cdrDeniedIndRollup2.alias("cdr").join(mapDeniedInd.alias("mpi"),
      $"cdr.denied_flag" === $"mpi.localcode" && $"mpi.groupid" === lit(groupId), "left").
      select(
        $"cdr.groupid".as("groupid")
        , $"cdr.datasrc".as("datasrc")
        , $"cdr.client_ds_id".as("client_ds_id")
        , $"cdr.denied_flag".as("denied_flag")
        , substring(coalesce($"cdr.denied_ind_desc", concat(lit("UNDEFINED ("),
          $"cdr.denied_flag", lit(")"))), 1, 150).as("denied_ind_desc")
        , substring(coalesce($"cdr.denied_ind_lv2", concat(lit("3."), $"cdr.denied_flag")),
          1, 30).as("denied_ind_lv2")
        , substring(when($"cdr.denied_ind_lv2".isNull,
          coalesce($"cdr.denied_ind_desc",
            concat(lit("UNDEFINED ("), $"cdr.denied_flag", lit(")"))))
          .otherwise(coalesce($"cdr.denied_ind_lv2_desc",
            concat(lit("UNDEFINED ("), $"cdr.denied_ind_lv2", lit(")")))),
          1, 150).as("denied_ind_lv2_desc")
        , substring(coalesce($"cdr.denied_ind_lv1", when($"cdr.denied_ind_lv2".isNotNull,
          concat(lit("2."), $"cdr.denied_ind_lv2")).otherwise($"cdr.denied_ind_lv2"),
          concat(lit("3."), $"cdr.denied_flag")), 1, 30).as("denied_ind_lv1")
        , substring(when($"cdr.denied_ind_lv1".isNull, when($"cdr.denied_ind_lv2".isNull,
          coalesce($"cdr.denied_ind_desc", concat(lit("UNDEFINED ("), $"cdr.denied_flag", lit(")"))))
          .otherwise(coalesce($"cdr.denied_ind_lv2_desc",
            concat(lit("UNDEFINED ("), $"cdr.denied_ind_lv2", lit(")")))))
          .otherwise(coalesce($"cdr.denied_ind_lv1_desc",
            concat(lit("UNDEFINED ("), $"cdr.denied_ind_lv1", lit(")")))),
          1, 150).as("denied_ind_lv1_desc")
        , when($"cdr.denied_ind_rollup" === lit("0"), lit("N")).otherwise(
          when($"cdr.denied_ind_rollup" === lit("1"), lit("Y")).otherwise(
            when($"cdr.denied_ind_rollup".isNotNull, $"cdr.denied_ind_rollup").otherwise(
              lit("X")))).as("denied_ind_rollup")
        , row_number().over(Window.partitionBy($"cdr.denied_flag")
          .orderBy(
            when($"cdr.denied_ind_desc".isNotNull, lit(0)).otherwise(lit(1)),
            when($"cdr.denied_ind_lv2".isNotNull, lit(0)).otherwise(lit(1)),
            when($"cdr.denied_ind_lv1".isNotNull, lit(0)).otherwise(lit(1)),
            $"cdr.denied_ind_desc", $"cdr.denied_ind_lv2", $"cdr.denied_ind_lv1")).as("rn"))
      .where($"cdr.denied_flag".isNotNull &&
        length($"cdr.denied_flag") <= 30 &&
        $"rn" === lit(1)).drop($"rn")

    val rollup1 = rollup.alias("cdr").join(mapDeniedInd.alias("mpi"),
      $"cdr.denied_flag" === $"mpi.localcode" && $"mpi.groupid" === lit(groupId), "left").
      select(
        $"cdr.client_ds_id",
        $"cdr.datasrc",
        $"cdr.denied_ind_desc",
        $"cdr.denied_ind_lv1",
        $"cdr.denied_ind_lv1_desc",
        $"cdr.denied_ind_lv2",
        $"cdr.denied_ind_lv2_desc",
        $"cdr.denied_flag",
        $"cdr.groupid",
        when(!($"cdr.denied_ind_rollup".isin("Y", "N", "U")), $"mpi.mappedvalue").otherwise(
          when($"cdr.denied_ind_rollup" === lit("0"), lit("N")).otherwise(
            when($"cdr.denied_ind_rollup" === lit("1"), lit("Y")).otherwise(
              $"cdr.denied_ind_rollup"))).as("denied_ind_rollup"))

    rollup1.toDF()

  }
}
