
package com.optum.oap.backend.etl.encgrps

import com.optum.oap.backend.cdrTempModel.temp_ins_join_eeg
import com.optum.oap.sparkdataloader.QueryAndMetadata

object TEMP_INS_JOIN_EEG extends QueryAndMetadata[temp_ins_join_eeg] {
  override def name: String = "TEMP_INS_JOIN_EEG"

  override def partitions: Int = 64

  override def sparkSql: String =
    """
      |SELECT eeg.groupid,
      |eeg.encounter_grp_num,
      |eeg.client_ds_id,
      |eeg.grp_mpi,
      |eeg.encounterid,
      |eeg.patienttype,
      |eeg.encounteridtype,
      |TimestampTruncate('DAY', ce.arrivaltime) as arrivaltime,
      |TimestampTruncate('DAY', ce.admittime) as admittime,
      |TimestampTruncate('DAY', ce.dischargetime) as dischargetime,
      |TimestampTruncate('DAY', current_date()) as curr_date
      |FROM TEMP_VISIT_ENCTR CE
      |INNER JOIN ENCOUNTER_ENCOUNTER_GRP EEG
      |  ON CE.GRP_MPI = EEG.GRP_MPI AND CE.CLIENT_DS_ID = EEG.CLIENT_DS_ID AND CE.ENCOUNTERID = EEG.ENCOUNTERID
      |WHERE ENCOUNTERIDTYPE IN ('MASTER','ENCTR')
      """.stripMargin

  override def dependsOn: Set[String] = Set("ENCOUNTER_ENCOUNTER_GRP", "TEMP_VISIT_ENCTR")
}
