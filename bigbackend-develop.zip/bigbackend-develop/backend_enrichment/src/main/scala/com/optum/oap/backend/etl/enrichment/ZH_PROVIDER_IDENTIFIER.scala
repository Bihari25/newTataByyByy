package com.optum.oap.backend.etl.enrichment

import com.optum.oap.backend.etl.common.MapMasterIds
import com.optum.oap.cdr.models.{zh_provider_identifier, zh_provider_master_xref}
import com.optum.oap.cdr.models.{zh_provider, zh_provider_identifier, zh_provider_master_xref}
import com.optum.oap.sparkdataloader.{RuntimeVariables, TableInfo, UserDefinedFunctionForDataLoader}
import org.apache.spark.sql.{DataFrame, SparkSession}
import org.slf4j.LoggerFactory
import org.apache.spark.sql.functions._

object ZH_PROVIDER_IDENTIFIER extends TableInfo[zh_provider_identifier] {

  val log = LoggerFactory.getLogger(this.getClass)

  override def dependsOn = Set("ZH_PROVIDER_MASTER_XREF", "CDR_FE_ZH_PROVIDER_IDENTIFIER", "TEMP_ZH_PROV_PREMATCH")

  override def name = "ZH_PROVIDER_IDENTIFIER"

  override def saveDataFrameToParquet: Boolean = true

  override def partitions: Int = 32

  override def skipTable: Boolean = false

  override def ignoreExtraColumnsInDataFrame: Boolean = true

  override def createDataFrame(sparkSession: SparkSession,
                               loadedDependencies: Map[String, DataFrame],
                               udfMap: Map[String, UserDefinedFunctionForDataLoader],
                               runtimeVariables: RuntimeVariables): DataFrame = {
    import sparkSession.implicits._
    val zhprovIn = loadedDependencies("TEMP_ZH_PROV_PREMATCH").as[zh_provider]
    val zhProvIdentifierIn = loadedDependencies("CDR_FE_ZH_PROVIDER_IDENTIFIER").as[zh_provider_identifier]
    val provXref = broadcast(loadedDependencies("ZH_PROVIDER_MASTER_XREF")).as[zh_provider_master_xref]

    val addedNPIs = zhprovIn.alias("zhp")
      .join(zhProvIdentifierIn.filter($"id_type" === lit("NPI")).alias("zhpi"), zhprovIn("client_ds_id") === zhProvIdentifierIn("client_ds_id") and
        zhprovIn("localproviderid") === zhProvIdentifierIn("provider_id"), "left_outer")
      .where($"provider_id".isNull && $"npi".isNotNull)
      .select(zhprovIn("groupid"), zhprovIn("client_ds_id"), zhprovIn("master_hgprovid"), zhprovIn("localproviderid").as("provider_id"), lit("NPI").as("id_type"), zhprovIn("npi").as("id_value"))

    val cols = addedNPIs.columns.map(c => $"$c")
    val results = addedNPIs.union(zhProvIdentifierIn.toDF().select(cols: _*)).distinct()


    MapMasterIds.mapProviderIds(results.toDF, provXref.toDF, "provider_id", "master_hgprovid")
  }

}
