package com.optum.oap.backend.etl.enrichment

import com.optum.oap.backend.etl.common.MapMasterIds
import com.optum.oap.backend.loader.EnrichmentRunTimeVariables
import com.optum.oap.cdr.models.{mem_userdef_rollup, int_claim_member}
import com.optum.oap.sparkdataloader.{RuntimeVariables, TableInfo, UserDefinedFunctionForDataLoader}
import org.apache.hadoop.yarn.webapp.hamlet.HamletSpec.SUB
import org.apache.spark.sql.expressions.Window
import org.apache.spark.sql.{DataFrame, SparkSession}
import org.slf4j.LoggerFactory
import org.apache.spark.sql.functions.{coalesce, length, regexp_replace, _}
import org.apache.spark.sql.types.DataTypes
import org.apache.spark.sql.types._

object MEM_USERDEF_ROLLUP extends TableInfo[mem_userdef_rollup] {

  private val log = LoggerFactory.getLogger(this.getClass)

  override def dependsOn = Set("CDR_FE_MEM_USERDEF_ROLLUP", "INT_CLAIM_MEMBER")

  override def name = "MEM_USERDEF_ROLLUP"

  override def partitions: Int = 32

  override def createDataFrame(sparkSession: SparkSession,
                               loadedDependencies: Map[String, DataFrame],
                               udfMap: Map[String, UserDefinedFunctionForDataLoader],
                               runtimeVariables: RuntimeVariables): DataFrame = {

    import sparkSession.implicits._

    val cdrMemUserDefRollup = loadedDependencies("CDR_FE_MEM_USERDEF_ROLLUP").as[mem_userdef_rollup]
    val intClaimMember = loadedDependencies("INT_CLAIM_MEMBER").as[int_claim_member]

    val intClaimMemberDf = intClaimMember
      .select("*").where(coalesce($"ii_mem_userdef_1", $"ii_mem_userdef_2", $"ii_mem_userdef_3", $"ii_mem_userdef_4") .isNotNull)
      .select(
        $"groupid",
        $"client_ds_id",
        lit("int_claim_member").cast(StringType).as("datasrc"),
        expr("stack(4,ii_mem_userdef_1, 'CH004044', ii_mem_userdef_2, 'CH004045', ii_mem_userdef_3, 'CH004046', ii_mem_userdef_4, 'CH004047') as (mem_userdef, attribute_type_cui)"),
        concat(lit("UNDEFINED ("), $"mem_userdef" , lit(")")).as("mem_userdef_desc"))

    //Frontend MemUserDefined Rollup table
    val cdrFeMemUserDef = cdrMemUserDefRollup.select(
      $"groupid",
      $"client_ds_id",
      $"datasrc",
      $"attribute_type_cui",
      $"mem_userdef",
      $"mem_userdef_desc",
      $"mem_userdef_lv2",
      $"mem_userdef_lv2_desc",
      $"mem_userdef_lv1",
      $"mem_userdef_lv1_desc"
    )

    //Filtering Frontend MemUserDefined Rollup table
    val cdrFeMUDR = cdrFeMemUserDef
      .dropDuplicates("attribute_type_cui","mem_userdef")
      .select("*")

    //getting the records from intclaimmember whose attribute_type_cui,mem_userdef are not in the MemUserDefined Rollup
    val iCM2 = intClaimMemberDf.as("a").join(cdrFeMUDR.as("b"), ($"a.attribute_type_cui" === $"b.attribute_type_cui") && ($"a.mem_userdef" === $"b.mem_userdef"), "left")
      .select($"a.*",
        $"b.mem_userdef_lv2",
        $"b.mem_userdef_lv2_desc",
        $"b.mem_userdef_lv1",
        $"b.mem_userdef_lv1_desc"
      )
      .where(($"a.mem_userdef" isNotNull) && (length($"a.mem_userdef") <=30 )&& ($"b.attribute_type_cui" isNull))
      .groupBy(
        $"a.groupid",
        $"a.attribute_type_cui",
        $"a.mem_userdef",
        $"a.datasrc",
        $"a.mem_userdef_desc",
        $"b.mem_userdef_lv2",
        $"b.mem_userdef_lv2_desc",
        $"b.mem_userdef_lv1",
        $"b.mem_userdef_lv1_desc")
      .agg(min($"client_ds_id").as("client_ds_id"))

    //union the missed records from intclaimmember and the original table
    val unionCdrFeMemUserDef = cdrFeMemUserDef.unionByName(iCM2)

    //Applying the additional logic and loading to the backend table.
    val rollup = unionCdrFeMemUserDef.select(
      $"groupid"
      ,$"client_ds_id"
      ,$"datasrc"
      ,$"attribute_type_cui"
      ,$"mem_userdef"
      ,substring(coalesce($"mem_userdef_desc", concat(lit("UNDEFINED ("),$"mem_userdef",lit(")"))),1,150).as("mem_userdef_desc")
      ,substring(coalesce($"mem_userdef_lv2", concat(lit("3."),$"mem_userdef")),1,30).as("mem_userdef_lv2")
      ,substring(when($"mem_userdef_lv2".isNull,coalesce($"mem_userdef_desc",concat(lit("UNDEFINED ("),$"mem_userdef",lit(")"))))
        .otherwise(coalesce($"mem_userdef_lv2_desc",concat(lit("UNDEFINED ("),$"mem_userdef_lv2",lit(")")))) ,1,150)
        .as("mem_userdef_lv2_desc")
      ,substring(when($"mem_userdef_lv1".isNotNull,$"mem_userdef_lv1")
        .otherwise(when($"mem_userdef_lv2".isNotNull,concat(lit("2."),$"mem_userdef_lv2"))
          .otherwise(concat(lit("3."),$"mem_userdef"))),1,30).as("mem_userdef_lv1")
      ,substring(when($"mem_userdef_lv1".isNull,
        when($"mem_userdef_lv2".isNull,coalesce($"mem_userdef_desc",concat(lit("UNDEFINED ("),$"mem_userdef",lit(")")) ))
          .otherwise(coalesce($"mem_userdef_lv2_desc",concat(lit("UNDEFINED ("),$"mem_userdef_lv2",lit(")")) )))
        .otherwise(coalesce($"mem_userdef_lv1_desc",concat(lit("UNDEFINED ("),$"mem_userdef_lv1",lit(")")))),1,150).as("mem_userdef_lv1_desc")
      ,row_number().over(Window.partitionBy($"mem_userdef")
        .orderBy(
          when($"mem_userdef_desc".isNotNull, lit(0)).otherwise(lit(1)),
          when($"mem_userdef_lv2".isNotNull, lit(0)).otherwise(lit(1)),
          when($"mem_userdef_lv1".isNotNull, lit(0)).otherwise(lit(1)),
          $"mem_userdef_desc",$"mem_userdef_lv2",$"mem_userdef_lv1"
        )).as("rn")
    ).where((unionCdrFeMemUserDef("mem_userdef") isNotNull) && (length(unionCdrFeMemUserDef("mem_userdef")) <=30) && ($"rn"=== 1))
      .drop($"rn")

    rollup.as[mem_userdef_rollup].toDF()
  }
}