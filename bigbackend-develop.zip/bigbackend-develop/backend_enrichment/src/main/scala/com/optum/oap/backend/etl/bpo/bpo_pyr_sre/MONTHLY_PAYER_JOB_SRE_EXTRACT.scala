package com.optum.oap.backend.etl.bpo.bpo_pyr_sre

import java.text.SimpleDateFormat
import java.util.{Calendar, TimeZone}

import com.optum.oap.backend.cdrTempModel.monthly_payer_job_sre_extract
import com.optum.oap.cdr.models.{mv_client_data_src, pp_bpo_member_detail, zo_bpo_map_employer}
import com.optum.oap.sparkdataloader.{RuntimeVariables, TableInfo, UserDefinedFunctionForDataLoader}
import org.apache.spark.sql.expressions.Window
import org.apache.spark.sql.functions._
import org.apache.spark.sql.types.{StringType, StructField, StructType}
import org.apache.spark.sql.{DataFrame, Dataset, Row, SparkSession}

object MONTHLY_PAYER_JOB_SRE_EXTRACT extends TableInfo[monthly_payer_job_sre_extract] {

  override def dependsOn = Set("PP_BPO_MEMBER_DETAIL", "SCHEMA_INIT", "ZO_BPO_MAP_EMPLOYER", "MV_CLIENT_DATA_SRC")

  override def name = "MONTHLY_PAYER_JOB_SRE_EXTRACT"


  /**
   * Source SQL:
   * date_format((to_date(date_add(add_months(add_months(last_day(from_unixtime(unix_timestamp(value,'yyyyMM'))),-2),-48),1))), "yyyy/MM/dd")
   *
   * Takes the releaseCycle in form yyyyMM and does the date math required to determine the start.date attribute value
   *
   * logic:
   * - 2 months before last day of the month of release_cycle
   * - 48 months before that
   * - +1 day after that
   */
  def deriveStartDateFromReleaseCycle(releaseCycle: String): String = {
    val formatter = new SimpleDateFormat("yyyy/MM/dd")
    val year: Int = releaseCycle.substring(0,4).toInt
    val month: Int = releaseCycle.substring(4,6).toInt
    val cal = Calendar.getInstance
    cal.setTimeZone(TimeZone.getTimeZone("GMT"))
    cal.set(year, month-1, 1)
    val lastDayReleaseCycle = cal.getActualMaximum(Calendar.DAY_OF_MONTH)
    cal.set(Calendar.DAY_OF_MONTH, lastDayReleaseCycle)
    cal.add(Calendar.MONTH, -50)
    val lastDayAfterMonthMath = cal.getActualMaximum(Calendar.DAY_OF_MONTH)
    cal.set(Calendar.DAY_OF_MONTH, lastDayAfterMonthMath)
    cal.add(Calendar.DATE, 1)

    formatter.format(cal.getTime)
  }

  /**
   * (WITH mths AS select
   * date_format(add_months(max(enddate), 0-rownum), 'yyyyMM') as month_yr,
   * date_format(last_day(add_months(max(enddate), 0-rownum)), 'yyyy-MM-dd') as month_end
   * from (select row_number() over (order by groupid) as rownum, max(enddate) over (order by groupid) from pp_bpo_member_detail limit 100))
   */
  private def mthsTempTable(sparkSession: SparkSession, ppBpoMemberDetail: Dataset[pp_bpo_member_detail]): DataFrame = {
    import sparkSession.implicits._
    val yearMonth = new SimpleDateFormat("yyyyMM")
    val yearMonthDay = new SimpleDateFormat("yyyy/MM/dd")

    val maxMemberEndDate = ppBpoMemberDetail.select(date_format(max($"enddate"), "yyyyMM").as("enddate"))
      .collect.head.getAs[String]("enddate")

    val currentEndDate = if (maxMemberEndDate != null) maxMemberEndDate else {
      logger.warn("Unable to determine maximum(PP_BPO_MEMBER_DETAIL.enddate), falling back to current_date (In QIT hopefully!)")
      val currentDate = Calendar.getInstance()
      yearMonth.format(currentDate.getTime)
    }

    val schema = StructType(
      StructField("month_yr", StringType, nullable=false) :: StructField("month_end", StringType, nullable=false) :: Nil)
    val oneToAHundred: Seq[Int] = 1 to 100

    val currentYear: Int = currentEndDate.substring(0,4).toInt
    val currentMonth: Int = currentEndDate.substring(4,6).toInt - 1

    val mthsRows = sparkSession.sparkContext.parallelize(oneToAHundred).map( rownum => {
      val rowCal = Calendar.getInstance()
      rowCal.set(Calendar.YEAR, currentYear)
      rowCal.set(Calendar.MONTH, currentMonth)
      rowCal.add(Calendar.MONTH, 0-rownum)
      val monthYr = yearMonth.format(rowCal.getTime)
      val maxDayOfMonth = rowCal.getActualMaximum(Calendar.DAY_OF_MONTH)
      rowCal.set(Calendar.DAY_OF_MONTH, maxDayOfMonth)
      val monthEnd = yearMonthDay.format(rowCal.getTime)

      Row(monthYr, monthEnd)
    })

    sparkSession.createDataFrame(mthsRows, schema)
  }

  private def deriveEndDate(sparkSession: SparkSession,
                            ppBpoMemberDetail: Dataset[pp_bpo_member_detail],
                            zoBpoMapEmployer: Dataset[zo_bpo_map_employer],
                            mvClientDataSrc: Dataset[mv_client_data_src]): String = {
    import sparkSession.implicits._

    val mths = mthsTempTable(sparkSession, ppBpoMemberDetail)

    val tempV = ppBpoMemberDetail.as("mem")
      .join(broadcast(zoBpoMapEmployer).as("b"), Seq("groupid", "employeraccountid"), "inner")
      .join(broadcast(mvClientDataSrc.where(!coalesce($"status_cd", lit("NULL")).isin("OBS", "HIST")).as("c")),
        $"groupid" === $"c.client_id" && $"b.client_ds_id" === $"c.client_data_src_id", "inner")
      .join(broadcast(mths).as("mths"), $"mths.month_yr".between(date_format($"mem.effectivedate", "yyyyMM"), date_format($"mem.enddate", "yyyyMM")))
      .groupBy($"mem.groupid", $"mths.month_end", $"mem.employeraccountid".as("payer_nm"))
      .agg(count("*").as("num_patients")).as("v")

    val tempX = tempV.select($"*",
        expr("lag(num_patients) over (partition by groupid,payer_nm order by month_end)").as("last_month_pats"))

    val tempW = tempX.select( $"*",
        when($"last_month_pats".isNull, lit(1)).otherwise(lit(round($"num_patients" / $"last_month_pats",2))).as("change_percent")
      ).as("w")

    val tempZ = tempW
      .groupBy($"w.groupid", $"w.month_end")
      .agg(
        sum($"w.num_patients").as("patients"),
        count($"w.payer_nm").as("num_payers"),
        sum(when($"w.change_percent" > lit(0.05), lit(1)).otherwise(0)).as("good_payer_cnt"),
        row_number().over(Window.partitionBy($"w.groupid").orderBy($"w.month_end".desc)).as("rownbr")
      ).as("z")

    try {
      tempZ.where($"z.rownbr" <= lit(10))
        .select(
          $"*", row_number.over(Window.partitionBy($"groupid").orderBy($"good_payer_cnt".desc, $"month_end".desc)).as("best_row")
        ).where($"best_row" === lit(1))
        .collect.head.getAs[String]("month_end")
    } catch {
      case e: NoSuchElementException =>
        "ERROR: Missing or invalid data in one of the following tables is preventing calculation of monthly_payer_job_sre_extract.key=end.date: PP_BPO_MEMBER_DETAIL, ZO_BPO_MAP_EMPLOYER, MV_CLIENT_DATA_SRC"
    }
  }

  override def createDataFrame(sparkSession: SparkSession,
                               loadedDependencies: Map[String, DataFrame],
                               udfMap: Map[String, UserDefinedFunctionForDataLoader],
                               runtimeVariables: RuntimeVariables): DataFrame = {
    import sparkSession.implicits._

    val schemaInit = loadedDependencies("SCHEMA_INIT")
    val ppBpoMemberDetail = loadedDependencies("PP_BPO_MEMBER_DETAIL").where($"healthplansource" === lit("PAYER")).as[pp_bpo_member_detail]
    val zoBpoMapEmployer = loadedDependencies("ZO_BPO_MAP_EMPLOYER").as[zo_bpo_map_employer]
    val mvClientDataSrc = loadedDependencies("MV_CLIENT_DATA_SRC").as[mv_client_data_src]

    val releaseCycle = try {
      schemaInit.where($"attribute" === lit("release_cycle")).collect.head.getAs[String]("value")
    } catch {
      case e: NoSuchElementException => throw new IllegalStateException("FATAL: SCHEMA_INIT release_cycle row missing")
    }

    Seq(
      monthly_payer_job_sre_extract(key = "package.name", "Symmetry"),
      monthly_payer_job_sre_extract(key = "package.version", "10.1.4"),
      monthly_payer_job_sre_extract(key = "sre.enable", "1"),
      monthly_payer_job_sre_extract(key = "input.handler", "IBPOV22"),
      monthly_payer_job_sre_extract(key = "merge.output", "1"),
      monthly_payer_job_sre_extract(key = "claim.size.max.limit", "40000"),
      monthly_payer_job_sre_extract(key = "start.date", deriveStartDateFromReleaseCycle(releaseCycle)),
      monthly_payer_job_sre_extract(key = "end.date",
        deriveEndDate(sparkSession, ppBpoMemberDetail, zoBpoMapEmployer, mvClientDataSrc)
      )
    ).toDF
  }
}

