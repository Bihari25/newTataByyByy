package com.optum.oap.backend.etl.encgrps

import com.optum.oap.backend.cdrTempModel.temp_encounter_zip
import com.optum.oap.sparkdataloader.QueryAndMetadata


object TEMP_ENCOUNTER_ZIP extends QueryAndMetadata[temp_encounter_zip] {

  override def name: String = "TEMP_ENCOUNTER_ZIP"

  override def sparkSql: String = """select ENCOUNTER_GRP_NUM, max(zipcode) as zipcode from (select *
      |from
      |(select pd.groupid, pd.grp_mpi, eeg.encounter_grp_num, patdetail_timestamp as zipdate, localvalue as zipcode
      | , row_number() over (partition by pd.groupid, pd.grp_mpi, eeg.encounter_grp_num
      |                          order by pd.groupid, pd.grp_mpi, eeg.encounter_grp_num
      |                          , abs(datediff(to_date(arrivaltime), to_date(patdetail_timestamp)))
      |                          , eeg.encounterid desc nulls last, eeg.client_ds_id
      |                          , patdetail_timestamp desc nulls last
      |                          , localvalue nulls last
      |                          ) as ziprank
      |from PATIENTDETAIL pd
      |inner join ENCOUNTER_ENCOUNTER_GRP  eeg on (pd.groupid = eeg.groupid and pd.grp_mpi = eeg.grp_mpi)
      |inner join TEMP_VISIT_ENCTR ve on (eeg.groupid = ve.groupid and eeg.encounterid = ve.encounterid and eeg.client_ds_id = ve.client_ds_id and ve.grp_mpi = pd.grp_mpi)
      |and patientdetailtype = 'ZIPCODE'
      |and localvalue is not null
      |and length(localvalue) >=5
      |and localvalue not like '999%'
      |and localvalue <> '00000'
      |and eeg.encounteridtype = 'MASTER'
      |)
      |where ziprank = 1)
      |group by ENCOUNTER_GRP_NUM""".stripMargin

  override def dependsOn: Set[String] = Set("PATIENTDETAIL","ENCOUNTER_ENCOUNTER_GRP","TEMP_VISIT_ENCTR")
}
