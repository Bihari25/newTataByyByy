package com.optum.oap.backend.etl.patient_matching.quality_gates

import com.optum.oap.backend.cdrTempModel.qgate_person_id_status
import com.optum.oap.backend.etl.summary.PATIENT_GRP_MPI_DIFF.getMostRecentExistingReleaseIfAny
import com.optum.oap.backend.loader.EnrichmentRunTimeVariables
import com.optum.oap.backend.etl.patient_matching.PATIENT_MPI_UTILS
import com.optum.oap.sparkdataloader.{RuntimeVariables, TableInfo, UserDefinedFunctionForDataLoader}
import org.apache.spark.sql.{DataFrame, SparkSession}
import org.slf4j.LoggerFactory

import scala.util.Try

object QGATE_PERSON_ID_STATUS extends TableInfo[qgate_person_id_status]{

  val log = LoggerFactory.getLogger(this.getClass)

  override def dependsOn: Set[String] = Set()

  override def name = "QGATE_PERSON_ID_STATUS"

  override def createDataFrame(sparkSession: SparkSession, loadedDependencies: Map[String, DataFrame], udfMap: Map[String, UserDefinedFunctionForDataLoader], runtimeVariables: RuntimeVariables): DataFrame = {
    import sparkSession.implicits._
    val releaseCycle = EnrichmentRunTimeVariables(runtimeVariables).release
    val grpid = EnrichmentRunTimeVariables(runtimeVariables).clientId
    val env = EnrichmentRunTimeVariables(runtimeVariables).environment

    val prevmonth_qgate =  PATIENT_MPI_UTILS.getPreviousCycleTable[qgate_person_id_status](sparkSession, releaseCycle, grpid, env, "QGATE_PERSON_ID_STATUS")
    prevmonth_qgate
  }

}
