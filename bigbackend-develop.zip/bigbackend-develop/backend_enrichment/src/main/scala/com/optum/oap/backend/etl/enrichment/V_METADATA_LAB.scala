package com.optum.oap.backend.etl.enrichment

import com.optum.oap.cdr.models.{metadata_lab, mv_hts_domain_concept, v_metadata_lab}
import com.optum.oap.sparkdataloader.{RuntimeVariables, TableInfo, UserDefinedFunctionForDataLoader}
import org.apache.spark.sql.{DataFrame, SparkSession}
import org.apache.spark.sql.functions.{lit, broadcast}

object V_METADATA_LAB extends TableInfo[v_metadata_lab] {

  override def dependsOn: Set[String] = Set(
    "METADATA_LAB",
    "MV_HTS_DOMAIN_CONCEPT"
  )

  override def name: String = "V_METADATA_LAB"

  override def createDataFrame(sparkSession: SparkSession, loadedDependencies: Map[String, DataFrame], udfMap: Map[String, UserDefinedFunctionForDataLoader], runtimeVariables: RuntimeVariables): DataFrame = {
    import sparkSession.implicits._

    val metadataLab = broadcast(loadedDependencies("METADATA_LAB").as[metadata_lab])
    val mvHTSDomainConcept = broadcast(loadedDependencies("MV_HTS_DOMAIN_CONCEPT").as[mv_hts_domain_concept])

    metadataLab.as("ml")
      .join(mvHTSDomainConcept.as("ht").where($"domain_cui" === lit("CH001281")), $"ml.cui" === $"ht.concept_cui", "left_outer")
      .join(mvHTSDomainConcept.as("hu").where($"domain_cui" === lit("CH001302")), $"ml.unit" === $"hu.concept_cui", "left_outer")
      .select(
        $"ml.cui",
        $"ht.concept_name".as("hts_test_name"),
        $"ml.unit",
        $"hu.concept_name".as("hts_unit_name"),
        $"ml.ref_range_min",
        $"ml.ref_range_max",
        $"ml.semantic_val_min",
        $"ml.semantic_val_max",
        $"ml.notes",
        $"ml.dts_version"
      )
  }

}
