package com.optum.oap.backend.etl.bpo

import com.optum.oap.cdr.models._
import com.optum.oap.sparkdataloader.{RuntimeVariables, TableInfo, UserDefinedFunctionForDataLoader}
import org.apache.spark.sql.{DataFrame, SparkSession}

object PP_BPO_PROVIDER_DETAIL_SPANS extends TableInfo[pp_bpo_provider_detail_spans]{

  override def dependsOn: Set[String] = Set("PP_BPO_PHARMACY_CLAIMS", "PP_BPO_MEDICAL_CLAIMS", "PP_BPO_MEMBER_DETAIL", "TEMP_PP_BPO_PROVIDER_DETAIL_SPANS")

  override def name = "PP_BPO_PROVIDER_DETAIL_SPANS"

  override def createDataFrame(sparkSession: SparkSession,
                               loadedDependencies: Map[String, DataFrame],
                               udfMap: Map[String, UserDefinedFunctionForDataLoader],
                               runtimeVariables: RuntimeVariables): DataFrame = {
    import sparkSession.implicits._

    val ppBpoPharmacyClaims = loadedDependencies("PP_BPO_PHARMACY_CLAIMS").as[pp_bpo_pharmacy_claims]
    val ppBpoMedicalClaims = loadedDependencies("PP_BPO_MEDICAL_CLAIMS").as[pp_bpo_medical_claims]
    val ppBpoMemberDetails = loadedDependencies("PP_BPO_MEMBER_DETAIL").as[pp_bpo_member_detail]
    val ppBpoProviderDetailSpans = loadedDependencies("TEMP_PP_BPO_PROVIDER_DETAIL_SPANS").as[pp_bpo_provider_detail_spans]

    val clause = ppBpoPharmacyClaims.select('prescprovider.as("providerid"))
      .union(ppBpoMedicalClaims.select('serviceproviderid.as("providerid")))
      .union(ppBpoMemberDetails.select('pcpid.as("providerid")))
      .union(ppBpoPharmacyClaims.select('pharmacyid.as("providerid")))
      .union(ppBpoMedicalClaims.select('billingproviderid.as("providerid")))
      .union(ppBpoMedicalClaims.select('orderingproviderid.as("providerid")))
      .union(ppBpoProviderDetailSpans.where($"provaffiliationid".isNotNull).select('providerid.as("providerid")))
      .unionByName(ppBpoMedicalClaims.where($"refer_prov_id".isNotNull).select($"refer_prov_id".as("providerid")))
      .distinct

    ppBpoProviderDetailSpans
      .join(clause.as("c"), Seq("providerid"), "inner")
      .select("groupid",
        "npi",
        "providerid",
        "adminpin",
        "affilaccess",
        "dea",
        "fifth_specialty",
        "fourth_specialty",
        "health_plan_id",
        "prod_code_1",
        "prod_code_2",
        "prod_code_3",
        "prod_code_4",
        "prod_code_5",
        "prod_code_6",
        "prov_grp_tin",
        "prov_tin",
        "provaccess",
        "provactive",
        "provaddress1",
        "provaddress2",
        "provcity",
        "provemail",
        "provider_county",
        "provphone",
        "provpin",
        "provregion",
        "provstate",
        "provzip",
        "qualityprofileflag",
        "third_specialty",
        "providername",
        "providerfirstname",
        "providerlastname",
        "specialty",
        "secondaryspecialty",
        "providertype",
        "pcpflag",
        "healthplansource",
        "mapsource",
        "prov_effective_dt",
        "prov_end_dt",
        "provaffiliationid",
        "provider_status",
        "cust_prov_attr1",
        "cust_prov_attr2",
        "cust_prov_attr3",
        "cust_prov_attr4",
        "cust_prov_attr5",
        "cust_prov_attr6",
        "cust_prov_attr7",
        "cust_prov_attr8",
        "cust_prov_attr9",
        "cust_prov_attr10",
        "cust_prov_attr11",
        "cust_prov_attr12",
        "cust_prov_attr13",
        "cust_prov_attr14",
        "cust_prov_attr15",
        "cust_prov_attr16",
        "cust_prov_attr17",
        "cust_prov_attr18",
        "cust_prov_attr19",
        "cust_prov_attr20",
        "final_flag",
        "final_network_flag",
        "prov_geo_lat",
        "prov_geo_lon",
        "prov_userdef_1",
        "prov_userdef_2",
        "sec_provider_id"
      )
  }
}
