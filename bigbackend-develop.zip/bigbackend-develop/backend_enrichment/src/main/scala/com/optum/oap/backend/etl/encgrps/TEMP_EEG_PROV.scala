package com.optum.oap.backend.etl.encgrps

import com.optum.oap.backend.cdrTempModel.temp_eeg_prov
import com.optum.oap.sparkdataloader.QueryAndMetadata

object TEMP_EEG_PROV extends QueryAndMetadata[temp_eeg_prov] {
  override def name: String = "TEMP_EEG_PROV"

  override def sparkSql: String =
    """
      |SELECT
      |    groupid,
      |    grp_mpi,
      |    client_ds_id,
      |    encounterid,
      |    providerrole,
      |    prov_id,
      |    patienttype,
      |    ii_code,
      |    entity_type_code,
      |    datasrc_excl,
      |    min_prov_dtm,
      |    max_prov_dtm
      |FROM
      |    (
      |        SELECT /*+  BROADCASTJOIN(temp_providers) */
      |            ce.*,
      |            p.ii_code,
      |            p.entity_type_code,
      |            ROW_NUMBER() OVER(
      |                PARTITION BY ce.groupid,ce.grp_mpi,ce.client_ds_id,ce.encounterid
      |                ORDER BY
      |                    CASE
      |                        WHEN ce.patienttype IN(
      |                            'CH000106','CH000107','CH000109','CH000113','CH000795','CH003031','CH003032'
      |                        )
      |                             AND ii_code < '200' THEN 1
      |                        WHEN ce.patienttype IN(
      |                            'CH000106','CH000107','CH000109','CH000113','CH000795','CH003031','CH003032'
      |                        )
      |                             AND entity_type_code = '2' THEN 2
      |                        WHEN ce.patienttype NOT IN(
      |                            'CH000106','CH000107','CH000109','CH000113','CH000795','CH003031','CH003032'
      |                        )
      |                             AND ii_code >= '200' THEN 3
      |                        WHEN ce.patienttype NOT IN(
      |                            'CH000106','CH000107','CH000109','CH000113','CH000795','CH003031','CH003032'
      |                        )
      |                             AND entity_type_code <> '2' THEN 4
      |                        else 99
      |                    END,
      |                    CASE
      |                            WHEN ce.providerrole = 'CH001413' THEN 1  --visit provider
      |                            WHEN ce.providerrole = 'CH001417' THEN 2  --performing provider
      |                            WHEN ce.providerrole = 'CH001418' THEN 3  --billing provider
      |                            ELSE 99
      |                        END,ce.min_prov_dtm,ce.prov_id
      |            ) AS provrank
      |        FROM
      |            temp_eeg_prov_all ce
      |            INNER JOIN temp_providers p ON ( ce.prov_id = p.master_hgprovid )
      |    )
      |WHERE
      |    provrank = 1
    """.stripMargin

  override def partitions: Int = 256

  override def dependsOn: Set[String] = Set("TEMP_EEG_PROV_ALL","TEMP_PROVIDERS")
}



