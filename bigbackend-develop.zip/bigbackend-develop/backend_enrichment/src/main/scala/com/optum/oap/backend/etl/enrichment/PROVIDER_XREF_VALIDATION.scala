package com.optum.oap.backend.etl.enrichment

import com.optum.oap.backend.cdrTempModel.{provider_xref, validation}
import com.optum.oap.backend.etl.common.PartitionedDataOperations
import com.optum.oap.backend.loader.EnrichmentRunTimeVariables
import com.optum.oap.sparkdataloader.{RuntimeVariables, TableInfo, UserDefinedFunctionForDataLoader}
import org.apache.spark.sql.functions.lit
import org.apache.spark.sql.{DataFrame, SparkSession}
import org.slf4j.LoggerFactory

import java.text.SimpleDateFormat
import java.util.Date

/**
  *
  * Copyright 2021 Optum Analytics
  *
  * Date: 02/09/21
  *
  * Creator: pavula
  */
object PROVIDER_XREF_VALIDATION extends TableInfo[validation] with PartitionedDataOperations {

  val log = LoggerFactory.getLogger(this.getClass)

  override def dependsOn = Set("V_PROVIDER_XREF")

  override def name = "PROVIDER_XREF_VALIDATION"

  private val date = new SimpleDateFormat("yyyyMMdd").format(new Date()).toInt

  override def createDataFrame(sparkSession: SparkSession,
                               loadedDependencies: Map[String, DataFrame],
                               udfMap: Map[String, UserDefinedFunctionForDataLoader],
                               runtimeVariables: RuntimeVariables): DataFrame = {
    import sparkSession.implicits._

    implicit val session = sparkSession
    val schema = EnrichmentRunTimeVariables(runtimeVariables).cdrSchema

    val pXref = loadedDependencies("V_PROVIDER_XREF").as[provider_xref]
    val provXref = if(pXref.isEmpty) loadData(schema, "V_PROVIDER_XREF").as[provider_xref] else pXref

    val currentProviderXref = provXref.where($"partition_date" === lit(date))
    val distinctHgprovid = currentProviderXref.select($"hgprovid").distinct()

    if(distinctHgprovid.count() != currentProviderXref.count()) {
      throw ProviderXrefMismatchException("The count of provider_xref did not match to distinct count of hgprovid, something went wrong." )
    }

    Seq.empty[validation].toDF()
  }

  final case class ProviderXrefMismatchException(message: String = "", exception: Throwable = null) extends Exception(message)
}
