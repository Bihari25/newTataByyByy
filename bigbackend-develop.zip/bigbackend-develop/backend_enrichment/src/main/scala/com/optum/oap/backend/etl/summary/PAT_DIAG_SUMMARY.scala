package com.optum.oap.backend.etl.summary

import com.optum.oap.cdr.models.{diagnosis, pat_diag_summary}
import com.optum.oap.sparkdataloader.{RuntimeVariables, TableInfo, UserDefinedFunctionForDataLoader}
import org.apache.spark.sql.functions._
import org.apache.spark.sql.types.{IntegerType, StringType}
import org.apache.spark.sql.{DataFrame, SparkSession}
import org.slf4j.LoggerFactory

object PAT_DIAG_SUMMARY extends TableInfo[pat_diag_summary] {

  val log = LoggerFactory.getLogger( this.getClass )

  override def dependsOn = Set( "DIAGNOSIS" )

  override def name = "PAT_DIAG_SUMMARY"

  override def saveDataFrameToParquet: Boolean = true

  override def partitions: Int = 512

  override def skipTable: Boolean = false

  override def ignoreExtraColumnsInDataFrame: Boolean = false

  override def createDataFrame( sparkSession: SparkSession,
                                loadedDependencies: Map[String, DataFrame],
                                udfMap: Map[String, UserDefinedFunctionForDataLoader],
                                runtimeVariables: RuntimeVariables ): DataFrame = {

    import sparkSession.implicits._

    val diagnosis = loadedDependencies( "DIAGNOSIS" ).as[diagnosis]

    val summary = diagnosis
      .filter( 'mappeddiagnosis.isNotNull && 'grp_mpi.isNotNull )
      .select(
        'groupid,
        'grp_mpi,
        coalesce( 'codetype, lit( "UNKNOWN" ) ).alias( "codetype" ),
        'mappeddiagnosis.alias( "diag" ),
        date_format( 'dx_timestamp, "yyyy" ).alias( "dt_yr" ),
        quarter( 'dx_timestamp ).cast( StringType ).alias( "dt_qtr" ),
        date_format( 'dx_timestamp, "MM" ).alias( "dt_month" )
      )
      .groupBy( "groupid", "grp_mpi", "codetype", "diag", "dt_yr", "dt_qtr", "dt_month" )
      .agg( count( lit( 1 ) ).cast( IntegerType ).alias( "cnt" ) )

    summary.select( "groupid", "grp_mpi", "codetype", "diag", "dt_yr", "dt_qtr", "dt_month", "cnt" )
  }
}
