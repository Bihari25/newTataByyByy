package com.optum.oap.backend.etl.enrichment

import com.optum.oap.backend.etl.common.MapMasterIds
import com.optum.oap.cdr.models.{prov_fac_rel, zh_provider_master_xref}
import com.optum.oap.sparkdataloader.{RuntimeVariables, TableInfo, UserDefinedFunctionForDataLoader}
import org.apache.spark.sql.functions.broadcast
import org.apache.spark.sql.{DataFrame, SparkSession}
import org.slf4j.LoggerFactory

object PROV_FAC_REL extends TableInfo[prov_fac_rel] {

  val log = LoggerFactory.getLogger(this.getClass)

  override def dependsOn = Set("ZH_PROVIDER_MASTER_XREF", "CDR_FE_PROV_FAC_REL")

  override def name = "PROV_FAC_REL"

  override def saveDataFrameToParquet: Boolean = true

  override def partitions: Int = 32

  override def skipTable: Boolean = false

  override def ignoreExtraColumnsInDataFrame: Boolean = true

  override def createDataFrame(sparkSession: SparkSession,
                               loadedDependencies: Map[String, DataFrame],
                               udfMap: Map[String, UserDefinedFunctionForDataLoader],
                               runtimeVariables: RuntimeVariables): DataFrame = {
    import sparkSession.implicits._

    val prov_fac_relIn = loadedDependencies("CDR_FE_PROV_FAC_REL").as[prov_fac_rel]
    val provXref = broadcast(loadedDependencies("ZH_PROVIDER_MASTER_XREF")).as[zh_provider_master_xref]

    MapMasterIds.mapProviderIds(prov_fac_relIn.toDF, provXref.toDF, "providerid", "mstrprovid")
  }

}
