package com.optum.oap.backend.etl.enrichment

import com.optum.oap.backend.etl.common.{Functions, MapMasterIds, Observations}
import com.optum.oap.backend.loader.EnrichmentRunTimeVariables
import com.optum.oap.backend.cdrTempModel.{observation_nlp_preset}
import com.optum.oap.cdr.models._
import com.optum.oap.sparkdataloader.{RuntimeVariables, TableInfo, UserDefinedFunctionForDataLoader}
import org.apache.spark.sql.functions._
import org.apache.spark.sql.types._
import org.apache.spark.sql.{DataFrame, Dataset, SparkSession}

object OBSERVATION_NLP extends TableInfo[observation] {
  override def dependsOn = Set("OBSERVATION_NLP_PRESET", "ZCM_OBSTYPE_CODE")

  override def name = "OBSERVATION_NLP"

  override def partitions: Int = 128

  override def ignoreExtraColumnsInDataFrame: Boolean = true

  override def createDataFrame(sparkSession: SparkSession,
                               loadedDependencies: Map[String, DataFrame],
                               udfMap: Map[String, UserDefinedFunctionForDataLoader],
                               runtimeVariables: RuntimeVariables): DataFrame = {
    import sparkSession.implicits._

    val partitionMultiplier = EnrichmentRunTimeVariables(runtimeVariables).partitionMultiplier

    val lZcmObstypeCode = broadcast(loadedDependencies("ZCM_OBSTYPE_CODE")).as[zcm_obstype_code]

    val lObservationNlpPreset = loadedDependencies("OBSERVATION_NLP_PRESET").as[observation_nlp_preset]

    lObservationNlpPreset.as("n")
      .join(lZcmObstypeCode.as("c"), $"c.groupid" === $"n.groupid" && $"c.datasrc" === $"n.datasrc" && upper($"c.obscode") === upper($"n.localcode"), "inner")
      .select(
        $"n.client_ds_id",
        $"n.datasrc",
        $"n.encounterid",
        lit(null).cast(StringType).as("facilityid"),
        $"n.groupid",
        lit(null).cast(StringType).as("grp_mpi"),
        lit(null).cast(LongType).as("hgpid"),
        lit(null).cast(StringType).as("local_method_cd"),
        lit(null).cast(StringType).as("local_method_desc"),
        lit(null).cast(StringType).as("local_obs_desc"),
        lit(null).cast(StringType).as("local_obs_type_cd"),
        $"n.units".as("local_obs_unit"),
        $"n.localcode".as("localcode"),
        when($"n.result_num".isNotNull, $"n.result_num")
          .when($"n.result_min".isNotNull && $"n.result_max".isNotNull, concat($"n.result_min", lit("-"), $"n.result_max"))
          .otherwise(lit(null)).as("localresult"),
        to_timestamp($"n.encounterdate", "yyyyMMdd").as("obsdate"),
        lit(null).cast(StringType).as("obsresult"),
        $"c.obstype",
        $"n.patientid",
        when($"n.concept_dt_type" === "exact", to_timestamp($"n.result_date", "yyyyMMdd"))
          .when($"n.concept_dt_type" === "unknown", lit(null))
          .otherwise(to_timestamp($"n.concept_dt_guess", "yyyyMMdd")).as("resultdate"),
        lit(null).cast(StringType).as("statuscode"),
        $"c.obstype_std_units".as("std_obs_unit"),
        when(upper($"n.modifier").endsWith("BY"), lit(1))
          .when($"n.result_num".isNull && $"n.result_min".isNull && $"n.result_max".isNull, lit(1))
          .otherwise(lit(0)).as("drop_row")
      ).where($"drop_row" =!= lit(1))
      .drop("drop_row")
  }
}