package com.optum.oap.backend.etl.bpo

import com.optum.oap.cdr.models._
import com.optum.oap.sparkdataloader.{RuntimeVariables, TableInfo, UserDefinedFunctionForDataLoader}
import org.apache.spark.sql.{DataFrame, SparkSession}

/**
  *
  * Copyright 2019 Optum Analytics
  *
  * Date: 6/19/19
  *
  * Creator: bpokharel(bishu)
  */

// create blank file which is needed as a part of contract
object PP_BPO_DISEASE_REGISTRY extends TableInfo[pp_bpo_disease_registry] {

  override def name = "PP_BPO_DISEASE_REGISTRY"

  override def dependsOn: Set[String] = Set()

  override def createDataFrame(sparkSession: SparkSession,
                               loadedDependencies: Map[String, DataFrame],
                               udfMap: Map[String, UserDefinedFunctionForDataLoader],
                               runtimeVariables: RuntimeVariables): DataFrame = {
    import sparkSession.implicits._

    sparkSession.emptyDataset[pp_bpo_disease_registry].toDF

  }

}

