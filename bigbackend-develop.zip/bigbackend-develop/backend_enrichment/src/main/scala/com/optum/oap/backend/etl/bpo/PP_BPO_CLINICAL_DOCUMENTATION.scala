package com.optum.oap.backend.etl.bpo

import com.optum.oap.backend.cdrTempModel.{temp_bpo_calculate_params, temp_bpo_patients}
import com.optum.oap.backend.etl.bpo.BpoUtil.getBpoInputParameters
import com.optum.oap.backend.etl.common.{Functions, TimestampTruncate}
import com.optum.oap.cdr.models._
import com.optum.oap.sparkdataloader.{RuntimeVariables, TableInfo, UserDefinedFunctionForDataLoader}
import org.apache.spark.sql.expressions.Window
import org.apache.spark.sql.functions._
import org.apache.spark.sql.types.{DateType, IntegerType}
import org.apache.spark.sql.{DataFrame, SparkSession}

object PP_BPO_CLINICAL_DOCUMENTATION extends TableInfo[pp_bpo_clinical_documentation] {

  override def dependsOn = Set("TEMP_BPO_PATIENTS", "OBSERVATION", "TEMP_BPO_CALCULATE_PARAMS")

  override def name = "PP_BPO_CLINICAL_DOCUMENTATION"

  override def createDataFrame(sparkSession: SparkSession,
                               loadedDependencies: Map[String, DataFrame],
                               udfMap: Map[String, UserDefinedFunctionForDataLoader],
                               runtimeVariables: RuntimeVariables): DataFrame = {

    import sparkSession.implicits._

    val tempBpoPatients = loadedDependencies("TEMP_BPO_PATIENTS").as[temp_bpo_patients]
    val observ = loadedDependencies("OBSERVATION").as[observation]
    val tempParams = broadcast(loadedDependencies("TEMP_BPO_CALCULATE_PARAMS")).as[temp_bpo_calculate_params]

    val inputParameters = getBpoInputParameters(sparkSession, tempParams)
    val startDate = to_timestamp(lit(inputParameters.engineStartDate))
    val endDate = to_timestamp(lit(inputParameters.engineEndDate))

    object CUIs extends Enumeration {
      val PHQ9DepressionScreen = "CH001846" //ACO.PHQ-9.Depression Screen
      val PHQ2DepressionScreen = "CH001999" //ACO.PHQ-2.Depression Screen
      val PHQDepressionScreenForTeens = "CH002805" //PHQ Depression Screen for Teens
      val PHQ9DepressionScreenCareCoordination = "CH002998" //PHQ9 Depression Screen (Care Coordination)
    }

    val pat = tempBpoPatients.select(
      $"groupid",
      $"grp_mpi",
      $"payer",
      row_number().over(Window.partitionBy($"groupid", $"grp_mpi").orderBy($"payer".desc)).as("rw_id")
    )

    val obs
    = observ
      .where(
        $"obstype".isin(lit(CUIs.PHQ9DepressionScreen), lit(CUIs.PHQ2DepressionScreen), lit(CUIs.PHQDepressionScreenForTeens), lit(CUIs.PHQ9DepressionScreenCareCoordination))
          && TimestampTruncate.truncate(lit("DAY"), $"obsdate").between(startDate, endDate)
      )
      .select(
        $"groupid",
        $"client_ds_id",
        $"grp_mpi",
        $"obstype",
        TimestampTruncate.truncate(lit("DAY"), $"obsdate").as("documentation_date"),
        $"obsresult",
        when($"obstype".isin(lit(CUIs.PHQ9DepressionScreen), lit(CUIs.PHQ9DepressionScreenCareCoordination)), "44261-6")
          .when($"obstype" === lit(CUIs.PHQ2DepressionScreen), "55758-7")
          .when($"obstype" === lit(CUIs.PHQDepressionScreenForTeens), "73831-0")
          .as("code")
      )

    val cd
    = obs.as("obs")
      .join(pat.as("pat"), Seq("groupid", "grp_mpi"), "inner")
      .where($"pat.rw_id" === lit(1))
      .select(
        $"obs.groupid",
        $"obs.client_ds_id",
        $"obs.grp_mpi",
        lit("LOINC").as("code_taxonomy"),
        $"obs.code",
        $"obs.documentation_date",
        when($"obs.obsresult".cast(IntegerType).between(lit(0), lit(27)), $"obs.obsresult").otherwise(null).as("result"),
        when($"obs.obstype".isin(lit("CH002805")), lit("M")).otherwise(lit("9")).as("phq9_version"),
        when($"pat.payer" === lit(1), lit("PAYER")).otherwise(lit("PROVIDER")).as("healthplansource")
      )
      .distinct()

    val withRowNumberDf = Functions.appendRowNumberToDataframe(sparkSession, cd, rowNumberName = "rownum")

    withRowNumberDf.select(
      'groupid,
      'grp_mpi.as("memberid"),
      concat(lit("CLD"), 'client_ds_id, lit("."), 'rownum).as("clinical_document_id"),
      'code_taxonomy,
      'code,
      'documentation_date,
      'result,
      'phq9_version,
      'healthplansource
    )
  }

}
