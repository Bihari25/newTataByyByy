package com.optum.oap.backend.etl.bpo.bpo_pyr_hedis_qme

import com.optum.oap.backend.cdrTempModel.hedis_monthly_enr_extract_qme
import com.optum.oap.backend.etl.common.CDRConstants
import com.optum.oap.cdr.models.pp_bpo_member_detail
import com.optum.oap.sparkdataloader.{RuntimeVariables, TableInfo, UserDefinedFunctionForDataLoader}
import org.apache.spark.sql.functions._
import org.apache.spark.sql.types.StringType
import org.apache.spark.sql.expressions.Window
import org.apache.spark.sql.{DataFrame, SparkSession}

object HEDIS_MONTHLY_ENR_EXTRACT_QME extends TableInfo[hedis_monthly_enr_extract_qme] {

  override def dependsOn: Set[String] = Set("PP_BPO_MEMBER_DETAIL")

  override def name = "HEDIS_MONTHLY_ENR_EXTRACT_QME"

  override def createDataFrame(sparkSession: SparkSession,
                               loadedDependencies: Map[String, DataFrame],
                               udfMap: Map[String, UserDefinedFunctionForDataLoader],
                               runtimeVariables: RuntimeVariables): DataFrame = {

      import sparkSession.implicits._

      val pp_bpo_member_detail = loadedDependencies("PP_BPO_MEMBER_DETAIL").as[pp_bpo_member_detail]
      val final_member_detail= pp_bpo_member_detail.where($"healthplansource" === lit("PAYER")).select(
          $"memberid",
          $"employeraccountid",
          max(to_date(concat(date_format($"enddate", "yyyy"), lit("1231")), CDRConstants.DATE_FORMAT_4Y2M2D))
            .over(Window.partitionBy($"groupid")).as("yr0_date"),
          max($"enddate").over(Window.partitionBy($"memberid")).as("mem_last_end_date"),
          max($"enddate").over(Window.partitionBy($"employeraccountid")).as("pyr_last_end_date")
      ).distinct


      pp_bpo_member_detail.as("md").where($"md.healthplansource" === lit("PAYER") && $"lineofbusinessid".isNotNull).join(final_member_detail.as("jmd"),$"jmd.memberid" === $"md.memberid" && $"jmd.employeraccountid" === $"md.employeraccountid", "inner").select(
          $"md.memberid".as("MemberID"),
          date_format(when($"effectivedate" < $"dob", $"dob").otherwise($"effectivedate"), "yyyy-MM-dd").cast(StringType).as("EffectiveDate"),
          date_format(when($"md.enddate" === $"mem_last_end_date" && $"mem_last_end_date" === $"pyr_last_end_date" && (date_format($"enddate", "yyyy") === date_format($"yr0_date", "yyyy")) , $"yr0_date").otherwise($"enddate"), "yyyy-MM-dd").cast(StringType).as("EndDate"),
          $"PRODUCTCODE".as("ProductCode"),
          $"LINEOFBUSINESSID".cast(StringType).as("LineofBusinessID"),
          $"PCPID".as("PCPID"),
          $"HEALTHPLANSOURCE".as("HealthPlanSource"),
          $"HEALTHPLANNAME".as("HealthPlanName"),
          $"COVERAGECLASSCODE".as("CoverageClassCode"),
          $"CONTRACTTYPE".as("ContractType"),
          $"BENEFITPLAN".as("BenefitPlan"),
          $"COVERAGESTATUS".as("CoverageStatus"),
          $"SUBSCRIBERID".as("SubscriberID"),
          $"SUBSCRIBERFLAG".as("IsSubscriber"),
          lit("AD").as("MapSourceCode"),
          $"PHARMACY".as("HasPharmacyBenefit"),
          $"MEDICAL".as("HasMedicalBenefit"),
          $"DENTAL_BENEFIT".as("HasDentalBenefit"),
          $"MH_INPATIENT_BENEFIT".as("HasMHInpatientBenefit"),
          $"MH_INTENSIVE_BENEFIT".as("HasMHIntensiveBenefit"),
          $"MH_OUTPATIENT_BENEFIT".as("HasMHOutpatientBenefit"),
          $"CD_INPATIENT_BENEFIT".as("HasCDInpatientBenefit"),
          $"CD_INTENSIVE_BENEFIT".as("HasCDIntensiveBenefit"),
          $"CD_OUTPATIENT_BENEFIT".as("HasCDOutpatientBenefit"),
          $"HOSPICE_BENEFIT".as("HasHospiceBenefit"),
          $"PROV_ORG_ID".as("ProviderOrganizationID"),
          $"MCOID".as("MCOID"),
          lit(null).cast(StringType).as("QHPIssuerID"),
          lit(null).cast(StringType).as("QHPStateCode"),
          lit(null).cast(StringType).as("QHPReportingUnitID"),
          lit(null).cast(StringType).as("QHPStandardComponentID"),
          lit(null).cast(StringType).as("QHPMetalLevelCode"),
          lit(null).cast(StringType).as("QHPVariantIDCode"),
          lit(null).cast(StringType).as("QHPAPTCCSREligibilityCode"),
          lit(null).cast(StringType).as("QHPPlanMarketingName"),
          lit(null).cast(StringType).as("QHPMedicaidExpansion"),
          lit(null).cast(StringType).as("QHPReportingStatus"),
          when($"ECDS_FLAG" === lit("Y"), lit(1)).otherwise(lit(4)).cast(StringType).as("ECDSDataAvailableforMemberCode"),
          $"PRIMARY_COVERAGE_FLAG".as("IsPrimaryCoverage"),
          lit(null).cast(StringType).as("HasLongTermInstitution"),
          lit(null).cast(StringType).as("IsPlanEmployee"),
          lit(null).cast(StringType).as("MedicareContractCode"),
          lit(null).cast(StringType).as("CIN"),
          lit(null).cast(StringType).as("MedicareID"),
          lit(null).cast(StringType).as("ENRUserDefined_1"),
          lit(null).cast(StringType).as("ENRUserDefined_2"),
          lit(null).cast(StringType).as("ENRUserDefined_3"),
          lit(null).cast(StringType).as("ENRUserDefined_4"),
          lit(null).cast(StringType).as("ENRUserDefined_5"),
          lit(null).cast(StringType).as("ENRUserDefined_6")

      )

  }

}
