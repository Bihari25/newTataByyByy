package com.optum.oap.backend.etl.enrichment

import com.optum.oap.backend.etl.common.{MapMasterIds, MapMedication}
import com.optum.oap.backend.loader.EnrichmentRunTimeVariables
import com.optum.oap.cdr.models._
import org.apache.spark.sql.functions._
import com.optum.oap.sparkdataloader.{RuntimeVariables, TableInfo, UserDefinedFunctionForDataLoader}
import org.apache.spark.sql.functions.{current_date, lit, trim, when}
import org.apache.spark.sql.{DataFrame, SparkSession}
import org.slf4j.LoggerFactory

object RX_PATIENT_REPORTED extends TableInfo[rx_patient_reported] {

  val log = LoggerFactory.getLogger(this.getClass)

  override def dependsOn = Set("PATIENT_MPI", "ZH_PROVIDER_MASTER_XREF", "CDR_FE_RX_PATIENT_REPORTED", "ZH_MED_MAP_DCC", "MAP_PTREP_MED_CATEGORY")

  override def name = "RX_PATIENT_REPORTED"

  override def saveDataFrameToParquet: Boolean = true

  override def partitions: Int = 32

  override def skipTable: Boolean = false

  override def ignoreExtraColumnsInDataFrame: Boolean = true

  override def createDataFrame(sparkSession: SparkSession,
                               loadedDependencies: Map[String, DataFrame],
                               udfMap: Map[String, UserDefinedFunctionForDataLoader],
                               runtimeVariables: RuntimeVariables): DataFrame = {
    import sparkSession.implicits._

    val partitionMultiplier = EnrichmentRunTimeVariables(runtimeVariables).partitionMultiplier

    val rx_patient_reported = loadedDependencies("CDR_FE_RX_PATIENT_REPORTED").as[rx_patient_reported]
    val rx_patient_reportedIn = rx_patient_reported.select(rx_patient_reported.columns.map {
      colName => {
        colName.toLowerCase match {
          case "localform" | "localroute" | "localstrengthunit"  => trim(rx_patient_reported.col(colName)).as(colName)
          case _ => rx_patient_reported.col(colName)
        }
      }
    }:_*)
    val provXref = broadcast(loadedDependencies("ZH_PROVIDER_MASTER_XREF")).as[zh_provider_master_xref]
    val patXref = loadedDependencies("PATIENT_MPI").as[patient_mpi]
    val mapDccDf = broadcast(loadedDependencies("ZH_MED_MAP_DCC")).as[zh_med_map_dcc]
    val medCategory = broadcast(loadedDependencies("MAP_PTREP_MED_CATEGORY")).as[map_ptrep_med_category]

    val mappedPatientReportedIdDf = MapMasterIds.mapProviderIds(MapMasterIds.mapPatientIds(rx_patient_reportedIn.toDF, patXref.toDF, false), provXref.toDF(), "localproviderid", "mstrprovid")
    val repNum = Math.ceil(partitions * partitionMultiplier).toInt
    val rePartitionedPatientReportedIdDf = mappedPatientReportedIdDf.repartition(repNum, $"groupid", $"datasrc", $"client_ds_id", $"localmedcode")

    val mappedPatientReportedMedDf = MapMedication.applyMedMap(rePartitionedPatientReportedIdDf, false, mapDccDf.toDF(), null, "localmedcode", dccFlag = true)
    val cols = getSelectList(mappedPatientReportedMedDf.columns.toSet)

    val resultDF = mappedPatientReportedMedDf.as("mpr")
      .join(medCategory.as("m"),
        mappedPatientReportedMedDf("groupid") === medCategory("groupid") and
          mappedPatientReportedMedDf("localcategorycode") === medCategory("mnemonic"), "left_outer"
      ).withColumn(
      "active_med_flag",
      when(mappedPatientReportedMedDf("discontinuedate").isNotNull and mappedPatientReportedMedDf("discontinuedate").between(mappedPatientReportedMedDf("medreportedtime"), current_date()), lit("N"))
        .when(mappedPatientReportedMedDf("discontinuereason").isNotNull, lit("N"))
        .when(medCategory("cui") === lit("CH001608"), lit("N"))
        .otherwise(lit("Y"))
    ).select(cols.head, cols.tail: _*)

    resultDF


  }

  def getSelectList(sourceCols: Set[String]): Array[String] = {
    sourceCols.map(s => if (s.equals("active_med_flag")) s else "mpr." + s).toArray
  }

}
