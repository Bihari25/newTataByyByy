package com.optum.oap.backend.etl.enrichment

import com.optum.oap.backend.cdrTempModel.ref_cmsnpi_partial
import com.optum.oap.backend.etl.common.MatchRegExPattern
import com.optum.oap.cdr.models._
import com.optum.oap.sparkdataloader.{RuntimeVariables, TableInfo, UserDefinedFunctionForDataLoader}
import org.apache.spark.sql.expressions.Window
import org.apache.spark.sql.functions._
import org.apache.spark.sql.types.{DoubleType, LongType, StringType}
import org.apache.spark.sql.{DataFrame, SparkSession}
import java.util.regex.Pattern
import com.optum.oap.backend.etl.common.EscapeSqlLikeString

object TEMP_ZH_PROV_PREMATCH extends TableInfo[zh_provider] {

  override def dependsOn = Set("CDR_FE_ZH_PROVIDER", "TEMP_PROV_SPEC_PREMATCH", "ZH_SPECIALTY_TIER",
    "MAP_SPECIALTY", "MAP_PROVIDER_TAXONOMY", "REF_CMSNPI", "ZCM_CREDENTIAL_MAP_PATTERN",
    "PROVIDER_CLASSIFICATION", "ICPM_ZH_PROVIDER")

  override def name = "TEMP_ZH_PROV_PREMATCH"

  override def ignoreExtraColumnsInDataFrame: Boolean = true

  override def createDataFrame(sparkSession: SparkSession,
                               loadedDependencies: Map[String, DataFrame],
                               udfMap: Map[String, UserDefinedFunctionForDataLoader],
                               runtimeVariables: RuntimeVariables): DataFrame = {
    import sparkSession.implicits._

    val providerIn = loadedDependencies("CDR_FE_ZH_PROVIDER").drop("row_source","modified_date").as[zh_provider]
    val provSpec = loadedDependencies("TEMP_PROV_SPEC_PREMATCH").as[prov_spec]
    val mapSpec = broadcast(loadedDependencies("MAP_SPECIALTY")).as[map_specialty]
    val specTier = broadcast(loadedDependencies("ZH_SPECIALTY_TIER")).as[zh_specialty_tier]
    val provTax = broadcast(loadedDependencies("MAP_PROVIDER_TAXONOMY")).as[map_provider_taxonomy]
    val cmsNPI = loadedDependencies("REF_CMSNPI").as[ref_cmsnpi_partial] //more than 256 fields, using a temp class created.
    val credMapPattern = broadcast(loadedDependencies("ZCM_CREDENTIAL_MAP_PATTERN")).as[zcm_credential_map_pattern]
    val provClassify = broadcast(loadedDependencies("PROVIDER_CLASSIFICATION")).as[provider_classification]
    val icpmProvider = loadedDependencies("ICPM_ZH_PROVIDER").as[zh_provider]

    //Union Patientaddress data coming from FE & ICPM Provider
    val zhproviderIn = providerIn.unionByName(icpmProvider)

    val name_pattern = """[^A-Z-a-z0-9 .,;!()*-_<>&#''`%$~"{}\t]"""
    val formatProviderNameUDF = udf((clientId: String, first: String, last: String, full: String, middle: String, credentials: String) => formatProviderName(clientId, first, last, full, middle, credentials))
    val withNormalizedNames = zhproviderIn.withColumn("providername", regexp_replace(formatProviderNameUDF($"groupid", $"first_name", $"last_name", $"providername", $"middle_name", $"credentials"), name_pattern, ""))
      .withColumn("first_name", regexp_replace($"first_name", name_pattern, ""))
      .withColumn("middle_name", regexp_replace($"middle_name", name_pattern, ""))
      .withColumn("last_name", regexp_replace($"last_name", name_pattern, ""))

    // Local Primary Specialty
    val withPrimSpec = findPrimarySpecialty(sparkSession, withNormalizedNames, provSpec.toDF(), mapSpec.toDF(), specTier.toDF(), provTax.toDF())
    // Credentials
    val withCred = setCredentials(sparkSession, withPrimSpec, cmsNPI.toDF(), credMapPattern.toDF())
    // Remove duplicates
    val removeDupes = deduplicateProviders(sparkSession, withCred)
    //provider exclusion
    providerExclusion(sparkSession, provClassify.toDF(), removeDupes)
  }

  def formatProviderName(clientId: String, firstName: String, lastName: String, fullName: String, middleName: String, credentials: String): String = {
    val provName = clientId match {
      case "H984442" => extendedName(firstName, lastName, fullName, middleName, credentials).trim
     //case "H788798" => smartCaps(if (fullName == null || fullName.isEmpty) lastName + ", " + firstName else fullName).trim
      case "H319046" => smartUpper(firstName = firstName, lastName = lastName, fullName = fullName, lastFirst = false).trim
      case _ => smartUpper(firstName, lastName, fullName).trim
    }
    if (provName.isEmpty)
      null
    else
      provName
  }

  def smartUpper(firstName: String, lastName: String, fullName: String, lastFirst: Boolean = true): String = {
    if (Option(lastName).getOrElse("").isEmpty)
      Option(fullName).getOrElse("").toUpperCase
    else if (lastFirst)
      (Option(lastName).getOrElse("") + ", " + Option(firstName).getOrElse("")).toUpperCase
    else
      (Option(firstName).getOrElse("") + " " + Option(lastName).getOrElse("")).toUpperCase
  }

  def extendedName(firstName: String, lastName: String, fullName: String, middleName: String, credentials: String): String = {
    if (Option(lastName).getOrElse("").isEmpty)
      smartCaps(fullName).orNull
    else
      smartCaps(Array(lastName, firstName, middleName).zipWithIndex.map { case (c, i) => if (c == null) "" else i match {
        case 0 => "" + c
        case 1 => ", " + c
        case _ => " " + c
      }
      }.mkString("")).getOrElse("") + (if (credentials != null && credentials.length > 0) " " + credentials else "")
  }

  def smartCaps(inStr: String): Option[String] = {
    val str = Option(inStr).getOrElse("")
    val lowerCasesChars = "[a-z]".r

    val wasMatched = lowerCasesChars.findFirstIn(str)
    wasMatched match {
      case None => Some(str.toLowerCase.split(' ').map(_.capitalize).mkString(" "))
      case Some(c) => Some(str)
    }
  }

  def findPrimarySpecialty(sparkSession: SparkSession, zhProv: DataFrame, provSpec: DataFrame, mapSpec: DataFrame, specTier: DataFrame, provTaxonomy: DataFrame): DataFrame = {
    import sparkSession.implicits._
    val specialties = provSpec.alias("ps").filter(coalesce($"localcodesource", lit("null")) =!= "npi")
      .join(mapSpec.alias("m"), $"localspecialtycode" === $"mnemonic" && $"ps.groupid" === $"m.groupid", "left_outer")
      .join(specTier.alias("t"), $"m.cui" === $"t.cui", "left_outer")
      .select($"ps.groupid", $"client_ds_id", $"localproviderid", $"localspecialtycode", coalesce($"local_code_order", lit(1)).as("code_order"), $"tier", $"t.cui".as("tier_cui")).distinct

    val provTaxSpecialties = provTaxonomy
      .join(provSpec.filter($"localcodesource" === "npi"), $"localspecialtycode" === $"taxonomy_code", "inner")
      .select($"specialty_cui", $"groupid", $"client_ds_id", $"localproviderid", $"localspecialtycode")

    //Should consider ordering by whether there was a mapped cui or not.
    val rankedSpecs = specialties.alias("ls").join(provTaxSpecialties.as("ns"), Seq("groupid", "client_ds_id", "localproviderid"), "left_outer")
      .select(
        $"ls.groupid", $"ls.client_ds_id", $"localproviderid", $"ls.localspecialtycode",
        row_number().over(Window.partitionBy($"groupid", $"ls.client_ds_id", $"ls.localproviderid")
          .orderBy($"tier".asc_nulls_last,
            when($"ls.tier_cui" === $"ns.specialty_cui", 1).otherwise(0).desc,
            $"code_order",
            coalesce($"ls.localspecialtycode", $"ns.localspecialtycode").desc_nulls_last)).as("prim_spec_row")
      ).filter($"prim_spec_row" === 1).alias("rs")

   zhProv.as("zh").join(rankedSpecs.alias("rs"), Seq("groupid", "client_ds_id", "localproviderid"), "left_outer")
      .select($"zh.*",
        coalesce($"rs.localspecialtycode", $"localprimaryspecialty").as("localprimaryspecialtyNew")
      ).drop("localprimaryspecialty").withColumnRenamed("localprimaryspecialtyNew", "localprimaryspecialty")

  }

  def setCredentials(sparkSession: SparkSession, zhProv: DataFrame, cmsNPI: DataFrame, credentialPatterns: DataFrame): DataFrame = {
    import sparkSession.implicits._

    val npiCredMap = cmsNPI.select($"npi".as("cms_npi"), $"prov_credential")
    val zhProvPlusNPI = zhProv.
      join(npiCredMap, $"npi" === $"cms_npi", "left_outer")
      .select($"*",when($"credentials".isNull, $"prov_credential").when($"prov_credential".isNull, $"credentials").otherwise(concat(col("credentials"), lit(", "), col("prov_credential"))).as("fullcredentials"))

    val credsAndSpecs = zhProvPlusNPI.filter($"fullcredentials".isNotNull || $"localprimaryspecialty".isNotNull).select(regexp_replace($"fullcredentials", "-", ",").as("fullcredentials"), $"localprimaryspecialty").distinct

    val credPatterns = credentialPatterns.select(cols = $"groupid", $"priority", $"txt_pattern", $"cui").orderBy($"priority", when($"groupid" === "ALL", 0).otherwise(1).desc, length($"txt_pattern").desc)
      .agg(collect_list(struct($"txt_pattern", $"cui", $"priority", $"groupid")).as("entries")).as[GroupEntries]

    val credMap = credsAndSpecs.filter($"fullcredentials".isNotNull).select("fullcredentials").distinct.crossJoin(credPatterns)
      .withColumn("mappedcredential", MatchRegExPattern.matchRegExPattern($"fullcredentials", $"entries"))
      .filter($"mappedcredential".isNotNull)
      .select($"fullcredentials".as("map_credentials"), $"mappedcredential")
    val specMap = credsAndSpecs.filter($"localprimaryspecialty".isNotNull).select("localprimaryspecialty").distinct.crossJoin(credPatterns)
      .withColumn("mappedspecialtycred", MatchRegExPattern.matchRegExPattern($"localprimaryspecialty", $"entries"))
      .filter($"mappedspecialtycred".isNotNull)
      .select($"localprimaryspecialty".as("map_localprimaryspecialty"), $"mappedspecialtycred")

    val results = zhProvPlusNPI.as("zhProv").join(credMap.as("cre"),  regexp_replace($"zhProv.fullcredentials", "-", ",") === $"cre.map_credentials", "left_outer")
      .join(specMap.as("spec"), $"zhProv.localprimaryspecialty" === $"spec.map_localprimaryspecialty", "left_outer")
      .withColumn("mappedcredentialtype", coalesce($"mappedcredential", $"mappedspecialtycred"))
      .drop("map_localprimaryspecialty", "map_credentials", "fullcredentials", "cms_npi", "prov_credential", "mappedspecialtycred", "mappedcredential")
    results
  }

  def deduplicateProviders(sparkSession: SparkSession, zhProv: DataFrame): DataFrame = {
    import sparkSession.implicits._

    val dedupeWindow = Window
      .partitionBy(zhProv("groupid"), zhProv("client_ds_id"), zhProv("localproviderid"))
      .orderBy(when($"npi".isNotNull && length($"npi") === 10, 1).otherwise(0).desc_nulls_last
        , length($"providername").desc_nulls_last
        , when($"credentials".isNotNull, 1).otherwise(0).desc
        , $"npi".asc_nulls_last
        , $"providername".asc
      )

    val result = zhProv.withColumn("rownbr", row_number().over(dedupeWindow))

    result.filter("rownbr = 1").drop("rownbr")
  }

  def providerExclusion(sparkSession: SparkSession, provClassify: DataFrame, zhproviderIn: DataFrame): DataFrame = {
    import sparkSession.implicits._
    val provClassMap = provClassify
      .select($"groupid",
        when(instr($"txt_pattern", "%") === lit(0) && $"operator" === lit("like"), lit("="))
            .otherwise($"operator").as("operator"),
        when($"operator" === lit("sql_like") || $"operator" === lit("sql_like_plus"), concat(lit("^"), EscapeSqlLikeString.escapeString($"txt_pattern"), lit("$")))
          .when($"operator" === lit("="), concat(lit("^"), EscapeSqlLikeString.escapeString($"txt_pattern"), lit("$")))
        .otherwise($"txt_pattern").as("txt_pattern"), $"flag_value", row_number().over(Window.orderBy(length($"txt_pattern").desc)).as("rownbr"))
      .agg(collect_list(struct(regexp_replace($"txt_pattern", "%", ".*").as("txt_pattern"), $"flag_value".as("cui"),($"rownbr" + when($"operator" === lit("="), lit(1)).when(substring($"operator",1, 3)=== lit("sql"), lit(2)).otherwise(lit(3))).as("priority"), $"groupid")).as("entries")).as[GroupEntries]


    val excludeMap = zhproviderIn.as("zhIn").filter($"zhIn.providername".isNotNull).select($"zhIn.providername").distinct.crossJoin(provClassMap)
      .withColumn("map_exclude_flag", MatchRegExPattern.matchRegExPattern($"zhIn.providername", $"entries"))
      .filter($"map_exclude_flag".isNotNull)
      .select($"zhIn.providername".as("map_providername"), $"map_exclude_flag")
    //populate the exclusion flag in the provider table
    zhproviderIn.alias("zhProvIn") //.drop("providerexclusionflag")
      .join(excludeMap.alias("exclMap"), $"zhProvIn.providername" <=> $"exclMap.map_providername", "left_outer")
      .withColumn("providerexclusionflag", coalesce($"map_exclude_flag", lit("N")))
      .drop("map_providername", "map_exclude_flag")


  }

}