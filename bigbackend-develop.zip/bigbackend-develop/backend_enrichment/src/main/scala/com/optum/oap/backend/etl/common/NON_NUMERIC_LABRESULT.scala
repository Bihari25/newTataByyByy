package com.optum.oap.backend.etl.common

import com.optum.oap.backend.cdrTempModel.gtt_labresult_nonnumeric
import com.optum.oap.backend.loader.EnrichmentRunTimeVariables
import com.optum.oap.cdr.models.{labresult, map_unit, unit_conversion, unit_remap, v_metadata_lab}
import com.optum.oap.sparkdataloader.{RuntimeVariables, TableInfo, UserDefinedFunctionForDataLoader}
import com.optum.oap.backend.etl.common.ExtractUom.extract_uom
import com.optum.oap.backend.etl.common.ExtractValue.extract_value
import com.optum.oap.backend.etl.common.ExtractResulttype.extract_resulttype
import com.optum.oap.backend.etl.common.ExtractRelativeindicator.extract_relativeindicator
import org.apache.spark.sql.functions._
import org.apache.spark.sql.types.DataTypes
import org.apache.spark.sql.{DataFrame, SparkSession}
import org.slf4j.LoggerFactory


object NON_NUMERIC_LABRESULT extends TableInfo[labresult] {

  private val log = LoggerFactory.getLogger(this.getClass)

  override def dependsOn = Set("GTT_LABRESULT_NONNUMERIC", "MAP_UNIT", "UNIT_REMAP", "V_METADATA_LAB", "UNIT_CONVERSION")

  override def name = "NON_NUMERIC_LABRESULT"

  override def createDataFrame(sparkSession: SparkSession,
                               loadedDependencies: Map[String, DataFrame],
                               udfMap: Map[String, UserDefinedFunctionForDataLoader],
                               runtimeVariables: RuntimeVariables): DataFrame = {

    import sparkSession.implicits._

    val gttLabResultNonNumericDf = loadedDependencies("GTT_LABRESULT_NONNUMERIC").as[gtt_labresult_nonnumeric]
    val mapUnitDf = broadcast(loadedDependencies("MAP_UNIT")).as[map_unit]
    val unitRemapDf = broadcast(loadedDependencies("UNIT_REMAP")).as[unit_remap]
    val metaDataLabDf = broadcast(loadedDependencies("V_METADATA_LAB")).as[v_metadata_lab]
    val unitConversionDf = broadcast(loadedDependencies("UNIT_CONVERSION")).as[unit_conversion]

    val groupId = runtimeVariables.asInstanceOf[EnrichmentRunTimeVariables].clientId

    val disLocalResult25 = gttLabResultNonNumericDf.select("localresult_25").where($"localresult_numeric".isNull).distinct()

    val localResult25 = disLocalResult25.select($"localresult_25",
      extract_value($"localresult_25", lit(null)).as("localresult_inferred"),
      extract_resulttype($"localresult_25").as("resulttype"),
      extract_relativeindicator($"localresult_25").as("relativeindicator"),
      extract_uom($"localresult_25").as("localunits_inferred"))

    val stdConvLabResultNonNumericDf = gttLabResultNonNumericDf.as("v")
      .join(localResult25.as("lr"), $"v.localresult_25" === $"lr.localresult_25", "left_outer")
      .join(mapUnitDf.as("mu"), lower(coalesce($"v.localunits", $"lr.localunits_inferred")) === $"mu.localcode", "left_outer")
      .join(unitRemapDf.as("lgu"), $"v.groupid" === $"lgu.groupid" && $"v.mappedcode" === $"lgu.lab" && expr("coalesce(mu.cui, 'CH999999')") === $"lgu.remap", "left_outer")
      .join(metaDataLabDf.as("mdl"), $"mdl.cui" === $"v.mappedcode", "left_outer")
      .join(unitConversionDf.as("uc"), $"uc.src_unit" === coalesce($"lgu.unit", $"mu.cui") && $"uc.dest_unit" === $"mdl.unit", "left_outer")
      .select($"v.groupid"
        , $"v.datasrc"
        , $"v.labresultid"
        , $"v.laborderid"
        , $"v.local_loinc_code"
        , $"v.facilityid"
        , $"v.encounterid"
        , $"v.patientid"
        , $"v.datecollected"
        , $"v.dateavailable"
        , $"v.resultstatus"
        , $"v.localresult"
        , $"v.localcode"
        , $"v.localname"
        , $"v.normalrange"
        , trim(lower($"v.localunits")).as("localunits")
        , $"statuscode"
        , $"v.labresult_date"
        , $"v.mappedcode"
        , $"v.mappedname"
        , $"lr.localresult_inferred".cast(DataTypes.DoubleType).as("localresult_inferred")
        , $"lr.resulttype"
        , $"lr.relativeindicator"
        , $"lr.localunits_inferred"
        , $"v.localspecimentype"
        , $"v.localtestname"
        , coalesce($"lgu.unit", $"mu.cui").as("mappedunits")
        , $"conv_fact"
        , $"mdl.unit".as("labstdunits")
        , when(coalesce($"lgu.unit", $"mu.cui") === $"mdl.unit", 1)
          .when($"conv_fact".isNotNull, $"conv_fact")
          .otherwise(null).as("stdconv")
        , $"v.client_ds_id"
        , $"v.labordereddate".cast(DataTypes.TimestampType).as("labordereddate")
        , $"v.locallisresource")

    stdConvLabResultNonNumericDf.select($"groupid"
      , $"datasrc"
      , $"labresultid"
      , $"laborderid"
      , $"local_loinc_code"
      , $"facilityid"
      , $"encounterid"
      , $"patientid"
      , $"datecollected"
      , $"dateavailable"
      , $"resultstatus"
      , $"localresult"
      , $"localcode"
      , $"localname"
      , $"normalrange"
      , $"localunits"
      , $"statuscode"
      , $"labresult_date"
      , $"mappedcode"
      , $"mappedname"
      , lit(null).cast(DataTypes.DoubleType).as("localresult_numeric")
      , $"localresult_inferred"
      , $"resulttype"
      , $"relativeindicator"
      , $"localunits_inferred"
      , $"mappedunits"
      , when($"relativeindicator" === "<", round($"localresult_inferred" - .0001, 4) * $"stdconv")
        .when($"relativeindicator" === ">", round($"localresult_inferred" + .0001, 4) * $"stdconv")
        .otherwise($"localresult_inferred" * $"stdconv").as("normalizedvalue")
      , $"localspecimentype"
      , $"client_ds_id"
      , $"localtestname"
      , $"labordereddate"
      , $"locallisresource"
      , lit(null).cast(DataTypes.StringType).as("grp_mpi")
      , lit(null).cast(DataTypes.LongType).as("hgpid")
      , lit(null).cast(DataTypes.StringType).as("mapped_qual_code")
      , lit(null).cast(DataTypes.StringType).as("mappedloinc")
    )
  }
}