package com.optum.oap.backend.etl.enrichment

import com.optum.oap.backend.etl.common.Functions.mpvList
import com.optum.oap.backend.loader.EnrichmentRunTimeVariables
import com.optum.oap.cdr.models.{int_claim_prov, map_prov_status, map_provider_taxonomy
  , map_specialty_ii, prov_pat_rel, prov_status_rollup, ref_cms_assign_proc_cds, ref_cms_assign_spec_cds
  , ref_primaryspecialty, zo_bpo_map_employer, map_predicate_values}
import com.optum.oap.sparkdataloader.{RuntimeVariables, TableInfo, UserDefinedFunctionForDataLoader}
import org.apache.spark.sql.expressions.Window
import org.apache.spark.sql.functions._
import org.apache.spark.sql.types.DataTypes
import org.apache.spark.sql.{DataFrame, SparkSession}
import org.slf4j.LoggerFactory

object MSSP_PROV_PAT_REL extends TableInfo[prov_pat_rel] {

  private val log = LoggerFactory.getLogger(this.getClass)

  override def dependsOn = Set("CDR_FE_INT_CLAIM_MEDICAL", "CDR_FE_INT_CLAIM_PROV", "CDR_FE_PROV_STATUS_ROLLUP", "MAP_PROV_STATUS"
    , "REF_PRIMARYSPECIALTY", "MAP_PROVIDER_TAXONOMY", "MAP_SPECIALTY_II", "REF_CMS_ASSIGN_SPEC_CDS", "REF_CMS_ASSIGN_PROC_CDS"
    , "MAP_PREDICATE_VALUES", "ZO_BPO_MAP_EMPLOYER")

  override def name = "MSSP_PROV_PAT_REL"

  override def createDataFrame(sparkSession: SparkSession,
                               loadedDependencies: Map[String, DataFrame],
                               udfMap: Map[String, UserDefinedFunctionForDataLoader],
                               runtimeVariables: RuntimeVariables): DataFrame = {

    import sparkSession.implicits._

    val cdrFeIntClaimMedical = loadedDependencies("CDR_FE_INT_CLAIM_MEDICAL").filter($"payer_name" === "MSSP")
    val cdrFeIntClaimProv = loadedDependencies("CDR_FE_INT_CLAIM_PROV").as[int_claim_prov]
    val cdrFeProvStatusRollup = loadedDependencies("CDR_FE_PROV_STATUS_ROLLUP").as[prov_status_rollup]
    val mapProvStatus = broadcast(loadedDependencies("MAP_PROV_STATUS")).as[map_prov_status]
    val refPrimarySpeciatly = broadcast(loadedDependencies("REF_PRIMARYSPECIALTY")).as[ref_primaryspecialty]
    val mapProvTaxonomy = broadcast(loadedDependencies("MAP_PROVIDER_TAXONOMY")).as[map_provider_taxonomy]
    val mapSpecialtyII = broadcast(loadedDependencies("MAP_SPECIALTY_II")).as[map_specialty_ii]
    val refCmsAssignSpecCds = broadcast(loadedDependencies("REF_CMS_ASSIGN_SPEC_CDS")).as[ref_cms_assign_spec_cds]
    val refCmsAssignProcCds = broadcast(loadedDependencies("REF_CMS_ASSIGN_PROC_CDS")).as[ref_cms_assign_proc_cds]
    val zoBpoMapEmployer = broadcast(loadedDependencies("ZO_BPO_MAP_EMPLOYER")).as[zo_bpo_map_employer]
    val mapPredicateValues = broadcast(loadedDependencies("MAP_PREDICATE_VALUES")).as[map_predicate_values]
    .filter($"data_src" === "CMS_CCLF" && $"entity" === "PROV_PAT_REL" && $"table_name" === "PROV_PAT_REL"
      && $"column_name" === "USE_CMS_ATTRIBUTION" && $"column_value" === "Y")

    val groupId = runtimeVariables.asInstanceOf[EnrichmentRunTimeVariables].clientId

    if (cdrFeIntClaimMedical.isEmpty)
      sparkSession.emptyDataset[prov_pat_rel].toDF()
    else {
      // Get mpvListValue
      val assignNonDomestic = mpvList(broadcast(loadedDependencies("MAP_PREDICATE_VALUES")),
        groupId,
        null,
        "CMS_CCLF",
        "PROV_PAT_REL",
        "PROV_PAT_REL",
        "ASSIGN_NON_DOMESTIC"
      ).distinct.mkString(",")

      val dateRange = broadcast(cdrFeIntClaimMedical.alias("med")
        .join(mapPredicateValues.alias("mpv"), $"med.groupid" === $"mpv.groupid" && $"med.client_ds_id" === $"mpv.client_ds_id")
        .groupBy($"med.client_ds_id")
        .agg(
          date_add(add_months(max($"service_date"), -13), 1).as("start_date_1")
          , add_months(max($"service_date"), -1).as("end_date_1")
          , trunc(add_months(max($"service_date"), -13), "Year").as("start_date_2")
          , date_add(add_months(trunc(add_months(max($"service_date"), -1), "Year"), -1), 30).as("end_date_2")
          , trunc(add_months(max($"service_date"), -25), "Year").as("start_date_3")
          , date_add(add_months(trunc(add_months(max($"service_date"), -13), "Year"), -1), 30).as("end_date_3")
          , trunc(add_months(max($"service_date"), -37), "Year").as("start_date_4")
          , date_add(add_months(trunc(add_months(max($"service_date"), -25), "Year"), -1), 30).as("end_date_4")
          , trunc(add_months(max($"service_date"), -49), "Year").as("start_date_5")
          , date_add(add_months(trunc(add_months(max($"service_date"), -37), "Year"), -1), 30).as("end_date_5")
        )
        .select($"client_ds_id"
          , expr("stack(5, start_date_1, end_date_1, 'PER1', start_date_2, end_date_2, 'PER2', start_date_3, end_date_3, 'PER3'" +
            ", start_date_4, end_date_4, 'PER4', start_date_5, end_date_5, 'PER5') as (start_date, end_date, timeperiod)")
        ))

      val provsTemp = cdrFeIntClaimProv.alias("prv").filter($"prov_npi".isNotNull)
        .select(
          $"prv.groupid"
          , $"prv.prov_npi".as("npi")
          , $"prv.prov_status_id"
          , $"prv.prov_spclty_cd".as("prov_specialty")
          , $"prv.eff_date".as("startdate")
          , coalesce($"prv.end_date", to_date(lit("99991231"), "yyyyMMdd")).as("enddate")
          , lit(2).as("priority")
        )
        .join(mapProvStatus.alias("mps"), $"prv.groupid" === $"mps.groupid" && $"prv.prov_status_id" === $"mps.localcode", "left_outer")
        .join(cdrFeProvStatusRollup.alias("psr"), $"prv.groupid" === $"psr.groupid" && $"prv.prov_status_id" === $"psr.prov_status_id", "left_outer")
        .crossJoin(dateRange.groupBy($"client_ds_id").agg(max($"end_date").as("end_date")).alias("c"))
        .select(
          $"prv.groupid"
          , $"npi"
          , $"prov_specialty"
          , when(coalesce($"psr.prov_status_rollup", $"psr.prov_status_id", $"mps.mappedvalue") === "Y" &&
            date_format($"c.end_date", "yyyyMMdd").between(date_format($"startdate", "yyyyMMdd"), date_format($"enddate", "yyyyMMdd")), lit(1)).otherwise(lit(0)).as("domestic_ind")
          , row_number.over(Window.partitionBy($"npi")
            .orderBy($"priority".desc_nulls_last, $"enddate".desc_nulls_last, $"startdate".desc_nulls_last,
            when(coalesce($"psr.prov_status_rollup", $"psr.prov_status_id", $"mps.mappedvalue") === "Y"
              && date_format($"c.end_date", "yyyyMMdd").between(date_format($"startdate", "yyyyMMdd"), date_format($"enddate", "yyyyMMdd"))
              , lit(1)).otherwise(lit(0)).desc_nulls_last)).as("rn")
        ).filter($"rn" === 1)

      val provsFinal = refPrimarySpeciatly.alias("a")
        .join(provsTemp.alias("b"), $"a.npi" === $"b.npi", "fullouter")
        .join(mapProvTaxonomy.alias("c"), $"a.primarycode" === $"c.taxonomy_code", "left_outer")
        .join(mapSpecialtyII.alias("d"), $"b.groupid" === $"d.groupid" && $"b.prov_specialty" === $"d.local_code", "left_outer")
        .join(refCmsAssignSpecCds.alias("e"), coalesce($"c.ii_code", $"d.ii_code") === $"e.code" && $"e.code_type" === "SPECIALTY_ID", "left_outer")
        .select(
          coalesce($"a.npi", $"b.npi").as("npi")
          , when($"e.elig_prov_id" === "3" && $"SP2" === "Other Professional Providers", lit("PCP-MIDLEVEL"))
            .when($"e.elig_prov_id" === "3", lit("PCP"))
            .when($"e.elig_prov_id" === "4", lit("SPECIALIST"))
            .otherwise(lit("OTHER")).as("provider_type")
          , coalesce($"domestic_ind", lit(0)).as("domestic_ind")
        )

      val claimsDf = cdrFeIntClaimMedical.alias("a")
        .join(mapPredicateValues.alias("mpv"), $"a.groupid" === $"mpv.groupid" && $"a.client_ds_id" === $"mpv.client_ds_id")
        .join(refCmsAssignProcCds.alias("b"), $"a.proc_code" === $"b.proc_cd" && $"b.code_type".isin("CPT4", "HCPCS"), "left_outer")
        .join(refCmsAssignProcCds.alias("c"), $"a.revenue_code" === $"c.proc_cd" && $"c.code_type".isin("REV"), "left_outer")
        .join(dateRange.alias("d"), $"a.client_ds_id" === $"d.client_ds_id"
          && date_format($"a.service_date", "yyyyMMdd").between(date_format($"d.start_date", "yyyyMMdd"), date_format($"d.end_date", "yyyyMMdd")), "inner")
        .join(provsFinal.alias("e"), when($"a.datasrc" === "aco_a", $"a.attnd_prov_id")
          .when($"a.datasrc" === "aco_b_dme", $"a.ordering_prov_id")
          .otherwise($"a.servicing_prov_id") === $"e.npi", "left_outer")
        .filter($"b.proc_cd".isNotNull || $"c.proc_cd".isNotNull)
        .select(
          $"a.groupid".as("groupid")
          , $"a.client_ds_id".as("client_ds_id")
          , $"member_id"
          , when($"a.datasrc" === "aco_a", $"a.attnd_prov_id")
            .when($"a.datasrc" === "aco_b_dme", $"a.ordering_prov_id")
            .otherwise($"a.servicing_prov_id").as("provider_id")
          , $"service_from_date"
          , $"service_date"
          , coalesce($"allowed_amt", lit(1.25) * $"payment_amt").as("allowed_amt")
          , when($"e.provider_type" === "PCP", $"e.provider_type")
            .when($"a.type_of_bill_code".isNotNull && $"a.type_of_bill_code".like("71%") && $"c.proc_cd".isNotNull, lit("PCP"))
            .when($"a.type_of_bill_code".isNull && $"a.place_of_service" === "72" && $"c.proc_cd".isNotNull, lit("PCP"))
            .when($"a.type_of_bill_code".isNotNull && $"a.type_of_bill_code".like("77%") && $"c.proc_cd".isNotNull, lit("PCP"))
            .when($"a.type_of_bill_code".isNull && $"a.place_of_service" === "50" && $"c.proc_cd".isNotNull, lit("PCP"))
            .when($"e.provider_type".isin("PCP-MIDLEVEL", "SPECIALIST"), $"e.provider_type")
            .otherwise(lit("OTHER")).as("provider_type")
          , $"domestic_ind"
          , $"contract_id"
          , $"d.start_date".as("start_date")
          , $"d.end_date".as("end_date")
          , $"d.timeperiod".as("timeperiod")
        ).distinct()
        .filter($"provider_type" =!= "OTHER")

      val claimsDf1 = claimsDf.groupBy($"groupid", $"client_ds_id", $"timeperiod", $"start_date", $"end_date", $"member_id", $"provider_id", $"provider_type", $"domestic_ind")
        .agg(
          max($"service_date").as("most_recent_service")
          , size(collect_set($"service_from_date")).as("visit_cnt")
          , sum($"allowed_amt").as("sum_allowed")
          , max($"contract_id").as("contract_id")
        ).select($"timeperiod", $"start_date", $"end_date", $"member_id", $"provider_id", $"provider_type"
        , $"domestic_ind", $"most_recent_service", $"visit_cnt", $"sum_allowed", $"contract_id", $"client_ds_id", $"groupid")

      val claimsDf2 = claimsDf1
        .select($"*"
          , sum(when($"domestic_ind" === 1 && $"provider_type".like("PCP%"), $"sum_allowed")
            .otherwise(lit(0))).over(Window.partitionBy($"client_ds_id", $"member_id")).as("tot_allowed_dom_pcp")
          , sum(when($"domestic_ind" === 0 && $"provider_type".like("PCP%"), $"sum_allowed")
            .otherwise(lit(0))).over(Window.partitionBy($"client_ds_id", $"member_id")).as("tot_allowed_non_dom_pcp")
          , sum(when($"domestic_ind" === 1 && !$"provider_type".like("PCP%"), $"sum_allowed")
            .otherwise(lit(0))).over(Window.partitionBy($"client_ds_id", $"member_id")).as("tot_allowed_dom_spec")
          , sum(when($"domestic_ind" === 0 && !$"provider_type".like("PCP%"), $"sum_allowed")
            .otherwise(lit(0))).over(Window.partitionBy($"client_ds_id", $"member_id")).as("tot_allowed_non_dom_spec")
          , sum(when($"domestic_ind" === 1 && $"provider_type".like("PCP%"), $"visit_cnt")
            .otherwise(lit(0))).over(Window.partitionBy($"client_ds_id", $"member_id")).as("tot_visits_dom_pcp")
          , sum(when($"domestic_ind" === 0 && $"provider_type".like("PCP%"), $"visit_cnt")
            .otherwise(lit(0))).over(Window.partitionBy($"client_ds_id", $"member_id")).as("tot_visits_non_dom_pcp")
          , sum(when($"domestic_ind" === 1 && !$"provider_type".like("PCP%"), $"visit_cnt")
            .otherwise(lit(0))).over(Window.partitionBy($"client_ds_id", $"member_id")).as("tot_visits_dom_spec")
          , sum(when($"domestic_ind" === 0 && !$"provider_type".like("PCP%"), $"visit_cnt")
            .otherwise(lit(0))).over(Window.partitionBy($"client_ds_id", $"member_id")).as("tot_visits_non_dom_spec")
          , sum(when($"provider_type" === "PCP", lit(1)).otherwise(lit(0)))
            .over(Window.partitionBy($"client_ds_id", $"member_id")).as("count_pcp")
        )

      val claimsAgg = if (assignNonDomestic.equalsIgnoreCase("'Y'")) {
        claimsDf2
          .filter(($"domestic_ind" === 1
            &&
            ($"provider_type".like("PCP%") && (($"tot_allowed_dom_pcp" > $"tot_allowed_non_dom_pcp") || ($"tot_allowed_dom_pcp" === $"tot_allowed_non_dom_pcp" && $"tot_visits_dom_pcp".geq($"tot_visits_non_dom_pcp"))) && $"count_pcp".gt(0)) || ($"provider_type" === "SPECIALIST" && (($"tot_allowed_dom_spec" > $"tot_allowed_non_dom_spec") || ($"tot_allowed_dom_spec" === $"tot_allowed_non_dom_spec" && $"tot_visits_dom_spec".geq($"tot_visits_non_dom_spec"))))
            ) || $"domestic_ind" === 0
          )
          .select($"*"
            , row_number().over(Window.partitionBy($"client_ds_id", $"timeperiod", $"member_id", substring($"provider_type", 1, 3))
              .orderBy($"domestic_ind".desc_nulls_last, $"provider_type".asc_nulls_last, $"sum_allowed".desc_nulls_last
                , $"visit_cnt".desc_nulls_last, $"most_recent_service".desc_nulls_last, $"provider_id".asc_nulls_last)).as("rn")
          )
      } else {
        claimsDf2
          .filter($"domestic_ind" === 1
            &&
            ($"provider_type".like("PCP%") && (($"tot_allowed_dom_pcp" > $"tot_allowed_non_dom_pcp") || ($"tot_allowed_dom_pcp" === $"tot_allowed_non_dom_pcp" && $"tot_visits_dom_pcp".geq($"tot_visits_non_dom_pcp"))) && $"count_pcp".gt(0)) || ($"provider_type" === "SPECIALIST" && (($"tot_allowed_dom_spec" > $"tot_allowed_non_dom_spec") || ($"tot_allowed_dom_spec" === $"tot_allowed_non_dom_spec" && $"tot_visits_dom_spec".geq($"tot_visits_non_dom_spec"))))
          )
          .select($"*"
            , row_number().over(Window.partitionBy($"client_ds_id", $"timeperiod", $"member_id", substring($"provider_type", 1, 3))
              .orderBy($"domestic_ind".desc_nulls_last, $"provider_type".asc_nulls_last, $"sum_allowed".desc_nulls_last
                , $"visit_cnt".desc_nulls_last, $"most_recent_service".desc_nulls_last, $"provider_id".asc_nulls_last)).as("rn")
          )
      }

      val claimsAggunion = claimsAgg.alias("ca1").filter($"ca1.provider_type".like("PCP%") && $"ca1.rn" === 1).select($"ca1.*", lit(1).as("priority"))
        .unionByName(claimsAgg.alias("ca2").filter($"ca2.provider_type" === "SPECIALIST" && $"ca2.rn" === 1).select($"ca2.*", lit(2).as("priority")))

      val zoBpoMapEmp = zoBpoMapEmployer.filter($"groupid" === groupId).groupBy($"client_ds_id")
        .agg(max($"employeraccountid").as("employeracctid"))

      claimsAggunion.alias("ca")
        .crossJoin(zoBpoMapEmp.alias("bpo"))
        .select(
          $"groupid"
          , $"ca.client_ds_id"
          , lit("cms_cclf").as("datasrc")
          , $"member_id".as("patientid")
          , $"provider_id".as("providerid")
          , lit("PCP").as("localrelshipcode")
          , when($"timeperiod" === "PER1", trunc($"end_date", "Year"))
            .otherwise($"start_date").cast(DataTypes.TimestampType).as("startdate")
          , when($"timeperiod" === "PER1", date_add(add_months(trunc($"end_date", "Year"), 12), -1))
            .otherwise($"end_date").cast(DataTypes.TimestampType).as("enddate")
          , coalesce($"contract_id", $"bpo.employeracctid").as("contract_id")
          , lit(null).cast(DataTypes.StringType).as("mstrprovid")
          , lit(null).cast(DataTypes.StringType).as("grp_mpi")
          , lit(null).cast(DataTypes.LongType).as("hgpid")
          , lit(null).cast(DataTypes.StringType).as("plan_level_cd")
          , lit(null).cast(DataTypes.StringType).as("prov_affil_id")
          , row_number().over(Window.partitionBy($"ca.client_ds_id", $"timeperiod", $"member_id").orderBy($"domestic_ind".desc_nulls_last, $"priority".asc_nulls_last)).as("rn_out")
        )
        .filter($"rn_out" === 1).drop("rn_out")
    }
  }

}