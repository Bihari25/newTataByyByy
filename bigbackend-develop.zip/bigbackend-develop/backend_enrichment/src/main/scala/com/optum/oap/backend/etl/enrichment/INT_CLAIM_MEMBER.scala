package com.optum.oap.backend.etl.enrichment

import com.optum.oap.backend.loader.EnrichmentRunTimeVariables
import com.optum.oap.cdr.models.int_claim_member
import com.optum.oap.cdr.models.map_predicate_values
import com.optum.oap.sparkdataloader.{RuntimeVariables, TableInfo, UserDefinedFunctionForDataLoader}
import org.apache.spark.sql.{DataFrame, SparkSession}
import org.slf4j.LoggerFactory

object INT_CLAIM_MEMBER extends TableInfo[int_claim_member] with INT_CLAIM_CLEANUP {

  private val log = LoggerFactory.getLogger(this.getClass)

  override def dependsOn = Set("CDR_FE_INT_CLAIM_MEMBER", "MAP_PREDICATE_VALUES")

  override def name = "INT_CLAIM_MEMBER"

  override def ignoreExtraColumnsInDataFrame: Boolean = true

  override def regexReplaceColumns: Set[String] = Set("emp_acct_id", "benefit_plan_code", "contract_id", "contract_type_code"
    , "coverage_status_code", "employee_type", "ii_mem_userdef_1", "ii_mem_userdef_2", "ii_mem_userdef_3", "ii_mem_userdef_4"
    , "product_code", "pcp_prov_affil_id")

  override def createDataFrame(sparkSession: SparkSession,
                               loadedDependencies: Map[String, DataFrame],
                               udfMap: Map[String, UserDefinedFunctionForDataLoader],
                               runtimeVariables: RuntimeVariables): DataFrame = {
    import sparkSession.implicits._

    val memIn = loadedDependencies("CDR_FE_INT_CLAIM_MEMBER")
    val mapPredicateValues = loadedDependencies("MAP_PREDICATE_VALUES").as[map_predicate_values]
    val groupId = runtimeVariables.asInstanceOf[EnrichmentRunTimeVariables].clientId
    cleanUp(groupId, mapPredicateValues.toDF(), memIn)
  }
}