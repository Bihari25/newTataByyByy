package com.optum.oap.backend.etl.enrichment

import com.optum.oap.backend.etl.common.{MapMasterIds, MapMedication}
import com.optum.oap.backend.loader.EnrichmentRunTimeVariables
import com.optum.oap.cdr.models.{immunization, patient_mpi, zh_med_map_dcc}
import com.optum.oap.sparkdataloader.{RuntimeVariables, TableInfo, UserDefinedFunctionForDataLoader}
import org.apache.spark.sql.functions.broadcast
import org.apache.spark.sql.{DataFrame, SparkSession}
import org.slf4j.LoggerFactory

object IMMUNIZATION extends TableInfo[immunization] {

  val log = LoggerFactory.getLogger(this.getClass)

  override def dependsOn = Set("CDR_FE_IMMUNIZATION", "PATIENT_MPI", "ZH_MED_MAP_DCC")

  override def name = "IMMUNIZATION"

  override def saveDataFrameToParquet: Boolean = true

  override def partitions: Int = 32

  override def skipTable: Boolean = false

  override def ignoreExtraColumnsInDataFrame: Boolean = true

  override def createDataFrame(sparkSession: SparkSession,
                               loadedDependencies: Map[String, DataFrame],
                               udfMap: Map[String, UserDefinedFunctionForDataLoader],
                               runtimeVariables: RuntimeVariables): DataFrame = {
    import sparkSession.implicits._

    val immunizationIn = loadedDependencies("CDR_FE_IMMUNIZATION").as[immunization]
    val patXref = loadedDependencies("PATIENT_MPI").as[patient_mpi]
    val mapDccDf = broadcast(loadedDependencies("ZH_MED_MAP_DCC")).as[zh_med_map_dcc]

    val mappedImmunizationIdDf = MapMasterIds.mapPatientIds(immunizationIn.toDF, patXref.toDF, false)

    val partitionMultiplier = EnrichmentRunTimeVariables(runtimeVariables).partitionMultiplier
    val repNum = Math.ceil(partitions * partitionMultiplier).toInt

    val repartitionedImmunization = mappedImmunizationIdDf.repartition(repNum, $"groupid", $"datasrc", $"client_ds_id", $"localimmunizationcd")
    MapMedication.applyMedMap(repartitionedImmunization, false, mapDccDf.toDF(), null, "localimmunizationcd", dccFlag = true)

  }


}
