package com.optum.oap.backend.etl.enrichment

import com.optum.oap.cdr.models.{contract_type_rollup, int_claim_member}
import com.optum.oap.sparkdataloader.{RuntimeVariables, TableInfo, UserDefinedFunctionForDataLoader}
import org.apache.spark.sql.expressions.Window
import org.apache.spark.sql.functions.{coalesce, lit, _}
import org.apache.spark.sql.types._
import org.apache.spark.sql.{DataFrame, SparkSession}
import org.slf4j.LoggerFactory

object CONTRACT_TYPE_ROLLUP extends TableInfo[contract_type_rollup] {

  private val log = LoggerFactory.getLogger(this.getClass)

  override def dependsOn = Set("CDR_FE_CONTRACT_TYPE_ROLLUP", "INT_CLAIM_MEMBER")

  override def name = "CONTRACT_TYPE_ROLLUP"

  override def partitions: Int = 32

  override def createDataFrame(sparkSession: SparkSession,
                               loadedDependencies: Map[String, DataFrame],
                               udfMap: Map[String, UserDefinedFunctionForDataLoader],
                               runtimeVariables: RuntimeVariables): DataFrame = {

    import sparkSession.implicits._

    val ContractTypeRollup = loadedDependencies("CDR_FE_CONTRACT_TYPE_ROLLUP").as[contract_type_rollup]
    val intClaimMember = loadedDependencies("INT_CLAIM_MEMBER").as[int_claim_member]

    //Origin Front end Contract Type Rollup table
    val cdrContractTypeRollup = ContractTypeRollup.select($"client_ds_id",
      $"contract_type_code",
      $"contract_type_desc",
      $"contract_type_lv1",
      $"contract_type_lv1_desc",
      $"contract_type_lv2",
      $"contract_type_lv2_desc",
      $"datasrc",
      $"groupid")

    //TAKING DISTINCT contract_type_code FROM THE CONTRACT TYPE ROLLUP TABLE
    val cdrFeContractTypeRollup = cdrContractTypeRollup.dropDuplicates("contract_type_code")

    //SELECTING RECORDS OF INTCLAIMMEMBER TABLE WHOSE contract_type_code ARE NOT IN THE CONTRACT TYPE ROLLUP TABLE
    val intclaimmember2 = intClaimMember.alias("icm").join(cdrFeContractTypeRollup.alias("cdr"),
      $"icm.contract_type_code" === $"cdr.contract_type_code", "left")
      .select(
        $"icm.groupid"
        , $"icm.client_ds_id"
        , $"icm.contract_type_code"
        , lit("int_claim_member").cast(StringType).as("datasrc")
        , substring(concat(lit("UNDEFINED ("), $"icm.contract_type_code",
          lit(")")), 1, 150).cast(StringType).as("contract_type_desc")
        , $"cdr.contract_type_lv2", $"cdr.contract_type_lv2_desc"
        , $"cdr.contract_type_lv1", $"cdr.contract_type_lv1_desc")
      .where($"icm.contract_type_code".isNotNull
        && length($"icm.contract_type_code") <= 30
        && $"cdr.contract_type_code".isNull)
      .groupBy($"groupid", $"icm.contract_type_code", $"datasrc", $"contract_type_desc",
        $"cdr.contract_type_lv2", $"cdr.contract_type_lv2_desc",
        $"cdr.contract_type_lv1", $"cdr.contract_type_lv1_desc")
      .agg(min($"client_ds_id").as("client_ds_id"))

    //NOW UNION THE MISSING RECORDS FETCHED FROM INTCLAIMMEMBER AND THE UNION CONTRACT ROLLUP TABLE
    val cdrContractTypeRollup1 = cdrContractTypeRollup.unionByName(intclaimmember2)

    //APPLYING ADDITIONAL TRANSFORMATIONS ON THE UNION
    val rollup = cdrContractTypeRollup1.alias("cdr1").select(
      $"cdr1.groupid".as("groupid")
      , $"cdr1.datasrc".as("datasrc")
      , $"cdr1.client_ds_id".as("client_ds_id")
      , $"cdr1.contract_type_code".as("contract_type_code")
      , substring(coalesce($"cdr1.contract_type_desc",
        concat(lit("UNDEFINED ("), $"cdr1.contract_type_code", lit(")"))),
        1, 150).as("contract_type_desc")
      , substring(coalesce($"cdr1.contract_type_lv2",
        concat(lit("3."), $"cdr1.contract_type_code")),
        1, 30).as("contract_type_lv2")
      , substring(when($"cdr1.contract_type_lv2".isNull,
        coalesce($"cdr1.contract_type_desc",
          concat(lit("UNDEFINED ("), $"cdr1.contract_type_code", lit(")"))))
        .otherwise(coalesce($"cdr1.contract_type_lv2_desc",
          concat(lit("UNDEFINED ("), $"cdr1.contract_type_lv2", lit(")")))),
        1, 150).as("contract_type_lv2_desc")
      , substring(coalesce($"cdr1.contract_type_lv1",
        when($"cdr1.contract_type_lv2".isNotNull,
          concat(lit("2."), $"cdr1.contract_type_lv2"))
          .otherwise(concat(lit("3."), $"cdr1.contract_type_code"))),
        1, 30).as("contract_type_lv1")
      , substring(when($"cdr1.contract_type_lv1".isNull,
        when($"cdr1.contract_type_lv2".isNull, coalesce($"cdr1.contract_type_desc",
          concat(lit("UNDEFINED ("), $"cdr1.contract_type_code", lit(")"))))
          .otherwise(coalesce($"cdr1.contract_type_lv2_desc",
            concat(lit("UNDEFINED ("), $"cdr1.contract_type_lv2", lit(")")))))
        .otherwise(coalesce($"cdr1.contract_type_lv1_desc",
          concat(lit("UNDEFINED ("), $"cdr1.contract_type_lv1", lit(")")))),
        1, 150).as("contract_type_lv1_desc")
      , row_number().over(Window.partitionBy($"cdr1.contract_type_code")
        .orderBy(
          when($"cdr1.contract_type_desc".isNotNull, lit(0)).otherwise(lit(1)),
          when($"cdr1.contract_type_lv2".isNotNull, lit(0)).otherwise(lit(1)),
          when($"cdr1.contract_type_lv1".isNotNull, lit(0)).otherwise(lit(1)),
          $"cdr1.contract_type_desc",
          $"cdr1.contract_type_lv2",
          $"cdr1.contract_type_lv1")).as("rn"))
      .where($"cdr1.contract_type_code".isNotNull &&
        length($"cdr1.contract_type_code") <= 30 &&
        $"rn" === 1).drop($"rn")

    rollup.toDF()

  }
}
