package com.optum.oap.backend.etl.encgrps

import com.optum.oap.backend.cdrTempModel.temp_encounter_prindx
import com.optum.oap.sparkdataloader.QueryAndMetadata


object TEMP_ENCOUNTER_PRINDX extends QueryAndMetadata[temp_encounter_prindx] {
  override def name: String = "TEMP_ENCOUNTER_PRINDX"

  override def sparkSql: String = """select  dx.groupid, eeg.grp_mpi, eeg.ENCOUNTER_GRP_NUM, dx.encounterid, dx.client_ds_id, dx.datasrc as dx_datasrc, mappeddiagnosis, dx_timestamp
, coalesce(primarydiagnosis,0) as primarydiagnosis, encounteridtype
, coalesce(codetype,'ICD9') as codetype
, case when codetype = 'ICD10' then '0' else '9' end as icd_ver

from
DIAGNOSIS dx
inner join ENCOUNTER_ENCOUNTER_GRP eeg on (dx.groupid = eeg.groupid and dx.encounterid = eeg.encounterid and dx.client_ds_id = eeg.client_ds_id)
where hosp_dx_flag = 'Y' 
and mappeddiagnosis is not null
and length(mappeddiagnosis) < 9
and codetype in ('ICD9','ICD10')
group by dx.groupid, eeg.grp_mpi, ENCOUNTER_GRP_NUM, dx.encounterid, dx.client_ds_id, dx.datasrc, mappeddiagnosis, dx_timestamp, coalesce(primarydiagnosis,0), encounteridtype
, coalesce(codetype,'ICD9'), case when codetype = 'ICD10' then '0' else '9' end"""

  override def dependsOn: Set[String] = Set("DIAGNOSIS","ENCOUNTER_ENCOUNTER_GRP")
}

