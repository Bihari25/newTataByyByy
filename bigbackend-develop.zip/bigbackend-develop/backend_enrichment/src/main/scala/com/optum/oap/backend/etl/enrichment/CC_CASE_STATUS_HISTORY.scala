package com.optum.oap.backend.etl.enrichment

import com.optum.oap.backend.etl.common.MapMasterIds
import com.optum.oap.cdr.models.{cc_case_status_history, patient_mpi}
import com.optum.oap.sparkdataloader.{RuntimeVariables, TableInfo, UserDefinedFunctionForDataLoader}
import org.apache.spark.sql.{DataFrame, SparkSession}
import org.slf4j.LoggerFactory

object CC_CASE_STATUS_HISTORY extends TableInfo[cc_case_status_history]{

  val log = LoggerFactory.getLogger(this.getClass)

  override def dependsOn = Set("CDR_FE_CC_CASE_STATUS_HISTORY", "PATIENT_MPI")

  override def name = "CC_CASE_STATUS_HISTORY"

  override def saveDataFrameToParquet: Boolean = true

  override def partitions: Int = 32

  override def skipTable: Boolean = false

  override def ignoreExtraColumnsInDataFrame: Boolean = true

  override def createDataFrame(sparkSession: SparkSession,
                               loadedDependencies: Map[String, DataFrame],
                               udfMap: Map[String, UserDefinedFunctionForDataLoader],
                               runtimeVariables: RuntimeVariables): DataFrame = {
    import sparkSession.implicits._

    val ccCaseStatusHistoryIn = loadedDependencies("CDR_FE_CC_CASE_STATUS_HISTORY").as[cc_case_status_history]
    val patXref = loadedDependencies("PATIENT_MPI").as[patient_mpi]

    MapMasterIds.mapPatientIds(ccCaseStatusHistoryIn.toDF, patXref.toDF, false)
  }

}
