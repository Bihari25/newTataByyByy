package com.optum.oap.backend.etl.summary

import com.optum.oap.backend.etl.common.CDRConstants
import com.optum.oap.cdr.models.{pat_proc_summary, proceduredo}
import com.optum.oap.sparkdataloader.{RuntimeVariables, TableInfo, UserDefinedFunctionForDataLoader}
import org.apache.spark.sql.functions.{date_format, _}
import org.apache.spark.sql.types.{IntegerType, StringType}
import org.apache.spark.sql.{DataFrame, SparkSession}
import org.slf4j.LoggerFactory

object PAT_PROC_SUMMARY extends TableInfo[pat_proc_summary] {

  val log = LoggerFactory.getLogger( this.getClass )

  override def dependsOn = Set( "PROCEDUREDO" )

  override def name = "PAT_PROC_SUMMARY"

  override def saveDataFrameToParquet: Boolean = true

  override def partitions: Int = 256

  override def skipTable: Boolean = false

  override def ignoreExtraColumnsInDataFrame: Boolean = false

  override def createDataFrame( sparkSession: SparkSession,
                                loadedDependencies: Map[String, DataFrame],
                                udfMap: Map[String, UserDefinedFunctionForDataLoader],
                                runtimeVariables: RuntimeVariables ): DataFrame = {

    import sparkSession.implicits._

    val proceduredo = loadedDependencies( "PROCEDUREDO" ).as[proceduredo]

    val summary = proceduredo
      .filter( 'mappedcode.isNotNull && 'grp_mpi.isNotNull )
      .select(
        'groupid,
        'grp_mpi,
        'mappedcode,
        coalesce( 'codetype, lit( "UNKNOWN" ) ).alias( "codetype" ),
        date_format( 'proceduredate, "yyyy" ).alias( "dt_yr" ),
        quarter( 'proceduredate ).cast( StringType ).alias( "dt_qtr" ),
        date_format( 'proceduredate, "MM" ).alias( "dt_month" ),
        date_format( 'proceduredate, CDRConstants.DATE_FORMAT_4Y2M2D ).alias( "dt_yyyymmdd" )
      )
      .groupBy( "groupid", "grp_mpi", "mappedcode", "codetype", "dt_yr", "dt_qtr", "dt_month" )
      .agg( countDistinct( 'dt_yyyymmdd ).cast( IntegerType ).alias( "cnt" ) )

    summary.select( "groupid", "grp_mpi", "mappedcode", "codetype", "dt_yr", "dt_qtr", "dt_month", "cnt" )
  }
}
