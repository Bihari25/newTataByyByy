package com.optum.oap.backend.etl.encgrps

import com.optum.oap.backend.cdrTempModel.temp_cmsinclude
import com.optum.oap.backend.etl.common.TimestampTruncate
import com.optum.oap.sparkdataloader.{RuntimeVariables, TableInfo, UserDefinedFunctionForDataLoader}
import org.apache.spark.sql.functions._
import org.apache.spark.sql.types.LongType
import org.apache.spark.sql.{DataFrame, SparkSession}

object TEMP_CMSINCLUDE extends TableInfo[temp_cmsinclude] {
  override def name: String = "TEMP_CMSINCLUDE"

  override def partitions: Int = 32

  override def dependsOn: Set[String] = Set("TEMP_VISIT_ENCTR","TEMP_ENCOUNTER_SORT","ZH_FACILITY_ROLLUP","ENCOUNTER_ENCOUNTER_GRP","TEMP_ENCOUNTER_GRP_PDX","MAP_DISCHARGE_DISPOSITION")

  override protected def createDataFrame(sparkSession: SparkSession, loadedDependencies: Map[String, DataFrame],
                                         udfMap: Map[String, UserDefinedFunctionForDataLoader], runtimeVariables: RuntimeVariables): DataFrame = {
    import sparkSession.implicits._

    val encounterEncounterGrp = loadedDependencies("ENCOUNTER_ENCOUNTER_GRP")
    val tempVisitEnctr = loadedDependencies("TEMP_VISIT_ENCTR")
    val tempEncounterSort = loadedDependencies("TEMP_ENCOUNTER_SORT")
    val zhFacilityRollup = broadcast(loadedDependencies("ZH_FACILITY_ROLLUP"))
    val tempEncounterGrpPdx = loadedDependencies("TEMP_ENCOUNTER_GRP_PDX")
    val mapDischargeDisposition = broadcast(loadedDependencies("MAP_DISCHARGE_DISPOSITION"))

    val encounterGrpsWithCorrectPatientType = encounterEncounterGrp.where(
      $"encounteridtype" === "MASTER" and $"patienttype" === "CH000106"
    ).select($"groupid", $"grp_mpi", $"encounter_grp_num")

    encounterEncounterGrp.as("eeg")
      .join(encounterGrpsWithCorrectPatientType.as("limiter"), Seq("groupid", "grp_mpi", "encounter_grp_num")) // this limits to encounter_grp_num with correct master patienttype
      .join(tempVisitEnctr.as("ce"), $"ce.groupid" === $"eeg.groupid" and $"ce.encounterid" === $"eeg.encounterid" and $"ce.client_ds_id" === $"eeg.client_ds_id", "left_outer")
      .join(tempEncounterSort.as("es"), $"eeg.encounter_grp_num" === $"es.encounter_grp_num" and $"ce.encounterid" === $"es.encounterid" and $"ce.client_ds_id" === $"es.client_ds_id", "left_outer")
      .join(zhFacilityRollup.as("zfr"), $"ce.groupid" === $"zfr.groupid" and $"ce.facilityid" === $"zfr.facility_id" and $"ce.client_ds_id" === $"zfr.client_ds_id", "left_outer")
      .join(tempEncounterGrpPdx.as("prdx"), $"eeg.encounter_grp_num" === $"prdx.encounter_grp_num", "left_outer")
      .join(mapDischargeDisposition.as("mdd"), $"ce.groupid" === $"mdd.groupid" and $"ce.localdischargedisposition" === $"mdd.mnemonic", "left_outer")
      .groupBy($"eeg.groupid", $"eeg.grp_mpi", $"eeg.encounter_grp_num")
      .agg(
        max(
          when($"es.facrank" === 1, $"zfr.master_facility_id").otherwise(null)
        ).as("master_facility_id"),
        max(
          when($"encounteridtype" === "MASTER", $"eeg.patienttype").otherwise(null)
        ).as("encounter_grp_type"),
        max(
          when($"es.admitrank" === 1, TimestampTruncate.truncate(lit("DAY"), coalesce($"ce.admittime", $"ce.arrivaltime")).cast(LongType)).otherwise(null)
        ).as("admittime"),
        min(
          when($"arrivalrank" === 1, $"ce.arrivaltime").otherwise(null)
        ).as("arrivaltime"),
        max(
          when($"encounteridtype".isin("MASTER", "ENCTR") and $"excl" === "N", $"ce.dischargetime").otherwise(null)
        ).as("dischargetime"),
        max($"prdx.prindx").as("prindx"),
        max(
          when($"disprank" === 1, coalesce($"mdd.cui", lit("CH999999"))).otherwise(null)
        ).as("disposition")
      )
  }
}
