package com.optum.oap.backend.etl.bpo

import com.optum.oap.backend.cdrTempModel.{temp_bpo_prov_spans, temp_bpo_provider_detail, temp_pid, temp_zip}
import com.optum.oap.backend.loader.EnrichmentRunTimeVariables
import com.optum.oap.cdr.models._
import com.optum.oap.sparkdataloader.{RuntimeVariables, TableInfo, UserDefinedFunctionForDataLoader}
import org.apache.spark.sql.expressions.Window
import org.apache.spark.sql.functions.{lit, _}
import org.apache.spark.sql.types.{DoubleType, StringType}
import org.apache.spark.sql.{DataFrame, SparkSession}

object TEMP_PP_BPO_PROVIDER_DETAIL extends TableInfo[pp_bpo_provider_detail] {

  override def dependsOn: Set[String] = Set("TEMP_BPO_PROVIDER_DETAIL", "TEMP_BPO_PROV_SPANS", "ZH_PROV_CONTACT_SUMMARY", "TEMP_PID", "TEMP_ZIP")

  override def name = "TEMP_PP_BPO_PROVIDER_DETAIL"

  override def createDataFrame(sparkSession: SparkSession,
                               loadedDependencies: Map[String, DataFrame],
                               udfMap: Map[String, UserDefinedFunctionForDataLoader],
                               runtimeVariables: RuntimeVariables): DataFrame = {
    import sparkSession.implicits._

    val tempBpoProvSpans = loadedDependencies("TEMP_BPO_PROV_SPANS").as[temp_bpo_prov_spans]
    val tempBpoProviderDetail = loadedDependencies("TEMP_BPO_PROVIDER_DETAIL").as[temp_bpo_provider_detail]
    val zhProvContactSummary = loadedDependencies("ZH_PROV_CONTACT_SUMMARY").as[zh_prov_contact_summary]
    val tempPid = loadedDependencies("TEMP_PID").as[temp_pid]
    val tempZip = loadedDependencies("TEMP_ZIP").as[temp_zip]

    val provIdWindow = Window.partitionBy($"master_hgprovid").orderBy($"prov_end_dt".desc)
    val grpid = EnrichmentRunTimeVariables(runtimeVariables).clientId

    val provSpans = tempBpoProvSpans
      .select(
        $"master_hgprovid",
        $"prov_effective_dt",
        $"prov_end_dt",
        $"provaffiliationid",
        $"provider_status",
        $"cust_prov_attr1",
        $"cust_prov_attr2",
        $"cust_prov_attr3",
        $"cust_prov_attr4",
        $"cust_prov_attr5",
        $"cust_prov_attr6",
        $"cust_prov_attr7",
        $"cust_prov_attr8",
        $"cust_prov_attr9",
        $"cust_prov_attr10",
        $"cust_prov_attr11",
        $"cust_prov_attr12",
        $"cust_prov_attr13",
        $"cust_prov_attr14",
        $"cust_prov_attr15",
        $"cust_prov_attr16",
        $"cust_prov_attr17",
        $"cust_prov_attr18",
        $"cust_prov_attr19",
        $"cust_prov_attr20",
        row_number().over(provIdWindow).as("rnk"),
        $"prov_userdef_1",
        $"prov_userdef_2"
      )

    val grpList = List("H984216", "H623622")

    val tempPpBpoProviderDetail = tempBpoProviderDetail.as("pd")
      .withColumn("grpid", lit(grpid))
      .join(provSpans.as("ps"), $"ps.master_hgprovid" === $"pd.providerid", "inner")
      .join(zhProvContactSummary.as("zpCS").where($"mapped_contact_type" === "CH003087"), $"zpCS.master_hgprovid".cast(StringType) === $"pd.providerid", "left_outer")
      .join(tempPid.as("pid"), $"pid.master_hgprovid".cast(StringType) === $"pd.providerid", "left_outer")
      .join(tempZip.as("zip"), substring($"zpCS.zipcode", 1, 5) === $"zip.zipcode","left_outer")
      .select(
        $"pd.groupid",
        $"pd.npi",
        $"pd.providerid",
        $"pd.providername",
        $"pd.providerfirstname",
        $"pd.providerlastname",
        $"pd.specialty",
        $"pd.secondaryspecialty",
        $"pd.providertype",
        $"pd.pcpflag",
        $"pd.healthplansource",
        $"pd.mapsource",
        $"ps.prov_effective_dt",
        $"ps.prov_end_dt",
        $"ps.provaffiliationid",
        $"ps.provider_status",
        $"ps.cust_prov_attr1",
        $"ps.cust_prov_attr2",
        $"ps.cust_prov_attr3",
        $"ps.cust_prov_attr4",
        $"ps.cust_prov_attr5",
        $"ps.cust_prov_attr6",
        $"ps.cust_prov_attr7",
        $"ps.cust_prov_attr8",
        $"ps.cust_prov_attr9",
        $"ps.cust_prov_attr10",
        $"ps.cust_prov_attr11",
        $"ps.cust_prov_attr12",
        $"ps.cust_prov_attr13",
        $"ps.cust_prov_attr14",
        $"ps.cust_prov_attr15",
        $"ps.cust_prov_attr16",
        $"ps.cust_prov_attr17",
        $"ps.cust_prov_attr18",
        $"ps.cust_prov_attr19",
        $"ps.cust_prov_attr20",
        $"ps.rnk",
        when($"ps.rnk" === lit(1), lit("Y")).otherwise(lit("N")).as("final_flag"),
        when($"grpid".isin(grpList: _*) && $"ps.rnk" === lit(1) && $"provider_status".isNotNull, lit("Y"))
          .when($"grpid".isin(grpList: _*), lit("N"))
          .otherwise(when($"ps.rnk" === lit(1), lit("Y")).otherwise(lit("N")))
          .as("final_network_flag"),
        substring($"zpCS.address_line1", 1, 50).as("provaddress1"),
        substring($"zpCS.address_line2", 1, 50).as("provaddress2"),
        substring($"zpCS.city", 1, 30).as("provcity"),
        when(length($"zpCS.state") === lit(2), $"zpCS.state").as("provstate"),
        substring($"zpCS.zipcode", 1, 10).as("provzip"),
        substring($"zpCS.work_phone", 1, 15).as("provphone"),
        when(length($"zpCS.email_address") <= 50, $"zpCS.email_address").as("provemail"),
        coalesce($"zpCS.address_latitude", $"zip.latitude").as("prov_geo_lat"),
        coalesce($"zpCS.address_longitude", $"zip.longitude").as("prov_geo_lon"),
        when(length($"ps.prov_userdef_1") <= 100, $"ps.prov_userdef_1").as("prov_userdef_1"),
        when(length($"ps.prov_userdef_2") <= 30, $"ps.prov_userdef_2").as("prov_userdef_2"),
        when(length($"pid.sec_provider_id") <= 20, $"pid.sec_provider_id").as("sec_provider_id")
      )

    tempPpBpoProviderDetail
      .where($"rnk" === lit(1))
      .select(
        $"groupid",
        $"npi",
        $"providerid",
        $"providername",
        $"providerfirstname",
        $"providerlastname",
        $"specialty",
        $"secondaryspecialty",
        $"providertype",
        $"pcpflag",
        $"healthplansource",
        $"mapsource",
        $"provaffiliationid",
        $"provider_status",
        $"cust_prov_attr1",
        $"cust_prov_attr2",
        $"cust_prov_attr3",
        $"cust_prov_attr4",
        $"cust_prov_attr5",
        $"cust_prov_attr6",
        $"cust_prov_attr7",
        $"cust_prov_attr8",
        $"cust_prov_attr9",
        $"cust_prov_attr10",
        $"cust_prov_attr11",
        $"cust_prov_attr12",
        $"cust_prov_attr13",
        $"cust_prov_attr14",
        $"cust_prov_attr15",
        $"cust_prov_attr16",
        $"cust_prov_attr17",
        $"cust_prov_attr18",
        $"cust_prov_attr19",
        $"cust_prov_attr20",
        lit(null).cast(StringType).as("adminpin"),
        lit(null).cast(StringType).as("affilaccess"),
        lit(null).cast(StringType).as("dea"),
        lit(null).cast(StringType).as("fifth_specialty"),
        lit(null).cast(StringType).as("fourth_specialty"),
        lit(null).cast(StringType).as("health_plan_id"),
        lit(null).cast(StringType).as("prod_code_1"),
        lit(null).cast(StringType).as("prod_code_2"),
        lit(null).cast(StringType).as("prod_code_3"),
        lit(null).cast(StringType).as("prod_code_4"),
        lit(null).cast(StringType).as("prod_code_5"),
        lit(null).cast(StringType).as("prod_code_6"),
        lit(null).cast(StringType).as("prov_grp_tin"),
        lit(null).cast(StringType).as("prov_tin"),
        lit(null).cast(StringType).as("provaccess"),
        lit(null).cast(StringType).as("provactive"),
        lit(null).cast(StringType).as("provider_county"),
        lit(null).cast(StringType).as("provpin"),
        lit(null).cast(StringType).as("provregion"),
        lit(null).cast(StringType).as("qualityprofileflag"),
        lit(null).cast(StringType).as("third_specialty"),
        $"provaddress1",
        $"provaddress2",
        $"provcity",
        $"provstate",
        $"provzip",
        $"provphone",
        $"provemail",
        $"prov_geo_lat",
        $"prov_geo_lon",
        $"prov_userdef_1",
        $"prov_userdef_2",
        $"sec_provider_id"
      )
  }
}
