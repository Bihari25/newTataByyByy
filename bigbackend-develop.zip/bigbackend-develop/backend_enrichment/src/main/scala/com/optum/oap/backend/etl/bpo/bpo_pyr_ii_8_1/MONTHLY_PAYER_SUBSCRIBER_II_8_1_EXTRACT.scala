package com.optum.oap.backend.etl.bpo.bpo_pyr_ii_8_1

import com.optum.oap.backend.cdrTempModel.{monthly_payer_subscriber, temp_bpo_insurance}
import com.optum.oap.cdr.models.{pp_bpo_member_detail, pp_bpo_member_detail_ii, zo_bpo_map_employer}
import com.optum.oap.sparkdataloader.{RuntimeVariables, TableInfo, UserDefinedFunctionForDataLoader}
import org.apache.spark.sql.expressions.Window
import org.apache.spark.sql.functions._
import org.apache.spark.sql.types.DoubleType
import org.apache.spark.sql.{DataFrame, SparkSession}


object MONTHLY_PAYER_SUBSCRIBER_II_8_1_EXTRACT extends TableInfo[monthly_payer_subscriber] {

  override def dependsOn = Set("ZO_BPO_MAP_EMPLOYER", "PP_BPO_MEMBER_DETAIL_II", "PP_BPO_MEMBER_DETAIL", "TEMP_BPO_INSURANCE")

  override def name = "MONTHLY_PAYER_SUBSCRIBER_II_8_1_EXTRACT"

  override def createDataFrame(sparkSession: SparkSession,
                               loadedDependencies: Map[String, DataFrame],
                               udfMap: Map[String, UserDefinedFunctionForDataLoader],
                               runtimeVariables: RuntimeVariables): DataFrame = {

    import sparkSession.implicits._

    implicit val spark = sparkSession

    val ppBpoMemberDetail = loadedDependencies("PP_BPO_MEMBER_DETAIL").as[pp_bpo_member_detail]
    val zoMapEmployer = broadcast(loadedDependencies("ZO_BPO_MAP_EMPLOYER")).as[zo_bpo_map_employer]
    val ppBpoMemberDetailII = loadedDependencies("PP_BPO_MEMBER_DETAIL_II").as[pp_bpo_member_detail_ii]
    val tempBpoInsurance = loadedDependencies("TEMP_BPO_INSURANCE").as[temp_bpo_insurance]


    val csid_df = zoMapEmployer.groupBy($"employeraccountid")
      .agg(max($"client_ds_id").as("client_ds_id"))
      .select($"employeraccountid", $"client_ds_id")

    val pp_ii = broadcast(dataframe(ppBpoMemberDetailII.select(concat($"subscriberid", $"employeraccountid").as("subscriber")).as[temp_subscriber_member_detail].distinct().collect():_*))

    val ii_Df = ppBpoMemberDetailII.alias("ii")
      .where($"healthplansource" === "PAYER")
      .join(pp_ii.as("pp_ii"), concat($"ii.memberid", $"ii.employeraccountid") === $"pp_ii.subscriber", "inner")
      .join(csid_df.as("csid"), $"ii.employeraccountid" === $"csid.employeraccountid", "left")
      .select(
        concat($"ii.memberid", lit("_"), $"client_ds_id").as("subscriber_id"),
        date_format($"effectivedate", "yyyy-MM-dd").as("eff_dt"),
        date_format($"enddate", "yyyy-MM-dd").as("end_dt"),
        $"emp_acct_id".as("account"),
        $"product_dtl_code".as("product"),
        $"benefitplan".as("benefit_plan"),
        $"contracttype".as("contract_type"),
        lit("1").as("map_srce_e"),
        $"contract_id".as("contract"),
        $"risk_type".as("risk_type"),
        $"cust_mem_attr1".as("cust_sub_1"),
        $"cust_mem_attr2".as("cust_sub_2"),
        $"cust_mem_attr3".as("cust_sub_3"),
        $"cust_mem_attr4".as("cust_sub_4"),
        $"cust_mem_attr5".as("cust_sub_5"),
        $"cust_mem_attr6".as("cust_sub_6"),
        $"cust_mem_attr7".as("cust_sub_7"),
        $"cust_mem_attr8".as("cust_sub_8"),
        $"cust_mem_attr9".as("cust_sub_9"),
        $"cust_mem_attr10".as("cust_sub_10"),
        $"cust_mem_attr11".as("cust_sub_11"),
        $"cust_mem_attr12".as("cust_sub_12"),
        $"cust_mem_attr13".as("cust_sub_13"),
        $"cust_mem_attr14".as("cust_sub_14"),
        $"cust_mem_attr15".as("cust_sub_15"),
        $"cust_mem_attr16".as("cust_sub_16"),
        $"cust_mem_attr17".as("cust_sub_17"),
        $"cust_mem_attr18".as("cust_sub_18"),
        $"cust_mem_attr19".as("cust_sub_19"),
        $"cust_mem_attr20".as("cust_sub_20"),
        concat($"ii.memberid", lit("_"), $"client_ds_id", lit("_"),
          row_number().over(Window.partitionBy($"ii.memberid", $"client_ds_id").orderBy($"effectivedate"))).as("cust_sub_pk_id")
      )

      val insurance_df = tempBpoInsurance.alias("sub").where($"sub.healthplansource" === "PAYER" && $"sub.payrank" === 1 && $"sub.grp_mpi" =!= $"sub.subscriberid")
      .join(tempBpoInsurance.alias("mem"), $"sub.groupid" === $"mem.groupid" && $"sub.subscriberid" === $"mem.grp_mpi" &&
        $"sub.employeraccountid" === $"mem.employeraccountid" && $"sub.member_start" === $"mem.member_start" && $"mem.payrank" === 1,"left_outer")
      .join(csid_df.as("csid"), $"sub.employeraccountid" === $"csid.employeraccountid", "left_outer")
      .where($"mem.grp_mpi".isNull)
      .select(
        concat($"sub.subscriberid", lit("_"), $"client_ds_id").as("subscriber_id"),
        date_format($"sub.member_start", "yyyy-MM-dd").as("eff_dt"),
        date_format($"sub.member_end", "yyyy-MM-dd").as("end_dt"),
        $"sub.emp_acct_id".as("account"),
        $"sub.product_dtl_code".as("product"),
        $"sub.benefitplan".as("benefit_plan"),
        $"sub.contracttype".as("contract_type"),
        lit("1").as("map_srce_e"),
        $"sub.contract_id".as("contract"),
        $"sub.risk_type",
        lit("").as("cust_sub_1"),
        lit("").as("cust_sub_2"),
        lit("").as("cust_sub_3"),
        lit("").as("cust_sub_4"),
        lit("").as("cust_sub_5"),
        lit("").as("cust_sub_6"),
        lit("").as("cust_sub_7"),
        lit("").as("cust_sub_8"),
        lit("").as("cust_sub_9"),
        lit("").as("cust_sub_10"),
        lit("").as("cust_sub_11"),
        lit("").as("cust_sub_12"),
        lit("").as("cust_sub_13"),
        lit("").as("cust_sub_14"),
        lit("").as("cust_sub_15"),
        lit(null).cast(DoubleType).as("cust_sub_16"),
        lit(null).cast(DoubleType).as("cust_sub_17"),
        lit(null).cast(DoubleType).as("cust_sub_18"),
        lit(null).cast(DoubleType).as("cust_sub_19"),
        lit(null).cast(DoubleType).as("cust_sub_20"),
        concat($"sub.subscriberid", lit("_"), $"client_ds_id", lit("_"), date_format($"sub.member_start", "yyyyMM")).as("cust_sub_pk_id")
    )
      .distinct()

    val filter_DF = ppBpoMemberDetail.where($"healthplansource" === "PAYER")
      .select(concat($"subscriberid", $"employeraccountid").as("subscriber")).distinct()

    val pp_ii_mem = ppBpoMemberDetailII.select(concat($"memberid", $"employeraccountid").as("member")).distinct()

    val detail_Df = ppBpoMemberDetail.alias("pp")
      .where($"healthplansource" === "PAYER")
      .join(filter_DF.as("fd"), concat($"pp.memberid", $"pp.employeraccountid") === $"fd.subscriber", "inner")
      .join(pp_ii_mem.as("pp_ii"), concat($"pp.memberid", $"pp.employeraccountid") === $"pp_ii.member", "left_anti")
      .join(csid_df.as("csid"), $"pp.employeraccountid" === $"csid.employeraccountid", "left")
      .select(
        concat($"pp.memberid", lit("_"), $"client_ds_id").as("subscriber_id"),
        date_format($"effectivedate", "yyyy-MM-dd").as("eff_dt"),
        date_format($"enddate", "yyyy-MM-dd").as("end_dt"),
        $"emp_acct_id".as("account"),
        $"product_dtl_code".as("product"),
        $"benefitplan".as("benefit_plan"),
        $"contracttype".as("contract_type"),
        lit("1").as("map_srce_e"),
        $"contract_id".as("contract"),
        $"risk_type".as("risk_type"),
        $"cust_mem_attr1".as("cust_sub_1"),
        $"cust_mem_attr2".as("cust_sub_2"),
        $"cust_mem_attr3".as("cust_sub_3"),
        $"cust_mem_attr4".as("cust_sub_4"),
        $"cust_mem_attr5".as("cust_sub_5"),
        $"cust_mem_attr6".as("cust_sub_6"),
        $"cust_mem_attr7".as("cust_sub_7"),
        $"cust_mem_attr8".as("cust_sub_8"),
        $"cust_mem_attr9".as("cust_sub_9"),
        $"cust_mem_attr10".as("cust_sub_10"),
        $"cust_mem_attr11".as("cust_sub_11"),
        $"cust_mem_attr12".as("cust_sub_12"),
        $"cust_mem_attr13".as("cust_sub_13"),
        $"cust_mem_attr14".as("cust_sub_14"),
        $"cust_mem_attr15".as("cust_sub_15"),
        $"cust_mem_attr16".as("cust_sub_16"),
        $"cust_mem_attr17".as("cust_sub_17"),
        $"cust_mem_attr18".as("cust_sub_18"),
        $"cust_mem_attr19".as("cust_sub_19"),
        $"cust_mem_attr20".as("cust_sub_20"),
        concat($"memberid", lit("_"), $"client_ds_id", lit("_"),
          row_number().over(Window.partitionBy($"memberid", $"client_ds_id").orderBy($"effectivedate"))).as("cust_sub_pk_id")
      )

    ii_Df.union(detail_Df)
         .union(insurance_df)

  }
}

case class temp_subscriber_member_detail(subscriber: String = null)