package com.optum.oap.backend.etl.bpo

import com.optum.oap.cdr.models._
import com.optum.oap.sparkdataloader.{RuntimeVariables, TableInfo, UserDefinedFunctionForDataLoader}
import org.apache.spark.sql.functions.broadcast
import org.apache.spark.sql.{DataFrame, SparkSession}

/**
  *
  * Copyright 2019 Optum Analytics
  *
  * Date: 5/20/19
  *
  * Creator: bpokharel(bishu)
  */
object PP_BPO_PROVIDER_XWALK extends TableInfo[pp_bpo_provider_xwalk] {

  override def dependsOn =
    Set("ZH_PROVIDER_MASTER_XREF", "ZO_BPO_MAP_EMPLOYER", "ZH_PROVIDER_MASTER")

  override def name = "PP_BPO_PROVIDER_XWALK"

  override def createDataFrame(sparkSession: SparkSession,
                               loadedDependencies: Map[String, DataFrame],
                               udfMap: Map[String, UserDefinedFunctionForDataLoader],
                               runtimeVariables: RuntimeVariables): DataFrame = {
    import sparkSession.implicits._

    val zh_provider_master_xref_DF = loadedDependencies("ZH_PROVIDER_MASTER_XREF").as[zh_provider_master_xref]
    val zo_bpo_map_employer_DF = broadcast(loadedDependencies("ZO_BPO_MAP_EMPLOYER")).as[zo_bpo_map_employer]
    val zh_provider_master_DF = loadedDependencies("ZH_PROVIDER_MASTER").as[zh_provider_master]

    zh_provider_master_xref_DF.as("xref")
      .join(zh_provider_master_DF.as("prv"), Seq("master_hgprovid"))
      .join(zo_bpo_map_employer_DF.as("zo"), Seq("client_ds_id"))
      .select(
        $"xref.groupid",
        $"xref.client_ds_id",
        $"xref.localproviderid".as("providerid"),
        $"xref.master_hgprovid",
        $"prv.npi",
        $"zo.employeraccountid".as("o1_plan_source")
      )
      .as[pp_bpo_provider_xwalk]
      .toDF()
  }
}
