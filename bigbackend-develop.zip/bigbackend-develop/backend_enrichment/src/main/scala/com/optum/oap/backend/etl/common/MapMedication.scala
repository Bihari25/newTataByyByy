package com.optum.oap.backend.etl.common

import org.apache.spark.sql.DataFrame
import org.apache.spark.sql.functions.{coalesce, lit, when}

/**
  *
  * Copyright 2019 Optum Analytics
  *
  * Date: 5/9/19
  *
  * Creator: bpokharel(bishu)
  */
object MapMedication {

  val MedicationFields = Set("map_used", "hum_med_key", "hum_gen_med_key", "hts_generic", "hts_generic_ext", "dcc", "mappedgpi", "mappedndc", "ndc11")

  /**
    * @param sourceDF         dataframe for which we want to apply medication map
    * @param joinNdcReference true we are joining to NDCreferece else false. for eg. this flag is true for rxOrder
    * @param zhMedMapDccDf    dataFrame for "ZH_MED_MAP_DCC"
    * @param ndcReferenceDf   dataFrame for "REF_HTS_NDC_CURRENT". If joinNdcReference is false, it can be null
    */
  def applyMedMap(sourceDF: DataFrame, joinNdcReference: Boolean, zhMedMapDccDf: DataFrame,
                  ndcReferenceDf: DataFrame, medCodeField: String, dccFlag: Boolean): DataFrame = {

    if (!dccFlag) {
      throw new IllegalArgumentException("dccFlag must be true")
    }

    if (medCodeField == null) {
      throw new IllegalArgumentException("medCodeField must not be null")
    }

    if (joinNdcReference && ndcReferenceDf == null) {
      throw new IllegalArgumentException("ndcReference cannot be null when joinNdcReference is true")
    }

    val cols = getSelectList(sourceDF.columns.toSet, MedicationFields)

    if (joinNdcReference) {

      val joinedDf_NdcRef = sourceDF.as("rx")
        .join(zhMedMapDccDf.as("mm"),
          sourceDF("groupid") === zhMedMapDccDf("groupid") and
            sourceDF("datasrc") === zhMedMapDccDf("datasrc") and
            sourceDF("client_ds_id") === zhMedMapDccDf("client_ds_id") and
            sourceDF(medCodeField) === zhMedMapDccDf("localmedcode"), "left_outer"
        )
        .join(ndcReferenceDf.as("ref"),
          sourceDF("localndc") === ndcReferenceDf("ndc") and
            sourceDF("datasrc") === lit("int_claim_pharm"), "left_outer"
        )
        .withColumn("map_used_temp", coalesce(
          zhMedMapDccDf("map_used"),
          when(ndcReferenceDf("ndc").isNotNull, lit("claims_automap"))
            .otherwise(
              when(
                sourceDF("datasrc") === lit("int_claim_pharm"), lit("missed"))
                .otherwise(null)))
        )
        .withColumn("hum_med_key_temp", coalesce(zhMedMapDccDf("hum_med_key"), ndcReferenceDf("hum_med_key")))
        .withColumn("hum_gen_med_key_temp", coalesce(zhMedMapDccDf("hum_gen_med_key"), ndcReferenceDf("hum_gen_med_key")))
        .withColumn("hts_generic_temp", coalesce(zhMedMapDccDf("hts_generic"), ndcReferenceDf("hts_generic")))
        .withColumn("hts_generic_ext_temp", coalesce(zhMedMapDccDf("hts_generic_ext"), ndcReferenceDf("hts_generic_ext")))
        .withColumn("dcc_temp", coalesce(zhMedMapDccDf("dcc"), ndcReferenceDf("dcc")))
        .withColumn("mappedgpi_temp", zhMedMapDccDf("hts_gpi"))
        .withColumn("mappedndc_temp", coalesce(zhMedMapDccDf("top_ndc"), ndcReferenceDf("ndc")))
        .withColumn("ndc11_temp", NormalizeNDC.normalize(sourceDF("localndc")))

      joinedDf_NdcRef
        .select(cols.head, cols.tail: _*)
        .withColumnRenamed("map_used_temp", "map_used")
        .withColumnRenamed("hum_med_key_temp", "hum_med_key")
        .withColumnRenamed("hum_gen_med_key_temp", "hum_gen_med_key")
        .withColumnRenamed("hts_generic_temp", "hts_generic")
        .withColumnRenamed("hts_generic_ext_temp", "hts_generic_ext")
        .withColumnRenamed("dcc_temp", "dcc")
        .withColumnRenamed("mappedgpi_temp", "mappedgpi")
        .withColumnRenamed("mappedndc_temp", "mappedndc")
        .withColumnRenamed("ndc11_temp", "ndc11")

    } else {

      val joinedDf2 = sourceDF.as("rx")
        .join(zhMedMapDccDf.as("mm"),
          sourceDF("groupid") === zhMedMapDccDf("groupid") and
            sourceDF("datasrc") === zhMedMapDccDf("datasrc") and
            sourceDF("client_ds_id") === zhMedMapDccDf("client_ds_id") and
            sourceDF(medCodeField) === zhMedMapDccDf("localmedcode"), "left_outer"
        )
        .withColumn("map_used_temp", zhMedMapDccDf("map_used"))
        .withColumn("hum_med_key_temp", zhMedMapDccDf("hum_med_key"))
        .withColumn("hum_gen_med_key_temp", zhMedMapDccDf("hum_gen_med_key"))
        .withColumn("hts_generic_temp", zhMedMapDccDf("hts_generic"))
        .withColumn("hts_generic_ext_temp", zhMedMapDccDf("hts_generic_ext"))
        .withColumn("dcc_temp", zhMedMapDccDf("dcc"))
        .withColumn("mappedgpi_temp", zhMedMapDccDf("hts_gpi"))
        .withColumn("mappedndc_temp", zhMedMapDccDf("top_ndc"))
        .withColumn("ndc11_temp", NormalizeNDC.normalize(sourceDF("localNDC")))

      joinedDf2
        .select(cols.head, cols.tail: _*)
        .withColumnRenamed("map_used_temp", "map_used")
        .withColumnRenamed("hum_med_key_temp", "hum_med_key")
        .withColumnRenamed("hum_gen_med_key_temp", "hum_gen_med_key")
        .withColumnRenamed("hts_generic_temp", "hts_generic")
        .withColumnRenamed("hts_generic_ext_temp", "hts_generic_ext")
        .withColumnRenamed("dcc_temp", "dcc")
        .withColumnRenamed("mappedgpi_temp", "mappedgpi")
        .withColumnRenamed("mappedndc_temp", "mappedndc")
        .withColumnRenamed("ndc11_temp", "ndc11")
    }
  }

  def getSelectList(sourceCols: Set[String], mapCols: Set[String]): Array[String] = {
    sourceCols.map(s => if (mapCols.contains(s.toLowerCase)) s + "_temp" else "rx." + s).toArray
  }

}