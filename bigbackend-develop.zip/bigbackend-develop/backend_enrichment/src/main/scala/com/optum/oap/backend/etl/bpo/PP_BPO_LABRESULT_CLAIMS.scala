package com.optum.oap.backend.etl.bpo

import com.optum.oap.backend.cdrTempModel.{temp_bpo_calculate_params, temp_bpo_patients}
import com.optum.oap.backend.etl.bpo.BpoUtil.getBpoInputParameters
import com.optum.oap.backend.etl.common.Functions.appendRowNumberToDataframe
import com.optum.oap.backend.etl.common.IsSafeToNumber
import com.optum.oap.cdr.models.{labresult, map_smoking_status, observation, _}
import com.optum.oap.sparkdataloader.{RuntimeVariables, TableInfo, UserDefinedFunctionForDataLoader}
import org.apache.spark.sql.expressions.Window
import org.apache.spark.sql.functions.{when, _}
import org.apache.spark.sql.types._
import org.apache.spark.sql.{DataFrame, SparkSession}


/**
  *
  * Copyright 2019 Optum Analytics
  *
  * Date: 5/23/19
  *
  * Creator: bpokharel(bishu)
  */
object PP_BPO_LABRESULT_CLAIMS extends TableInfo[pp_bpo_labresult_claims] {

  override def dependsOn = Set(
    "TEMP_BPO_PATIENTS",
    "LABRESULT",
    "OBSERVATION",
    "TEMP_BPO_CALCULATE_PARAMS",
    "MV_HTS_DOMAIN_CONCEPT",
    "MAP_HTS_TERM",
    "MAP_SMOKING_STATUS",
    "MAP_TOBACCO_USE",
    "MAP_SMOKING_CESSATION",
    "MAP_TOBACCO_CESSATION",
    "ZO_BPO_LOINC_UNITS"
  )

  override def name = "PP_BPO_LABRESULT_CLAIMS"

  override def createDataFrame(sparkSession: SparkSession,
                               loadedDependencies: Map[String, DataFrame],
                               udfMap: Map[String, UserDefinedFunctionForDataLoader],
                               runtimeVariables: RuntimeVariables): DataFrame = {

    import sparkSession.implicits._

    val temp_bpo_patients_DS = loadedDependencies("TEMP_BPO_PATIENTS").as[temp_bpo_patients]
    val labresult_DS = loadedDependencies("LABRESULT").as[labresult]
    val obs_DS = loadedDependencies("OBSERVATION").as[observation]
    val tempBpoParams_DS = broadcast(loadedDependencies("TEMP_BPO_CALCULATE_PARAMS")).as[temp_bpo_calculate_params]
    val mv_hts_domain_concept_DS = loadedDependencies("MV_HTS_DOMAIN_CONCEPT").as[mv_hts_domain_concept]
    val map_hts_term_DS = broadcast(loadedDependencies("MAP_HTS_TERM")).as[map_hts_term]
    val map_smoking_status_DS = broadcast(loadedDependencies("MAP_SMOKING_STATUS")).as[map_smoking_status]
    val map_tobacco_use_DS = broadcast(loadedDependencies("MAP_TOBACCO_USE")).as[map_tobacco_use]
    val map_smoking_cessation_DS = broadcast(loadedDependencies("MAP_SMOKING_CESSATION")).as[map_smoking_cessation]
    val map_tobacco_cessation_DS = loadedDependencies("MAP_TOBACCO_CESSATION").as[map_tobacco_cessation]
    val zo_bpo_loinc_units_DS = broadcast(loadedDependencies("ZO_BPO_LOINC_UNITS")).as[zo_bpo_loinc_units]

    val inputParameters = getBpoInputParameters(sparkSession, tempBpoParams_DS)
    val extractStartDate = inputParameters.engineStartDate
    val extractEndDate = inputParameters.engineEndDate

    val pat_DF = temp_bpo_patients_DS
      .withColumn("row1",
        row_number().over(Window.partitionBy($"groupid", $"grp_mpi").orderBy($"groupid", $"grp_mpi", $"payer".desc))
      ).select(
      "groupid",
      "grp_mpi",
      "payer",
      "row1"
    )
    val pat1_DF = pat_DF.where(pat_DF("row1") === lit(1))

    val temp_bpo_labresult_DF = labresult_DS.as("clm")
      .join(pat1_DF.as("pat1"), Seq("groupid", "grp_mpi"))
      .where(to_date(coalesce(labresult_DS("datecollected"), labresult_DS("dateavailable"))).between(lit(extractStartDate), lit(extractEndDate)))
      .where(coalesce(labresult_DS("resulttype"), lit("CH999999")).notEqual(lit("CH999990")))
      .where(labresult_DS("grp_mpi").isNotNull)
      .where(labresult_DS("mappedcode").isNotNull)
      .where(labresult_DS("localresult").isNotNull)
      .select(
        $"clm.groupid",
        $"clm.grp_mpi",
        $"clm.client_ds_id",
        $"clm.datasrc",
        $"clm.dateavailable",
        $"clm.datecollected",
        $"clm.mappedcode",
        $"clm.mappedunits",
        $"clm.localresult",
        $"clm.normalizedvalue",
        $"pat1.payer"
      )

    val temp_bpo_observation_DF = obs_DS.as("clm")
      .join(pat1_DF.as("pat1"), Seq("groupid", "grp_mpi"))
      .where(obs_DS("obstype").isin(lit("SBP"), lit("DBP"), lit("SMOKE"), lit("CH001851"), lit("CH001850"), lit("SMOKE_CESS_CONSULT"), lit("CH004625") ))
      .where(to_date(obs_DS("obsdate")).between(lit(extractStartDate), lit(extractEndDate)))
      .where(obs_DS("grp_mpi").isNotNull)
      .where(obs_DS("obsresult").isNotNull)
      .where(!obs_DS("datasrc").isin(lit("foam"), lit("nlp")))
      .select(
        $"clm.groupid",
        $"clm.grp_mpi",
        $"clm.client_ds_id",
        $"clm.datasrc",
        $"clm.obstype",
        $"clm.obsdate",
        $"clm.obsresult",
        $"pat1.payer"
      )

    // calculate first clause of union statement
    val partitionBy1 = Window
      .partitionBy($"clm.groupid", $"clm.grp_mpi", $"clm.mappedcode", to_date(coalesce($"clm.datecollected", $"clm.dateavailable")))
      .orderBy($"clm.groupid", $"clm.grp_mpi", $"clm.mappedcode", coalesce($"clm.datecollected", $"clm.dateavailable").desc, $"clm.normalizedvalue".asc_nulls_last)

    val union_part1_DF = temp_bpo_labresult_DF.as("clm")
      .join(mv_hts_domain_concept_DS.as("mhdc"), $"clm.mappedunits" === $"mhdc.concept_cui" && $"mhdc.domain_cui" === lit("CH001302"), "left_outer")
      .join(map_hts_term_DS.as("mht"), $"clm.mappedcode" === $"mht.hts_cui" && $"mht.preferred" === lit("Y"))
      .withColumn("testresultunits",
        when(
          $"clm.normalizedvalue".isNotNull, substring($"mhdc.concept_name", 1, 25))
          .otherwise(lit(null).cast(StringType))
      )
      .withColumn("healthplansource",
        when(
          $"clm.payer" === lit(1), lit("PAYER"))
          .otherwise(lit("PROVIDER"))
      )
      .withColumn(
        "laborder", row_number().over(partitionBy1)
      )
      .select(
        $"clm.groupid",
        $"clm.client_ds_id",
        $"clm.grp_mpi".cast(StringType).as("memberid"),
        to_date(coalesce($"datecollected", $"dateavailable")).as("servicedate"),
        $"term_code".as("loinc"),
        $"normalizedvalue".as("testresultnumber"),
        $"testresultunits",
        lit(null).cast(StringType).as("testresulttext"),
        lit("Y").as("fastingstatus"),
        lit("MED").as("coverageclasscode"),
        $"healthplansource",
        $"laborder"
      )

    // calculate second clause of union statement
    val partitionBy2 = Window
      .partitionBy($"clm.groupid", $"grp_mpi", $"clm.obstype", to_date($"clm.obsdate"))
      .orderBy($"clm.groupid", $"clm.grp_mpi", $"clm.obstype", $"clm.obsdate".desc, $"clm.obsresult")

    val union_part2_DF = temp_bpo_observation_DF.as("clm")
      .join(map_smoking_status_DS.as("ss"), $"clm.groupid" === $"ss.groupid" && $"clm.obsresult" === $"ss.mnemonic" && $"clm.obstype" === lit("SMOKE"), "left_outer")
      .join(map_tobacco_use_DS.as("tu"), $"clm.groupid" === $"tu.groupid" && $"clm.obsresult" === $"tu.localcode" && $"clm.obstype" === lit("CH001850"), "left_outer")
      .join(map_smoking_cessation_DS.as("sc"), $"clm.groupid" === $"sc.groupid" && $"clm.obsresult" === $"sc.local_code" && $"clm.obstype" === lit("SMOKE_CESS_CONSULT"), "left_outer")
      .join(map_tobacco_cessation_DS.as("tc"), $"clm.groupid" === $"tc.groupid" && $"clm.obsresult" === $"tc.localcode" && $"clm.obstype" === lit("CH001851"), "left_outer")
      .withColumn("loinc",
        when($"clm.obstype" === lit("SBP"), lit("8480-6"))
          .when($"clm.obstype" === lit("DBP"), lit("8462-4"))
          .when(($"clm.obstype" === lit("SMOKE")) && $"ss.cui" === lit("CH000036"), lit("39240-7"))
          .when(($"clm.obstype" === lit("CH001850")) && $"tu.cui" === lit("CH001884"), lit("39240-7"))
          .when(($"clm.obstype" === lit("SMOKE_CESS_CONSULT")) && $"sc.cui" === lit("CH000217"), lit("39241-5"))
          .when(($"clm.obstype" === lit("CH001851")) && $"tc.cui" === lit("CH001886"), lit("39241-5"))
          .when(($"clm.obstype" === lit("CH004625")), lit("59574-4"))
          .otherwise(lit(null).cast(StringType))
      )
      .withColumn("testresultnumber",
        when($"clm.obstype".isin(lit("SBP"), lit("DBP"), lit("CH004625")) && IsSafeToNumber.isSafeToNumber($"obsresult".cast(StringType)), $"obsresult".cast(DoubleType))
          .otherwise(lit(null).cast(DoubleType))
      )
      .withColumn("testresultunits", // this calculation is never used in oracle . Looks it was just added for future improvement
        when($"clm.obstype".isin(lit("SBP"), lit("DBP")), lit("bpm"))
          .otherwise(lit(null).cast(StringType))
      )
      .withColumn("testresulttext",
        when(!$"clm.obstype".isin(lit("SBP"), lit("DBP"), lit("CH004625")), lit("Y"))
          .otherwise(lit(null).cast(StringType))
      )
      .withColumn("healthplansource",
        when($"payer" === lit(1), lit("PAYER"))
          .otherwise(lit("PROVIDER"))
      )
      .withColumn(
        "laborder", row_number().over(partitionBy2)
      ).select(
      $"clm.groupid",
      $"clm.client_ds_id",
      $"clm.grp_mpi".cast(StringType).as("memberid"),
      to_date($"clm.obsdate").as("servicedate"),
      $"loinc",
      $"testresultnumber",
      $"testresultunits",
      $"testresulttext",
      lit("Y").as("fastingstatus"),
      lit("MED").as("coverageclasscode"),
      $"healthplansource",
      $"laborder"
    )

    val union_Df = union_part1_DF
      .union(union_part2_DF)

    val ionic_units_DF = zo_bpo_loinc_units_DS
      .select(
        "loinc",
        "units"
      ).distinct()

    val df1 = union_Df.as("l")
      .join(ionic_units_DF.as("u"), Seq("loinc"), "left_outer")
      .withColumn("testresultunits",
        when($"units".isNull || $"units" === lit("NULL"), lit(null).cast(StringType))
          .otherwise($"units")
      )
      .where(union_Df("loinc").isNotNull)
      .where(union_Df("laborder") === lit(1))
      .select(
        $"groupid",
        $"memberid",
        $"servicedate",
        $"l.loinc",
        $"testresultnumber",
        $"testresultunits",
        $"testresulttext",
        $"fastingstatus",
        $"coverageclasscode",
        $"client_ds_id",
        $"healthplansource",
        lit("AD").as("labsource"),
        lit(null).cast(StringType).alias("cpt_code") // cpt_code exists in table but is never calculated
      )

    //Add rownum
    val withRowNumberDf = appendRowNumberToDataframe(sparkSession, df1)

    val finalDf = withRowNumberDf
      .withColumn("claimheader", concat(lit("LAB"), $"client_ds_id", lit("."), $"rownumber"))
      .select(
        $"groupid",
        $"memberid",
        $"servicedate".cast(TimestampType),
        $"loinc",
        $"testresultnumber",
        $"testresultunits",
        $"testresulttext",
        $"fastingstatus",
        $"coverageclasscode",
        $"claimheader",
        $"healthplansource",
        $"labsource",
        $"cpt_code"
      )

    finalDf.as[pp_bpo_labresult_claims].toDF()

  }
}
