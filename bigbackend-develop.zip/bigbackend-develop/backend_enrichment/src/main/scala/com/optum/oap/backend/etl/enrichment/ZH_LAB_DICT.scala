package com.optum.oap.backend.etl.enrichment

import com.optum.oap.cdr.models.{zh_lab_dict}
import com.optum.oap.sparkdataloader.{RuntimeVariables, TableInfo, UserDefinedFunctionForDataLoader}
import org.apache.spark.sql.{DataFrame, SparkSession}
import org.slf4j.LoggerFactory

object ZH_LAB_DICT extends TableInfo[zh_lab_dict] {

  private val log = LoggerFactory.getLogger(this.getClass)

  override def dependsOn = Set("CDR_FE_ZH_LAB_DICT", "ICPM_ZH_LAB_DICT")

  override def name = "ZH_LAB_DICT"

  override def createDataFrame(sparkSession: SparkSession,
                               loadedDependencies: Map[String, DataFrame],
                               udfMap: Map[String, UserDefinedFunctionForDataLoader],
                               runtimeVariables: RuntimeVariables): DataFrame = {
    import sparkSession.implicits._

    val zhLabDictIn = loadedDependencies("CDR_FE_ZH_LAB_DICT").drop("row_source","modified_date").as[zh_lab_dict]

    //Load df from ICPM ZH_LAB_DICT
    val icpmZhLabDict = loadedDependencies("ICPM_ZH_LAB_DICT").as[zh_lab_dict]

    //Union Lab dictionary data coming from FE & ICPM
    zhLabDictIn.unionByName(icpmZhLabDict).select("*")
  }

}