package com.optum.oap.backend.etl.enrichment

import com.optum.oap.backend.etl.common.{MapMasterIds, MatchRegExPattern}
import com.optum.oap.cdr.models._
import com.optum.oap.sparkdataloader.{RuntimeVariables, TableInfo, UserDefinedFunctionForDataLoader}
import org.apache.spark.sql.functions._
import org.apache.spark.sql.{DataFrame, SparkSession}
import org.slf4j.LoggerFactory

object MBRESULT extends TableInfo[mbresult] {

  val log = LoggerFactory.getLogger(this.getClass)

  override def dependsOn = Set("CDR_FE_MBRESULT", "PATIENT_MPI",
    "CDR_FE_ZCM_MICRO_GROWTH_PATTERN", "CDR_FE_ZCM_MICRO_CULT_UNIT_PATTERN",
    "CDR_FE_ZCM_MICRO_CULT_VAL_PATTERN", "CDR_FE_ZCM_CULT_ORG_EXCL", "CDR_FE_ZCM_CULT_ORG_FOUND",
    "CDR_FE_ZCM_MICRO_SENS_RESULT_PATTERN", "CDR_FE_ZCM_MICRO_ANTIBIOTIC_PATTERN", "CDR_FE_ZCM_MICRO_RESLT_STATS_PATTERN")

  override def name = "MBRESULT"

  override def ignoreExtraColumnsInDataFrame: Boolean = true

  override def createDataFrame(sparkSession: SparkSession,
                               loadedDependencies: Map[String, DataFrame],
                               udfMap: Map[String, UserDefinedFunctionForDataLoader],
                               runtimeVariables: RuntimeVariables): DataFrame = {
    import sparkSession.implicits._

    val mbresultIn = loadedDependencies("CDR_FE_MBRESULT").as[mbresult]
    val patXref = loadedDependencies("PATIENT_MPI").as[patient_mpi]

    val zcmMicroGrowth = loadedDependencies("CDR_FE_ZCM_MICRO_GROWTH_PATTERN").as[zcm_micro_growth_pattern]
    val zcmMicroCultUnit = loadedDependencies("CDR_FE_ZCM_MICRO_CULT_UNIT_PATTERN").as[zcm_micro_cult_unit_pattern]
    val zcmMicroCultVal = loadedDependencies("CDR_FE_ZCM_MICRO_CULT_VAL_PATTERN").as[zcm_micro_cult_val_pattern]
    val zcmCultOrg = loadedDependencies("CDR_FE_ZCM_CULT_ORG_EXCL").as[zcm_cult_org_excl]
    val zcmOrgFound = loadedDependencies("CDR_FE_ZCM_CULT_ORG_FOUND").as[zcm_cult_org_found]
    val zcmSensResult = loadedDependencies("CDR_FE_ZCM_MICRO_SENS_RESULT_PATTERN").as[zcm_micro_sens_result_pattern]
    val zcmAntibiotic = loadedDependencies("CDR_FE_ZCM_MICRO_ANTIBIOTIC_PATTERN").as[zcm_micro_antibiotic_pattern]
    val zcmResStatus = loadedDependencies("CDR_FE_ZCM_MICRO_RESLT_STATS_PATTERN").as[zcm_micro_reslt_stats_pattern]

    val mbResultsEnhanced = mbresultIn.withColumn("coalesce_sensitivity", coalesce($"localsensitivityname", $"localsensitivity"))

    //Collect up the distinct values for each column we're going to map
    val distinctVals = List("localorganismname", "localantibioticname", "localresulstatus", "coalesce_sensitivity").map(c => {
      c -> mbResultsEnhanced.filter(c + " IS NOT NULL")
        .select(c).distinct
    }).toMap

    val colMapSpecs: List[ColumnMapInfo] = List(
      ColumnMapInfo(distinctVals, zcmMicroGrowth.toDF(), "localorganismname", "hts_culture_growth", "cui"),
      ColumnMapInfo(distinctVals, zcmMicroCultUnit.toDF(), "localorganismname", "hts_culture_unit", "cui"),
      ColumnMapInfo(distinctVals, zcmMicroCultVal.toDF(), "localorganismname", "hts_culture_val", "cui"),
      ColumnMapInfo(distinctVals, zcmCultOrg.toDF(), "localorganismname", "hts_org_exclude", "cui"),
      ColumnMapInfo(distinctVals, zcmOrgFound.toDF(), "localorganismname", "hts_organism_found", "cui"),
      ColumnMapInfo(distinctVals, zcmResStatus.toDF(), "localresulstatus", "hts_result_status", "cui"),
      ColumnMapInfo(distinctVals, zcmSensResult.toDF(), "coalesce_sensitivity", "hts_sens_result", "cui"),
      ColumnMapInfo(distinctVals, zcmAntibiotic.toDF().where($"hgmk".isNotNull), "localantibioticname", "hts_sens_antibiotic", "hgmk"),
      ColumnMapInfo(distinctVals, zcmAntibiotic.toDF(), "localantibioticname", "antibiotic_loinc", "loinc")
    )

    val withMapsApplied = colMapSpecs.foldLeft[DataFrame](mbResultsEnhanced)((mbr: DataFrame, colInfo: ColumnMapInfo) => applyColumnMap(sparkSession, mbr, colInfo))

    MapMasterIds.mapPatientIds(withMapsApplied.drop("coalesce_sensitivity"), patXref.toDF, false)
  }

  def applyColumnMap(sparkSession: SparkSession, mbResultDF: DataFrame, mapInfo: ColumnMapInfo): DataFrame = {
    import sparkSession.implicits._
    val mapPatterns = mapInfo.regexMap.select($"groupid", $"priority", $"txt_pattern", col(mapInfo.cuiCol).as("cui")).orderBy(when(substring($"groupid", 1, 1) === "H", 1).otherwise(0).desc, col("priority"), length($"txt_pattern").desc)
      .agg(collect_list(struct($"txt_pattern", $"cui", $"priority", $"groupid")).as("entries")).as[GroupEntries]

    val mappedColumn = "mapped_" + mapInfo.srcColumn
    val mapColumn = "map_" + mapInfo.srcColumn
    val columnMap = mapInfo.uniqueVals(mapInfo.srcColumn).crossJoin(mapPatterns)
      .withColumn(mappedColumn, MatchRegExPattern.matchRegExPattern(col(mapInfo.srcColumn), $"entries"))
      .filter(mappedColumn + " is not null")
      .select(col(mapInfo.srcColumn).as(mapColumn), col(mappedColumn))

    mbResultDF.join(broadcast(columnMap), col(mapInfo.srcColumn) <=> col(mapColumn), "left_outer").drop(mapInfo.destColumn, mapColumn)
      .withColumnRenamed(mappedColumn, mapInfo.destColumn)
  }


}

case class ColumnMapInfo(uniqueVals: Map[String, DataFrame], regexMap: DataFrame, srcColumn: String, destColumn: String, cuiCol: String)