package com.optum.oap.backend.etl.bpo

import com.amazonaws.services.s3.model.GetObjectRequest
import com.optum.oap.awsutils.AWSClientConfig
import com.optum.oap.backend.cdrTempModel.imap_drg
import com.optum.oap.backend.etl.common.{CDRConstants, EnrichmentUtils}
import com.optum.oap.backend.loader.EnrichmentRunTimeVariables
import com.optum.oap.sparkdataloader.{RuntimeVariables, TableInfo, UserDefinedFunctionForDataLoader}
import org.apache.spark.sql.{DataFrame, SparkSession}

import scala.io.BufferedSource
import scala.util.Try

object IMAP_APR_DRG extends TableInfo[imap_drg] {

  override def dependsOn = Set.empty[String]

  override def name = "IMAP_APR_DRG"

  override def createDataFrame(sparkSession: SparkSession,
                               loadedDependencies: Map[String, DataFrame],
                               udfMap: Map[String, UserDefinedFunctionForDataLoader],
                               runtimeVariables: RuntimeVariables): DataFrame = {

    val clientBucket = EnrichmentRunTimeVariables(runtimeVariables).clientBucket
    if (clientBucket.isEmpty) fromGitHub(sparkSession)
    else fromS3(sparkSession)
  }

  def fromGitHub(sparkSession: SparkSession): DataFrame = {
    val config_url = s"https://github.optum.com/raw/OptumAnalyticsPlatform/oap-configs/master/CDRBE/BPO/II_8_1/MAP/IMAP_APR_DRG.txt"
    val urlBufferedSource = scala.io.Source.fromURL(config_url)
    try {
      constructResult(sparkSession, urlBufferedSource)
    } finally {
      if (urlBufferedSource != null) urlBufferedSource.close()
    }
  }

  def fromS3(sparkSession: SparkSession): DataFrame = {
    val awsS3Client = AWSClientConfig.default.createS3Client()
    val obj = awsS3Client.getObject(new GetObjectRequest(CDRConstants.OAPCONFIG_BUCKET_NAME, "CDRBE/BPO/II_8_1/MAP/IMAP_APR_DRG.txt"))
    val s3BufferedSource = scala.io.Source.fromInputStream(obj.getObjectContent)
    try {
      constructResult(sparkSession, s3BufferedSource)
    } finally {
      if (s3BufferedSource != null) s3BufferedSource.close()
      if (obj != null) obj.close()
    }
  }

  def constructResult(sparkSession: SparkSession, bufferedSource: BufferedSource): DataFrame = {
    import sparkSession.implicits._
    val result = bufferedSource.getLines
      .map(row => row.split('|'))
      .drop(1)
      .map(field => imap_drg(field(0), field(1), field(2), field(3), field(4), Try(field(5)).getOrElse(""), Try(field(6).toDouble).getOrElse(null).asInstanceOf[Double]))
    result.toSeq.toDF()
  }

}
