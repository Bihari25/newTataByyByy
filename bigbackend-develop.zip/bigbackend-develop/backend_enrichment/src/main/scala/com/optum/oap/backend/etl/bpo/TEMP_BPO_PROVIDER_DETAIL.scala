package com.optum.oap.backend.etl.bpo

import com.optum.oap.backend.cdrTempModel.temp_bpo_provider_detail
import com.optum.oap.backend.loader.EnrichmentRunTimeVariables
import com.optum.oap.cdr.models._
import com.optum.oap.sparkdataloader.{RuntimeVariables, TableInfo, UserDefinedFunctionForDataLoader}
import org.apache.spark.sql.functions._
import org.apache.spark.sql.types._
import org.apache.spark.sql.{DataFrame, Dataset, SparkSession}

import scala.collection.mutable.ListBuffer

object TEMP_BPO_PROVIDER_DETAIL extends TableInfo[temp_bpo_provider_detail]{

  override def name = "TEMP_BPO_PROVIDER_DETAIL"

  override def dependsOn: Set[String] = Set("MAP_PREDICATE_VALUES", "PROV_CLIENT_REL", "ZH_PROVIDER_MASTER_XREF", "ZH_PROVIDER", "ZO_BPO_MAP_EMPLOYER", "ZH_PROVIDER_MASTER", "MAP_SPECIALTY_II", "REF_PRIMARYSPECIALTY", "MAP_PROVIDER_TAXONOMY", "MAP_SPECIALTY", "ZO_SPECIALTY")

  def tempBpoETLCountNotZero(rel : DataFrame, subClause : DataFrame, provider: List[Int], zhProviderMaster : Dataset[zh_provider_master], mapSpecialtyII : Dataset[map_specialty_ii], refPrimarySpecialty : Dataset[ref_primaryspecialty], mapProviderTaxonomy: Dataset[map_provider_taxonomy] , sparkSession :SparkSession) : DataFrame = {

    import sparkSession.implicits._

    val clause = zhProviderMaster.as("p")
      .join(subClause.as("h"), $"p.groupid" === $"h.groupid" && $"p.master_hgprovid" === $"h.master_hgprovid", "inner")
      .join(rel.as("rel"), $"p.groupid" === $"rel.groupid" && $"p.master_hgprovid" === $"rel.master_hgprovid", "left_outer")
      .join(mapSpecialtyII.as("ms_i"), $"ms_i.groupid" === $"p.groupid" && $"ms_i.LOCAL_CODE" === $"p.localprimaryspecialty", "left_outer")
      .join(refPrimarySpecialty.as("ps"), $"ps.npi" === $"p.npi", "left_outer")
      .join(mapProviderTaxonomy.as("dsc"), $"dsc.taxonomy_code" === $"ps.primarycode", "left_outer")
      .select(
    $"p.groupid",
        $"p.master_hgprovid".cast(StringType).as("providerid"),
        $"p.npi",
        coalesce(substring($"p.providername", 1, 50), lit("No Provider Name")).as("providername"),
        when($"p.providername".substr(instr($"p.providername", ",") + 1, lit(40)) === lit(""), lit("No Provider First Name"))
          .otherwise($"p.providername".substr(instr($"p.providername", ",") + 1, lit(40))).as("providerfirstname"),
        when(($"p.providername".contains(",") && length(trim(substring(substring_index($"p.providername",",", 1),1,40))) > lit(0)), substring(substring_index($"p.providername",",", 1),1,40))
          .otherwise(lit("No Provider Last Name")).as("providerlastname"),
        $"dsc.ii_code".as("npi_ii_code"),
        $"ms_i.ii_code".as("local_ii_code"),
        when(($"p.groupid" =!= lit("H416989")) && (coalesce($"rel.rel_prv", lit(0)) === 1), lit("PROVIDER"))
        .when(($"p.groupid" === lit("H416989")) && (coalesce($"h.provider", lit(0)) === 1), lit("PROVIDER"))
        .when(($"p.groupid" === lit("H416989")) && (!$"providername".like("NON%MAYO%")), lit("PROVIDER"))
        .otherwise(lit("PAYER")).as("healthplansource"),
        $"h.pcpflag")

    clause.select(
    $"groupid",
      $"npi",
      $"providerid",
      $"providername",
      $"providerfirstname",
      $"providerlastname",
      coalesce($"npi_ii_code", $"local_ii_code", lit("999")).as("specialty"),
      when($"local_II_Code" === $"npi_ii_code", lit("999")).otherwise(coalesce($"local_ii_code", lit("999"))).as("secondaryspecialty"),
      coalesce($"npi_ii_code", $"local_ii_code", lit("999")).as("providertype"),
      $"pcpflag",
      $"healthplansource",
      lit("*").as("mapsource")
    )
  }

  def tempBpoETLCountZero(rel : DataFrame, subClause : DataFrame, provider: List[Int],cuiList: List[String] ,zhProviderMaster : Dataset[zh_provider_master], mapSpecialty : Dataset[map_specialty], refPrimarySpecialty : Dataset[ref_primaryspecialty], mapProviderTaxonomy: Dataset[map_provider_taxonomy], zoSpecialty : Dataset[zo_specialty] , sparkSession :SparkSession) : DataFrame = {

    import sparkSession.implicits._

    val cuiId = "CH999999"
    val groupid = "H416989"

    val clause = zhProviderMaster.as("p")
      .join(subClause.as("h"), $"p.groupid" ===$"h.groupid" && $"p.master_hgprovid" === $"h.master_hgprovid", "inner")
      .join(rel.as("rel"), $"p.groupid" === $"rel.groupid" && $"p.master_hgprovid" === $"rel.master_hgprovid", "left_outer")
      .join(mapSpecialty.as("ms"), $"ms.groupid" === $"p.groupid" && $"ms.mnemonic" === $"p.localprimaryspecialty", "left_outer")
      .join(refPrimarySpecialty.as("ps"), $"ps.npi" === $"p.npi", "left_outer")
      .join(mapProviderTaxonomy.as("dsc"), $"dsc.taxonomy_code" === $"ps.primarycode")
      .select(
        $"p.groupid",
        $"p.master_hgprovid".cast(StringType).as("providerid"),
        $"p.npi",
        coalesce(substring($"p.providername", 1, 50), lit("No Provider Name")).as("providername"),
        when($"p.providername".substr(instr($"p.providername", ",") + 1, lit(40)) === lit(""), lit("No Provider First Name"))
          .otherwise($"p.providername".substr(instr($"p.providername", ",") + 1, lit(40))).as("providerfirstname"),
        coalesce(substring(substring_index($"p.providername",",", 1),1,40), lit("No Provider Last Name")).as("providerlastname"),
        when(coalesce($"ms.cui",lit(cuiId)).isin(cuiList : _*) && coalesce($"dsc.specialty_cui", lit("CH999999")).isin(cuiList : _*), lit("CH999999"))
          .when(coalesce($"ms.cui", lit(cuiId)).isin(cuiList : _* ), $"dsc.specialty_cui")
          .when(coalesce($"dsc.specialty_cui", lit(cuiId)).isin(cuiList : _*), $"ms.cui")
          .when($"dsc.specialty_cui" === lit("CH000831"), $"ms.cui")
          .otherwise($"dsc.specialty_cui").as("cui"),
        when(($"p.groupid" =!= lit(groupid)) && (coalesce($"rel.rel_prv", lit(0)) === lit(1)), lit("PROVIDER"))
          .when(($"p.groupid" === lit(groupid)) && (coalesce($"h.provider", lit(0))  === lit(1)), lit("PROVIDER"))
          .when(($"p.groupid" === lit(groupid)) && (!$"providername".like("NON%MAYO%")), lit("PROVIDER"))
          .otherwise(lit("PAYER")).as("healthplansource"),
        $"dsc.specialty_cui".as("npicui"),
        $"ms.cui".as("localcui"),
        $"h.pcpflag"
      )

    clause.as("s")
      .join(zoSpecialty.as("zs"), $"s.cui" === $"zs.hts_cui", "left_outer")
      .join(zoSpecialty.as("zsnpi"), $"s.localcui" === $"zsnpi.hts_cui", "left_outer")
      .select(
        $"s.groupid",
        $"s.npi",
        $"s.providerid",
        $"s.providername",
        $"s.providerfirstname",
        $"s.providerlastname",
        coalesce($"zs.ii_code", lit("999")).as("specialty"),
        when($"s.localcui" === $"s.cui", lit("999")).otherwise(coalesce($"zsnpi.ii_code", lit("999"))).as("secondaryspecialty"),
        coalesce($"zs.ii_code", lit("999")).as("providertype"),
        $"s.pcpflag",
        $"s.healthplansource",
        lit("*").as("mapsource")
      )
  }

  def addDefaultRows(tempBpoProviderDetail : DataFrame, grpid : String, sparkSession: SparkSession) : DataFrame = {
    import sparkSession.implicits._

    val tempBpoProviderIds = tempBpoProviderDetail.select($"providerid").where($"providerid".isin("0", "ACHOSPOUT", "ACHOSPIN")).as[String].collect()
    var defaultRows = new ListBuffer[temp_bpo_provider_detail]()

    if(!tempBpoProviderIds.contains("0")){
      defaultRows += temp_bpo_provider_detail(groupid = grpid, providerid = "0", providername = "Provider Unknown", providerfirstname = "Provider", providerlastname = "Unknown", specialty = "999", secondaryspecialty = "999", providertype = "999", pcpflag = "N", healthplansource = "PAYER", mapsource = "*")
    }

    if (!tempBpoProviderIds.contains("ACHOSPOUT")) {
      defaultRows += temp_bpo_provider_detail(groupid = grpid, providerid = "ACHOSPOUT", providername = "Acute Care Hospital Non " + grpid, providerfirstname = "Acute Care", providerlastname = "Hospital Non " + grpid, specialty = "100", secondaryspecialty = "100", providertype = "100", pcpflag = "N", healthplansource = "PAYER", mapsource = "*")
    }

    if (!tempBpoProviderIds.contains("ACHOSPIN")){
      defaultRows += temp_bpo_provider_detail(groupid = grpid, providerid = "ACHOSPIN", providername = "Acute Care Hospital " + grpid, providerfirstname = "Acute Care", providerlastname = "Hospital " + grpid, specialty = "100", secondaryspecialty = "100", providertype = "100", pcpflag = "N", healthplansource = "PROVIDER", mapsource = "*")
    }
    defaultRows.toList.toDF()
  }

  override def createDataFrame(sparkSession: SparkSession, loadedDependencies: Map[String, DataFrame], udfMap: Map[String, UserDefinedFunctionForDataLoader], runtimeVariables: RuntimeVariables): DataFrame = {

    import sparkSession.implicits._

    val mapPredicateValues = loadedDependencies("MAP_PREDICATE_VALUES").as[map_predicate_values]
    val provClientRel= loadedDependencies("PROV_CLIENT_REL").as[prov_client_rel]
    val zhProviderMasterXref = loadedDependencies("ZH_PROVIDER_MASTER_XREF").as[zh_provider_master_xref]
    val zhProvider = loadedDependencies("ZH_PROVIDER").as[zh_provider]
    val zoBpoMapEmployer = broadcast(loadedDependencies("ZO_BPO_MAP_EMPLOYER")).as[zo_bpo_map_employer]
    val zhProviderMaster = loadedDependencies("ZH_PROVIDER_MASTER").as[zh_provider_master]
    val mapSpecialtyII = broadcast(loadedDependencies("MAP_SPECIALTY_II")).as[map_specialty_ii]
    val refPrimarySpecialty = loadedDependencies("REF_PRIMARYSPECIALTY").as[ref_primaryspecialty]
    val mapProviderTaxonomy = broadcast(loadedDependencies("MAP_PROVIDER_TAXONOMY")).as[map_provider_taxonomy]
    val mapSpecialty = broadcast(loadedDependencies("MAP_SPECIALTY")).as[map_specialty]
    val zoSpecialty = broadcast(loadedDependencies("ZO_SPECIALTY")).as[zo_specialty]

    val localRelShipCode = List("EMR PROVIDER", "IN_NETWORK")
    val cuiList = List("CH999999", "CH000953")

    val grpid = EnrichmentRunTimeVariables(runtimeVariables).clientId

    val vCount = mapPredicateValues
      .where($"entity" === lit("PP_BPO_PROVIDER_DETAIL") && $"column_name" === lit("II_SPECIALTY") && $"data_src" === lit("OADW") && $"groupid" === lit(grpid))
      .count()

    val rel = provClientRel.as("p")
      .where($"p.groupid" === lit(grpid) && upper($"localrelshipcode").isin(localRelShipCode : _*))
      .join(zhProviderMasterXref.as("z"), $"z.localproviderid" === $"p.providerid" && $"z.groupid" === $"p.groupid" && $"z.client_ds_id" === $"p.client_ds_id", "inner")
      .select($"z.groupid",
        $"z.master_hgprovid",
        lit(1).as("rel_prv")).distinct()

    val provider = zoBpoMapEmployer.select($"client_ds_id").where($"groupid" === lit(grpid)).collect.map(r => r(0).asInstanceOf[Int]).toList
    val tempZhProvider = zhProvider.withColumn("grpid", lit(grpid))

    val subClause = tempZhProvider.as("pr")
      .join(zhProviderMasterXref.as("x"), $"pr.groupid" === $"x.groupid" && $"pr.localproviderid" === $"x.localproviderid" && $"pr.client_ds_id" === $"x.client_ds_id","inner")
      .groupBy($"pr.groupid", $"x.master_hgprovid")
      .agg(max(when(!$"pr.client_ds_id".isin(provider :_*), 1).otherwise(0)).as("provider"),
          when(max($"pr.grpid") === lit("H984216"),
            coalesce(max(when($"pr.pcp_flag".isin(lit("0"),lit("N")), lit("N"))
              .when($"pr.pcp_flag".isin(lit("1"), lit("Y")), lit("Y"))
              .otherwise(null)), lit("N")))
          .otherwise(
              coalesce(max(when($"pr.pcp_flag".isin(lit("0"), lit("N")), lit("N"))
                .when($"pr.pcp_flag".isin(lit("1"), lit("Y")), lit("Y"))
                .otherwise(null)), lit("Y"))
            ).as("pcpflag"))
      .select($"pr.groupid",
              $"x.master_hgprovid",
              $"provider",
              $"pcpflag"
              )

    val  tempBpoProviderDetail = if (vCount > 0) {
      tempBpoETLCountNotZero(rel, subClause,provider, zhProviderMaster, mapSpecialtyII, refPrimarySpecialty,mapProviderTaxonomy, sparkSession)
    }
    else {
      tempBpoETLCountZero(rel,subClause,provider, cuiList, zhProviderMaster, mapSpecialty, refPrimarySpecialty, mapProviderTaxonomy, zoSpecialty, sparkSession)
    }
    tempBpoProviderDetail.union(addDefaultRows(tempBpoProviderDetail, grpid, sparkSession))
  }
}



