package com.optum.oap.backend.loader.loadgroup
import com.optum.oap.backend.loader.{BeEncounterDependencies, DataTableDependencies, EnrichmentQueryRegistry, EnrichmentRunTimeVariables, StaticDependencies}
import com.optum.oap.sparkdataloader.TableInfo
import org.apache.spark.sql.SparkSession

trait MetricsLoadGroup extends LoadGroup {

  override def loadGroup: String = "metrics"

  override def initialDependencies(runTimeVariables: EnrichmentRunTimeVariables, sparkSession: SparkSession): Seq[TableInfo[_ <: Product with Serializable]] = {
    import runTimeVariables._

    DataTableDependencies.dataInitialDependencies(cdrSchema) ++
      StaticDependencies.staticInitialDependencies(cdrSchema) ++
      BeEncounterDependencies.cdrBeEncounterInitialDependencies(cdrSchema)
  }

  override def queryRegistry(runTimeVariables: EnrichmentRunTimeVariables, sparkSession: SparkSession): Seq[TableInfo[_ <: Product with Serializable]] = {
    EnrichmentQueryRegistry.metricsQueryRegistry
  }
}
