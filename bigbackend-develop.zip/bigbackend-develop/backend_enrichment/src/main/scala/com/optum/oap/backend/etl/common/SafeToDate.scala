package com.optum.oap.backend.etl.common

import com.optum.oap.sparkdataloader.UserDefinedFunctionForDataLoader
import org.apache.spark.sql.SparkSession
import org.apache.spark.sql.expressions.UserDefinedFunction
import org.apache.spark.sql.functions.udf


object SafeToDate extends UserDefinedFunctionForDataLoader {
  val safeToDate: UserDefinedFunction = udf {
    (dateString: String, dateFormat: String) => {
      CommonFunctions.safeToDate(dateString, dateFormat, null)
    }
  }

  override def name: String = "safe_to_date"

  override def registerMe(sparkSession: SparkSession): Unit = {
    sparkSession.udf.register(name, safeToDate)
  }

}

