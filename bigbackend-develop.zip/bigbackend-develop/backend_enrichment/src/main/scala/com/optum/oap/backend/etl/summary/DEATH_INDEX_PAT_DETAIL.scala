package com.optum.oap.backend.etl.summary

import com.optum.oap.backend.etl.common.SSNValidation
import com.optum.oap.cdr.models.death_index_pat_detail
import com.optum.oap.sparkdataloader.{RuntimeVariables, TableInfo, UserDefinedFunctionForDataLoader}
import org.apache.spark.sql.functions._
import org.apache.spark.sql.{DataFrame, SparkSession}
import org.slf4j.LoggerFactory


object DEATH_INDEX_PAT_DETAIL extends TableInfo[death_index_pat_detail] {

  val log = LoggerFactory.getLogger(this.getClass)

  override def dependsOn = Set("PATIENT_SUMMARY", "PATIENT_ID")

  override def name = "DEATH_INDEX_PAT_DETAIL"

  override def saveDataFrameToParquet: Boolean = true

  override def partitions: Int = 64

  override def skipTable: Boolean = false

  override def ignoreExtraColumnsInDataFrame: Boolean = false

  override def createDataFrame(sparkSession: SparkSession,
                               loadedDependencies: Map[String, DataFrame],
                               udfMap: Map[String, UserDefinedFunctionForDataLoader],
                               runtimeVariables: RuntimeVariables): DataFrame = {
    import sparkSession.implicits._

    val patient_summary = loadedDependencies("PATIENT_SUMMARY").alias("ps")
    val patient_id = loadedDependencies("PATIENT_ID")
    val patids = patient_id.filter("IDTYPE = 'SSN'").withColumn("SSN", SSNValidation.cleanAndValidate($"idvalue"))
      .filter("length(SSN) = 9")
      .select("SSN", "GROUPID", "GRP_MPI", "PATIENTID", "CLIENT_DS_ID")
      .distinct.alias("pid")

    val joined = patient_summary.join(patids, Seq("GRP_MPI", "CLIENT_DS_ID", "PATIENTID"), "left_outer")
    joined.select("ps.GROUPID", "ps.GRP_MPI", "FIRST_NAME", "MIDDLE_NAME", "LAST_NAME", "DOB", "pid.SSN").distinct
  }
}
