package com.optum.oap.backend.etl.enrichment

import com.optum.oap.backend.loader.EnrichmentRunTimeVariables
import com.optum.oap.cdr.models.{netwrk_paid_status_rollup,int_claim_pharm, map_network_paid_status}
import com.optum.oap.sparkdataloader.{RuntimeVariables, TableInfo, UserDefinedFunctionForDataLoader}
import org.apache.spark.sql.expressions.Window
import org.apache.spark.sql.{DataFrame, SparkSession}
import org.slf4j.LoggerFactory
import org.apache.spark.sql.functions._
import org.apache.spark.sql.types._

object NETWRK_PAID_STATUS_ROLLUP extends TableInfo[netwrk_paid_status_rollup] {

  private val log = LoggerFactory.getLogger(this.getClass)

  override def dependsOn = Set("CDR_FE_NETWRK_PAID_STATUS_ROLLUP", "INT_CLAIM_MEDICAL", "INT_CLAIM_PHARM", "MAP_NETWORK_PAID_STATUS")

  override def name = "NETWRK_PAID_STATUS_ROLLUP"

  override def partitions: Int = 32

  override def createDataFrame(sparkSession: SparkSession,
                               loadedDependencies: Map[String, DataFrame],
                               udfMap: Map[String, UserDefinedFunctionForDataLoader],
                               runtimeVariables: RuntimeVariables): DataFrame = {

    import sparkSession.implicits._

    val cdrNtwrkPdStRDf = loadedDependencies("CDR_FE_NETWRK_PAID_STATUS_ROLLUP").as[netwrk_paid_status_rollup]

    val intClaimMedDf = loadedDependencies("INT_CLAIM_MEDICAL")

    val intClaimPharmDf = loadedDependencies("INT_CLAIM_PHARM").as[int_claim_pharm]

    val mapNtwrkPaidStsDf = broadcast(loadedDependencies("MAP_NETWORK_PAID_STATUS")).as[map_network_paid_status]

    val groupId = runtimeVariables.asInstanceOf[EnrichmentRunTimeVariables].clientId

    //Frontend netwrk_paid_status_rollup Rollup table
    val cdrFeNtwrkPaidSts = cdrNtwrkPdStRDf.select(
      $"groupid",
      $"client_ds_id",
      $"datasrc",
      $"network_paid_status",
      $"network_paid_status_desc",
      $"network_paid_status_lv2",
      $"network_paid_status_lv2_desc",
      $"network_paid_status_lv1",
      $"network_paid_status_lv1_desc",
      $"network_paid_status_rollup"
    )

    //Filtering Frontend netwrk_paid_status_rollup Rollup table
    val cdrFeNtwrkPaidStsSelect1 = cdrFeNtwrkPaidSts
      .dropDuplicates("network_paid_status")
      .select("*")

    //getting the records from INT_CLAIM_MEDICAL whose emp_acct_id is not in the netwrk_paid_status_rollup
    val intClaimMedDf1 = intClaimMedDf.as("a").join(cdrFeNtwrkPaidStsSelect1.as("b"), $"a.network_paid_status" === $"b.network_paid_status", "left")
      .select($"a.groupid",
        $"a.client_ds_id",
        lit("int_claim_medical").cast(StringType).as("datasrc"),
        $"a.network_paid_status",
        concat(lit("UNDEFINED ("), $"a.network_paid_status" , lit(")")).as("network_paid_status_desc"),
        $"b.network_paid_status_lv2",
        $"b.network_paid_status_lv2_desc",
        $"b.network_paid_status_lv1",
        $"b.network_paid_status_lv1_desc",
        $"b.network_paid_status_rollup"
      )
      .where(($"a.network_paid_status" isNotNull) && (length($"a.network_paid_status") <=30) && ($"b.network_paid_status" isNull))
      .groupBy($"a.groupid",
        $"a.network_paid_status",
        $"datasrc",
        $"network_paid_status_desc",
        $"b.network_paid_status_lv2",
        $"b.network_paid_status_lv2_desc",
        $"b.network_paid_status_lv1",
        $"b.network_paid_status_lv1_desc",
        $"b.network_paid_status_rollup")
      .agg(min($"client_ds_id").as("client_ds_id"))

    //union the frontend table with missing records of the int_claim_medical
    val cdrFeNtwrkPaidSts2 = cdrFeNtwrkPaidSts.unionByName(intClaimMedDf1)

    //Filtering Frontend netwrk_paid_status_rollup  table
    val cdrFeNtwrkPaidStsSelect2 = cdrFeNtwrkPaidSts2
      .dropDuplicates("network_paid_status")
      .select("*")

    //getting the records from INT_CLAIM_PHARM whose emp_acct_id is not in the netwrk_paid_status_rollup
    val intClaimPharmDf1 = intClaimPharmDf.as("a").join(cdrFeNtwrkPaidStsSelect2.as("b"), ($"a.network_paid_status" === $"b.network_paid_status") && ($"b.groupid" === groupId), "left")
      .select($"a.groupid",
        $"a.client_ds_id",
        lit("int_claim_pharm").cast(StringType).as("datasrc"),
        $"a.network_paid_status".as("network_paid_status"),
        concat(lit("UNDEFINED ("), $"a.network_paid_status" , lit(")")).as("network_paid_status_desc"),
        $"b.network_paid_status_lv2",
        $"b.network_paid_status_lv2_desc",
        $"b.network_paid_status_lv1",
        $"b.network_paid_status_lv1_desc",
        $"b.network_paid_status_rollup"
      )
      .where(($"a.network_paid_status" isNotNull) && (length($"a.network_paid_status") <=30)&& ($"b.network_paid_status" isNull))
      .groupBy($"a.groupid",$"network_paid_status"
        ,$"datasrc",$"network_paid_status_desc",$"b.network_paid_status_lv2",
        $"b.network_paid_status_lv2_desc",
        $"b.network_paid_status_lv1",
        $"b.network_paid_status_lv1_desc",
        $"b.network_paid_status_rollup")
      .agg(min($"client_ds_id").as("client_ds_id"))

    //union the missed records from INT_CLAIM_MEDICAL and the original table
    val unionNtwrkPaidSts = cdrFeNtwrkPaidSts2.unionByName(intClaimPharmDf1)

    //Applying the additional logic and loading to the backend table.
    val rollup = unionNtwrkPaidSts.as("a").join(mapNtwrkPaidStsDf.as("b"),($"a.network_paid_status" === $"b.localcode") && ($"b.groupid" === groupId),"left" )
      .select(
      $"a.groupid"
      ,$"client_ds_id"
      ,$"datasrc"
      ,$"network_paid_status"
      ,substring(coalesce($"network_paid_status_desc", concat(lit("UNDEFINED ("),$"network_paid_status",lit(")"))),1,150).as("network_paid_status_desc")
      ,substring(coalesce($"network_paid_status_lv2", concat(lit("3."),$"network_paid_status")),1,30).as("network_paid_status_lv2")
      ,substring(when($"network_paid_status_lv2".isNull,coalesce($"network_paid_status_desc",concat(lit("UNDEFINED ("),$"network_paid_status",lit(")"))))
        .otherwise(coalesce($"network_paid_status_lv2_desc",concat(lit("UNDEFINED ("),$"network_paid_status_lv2",lit(")")))) ,1,150)
        .as("network_paid_status_lv2_desc")
      ,substring(when($"network_paid_status_lv1".isNotNull,$"network_paid_status_lv1")
        .otherwise(when($"network_paid_status_lv2".isNotNull,concat(lit("2."),$"network_paid_status_lv2"))
          .otherwise(concat(lit("3."),$"network_paid_status"))),1,30).as("network_paid_status_lv1")
      ,substring(when($"network_paid_status_lv1".isNull,
        when($"network_paid_status_lv2".isNull,coalesce($"network_paid_status_desc",concat(lit("UNDEFINED ("),$"network_paid_status",lit(")")) ))
          .otherwise(coalesce($"network_paid_status_lv2_desc",concat(lit("UNDEFINED ("),$"network_paid_status_lv2",lit(")")) )))
        .otherwise(coalesce($"network_paid_status_lv1_desc",concat(lit("UNDEFINED ("),$"network_paid_status_lv1",lit(")")))),1,150).as("network_paid_status_lv1_desc")
        ,when(upper(when($"network_paid_status_rollup" === lit("0"),lit("N"))
          .otherwise(when($"network_paid_status_rollup" === lit("1"),lit("Y"))
            .otherwise(when($"network_paid_status_rollup".isNull,lit("X"))
              .otherwise($"network_paid_status_rollup")) ))
          .isin("Y","N","U") ,
          upper(when($"network_paid_status_rollup" === lit("0"),lit("N"))
          .otherwise(when($"network_paid_status_rollup" === lit("1"),lit("Y"))
            .otherwise($"network_paid_status_rollup"))))
    .otherwise($"b.MAPPEDVALUE").as("network_paid_status_rollup")
      ,row_number().over(Window.partitionBy($"network_paid_status")
        .orderBy(
          when($"network_paid_status_desc".isNotNull, lit(0)).otherwise(lit(1)),
          when($"network_paid_status_lv2".isNotNull, lit(0)).otherwise(lit(1)),
          when($"network_paid_status_lv1".isNotNull, lit(0)).otherwise(lit(1)),
          $"network_paid_status_desc",
          $"network_paid_status_lv2",
          $"network_paid_status_lv1"
        )).as("rn")
    )
      .where(($"network_paid_status" isNotNull) && (length($"network_paid_status") <=30) && ($"rn"=== 1))
      .drop($"rn")

    rollup.toDF()
  }
}