package com.optum.oap.backend.etl.enrichment

import com.optum.oap.cdr.models.{int_claim_pharm, specialty_rx_rollup}
import com.optum.oap.sparkdataloader.{RuntimeVariables, TableInfo, UserDefinedFunctionForDataLoader}
import org.apache.spark.sql.expressions.Window
import org.apache.spark.sql.{DataFrame, SparkSession}
import org.slf4j.LoggerFactory
import org.apache.spark.sql.functions.{coalesce, lit, _}
import org.apache.spark.sql.types.DataTypes
import org.apache.spark.sql.types._

object SPECIALTY_RX_ROLLUP extends TableInfo[specialty_rx_rollup] {

  private val log = LoggerFactory.getLogger(this.getClass)

  override def dependsOn = Set("CDR_FE_SPECIALTY_RX_ROLLUP","INT_CLAIM_PHARM","INT_CLAIM_MEDICAL")

  override def name = "SPECIALTY_RX_ROLLUP"

  override def partitions: Int = 32

  override def createDataFrame(sparkSession: SparkSession,
                               loadedDependencies: Map[String, DataFrame],
                               udfMap: Map[String, UserDefinedFunctionForDataLoader],
                               runtimeVariables: RuntimeVariables): DataFrame = {

    import sparkSession.implicits._

    val cdrSpecialtyRxRollup = loadedDependencies("CDR_FE_SPECIALTY_RX_ROLLUP").as[specialty_rx_rollup]

    val cdrIntClaimPharm = loadedDependencies("INT_CLAIM_PHARM").as[int_claim_pharm]

    val intClaimMedical = loadedDependencies("INT_CLAIM_MEDICAL")

    //*SPECIALTY_RX_ROLLUP*
    //Origin SPECIALTY_RX_ROLLUP rollup table
    val cdrSpecialtyRxRollup1 = cdrSpecialtyRxRollup.select( $"groupid",
      $"client_ds_id",
      $"datasrc",
      $"spec_rx_ind",
      $"spec_rx_desc",
      $"spec_rx_lv2",
      $"spec_rx_lv2_desc",
      $"spec_rx_lv1",
      $"spec_rx_lv1_desc")

    //TAKING DISTINCT SPEC_RX IDS FROM THE SPEC_RX ROLLUP TABLE
    val cdrSpecialtyRxSelect = cdrSpecialtyRxRollup1
      .dropDuplicates("spec_rx_ind")

    //SELECTING RECORDS OF INT_CLAIM_PHARM TABLE WHOSE SPEC_RX IDS ARE NOT IN THE SPEC_RX ROLLUP TABLE
    val specRxRollup = cdrIntClaimPharm.as("a").join(cdrSpecialtyRxSelect.as("b"),$"a.spec_rx_ind" === $"b.spec_rx_ind","left")
      .select($"a.groupid"
        ,$"a.client_ds_id"
        ,lit("int_claim_pharm").as("datasrc")
        ,$"a.spec_rx_ind"
        ,concat(lit("UNDEFINED ("), $"a.spec_rx_ind", lit(")")).as("spec_rx_desc")
        ,$"b.spec_rx_lv2"
        ,$"b.spec_rx_lv2_desc"
        ,$"b.spec_rx_lv1"
        ,$"b.spec_rx_lv1_desc"
      )
      .where(($"a.spec_rx_ind".isNotNull) && ((length($"a.spec_rx_ind")) <= 30) && ($"b.spec_rx_ind".isNull))
      .groupBy($"groupid", $"datasrc", $"a.spec_rx_ind", $"spec_rx_desc",
        $"b.spec_rx_lv2", $"b.spec_rx_lv2_desc", $"b.spec_rx_lv1",
        $"b.spec_rx_lv1_desc")
      .agg(min($"client_ds_id").as("client_ds_id"))

    //UNION THE MISSING RECORDS FETCHED FROM INT_CLAIM_PHARM AND THE ORIGINAL SPEC_RX ROLLUP TABLE
    val cdrSpecialtyRxRollup2 = cdrSpecialtyRxRollup1.unionByName(specRxRollup)

    //TAKING DISTINCT SPEC_RX IDS FROM THE UNION SPEC_RX ROLLUP TABLE
    val cdrSpecialtyRxSelect2 = cdrSpecialtyRxRollup2
      .dropDuplicates("spec_rx_ind")
      .select("*")

    //SELECTING RECORDS OF INT_CLAIM_MEDICAL TABLE WHOSE SPEC_RX IDS ARE NOT IN THE SPEC_RX ROLLUP TABLE
    val intClaimMedical1 = intClaimMedical.as("a").join(cdrSpecialtyRxSelect2.as("b"),$"a.spec_rx_ind" === $"b.spec_rx_ind","left")
      .select($"a.groupid"
        ,$"a.client_ds_id"
        ,$"a.spec_rx_ind".as("spec_rx_ind")
        ,lit("int_claim_medical").as("datasrc")
        ,concat(lit("UNDEFINED ("), $"a.spec_rx_ind", lit(")")).as("spec_rx_desc")
        ,$"b.spec_rx_lv2"
        ,$"b.spec_rx_lv2_desc"
        ,$"b.spec_rx_lv1"
        ,$"b.spec_rx_lv1_desc")
      .where(($"a.spec_rx_ind".isNotNull) && (length($"a.spec_rx_ind") <= 30) && ($"b.spec_rx_ind" isNull))
      .groupBy($"groupid",$"spec_rx_ind",$"datasrc",$"spec_rx_desc",
        $"b.spec_rx_lv2",$"b.spec_rx_lv2_desc",$"b.spec_rx_lv1",$"b.spec_rx_lv1_desc")
      .agg(min($"client_ds_id").as("client_ds_id"))

    //*UNION*
    //NOW UNION THE MISSING RECORDS FETCHED FROM INT_CLAIM_MEDICAL AND THE UNIONED SPEC_RX ROLLUP,INT_CLAIM_PHARM TABLES
    val unionSpecialtyRxRollup = cdrSpecialtyRxRollup2.unionByName(intClaimMedical1)

    //APPLYING ADDITIONAL TRANSFORMATIONS ON THE UNION WITH THE FETCHED RECORDS OF INT_CLAIM_PHARM AND INTCLAIMEMBER AND LOAD TO BACKEND.
    val rollup = unionSpecialtyRxRollup.select(
      $"groupid"
      ,$"client_ds_id"
      ,$"datasrc"
      ,$"spec_rx_ind"
      ,substring(coalesce($"spec_rx_desc", concat(lit("UNDEFINED ("),$"spec_rx_ind",lit(")"))),1,150).as("spec_rx_desc")
      ,substring(coalesce($"spec_rx_lv2", concat(lit("3."),$"spec_rx_ind")),1,30).as("spec_rx_lv2")
      ,substring(when($"spec_rx_lv2".isNull,coalesce($"spec_rx_desc",concat(lit("UNDEFINED ("),$"spec_rx_ind",lit(")"))))
        .otherwise(coalesce($"spec_rx_lv2_desc",concat(lit("UNDEFINED ("),$"spec_rx_lv2",lit(")")))) ,1,150)
        .as("spec_rx_lv2_desc")
      ,substring(when($"spec_rx_lv1".isNotNull,$"spec_rx_lv1")
        .otherwise(when($"spec_rx_lv2".isNotNull,concat(lit("2."),$"spec_rx_lv2"))
          .otherwise(concat(lit("3."),$"spec_rx_ind"))),1,30).as("spec_rx_lv1")
      ,substring(when($"spec_rx_lv1".isNull,
        when($"spec_rx_lv2".isNull,coalesce($"spec_rx_desc",concat(lit("UNDEFINED ("),$"spec_rx_ind",lit(")")) ))
          .otherwise(coalesce($"spec_rx_lv2_desc",concat(lit("UNDEFINED ("),$"spec_rx_lv2",lit(")")) )))
        .otherwise(coalesce($"spec_rx_lv1_desc",concat(lit("UNDEFINED ("),$"spec_rx_lv1",lit(")")))),1,150).as("spec_rx_lv1_desc")
      ,row_number().over(Window.partitionBy($"spec_rx_ind")
        .orderBy(
          when($"spec_rx_desc".isNotNull, lit(0)).otherwise(lit(1)),
          when($"spec_rx_lv2".isNotNull, lit(0)).otherwise(lit(1)),
          when($"spec_rx_lv1".isNotNull, lit(0)).otherwise(lit(1)),
          $"spec_rx_desc",$"spec_rx_lv2",$"spec_rx_lv1"
        )).as("rn")
    )
      .where((unionSpecialtyRxRollup("spec_rx_ind") isNotNull) && (length(unionSpecialtyRxRollup("spec_rx_ind")) <=30) && ($"rn"=== 1))
      .drop($"rn")

    rollup.toDF()
  }
}