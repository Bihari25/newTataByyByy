package com.optum.oap.backend.etl.common

trait cleanNameTrait {

  val matchPatterns = ""

  def cleanName(inStr: String, recursiveLevel: Int) = {

    if (inStr == null) {
      null
    } else {
      val replaceWithSpaces = "[-,.:;_]"
      val removePunct = "[''`*\"?]"
      val str = inStr.replaceAll(removePunct, "").replaceAll(replaceWithSpaces, " ").toUpperCase.trim
      (1 to recursiveLevel).foldLeft(str)(cleanString)
    }
  }

  def cleanString(inStr: String, iteration: Int): String = {
    if (inStr == null) {
      null
    }
    else {
    //remove suffix and cred
      val partial = inStr.replaceAll(matchPatterns, " ").replaceAll("[ ]{2,}", " ").trim
      //remove trailing single characters
      partial.length match {
        case 0 => null
        case _ if partial.length <= 2 => partial
        case _ => val secondToLast = partial.substring(partial.length - 2, partial.length - 1)
        secondToLast match {
          case " " => partial.substring(0, partial.length - 2).trim
          case _ => partial
        }

      }
    }
  }
}
