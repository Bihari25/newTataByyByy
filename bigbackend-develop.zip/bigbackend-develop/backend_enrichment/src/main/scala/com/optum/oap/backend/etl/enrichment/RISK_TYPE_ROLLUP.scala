package com.optum.oap.backend.etl.enrichment

import com.optum.oap.cdr.models.{risk_type_rollup, pat_risk_attrib}
import com.optum.oap.sparkdataloader.{RuntimeVariables, TableInfo, UserDefinedFunctionForDataLoader}
import org.apache.spark.sql.expressions.Window
import org.apache.spark.sql.functions.{coalesce, lit, _}
import org.apache.spark.sql.types._
import org.apache.spark.sql.{DataFrame, SparkSession}
import org.slf4j.LoggerFactory

object RISK_TYPE_ROLLUP extends TableInfo[risk_type_rollup] {

  private val log = LoggerFactory.getLogger(this.getClass)

  override def dependsOn = Set("CDR_FE_RISK_TYPE_ROLLUP", "PAT_RISK_ATTRIB")

  override def name = "RISK_TYPE_ROLLUP"

  override def partitions: Int = 32

  override def createDataFrame(sparkSession: SparkSession,
                               loadedDependencies: Map[String, DataFrame],
                               udfMap: Map[String, UserDefinedFunctionForDataLoader],
                               runtimeVariables: RuntimeVariables): DataFrame = {

    import sparkSession.implicits._

    val riskTypeRollup = loadedDependencies("CDR_FE_RISK_TYPE_ROLLUP").as[risk_type_rollup]
    val patRiskAttrib = loadedDependencies("PAT_RISK_ATTRIB").as[pat_risk_attrib]

    //Origin Front end RISK_TYPE_ROLLUP table
    val cdrRiskTypeRollup = riskTypeRollup.select(
      $"client_ds_id",
      $"risk_type",
      $"risk_type_desc",
      $"risk_type_lv1",
      $"risk_type_lv1_desc",
      $"risk_type_lv2",
      $"risk_type_lv2_desc",
      $"datasrc",
      $"groupid")

    //TAKING DISTINCT risk_type FROM THE RISK_TYPE_ROLLUP TABLE
    val cdrFeRiskTypeRollup = cdrRiskTypeRollup.dropDuplicates("risk_type")

    //SELECTING RECORDS OF PAT_RISK_ATTRIB TABLE WHOSE risk_type ARE NOT IN RISK_TYPE_ROLLUP TABLE
    val patRiskAttrib1 = patRiskAttrib.alias("pra").join(cdrFeRiskTypeRollup.alias("cdr"),
      $"pra.risk_type" === $"cdr.risk_type", "left").select(
      $"pra.groupid"
      , $"pra.client_ds_id"
      , $"pra.risk_type"
      , lit("pat_risk_attrib").cast(StringType).as("datasrc")
      , substring(concat(lit("UNDEFINED ("), $"pra.risk_type",
        lit(")")), 1, 150).cast(StringType).as("risk_type_desc")
      , $"cdr.risk_type_lv2", $"cdr.risk_type_lv2_desc"
      , $"cdr.risk_type_lv1", $"cdr.risk_type_lv1_desc").where($"pra.risk_type".isNotNull
      && length($"pra.risk_type") <= 30
      && $"cdr.risk_type".isNull).groupBy($"groupid", $"pra.risk_type", $"datasrc", $"risk_type_desc",
      $"cdr.risk_type_lv2", $"cdr.risk_type_lv2_desc",
      $"cdr.risk_type_lv1", $"cdr.risk_type_lv1_desc").agg(min($"client_ds_id").as("client_ds_id"))

    //NOW UNION THE MISSING RECORDS FETCHED FROM PAT_RISK_ATTRIB AND THE UNION RISK_TYPE_ROLLUP TABLE
    val cdrRiskTypeRollup1 = cdrRiskTypeRollup.unionByName(patRiskAttrib1)

    //APPLYING ADDITIONAL TRANSFORMATIONS ON THE UNION
    val rollup = cdrRiskTypeRollup1.alias("cdr").select(
      $"cdr.groupid".as("groupid")
      , $"cdr.datasrc".as("datasrc")
      , $"cdr.client_ds_id".as("client_ds_id")
      , $"cdr.risk_type".as("risk_type")
      , substring(coalesce($"cdr.risk_type_desc",
        concat(lit("UNDEFINED ("), $"cdr.risk_type", lit(")"))), 1, 150).as("risk_type_desc")
      , substring(coalesce($"cdr.risk_type_lv2",
        concat(lit("3."), $"cdr.risk_type")), 1, 30).as("risk_type_lv2")
      , substring(when($"cdr.risk_type_lv2".isNull,
        coalesce($"cdr.risk_type_desc",
          concat(lit("UNDEFINED ("), $"cdr.risk_type", lit(")")))).otherwise(
        coalesce($"cdr.risk_type_lv2_desc",
          concat(lit("UNDEFINED ("), $"cdr.risk_type_lv2", lit(")")))),
        1, 150).as("risk_type_lv2_desc")
    , substring(coalesce($"cdr.risk_type_lv1",
        when($"cdr.risk_type_lv2".isNotNull,
          concat(lit("2."), $"cdr.risk_type_lv2"))
          .otherwise(concat(lit("3."), $"cdr.risk_type"))),
        1, 30).as("risk_type_lv1")
      , substring(when($"cdr.risk_type_lv1".isNull,
        when($"cdr.risk_type_lv2".isNull, coalesce($"cdr.risk_type_desc",
          concat(lit("UNDEFINED ("), $"cdr.risk_type", lit(")")))).otherwise(
          coalesce($"cdr.risk_type_lv2_desc",
            concat(lit("UNDEFINED ("), $"cdr.risk_type_lv2", lit(")"))))).otherwise(
        coalesce($"cdr.risk_type_lv1_desc",
          concat(lit("UNDEFINED ("), $"cdr.risk_type_lv1", lit(")")))),
        1, 150).as("risk_type_lv1_desc")
      , row_number().over(Window.partitionBy($"cdr.risk_type").orderBy(
        when($"cdr.risk_type_desc".isNotNull, lit(0)).otherwise(lit(1)),
        when($"cdr.risk_type_lv2".isNotNull, lit(0)).otherwise(lit(1)),
        when($"cdr.risk_type_lv1".isNotNull, lit(0)).otherwise(lit(1)),
        $"cdr.risk_type_desc", $"cdr.risk_type_lv2", $"cdr.risk_type_lv1")).as("rn"))
      .where($"cdr.risk_type".isNotNull &&
        length($"cdr.risk_type") <= 30 &&
        $"rn" === 1).drop($"rn")

    rollup.toDF()

  }
}
