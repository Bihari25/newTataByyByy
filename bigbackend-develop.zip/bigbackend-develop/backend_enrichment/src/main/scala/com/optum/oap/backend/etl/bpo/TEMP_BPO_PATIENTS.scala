package com.optum.oap.backend.etl.bpo

import com.optum.oap.backend.cdrTempModel.{temp_bpo_calculate_params, temp_bpo_patients}
import com.optum.oap.backend.etl.bpo.BpoUtil.getBpoInputParameters
import com.optum.oap.cdr.models._
import com.optum.oap.sparkdataloader.{RuntimeVariables, TableInfo, UserDefinedFunctionForDataLoader}
import org.apache.spark.sql.functions._
import org.apache.spark.sql.types.{IntegerType, StringType}
import org.apache.spark.sql.{DataFrame, SparkSession}

/**
  *
  * Copyright 2019 Optum Analytics
  *
  * Date: 5/16/19
  *
  * Creator: pavula1
  */
object TEMP_BPO_PATIENTS extends TableInfo[temp_bpo_patients] {

  override def dependsOn = Set("CLINICALENCOUNTER", "PATIENT_SUMMARY_GRP_MPI", "INSURANCE", "PATIENT_SUMMARY", "ZO_BPO_MAP_EMPLOYER",
    "MAP_FINANCIAL_CLASS", "MAP_PREDICATE_VALUES", "TEMP_BPO_CALCULATE_PARAMS")

  override def name = "TEMP_BPO_PATIENTS"

  override def createDataFrame(sparkSession: SparkSession,
                               loadedDependencies: Map[String, DataFrame],
                               udfMap: Map[String, UserDefinedFunctionForDataLoader],
                               runtimeVariables: RuntimeVariables): DataFrame = {

    import sparkSession.implicits._

    val clinicalEnc = loadedDependencies("CLINICALENCOUNTER").as[clinicalencounter]

    val patientSummaryGrp = loadedDependencies("PATIENT_SUMMARY_GRP_MPI").as[patient_summary_grp_mpi]

    val insurance = loadedDependencies("INSURANCE").as[insurance]

    val patientSummary = loadedDependencies("PATIENT_SUMMARY").as[patient_summary]

    val mapEmployer = broadcast(loadedDependencies("ZO_BPO_MAP_EMPLOYER")).as[zo_bpo_map_employer]

    val financialClass = broadcast(loadedDependencies("MAP_FINANCIAL_CLASS")).as[map_financial_class]

    val predicateValues = broadcast(loadedDependencies("MAP_PREDICATE_VALUES")).as[map_predicate_values]

    val tempParams = broadcast(loadedDependencies("TEMP_BPO_CALCULATE_PARAMS")).as[temp_bpo_calculate_params]

    val inputParameters = getBpoInputParameters(sparkSession, tempParams)

    val startdate3 = inputParameters.engineStartDate3
    val startdate2 = inputParameters.engineStartDate2
    val endDate = inputParameters.engineEndDate
    val startdate = inputParameters.engineStartDate

    val clinicalEncounter = clinicalEnc.alias("c").filter($"grp_mpi".isNotNull)
      .join(patientSummaryGrp.alias("p"), Seq("grp_mpi"), "inner")
      .where(to_date($"arrivaltime") >= lit(startdate2) && to_date($"arrivaltime") <= lit(endDate) &&
        $"c.groupid".isin(predicateValues.select($"groupid")
          .where($"DATA_SRC" === "BPO_NONPAYER"
            && $"ENTITY" === "BPO_TABLES"
            && $"TABLE_NAME" === "PP_BPO_MEMBER_DETAIL"
            && $"COLUMN_NAME" === "MEMBERID"
            && upper($"COLUMN_VALUE") === "YES").distinct().collect().map(_.getString(0)): _*))
      .select($"c.groupid",
        $"c.grp_mpi", $"p.dob",
        $"p.mapped_Gender",
        lit(startdate3).alias("effective_date"),
        lit(endDate).alias("end_date"),
        $"p.mapped_race",
        $"p.mapped_ethnicity",
        $"p.mapped_language",
        $"p.date_of_death"
      ).distinct()

    val clinical = clinicalEncounter.select($"groupid",
      $"grp_mpi",
      $"dob",
      lit(" ").alias("employeraccountid"),
      $"mapped_gender",
      $"effective_date",
      $"end_date",
      lit(0).alias("payer"),
      lit("Other").alias("productcode"),
      lit(null).cast(IntegerType).alias("lineofbusinessid"),
      lit("N").alias("pharmacy_benefit_flag"),
      $"mapped_race",
      $"mapped_ethnicity",
      $"mapped_language",
      $"date_of_death",
      lit(" ").alias("contract_id"),
      $"grp_mpi".alias("subscriberid"),
      lit("Y").alias("subscriberflag"),
      lit(null).cast(StringType).alias("coverage_status"),
      lit(null).cast(StringType).alias("emp_acct_id"),
      lit(null).cast(StringType).alias("contracttype"),
      lit(null).cast(StringType).alias("benefitplan"),
      lit("MED").alias("coverageclasscode"),
      lit(null).alias("dental_benefit_ind"),
      lit(null).alias("medical_benefit_ind"),
      lit(null).alias("mh_benefit_ind"),
      lit(null).alias("employee_type"),
      lit(null).alias("hra_ind"),
      lit(null).alias("hsa_ind"),
      lit(null).alias("product_dtl_code")
    )

    val ins = insurance.alias("i").filter('grp_mpi.isNotNull)
      .join(patientSummaryGrp.alias("c"),
        $"c.groupid" === $"i.groupid" && $"c.grp_mpi" === $"i.grp_mpi", "inner")
      .join(patientSummary.alias("sc"),
        $"sc.client_ds_id" === $"i.client_ds_id" && $"sc.patientid" === $"i.subscriber_id", "left")
      .join(mapEmployer.alias("zb"),
        $"zb.client_ds_id" === $"i.client_ds_id" && $"zb.groupid" === $"i.groupid", "inner")
      .join(financialClass.alias("fc"),
        $"i.plantype" === $"fc.mnemonic" && $"fc.groupid" === $"i.groupid", "left_outer")
      .where(coalesce(to_date($"enrollenddt"), lit(endDate)) >= lit(startdate)
        && !$"i.client_ds_id".isin(predicateValues.select($"client_ds_id")
        .where($"DATA_SRC" === "BPO_ENROLL_EXCLUDE"
          && $"ENTITY" === "BPO_TABLES"
          && $"TABLE_NAME" === "PP_BPO_MEMBER_DETAIL"
          && $"COLUMN_NAME" === "ENDDATE").collect().map(_.getInt(0)): _*)
      )
      .select($"i.groupid",
        $"i.grp_mpi",
        $"c.dob",
        $"employeraccountid",
        $"c.mapped_gender",
        coalesce($"enrollstartdt", $"ins_timestamp").alias("effective_date"),
        coalesce($"enrollenddt", lit(endDate)).alias("end_date"),
        lit(1).alias("payer"),
        when(coalesce($"fc.cui", $"mappedplanfincode") === "CH000099", "MLI")
          .when(coalesce($"fc.cui", $"mappedplanfincode").isin("CH000100","CH004570"), "MR")
          .when(coalesce($"fc.cui", $"mappedplanfincode") === "CH000097", "HMO")
          .when(coalesce($"fc.cui", $"mappedplanfincode") === "CH002999", "MDE")
          .otherwise("Other").alias("productcode"),
        when(coalesce($"fc.cui", $"mappedplanfincode") === "CH000099", 1)
          .when(coalesce($"fc.cui", $"mappedplanfincode").isin("CH000100","CH004570"), 2)
          .when(coalesce($"fc.cui", $"mappedplanfincode") === "CH000097", 0)
          .when(coalesce($"fc.cui", $"mappedplanfincode") === "CH002999", 3)
          .alias("lineofbusinessid"),
        when(upper($"i.pharmacy_benefit_flag") === "N", "N").otherwise("Y").alias("pharmacy_benefit_flag"),
        $"c.mapped_race",
        $"c.mapped_ethnicity",
        $"c.mapped_language",
        $"c.date_of_death",
        coalesce($"i.contract_id", $"zb.employeraccountid").alias("contract_id"),
        coalesce($"sc.grp_mpi", $"i.grp_mpi").alias("subscriberid"),
        when($"sc.grp_mpi" =!= $"i.grp_mpi", "N").otherwise("Y").alias("subscriberflag"),
        $"i.subscriber_relation".alias("coverage_status"),
        when(length($"i.emp_acct_id") <= 30, $"i.emp_acct_id").otherwise(lit(null)).alias("emp_acct_id"),
        when(length($"i.contract_type_code") <= 30, $"i.contract_type_code").otherwise(lit(null)).alias("contracttype"),
        when(length($"i.benefit_plan_code") <= 30, $"i.benefit_plan_code").otherwise(lit(null)).alias("benefitplan"),
        lit("MED").alias("coverageclasscode"),
        $"i.dental_benefit_ind".as("dental_benefit_ind"),
        $"i.medical_benefit_ind".as("medical_benefit_ind"),
        $"i.mh_benefit_ind".as("mh_benefit_ind"),
        when(length($"i.employee_type") <= 30, $"i.employee_type").as("employee_type"),
        $"i.hra_ind".as("hra_ind"),
        $"i.hsa_ind".as("hsa_ind"),
        when(length($"i.product_code") <= 30, $"i.product_code").as("product_dtl_code")
      ).distinct()

    val result = clinical.union(ins)

    result.select($"*")
  }
}
