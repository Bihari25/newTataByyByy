package com.optum.oap.backend.etl.summary

import com.optum.oap.backend.cdrTempModel.{provider_xref, ref_cmsnpi_partial}
import com.optum.oap.backend.etl.common.{IsSafeToNumber, PartitionedDataOperations}
import com.optum.oap.backend.loader.EnrichmentRunTimeVariables
import com.optum.oap.cdr.models._
import com.optum.oap.sparkdataloader.{RuntimeVariables, TableInfo, UserDefinedFunctionForDataLoader}
import org.apache.spark.sql.expressions.Window
import org.apache.spark.sql.types.{IntegerType, StringType}
import org.apache.spark.sql.{DataFrame, SparkSession}
import org.slf4j.LoggerFactory
import org.apache.spark.sql.functions._

object ZH_PROVIDER_MASTER extends TableInfo[zh_provider_master] with PartitionedDataOperations {

  private val log = LoggerFactory.getLogger(this.getClass)

  override def dependsOn: Set[String] = Set(
    "MAP_PREDICATE_VALUES",
    "ZH_PROVIDER",
    "V_PROVIDER_XREF",
    "ZH_PROVIDER_MASTER_XREF",
    "ZCM_CLIENT_DS_PRIORITY",
    "MV_CLIENT_DATA_SRC",
    "REF_PRIMARYSPECIALTY",
    "MAP_PROVIDER_TAXONOMY",
    "MAP_SPECIALTY",
    "ZH_SPECIALTY_TIER",
    "MAP_DOMAIN_CDSID_PRIORITY",
    "REF_CMSNPI")

  override protected def createDataFrame(sparkSession: SparkSession,
                                         loadedDependencies: Map[String, DataFrame],
                                         udfMap: Map[String, UserDefinedFunctionForDataLoader],
                                         runtimeVariables: RuntimeVariables): DataFrame = {
    import sparkSession.implicits._

    implicit val session = sparkSession
    val groupId = EnrichmentRunTimeVariables(runtimeVariables).clientId
    val schema = EnrichmentRunTimeVariables(runtimeVariables).cdrSchema
    val mapPredicateValue = broadcast(loadedDependencies("MAP_PREDICATE_VALUES")).as[map_predicate_values]
    val zhProvider = loadedDependencies("ZH_PROVIDER").as[zh_provider]
    val pXref = loadedDependencies("V_PROVIDER_XREF").as[provider_xref]
    val providerXRef = if(pXref.isEmpty) loadData(schema, "V_PROVIDER_XREF").as[provider_xref] else pXref
    val zhProviderMasterXRef = broadcast(loadedDependencies("ZH_PROVIDER_MASTER_XREF")).as[zh_provider_master_xref]
    val zcmClientDSPriority = broadcast(loadedDependencies("ZCM_CLIENT_DS_PRIORITY")).as[zcm_client_ds_priority]
    val mvClientDataSrc = broadcast(loadedDependencies("MV_CLIENT_DATA_SRC")).as[mv_client_data_src]
    val refPrimarySpeciality = broadcast(loadedDependencies("REF_PRIMARYSPECIALTY")).as[ref_primaryspecialty]
    val mapProviderTaxonomy = broadcast(loadedDependencies("MAP_PROVIDER_TAXONOMY")).as[map_provider_taxonomy]
    val mapSpecialty = broadcast(loadedDependencies("MAP_SPECIALTY").where($"groupid" === lit(groupId))).as[map_specialty]
    val zhSpecialtyTier = broadcast(loadedDependencies("ZH_SPECIALTY_TIER")).as[zh_specialty_tier]
    val mapDomainCDSIDPriority = broadcast(loadedDependencies("MAP_DOMAIN_CDSID_PRIORITY")).as[map_domain_cdsid_priority]
    val refCMSNPI = loadedDependencies("REF_CMSNPI").as[ref_cmsnpi_partial]

    val predicateValues = mapPredicateValue
      .where($"table_name" === lit("ZH_PROVIDER_MASTER") &&
        $"data_src" === lit("ZH_PROVIDER") && $"entity" === "ZH_PROVIDER_MASTER" &&
        $"column_name" === "PROVIDEREXCLUSION").select($"column_value").as[String].collect()
    val minColumnValue = if (predicateValues.isEmpty) "N" else predicateValues.filter(_ != null).min

    val nestedDataSet = zhProvider.as("a")
      .join(providerXRef.as("b"),
        $"a.groupid" === $"b.groupid" && $"a.localproviderid" === $"b.providerid" && $"a.client_ds_id" === $"b.client_ds_id")
      .join(zhProviderMasterXRef.as("c"), $"b.hgprovid" === $"c.hgprovid")
      .join(zcmClientDSPriority.as("cdp"), $"a.client_ds_id" === $"cdp.client_ds_id", "left_outer")
      .join(mvClientDataSrc.as("cds"),
        $"a.client_ds_id" === $"cds.client_data_src_id" &&
          $"a.groupid" === $"cds.client_id" &&
          !$"cds.data_src_name".isin("NLP", "COMMON"), "left_outer")
      .join(refPrimarySpeciality.as("ps"), $"a.npi" === $"ps.npi", "left_outer")
      .join(mapProviderTaxonomy.as("dsc"), $"ps.primarycode" === $"dsc.taxonomy_code", "left_outer")
      .join(mapSpecialty.as("m"), $"a.localprimaryspecialty" === $"m.mnemonic", "left_outer")
      .join(zhSpecialtyTier.as("t"), $"m.cui" === $"t.cui", "left_outer")
      .join(mapDomainCDSIDPriority.as("mdcp_n"),
        $"a.groupid" === $"mdcp_n.groupid" && $"mdcp_n.client_ds_id" === $"a.client_ds_id" &&
          when($"mdcp_n.datasrc" === lit("ALL"), $"a.datasrc").otherwise($"mdcp_n.datasrc") === $"a.datasrc"
          && $"mdcp_n.domain" === lit("PROV.NAME"), "left_outer")
      .join(mapDomainCDSIDPriority.as("mdcp_s"),
        $"a.groupid" === $"mdcp_s.groupid" && $"mdcp_s.client_ds_id" === $"a.client_ds_id" &&
          when($"mdcp_s.datasrc" === lit("ALL"), $"a.datasrc").otherwise($"mdcp_s.datasrc") === $"a.datasrc"
          && $"mdcp_s.domain" === lit("PROV.SPEC"), "left_outer")
      .select(
        $"a.groupid",
        $"c.hgprovid",
        $"c.master_hgprovid",
        $"a.client_ds_id",
        when(length($"a.npi") === lit(10) && IsSafeToNumber.isSafeToNumber($"a.npi").isNotNull, $"a.npi")
          .otherwise(lit(null)).as("npi"),
        expr("""nullif(a.providername, "No Provider Name")""").as("providername"),
        count($"c.hgprovid").over(Window.partitionBy($"a.groupid", $"c.master_hgprovid", coalesce($"a.providername", lit("No Provider Name"))))
          .as("providername_cnt"),
        size(collect_set($"a.client_ds_id")
          .over(Window.partitionBy($"a.groupid", $"c.master_hgprovid", coalesce($"a.providername", lit("No Provider Name")))))
          .as("providername_srcs"),
        rank().over(Window.partitionBy($"a.groupid", $"c.master_hgprovid")
          .orderBy($"cdp.priority",
            when($"cds.is_shared" === lit("Y"), lit(0))
              .when($"cds.is_shared" === lit("N"), lit(1))
              .otherwise(lit(2)), $"a.client_ds_id")).as("dsrank"),
        $"a.localprimaryspecialty",
        $"m.cui",
        $"dsc.specialty_cui",
        $"t.tier",
        $"a.emailaddress",
        $"a.primaryfacilityid",
        $"a.providerexclusionflag",
        $"a.localclassification",
        $"a.mappedcredentialtype",
        $"mdcp_n.priority".as("prov_name_priority"),
        $"mdcp_s.priority".as("prov_spec_priority")
      )

    val bestProviderDetails = nestedDataSet.as("p")
      .select(
        $"p.*",
        first($"p.providername", true)
          .over(Window.partitionBy($"p.groupid", $"p.master_hgprovid")
            .orderBy($"p.prov_name_priority".asc_nulls_last,
              when($"p.providername".isNotNull && $"p.providername" != lit("No Provider Name"), lit(0)).otherwise(lit(1)),
              $"p.providername_cnt".desc, $"p.providername_srcs".desc, $"p.dsrank", $"p.hgprovid")).as("best_providername"),
        first($"p.localprimaryspecialty", true)
          .over(Window.partitionBy($"p.groupid", $"p.master_hgprovid")
            .orderBy($"p.prov_spec_priority".asc_nulls_last,
              expr("nvl2(p.localprimaryspecialty, 0, 1)"), expr("nvl2(p.cui,0,1)"), $"p.tier",
              when($"p.cui" === $"p.specialty_cui", lit(0)).otherwise(lit(1)), $"p.dsrank", $"p.hgprovid")).as("best_localprimaryspecialty"),
        first($"p.localclassification", true).over(Window.partitionBy($"p.groupid", $"p.master_hgprovid")
          .orderBy(expr("nvl2(p.localclassification, 0, 1)"), $"p.dsrank", $"p.localclassification".desc)).as("best_localclassification"))

    val groupedDataSet = bestProviderDetails
      .groupBy($"groupid", $"master_hgprovid")
      .agg(
        min($"best_providername").as("providername"),
        min($"emailaddress").as("emailaddress"),
        min($"primaryfacilityid").as("primaryfacilityid"),
        min($"providerexclusionflag").as("providerexclusionflag"),
        min($"best_localprimaryspecialty").as("localprimaryspecialty"),
        min($"best_localclassification").as("localclassification"),
        min($"npi").as("npi"),
        min($"mappedcredentialtype").as("mappedcredentialtype"),
        countDistinct($"npi").as("npi_cnt"),
        countDistinct($"hgprovid").as("match_cnt")
      )

    val output = groupedDataSet.as("mpv")
      .join(refCMSNPI.as("r"), $"mpv.npi" === $"r.npi", "left_outer")
      .select(
        $"mpv.groupid",
        $"mpv.master_hgprovid",
        coalesce($"mpv.providername",
          when($"r.entity_type_code" === lit(1), concat_ws(", ", $"r.prov_lastname_legalname", $"r.prov_firstname"))
            .when($"r.entity_type_code" === lit(2), coalesce($"r.prov_oth_org_name", $"r.prov_org_name_legal_bus_name"))
            .otherwise(lit(null)), lit("No Provider Name")).as("providername"),
        $"mpv.npi".as("npi"),
        $"mpv.localprimaryspecialty".as("localprimaryspecialty"),
        $"mpv.emailaddress".as("emailaddress"),
        $"mpv.primaryfacilityid".as("primaryfacilityid"),
        when(lit(minColumnValue) === "Y", coalesce(
          when($"r.ENTITY_TYPE_CODE" === lit(1), lit("N"))
            .when($"r.ENTITY_TYPE_CODE" === lit(2), lit("Y")),
          $"mpv.providerexclusionflag"))
          .otherwise($"mpv.providerexclusionflag").as("providerexclusionflag"),
        $"mpv.match_cnt".cast(IntegerType).as("match_cnt"),
        $"mpv.localclassification".as("localclassification"),
        $"mappedcredentialtype".as("mappedcredentialtype"),
        lit(null).cast(StringType).as("prim_spec"),
        lit(null).cast(StringType).as("prim_spec_src")
      ).as[zh_provider_master]

    output.toDF()
  }
}
