package com.optum.oap.backend.etl.enrichment

import com.optum.oap.backend.cdrTempModel.{ref_cmsnpi_partial}
import com.optum.oap.cdr.models._
import com.optum.oap.sparkdataloader.{RuntimeVariables, TableInfo, UserDefinedFunctionForDataLoader}
import org.apache.spark.sql.expressions.Window
import org.apache.spark.sql.functions._
import org.apache.spark.sql.types.DataTypes
import org.apache.spark.sql.{DataFrame, SparkSession}
import org.slf4j.LoggerFactory
import com.optum.oap.backend.etl.common.Functions.mpvList
import com.optum.oap.backend.loader.EnrichmentRunTimeVariables

object ICPM_PROVIDER_ATTRIBUTES extends TableInfo[zh_prov_attribute] {

  private val log = LoggerFactory.getLogger(this.getClass)

  override def dependsOn = Set("INT_CLAIM_PROV")

  override def name = "ICPM_PROVIDER_ATTRIBUTES"

  override def createDataFrame(sparkSession: SparkSession,
                               loadedDependencies: Map[String, DataFrame],
                               udfMap: Map[String, UserDefinedFunctionForDataLoader],
                               runtimeVariables: RuntimeVariables): DataFrame = {
    import sparkSession.implicits._

    val intClaimProvIn = loadedDependencies("INT_CLAIM_PROV").as[int_claim_prov]

    val provDf1 = intClaimProvIn
      .select(
        $"groupid",
        $"client_ds_id",
        $"prov_id".as("localproviderid"),
        $"eff_date",
        $"end_date",
        upper(first("primary_span", true).over(Window.partitionBy($"client_ds_id", $"eff_date", $"end_date", $"prov_id").orderBy($"primary_span".desc_nulls_last))).as("primary_span"),
        lit(null).cast(DataTypes.StringType).as("master_hgprovid"),
        expr("stack(17,cust_attr_1, 'CH002486', cust_attr_2, 'CH002487', cust_attr_3, 'CH002488', cust_attr_4, 'CH002489'," +
          "cust_attr_5, 'CH002987', cust_attr_6, 'CH002988', cust_attr_7, 'CH003906', cust_attr_8, 'CH003907', cust_attr_9, 'CH003908', cust_attr_10," +
          "'CH003909', cust_attr_11, 'CH003910', cust_attr_12, 'CH003911', cust_attr_13, 'CH003912', cust_attr_14, 'CH003913', cust_attr_15, 'CH003914'," +
          " ii_prov_userdef_1, 'CH004048', ii_prov_userdef_2, 'CH004049') as (attribute_value,attribute_type_cui)")).where($"attribute_value".isNotNull && $"prov_id".isNotNull)
      .distinct()

    val provDf2 = intClaimProvIn
      .select(
        $"groupid",
        $"client_ds_id",
        $"prov_id".as("localproviderid"),
        $"eff_date",
        $"end_date",
        upper(first("primary_span", true).over(Window.partitionBy($"client_ds_id", $"eff_date", $"end_date", $"prov_id").orderBy($"primary_span".desc_nulls_last))).as("primary_span"),
        lit(null).cast(DataTypes.StringType).as("master_hgprovid"),
        expr("stack(5,cust_attr_16, 'CH003915', cust_attr_17, 'CH003916', cust_attr_18, 'CH003917', cust_attr_19, 'CH003918',cust_attr_20, 'CH003919') as (attribute_value,attribute_type_cui)"))
      .where($"attribute_value".isNotNull && $"prov_id".isNotNull)
      .distinct()

    provDf1.unionByName(provDf2)

  }
}
