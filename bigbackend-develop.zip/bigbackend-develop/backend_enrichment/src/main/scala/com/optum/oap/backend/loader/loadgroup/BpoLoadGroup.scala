package com.optum.oap.backend.loader.loadgroup

import com.optum.oap.backend.loader.{BpoDependencies, DataTableDependencies, EnrichmentQueryRegistry, EnrichmentRunTimeVariables, GitHubBpoConfigReader, S3BpoConfigReader, StaticDependencies}
import com.optum.oap.sparkdataloader.TableInfo
import org.apache.spark.sql.SparkSession

trait BpoLoadGroup extends LoadGroup {

  override def loadGroup: String = "bpo"

  override def initialDependencies(runTimeVariables: EnrichmentRunTimeVariables, sparkSession: SparkSession): Seq[TableInfo[_ <: Product with Serializable]] = {
    import runTimeVariables._
    DataTableDependencies.dataInitialDependencies(cdrSchema, "") ++
      StaticDependencies.staticInitialDependencies(cdrSchema) ++
      BpoDependencies.bpoInitialDependencies(cdrSchema)
  }

  override def queryRegistry(runTimeVariables: EnrichmentRunTimeVariables, sparkSession: SparkSession): Seq[TableInfo[_ <: Product with Serializable]] = {
    val bpoConfigReader = if (runTimeVariables.clientBucket.isEmpty) GitHubBpoConfigReader() else S3BpoConfigReader()
    val bpoComponents = bpoConfigReader
      .constructBpoComponents(clientId = runTimeVariables.clientId,
        release = runTimeVariables.release,
        cdrCycle = runTimeVariables.cdrCycle)
    EnrichmentQueryRegistry.bpoQueryRegistry(bpoComponents) ++ super.queryRegistry(runTimeVariables, sparkSession)
  }
}
