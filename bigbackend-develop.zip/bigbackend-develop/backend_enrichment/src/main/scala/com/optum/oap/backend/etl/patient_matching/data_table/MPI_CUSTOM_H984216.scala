package com.optum.oap.backend.etl.patient_matching.data_table

import com.optum.oap.backend.cdrTempModel.pat_match_prep
import com.optum.oap.backend.etl.common._
import com.optum.oap.backend.etl.patient_matching.PATIENT_MPI_UTILS
import com.optum.oap.backend.loader.EnrichmentRunTimeVariables
import com.optum.oap.cdr.models._
import com.optum.oap.sparkdataloader.{RuntimeVariables, TableInfo, UserDefinedFunctionForDataLoader}
import org.apache.spark.sql.expressions.Window
import org.apache.spark.sql.functions._
import org.apache.spark.sql.types.{IntegerType, LongType, StringType}
import org.apache.spark.sql.{DataFrame, SparkSession}

object MPI_CUSTOM_H984216 extends TableInfo[mpi_custom] {

  override def dependsOn = Set("PAT_MATCH_PREP", "PATIENTDETAIL_PREMATCH", "MAP_GENDER", "PATIENT_ID_PREMATCH", "ORG_ROLLUP", "ECDR_MPI_CUSTOM_H984216")

  override def name = "MPI_CUSTOM_H984216"

  override def createDataFrame(sparkSession: SparkSession,
                               loadedDependencies: Map[String, DataFrame],
                               udfMap: Map[String, UserDefinedFunctionForDataLoader],
                               runtimeVariables: RuntimeVariables): DataFrame = {
    import sparkSession.implicits._

    val tempPatMatchPrep = loadedDependencies("PAT_MATCH_PREP").as[pat_match_prep]
    val patientId = loadedDependencies("PATIENT_ID_PREMATCH").as[patient_id]
    val mapGender = broadcast(loadedDependencies("MAP_GENDER").as[map_gender])
    val patientDetail = loadedDependencies("PATIENTDETAIL_PREMATCH").distinct.as[patientdetail]
    val orgRollup = broadcast(loadedDependencies("ORG_ROLLUP").as[org_rollup])

    val dailyBuild = if (runtimeVariables.asInstanceOf[EnrichmentRunTimeVariables].buildType == CDRConstants.DELTA_BUILD_TYPE) true else false


    val ps = tempPatMatchPrep
      .where($"dob".isNotNull)
      .select(
        $"groupid", $"client_ds_id", $"patientid", $"hgpid", $"dob",
        upper($"fname").as("first_name"),
        upper($"lname").as("last_name"),
        CleanPatientName.cleanPatientName($"fname", lit(3)).as("fname"),
        CleanPatientName.cleanPatientName($"lname", lit(3)).as("lname")
      ).distinct

    val pid = patientId.as("tpi")
      .where(!trim(substring(regexp_replace($"idvalue", "-", ""), 1, 9)).isin(PATIENT_MPI_UTILS.getBadSSNs: _*) &&
        $"idtype" === lit("SSN") && !SSNValidation.cleanAndValidate($"idvalue").isin(SSNValidation.INVALID_OUTCOMES: _*)
      )
      .select(
        $"groupid", $"client_ds_id", $"patientid",
        trim(substring(regexp_replace($"idvalue", "-", ""), 1, 9)).as("ssn")
      ).distinct

    val dobGrouping = ps.as("t").
      groupBy($"dob")
      .agg(
        size(collect_set("hgpid")).as("hgpids")
      ).select(
      $"dob",
      $"hgpids"
    )

    val dataDf = ps.as("ps")
      .join(pid.as("pid"), Seq("groupid", "client_ds_id", "patientid"), "left")
      .join(patientDetail.as("pd").where($"pd.patientdetailtype" === lit("GENDER")),
        Seq("groupid", "client_ds_id", "patientid"), "left")
      .join(mapGender.as("mg").where($"mg.cui".isInCollection(CDRConstants.MALE_AND_FEMALE_CUIS)), $"pd.localvalue" === $"mg.mnemonic", "left")
      .join(patientDetail.as("pz").where($"pz.patientdetailtype" === lit("ZIPCODE")),
        Seq("groupid", "client_ds_id", "patientid"), "left")
      .join(orgRollup.as("org"), $"ps.client_ds_id" === when(IsSafeToNumber.isSafeToNumber($"org.org_cd"), $"org.org_cd")
        .otherwise(null), "left")
      .join(dobGrouping.as("dg"), Seq("dob"))
      .select(
        $"ps.groupid",
        $"ps.client_ds_id",
        $"ps.patientid",
        $"ps.hgpid",
        $"ps.dob".as("key_attr"),
        $"ps.fname".as("attr_2"),
        $"ps.lname".as("attr_3"),
        upper(regexp_extract($"ps.fname", "^([^ ,]{1,})", 1)).as("attr_4"),
        substring($"ps.first_name", 1, 3).as("attr_5"),
        $"org_lv1_cd".as("attr_6"),
        lit(null).cast(StringType).as("attr_7"),
        $"mg.cui".as("attr_8"),
        $"ssn".as("attr_9"),
        when(substring(trim(regexp_replace(upper($"pz.localvalue"), "O", "0")), 1, 5) =!= lit("00000"), substring(trim(regexp_replace(upper($"pz.localvalue"), "O", "0")), 1, 5))
          .otherwise(lit(null).cast(StringType)).as("attr_10"),
        when($"ORG_LV1_CD".isin(lit("TXMKT")), substring($"lname", 1, 7))
          .otherwise(lit(null).cast(StringType)).as("attr_11"),
        when($"ORG_LV1_CD".isin(lit("TXMKT")), substring($"ps.lname", -7, 7))
          .otherwise(lit(null).cast(StringType)).as("attr_12"),
        $"dg.hgpids".cast(LongType).as("hgpids"),
        lit(1).cast(IntegerType).as("group_cnt")
      )

    val ecdrDf = {
      if (dailyBuild) EnrichmentUtils.removeRowSourceAndModifiedDate(loadedDependencies("ECDR_MPI_CUSTOM_H984216")).as[mpi_custom]
      else sparkSession.emptyDataset[mpi_custom].as[mpi_custom]
    }.as("e")
      .select($"e.*")

    dataDf.unionByName(ecdrDf).distinct()
  }

}
