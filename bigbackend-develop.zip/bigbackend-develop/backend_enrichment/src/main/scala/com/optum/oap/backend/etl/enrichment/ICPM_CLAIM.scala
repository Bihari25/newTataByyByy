package com.optum.oap.backend.etl.enrichment

import com.optum.oap.backend.cdrTempModel.temp_med_claim
import com.optum.oap.backend.etl.common.IsSafeToNumber
import com.optum.oap.cdr.models.{claim, map_specialty_ii, ref_ub04_rev_codes}
import com.optum.oap.sparkdataloader.{RuntimeVariables, TableInfo, UserDefinedFunctionForDataLoader}
import org.apache.spark.sql.functions.{coalesce, _}
import org.apache.spark.sql.types.DataTypes
import org.apache.spark.sql.{DataFrame, SparkSession}
import org.slf4j.LoggerFactory

object ICPM_CLAIM extends TableInfo[claim] {

    private val log = LoggerFactory.getLogger(this.getClass)

    override def dependsOn = Set("ICPM_TEMP_MED_CLAIM", "REF_UB04_REV_CODES", "MAP_SPECIALTY_II")

    override def name = "ICPM_CLAIM"

    override def createDataFrame(sparkSession: SparkSession,
                                 loadedDependencies: Map[String, DataFrame],
                                 udfMap: Map[String, UserDefinedFunctionForDataLoader],
                                 runtimeVariables: RuntimeVariables): DataFrame = {
        import sparkSession.implicits._

        val tempMedClaim = loadedDependencies("ICPM_TEMP_MED_CLAIM").as[temp_med_claim]
        val refUb04RevCodes = broadcast(loadedDependencies("REF_UB04_REV_CODES")).as[ref_ub04_rev_codes]
        val mapSpecialtyIi = broadcast(loadedDependencies("MAP_SPECIALTY_II")).as[map_specialty_ii]

        val tempMedClaimDf = tempMedClaim.as("med")
          .join(refUb04RevCodes.as("r"), $"r.rev_code" === lpad(when(IsSafeToNumber.isSafeToNumber($"Revenue_Code"), $"Revenue_Code").otherwise(null), 4, "0"), "left")
          .join(mapSpecialtyIi.as("ii"), $"ii.local_code" === $"med.servicing_prov_spclty_cd" && $"ii.groupid" === $"med.groupid", "left")
          .where(($"Proc_Code".isNotNull or $"Revenue_Code".isNotNull) or (($"Proc_Code".isNull or $"Revenue_Code".isNull) and ((coalesce(round($"Allowed_Amt", 2), lit(0)) =!= 0) or coalesce(round($"Requested_Amt", 2), lit(0)) =!= 0 or coalesce(round($"Payment_Amt", 2), lit(0)) =!= 0)))
          .select(
              $"med.groupid"
              , $"client_ds_id"
              , $"encounterid"
              , $"datasrc"
              , $"Claim_Header_Id".as("claimid")
              , $"Member_Id".as("patientid")
              , $"Service_Date".as("servicedate")
              , round($"Allowed_Amt", 2).as("allowedamount")
              , when($"Proc_Code".isNotNull && length($"Proc_Cd_Modifier_1") === 2, $"Proc_Cd_Modifier_1").as("mappedcptmod1")
              , when($"Proc_Code".isNotNull && length($"Proc_Cd_Modifier_2") === 2, $"Proc_Cd_Modifier_2").as("mappedcptmod2")
              , when($"Proc_Code".isNotNull && length($"Proc_Cd_Modifier_3") === 2, $"Proc_Cd_Modifier_3").as("mappedcptmod3")
              , $"Requested_Amt".as("charge")
              , $"Servicing_Prov_Id".as("claimproviderid")
              , $"Proc_Code".as("mappedcpt")
              , when($"datasrc" === "int_claim_medical_i", coalesce($"Facility_Code", $"Servicing_Prov_Id"))
                .when($"datasrc" === "int_claim_medical_p", $"Facility_Code").as("facilityid")
              , $"Revenue_Code".as("localrev")
              , $"Proc_Code".as("localcpt")
              , when($"Proc_Code".isNotNull, $"Proc_Cd_Modifier_1").as("localcptmod1")
              , when($"Proc_Code".isNotNull, $"Proc_Cd_Modifier_2").as("localcptmod2")
              , when($"Proc_Code".isNotNull, $"Proc_Cd_Modifier_3").as("localcptmod3")
              , $"place_of_service".as("pos")
              , when($"datasrc" === "int_claim_medical_p", $"Billing_Prov_Id").as("localbillingproviderid")
              , round($"Payment_Amt", 2).as("paidamount")
              , $"Pay_Process_Date".as("post_dt")
              , $"Quantity_Of_Service".as("quantity")
              , $"r.rev_code".as("mappedrev")
              , when($"Service_From_Date".isNotNull, when(year(col("Service_To_Date")) >= 2079, lit(null)).otherwise($"Service_To_Date")).as("to_dt")
              , $"par_flag"
              , $"source_code".as("sourceid")
              , $"ii.ii_code".cast(DataTypes.IntegerType).as("prov_svc_ii_spec")
              , $"contract_id"
              , $"network_paid_status"
              , round($"fee_for_service_amt", 2).as("fee_for_service_amt")
              , round($"copay_amt", 2).as("copay_amt")
              , round($"coinsurance_amt", 2).as("coinsurance_amt")
              , round($"deductable_amt", 2).as("deductible_amt")
              , round($"pat_liability_amt", 2).as("pat_liability_amt")
              , round($"coord_benifits_amt", 2).as("coord_benefits_amt")
              , round($"withhold_amt", 2).as("withhold_amt")
              , round($"capitation_amt", 2).as("capitation_amt")
              , $"capitated_service_flag"
              , $"denied_flag"
              , $"pseudo_flag"
              , $"II_CUST_ATTR_1".as("CUST_ATTR_1")
              , $"II_CUST_ATTR_2".as("CUST_ATTR_2")
              , $"II_CUST_ATTR_3".as("CUST_ATTR_3")
              , $"II_CUST_ATTR_4".as("CUST_ATTR_4")
              , $"II_CUST_ATTR_5".as("CUST_ATTR_5")
              , $"II_CUST_ATTR_6".as("CUST_ATTR_6")
              , $"II_CUST_ATTR_7".as("CUST_ATTR_7")
              , $"II_CUST_ATTR_8".as("CUST_ATTR_8")
              , $"II_CUST_ATTR_9".as("CUST_ATTR_9")
              , $"II_CUST_ATTR_10".as("CUST_ATTR_10")
              , $"II_CUST_ATTR_11".as("CUST_ATTR_11")
              , $"II_CUST_ATTR_12".as("CUST_ATTR_12")
              , $"II_CUST_ATTR_13".as("CUST_ATTR_13")
              , $"II_CUST_ATTR_14".as("CUST_ATTR_14")
              , $"II_CUST_ATTR_15".as("CUST_ATTR_15")
              , when(IsSafeToNumber.isSafeToNumber($"II_CUST_ATTR_16"), $"II_CUST_ATTR_16").otherwise(null).as("CUST_ATTR_16")
              , when(IsSafeToNumber.isSafeToNumber($"II_CUST_ATTR_16"), $"II_CUST_ATTR_16").otherwise(null).as("CUST_ATTR_17")
              , when(IsSafeToNumber.isSafeToNumber($"II_CUST_ATTR_18"), $"II_CUST_ATTR_18").otherwise(null).as("CUST_ATTR_18")
              , when(IsSafeToNumber.isSafeToNumber($"II_CUST_ATTR_19"), $"II_CUST_ATTR_19").otherwise(null).as("CUST_ATTR_19")
              , when(IsSafeToNumber.isSafeToNumber($"II_CUST_ATTR_20"), $"II_CUST_ATTR_20").otherwise(null).as("CUST_ATTR_20")
              , round($"admin_fee_amt", 2).as("admin_fee_amt")
              , $"serv_prov_affil_id".as("claim_prov_affil_id")
              , $"serv_prov_status_id".as("claim_prov_status_id")
              , round($"not_covered_amt", 2).as("not_covered_amt")
              , $"ordering_prov_id"
              , round($"other_1_amt", 2).as("other_1_amt")
              , round($"other_2_amt", 2).as("other_2_amt")
              , round($"other_3_amt", 2).as("other_3_amt")
              , round($"other_4_amt", 2).as("other_4_amt")
              , round($"other_carrier_pay_amt", 2).as("other_carrier_pay_amt")
              , $"spec_rx_ind"
              , $"type_of_bill_code"
              , when(length($"type_of_service") <= 30, $"type_of_service").otherwise(lit(null)).as("type_of_service")
              , lit(null).cast(DataTypes.StringType).as("claim_mstrprovid")
              , lit(null).cast(DataTypes.DoubleType).as("costamount")
              , lit(null).cast(DataTypes.StringType).as("ein")
              , lit(null).cast(DataTypes.StringType).as("grp_mpi")
              , lit(null).cast(DataTypes.StringType).as("hgpid")
              , lit(null).cast(DataTypes.StringType).as("localcptmod4")
              , lit(null).cast(DataTypes.StringType).as("localhcpcs")
              , lit(null).cast(DataTypes.StringType).as("localicd9")
              , lit(null).cast(DataTypes.StringType).as("mappedcptmod4")
              , lit(null).cast(DataTypes.StringType).as("mappedhcpcs")
              , lit(null).cast(DataTypes.StringType).as("mappedicd9")
              , lit(null).cast(DataTypes.LongType).as("seq")
              , lit(null).cast(DataTypes.StringType).as("techorprof")
              , $"med.admit_type_code"
              , $"med.referring_prov_id"
          ).distinct


        tempMedClaimDf.where($"claimid".isNotNull and $"patientid".isNotNull and $"servicedate".isNotNull)

    }
}