package com.optum.oap.backend.etl.encgrps

import com.optum.oap.backend.cdrTempModel.temp_eeg_p1a
import com.optum.oap.sparkdataloader.QueryAndMetadata

object TEMP_EEG_P1A extends QueryAndMetadata[temp_eeg_p1a] {

  override def name: String = "TEMP_EEG_P1A"

  override def sparkSql: String =
    """
      |SELECT
      |    ce.groupid,
      |    ce.client_ds_id,
      |    ce.encounterid,
      |    ce.grp_mpi,
      |    ce.arrivaltime,
      |    ce.dischargetime,
      |    ce.patienttype,
      |    ce.master_facility_name,
      |    pdx.prindx,
      |    pdx.prindx_codetype
      |FROM
      |    temp_visit_enctr ce
      |    LEFT OUTER JOIN temp_eeg_pdx pdx ON ( ce.groupid = pdx.groupid
      |                                          AND ce.client_ds_id = pdx.client_ds_id
      |                                          AND ce.encounterid = pdx.encounterid
      |                                          AND ce.grp_mpi = pdx.grp_mpi )
      |WHERE
      |    ce.patienttype IN (
      |        'CH000106',
      |        'CH000107',
      |        'CH000109',
      |        'CH000113',
      |        'CH000795',
      |        'CH003031',
      |        'CH003032'
      |    )
      |    AND to_date(ce.dischargetime) > to_date(ce.arrivaltime)
      |    AND ce.excl_fac = 'N'
      |    AND ce.altid_excl = 'N'
    """.stripMargin


  override def dependsOn: Set[String] = Set("TEMP_VISIT_ENCTR", "TEMP_EEG_PDX")
}
