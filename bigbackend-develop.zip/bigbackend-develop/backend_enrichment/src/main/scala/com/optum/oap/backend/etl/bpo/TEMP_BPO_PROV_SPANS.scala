package com.optum.oap.backend.etl.bpo

import com.optum.oap.cdr.models._
import com.optum.oap.sparkdataloader.{RuntimeVariables, TableInfo, UserDefinedFunctionForDataLoader}
import org.apache.spark.sql.{DataFrame, SparkSession}
import org.apache.spark.sql.functions._
import com.optum.oap.backend.cdrTempModel.{temp_bpo_prov_affil_spans, temp_bpo_prov_attr_spans, temp_bpo_prov_client_rel_spans, temp_bpo_prov_spans, temp_bpo_provider_detail}
import com.optum.oap.backend.loader.EnrichmentRunTimeVariables
import org.apache.spark.sql.expressions.Window
import org.apache.spark.sql.types._


object TEMP_BPO_PROV_SPANS extends TableInfo[temp_bpo_prov_spans]{
  override def name = "TEMP_BPO_PROV_SPANS"

  override def dependsOn: Set[String] = Set("PP_BPO_MEMBER_DETAIL", "TEMP_BPO_PROV_AFFIL_SPANS", "TEMP_BPO_PROV_ATTR_SPANS", "TEMP_BPO_PROV_CLIENT_REL_SPANS", "TEMP_BPO_PROVIDER_DETAIL")

  override def createDataFrame(sparkSession: SparkSession, loadedDependencies: Map[String, DataFrame], udfMap: Map[String, UserDefinedFunctionForDataLoader], runtimeVariables: RuntimeVariables): DataFrame = {

    import sparkSession.implicits._

    val ppBpoMemberDetail = loadedDependencies("PP_BPO_MEMBER_DETAIL").as[pp_bpo_member_detail]
    val tempBpoProvAffilSpans = loadedDependencies("TEMP_BPO_PROV_AFFIL_SPANS").as[temp_bpo_prov_affil_spans]
    val tempBpoProvAttrSpans = loadedDependencies("TEMP_BPO_PROV_ATTR_SPANS").as[temp_bpo_prov_attr_spans]
    val tempBpoProvClientRelSpans = loadedDependencies("TEMP_BPO_PROV_CLIENT_REL_SPANS").as[temp_bpo_prov_client_rel_spans]
    val tempBpoProviderDetail = loadedDependencies("TEMP_BPO_PROVIDER_DETAIL").as[temp_bpo_provider_detail]

    val grpid = EnrichmentRunTimeVariables(runtimeVariables).clientId

    val dflt_dates = ppBpoMemberDetail.
      where($"healthplansource" === lit("PAYER")).
      select(trunc(min($"effectivedate"), "MONTH").as("eff_date"),
        last_day(max($"enddate")).as("end_date"))

    val intermediateDf = tempBpoProvAffilSpans.select($"master_hgprovid", $"start_date", $"end_date")
        .union(tempBpoProvAttrSpans.select($"master_hgprovid", $"start_date", $"end_date"))
        .union(tempBpoProvClientRelSpans.select($"master_hgprovid", $"start_date", $"end_date"))
      .distinct()

    val maxDates = intermediateDf.
      groupBy($"master_hgprovid").
      agg(max($"start_date").as("start_date"),
        max($"end_date").as("end_date")).
      select(
      $"master_hgprovid",
      $"start_date",
      $"end_date"
    )

    val allDates = intermediateDf.select(
      $"master_hgprovid",
      $"start_date".as("date_value")
    ).distinct()

    val spanWindow = Window.partitionBy($"al.master_hgprovid").orderBy($"al.date_value".asc_nulls_last)

    val allSpans = allDates.as("al")
        .join(maxDates.as("md"), $"md.master_hgprovid" === $"al.master_hgprovid", "inner")
        .select($"al.master_hgprovid",
          $"al.date_value".as("start_date"),
          coalesce(add_months(last_day(lead($"al.date_value", 1).over(spanWindow)), -1), $"md.end_date").as("end_date"))
        .union(
          maxDates.as("md").crossJoin(dflt_dates.as("dd")).
            where($"md.end_date" < $"dd.end_date").
            select(
              $"md.master_hgprovid",
              date_add($"md.end_date", 1).as("start_date"),
              $"dd.end_date".as("end_date")
            )
        ).distinct()

    val tempBpoProvSpans = allSpans.as("sp")
        .join(tempBpoProvAffilSpans.as("pa1"), $"pa1.master_hgprovid" === $"sp.master_hgprovid" && $"pa1.start_date".between($"sp.start_date", $"sp.end_date"), "left")
        .join(tempBpoProvAffilSpans.as("pa2"), $"pa2.master_hgprovid" === $"sp.master_hgprovid" && $"sp.start_date" > $"pa2.start_date" && $"sp.end_date" <= $"pa2.end_date", "left")
        .join(tempBpoProvAttrSpans.as("pr1"), $"pr1.master_hgprovid" === $"sp.master_hgprovid" && $"pr1.start_date".between($"sp.start_date", $"sp.end_date"), "left")
        .join(tempBpoProvAttrSpans.as("pr2"), $"pr2.master_hgprovid" === $"sp.master_hgprovid" && $"sp.start_date" > $"pr2.start_date" && $"sp.end_date" <= $"pr2.end_date", "left")
        .join(tempBpoProvClientRelSpans.as("pc1"), $"pc1.master_hgprovid" === $"sp.master_hgprovid" && $"pc1.start_date".between($"sp.start_date", $"sp.end_date"), "left")
        .join(tempBpoProvClientRelSpans.as("pc2"), $"pc2.master_hgprovid" === $"sp.master_hgprovid" && $"sp.start_date" > $"pc2.start_date" && $"sp.end_date" <= $"pc2.end_date", "left")
        .select(
          lit(grpid).as("groupid"),
          $"sp.master_hgprovid".cast(StringType),
          $"sp.start_date".as("prov_effective_dt"),
          $"sp.end_date".as("prov_end_dt"),
          coalesce($"pa1.provaffiliationid", $"pa2.provaffiliationid").as("provaffiliationid"),
          coalesce($"pc1.provider_status", $"pc2.provider_status").as("provider_status"),
          coalesce($"pr1.cust_prov_attr1", $"pr2.cust_prov_attr1").as("cust_prov_attr1"),
          coalesce($"pr1.cust_prov_attr2", $"pr2.cust_prov_attr2").as("cust_prov_attr2"),
          coalesce($"pr1.cust_prov_attr3", $"pr2.cust_prov_attr3").as("cust_prov_attr3"),
          coalesce($"pr1.cust_prov_attr4", $"pr2.cust_prov_attr4").as("cust_prov_attr4"),
          coalesce($"pr1.cust_prov_attr5", $"pr2.cust_prov_attr5").as("cust_prov_attr5"),
          coalesce($"pr1.cust_prov_attr6", $"pr2.cust_prov_attr6").as("cust_prov_attr6"),
          coalesce($"pr1.cust_prov_attr7", $"pr2.cust_prov_attr7").as("cust_prov_attr7"),
          coalesce($"pr1.cust_prov_attr8", $"pr2.cust_prov_attr8").as("cust_prov_attr8"),
          coalesce($"pr1.cust_prov_attr9", $"pr2.cust_prov_attr9").as("cust_prov_attr9"),
          coalesce($"pr1.cust_prov_attr10", $"pr2.cust_prov_attr10").as("cust_prov_attr10"),
          coalesce($"pr1.cust_prov_attr11", $"pr2.cust_prov_attr11").as("cust_prov_attr11"),
          coalesce($"pr1.cust_prov_attr12", $"pr2.cust_prov_attr12").as("cust_prov_attr12"),
          coalesce($"pr1.cust_prov_attr13", $"pr2.cust_prov_attr13").as("cust_prov_attr13"),
          coalesce($"pr1.cust_prov_attr14", $"pr2.cust_prov_attr14").as("cust_prov_attr14"),
          coalesce($"pr1.cust_prov_attr15", $"pr2.cust_prov_attr15").as("cust_prov_attr15"),
          coalesce($"pr1.cust_prov_attr16", $"pr2.cust_prov_attr16").as("cust_prov_attr16"),
          coalesce($"pr1.cust_prov_attr17", $"pr2.cust_prov_attr17").as("cust_prov_attr17"),
          coalesce($"pr1.cust_prov_attr18", $"pr2.cust_prov_attr18").as("cust_prov_attr18"),
          coalesce($"pr1.cust_prov_attr19", $"pr2.cust_prov_attr19").as("cust_prov_attr19"),
          coalesce($"pr1.cust_prov_attr20", $"pr2.cust_prov_attr20").as("cust_prov_attr20"),
          coalesce($"pr1.prov_userdef_1", $"pr2.prov_userdef_1").as("prov_userdef_1"),
          coalesce($"pr1.prov_userdef_2", $"pr2.prov_userdef_2").as("prov_userdef_2")
        )

    val defaultRow = tempBpoProviderDetail.as("p")
      .crossJoin(dflt_dates.as("dd"))
      .join(allSpans.as("al"), $"al.master_hgprovid" === $"p.providerid","left")
      .where($"al.master_hgprovid".isNull)
      .select(
        $"p.groupid",
        $"p.providerid".as("master_hgprovid"),
        $"dd.eff_date".as("start_date"),
        $"dd.end_date",
        lit(null).as("prov_affil_id"),
        lit(null).as("prov_status_id"),
        lit(null).as("CUST_PROV_ATTR1"),
        lit(null).as("CUST_PROV_ATTR2"),
        lit(null).as("CUST_PROV_ATTR3"),
        lit(null).as("CUST_PROV_ATTR4"),
        lit(null).as("CUST_PROV_ATTR5"),
        lit(null).as("CUST_PROV_ATTR6"),
        lit(null).as("CUST_PROV_ATTR7"),
        lit(null).as("CUST_PROV_ATTR8"),
        lit(null).as("CUST_PROV_ATTR9"),
        lit(null).as("CUST_PROV_ATTR10"),
        lit(null).as("CUST_PROV_ATTR11"),
        lit(null).as("CUST_PROV_ATTR12"),
        lit(null).as("CUST_PROV_ATTR13"),
        lit(null).as("CUST_PROV_ATTR14"),
        lit(null).as("CUST_PROV_ATTR15"),
        lit(null).as("CUST_PROV_ATTR16"),
        lit(null).as("CUST_PROV_ATTR17"),
        lit(null).as("CUST_PROV_ATTR18"),
        lit(null).as("CUST_PROV_ATTR19"),
        lit(null).as("CUST_PROV_ATTR20"),
        lit(null).as("PROV_USERDEF_1"),
        lit(null).as("PROV_USERDEF_2")
      )

   tempBpoProvSpans.union(defaultRow)

  }
}
