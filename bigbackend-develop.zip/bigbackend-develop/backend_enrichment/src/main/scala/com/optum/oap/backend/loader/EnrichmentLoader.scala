package com.optum.oap.backend.loader

import com.optum.oap.backend.etl.common.EnrichmentUtils.EnrichmentConf
import com.optum.oap.backend.etl.common.{CDRConstants, EnrichmentUtils, OADefinedFunctionsRegistry, PartitionedDataOperations}
import com.optum.oap.sparkdataloader.{DataLoader, RuntimeVariables, TableInfo}
import com.optum.oap.sparklib.SparkUtils
import com.optum.oap.utils.CliUtils.getOptionalSeq
import org.apache.spark.sql.SparkSession
import org.slf4j.LoggerFactory
import com.optum.oap.backend.etl.common.CDRConstants
import com.optum.oap.backend.loader.loadgroup.LoadGroup

import java.util.concurrent.Executors
import scala.collection.JavaConversions._
import scala.concurrent.{ExecutionContext, ExecutionContextExecutorService}

object EnrichmentLoader extends PartitionedDataOperations {
  private val logger = LoggerFactory.getLogger(this.getClass)

  def main(args: Array[String]): Unit = {
    val conf = new EnrichmentConf(args)
    logger.warn(conf.toString)

    val executionThreads = conf.executorThreads()
    implicit val executionContext: ExecutionContextExecutorService = ExecutionContext.fromExecutorService(Executors.newFixedThreadPool(executionThreads))
    val targetTables = getOptionalSeq(conf.targetTables)

    val loader = DataLoaderFactory.getDataLoader(conf)
    val runtimeVariables = getRunTimeVariables(conf)
    val sparkSession: SparkSession = SparkUtils.createSparkSession("enrichment-loader", verboseLogging = false, logWarnings = true)
    val initialData = loader.initialDependencies(runtimeVariables, sparkSession)
    loadData(loader, sparkSession, initialData, runtimeVariables, targetTables, conf.getDependencyGraph(), conf.partitionMultiplier())

    try {
      // This should not cause the build to fail
      val buildMetrics = DataLoader.generateLogVisualization(loader.logs.keys().toList.sorted.toIterator)
      val logRunTimeVariables = getRunTimeVariables(conf, Option(buildMetrics))
      loadData(loader, sparkSession, initialData, logRunTimeVariables, Option(CDRConstants.metricTables), conf.getDependencyGraph(), conf.partitionMultiplier())
      logger.warn(buildMetrics)
    } catch {
      case ex: Exception =>
        logger.error(s"Unable to generate the DAG visualization.", ex)
    }
  }

  def loadData(dataLoader: DataLoader[_] with LoadGroup,
               session: SparkSession,
               initialData: Seq[TableInfo[_ <: Product with Serializable]],
               runtimeVariables: EnrichmentRunTimeVariables,
               targetTables: Option[Seq[String]] = None,
               printDependencyGraphOnly: Boolean = false,
               partitionMultiplier: Double = 1)(implicit ec: ExecutionContext): Seq[String] = {
    val udfs = OADefinedFunctionsRegistry.ALL_UDFS

    val queryRegistry = dataLoader.queryRegistry(runtimeVariables, session)
    val tables = (initialData ++ queryRegistry).distinct

    val finalTables = DataLoader.filterAllTablesByTarget(tables, targetTables.map(_.toSet).getOrElse(Set.empty))

    if (printDependencyGraphOnly) {
      printDependencyGraph(finalTables)

    } else {
      dataLoader.loadData(tables = finalTables, baseSparkSession = session, udfs = udfs.toSeq,
        runtimeVariables = runtimeVariables, partitionMultiplier = partitionMultiplier)
    }
    finalTables.map(_.fullName)
  }

  private def getRunTimeVariables(inputArgsConf: EnrichmentConf, logMetrics: Option[String] = None): EnrichmentRunTimeVariables = {

    EnrichmentRunTimeVariables(
      clientId = inputArgsConf.clientId(),
      environment = inputArgsConf.environment(),
      cdrSchema = inputArgsConf.cdrSchema(),
      cdrLevel = inputArgsConf.cdrLevel(),
      cdrCycle = inputArgsConf.cdrCycle(),
      instance = inputArgsConf.instance(),
      release = inputArgsConf.release(),
      buildType = inputArgsConf.buildType(),
      fullHiveDb = inputArgsConf.fullHiveDb.getOrElse(""),
      partitionMultiplier = inputArgsConf.partitionMultiplier(),
      clientBucket = inputArgsConf.clientBucket.toOption,
      buildMetrics = logMetrics,
      loadGroups = inputArgsConf.loadGroups(),
      mercuryStage = inputArgsConf.mercuryStage(),
      dailyEndDate = inputArgsConf.dailyEndDate.toOption
    )
  }

  private def printDependencyGraph(finalTables: Seq[TableInfo[_ <: Product with Serializable]]): Unit = {
    val dependencyGraph = DataLoader.generateDOTString(finalTables, includeNonRelevant = true)
    logger.warn(s"Dependency Graph => \n$dependencyGraph")
  }
}

case class EnrichmentRunTimeVariables(clientId: String,
                                      environment: String,
                                      cdrSchema: String,
                                      cdrLevel: String,
                                      cdrCycle: String,
                                      instance: String,
                                      release: String,
                                      buildType: String,
                                      fullHiveDb: String,
                                      partitionMultiplier: Double = 1,
                                      clientBucket: Option[String] = None,
                                      buildMetrics: Option[String] = None,
                                      loadGroups: String = "",
                                      mercuryStage: Boolean = false,
                                      dailyEndDate: Option[String] = None) extends RuntimeVariables {

  private val commonCdrbePath = if (clientBucket.isEmpty) {
    s"/optum/data_factory/${clientId.toUpperCase}"
  } else {
    s"s3://${clientBucket.get}"
  }

  private val commonMercuryPath = if (clientBucket.isEmpty) {
    val mercuryOrMercuryStage = if (mercuryStage) "mercury-stage" else "mercury"
    s"/optum/$mercuryOrMercuryStage"
  } else {
    s"s3://${clientBucket.get}/${environment.toLowerCase}"
  }

  val isInAWS: Boolean = clientBucket.isDefined
  val commonPath: String = s"$commonCdrbePath/${environment.toLowerCase}/cdr_be/common/default"
  val cdrFeBasePath: String = s"$commonCdrbePath/${environment.toLowerCase}/cdr_fe/$cdrCycle/$instance/default"
  val mercuryBasePath: String = s"$commonMercuryPath/data/CDR/frontend/$clientId"
  //Replace the CDR_DELTA_YYYYMM with CDR_YYYYMM for daily build maps.
  val mercuryMapsPath: String = s"$commonMercuryPath/provisional/data/maps/SDL/${cdrCycle.toUpperCase.replace("DELTA_", "")}"
}

object EnrichmentRunTimeVariables {
  def apply(runtimeVariables: RuntimeVariables) = runtimeVariables.asInstanceOf[EnrichmentRunTimeVariables]
}
