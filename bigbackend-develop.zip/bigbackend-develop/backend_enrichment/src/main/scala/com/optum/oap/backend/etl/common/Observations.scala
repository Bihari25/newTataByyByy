package com.optum.oap.backend.etl.common

import java.text.SimpleDateFormat
import java.time.temporal.ChronoUnit

import com.optum.oap.backend.etl.common.Functions.regexParse
import com.optum.oap.backend.etl.common.UnitConversionFunction.UnitConversionFunction
import com.optum.oap.cdr.models.{observation, patient, unit_conversion, zcm_client_ds_priority}
import org.apache.spark.sql._
import org.apache.spark.sql.expressions.Window
import org.apache.spark.sql.functions._
import org.apache.spark.sql.types.{DateType, TimestampType}
import org.joda.time.LocalDate
import org.joda.time.format.DateTimeFormat

import scala.math.BigDecimal
import scala.math.BigDecimal.RoundingMode


object Observations extends UnitConversion {
  private val rangeTypes: Set[String] = Set("CH001846", "CH001999", "PAIN")
  private val weekDayCuis: Set[String] = Set("CH002722", "CH002723", "CH002773")
  private val gestationalAgeCuis: Set[String] = Set("CH002752","CH002753","CH002754")

  /**
   * Method to convert the obsresult value coming in from the OBSERVATION table into a normalized value.
   *
   * Translated from legacy here: https://svn.humedica.net/svn/ops/cdr/trunk/sql/code/objects/functions/std_obsresult.sql
   */
  def deriveObsResult(incomingObsResult: Option[String],
                      obsType: String,
                      obsConvFactor: Option[java.lang.Double],
                      obsRegex: Option[String],
                      dataType: Option[String],
                      beginRange: Option[Int],
                      endRange: Option[Int],
                      roundPrec: Option[Int],
                      obsTypeStdUnit: Option[String],
                      inputValue: Option[String],
                      localUnitCui: Option[String],
                      convFactor: Option[java.lang.Double],
                      dateofbirth: Option[java.sql.Timestamp],
                      obsDate: Option[java.sql.Timestamp],
                      functionApplied: Option[String],
                      unitConversionData: Set[conversion_factors]): String = {
    val outgoingResult = incomingObsResult.getOrElse({
      if (inputValue.isEmpty) null else { // null values incoming are null values outgoing
        // trim down to maxlength
        val nonNullValue = inputValue.get
        val maxLength = scala.math.min(nonNullValue.length, 250)
        val trimmedValue = nonNullValue.substring(0, maxLength)
        // search for passed in string within larger value
        val regexFilteredValue: Option[String] = if (obsRegex.isEmpty) Some(trimmedValue)
          else regexParse(obsRegex.get, Some(trimmedValue))

        if (regexFilteredValue.isEmpty || dataType.isEmpty) null else dataType.get.toLowerCase match {
          case "n" | "f" => // numeric
            // The + or / sign should be remove only for simple units.
            // For combined units for example Gestational Age comes in the format 30 + 3 weekes or 30 3/7 weeks
            // In those cases we want to keep the + and / sign and use them for parsing the weeks and days string
            val cleanedValue = if (localUnitCui.getOrElse("1") != "CH002773") {
              // the + sign should be removed from the local result only if the datatype is 'N' -numeric.
              // For CV or controlled Vocabulary the + should remain.
              // There are some BP values that come with a / and the / have to be replaced.
              regexFilteredValue.get.replaceAll("[/+]", "")
            } else regexFilteredValue.get
            val cleanedValueOptionDouble: Option[java.lang.Double] = scala.util.Try[java.lang.Double](cleanedValue.toDouble).toOption

            // range detection
            val hyphenIndex = cleanedValue.indexOf("-")
            // if range detected AND obsType contains ranged value type...
            val rangedValue: Option[java.lang.Double] = if (hyphenIndex != -1 && rangeTypes.contains(obsType)) {
              // parse the low range
              val lowRangeStringUntruncated = cleanedValue.substring(0, hyphenIndex)
              val lowRangeString = lowRangeStringUntruncated.substring(0, scala.math.min(lowRangeStringUntruncated.length, 8))
              val lowRangeOptionDouble = scala.util.Try[java.lang.Double](lowRangeString.toDouble).toOption

              // parsing numeric value of hi range
              val hiRangeStringPreValidationUntruncated = cleanedValue.substring(hyphenIndex + 1)
              val hiRangeStringPreValidation = hiRangeStringPreValidationUntruncated.substring(0, scala.math.min(hiRangeStringPreValidationUntruncated.length, 8))
              val hiRangeStringPreValidationOptionDouble =
                scala.util.Try[java.lang.Double](hiRangeStringPreValidation.toDouble).toOption
              val hiRangeString = if (hiRangeStringPreValidationOptionDouble.nonEmpty &&
                lowRangeOptionDouble.nonEmpty &&
                hiRangeStringPreValidationOptionDouble.get < lowRangeOptionDouble.get) {
                val parseAttempt = lowRangeString.substring(0, lowRangeString.length - hiRangeStringPreValidation.length) + hiRangeStringPreValidation
                if (parseAttempt.isEmpty) hiRangeStringPreValidation else parseAttempt
              } else hiRangeStringPreValidation
              val hiRangeOptionDouble = scala.util.Try[java.lang.Double](hiRangeString.toDouble).toOption

              // coalesce results from hi to low to original value; convert back to Option
              Option(
                hiRangeOptionDouble.getOrElse(
                  lowRangeOptionDouble.getOrElse(
                    cleanedValueOptionDouble.orNull
                  )
                )
              )
            } else cleanedValueOptionDouble // no range was detected, return the cleanedValue

            // If the cui for local unit and cui for obstype standard units do not match, then
            // get the conversion information from unit conversion table.
            val convertedValue: Option[java.lang.Double] = if (localUnitCui.isEmpty || obsTypeStdUnit.isEmpty) rangedValue else {
              // mixed unit CUIs process mixed units way
              if (weekDayCuis.contains(localUnitCui.get)) {
                convertMultipleUnits(obsType, cleanedValue, localUnitCui.get, obsTypeStdUnit.get, unitConversionData)
              } else { // process the normal way
                if (obsTypeStdUnit.getOrElse("0") != localUnitCui.getOrElse("0") && rangedValue.nonEmpty) {
                  // Get the conversion factor -- we dont want a 0 or null for the conversion factor, so default to 1
                  val conversionFactor: java.lang.Double = convFactor.getOrElse(obsConvFactor.getOrElse(1.0))
                  // Multiply local result by conversion factor
                  val convertedValue = rangedValue.get * conversionFactor
                  // Pass the multiplied result to applyUnitConversionFunction with the function applied value.
                  val conversionType: UnitConversionFunction = UnitConversionFunction.values.find(
                    _.toString.toLowerCase == functionApplied.getOrElse(UnitConversionFunction.LINEAR.toString).toLowerCase
                  ).getOrElse(UnitConversionFunction.LINEAR)
                  Some(applyUnitConversionFunction(convertedValue, conversionType))
                } else rangedValue //  no conversion needed
              }
            }

            val rangeLimitedValue: Option[java.lang.Double] = {
              val deOptionedValue = convertedValue.orNull

              if (convertedValue.isEmpty) None
              else if (obsType == "WT" &&
                (beginRange.getOrElse(1) > deOptionedValue || endRange.getOrElse(300) < deOptionedValue)) None
              else if (obsType == "HT" &&
                (beginRange.getOrElse(3) > deOptionedValue || endRange.getOrElse(300) < deOptionedValue)) None
              else if (obsType == "DYSPNEA_SCALE" && beginRange.isDefined && deOptionedValue < beginRange.get) None
              else if (obsType == "DYSPNEA_SCALE" && endRange.isDefined && deOptionedValue > endRange.get) None
              else if (beginRange.isDefined && endRange.isDefined && (deOptionedValue > endRange.get || deOptionedValue < beginRange.get)) None
              else convertedValue
            }

            // rounding
            val roundedValue = rangeLimitedValue.map(x => {
              val decimalValue = BigDecimal(x)
              val roundAttempt = decimalValue.setScale(roundPrec.getOrElse(2), RoundingMode.HALF_UP)
              roundAttempt.toDouble
            })

            roundedValue.map(_.toString).orNull
          case "p" => // percentages
            val lowRange = regexFilteredValue.get.split("-").head // for LVEF handle values with a range, eg 50-60
            val adjustedValue = if (obsType.toUpperCase == "LVEF") lowRange else regexFilteredValue.get
            val noPercentSign = if (adjustedValue.substring(adjustedValue.length() - 1) == "%") adjustedValue.substring(0,adjustedValue.length() - 1) else adjustedValue
            val test = scala.util.Try[java.lang.Double](noPercentSign.toDouble).toOption
              .map(scala.math.abs(_))
              .map(value => if (value <= 1.0) value * 100.0 else value)

            if (test.isDefined && beginRange.isDefined && endRange.isDefined && (test.get > endRange.get || test.get < beginRange.get)) null
            else test.map(_.toString).getOrElse(regexFilteredValue.get)
          case "d" => // dates
            val filteredValue = regexFilteredValue.get
            val fxmdySlashes = safeToDate(filteredValue, "M/d/yy")
            val ymd = safeToDate(filteredValue, "yyyyMd")
            val fxmdyDashes = safeToDate(filteredValue, "M-d-yy")
            val mdy = safeToDate(filteredValue, "yy-M-d H:m:s")

            val priorityDateOption = Option(fxmdySlashes.map(_.toString).getOrElse(
              ymd.map(_.toString).getOrElse(
                fxmdyDashes.map(_.toString).getOrElse(
                  mdy.map(_.toString).orNull))))

            val outcome = priorityDateOption.map(date => {
              val format = new SimpleDateFormat("dd-MMM-yy")
              val parsedTimestamp = java.sql.Timestamp.valueOf(date)
              format.format(parsedTimestamp).toUpperCase
            }).orNull

            outcome
          case _ => regexFilteredValue.get
        }
      }
    })

    // validate ht/wt records
    if (obsType == "WT") validateWeight(Option(outgoingResult), dateofbirth, obsDate).orNull
    else if (obsType == "HT") validateHeight(Option(outgoingResult), dateofbirth, obsDate).orNull
    else outgoingResult
  }

  /**
   * Filters out unliklely weight records based on a patient's age
   *
   * Translated from legacy here: https://svn.humedica.net/svn/ops/cdr/trunk/sql/etl/apply_ht_wt_validations.sql
   * @param obsResult
   * @param dob
   * @param obsDate
   * @return
   */
  private def validateWeight(obsResult: Option[String], dob: Option[java.sql.Timestamp], obsDate: Option[java.sql.Timestamp]): Option[String] = {
    if (obsResult.isDefined) {
      val parsedDouble = scala.util.Try[java.lang.Double](obsResult.get.toDouble).toOption
      if (parsedDouble.isEmpty || dob.isEmpty || obsDate.isEmpty) None // unable to validate, null it out
      else {
        val age = calculateAgeAtDate(dob.get, obsDate.get)
        val obsValue = parsedDouble.get
        if (age <= 3 && obsValue > 0.5) parsedDouble.map(_.toString)
        else if (age > 3 && age <= 20 && obsValue >= 5) parsedDouble.map(_.toString)
        else if (age > 20 && obsValue > 20 && obsValue < 500 ) parsedDouble.map(_.toString)
        else None
      }
    } else obsResult
  }

  /**
   * Filters out unlikley height records based on a patient's age
   *
   * Translated from legacy here: https://svn.humedica.net/svn/ops/cdr/trunk/sql/etl/apply_ht_wt_validations.sql
   * @param obsResult
   * @param dob
   * @param obsDate
   * @return
   */
  private def validateHeight(obsResult: Option[String], dob: Option[java.sql.Timestamp], obsDate: Option[java.sql.Timestamp]): Option[String] = {
    if (obsResult.isDefined) {
      val parsedDouble = scala.util.Try[java.lang.Double](obsResult.get.toDouble).toOption
      if (parsedDouble.isEmpty || dob.isEmpty || obsDate.isEmpty) None // unable to validate, null it out
      else {
        val age = calculateAgeAtDate(dob.get, obsDate.get)
        val obsValue = parsedDouble.get
        if (age < 1 && obsValue > 20.0) obsResult
        else if (age >= 1 && age < 3 && obsValue > 45.0) parsedDouble.map(_.toString)
        else if (age >= 3 && age < 20 && obsValue > 70) parsedDouble.map(_.toString)
        else if (age >= 20 && obsValue > 90 && obsValue < 300) parsedDouble.map(_.toString)
        else None
      }
    } else obsResult
  }


  /**
   * Given a date of birth and a referenceDate, calculate the AGE IN YEARS at the referenceDate
   *
   * @param dob
   * @param referenceDate
   * @return number of years double
   */
  private def calculateAgeAtDate(dob: java.sql.Timestamp, referenceDate: java.sql.Timestamp): Double = {
    val dobLocalDate = dob.toLocalDateTime.toLocalDate
    val refLocalDate = referenceDate.toLocalDateTime.toLocalDate
    val days = dobLocalDate.until(refLocalDate, ChronoUnit.DAYS)
    BigDecimal(days / 365.0).setScale(1, BigDecimal.RoundingMode.HALF_UP).toDouble
  }

  /**
   * parses a Timestamp of a given format... or not.
   */
  def safeToDate(input: String, format: String): Option[java.sql.Timestamp] = {
    val pattern = DateTimeFormat.forPattern(format)
    val jodaDate: Option[LocalDate] = scala.util.Try(LocalDate.parse(input, pattern)).toOption
    if (jodaDate.isDefined)
      scala.util.Try(java.sql.Timestamp.valueOf(jodaDate.get.toString + " 00:00:00")).toOption
    else None
  }

  /**
   * For numeric rows, this method converts different types of numeric values depending
   * on the observation type and localunit cuis.
   *
   * Ported from legacy here:
   * https://svn.humedica.net/svn/ops/cdr/trunk/sql/code/objects/functions/convert_multiple_units.sql
   */
  def convertMultipleUnits(p_OBSTYPE: String, p_localresult: String, p_local_unit_cui: String, p_std_unit_cui: String, unitConversionData: Set[conversion_factors]): Option[java.lang.Double] = {
      val v_localresult = p_localresult.substring(0, scala.math.min(99, p_localresult.length)).toUpperCase

      if (p_OBSTYPE == "HT" && p_local_unit_cui == "CH002722") {
        // the local result is converted to upper case. So we have to look for 'F' in it.
        val v_ht_ft = regexParse("^[^F''f]*", Some(v_localresult)).getOrElse("0")
        // There are cases when the feet component of the height would be missing and
        // it would just be inches (like an infant's height).
        // IN such a case, set it to zero
        val conversionFactorCH001212 = unitConversionData.find(ucf => ucf.src_unit == "CH001212" && ucf.dest_unit == p_std_unit_cui).map(_.conv_fact).get // NOTE: this will fatal if there's no row for it in the unit conversion data
        val ht_ft: Option[java.lang.Double] = if (v_ht_ft == v_localresult) Some(0.0) else scala.util.Try[java.lang.Double](v_ht_ft.toDouble).toOption
        val ht_ft_cm = if (v_ht_ft == v_localresult) Some(0.0) else ht_ft.map(_ * conversionFactorCH001212).map(roundDouble(_, precision = 5))
        val v_ht_inPreCheck = regexParse("[^Tt]*$", // Get the part of the string enclosed between 2 blank spaces and get its third occurance,
           regexParse("^[^I\"'i]*", Some(v_localresult)) // This will get the part before the in.
        ).getOrElse(v_localresult).trim
        val v_ht_in = if (v_ht_inPreCheck != v_localresult) {
          v_ht_inPreCheck.substring(0, scala.math.min(v_ht_inPreCheck.length, 2))
        } else v_ht_inPreCheck

        val conversionFactorCH000136 = unitConversionData.find(ucf => ucf.src_unit == "CH000136" && ucf.dest_unit == p_std_unit_cui).map(_.conv_fact).get // NOTE: this will fatal if there's no row for it in the unit conversion data
        val ht_in = scala.util.Try[java.lang.Double](v_ht_in.toDouble).toOption
        val ht_in_cm = ht_in.map(_ * conversionFactorCH000136).map(roundDouble(_, precision = 5))

        if (ht_ft_cm.isEmpty && ht_in_cm.isEmpty) None else Some(ht_ft_cm.getOrElse(0.0) + ht_in_cm.getOrElse(0.0))
      } else if (p_OBSTYPE == "WT" && p_local_unit_cui == "CH002723") {
        // the local result is converted to upper case. So we have to look for 'L'
        // or different ways in which pounds may be represented
        // like Lbs, lbs, lb, #, pound
        // Some Groups represent the weight as 7lbs. 8oz.
        // the dot at the end of lbs. should come out.
        val filteredWtLbs = regexParse("^[^L''l#Pp]*", Some(v_localresult.replaceAll("[_,]","").replace("LBS.", "LBS"))
        ).getOrElse(v_localresult)
        val v_wt_lbs = scala.util.Try[java.lang.Double](filteredWtLbs.toDouble).toOption
        val conversionFactorCH000143 = unitConversionData.find(ucf => ucf.src_unit == "CH000143" && ucf.dest_unit == p_std_unit_cui).map(_.conv_fact).get // NOTE: this will fatal if there's no row for it in the unit conversion data
        val wt_lbs_kg = v_wt_lbs.map(value => roundDouble(value * conversionFactorCH000143,5)).getOrElse(0.0)
        // Some times pounds are represented as Lbs, lbs, lb, # pound and regex should cover all these cases
        val partBeforeOz = regexParse("^[^O\"''''o]*", Some(v_localresult)).getOrElse(v_localresult)
        val secondNumber = regexParse("[^Ss#bBdD]*$", Some(partBeforeOz)).getOrElse(partBeforeOz).trim
        val finalOz = if (secondNumber != v_localresult) secondNumber.substring(0,scala.math.min(secondNumber.length, 2)) else secondNumber
        val v_wt_oz = scala.util.Try[java.lang.Double](finalOz.toDouble).toOption
        val conversionFactorCH000215 = unitConversionData.find(ucf => ucf.src_unit == "CH000215" && ucf.dest_unit == p_std_unit_cui).map(_.conv_fact).get // NOTE: this will fatal if there's no row for it in the unit conversion data
        val wt_oz_kg = v_wt_oz.map(value => roundDouble(value * conversionFactorCH000215, precision = 5)).getOrElse(0.0)

        Some(wt_lbs_kg + wt_oz_kg)
      } else if (gestationalAgeCuis.contains(p_OBSTYPE) && p_local_unit_cui == "CH002773") {
        // First remove the space and the 'S' from the string
        // the GA value can be represented as '39 Weeks 3 Days'
        // if S is present in the string we will not know if that 'S' is in weeks or days
        val cleanedValue = v_localresult.replaceAll("[ S]", "")
        val ga_week = regexParse("^[^'W]*", Some(cleanedValue)).getOrElse(cleanedValue)

        // If the input string contains a /  contains 7 after the slash then the string could be of the form
        // 20 6/7 weeks  days...
        val hasSlashAndSeven: Boolean = ga_week.contains("/") && regexParse("[^/]*$", Some(ga_week)).getOrElse(ga_week).contains("7")
        val days_var = if (hasSlashAndSeven) ga_week.substring(3,4) else "0.0"
        val week_var = if (hasSlashAndSeven) ga_week.substring(1,2) else ga_week

        // The value could be of the form 37+2weeks.
        val hasPlus: Boolean = ga_week.contains("+")
        val plusIndex: Int = ga_week.indexOf("+")
        val ga_days_varSplChrFormat = if (hasPlus) ga_week.substring(plusIndex+1, scala.math.min(ga_week.length, plusIndex+2)).trim else days_var
        val ga_week_var = if (hasPlus) ga_week.substring(0, plusIndex).trim else week_var
        // convert the week part of the GA to KG if its a parse-able double
        val ga_week_num: java.lang.Double = scala.util.Try[java.lang.Double](ga_week_var.toDouble).toOption.getOrElse(0.0)

        // (hasSlashAndSeven || hasPlus) is equivalent to `if ga_spl_chr_format = false then...`
        val ga_days_varDWFormat = if (hasSlashAndSeven || hasPlus) ga_days_varSplChrFormat else {
          // get the part before the D (days).
          // Get the part after W (weeks)
          val day_portion = regexParse("^[^D']*", Some(cleanedValue))
          regexParse("[^WK]*$", day_portion).getOrElse(cleanedValue).trim
        }

        // If there is no days part in the local result, its considered as weeks
        val ga_days_var = if (ga_days_varDWFormat == cleanedValue) "0.0" else ga_days_varDWFormat

        val ga_days_varOptionDouble = scala.util.Try[java.lang.Double](ga_days_var.toDouble).toOption
        val ga_days_num_week = if (ga_days_varOptionDouble.isDefined && ga_days_var != "0.0") {
          val conversionFactorCH000127 = unitConversionData.find(ucf => ucf.src_unit == "CH000127" && ucf.dest_unit == p_std_unit_cui).map(_.conv_fact).get // NOTE: this will fatal if there's no row for it in the unit conversion data
          ga_days_varOptionDouble.map(value => roundDouble(value * conversionFactorCH000127, precision = 5)).get
        } else 0.0

        Some(ga_week_num + ga_days_num_week)
    } else None
  }

  /**
   * This is the set of UNIT_CONVERSION.SRC_UNIT CUIs that are used in the convertMultipleUnits method later
   * in this object.
   *
   * From an ETL that needs an ObsResult calculation, use queryUnitConversionData method below to query all required
   * conversion factors from UNIT_CONVERSION table
   */
  private val unitConversionSrcUnitCUIs: Seq[String] = Seq("CH001212", "CH000136", "CH000143", "CH000215", "CH000127")
  def queryUnitConversionData(sparkSession: SparkSession, unitConversionDf: Dataset[unit_conversion]): Set[conversion_factors] = {
    import sparkSession.implicits._
    unitConversionDf
      .where($"src_unit".isin(unitConversionSrcUnitCUIs: _*))
      .select($"src_unit", $"dest_unit", $"conv_fact").as[conversion_factors].collect.toSet
  }

  /**
   * A method that, given a row of observations from cdr_fe,
   * normalizes the obsresult value in the case the source doesn't present one.
   */
  def normalizeObsResultByRow(row: Row, unitConversionData: Set[conversion_factors], roundPrecNum: java.lang.Integer): observation = {
    val obsType = row.getAs[String]("obstype")
    val localResult = row.getAs[String]("localresult")
    val obsDate = Option(row.getAs[java.sql.Timestamp]("obsdate"))

    observation(
      facilityid = row.getAs[String]("facilityid"),
      local_obs_unit = row.getAs[String]("local_obs_unit"),
      localresult = localResult,
      obsdate = obsDate.orNull,
      obstype = row.getAs[String]("obstype"),
      resultdate = row.getAs[java.sql.Timestamp]("resultdate"),
      statuscode = row.getAs[String]("statuscode"),
      std_obs_unit = row.getAs[String]("std_obs_unit"),
      client_ds_id = row.getAs[Integer]("client_ds_id"),
      datasrc = row.getAs[String]("datasrc"),
      encounterid = row.getAs[String]("encounterid"),
      groupid = row.getAs[String]("groupid"),
      grp_mpi = row.getAs[String]("grp_mpi"),
      hgpid = row.getAs[java.lang.Long]("hgpid"),
      localcode = row.getAs[String]("localcode"),
      patientid = row.getAs[String]("patientid"),
      local_obs_desc = row.getAs[String]("local_obs_desc"),
      local_obs_type_cd = row.getAs[String]("local_obs_type_cd"),
      obsresult = if (row.getAs[String]("zcm_obstype") == null)
      {
        row.getAs[String]("obsresult")
      } else {
        Observations.deriveObsResult(
          incomingObsResult = Option(row.getAs[String]("obsresult")),
          obsType = obsType,
          obsConvFactor = Option(row.getAs[java.lang.Double]("zcm_obsconvfactor")),
          obsRegex = Option(row.getAs[String]("zcm_obsregex")),
          dataType = Option(row.getAs[String]("zcm_datatype")),
          beginRange = Option(row.getAs[Int]("zcm_begin_range")),
          endRange = Option(row.getAs[Int]("zcm_end_range")),
          roundPrec = Option(row.getAs[Int]("zcm_round_prec")),
          obsTypeStdUnit = Option(row.getAs[String]("zcm_obstype_std_units")),
          inputValue = Option(localResult),
          localUnitCui = Option(row.getAs[String]("zcm_localunit_cui")),
          convFactor = Option(row.getAs[java.lang.Double]("zcm_conv_fact")),
          dateofbirth = Option(row.getAs[java.sql.Timestamp]("dateofbirth")),
          obsDate = obsDate,
          functionApplied = Option(row.getAs[String]("zcm_function_applied")),
          unitConversionData = unitConversionData
        )
      }
    )
  }

  /**
   * When capturing observations for calculations, this selection of columns is used to get calculation information
   * per observation row
   *
   * @param sparkSession
   * @return
   */
  def getZcmJoinedObservationsColSelect(sparkSession: SparkSession): Seq[Column] = {
    import sparkSession.implicits._
    val zColNames = Seq("begin_range", "conv_fact", "cui", "datasrc", "datatype", "end_range", "function_applied", "localunit",
      "localunit_cui", "obscode", "obsconvfactor", "obsregex", "obstype", "obstype_std_units", "obstype_std_units_desc", "round_prec")
    zColNames.map(colName => $"z.$colName".as(s"zcm_$colName")) :+ $"o.*" :+ $"dateofbirth"
  }

  /**
   * generates the additional BMI observation rows from normalized observation data
   *
   * Translated from legacy SQL here: https://svn.humedica.net/svn/ops/cdr/trunk/sql/etl/calculate_bmi.sql
   */
  def deriveBmiRows(sparkSession: SparkSession, masteredObservations: DataFrame, roundPrecNum: Int): Dataset[observation] = {
    import sparkSession.implicits._

    val patientObsDateWindow = Window.partitionBy($"grp_mpi").orderBy($"obsdate".desc, $"obstype".desc, $"obsresult".desc).rangeBetween(Window.currentRow, Window.unboundedFollowing)

    val innerBmiQuery = masteredObservations
      .where($"obstype".isin("WT", "HT") && $"grp_mpi".isNotNull)
      .select($"groupid", $"encounterid", $"obsdate", $"obstype",$"datasrc", $"obsresult", $"patientid", $"grp_mpi", $"client_ds_id", $"hgpid",
        first(when($"obstype" === lit("HT") && $"datasrc" != lit("foam"), $"obsresult" / 100).otherwise(null), ignoreNulls=true).over(patientObsDateWindow).as("ht_val"),
        first(when($"obstype" === lit("HT") && $"datasrc" != lit("foam"), $"obsdate").otherwise(null), ignoreNulls=true).over(patientObsDateWindow).as("ht_dt"),
        first(when($"obstype" === lit("HT") && $"datasrc" == lit("foam"), $"obsresult" / 100).otherwise(null), ignoreNulls=true).over(patientObsDateWindow).as("foam_ht_val"),
        first(when($"obstype" === lit("HT") && $"datasrc" == lit("foam"), $"obsdate").otherwise(null), ignoreNulls=true).over(patientObsDateWindow).as("foam_ht_dt"),
        $"local_method_cd",
        $"local_method_desc",
        $"local_obs_desc",
        $"local_obs_type_cd"
      )

    val outerBmiQuery = innerBmiQuery
      .where($"obstype" === lit("WT") &&
        $"obsresult".isNotNull &&
        when($"foam_ht_dt".gt($"ht_dt") && $"datasrc" === lit("foam"), $"foam_ht_val")
          .otherwise(coalesce($"ht_val", $"foam_ht_val")) != lit(0)
      )
      .select(
        $"groupid", $"encounterid", $"patientid", $"grp_mpi", $"datasrc", $"obsdate", $"obsresult", $"client_ds_id",
        $"foam_ht_dt", $"ht_dt", $"hgpid",
        $"local_method_cd",
        $"local_method_desc",
        $"local_obs_desc",
        $"local_obs_type_cd",
        when($"foam_ht_dt".gt($"ht_dt") && $"datasrc" === lit("foam"),$"foam_ht_val")
          .otherwise(coalesce($"ht_val",$"foam_ht_val")).as("ht_val")
      )

     outerBmiQuery.select(
      $"groupid", lit("IMPUTED").as("datasrc"), $"encounterid",
      $"patientid", $"grp_mpi", $"obsdate", $"client_ds_id", $"hgpid",
      // pad the record with nulls for other columns
      lit(null).as("facilityid"),
      lit(null).as("local_obs_unit"),
      lit(null).as("localcode"),
      lit(null).as("resultdate"),
      lit(null).as("statuscode"),
      lit(null).as("std_obs_unit"),
      $"local_method_cd",
      $"local_method_desc",
      $"local_obs_desc",
      $"local_obs_type_cd",
      when($"datasrc" === "foam", "CH001979")
        .when($"ht_dt".isNull, "CH001979")
        .otherwise("BMI")
        .as("obstype"),
      round($"obsresult" / pow($"ht_val", lit(2)), roundPrecNum).as("obsresult"),
      regexp_replace(concat($"obsresult", lit("/("), round($"ht_val", 4), lit("^2)")),  "\\/\\(0\\.", "/(.").as("localresult")
    ).distinct.where($"obsresult".isNotNull).as[observation]
  }

  /**
   * This method generates a series of dates of birth for every known patient.
   * In legacy Oracle pipeline, the data from the SUMMARY tables was used instead for potients' DOB
   *
   * @param sparkSession
   * @param patientIn
   * @param zcmClientDsPriority
   * @return
   */
  def getPatientDobs(sparkSession: SparkSession, patientIn: Dataset[patient], zcmClientDsPriority: Dataset[zcm_client_ds_priority]): DataFrame = {
    import sparkSession.implicits._

    val normalizedDobPatients = patientIn
      .select(
        $"dateofbirth".cast(DateType).cast(TimestampType).as("dateofbirth"),
        $"grp_mpi", $"client_ds_id", $"hgpid"
      )

    val zcmClientDsPriorityDf = zcmClientDsPriority
      .select($"client_ds_id", $"priority".as("client_ds_id_priority"))

    val dobFrequencyByMpi = normalizedDobPatients
      .groupBy($"grp_mpi", $"dateofbirth".as("dateofbirth"))
      .agg(
        count($"dateofbirth").as("dob_frequency")
      )

    normalizedDobPatients
      .join(broadcast(zcmClientDsPriorityDf), Seq("client_ds_id"), "left") // priority might not be defined per ds
      .join(dobFrequencyByMpi, Seq("grp_mpi", "dateofbirth"))
      .select(
        $"hgpid",
        $"grp_mpi",
        $"dateofbirth",
        $"dob_frequency",
        $"client_ds_id_priority",
        row_number().over(Window.partitionBy(
          $"grp_mpi"
        ).orderBy(
          when(
            (months_between(current_date(), $"dateofbirth") / 12) > -1 &&
              (months_between(current_date(), $"dateofbirth") / 12) < 135, lit(0)
          ).otherwise(lit(1)).asc_nulls_last,
          $"dob_frequency".desc,
          $"client_ds_id_priority".asc_nulls_last,
          $"hgpid".asc
        )).as("dob_priority")
      ).where($"dob_priority" === lit(1))
      .select($"grp_mpi", $"dateofbirth")
  }
}

/**
 * Case class used to collect conversion data facts from unit_conversion database.
 * Use this to create a dataset from UNIT_CONVERSION table and feed a set of them into the derive method below.
 *
 * @param src_unit - CUI
 * @param dest_unit - CUI
 * @param conv_fact - multiplication factor to apply to the value associated with the cuis
 */
case class conversion_factors(src_unit: String, dest_unit: String, conv_fact: Double)
