package com.optum.oap.backend.etl.encgrps
import com.optum.oap.backend.cdrTempModel.{temp_enc_grp_pyr, temp_enc_ins}
import com.optum.oap.sparkdataloader.{RuntimeVariables, TableInfo, UserDefinedFunctionForDataLoader}
import org.apache.spark.sql.expressions.Window
import org.apache.spark.sql.{DataFrame, SparkSession}
import org.apache.spark.sql.functions.{row_number, when}

object TEMP_ENC_GRP_PYR extends TableInfo[temp_enc_grp_pyr] {
  override def dependsOn: Set[String] = Set("TEMP_ENC_INS")

  override def name = "TEMP_ENC_GRP_PYR"

  override def createDataFrame(sparkSession: SparkSession, loadedDependencies: Map[String, DataFrame], udfMap: Map[String, UserDefinedFunctionForDataLoader], runtimeVariables: RuntimeVariables): DataFrame = {
    import sparkSession.implicits._

    val encInsDF = loadedDependencies("TEMP_ENC_INS").as[temp_enc_ins]

    val insorder = encInsDF.select(
      $"groupid",
      $"grp_mpi",
      $"ENCOUNTER_GRP_NUM",
      $"finclass",
      $"plancode",
      $"planname",
      $"payorcode",
      $"payorname",
      row_number()
        .over(Window.partitionBy($"groupid", $"grp_mpi", $"encounter_grp_num")
          .orderBy($"groupid", $"grp_mpi", $"encounter_grp_num",
            when($"finclass" === "CH999999", 4)
              .when($"finclass" === "CH000103", 3)
              .when($"finclass" === "CH000102", 2)
              .otherwise(1),
            $"insuranceorder".asc_nulls_last,
            when($"finclass" === "CH000101", 2)
              .otherwise(1),
            when($"encounteridtype" === "MASTER" || $"encounteridtype" === "ENCTR", 1)
              .otherwise(2),
            $"ins_timestamp".desc,
            when($"groupid" === "H101623" && $"datasrc".like("hl7%"), $"sourceid")
              .otherwise("0000").desc,
            $"encounterid".asc_nulls_last,
            $"client_ds_id",
            $"plancode".desc_nulls_last
          )
        ).as("insorder")
    )

    val df = insorder.select("*").where($"insorder" === 1)

    df
  }
}
