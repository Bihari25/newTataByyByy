package com.optum.oap.backend.etl.bpo

import java.sql.Timestamp

import com.optum.oap.backend.etl.common.CDRConstants
import com.optum.oap.cdr.models.{claim, claim_member_months, rxorder, zo_bpo_map_employer}
import com.optum.oap.sparkdataloader.{RuntimeVariables, TableInfo, UserDefinedFunctionForDataLoader}
import org.apache.spark.sql.functions.{lit, _}
import org.apache.spark.sql.types.{IntegerType, TimestampType}
import org.apache.spark.sql.{DataFrame, SparkSession}
import org.joda.time.DateTime
import org.slf4j.LoggerFactory

/**
  *
  * Copyright 2019 Optum Analytics
  *
  * Date: 5/13/19
  *
  * Creator: pavula1
  */
object CLAIM_MEMBER_MONTHS extends TableInfo[claim_member_months] {
  val log = LoggerFactory.getLogger(this.getClass)

  override def dependsOn = Set("CLAIM", "ZO_BPO_MAP_EMPLOYER", "RXORDER")

  override def name = "CLAIM_MEMBER_MONTHS"

  override def saveDataFrameToParquet: Boolean = true

  override def partitions: Int = 32

  override def skipTable: Boolean = false

  override def ignoreExtraColumnsInDataFrame: Boolean = false

  override def createDataFrame(sparkSession: SparkSession,
                               loadedDependencies: Map[String, DataFrame],
                               udfMap: Map[String, UserDefinedFunctionForDataLoader],
                               runtimeVariables: RuntimeVariables): DataFrame = {

    import sparkSession.implicits._

    val claimIn = loadedDependencies("CLAIM").as[claim]

    val zo_bpo_map_employerIn = broadcast(loadedDependencies("ZO_BPO_MAP_EMPLOYER")).as[zo_bpo_map_employer]

    val rxorderIn = loadedDependencies("RXORDER").as[rxorder]

    val clm_df = claimIn.alias("c").filter($"c.grp_mpi".isNotNull)
      .join(zo_bpo_map_employerIn.alias("z"), $"c.groupid" === $"z.groupid" && $"c.client_ds_id" === $"z.client_ds_id", "inner")
      .select(
        $"c.groupId", $"c.grp_mpi", $"c.client_ds_id", $"employeraccountid", $"c.paidamount",$"mappedcpt", $"mappedhcpcs",
        year(coalesce($"c.servicedate", lit("1900-01-01"))).as("claims_year"),
        month(coalesce($"c.servicedate", lit("1900-01-01"))).as("claims_month")
      )
      .groupBy("c.groupId", "c.grp_mpi", "c.client_ds_id", "employeraccountid", "claims_year", "claims_month")
      .agg(count(lit(1)).cast(IntegerType) alias ("claim_count"),
        sum(coalesce($"c.paidamount", lit(0))).as("claim_paid_amount"),
        count(when(length(coalesce($"c.mappedcpt", $"c.mappedhcpcs")) === 5 && coalesce($"c.mappedcpt", $"c.mappedhcpcs").like("D%") , true)).as("dental_count")).alias("clm")

    val rx_df = rxorderIn.alias("r").filter($"r.grp_mpi".isNotNull)
      .join(zo_bpo_map_employerIn.alias("z"), $"r.groupid" === $"z.groupid" && $"r.client_ds_id" === $"z.client_ds_id", "inner")
      .select($"r.groupId", $"r.grp_mpi", $"r.client_ds_id", $"employeraccountid", $"r.paidamount",
        year(coalesce($"r.issuedate", lit("1900-01-01"))).as("claims_year"),
        month(coalesce($"r.issuedate", lit("1900-01-01"))).as("claims_month"))
      .groupBy("r.groupId", "r.grp_mpi", "r.client_ds_id", "employeraccountid", "claims_year", "claims_month")
      .agg(count(lit(1)).cast(IntegerType).alias("rx_count"), sum(coalesce($"r.paidamount", lit(0))).as("rx_paid_amount")).alias("rx")

    clm_df.join(rx_df, $"clm.groupid" === $"rx.groupid"
      && $"clm.grp_mpi" === $"rx.grp_mpi"
      && $"clm.client_ds_id" === $"rx.client_ds_id"
      && $"clm.employeraccountid" === $"rx.employeraccountid"
      && $"clm.claims_year" === $"rx.claims_year"
      && $"clm.claims_month" === $"rx.claims_month", "full_outer")
      .select(coalesce($"clm.groupid", $"rx.groupid").alias("groupid"),
        coalesce($"clm.grp_mpi", $"rx.grp_mpi").alias("grp_mpi"),
        coalesce($"clm.client_ds_id", $"rx.client_ds_id").alias("client_ds_id"),
        coalesce($"clm.claims_year", $"rx.claims_year").alias("claims_year"),
        coalesce($"clm.claims_month", $"rx.claims_month").alias("claims_month"),
        round(coalesce($"clm.claim_paid_amount", lit(0)), 2).alias("claim_paid_amount"),
        round(coalesce($"rx.rx_paid_amount", lit(0)), 2).alias("rx_paid_amount"),
        coalesce($"clm.claim_count", lit(0)).alias("claim_count"),
        coalesce($"rx.rx_count", lit(0)).alias("rx_count"),
        coalesce($"clm.employeraccountid", $"rx.employeraccountid").alias("product_code"),
        to_timestamp(concat(coalesce($"clm.claims_year", $"rx.claims_year"),
          lpad(coalesce($"clm.claims_month", $"rx.claims_month"), 2, "0"), lit("01")), CDRConstants.DATE_FORMAT_4Y2M2D).alias("effective_date"),
        lit(new Timestamp(DateTime.now().getMillis)).cast(TimestampType).alias("db_create_dt_tm"),
        coalesce($"clm.dental_count", lit(0)).cast(IntegerType).alias("dental_count")
      )

  }

}
