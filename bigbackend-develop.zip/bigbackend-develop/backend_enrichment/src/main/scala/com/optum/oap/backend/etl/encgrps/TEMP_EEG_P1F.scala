package com.optum.oap.backend.etl.encgrps

import com.optum.oap.backend.cdrTempModel.temp_eeg_p1f
import com.optum.oap.sparkdataloader.QueryAndMetadata


object TEMP_EEG_P1F extends QueryAndMetadata[temp_eeg_p1f] {

  override def name: String = "TEMP_EEG_P1F"

  override def partitions: Int = 32

  override def sparkSql: String =
    """
      |SELECT
      |    *
      |FROM
      |    (
      |        SELECT
      |            ce.groupid,
      |            ce.client_ds_id,
      |            ce.encounterid,
      |            ce.grp_mpi,
      |            f.master_facility_name,
      |            ROW_NUMBER() OVER(
      |                PARTITION BY ce.groupid,ce.client_ds_id,ce.encounterid
      |                ORDER BY
      |                    datediff(least(to_date(ce.dischargetime),to_date(f.dischargetime)),greatest(to_date(ce.arrivaltime),to_date(f.arrivaltime))) DESC,
      |                    f.client_ds_id,f.encounterid
      |            ) AS fac_order
      |        FROM
      |            temp_eeg_p1a ce
      |            INNER JOIN temp_eeg_p1a f ON ( ce.grp_mpi = f.grp_mpi
      |                                           AND ce.patienttype = f.patienttype
      |                                           AND ce.master_facility_name IS NULL
      |                                           AND f.master_facility_name IS NOT NULL
      |                                           AND datediff(least(to_date(ce.dischargetime),to_date(f.dischargetime)),greatest(to_date(ce.arrivaltime),to_date(f.arrivaltime))) + 1 > 1 ) --must overlap by more than one day
      |    )
      |WHERE
      |    fac_order = 1
    """.stripMargin

  override def dependsOn: Set[String] = Set("TEMP_EEG_P1A")
}
