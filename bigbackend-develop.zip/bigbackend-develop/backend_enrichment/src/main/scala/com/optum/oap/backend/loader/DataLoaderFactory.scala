package com.optum.oap.backend.loader

import com.optum.oap.awsutils.AWSClientConfig
import com.optum.oap.backend.etl.common.CDRConstants
import com.optum.oap.backend.etl.common.EnrichmentUtils.EnrichmentConf
import com.optum.oap.backend.loader.loadgroup._
import com.optum.oap.backend.util.ECDRPathConfig
import com.optum.oap.backend.util.ECDRPathUtils.getBasePath
import com.optum.oap.checkpointing.{HDFSCheckpointer, PurgeAll, PurgeSome, S3Checkpointer}
import com.optum.oap.sparkdataloader.DataLoader
import com.optum.oap.utils.CliUtils.getOptionalSeq
import org.apache.hadoop.fs.Path

import java.net.URI

object DataLoaderFactory {

  private def ecdrPathConfig(conf: EnrichmentConf) =
    ECDRPathConfig(conf.clientId(), conf.environment(), conf.cdrLevel(), conf.cdrCycle(), conf.instance(), conf.clientBucket.toOption)

  private def checkpointerFromConfig(conf: EnrichmentConf) =
    conf.clientBucket
      .map(_ => S3Checkpointer.fromClientBucketURI(new URI(getBasePath(ecdrPathConfig(conf))), AWSClientConfig.default.createS3Client()))
      .getOrElse(HDFSCheckpointer.fromPath(new Path(getBasePath(ecdrPathConfig(conf)))))

  def getDataLoader(conf: EnrichmentConf): DataLoader[Seq[String]] with LoadGroup = {
    val purgePolicy =
      (conf.fullRun.toOption, getOptionalSeq(conf.targetTables)) match {
        case (Some(true), _) => PurgeAll
        case (_, Some(tables)) if tables.nonEmpty => PurgeSome(tables)
        case _ => PurgeSome(CDRConstants.metricTables)
      }

    val basePath = getBasePath(ecdrPathConfig(conf))
    val checkPointer = checkpointerFromConfig(conf)

    conf.loadGroups().split(",").head.toLowerCase match {
      case "bpo" => new DataLoader(basePath, checkPointer, purgePolicy) with BpoLoadGroup
      case "summary" => new DataLoader(basePath, checkPointer, purgePolicy) with SummaryLoadGroup
      case "encgrps" => new DataLoader(basePath, checkPointer, purgePolicy) with EncounterLoadGroup
      case "enrichment" => new DataLoader(basePath, checkPointer, purgePolicy) with EnrichmentLoadGroup
      case "combine" => new DataLoader(basePath, checkPointer, purgePolicy) with CombinedLoadGroup
      case "cdrfe" => new DataLoader(basePath, checkPointer, purgePolicy) with CDRFELoadGroup
      case "metrics" => new DataLoader(basePath, checkPointer, purgePolicy) with MetricsLoadGroup
      case _ => throw new IllegalArgumentException(s"Invalid loadGroup option - ${conf.loadGroups()}")
    }
  }
}
