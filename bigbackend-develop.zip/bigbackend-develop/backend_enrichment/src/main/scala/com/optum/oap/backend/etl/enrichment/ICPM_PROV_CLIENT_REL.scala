package com.optum.oap.backend.etl.enrichment


import com.optum.oap.backend.loader.EnrichmentRunTimeVariables
import com.optum.oap.cdr.models.{int_claim_prov, prov_client_rel, prov_status_rollup}
import com.optum.oap.sparkdataloader.{RuntimeVariables, TableInfo, UserDefinedFunctionForDataLoader}
import org.apache.spark.sql.expressions.Window
import org.apache.spark.sql.functions._
import org.apache.spark.sql.types.DataTypes
import org.apache.spark.sql.{DataFrame, SparkSession}
import org.slf4j.LoggerFactory

object ICPM_PROV_CLIENT_REL extends TableInfo[prov_client_rel] {

  private val log = LoggerFactory.getLogger(this.getClass)

  override def dependsOn = Set("INT_CLAIM_PROV", "PROV_STATUS_ROLLUP")

  override def name = "ICPM_PROV_CLIENT_REL"

  override def createDataFrame(sparkSession: SparkSession,
                               loadedDependencies: Map[String, DataFrame],
                               udfMap: Map[String, UserDefinedFunctionForDataLoader],
                               runtimeVariables: RuntimeVariables): DataFrame = {
    import sparkSession.implicits._

    val intClaimProvDf = loadedDependencies("INT_CLAIM_PROV").as[int_claim_prov]
    val provStatusRollup = loadedDependencies("PROV_STATUS_ROLLUP").as[prov_status_rollup]

    //val groupId = runtimeVariables.asInstanceOf[EnrichmentRunTimeVariables].clientId

    intClaimProvDf.alias("prv")
        .join(provStatusRollup.alias("prv_s"), $"prv.prov_status_id" === $"prv_s.prov_status_id", "left")
      .where($"prv.prov_status_id".isNotNull && $"prv.prov_id".isNotNull && $"prv.eff_date".isNotNull)
      .select($"prv.client_ds_id".as("client_ds_id"),
        lit("int_claim_prov").as("datasrc"),
        $"prv.end_date".as("enddate"),
        $"prv.groupid".as("groupid"),
        when($"prv_s.prov_status_rollup" === "Y", lit("IN_NETWORK"))
        .when($"prv_s.prov_status_rollup" === "N", lit("OUT_OF_NETWORK"))
        .otherwise($"prv.prov_status_id").as("localrelshipcode"),
        lit(null).cast(DataTypes.StringType).as("mstrprovid"),
        $"prv.prov_status_id",
        $"prv.prov_id".as("providerid"),
        $"prv.eff_date".as("startdate"),
        upper(first("prv.primary_span", true).over(Window.partitionBy($"prv.client_ds_id", $"prv.eff_date", $"prv.end_date", $"prv.prov_id", $"prv.prov_status_id").orderBy($"prv.primary_span".desc_nulls_last))).as("primary_span")
      ).distinct()

  }
}