package com.optum.oap.backend.etl.enrichment

import com.optum.oap.cdr.models.{int_claim_member, int_claim_prov, prov_affil_rollup}
import com.optum.oap.sparkdataloader.{RuntimeVariables, TableInfo, UserDefinedFunctionForDataLoader}
import org.apache.spark.sql.expressions.Window
import org.apache.spark.sql.{DataFrame, SparkSession}
import org.slf4j.LoggerFactory
import org.apache.spark.sql.functions.{coalesce, lit, _}

object PROV_AFFIL_ROLLUP extends TableInfo[prov_affil_rollup] {

  private val log = LoggerFactory.getLogger(this.getClass)

  override def dependsOn = Set("CDR_FE_PROV_AFFIL_ROLLUP","INT_CLAIM_PROV","INT_CLAIM_MEDICAL", "INT_CLAIM_MEMBER")

  override def name = "PROV_AFFIL_ROLLUP"

  override def partitions: Int = 32

  override def createDataFrame(sparkSession: SparkSession,
                               loadedDependencies: Map[String, DataFrame],
                               udfMap: Map[String, UserDefinedFunctionForDataLoader],
                               runtimeVariables: RuntimeVariables): DataFrame = {

    import sparkSession.implicits._

    val cdrProvAffilRollup = loadedDependencies("CDR_FE_PROV_AFFIL_ROLLUP").as[prov_affil_rollup]

    val cdrIntClaimProv = loadedDependencies("INT_CLAIM_PROV").as[int_claim_prov]

    val intClaimMem = loadedDependencies("INT_CLAIM_MEMBER").as[int_claim_member]

    val intClaimMedical = loadedDependencies("INT_CLAIM_MEDICAL")

    //*PROV_AFFIL_ROLLUP*
    //Origin PROV_AFFIL_ROLLUP rollup table
    val cdrPARollup1 = cdrProvAffilRollup.select( $"groupid",
      $"client_ds_id",
      $"datasrc",
      $"prov_affil_id",
      $"prov_affil_desc",
      $"prov_affil_lv2",
      $"prov_affil_lv2_desc",
      $"prov_affil_lv1",
      $"prov_affil_lv1_desc")

    //TAKING DISTINCT PROV_AFFIL IDS FROM THE PROV_AFFIL ROLLUP TABLE
    val cdrPASelect = cdrPARollup1
      .dropDuplicates("prov_affil_id")

    //SELECTING RECORDS OF INT_CLAIM_PROV TABLE WHOSE PROV_AFFIL IDS ARE NOT IN THE PROV_AFFIL ROLLUP TABLE
    val provAffil = cdrIntClaimProv.as("a").join(cdrPASelect.as("b"),$"a.prov_affil_id" === $"b.prov_affil_id","left")
      .select($"a.groupid"
        ,$"a.client_ds_id"
        ,lit("int_claim_prov").as("datasrc")
      ,$"a.prov_affil_id"
        ,substring(concat(lit("UNDEFINED ("), $"a.prov_affil_id", lit(")")),1,150).as("prov_affil_desc")
        ,$"b.prov_affil_lv2"
        ,$"b.prov_affil_lv2_desc"
        ,$"b.prov_affil_lv1"
        ,$"b.prov_affil_lv1_desc"
      )
      .where($"a.prov_affil_id".isNotNull && (length($"a.prov_affil_id") <= 30) && $"b.prov_affil_id".isNull)
      .groupBy($"groupid", $"datasrc", $"a.prov_affil_id", $"prov_affil_desc",
        $"b.prov_affil_lv2", $"b.prov_affil_lv2_desc", $"b.prov_affil_lv1",
        $"b.prov_affil_lv1_desc")
      .agg(min($"client_ds_id").as("client_ds_id"))

    //UNION THE MISSING RECORDS FETCHED FROM INT_CLAIM_PROV AND THE ORIGINAL PROV_AFFIL ROLLUP TABLE
    val cdrUnionPAffil = cdrPARollup1.unionByName(provAffil)

    //TAKING DISTINCT PROV_AFFIL IDS FROM THE UNION PROV_AFFIL ROLLUP TABLE
    val cdrPASel = cdrUnionPAffil
      .dropDuplicates("prov_affil_id")
      .select("*")

    //SELECTING RECORDS OF INT_CLAIM_MEDICAL TABLE WHOSE PROV_AFFIL IDS ARE NOT IN THE PROV_AFFIL ROLLUP TABLE
    val claimMedical = intClaimMedical.as("a").join(cdrPASel.as("b"),$"a.serv_prov_affil_id" === $"b.prov_affil_id","left")
      .select($"a.groupid"
        ,$"a.client_ds_id"
        ,$"a.serv_prov_affil_id".as("prov_affil_id")
        ,lit("int_claim_medical").as("datasrc")
        ,substring(concat(lit("UNDEFINED ("), $"a.serv_prov_affil_id", lit(")")),1,150).as("prov_affil_desc")
        ,$"b.prov_affil_lv2"
        ,$"b.prov_affil_lv2_desc"
        ,$"b.prov_affil_lv1"
        ,$"b.prov_affil_lv1_desc")
      .where($"a.serv_prov_affil_id".isNotNull && (length($"a.serv_prov_affil_id") <= 30) && $"b.prov_affil_id".isNull)
      .groupBy($"groupid",$"prov_affil_id",$"datasrc",$"prov_affil_desc",
        $"b.prov_affil_lv2",$"b.prov_affil_lv2_desc",$"b.prov_affil_lv1",$"b.prov_affil_lv1_desc")
      .agg(min($"client_ds_id").as("client_ds_id"))

    //UNION THE MISSING RECORDS FETCHED FROM INT_CLAIM_MEDICAL AND THE UNIONED PROV_AFFIL ROLLUP and INT_CLAIM_PROV TABLES
    val unionProvAffilRollup = cdrUnionPAffil.unionByName(claimMedical)

    //TAKING DISTINCT PROV_AFFIL IDS FROM THE UNION ROLLUP TABLE
    val cPASelect = unionProvAffilRollup
      .dropDuplicates("prov_affil_id")
      .select("*")

    //SELECTING RECORDS OF INT_CLAIM_MEDICAL TABLE WHOSE PROV_AFFIL IDS ARE NOT IN THE INTCLAIMMEMBER  TABLE
    val claimmember = intClaimMem.as("a").join(cPASelect.as("b"),$"a.pcp_prov_affil_id" === $"b.prov_affil_id","left")
      .select($"a.groupid"
        ,$"a.client_ds_id"
        ,$"a.pcp_prov_affil_id" .as("prov_affil_id")
        ,lit("int_claim_member").as("datasrc")
        ,substring(concat(lit("UNDEFINED ("), $"a.pcp_prov_affil_id", lit(")")),1,150).as("prov_affil_desc")
        ,$"b.prov_affil_lv2"
        ,$"b.prov_affil_lv2_desc"
        ,$"b.prov_affil_lv1"
        ,$"b.prov_affil_lv1_desc")
      .where($"a.pcp_prov_affil_id".isNotNull && (length($"a.pcp_prov_affil_id") <= 30) && $"b.prov_affil_id".isNull)
      .groupBy($"groupid",$"prov_affil_id",$"datasrc",$"prov_affil_desc",
        $"b.prov_affil_lv2",$"b.prov_affil_lv2_desc",$"b.prov_affil_lv1",$"b.prov_affil_lv1_desc")
      .agg(min($"client_ds_id").as("client_ds_id"))
    
    //*UNION*
    //NOW UNION THE MISSING RECORDS FETCHED FROM INT_CLAIM_MEMBER AND THE UNIONED PROV_AFFIL ROLLUP,INT_CLAIM_PROV, PROV_AFFIL_ROLLUP TABLES
    val unionFinal = unionProvAffilRollup.unionByName(claimmember)

    //APPLYING ADDITIONAL TRANSFORMATIONS ON THE UNION WITH THE FETCHED RECORDS OF INT_CLAIM_PROV AND INTCLAIMEMBER AND LOAD TO BACKEND.
    val rollup = unionFinal.select(
      $"groupid"
      ,$"client_ds_id"
      ,$"datasrc"
      ,$"prov_affil_id"
      ,substring(coalesce($"prov_affil_desc", concat(lit("UNDEFINED ("),$"prov_affil_id",lit(")"))),1,150).as("prov_affil_desc")
      ,substring(coalesce($"prov_affil_lv2", concat(lit("3."),$"prov_affil_id")),1,30).as("prov_affil_lv2")
      ,substring(when($"prov_affil_lv2".isNull,coalesce($"prov_affil_desc",concat(lit("UNDEFINED ("),$"prov_affil_id",lit(")"))))
        .otherwise(coalesce($"prov_affil_lv2_desc",concat(lit("UNDEFINED ("),$"prov_affil_lv2",lit(")")))) ,1,150)
        .as("prov_affil_lv2_desc")
      ,substring(coalesce($"prov_affil_lv1" ,when($"prov_affil_lv2".isNotNull,concat(lit("2."),$"prov_affil_lv2"))
        .otherwise(concat(lit("3."),$"prov_affil_id"))),1,30).as("prov_affil_lv1")
      ,substring(when($"prov_affil_lv1".isNull,
        when($"prov_affil_lv2".isNull,coalesce($"prov_affil_desc",concat(lit("UNDEFINED ("),$"prov_affil_id",lit(")")) ))
          .otherwise(coalesce($"prov_affil_lv2_desc",concat(lit("UNDEFINED ("),$"prov_affil_lv2",lit(")")) )))
        .otherwise(coalesce($"prov_affil_lv1_desc",concat(lit("UNDEFINED ("),$"prov_affil_lv1",lit(")")))),1,150).as("prov_affil_lv1_desc")
      ,row_number().over(Window.partitionBy($"prov_affil_id")
        .orderBy(
          when($"prov_affil_desc".isNotNull, lit(0)).otherwise(lit(1)),
          when($"prov_affil_lv2".isNotNull, lit(0)).otherwise(lit(1)),
          when($"prov_affil_lv1".isNotNull, lit(0)).otherwise(lit(1)),
          $"prov_affil_desc",$"prov_affil_lv2",$"prov_affil_lv1", $"client_ds_id"
        )).as("rn")
    )
      .where(unionProvAffilRollup("prov_affil_id").isNotNull && (length(unionProvAffilRollup("prov_affil_id")) <=30) && ($"rn"=== 1))
      .drop($"rn")

    rollup.as[prov_affil_rollup].toDF()
  }
}
