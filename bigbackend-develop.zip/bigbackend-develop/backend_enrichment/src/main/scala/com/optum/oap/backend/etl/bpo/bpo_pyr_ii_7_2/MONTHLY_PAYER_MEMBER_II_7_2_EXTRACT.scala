package com.optum.oap.backend.etl.bpo.bpo_pyr_ii_7_2

import com.optum.oap.backend.cdrTempModel.monthly_payer_member
import com.optum.oap.cdr.models.{pp_bpo_member_detail, pp_bpo_member_detail_ii, zo_bpo_map_employer}
import com.optum.oap.sparkdataloader.{RuntimeVariables, TableInfo, UserDefinedFunctionForDataLoader}
import org.apache.spark.sql.expressions.Window
import org.apache.spark.sql.functions._
import org.apache.spark.sql.types.StringType
import org.apache.spark.sql.{DataFrame, SparkSession}

/**
  *
  * Copyright 2020 Optum Analytics
  *
  * Date: 2/18/20
  *
  * Creator: pavula1
  */
object MONTHLY_PAYER_MEMBER_II_7_2_EXTRACT extends TableInfo[monthly_payer_member] {

  override def dependsOn = Set("ZO_BPO_MAP_EMPLOYER", "PP_BPO_MEMBER_DETAIL_II", "PP_BPO_MEMBER_DETAIL")

  override def name = "MONTHLY_PAYER_MEMBER_II_7_2_EXTRACT"

  override def createDataFrame(sparkSession: SparkSession,
                               loadedDependencies: Map[String, DataFrame],
                               udfMap: Map[String, UserDefinedFunctionForDataLoader],
                               runtimeVariables: RuntimeVariables): DataFrame = {
    import sparkSession.implicits._

    val ppBpoMemberDetail = loadedDependencies("PP_BPO_MEMBER_DETAIL").as[pp_bpo_member_detail]
    val zoMapEmployer = broadcast(loadedDependencies("ZO_BPO_MAP_EMPLOYER")).as[zo_bpo_map_employer]
    val ppBpoMemberDetailII = loadedDependencies("PP_BPO_MEMBER_DETAIL_II").as[pp_bpo_member_detail_ii]

    val csid_df = zoMapEmployer.groupBy($"employeraccountid")
      .agg(max($"client_ds_id").as("client_ds_id"))
      .select($"employeraccountid", $"client_ds_id")

    val pp_ii = ppBpoMemberDetailII.select($"memberid").distinct()

    val ii_Df = ppBpoMemberDetailII.alias("ii")
      .where($"healthplansource" === "PAYER")
      .join(csid_df.as("csid"), $"ii.employeraccountid" === $"csid.employeraccountid", "left")
      .select(
        $"memberid".as("member"),
        when($"gender" === lit("F"), lit(1)).otherwise(lit(0)).cast(StringType).alias("sex"),
        date_format($"dob", "yyyy-MM-dd").as("dob"),
        $"state".as("state_n"),
        $"zipcode".as("zip_n"),
        $"coveragestatus".as("coverage_status"),
        date_format($"effectivedate", "yyyy-MM-dd").as("eff_dt"),
        date_format($"enddate", "yyyy-MM-dd").as("end_dt"),
        when($"pharmacy" === lit("Y"), lit(1)).otherwise(lit(0)).cast(StringType).alias("rx"),
        when($"medical" === lit("Y"), lit(1)).otherwise(lit(0)).cast(StringType).alias("med"),
        $"pcpid".as("pcp_id"),
        lit(1).cast(StringType).as("map_srce_e"),
        concat($"subscriberid", lit("_"), $"client_ds_id").as("subscriber_id"),
        $"lastname".as("last_name"),
        $"firstname".as("first_name"),
        concat($"lastname", lit(","), $"firstname").as("full_name"),
        $"mem_userdef_1".as("mem_userdef_1"),
        $"mem_userdef_2".as("mem_userdef_2"),
        $"mem_userdef_3".as("mem_userdef_3"),
        $"mem_userdef_4".as("mem_userdef_4"),
        $"at_risk_status".as("at_risk_status"),
        when($"dental_benefit" === lit("Y"), lit(1)).otherwise(lit(0)).cast(StringType).alias("den"),
        when($"mentalhealth" === lit("Y"), lit(1)).otherwise(lit(0)).cast(StringType).alias("mh"),
        $"pcp_affil".as("pcp_affil"),
        substring(concat($"address1", when($"address2".isNotNull, concat(lit(" "), $"address2")).otherwise(lit(null).cast(StringType))), 0, 100).alias("address"),
        $"city".as("city"),
        $"phone".as("phone"),
        $"email".as("email"),
        $"sec_member_id_1".as("sec_member_id_1"),
        $"sec_member_id_2".as("sec_member_id_2"),
        $"employee_type".as("employee_type"),
        $"hra_ind".cast(StringType).as("hra_ind"),
        $"hsa_ind".cast(StringType).as("hsa_ind"),
        lit("").cast(StringType).as("geo_lat"),
        lit("").cast(StringType).as("geo_lon"),
        $"cust_mem_attr1".as("cust_mem_1"),
        $"cust_mem_attr2".as("cust_mem_2"),
        $"cust_mem_attr3".as("cust_mem_3"),
        $"cust_mem_attr4".as("cust_mem_4"),
        $"cust_mem_attr5".as("cust_mem_5"),
        $"cust_mem_attr6".as("cust_mem_6"),
        $"cust_mem_attr7".as("cust_mem_7"),
        $"cust_mem_attr8".as("cust_mem_8"),
        $"cust_mem_attr9".as("cust_mem_9"),
        $"cust_mem_attr10".as("cust_mem_10"),
        $"cust_mem_attr11".as("cust_mem_11"),
        $"cust_mem_attr12".as("cust_mem_12"),
        $"cust_mem_attr13".as("cust_mem_13"),
        $"cust_mem_attr14".as("cust_mem_14"),
        $"cust_mem_attr15".as("cust_mem_15"),
        $"cust_mem_attr16".as("cust_mem_16"),
        $"cust_mem_attr17".as("cust_mem_17"),
        $"cust_mem_attr18".as("cust_mem_18"),
        $"cust_mem_attr19".as("cust_mem_19"),
        $"cust_mem_attr20".as("cust_mem_20"),
        concat($"memberid", lpad(row_number().over(Window.partitionBy($"memberid").orderBy($"effectivedate".asc, $"contract_id".asc)), 3, "0")).as("cust_mem_pk_id")
      )

    val member_detail_Df = ppBpoMemberDetail.alias("pp")
      .where($"healthplansource" === "PAYER")
      .join(csid_df.as("csid"), $"pp.employeraccountid" === $"csid.employeraccountid", "left")
      .join(pp_ii.as("pp_ii"), $"pp.memberid" === $"pp_ii.memberid", "left_anti")
      .select(
        $"memberid".as("member"),
        when($"gender" === lit("F"), lit(1)).otherwise(lit(0)).cast(StringType).alias("sex"),
        date_format($"dob", "yyyy-MM-dd").as("dob"),
        $"state".as("state_n"),
        $"zipcode".as("zipcode_n"),
        $"coveragestatus".as("coverage_status"),
        date_format($"effectivedate", "yyyy-MM-dd").as("eff_dt"),
        date_format($"enddate", "yyyy-MM-dd").as("end_dt"),
        when($"pharmacy" === lit("Y"), lit(1)).otherwise(lit(0)).cast(StringType).alias("rx"),
        when($"medical" === lit("Y"), lit(1)).otherwise(lit(0)).cast(StringType).alias("med"),
        $"pcpid".as("pcp_id"),
        lit(1).cast(StringType).as("map_srce_e"),
        concat($"subscriberid", lit("_"), $"client_ds_id").as("subscriber_id"),
        $"lastname".as("last_name"),
        $"firstname".as("first_name"),
        concat($"lastname", lit(","), $"firstname").as("full_name"),
        $"mem_userdef_1".as("mem_userdef_1"),
        $"mem_userdef_2".as("mem_userdef_2"),
        $"mem_userdef_3".as("mem_userdef_3"),
        $"mem_userdef_4".as("mem_userdef_4"),
        $"at_risk_status".as("at_risk_status"),
        when($"dental_benefit" === lit("Y"), lit(1)).otherwise(lit(0)).cast(StringType).alias("den"),
        when($"mentalhealth" === lit("Y"), lit(1)).otherwise(lit(0)).cast(StringType).alias("mh"),
        $"pcp_affil".as("pcp_affil"),
        substring(concat($"address1", when($"address2".isNotNull, concat(lit(" "), $"address2")).otherwise(lit(null).cast(StringType))), 0, 100).alias("address"),
        $"city".as("city"),
        $"phone".as("phone"),
        $"email".as("email"),
        $"sec_member_id_1".cast(StringType).as("sec_member_id_1"),
        $"sec_member_id_2".cast(StringType).as("sec_member_id_2"),
        $"employee_type".as("employee_type"),
        $"hra_ind".as("hra_ind"),
        $"hsa_ind".as("hsa_ind"),
        lit("").cast(StringType).as("geo_lat"),
        lit("").cast(StringType).as("geo_lon"),
        $"cust_mem_attr1".as("cust_mem_1"),
        $"cust_mem_attr2".as("cust_mem_2"),
        $"cust_mem_attr3".as("cust_mem_3"),
        $"cust_mem_attr4".as("cust_mem_4"),
        $"cust_mem_attr5".as("cust_mem_5"),
        $"cust_mem_attr6".as("cust_mem_6"),
        $"cust_mem_attr7".as("cust_mem_7"),
        $"cust_mem_attr8".as("cust_mem_8"),
        $"cust_mem_attr9".as("cust_mem_9"),
        $"cust_mem_attr10".as("cust_mem_10"),
        $"cust_mem_attr11".as("cust_mem_11"),
        $"cust_mem_attr12".as("cust_mem_12"),
        $"cust_mem_attr13".as("cust_mem_13"),
        $"cust_mem_attr14".as("cust_mem_14"),
        $"cust_mem_attr15".as("cust_mem_15"),
        $"cust_mem_attr16".as("cust_mem_16"),
        $"cust_mem_attr17".as("cust_mem_17"),
        $"cust_mem_attr18".as("cust_mem_18"),
        $"cust_mem_attr19".as("cust_mem_19"),
        $"cust_mem_attr20".as("cust_mem_20"),
        concat($"memberid", lpad(row_number().over(Window.partitionBy($"memberid").orderBy($"effectivedate".asc, $"contract_id".asc)), 3, "0")).as("cust_mem_pk_id")
      )

    ii_Df.union(member_detail_Df)

  }

}
