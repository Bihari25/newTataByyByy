package com.optum.oap.backend.etl.encgrps

import com.optum.oap.backend.cdrTempModel.{temp_encounter_grp_ccs, temp_encounter_grp_rel_base}
import com.optum.oap.cdr.models.encounter_grp_rel
import com.optum.oap.sparkdataloader.{RuntimeVariables, TableInfo, UserDefinedFunctionForDataLoader}
import org.apache.spark.sql.expressions.Window
import org.apache.spark.sql.{DataFrame, SparkSession}

// Maps to TEMP_ENCOUNTER_GRP_REL0
object TEMP_ENCOUNTER_GRP_REL_CCS_CH001649 extends TableInfo[encounter_grp_rel] {

  override def name: String = "TEMP_ENCOUNTER_GRP_REL_CCS_CH001649"

  override def dependsOn: Set[String] = Set("TEMP_ENCOUNTER_GRP_CCS", "ENCOUNTER_GRP_REL_BASE")

  override protected def createDataFrame(sparkSession: SparkSession,
                                         loadedDependencies: Map[String, DataFrame],
                                         udfMap: Map[String, UserDefinedFunctionForDataLoader],
                                         runtimeVariables: RuntimeVariables): DataFrame = {
    import org.apache.spark.sql.functions._
    import sparkSession.implicits._

    val tempEncounterGrpBaseRel = loadedDependencies("ENCOUNTER_GRP_REL_BASE").as[temp_encounter_grp_rel_base]
    val tempEncounterGrpCCS = loadedDependencies("TEMP_ENCOUNTER_GRP_CCS").as[temp_encounter_grp_ccs]

    /*
    select  GROUPID,ENCOUNTER_GRP_NUM,ENCOUNTER_GRP_REL_TYPE,REL_ENCOUNTER_GRP_NUM
from
(select idx.groupid, idx.ENCOUNTER_GRP_NUM, 'CH001649' as ENCOUNTER_GRP_REL_TYPE  --IP to IP base any dx
  , readm.ENCOUNTER_GRP_NUM as REL_ENCOUNTER_GRP_NUM
  , row_number() over (partition by idx.ENCOUNTER_GRP_NUM
                 order by idx.ENCOUNTER_GRP_NUM, datediff(date_trunc('dd', readm.admittime), date_trunc('dd', idx.dischargetime)), readm.ENCOUNTER_GRP_NUM) as rrank
from ENCOUNTER_GRP idx
inner join ENCOUNTER_GRP readm on (idx.grp_mpi = readm.grp_mpi)
where idx.encounter_grp_type = 'CH000106'
and readm.encounter_grp_type = 'CH000106'
and date_trunc('dd', readm.admittime) > date_trunc('dd', idx.dischargetime)
and idx.baseinclude = 'Y'
and (readm.drg is null or readm.drg not in ('945','946'))
and (readm.prindx is null or substr(readm.prindx,1,3) not in ('V52','V53','V54','V57'))
and not exists (select 1 from TEMP_ENCOUNTER_GRP_CCS ccs
                where readm.ENCOUNTER_GRP_NUM = ccs.ENCOUNTER_GRP_NUM
                and ccs_cat = '254')
)
where rrank = 1
     */
    val result = tempEncounterGrpBaseRel.as("rel")
      .join(tempEncounterGrpCCS.where($"ccs_cat" === lit("254")).as("ccs"), $"rel.readmEncounterGrpNum" === $"ccs.ENCOUNTER_GRP_NUM", "leftouter")
      .where(
        $"rel.idxEncounterGrpType" === lit("CH000106") &&
          $"rel.readmEncounterGrpType" === lit("CH000106") &&
          $"rel.idxBaseInclude" === lit("Y") &&
          ($"rel.readmDrg".isNull || !$"rel.readmDrg".isin("945", "946")) &&
          ($"rel.readmPrinDx".isNull || !substring($"rel.readmPrinDx", 1, 3).isin("V52", "V53", "V54", "V57")) && $"ccs.ccs_cat".isNull)
      .select(
        $"rel.idxGroupId".as("GROUPID"),
        $"rel.idxEncounterGrpNum".as("ENCOUNTER_GRP_NUM"),
        lit("CH001649").as("ENCOUNTER_GRP_REL_TYPE"),
        $"rel.readmEncounterGrpNum".as("REL_ENCOUNTER_GRP_NUM"),
        row_number().over(Window.partitionBy($"rel.idxEncounterGrpNum")
          .orderBy($"rel.idxEncounterGrpNum", datediff(to_date($"rel.readmAdmitTime"), to_date($"rel.idxDischargeTime")), $"rel.readmEncounterGrpNum")).as("rrank")
      )
      .where($"rrank" === lit(1))
      .select(
        $"GROUPID",
        $"ENCOUNTER_GRP_NUM",
        $"ENCOUNTER_GRP_REL_TYPE",
        $"REL_ENCOUNTER_GRP_NUM"
      ).as[encounter_grp_rel]

    result.toDF()
  }
}

// Maps to TEMP_ENCOUNTER_GRP_REL1
object TEMP_ENCOUNTER_GRP_REL_CCS_CH001650 extends TableInfo[encounter_grp_rel] {

  override def name: String = "TEMP_ENCOUNTER_GRP_REL_CCS_CH001650"

  override def dependsOn: Set[String] = Set("TEMP_ENCOUNTER_GRP_CCS", "ENCOUNTER_GRP_REL_BASE")

  override protected def createDataFrame(sparkSession: SparkSession,
                                         loadedDependencies: Map[String, DataFrame],
                                         udfMap: Map[String, UserDefinedFunctionForDataLoader],
                                         runtimeVariables: RuntimeVariables): DataFrame = {
    import org.apache.spark.sql.functions._
    import sparkSession.implicits._

    val tempEncounterGrpBaseRel = loadedDependencies("ENCOUNTER_GRP_REL_BASE").as[temp_encounter_grp_rel_base]
    val tempEncounterGrpCCS = loadedDependencies("TEMP_ENCOUNTER_GRP_CCS").as[temp_encounter_grp_ccs]

    /*
    select GROUPID,ENCOUNTER_GRP_NUM,ENCOUNTER_GRP_REL_TYPE,REL_ENCOUNTER_GRP_NUM
from
(select idx.groupid, idx.ENCOUNTER_GRP_NUM, 'CH001650' as ENCOUNTER_GRP_REL_TYPE  --IP to IP base same prindx3
  , readm.ENCOUNTER_GRP_NUM as REL_ENCOUNTER_GRP_NUM
  , row_number() over (partition by idx.ENCOUNTER_GRP_NUM
                 order by idx.ENCOUNTER_GRP_NUM,datediff(date_trunc('dd', readm.admittime), date_trunc('dd', idx.dischargetime)), readm.ENCOUNTER_GRP_NUM) as rrank
from ENCOUNTER_GRP idx
inner join ENCOUNTER_GRP readm on (idx.grp_mpi = readm.grp_mpi)
where idx.encounter_grp_type = 'CH000106'
and readm.encounter_grp_type = 'CH000106'
and date_trunc('dd', readm.admittime) > date_trunc('dd', idx.dischargetime)
and idx.prindx is not null
and substr(idx.prindx,1,3) =  substr(readm.prindx,1,3)
and idx.baseinclude = 'Y'
and (readm.drg is null or readm.drg not in ('945','946'))
and substr(readm.prindx,1,3) not in ('V52','V53','V54','V57')
and not exists (select 1 from TEMP_ENCOUNTER_GRP_CCS ccs
                where readm.ENCOUNTER_GRP_NUM = ccs.ENCOUNTER_GRP_NUM
                and ccs_cat = '254')
)
where rrank = 1
     */
    val result = tempEncounterGrpBaseRel.as("rel")
      .join(tempEncounterGrpCCS.where($"ccs_cat" === lit("254")).as("ccs"), $"rel.readmEncounterGrpNum" === $"ccs.ENCOUNTER_GRP_NUM", "leftouter")
      .where(
        $"rel.idxEncounterGrpType" === lit("CH000106") &&
          $"rel.readmEncounterGrpType" === lit("CH000106") &&
          $"rel.idxPrinDx".isNotNull && substring($"rel.idxPrinDx", 1, 3) === substring($"rel.readmPrinDx", 1, 3) &&
          $"rel.idxBaseInclude" === lit("Y") &&
          ($"rel.readmDrg".isNull || !$"rel.readmDrg".isin("945", "946")) &&
          !substring($"rel.readmPrinDx", 1, 3).isin("V52", "V53", "V54", "V57") && $"ccs.ccs_cat".isNull)
      .select(
        $"rel.idxGroupId".as("GROUPID"),
        $"rel.idxEncounterGrpNum".as("ENCOUNTER_GRP_NUM"),
        lit("CH001650").as("ENCOUNTER_GRP_REL_TYPE"),
        $"rel.readmEncounterGrpNum".as("REL_ENCOUNTER_GRP_NUM"),
        row_number().over(Window.partitionBy($"rel.idxEncounterGrpNum")
          .orderBy($"rel.idxEncounterGrpNum", datediff(to_date($"rel.readmAdmitTime"), to_date($"rel.idxDischargeTime")), $"rel.readmEncounterGrpNum")).as("rrank")
      )
      .where($"rrank" === lit(1))
      .select(
        $"GROUPID",
        $"ENCOUNTER_GRP_NUM",
        $"ENCOUNTER_GRP_REL_TYPE",
        $"REL_ENCOUNTER_GRP_NUM"
      ).as[encounter_grp_rel]

    result.toDF()
  }
}

// Maps to TEMP_ENCOUNTER_GRP_REL3
object TEMP_ENCOUNTER_GRP_REL_CCS_CH001653 extends TableInfo[encounter_grp_rel] {

  override def name: String = "TEMP_ENCOUNTER_GRP_REL_CCS_CH001653"

  override def dependsOn: Set[String] = Set("TEMP_ENCOUNTER_GRP_CCS", "ENCOUNTER_GRP_REL_BASE")

  override protected def createDataFrame(sparkSession: SparkSession,
                                         loadedDependencies: Map[String, DataFrame],
                                         udfMap: Map[String, UserDefinedFunctionForDataLoader],
                                         runtimeVariables: RuntimeVariables): DataFrame = {
    import org.apache.spark.sql.functions._
    import sparkSession.implicits._

    val tempEncounterGrpBaseRel = loadedDependencies("ENCOUNTER_GRP_REL_BASE").as[temp_encounter_grp_rel_base]
    val tempEncounterGrpCCS = loadedDependencies("TEMP_ENCOUNTER_GRP_CCS").as[temp_encounter_grp_ccs]

    /*
    select GROUPID,ENCOUNTER_GRP_NUM,ENCOUNTER_GRP_REL_TYPE,REL_ENCOUNTER_GRP_NUM
from
(select idx.groupid, idx.ENCOUNTER_GRP_NUM, 'CH001653' as ENCOUNTER_GRP_REL_TYPE  --IP to IP client unplanned any dx
  , readm.ENCOUNTER_GRP_NUM as REL_ENCOUNTER_GRP_NUM
  , row_number() over (partition by idx.ENCOUNTER_GRP_NUM
                 order by idx.ENCOUNTER_GRP_NUM,datediff(date_trunc('dd', readm.admittime), date_trunc('dd', idx.dischargetime)), readm.ENCOUNTER_GRP_NUM) as rrank
from ENCOUNTER_GRP idx
inner join ENCOUNTER_GRP readm on (idx.grp_mpi = readm.grp_mpi)
where idx.encounter_grp_type = 'CH000106'
and readm.encounter_grp_type = 'CH000106'
and date_trunc('dd', readm.admittime) > date_trunc('dd', idx.dischargetime)
and idx.baseinclude = 'Y'
and readm.clientplanned = 'N'
and (readm.drg is null or readm.drg not in ('945','946'))
and (readm.prindx is null or substr(readm.prindx,1,3) not in ('V52','V53','V54','V57'))
and not exists (select 1 from TEMP_ENCOUNTER_GRP_CCS ccs
                where readm.ENCOUNTER_GRP_NUM = ccs.ENCOUNTER_GRP_NUM
                and ccs_cat = '254')
)
where rrank = 1
     */
    val result = tempEncounterGrpBaseRel.as("rel")
      .join(tempEncounterGrpCCS.where($"ccs_cat" === lit("254")).as("ccs"), $"rel.readmEncounterGrpNum" === $"ccs.ENCOUNTER_GRP_NUM", "leftouter")
      .where(
        $"rel.idxEncounterGrpType" === lit("CH000106") &&
          $"rel.readmEncounterGrpType" === lit("CH000106") &&
          $"rel.idxBaseInclude" === lit("Y") &&
          $"rel.readmClientPlanned" === lit("N") &&
          ($"rel.readmDrg".isNull || !$"rel.readmDrg".isin("945", "946")) &&
          ($"rel.readmPrinDx".isNull || !substring($"rel.readmPrinDx", 1, 3).isin("V52", "V53", "V54", "V57")) && $"ccs.ccs_cat".isNull)
      .select(
        $"rel.idxGroupId".as("GROUPID"),
        $"rel.idxEncounterGrpNum".as("ENCOUNTER_GRP_NUM"),
        lit("CH001653").as("ENCOUNTER_GRP_REL_TYPE"),
        $"rel.readmEncounterGrpNum".as("REL_ENCOUNTER_GRP_NUM"),
        row_number().over(Window.partitionBy($"rel.idxEncounterGrpNum")
          .orderBy($"rel.idxEncounterGrpNum", datediff(to_date($"rel.readmAdmitTime"), to_date($"rel.idxDischargeTime")), $"rel.readmEncounterGrpNum")).as("rrank")
      )
      .where($"rrank" === lit(1))
      .select(
        $"GROUPID",
        $"ENCOUNTER_GRP_NUM",
        $"ENCOUNTER_GRP_REL_TYPE",
        $"REL_ENCOUNTER_GRP_NUM"
      ).as[encounter_grp_rel]

    result.toDF()
  }
}

// Maps to TEMP_ENCOUNTER_GRP_REL4
object TEMP_ENCOUNTER_GRP_REL_CCS_CH001651 extends TableInfo[encounter_grp_rel] {

  override def name: String = "TEMP_ENCOUNTER_GRP_REL_CCS_CH001651"

  override def dependsOn: Set[String] = Set("TEMP_ENCOUNTER_GRP_CCS", "ENCOUNTER_GRP_REL_BASE")

  override protected def createDataFrame(sparkSession: SparkSession,
                                         loadedDependencies: Map[String, DataFrame],
                                         udfMap: Map[String, UserDefinedFunctionForDataLoader],
                                         runtimeVariables: RuntimeVariables): DataFrame = {
    import org.apache.spark.sql.functions._
    import sparkSession.implicits._

    val tempEncounterGrpBaseRel = loadedDependencies("ENCOUNTER_GRP_REL_BASE").as[temp_encounter_grp_rel_base]
    val tempEncounterGrpCCS = loadedDependencies("TEMP_ENCOUNTER_GRP_CCS").as[temp_encounter_grp_ccs]

    /*
    select GROUPID,ENCOUNTER_GRP_NUM,ENCOUNTER_GRP_REL_TYPE,REL_ENCOUNTER_GRP_NUM
from
(select idx.groupid, idx.ENCOUNTER_GRP_NUM, 'CH001651' as ENCOUNTER_GRP_REL_TYPE  --IP to IP client unplanned same prindx3
  , readm.ENCOUNTER_GRP_NUM as REL_ENCOUNTER_GRP_NUM
  , row_number() over (partition by idx.ENCOUNTER_GRP_NUM
                 order by idx.ENCOUNTER_GRP_NUM,datediff(date_trunc('dd', readm.admittime), date_trunc('dd', idx.dischargetime)), readm.ENCOUNTER_GRP_NUM) as rrank
from ENCOUNTER_GRP idx
inner join ENCOUNTER_GRP readm on (idx.grp_mpi = readm.grp_mpi)
where idx.encounter_grp_type = 'CH000106'
and readm.encounter_grp_type = 'CH000106'
and date_trunc('dd', readm.admittime) > date_trunc('dd', idx.dischargetime)
and idx.prindx is not null
and substr(idx.prindx,1,3) =  substr(readm.prindx,1,3)
and idx.baseinclude = 'Y'
and readm.clientplanned = 'N'
and (readm.drg is null or readm.drg not in ('945','946'))
and substr(readm.prindx,1,3) not in ('V52','V53','V54','V57')
and not exists (select 1 from TEMP_ENCOUNTER_GRP_CCS ccs
                where readm.ENCOUNTER_GRP_NUM = ccs.ENCOUNTER_GRP_NUM
                and ccs_cat = '254')
)
where rrank = 1
     */
    val result = tempEncounterGrpBaseRel.as("rel")
      .join(tempEncounterGrpCCS.where($"ccs_cat" === lit("254")).as("ccs"), $"rel.readmEncounterGrpNum" === $"ccs.ENCOUNTER_GRP_NUM", "leftouter")
      .where(
        $"rel.idxEncounterGrpType" === lit("CH000106") &&
          $"rel.readmEncounterGrpType" === lit("CH000106") &&
          $"rel.idxPrinDx".isNotNull && substring($"rel.idxPrinDx", 1, 3) === substring($"rel.readmPrinDx", 1, 3) &&
          $"rel.idxBaseInclude" === lit("Y") &&
          $"rel.readmClientPlanned" === lit("N") &&
          ($"rel.readmDrg".isNull || !$"rel.readmDrg".isin("945", "946")) &&
          !substring($"rel.readmPrinDx", 1, 3).isin("V52", "V53", "V54", "V57") && $"ccs.ccs_cat".isNull)
      .select(
        $"rel.idxGroupId".as("GROUPID"),
        $"rel.idxEncounterGrpNum".as("ENCOUNTER_GRP_NUM"),
        lit("CH001651").as("ENCOUNTER_GRP_REL_TYPE"),
        $"rel.readmEncounterGrpNum".as("REL_ENCOUNTER_GRP_NUM"),
        row_number().over(Window.partitionBy($"rel.idxEncounterGrpNum")
          .orderBy($"rel.idxEncounterGrpNum", datediff(to_date($"rel.readmAdmitTime"), to_date($"rel.idxDischargeTime")), $"rel.readmEncounterGrpNum")).as("rrank")
      )
      .where($"rrank" === lit(1))
      .select(
        $"GROUPID",
        $"ENCOUNTER_GRP_NUM",
        $"ENCOUNTER_GRP_REL_TYPE",
        $"REL_ENCOUNTER_GRP_NUM"
      ).as[encounter_grp_rel]

    result.toDF()
  }
}

// Maps to TEMP_ENCOUNTER_GRP_REL9
object TEMP_ENCOUNTER_GRP_REL_CCS_CH001657 extends TableInfo[encounter_grp_rel] {

  override def name: String = "TEMP_ENCOUNTER_GRP_REL_CCS_CH001657"

  override def dependsOn: Set[String] = Set("TEMP_ENCOUNTER_GRP_CCS", "ENCOUNTER_GRP_REL_BASE")

  override protected def createDataFrame(sparkSession: SparkSession,
                                         loadedDependencies: Map[String, DataFrame],
                                         udfMap: Map[String, UserDefinedFunctionForDataLoader],
                                         runtimeVariables: RuntimeVariables): DataFrame = {
    import org.apache.spark.sql.functions._
    import sparkSession.implicits._

    val tempEncounterGrpBaseRel = loadedDependencies("ENCOUNTER_GRP_REL_BASE").as[temp_encounter_grp_rel_base]
    val tempEncounterGrpCCS = loadedDependencies("TEMP_ENCOUNTER_GRP_CCS").as[temp_encounter_grp_ccs]

    /*
    select GROUPID,ENCOUNTER_GRP_NUM,ENCOUNTER_GRP_REL_TYPE,REL_ENCOUNTER_GRP_NUM
from
(select idx.groupid, idx.ENCOUNTER_GRP_NUM, 'CH001657' as ENCOUNTER_GRP_REL_TYPE  --SDS to IP base any dx
  , readm.ENCOUNTER_GRP_NUM as REL_ENCOUNTER_GRP_NUM
  , row_number() over (partition by idx.ENCOUNTER_GRP_NUM
                 order by idx.ENCOUNTER_GRP_NUM,datediff(date_trunc('dd', readm.admittime), date_trunc('dd', idx.dischargetime)), readm.ENCOUNTER_GRP_NUM) as rrank
from ENCOUNTER_GRP idx
inner join ENCOUNTER_GRP readm on (idx.grp_mpi = readm.grp_mpi)
where idx.encounter_grp_type = 'CH000113'
and readm.encounter_grp_type = 'CH000106'
and date_trunc('dd', readm.admittime) > date_trunc('dd', idx.dischargetime)
and idx.baseinclude = 'Y'
and (readm.drg is null or readm.drg not in ('945','946'))
and (readm.prindx is null or substr(readm.prindx,1,3) not in ('V52','V53','V54','V57'))
and not exists (select 1 from TEMP_ENCOUNTER_GRP_CCS ccs
                where readm.ENCOUNTER_GRP_NUM = ccs.ENCOUNTER_GRP_NUM
                and ccs_cat = '254')
)
where rrank = 1
     */
    val result = tempEncounterGrpBaseRel.as("rel")
      .join(tempEncounterGrpCCS.where($"ccs_cat" === lit("254")).as("ccs"), $"rel.readmEncounterGrpNum" === $"ccs.ENCOUNTER_GRP_NUM", "leftouter")
      .where(
        $"rel.idxEncounterGrpType" === lit("CH000113") &&
          $"rel.readmEncounterGrpType" === lit("CH000106") &&
          $"rel.idxBaseInclude" === lit("Y") &&
          ($"rel.readmDrg".isNull || !$"rel.readmDrg".isin("945", "946")) &&
          ($"rel.readmPrinDx".isNull || !substring($"rel.readmPrinDx", 1, 3).isin("V52", "V53", "V54", "V57")) && $"ccs.ccs_cat".isNull)
      .select(
        $"rel.idxGroupId".as("GROUPID"),
        $"rel.idxEncounterGrpNum".as("ENCOUNTER_GRP_NUM"),
        lit("CH001657").as("ENCOUNTER_GRP_REL_TYPE"),
        $"rel.readmEncounterGrpNum".as("REL_ENCOUNTER_GRP_NUM"),
        row_number().over(Window.partitionBy($"rel.idxEncounterGrpNum")
          .orderBy($"rel.idxEncounterGrpNum", datediff(to_date($"rel.readmAdmitTime"), to_date($"rel.idxDischargeTime")), $"rel.readmEncounterGrpNum")).as("rrank")
      )
      .where($"rrank" === lit(1))
      .select(
        $"GROUPID",
        $"ENCOUNTER_GRP_NUM",
        $"ENCOUNTER_GRP_REL_TYPE",
        $"REL_ENCOUNTER_GRP_NUM"
      ).as[encounter_grp_rel]

    result.toDF()
  }
}

// Maps to TEMP_ENCOUNTER_GRP_REL10
object TEMP_ENCOUNTER_GRP_REL_CCS_CH001658 extends TableInfo[encounter_grp_rel] {

  override def name: String = "TEMP_ENCOUNTER_GRP_REL_CCS_CH001658"

  override def dependsOn: Set[String] = Set("TEMP_ENCOUNTER_GRP_CCS", "ENCOUNTER_GRP_REL_BASE")

  override protected def createDataFrame(sparkSession: SparkSession,
                                         loadedDependencies: Map[String, DataFrame],
                                         udfMap: Map[String, UserDefinedFunctionForDataLoader],
                                         runtimeVariables: RuntimeVariables): DataFrame = {
    import org.apache.spark.sql.functions._
    import sparkSession.implicits._

    val tempEncounterGrpBaseRel = loadedDependencies("ENCOUNTER_GRP_REL_BASE").as[temp_encounter_grp_rel_base]
    val tempEncounterGrpCCS = loadedDependencies("TEMP_ENCOUNTER_GRP_CCS").as[temp_encounter_grp_ccs]

    /*
    select GROUPID,ENCOUNTER_GRP_NUM,ENCOUNTER_GRP_REL_TYPE,REL_ENCOUNTER_GRP_NUM
from
(select idx.groupid, idx.ENCOUNTER_GRP_NUM, 'CH001658' as ENCOUNTER_GRP_REL_TYPE  --SDS to IP base same prindx3
  , readm.ENCOUNTER_GRP_NUM as REL_ENCOUNTER_GRP_NUM
  , row_number() over (partition by idx.ENCOUNTER_GRP_NUM
                 order by idx.ENCOUNTER_GRP_NUM,datediff(date_trunc('dd', readm.admittime), date_trunc('dd', idx.dischargetime)), readm.ENCOUNTER_GRP_NUM) as rrank
from ENCOUNTER_GRP idx
inner join ENCOUNTER_GRP readm on (idx.grp_mpi = readm.grp_mpi)
where idx.encounter_grp_type = 'CH000113'
and readm.encounter_grp_type = 'CH000106'
and date_trunc('dd', readm.admittime) > date_trunc('dd', idx.dischargetime)
and idx.prindx is not null
and substr(idx.prindx,1,3) =  substr(readm.prindx,1,3)
and idx.baseinclude = 'Y'
and (readm.drg is null or readm.drg not in ('945','946'))
and (readm.prindx is null or substr(readm.prindx,1,3) not in ('V52','V53','V54','V57'))
and not exists (select 1 from TEMP_ENCOUNTER_GRP_CCS ccs
                where readm.ENCOUNTER_GRP_NUM = ccs.ENCOUNTER_GRP_NUM
                and ccs_cat = '254')
)
where rrank = 1
     */
    val result = tempEncounterGrpBaseRel.as("rel")
      .join(tempEncounterGrpCCS.where($"ccs_cat" === lit("254")).as("ccs"), $"rel.readmEncounterGrpNum" === $"ccs.ENCOUNTER_GRP_NUM", "leftouter")
      .where(
        $"rel.idxEncounterGrpType" === lit("CH000113") &&
          $"rel.readmEncounterGrpType" === lit("CH000106") &&
          $"rel.idxPrinDx".isNotNull && substring($"rel.idxPrinDx", 1, 3) === substring($"rel.readmPrinDx", 1, 3) &&
          $"rel.idxBaseInclude" === lit("Y") &&
          ($"rel.readmDrg".isNull || !$"rel.readmDrg".isin("945", "946")) &&
          ($"rel.readmPrinDx".isNull || !substring($"rel.readmPrinDx", 1, 3).isin("V52", "V53", "V54", "V57")) && $"ccs.ccs_cat".isNull)
      .select(
        $"rel.idxGroupId".as("GROUPID"),
        $"rel.idxEncounterGrpNum".as("ENCOUNTER_GRP_NUM"),
        lit("CH001658").as("ENCOUNTER_GRP_REL_TYPE"),
        $"rel.readmEncounterGrpNum".as("REL_ENCOUNTER_GRP_NUM"),
        row_number().over(Window.partitionBy($"rel.idxEncounterGrpNum")
          .orderBy($"rel.idxEncounterGrpNum", datediff(to_date($"rel.readmAdmitTime"), to_date($"rel.idxDischargeTime")), $"rel.readmEncounterGrpNum")).as("rrank")
      )
      .where($"rrank" === lit(1))
      .select(
        $"GROUPID",
        $"ENCOUNTER_GRP_NUM",
        $"ENCOUNTER_GRP_REL_TYPE",
        $"REL_ENCOUNTER_GRP_NUM"
      ).as[encounter_grp_rel]

    result.toDF()
  }
}

// Maps to TEMP_ENCOUNTER_GRP_REL13
object TEMP_ENCOUNTER_GRP_REL_CCS_CH002594 extends TableInfo[encounter_grp_rel] {

  override def name: String = "TEMP_ENCOUNTER_GRP_REL_CCS_CH002594"

  override def dependsOn: Set[String] = Set("TEMP_ENCOUNTER_GRP_CCS", "ENCOUNTER_GRP_REL_BASE")

  override protected def createDataFrame(sparkSession: SparkSession,
                                         loadedDependencies: Map[String, DataFrame],
                                         udfMap: Map[String, UserDefinedFunctionForDataLoader],
                                         runtimeVariables: RuntimeVariables): DataFrame = {
    import org.apache.spark.sql.functions._
    import sparkSession.implicits._

    val tempEncounterGrpBaseRel = loadedDependencies("ENCOUNTER_GRP_REL_BASE").as[temp_encounter_grp_rel_base]
    val tempEncounterGrpCCS = loadedDependencies("TEMP_ENCOUNTER_GRP_CCS").as[temp_encounter_grp_ccs]

    /*
    select GROUPID,ENCOUNTER_GRP_NUM,ENCOUNTER_GRP_REL_TYPE,REL_ENCOUNTER_GRP_NUM
from
(select idx.groupid, idx.ENCOUNTER_GRP_NUM, 'CH002594' as ENCOUNTER_GRP_REL_TYPE  --IP to IP base readmission (same MDC)
  , readm.ENCOUNTER_GRP_NUM as REL_ENCOUNTER_GRP_NUM
  , row_number() over (partition by idx.ENCOUNTER_GRP_NUM
                 order by idx.ENCOUNTER_GRP_NUM,datediff(date_trunc('dd', readm.admittime), date_trunc('dd', idx.dischargetime)), readm.ENCOUNTER_GRP_NUM) as rrank
from ENCOUNTER_GRP idx
inner join ENCOUNTER_GRP readm on (idx.grp_mpi = readm.grp_mpi)
where idx.encounter_grp_type = 'CH000106'
and readm.encounter_grp_type = 'CH000106'
and date_trunc('dd', readm.admittime) > date_trunc('dd', idx.dischargetime)
and idx.baseinclude = 'Y'
and idx.MDC is not null
and idx.MDC =  readm.MDC
and (readm.drg is null or readm.drg not in ('945','946'))
and (readm.prindx is null or substr(readm.prindx,1,3) not in ('V52','V53','V54','V57'))
and not exists (select 1 from TEMP_ENCOUNTER_GRP_CCS ccs
                where readm.ENCOUNTER_GRP_NUM = ccs.ENCOUNTER_GRP_NUM
                and ccs_cat = '254')
)
where rrank = 1
     */
    val result = tempEncounterGrpBaseRel.as("rel")
      .join(tempEncounterGrpCCS.where($"ccs_cat" === lit("254")).as("ccs"), $"rel.readmEncounterGrpNum" === $"ccs.ENCOUNTER_GRP_NUM", "leftouter")
      .where(
        $"rel.idxEncounterGrpType" === lit("CH000106") &&
          $"rel.readmEncounterGrpType" === lit("CH000106") &&
          $"rel.idxBaseInclude" === lit("Y") && $"rel.idxMDC".isNotNull && $"rel.idxMDC" === $"rel.readmMDC" &&
          ($"rel.readmDrg".isNull || !$"rel.readmDrg".isin("945", "946")) &&
          ($"rel.readmPrinDx".isNull || !substring($"rel.readmPrinDx", 1, 3).isin("V52", "V53", "V54", "V57")) && $"ccs.ccs_cat".isNull)
      .select(
        $"rel.idxGroupId".as("GROUPID"),
        $"rel.idxEncounterGrpNum".as("ENCOUNTER_GRP_NUM"),
        lit("CH002594").as("ENCOUNTER_GRP_REL_TYPE"),
        $"rel.readmEncounterGrpNum".as("REL_ENCOUNTER_GRP_NUM"),
        row_number().over(Window.partitionBy($"rel.idxEncounterGrpNum")
          .orderBy($"rel.idxEncounterGrpNum", datediff(to_date($"rel.readmAdmitTime"), to_date($"rel.idxDischargeTime")), $"rel.readmEncounterGrpNum")).as("rrank")
      )
      .where($"rrank" === lit(1))
      .select(
        $"GROUPID",
        $"ENCOUNTER_GRP_NUM",
        $"ENCOUNTER_GRP_REL_TYPE",
        $"REL_ENCOUNTER_GRP_NUM"
      ).as[encounter_grp_rel]

    result.toDF()
  }
}

// Maps to TEMP_ENCOUNTER_GRP_REL14
object TEMP_ENCOUNTER_GRP_REL_CCS_CH002595 extends TableInfo[encounter_grp_rel] {

  override def name: String = "TEMP_ENCOUNTER_GRP_REL_CCS_CH002595"

  override def dependsOn: Set[String] = Set("TEMP_ENCOUNTER_GRP_CCS", "ENCOUNTER_GRP_REL_BASE")

  override protected def createDataFrame(sparkSession: SparkSession,
                                         loadedDependencies: Map[String, DataFrame],
                                         udfMap: Map[String, UserDefinedFunctionForDataLoader],
                                         runtimeVariables: RuntimeVariables): DataFrame = {
    import org.apache.spark.sql.functions._
    import sparkSession.implicits._

    val tempEncounterGrpBaseRel = loadedDependencies("ENCOUNTER_GRP_REL_BASE").as[temp_encounter_grp_rel_base]
    val tempEncounterGrpCCS = loadedDependencies("TEMP_ENCOUNTER_GRP_CCS").as[temp_encounter_grp_ccs]

    /*
    select GROUPID,ENCOUNTER_GRP_NUM,ENCOUNTER_GRP_REL_TYPE,REL_ENCOUNTER_GRP_NUM
from
(select idx.groupid, idx.ENCOUNTER_GRP_NUM, 'CH002595' as ENCOUNTER_GRP_REL_TYPE   --IP to IP CMS readmission (same MDC)
  , readm.ENCOUNTER_GRP_NUM as REL_ENCOUNTER_GRP_NUM
  , row_number() over (partition by idx.ENCOUNTER_GRP_NUM
                 order by idx.ENCOUNTER_GRP_NUM,datediff(date_trunc('dd', readm.admittime), date_trunc('dd', idx.dischargetime)), readm.ENCOUNTER_GRP_NUM) as rrank
from ENCOUNTER_GRP idx
inner join ENCOUNTER_GRP readm on (idx.grp_mpi = readm.grp_mpi)
where idx.encounter_grp_type = 'CH000106'
and readm.encounter_grp_type = 'CH000106'
and date_trunc('dd', readm.admittime) > date_trunc('dd', idx.dischargetime)
and idx.cmsinclude = 'Y'
and readm.cmsplanned = 'N'
and idx.MDC is not null
and idx.MDC =  readm.MDC
and (readm.drg is null or readm.drg not in ('945','946'))
and (readm.prindx is null or substr(readm.prindx,1,3) not in ('V52','V53','V54','V57'))
and not exists (select 1 from TEMP_ENCOUNTER_GRP_CCS ccs
                where readm.ENCOUNTER_GRP_NUM = ccs.ENCOUNTER_GRP_NUM
                and ccs_cat = '254')
)
where rrank = 1
     */
    val result = tempEncounterGrpBaseRel.as("rel")
      .join(tempEncounterGrpCCS.where($"ccs_cat" === lit("254")).as("ccs"), $"rel.readmEncounterGrpNum" === $"ccs.ENCOUNTER_GRP_NUM", "leftouter")
      .where(
        $"rel.idxEncounterGrpType" === lit("CH000106") &&
          $"rel.readmEncounterGrpType" === lit("CH000106") &&
          $"rel.idxCMSInclude" === lit("Y") &&  $"rel.readmCMSPlanned" === lit("N") && $"rel.idxMDC".isNotNull && $"rel.idxMDC" === $"rel.readmMDC" &&
          ($"rel.readmDrg".isNull || !$"rel.readmDrg".isin("945", "946")) &&
          ($"rel.readmPrinDx".isNull || !substring($"rel.readmPrinDx", 1, 3).isin("V52", "V53", "V54", "V57")) && $"ccs.ccs_cat".isNull)
      .select(
        $"rel.idxGroupId".as("GROUPID"),
        $"rel.idxEncounterGrpNum".as("ENCOUNTER_GRP_NUM"),
        lit("CH002595").as("ENCOUNTER_GRP_REL_TYPE"),
        $"rel.readmEncounterGrpNum".as("REL_ENCOUNTER_GRP_NUM"),
        row_number().over(Window.partitionBy($"rel.idxEncounterGrpNum")
          .orderBy($"rel.idxEncounterGrpNum", datediff(to_date($"rel.readmAdmitTime"), to_date($"rel.idxDischargeTime")), $"rel.readmEncounterGrpNum")).as("rrank")
      )
      .where($"rrank" === lit(1))
      .select(
        $"GROUPID",
        $"ENCOUNTER_GRP_NUM",
        $"ENCOUNTER_GRP_REL_TYPE",
        $"REL_ENCOUNTER_GRP_NUM"
      ).as[encounter_grp_rel]

    result.toDF()
  }
}

// Maps to TEMP_ENCOUNTER_GRP_REL15
object TEMP_ENCOUNTER_GRP_REL_CCS_CH002596 extends TableInfo[encounter_grp_rel] {

  override def name: String = "TEMP_ENCOUNTER_GRP_REL_CCS_CH002596"

  override def dependsOn: Set[String] = Set("TEMP_ENCOUNTER_GRP_CCS", "ENCOUNTER_GRP_REL_BASE")

  override protected def createDataFrame(sparkSession: SparkSession,
                                         loadedDependencies: Map[String, DataFrame],
                                         udfMap: Map[String, UserDefinedFunctionForDataLoader],
                                         runtimeVariables: RuntimeVariables): DataFrame = {
    import org.apache.spark.sql.functions._
    import sparkSession.implicits._

    val tempEncounterGrpBaseRel = loadedDependencies("ENCOUNTER_GRP_REL_BASE").as[temp_encounter_grp_rel_base]
    val tempEncounterGrpCCS = loadedDependencies("TEMP_ENCOUNTER_GRP_CCS").as[temp_encounter_grp_ccs]

    /*
    select GROUPID,ENCOUNTER_GRP_NUM,ENCOUNTER_GRP_REL_TYPE,REL_ENCOUNTER_GRP_NUM
from
(select idx.groupid, idx.ENCOUNTER_GRP_NUM, 'CH002596' as ENCOUNTER_GRP_REL_TYPE   --IP to IP base readmission (same DRG)
  , readm.ENCOUNTER_GRP_NUM as REL_ENCOUNTER_GRP_NUM
  , row_number() over (partition by idx.ENCOUNTER_GRP_NUM
                 order by idx.ENCOUNTER_GRP_NUM,datediff(date_trunc('dd', readm.admittime), date_trunc('dd', idx.dischargetime)), readm.ENCOUNTER_GRP_NUM) as rrank
from ENCOUNTER_GRP idx
inner join ENCOUNTER_GRP readm on (idx.grp_mpi = readm.grp_mpi)
where idx.encounter_grp_type = 'CH000106'
and readm.encounter_grp_type = 'CH000106'
and date_trunc('dd', readm.admittime) > date_trunc('dd', idx.dischargetime)
and idx.baseinclude = 'Y'
and idx.DRG is not null
and idx.DRG =  readm.DRG
and (readm.drg is null or readm.drg not in ('945','946'))
and (readm.prindx is null or substr(readm.prindx,1,3) not in ('V52','V53','V54','V57'))
and not exists (select 1 from TEMP_ENCOUNTER_GRP_CCS ccs
                where readm.ENCOUNTER_GRP_NUM = ccs.ENCOUNTER_GRP_NUM
                and ccs_cat = '254')
)
where rrank = 1
     */
    val result = tempEncounterGrpBaseRel.as("rel")
      .join(tempEncounterGrpCCS.where($"ccs_cat" === lit("254")).as("ccs"), $"rel.readmEncounterGrpNum" === $"ccs.ENCOUNTER_GRP_NUM", "leftouter")
      .where(
        $"rel.idxEncounterGrpType" === lit("CH000106") &&
          $"rel.readmEncounterGrpType" === lit("CH000106") &&
          $"rel.idxBaseInclude" === lit("Y") && $"rel.idxDRG".isNotNull && $"rel.idxDRG" === $"rel.readmDRG" &&
          ($"rel.readmDrg".isNull || !$"rel.readmDrg".isin("945", "946")) &&
          ($"rel.readmPrinDx".isNull || !substring($"rel.readmPrinDx", 1, 3).isin("V52", "V53", "V54", "V57")) && $"ccs.ccs_cat".isNull)
      .select(
        $"rel.idxGroupId".as("GROUPID"),
        $"rel.idxEncounterGrpNum".as("ENCOUNTER_GRP_NUM"),
        lit("CH002596").as("ENCOUNTER_GRP_REL_TYPE"),
        $"rel.readmEncounterGrpNum".as("REL_ENCOUNTER_GRP_NUM"),
        row_number().over(Window.partitionBy($"rel.idxEncounterGrpNum")
          .orderBy($"rel.idxEncounterGrpNum", datediff(to_date($"rel.readmAdmitTime"), to_date($"rel.idxDischargeTime")), $"rel.readmEncounterGrpNum")).as("rrank")
      )
      .where($"rrank" === lit(1))
      .select(
        $"GROUPID",
        $"ENCOUNTER_GRP_NUM",
        $"ENCOUNTER_GRP_REL_TYPE",
        $"REL_ENCOUNTER_GRP_NUM"
      ).as[encounter_grp_rel]

    result.toDF()
  }
}

// Maps to TEMP_ENCOUNTER_GRP_REL16
object TEMP_ENCOUNTER_GRP_REL_CCS_CH002597 extends TableInfo[encounter_grp_rel] {

  override def name: String = "TEMP_ENCOUNTER_GRP_REL_CCS_CH002597"

  override def dependsOn: Set[String] = Set("TEMP_ENCOUNTER_GRP_CCS", "ENCOUNTER_GRP_REL_BASE")

  override protected def createDataFrame(sparkSession: SparkSession,
                                         loadedDependencies: Map[String, DataFrame],
                                         udfMap: Map[String, UserDefinedFunctionForDataLoader],
                                         runtimeVariables: RuntimeVariables): DataFrame = {
    import org.apache.spark.sql.functions._
    import sparkSession.implicits._

    val tempEncounterGrpBaseRel = loadedDependencies("ENCOUNTER_GRP_REL_BASE").as[temp_encounter_grp_rel_base]
    val tempEncounterGrpCCS = loadedDependencies("TEMP_ENCOUNTER_GRP_CCS").as[temp_encounter_grp_ccs]

    /*
    select GROUPID,ENCOUNTER_GRP_NUM,ENCOUNTER_GRP_REL_TYPE,REL_ENCOUNTER_GRP_NUM
from
(select idx.groupid, idx.ENCOUNTER_GRP_NUM, 'CH002597' as ENCOUNTER_GRP_REL_TYPE   ---IP to IP CMS readmission (same DRG)
  , readm.ENCOUNTER_GRP_NUM as REL_ENCOUNTER_GRP_NUM
  , row_number() over (partition by idx.ENCOUNTER_GRP_NUM
                 order by idx.ENCOUNTER_GRP_NUM,datediff(date_trunc('dd', readm.admittime), date_trunc('dd', idx.dischargetime)), readm.ENCOUNTER_GRP_NUM) as rrank
from ENCOUNTER_GRP idx
inner join ENCOUNTER_GRP readm on (idx.grp_mpi = readm.grp_mpi)
where idx.encounter_grp_type = 'CH000106'
and readm.encounter_grp_type = 'CH000106'
and date_trunc('dd', readm.admittime) > date_trunc('dd', idx.dischargetime)
and idx.cmsinclude = 'Y'
and readm.cmsplanned = 'N'
and idx.DRG is not null
and idx.DRG =  readm.DRG
and (readm.drg is null or readm.drg not in ('945','946'))
and (readm.prindx is null or substr(readm.prindx,1,3) not in ('V52','V53','V54','V57'))
and not exists (select 1 from TEMP_ENCOUNTER_GRP_CCS ccs
                where readm.ENCOUNTER_GRP_NUM = ccs.ENCOUNTER_GRP_NUM
                and ccs_cat = '254')
)
where rrank = 1
     */

    val result = tempEncounterGrpBaseRel.as("rel")
      .join(tempEncounterGrpCCS.where($"ccs_cat" === lit("254")).as("ccs"), $"rel.readmEncounterGrpNum" === $"ccs.ENCOUNTER_GRP_NUM", "leftouter")
      .where(
        $"rel.idxEncounterGrpType" === lit("CH000106") &&
          $"rel.readmEncounterGrpType" === lit("CH000106") &&
          $"rel.idxCMSInclude" === lit("Y") && $"rel.readmCMSPlanned" === lit("N") && $"rel.idxDRG".isNotNull && ($"rel.idxDRG" === $"rel.readmDRG") &&
          ($"rel.readmDrg".isNull || !$"rel.readmDrg".isin("945", "946")) &&
          ($"rel.readmPrinDx".isNull || !substring($"rel.readmPrinDx", 1, 3).isin("V52", "V53", "V54", "V57")) && $"ccs.ccs_cat".isNull)
      .select(
        $"rel.idxGroupId".as("GROUPID"),
        $"rel.idxEncounterGrpNum".as("ENCOUNTER_GRP_NUM"),
        lit("CH002597").as("ENCOUNTER_GRP_REL_TYPE"),
        $"rel.readmEncounterGrpNum".as("REL_ENCOUNTER_GRP_NUM"),
        row_number().over(Window.partitionBy($"rel.idxEncounterGrpNum")
          .orderBy($"rel.idxEncounterGrpNum", datediff(to_date($"rel.readmAdmitTime"), to_date($"rel.idxDischargeTime")), $"rel.readmEncounterGrpNum")).as("rrank")
      )
      .where($"rrank" === lit(1))
      .select(
        $"GROUPID",
        $"ENCOUNTER_GRP_NUM",
        $"ENCOUNTER_GRP_REL_TYPE",
        $"REL_ENCOUNTER_GRP_NUM"
      ).as[encounter_grp_rel]

    result.toDF()
  }
}

// Maps to TEMP_ENCOUNTER_GRP_REL17
object TEMP_ENCOUNTER_GRP_REL_CCS_CH002598 extends TableInfo[encounter_grp_rel] {

  override def name: String = "TEMP_ENCOUNTER_GRP_REL_CCS_CH002598"

  override def dependsOn: Set[String] = Set("TEMP_ENCOUNTER_GRP_CCS", "ENCOUNTER_GRP_REL_BASE")

  override protected def createDataFrame(sparkSession: SparkSession,
                                         loadedDependencies: Map[String, DataFrame],
                                         udfMap: Map[String, UserDefinedFunctionForDataLoader],
                                         runtimeVariables: RuntimeVariables): DataFrame = {
    import org.apache.spark.sql.functions._
    import sparkSession.implicits._

    val tempEncounterGrpBaseRel = loadedDependencies("ENCOUNTER_GRP_REL_BASE").as[temp_encounter_grp_rel_base]
    val tempEncounterGrpCCS = loadedDependencies("TEMP_ENCOUNTER_GRP_CCS").as[temp_encounter_grp_ccs]

    /*
    select GROUPID,ENCOUNTER_GRP_NUM,ENCOUNTER_GRP_REL_TYPE,REL_ENCOUNTER_GRP_NUM
from
(select idx.groupid, idx.ENCOUNTER_GRP_NUM, 'CH002598' as ENCOUNTER_GRP_REL_TYPE   --IP to IP base readmission (same APR-DRG)
  , readm.ENCOUNTER_GRP_NUM as REL_ENCOUNTER_GRP_NUM
  , row_number() over (partition by idx.ENCOUNTER_GRP_NUM
                 order by idx.ENCOUNTER_GRP_NUM,datediff(date_trunc('dd', readm.admittime), date_trunc('dd', idx.dischargetime)), readm.ENCOUNTER_GRP_NUM) as rrank
from ENCOUNTER_GRP idx
inner join ENCOUNTER_GRP readm on (idx.grp_mpi = readm.grp_mpi)
where idx.encounter_grp_type = 'CH000106'
and readm.encounter_grp_type = 'CH000106'
and date_trunc('dd', readm.admittime) > date_trunc('dd', idx.dischargetime)
and idx.baseinclude = 'Y'
and idx.aprDRG is not null
and idx.aprDRG =  readm.aprDRG
and (readm.drg is null or readm.drg not in ('945','946'))
and (readm.prindx is null or substr(readm.prindx,1,3) not in ('V52','V53','V54','V57'))
and not exists (select 1 from TEMP_ENCOUNTER_GRP_CCS ccs
                where readm.ENCOUNTER_GRP_NUM = ccs.ENCOUNTER_GRP_NUM
                and ccs_cat = '254')
)
where rrank = 1
     */
    val result = tempEncounterGrpBaseRel.as("rel")
      .join(tempEncounterGrpCCS.where($"ccs_cat" === lit("254")).as("ccs"), $"rel.readmEncounterGrpNum" === $"ccs.ENCOUNTER_GRP_NUM", "leftouter")
      .where(
        $"rel.idxEncounterGrpType" === lit("CH000106") &&
          $"rel.readmEncounterGrpType" === lit("CH000106") &&
          $"rel.idxBaseInclude" === lit("Y") && $"rel.idxAPRDRG".isNotNull && $"rel.idxAPRDRG" === $"rel.readmAPRDRG" &&
          ($"rel.readmDrg".isNull || !$"rel.readmDrg".isin("945", "946")) &&
          ($"rel.readmPrinDx".isNull || !substring($"rel.readmPrinDx", 1, 3).isin("V52", "V53", "V54", "V57")) && $"ccs.ccs_cat".isNull)
      .select(
        $"rel.idxGroupId".as("GROUPID"),
        $"rel.idxEncounterGrpNum".as("ENCOUNTER_GRP_NUM"),
        lit("CH002598").as("ENCOUNTER_GRP_REL_TYPE"),
        $"rel.readmEncounterGrpNum".as("REL_ENCOUNTER_GRP_NUM"),
        row_number().over(Window.partitionBy($"rel.idxEncounterGrpNum")
          .orderBy($"rel.idxEncounterGrpNum", datediff(to_date($"rel.readmAdmitTime"), to_date($"rel.idxDischargeTime")), $"rel.readmEncounterGrpNum")).as("rrank")
      )
      .where($"rrank" === lit(1))
      .select(
        $"GROUPID",
        $"ENCOUNTER_GRP_NUM",
        $"ENCOUNTER_GRP_REL_TYPE",
        $"REL_ENCOUNTER_GRP_NUM"
      ).as[encounter_grp_rel]

    result.toDF()
  }
}

// Maps to TEMP_ENCOUNTER_GRP_REL18
object TEMP_ENCOUNTER_GRP_REL_CCS_CH002599 extends TableInfo[encounter_grp_rel] {

  override def name: String = "TEMP_ENCOUNTER_GRP_REL_CCS_CH002599"

  override def dependsOn: Set[String] = Set("TEMP_ENCOUNTER_GRP_CCS", "ENCOUNTER_GRP_REL_BASE")

  override protected def createDataFrame(sparkSession: SparkSession,
                                         loadedDependencies: Map[String, DataFrame],
                                         udfMap: Map[String, UserDefinedFunctionForDataLoader],
                                         runtimeVariables: RuntimeVariables): DataFrame = {
    import org.apache.spark.sql.functions._
    import sparkSession.implicits._

    val tempEncounterGrpBaseRel = loadedDependencies("ENCOUNTER_GRP_REL_BASE").as[temp_encounter_grp_rel_base]
    val tempEncounterGrpCCS = loadedDependencies("TEMP_ENCOUNTER_GRP_CCS").as[temp_encounter_grp_ccs]

    /*
    select GROUPID,ENCOUNTER_GRP_NUM,ENCOUNTER_GRP_REL_TYPE,REL_ENCOUNTER_GRP_NUM
from
(select idx.groupid, idx.ENCOUNTER_GRP_NUM, 'CH002599' as ENCOUNTER_GRP_REL_TYPE   --ED-IP base readmission (any dx)
  , readm.ENCOUNTER_GRP_NUM as REL_ENCOUNTER_GRP_NUM
  , row_number() over (partition by idx.ENCOUNTER_GRP_NUM
                 order by idx.ENCOUNTER_GRP_NUM,datediff(date_trunc('dd', readm.admittime), date_trunc('dd', idx.dischargetime)), readm.ENCOUNTER_GRP_NUM) as rrank
from ENCOUNTER_GRP idx
inner join ENCOUNTER_GRP readm on (idx.grp_mpi = readm.grp_mpi)
where idx.encounter_grp_type = 'CH000109'
and readm.encounter_grp_type = 'CH000106'
and date_trunc('dd', readm.admittime) > date_trunc('dd', idx.dischargetime)
and idx.baseinclude = 'Y'
and (readm.drg is null or readm.drg not in ('945','946'))
and (readm.prindx is null or substr(readm.prindx,1,3) not in ('V52','V53','V54','V57'))
and not exists (select 1 from TEMP_ENCOUNTER_GRP_CCS ccs
                where readm.ENCOUNTER_GRP_NUM = ccs.ENCOUNTER_GRP_NUM
                and ccs_cat = '254')
)
where rrank = 1
     */
    val result = tempEncounterGrpBaseRel.as("rel")
      .join(tempEncounterGrpCCS.where($"ccs_cat" === lit("254")).as("ccs"), $"rel.readmEncounterGrpNum" === $"ccs.ENCOUNTER_GRP_NUM", "leftouter")
      .where(
        $"rel.idxEncounterGrpType" === lit("CH000109") &&
          $"rel.readmEncounterGrpType" === lit("CH000106") &&
          $"rel.idxBaseInclude" === lit("Y") &&
          ($"rel.readmDrg".isNull || !$"rel.readmDrg".isin("945", "946")) &&
          ($"rel.readmPrinDx".isNull || !substring($"rel.readmPrinDx", 1, 3).isin("V52", "V53", "V54", "V57")) && $"ccs.ccs_cat".isNull)
      .select(
        $"rel.idxGroupId".as("GROUPID"),
        $"rel.idxEncounterGrpNum".as("ENCOUNTER_GRP_NUM"),
        lit("CH002599").as("ENCOUNTER_GRP_REL_TYPE"),
        $"rel.readmEncounterGrpNum".as("REL_ENCOUNTER_GRP_NUM"),
        row_number().over(Window.partitionBy($"rel.idxEncounterGrpNum")
          .orderBy($"rel.idxEncounterGrpNum", datediff(to_date($"rel.readmAdmitTime"), to_date($"rel.idxDischargeTime")), $"rel.readmEncounterGrpNum")).as("rrank")
      )
      .where($"rrank" === lit(1))
      .select(
        $"GROUPID",
        $"ENCOUNTER_GRP_NUM",
        $"ENCOUNTER_GRP_REL_TYPE",
        $"REL_ENCOUNTER_GRP_NUM"
      ).as[encounter_grp_rel]

    result.toDF()
  }
}