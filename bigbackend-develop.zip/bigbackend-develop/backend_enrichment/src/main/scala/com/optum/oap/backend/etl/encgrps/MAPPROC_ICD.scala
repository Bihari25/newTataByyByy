
package com.optum.oap.backend.etl.encgrps

import com.optum.oap.cdr.models.mapproc_icd
import com.optum.oap.sparkdataloader.QueryAndMetadata

object MAPPROC_ICD extends QueryAndMetadata[mapproc_icd] {
  override def name: String = "MAPPROC_ICD"

  override def sparkSql: String =
    """
      |select px.codetype,px.mappedcode
      |       ,CUI, is_ambulatory
      |       ,cnt
      |from (
      |select  codetype
      |       , mappedcode
      |       , CAST(count(*) as INT) as cnt
      |from TEMP_ENCOUNTER_PRINPX
      |where 1=1
      |group by codetype, mappedcode
      |) px
      |inner join MAP_PROCEDURE mp on (px.codetype = mp.codetype AND px.mappedcode = mp.mappedcode)
    """.stripMargin

  override def dependsOn: Set[String] = Set("MAP_PROCEDURE", "TEMP_ENCOUNTER_PRINPX")
}
