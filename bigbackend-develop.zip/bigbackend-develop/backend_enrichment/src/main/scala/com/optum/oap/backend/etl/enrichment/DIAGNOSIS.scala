package com.optum.oap.backend.etl.enrichment

import com.optum.oap.backend.etl.common.MapMasterIds
import com.optum.oap.backend.loader.EnrichmentRunTimeVariables
import com.optum.oap.cdr.models._
import com.optum.oap.sparkdataloader.{RuntimeVariables, TableInfo, UserDefinedFunctionForDataLoader}
import org.apache.spark.sql.functions._
import org.apache.spark.sql.types.TimestampType
import org.apache.spark.sql.{DataFrame, SparkSession}
import org.apache.spark.sql.types.{IntegerType, StringType}
import org.slf4j.LoggerFactory

object DIAGNOSIS extends TableInfo[diagnosis] {

  val log = LoggerFactory.getLogger(this.getClass)

  override def dependsOn = Set("CDR_FE_DIAGNOSIS", "PATIENT_MPI", "MAP_PREDICATE_VALUES", "REF_DIAG_CODES", "CDR_FE_CLINICALENCOUNTER"
  , "ICPM_DIAGNOSIS")

  override def name = "DIAGNOSIS"

  override def saveDataFrameToParquet: Boolean = true

  override def partitions: Int = 256

  override def skipTable: Boolean = false

  override def ignoreExtraColumnsInDataFrame: Boolean = true

  override def createDataFrame(sparkSession: SparkSession,
                               loadedDependencies: Map[String, DataFrame],
                               udfMap: Map[String, UserDefinedFunctionForDataLoader],
                               runtimeVariables: RuntimeVariables): DataFrame = {
    import sparkSession.implicits._
    implicit val spark = sparkSession

    val partitionMultiplier = EnrichmentRunTimeVariables(runtimeVariables).partitionMultiplier

    val diagnosisIn = loadedDependencies("CDR_FE_DIAGNOSIS").drop("row_source", "modified_date").as[diagnosis]
    val icpmDiagnosisIn = loadedDependencies("ICPM_DIAGNOSIS").as[diagnosis]

    val diagnosisUnion = diagnosisIn.unionByName(icpmDiagnosisIn)

    val patXref = loadedDependencies("PATIENT_MPI").as[patient_mpi]

    val map_predicate_values = broadcast(loadedDependencies("MAP_PREDICATE_VALUES")).as[map_predicate_values]

    val ref_diag_codes = broadcast(loadedDependencies("REF_DIAG_CODES")).as[ref_diag_codes]

    val clinicalencounter = loadedDependencies("CDR_FE_CLINICALENCOUNTER").as[clinicalencounter]

    val srcDiag = diagnosisUnion.select(
      $"datasrc".alias("datasrc1"),
      $"client_ds_id".alias("client_ds_id1"),
      $"ORIG_CODETYPE",
      $"ORIG_MAPPEDDIAGNOSIS"
    ).groupBy("datasrc1", "client_ds_id1")
      .agg(when(sum(when($"ORIG_CODETYPE".isNotNull || $"ORIG_MAPPEDDIAGNOSIS".isNotNull, 1)
        .otherwise(0)) === 0, 0).otherwise(1).as("is_orig")).as[is_orig_diagnosis].collect()

    val diagSrc = broadcast(dataframe(srcDiag: _*))

    val joinDfTemp = diagnosisUnion.alias("td1")
      .join(clinicalencounter.alias("ce1"), Seq("GROUPID", "CLIENT_DS_ID", "ENCOUNTERID"))
      .select($"td1.*", $"ce1.dischargetime", $"ce1.arrivaltime")

    // diff of join to left join
    val joinDfTempDiff = diagnosisUnion.alias("td2").select("GROUPID", "CLIENT_DS_ID", "ENCOUNTERID")
      .except(clinicalencounter.alias("ce2").select("GROUPID", "CLIENT_DS_ID", "ENCOUNTERID"))

    //now join original with diff to get all missing in left_join
    val joinedDfTempDiffAllCoumns = diagnosisUnion.as("td3")
      .join(joinDfTempDiff, Seq("GROUPID", "CLIENT_DS_ID", "ENCOUNTERID"))
      .select($"td3.*",
        lit(null).cast(TimestampType).alias("dischargetime"),
        lit(null).cast(TimestampType).alias("arrivaltime")
      ).unionByName(
      diagnosisUnion.as("td4").where($"encounterid".isNull).select(
        $"td4.*",
        lit(null).cast(TimestampType).alias("dischargetime"),
        lit(null).cast(TimestampType).alias("arrivaltime")
      )
    )

    val unionTempDf = joinDfTemp.unionByName(joinedDfTempDiffAllCoumns)

    val joinDf = unionTempDf.alias("td")
      .join(diagSrc.alias("src"),
        $"src.datasrc1" === $"td.datasrc" && $"src.client_ds_id1" === $"td.client_ds_id", "left_outer")
      .join(map_predicate_values.alias("mpv"),
        $"td.client_ds_id" === $"mpv.client_ds_id" && $"td.groupid" === $"mpv.groupid" && $"mpv.data_src" === $"td.datasrc" && $"mpv.entity" === "DIAG_SKIP_FORMAT" && $"mpv.table_name" === "DIAGNOSIS", "left_outer")
      .join(ref_diag_codes.alias("rd"),
        $"rd.DIAGNOSIS_CODE" === when($"src.is_orig" === 1, upper(regexp_replace($"td.ORIG_MAPPEDDIAGNOSIS", "\\.", "")))
          .otherwise(upper(regexp_replace($"td.MAPPEDDIAGNOSIS", "\\.", ""))), "left_outer")

    val mainSelect = joinDf.select($"td.*", $"rd.IS_ICD9", $"IS_ICD10", $"mpv.groupid",
      upper(regexp_replace(trim(when($"is_orig" === 1, $"ORIG_MAPPEDDIAGNOSIS").otherwise($"MAPPEDDIAGNOSIS")), "\\.", ""))
        .alias("clean_md"),
      when($"is_orig" === 1, $"ORIG_MAPPEDDIAGNOSIS").otherwise($"MAPPEDDIAGNOSIS").alias("ORIG_MD_MOD"),
      when($"is_orig" === 1, $"ORIG_CODETYPE").otherwise($"CODETYPE").alias("ORIG_CT_MOD")
    )

    val finalSelect = mainSelect.select(
      $"td.client_ds_id",
      $"td.codetype",
      $"td.datasrc",
      $"td.dx_timestamp",
      $"td.encounterid",
      $"td.facilityid",
      $"td.groupid",
      $"td.grp_mpi",
      $"td.hgpid",
      $"td.hosp_dx_flag",
      $"td.localactiveind",
      $"td.localadmitflg",
      $"td.localdiagnosis",
      $"td.localdiagnosisproviderid",
      $"td.localdiagnosisstatus",
      $"td.localdischargeflg",
      $"td.localpresentonadmission",
      $"td.mappeddiagnosis",
      $"td.mappeddiagnosisstatus",
      $"td.orig_codetype",
      $"td.orig_mappeddiagnosis",
      $"td.patientid",
      $"td.primarydiagnosis",
      $"td.resolutiondate",
      $"td.seq",
      $"td.sourceid",
      $"td.recorded_dtm",
      $"ORIG_MD_MOD", $"clean_md", $"ORIG_CT_MOD",
     $"charge_id",
      $"chronic_ind",
      $"local_diag_desc",
      $"local_severity",
      $"problem_record_id",
      when($"ORIG_CT_MOD".isNotNull && !upper($"ORIG_CT_MOD").isin("ICD9", "ICD10"), $"CODETYPE")
        .when(upper($"ORIG_CT_MOD") === "ICD9",
          when($"rd.IS_ICD9" === "Y" && $"IS_ICD10" === "N", "ICD9")
            .when($"rd.IS_ICD9" === "N" && $"IS_ICD10" === "Y", "ICD10")
            .when(!coalesce(length(regexp_replace($"ORIG_MD_MOD", "\\.", "")), lit(0)).between(3, 5), "UNKNOWN")
            .when(!substring(regexp_replace($"ORIG_MD_MOD", "\\.", ""), 1, 1).rlike("[0-9]")
              && !upper(substring(regexp_replace($"ORIG_MD_MOD", "\\.", ""), 1, 1)).isin("E", "V"), "UNKNOWN")
            .otherwise($"ORIG_CT_MOD"))
        .when(upper($"ORIG_CT_MOD") === "ICD10",
          when($"rd.IS_ICD9" === "N" && $"IS_ICD10" === "Y", "ICD10")
            .when($"rd.IS_ICD9" === "Y" && $"IS_ICD10" === "N", "ICD9")
            .when(!coalesce(length(regexp_replace($"ORIG_MD_MOD", "\\.", "")), lit(0)).between(3, 7), "UNKNOWN")
            .when(!upper(substring(regexp_replace($"ORIG_MD_MOD", "\\.", ""), 1, 1)).rlike("[A-Z]"), "UNKNOWN")
            .when(!substring(regexp_replace($"ORIG_MD_MOD", "\\.", ""), 2, 1).rlike("[0-9]"), "UNKNOWN")
            .otherwise($"ORIG_CT_MOD"))
        .when(!coalesce(length(regexp_replace($"ORIG_MD_MOD", "\\.", "")), lit(0)).between(3, 7), "OTHER")
        .when($"rd.IS_ICD9" === "Y" && $"IS_ICD10" === "N", "ICD9")
        .when($"rd.IS_ICD9" === "N" && $"IS_ICD10" === "Y", "ICD10")
        .when(substring(regexp_replace($"ORIG_MD_MOD", "\\.", ""), 1, 1).rlike("[0-9]") &&
          coalesce(length(regexp_replace($"ORIG_MD_MOD", "\\.", "")), lit(0)).between(3, 5), "ICD9")
        .when(upper(substring(regexp_replace($"ORIG_MD_MOD", "\\.", ""), 1, 1)).rlike("[A-Z]")
          && !upper(substring(regexp_replace($"ORIG_MD_MOD", "\\.", ""), 1, 1)).isin("E", "V")
          && coalesce(length(regexp_replace($"ORIG_MD_MOD", "\\.", "")), lit(0)).between(3, 7), "ICD10")
        .when(!upper(substring(regexp_replace($"ORIG_MD_MOD", "\\.", ""), 1, 1)).isin("E", "V"), "OTHER")
        .when($"mpv.groupid".isNull
          && upper(substring(regexp_replace($"ORIG_MD_MOD", "\\.", ""), 1, 1)) === "E"
          && (instr($"localdiagnosis", ".").between(4, 5) || instr($"ORIG_MD_MOD", ".").between(4, 5)),
          when(regexp_replace($"ORIG_MD_MOD", "\\.", "") === regexp_replace($"localdiagnosis", "\\.", "") && instr($"localdiagnosis", ".") === 4, "ICD10")
            .when(regexp_replace($"ORIG_MD_MOD", "\\.", "") === regexp_replace($"localdiagnosis", "\\.", "") && instr($"localdiagnosis", ".") === 5, "ICD9")
            .when(instr($"ORIG_MD_MOD", ".") === 4, "ICD10")
            .when(instr($"ORIG_MD_MOD", ".") === 5, "ICD9"))
        .when(upper(substring(regexp_replace($"ORIG_MD_MOD", "\\.", ""), 1, 1)).isin("E", "V")
          && to_date(coalesce($"td.dischargetime", $"td.arrivaltime", $"td.dx_timestamp")) < lit("2015-10-01"), "ICD9")
        .otherwise("UNKNOWN")
        .alias("ct_mod"))

    val finalResult = finalSelect.select($"*",
      when($"ct_mod" === "ICD9",
        when(upper(substring($"clean_md", 1, 1)) === "E" && coalesce(length($"clean_md"), lit(0)) === 5,
          concat(substring($"clean_md", 1, 4), lit("."), substring($"clean_md", 5, 1)))
          .when(upper(substring($"clean_md", 1, 1)) === "E" && coalesce(length($"clean_md"), lit(0)) === 4,
            substring($"clean_md", 1, 4))
          .when(upper(substring($"clean_md", 1, 1)).rlike("[0-9V]") && length($"clean_md").between(4, 5),
            concat(substring($"clean_md", 1, 3), lit("."), substring($"clean_md", 4, 2)))
          .when(coalesce(length($"clean_md"), lit(0)).leq(3), substring($"clean_md", 1, 3))
          .otherwise($"ORIG_MD_MOD"))
        .when($"ct_mod" === "ICD10",
          when(coalesce(length($"clean_md"), lit(0)).between(4, 7),
            concat(substring($"clean_md", 1, 3), lit("."), substring($"clean_md", 4, 4)))
            .when(coalesce(length($"clean_md"), lit(0)).leq(3), substring($"clean_md", 1, 3))
            .otherwise($"ORIG_MD_MOD")
        ).otherwise($"ORIG_MD_MOD").alias("md_mod")
    ).withColumn("ORIG_MAPPEDDIAGNOSIS", $"ORIG_MD_MOD")
      .withColumn("ORIG_CODETYPE", $"ORIG_CT_MOD")
      .withColumn("MAPPEDDIAGNOSIS", $"md_mod")
      .withColumn("CODETYPE", $"CT_MOD")
      .drop("clean_md", "md_mod", "ORIG_MD_MOD", "ORIG_CT_MOD", "ct_mod")

    MapMasterIds.mapPatientIds(finalResult, patXref.toDF, filterIds = false)
  }
}

case class is_orig_diagnosis(datasrc1: String, client_ds_id1: Integer, is_orig: Integer)
