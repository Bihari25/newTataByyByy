package com.optum.oap.backend.etl.enrichment

import com.optum.oap.backend.cdrTempModel.{ref_cmsnpi_partial}
import com.optum.oap.cdr.models._
import com.optum.oap.sparkdataloader.{RuntimeVariables, TableInfo, UserDefinedFunctionForDataLoader}
import org.apache.spark.sql.expressions.Window
import org.apache.spark.sql.functions._
import org.apache.spark.sql.types.DataTypes
import org.apache.spark.sql.{DataFrame, SparkSession}
import org.slf4j.LoggerFactory
import com.optum.oap.backend.etl.common.Functions.mpvList
import com.optum.oap.backend.loader.EnrichmentRunTimeVariables

object ICPM_ZH_PROVIDER extends TableInfo[zh_provider] {

  private val log = LoggerFactory.getLogger(this.getClass)

  override def dependsOn = Set("INT_CLAIM_PROV", "INT_CLAIM_MEDICAL", "INT_CLAIM_MEMBER", "INT_CLAIM_PHARM",
    "INT_CLAIM_LABRESULT", "MAP_PREDICATE_VALUES", "REF_CMSNPI")

  override def name = "ICPM_ZH_PROVIDER"

  override def createDataFrame(sparkSession: SparkSession,
                               loadedDependencies: Map[String, DataFrame],
                               udfMap: Map[String, UserDefinedFunctionForDataLoader],
                               runtimeVariables: RuntimeVariables): DataFrame = {
    import sparkSession.implicits._

    val intClaimProvIn = loadedDependencies("INT_CLAIM_PROV").as[int_claim_prov]

    val intClaimMedicalIn = loadedDependencies("INT_CLAIM_MEDICAL")

    val intClaimMemberIn = loadedDependencies("INT_CLAIM_MEMBER").as[int_claim_member]

    val intClaimPharmIn = loadedDependencies("INT_CLAIM_PHARM").as[int_claim_pharm]

    val intClaimLabresultIn = loadedDependencies("INT_CLAIM_LABRESULT").as[int_claim_labresult]

    val refCmsNpi = loadedDependencies("REF_CMSNPI").as[ref_cmsnpi_partial]

    val mapPredicateVal = loadedDependencies("MAP_PREDICATE_VALUES").as[map_predicate_values]

    val groupId = runtimeVariables.asInstanceOf[EnrichmentRunTimeVariables].clientId

    //predicate_values_listagg function call
    val provNpiValMpv = mpvList(loadedDependencies("MAP_PREDICATE_VALUES"),
      groupId,
      null,
      "PROVIDERID",
      "ZH_PROVIDER",
      "INT_CLAIM_PROVIDER",
      "O1_NPI"
    ).mkString(",")

    val unionProvDf = intClaimProvIn.select(
      $"groupid",
      $"client_ds_id",
      lit("int_claim_prov").as("datasrc"),
      $"prov_id".as("localproviderid"),
      $"prov_credentials".as("credentials"),
      $"prov_email".as("emailaddress"),
      $"prov_fname".as("firstname"),
      $"prov_name".as("fullname"),
      $"prov_lname".as("lastname"),
      $"prov_mi".as("middlename"),
      $"prov_npi".as("prov_npi"),
      $"update_dt".as("lastupdatedate"),
      $"pcp_flag".as("pcp_flag"),
      lit(1).as("source"),
      $"eff_date".as("start_date"),
      $"end_date".as("end_date")
    )
      .unionByName(intClaimMedicalIn.select(
        $"groupid",
        $"client_ds_id",
        lit("int_claim_medical").as("datasrc"),
        lit(null).cast(DataTypes.StringType).as("credentials"),
        lit(null).cast(DataTypes.StringType).as("emailaddress"),
        expr("stack(4, admit_prov_id, admit_prov_fname, admit_prov_name, admit_prov_lname, admit_prov_mi, admit_prov_npi, 'ADMIT', " +
          "attnd_prov_id, attnd_prov_fname, attnd_prov_name, attnd_prov_lname, attnd_prov_mi, attnd_prov_npi, 'ATTEND', " +
          "billing_prov_id, billing_prov_fname, billing_prov_name, billing_prov_lname, billing_prov_mi, billing_prov_npi, 'BILL', " +
          "servicing_prov_id, servicing_prov_fname, servicing_prov_name, servicing_prov_lname, servicing_prov_mi, servicing_prov_npi, 'SERV') " +
          " as (localproviderid, firstname, fullname, lastname, middlename, prov_npi, prov_type)"),
        $"service_date".as("lastupdatedate"),
        lit(null).cast(DataTypes.StringType).as("pcp_flag"),
        lit(2).as("source"),
        lit(null).cast(DataTypes.TimestampType).as("start_date"),
        lit(null).cast(DataTypes.TimestampType).as("end_date")
      ).filter($"localproviderid".isNotNull).drop("prov_type")
      )
      .unionByName(intClaimMemberIn.select(
        $"groupid",
        $"client_ds_id",
        lit("int_claim_member").as("datasrc"),
        $"pcp_id".as("localproviderid"),
        lit(null).cast(DataTypes.StringType).as("credentials"),
        lit(null).cast(DataTypes.StringType).as("emailaddress"),
        $"pcp_fname".as("firstname"),
        $"pcp_name".as("fullname"),
        $"pcp_lname".as("lastname"),
        $"pcp_mi".as("middlename"),
        $"pcp_npi".as("prov_npi"),
        coalesce($"member_eff_date", to_date($"eligibile_member_month", "yyyyMM")).as("lastupdatedate"),
        lit(null).cast(DataTypes.StringType).as("pcp_flag"),
        lit(3).as("source"),
        lit(null).cast(DataTypes.StringType).as("start_date"),
        lit(null).cast(DataTypes.StringType).as("end_date")
      ))
      .unionByName(intClaimPharmIn.select(
        $"groupid",
        $"client_ds_id",
        lit("int_claim_pharm").as("datasrc"),
        lit(null).cast(DataTypes.StringType).as("credentials"),
        lit(null).cast(DataTypes.StringType).as("emailaddress"),
        expr("stack(2, pcp_id, pcp_fname, pcp_name, pcp_lname, pcp_mi, pcp_npi, 'PCP', " +
          "presc_prov_id, presc_prov_fname, presc_prov_name, presc_prov_lname, presc_prov_mi, presc_prov_npi, 'PRESC') " +
          " as (localproviderid, firstname, fullname, lastname, middlename, prov_npi, prov_type)"),
        $"service_date".as("lastupdatedate"),
        lit(null).cast(DataTypes.StringType).as("pcp_flag"),
        lit(4).as("source"),
        lit(null).cast(DataTypes.TimestampType).as("start_date"),
        lit(null).cast(DataTypes.TimestampType).as("end_date")
      ).filter($"localproviderid".isNotNull).drop("prov_type")
      )
      .unionByName(intClaimPharmIn.filter($"pharmacy_id".isNotNull).select(
        $"groupid",
        $"client_ds_id",
        lit("int_claim_pharm").as("datasrc"),
        $"pharmacy_id".as("localproviderid"),
        lit(null).cast(DataTypes.StringType).as("credentials"),
        lit(null).cast(DataTypes.StringType).as("emailaddress"),
        lit(null).cast(DataTypes.StringType).as("firstname"),
        lit(null).cast(DataTypes.StringType).as("fullname"),
        lit(null).cast(DataTypes.StringType).as("lastname"),
        lit(null).cast(DataTypes.StringType).as("middlename"),
        lit(null).cast(DataTypes.StringType).as("prov_npi"),
        $"service_date".as("lastupdatedate"),
        lit(null).cast(DataTypes.StringType).as("pcp_flag"),
        lit(4).as("source"),
        lit(null).cast(DataTypes.StringType).as("start_date"),
        lit(null).cast(DataTypes.StringType).as("end_date")
      ))
      .unionByName(intClaimLabresultIn.select($"groupid",
        $"client_ds_id",
        lit("int_claim_labresult").as("datasrc"),
        lit(null).cast(DataTypes.StringType).as("credentials"),
        lit(null).cast(DataTypes.StringType).as("emailaddress"),
        expr("stack(2, pcp_id, pcp_fname, pcp_name, pcp_lname, pcp_mi, pcp_npi, 'PCP', " +
          "ordering_prov_id, ordering_prov_fname, ordering_prov_name, ordering_prov_lname, ordering_prov_mi, ordering_prov_npi, 'ORD') " +
          " as (localproviderid, firstname, fullname, lastname, middlename, prov_npi, prov_type)"),
        $"result_date".as("lastupdatedate"),
        lit(null).cast(DataTypes.StringType).as("pcp_flag"),
        lit(5).as("source"),
        lit(null).cast(DataTypes.TimestampType).as("start_date"),
        lit(null).cast(DataTypes.TimestampType).as("end_date")
      ).filter($"localproviderid".isNotNull).drop("prov_type")
      )

    val cdrFeProv = unionProvDf.alias("pr")
      .join(refCmsNpi.alias("ref"), $"pr.prov_npi" === $"ref.npi", "left_outer")
      .select(
        $"pr.groupid",
        $"pr.datasrc",
        $"pr.client_ds_id",
        $"localproviderid",
        $"pr.credentials",
        $"pr.emailaddress",
        when($"pr.firstname".isNull && $"pr.lastname".isNull, $"ref.prov_firstname")
          .otherwise($"pr.firstname").as("first_name"),
        $"pr.fullname".as("providername"),
        when($"pr.firstname".isNull && $"pr.lastname".isNull,
          coalesce($"ref.prov_lastname_legalname", $"ref.prov_org_name_legal_bus_name"))
          .otherwise($"pr.lastname").as("last_name"),
        $"pr.middlename".as("middle_name"),
        when($"pr.prov_npi".isin("0000000000", "9999999999") ||
          length(coalesce($"pr.prov_npi", lit("0"))) =!= 10, null)
          .otherwise($"pr.prov_npi").as("npi"),
        $"lastupdatedate",
        $"source",
        when($"pr.client_ds_id".isin(provNpiValMpv) && $"ref.entity_type_code" === "1", lit("N"))
          .when($"pr.client_ds_id".isin(provNpiValMpv) && $"ref.entity_type_code" === "2", lit("Y"))
          .otherwise(null).as("providerexclusionflag"),
        $"pcp_flag",
        $"start_date",
        $"end_date"
      ).withColumn("rank_prov", row_number().over(Window.partitionBy($"client_ds_id", $"localproviderid")
      //Comparing to Oracle script, last_name is added in addition to other orderBy columns to avoid non-deterministic issue.
      .orderBy($"source", $"lastupdatedate".desc_nulls_last, $"end_date".desc_nulls_first,
        $"start_date".desc_nulls_last, $"npi".asc_nulls_last, $"providername".desc_nulls_last,
        $"first_name".desc_nulls_last, $"last_name".desc_nulls_last)))

    cdrFeProv.filter($"rank_prov" === 1 && $"localproviderid".isNotNull)
      .select(
        $"groupid",
        $"client_ds_id",
        $"datasrc",
        $"localproviderid",
        $"credentials",
        $"emailaddress",
        $"first_name",
        $"last_name",
        $"middle_name",
        $"npi",
        $"providername",
        $"providerexclusionflag",
        $"pcp_flag",
        lit(null).cast(DataTypes.StringType).as("localclassification"),
        lit(null).cast(DataTypes.StringType).as("localprimaryspecialty"),
        lit(null).cast(DataTypes.StringType).as("mappedcredentialtype"),
        lit(null).cast(DataTypes.StringType).as("primaryfacilityid"),
        lit(null).cast(DataTypes.StringType).as("suffix"),
        lit(null).cast(DataTypes.StringType).as("gender"),
        lit(null).cast(DataTypes.TimestampType).as("dob"),
        lit(null).cast(DataTypes.StringType).as("master_hgprovid"),
        lit(null).cast(DataTypes.StringType).as("employment_status_cd"),
        lit(null).cast(DataTypes.StringType).as("name_prefix"),
        lit(null).cast(DataTypes.IntegerType).as("resident_ind"),
        lit(null).cast(DataTypes.IntegerType).as("resident_program_year")
      )
  }
}
