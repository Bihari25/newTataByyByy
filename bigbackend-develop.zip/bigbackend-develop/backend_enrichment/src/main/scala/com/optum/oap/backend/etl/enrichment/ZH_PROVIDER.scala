package com.optum.oap.backend.etl.enrichment

import com.optum.oap.backend.etl.common.MapMasterIds
import com.optum.oap.cdr.models.{zh_provider, zh_provider_master_xref}
import com.optum.oap.sparkdataloader.{RuntimeVariables, TableInfo, UserDefinedFunctionForDataLoader}
import org.apache.spark.sql.functions.broadcast
import org.apache.spark.sql.{DataFrame, SparkSession}
import org.slf4j.LoggerFactory

object ZH_PROVIDER extends TableInfo[zh_provider] {

  val log = LoggerFactory.getLogger(this.getClass)

  override def dependsOn = Set("ZH_PROVIDER_MASTER_XREF", "TEMP_ZH_PROV_PREMATCH")

  override def name = "ZH_PROVIDER"

  override def saveDataFrameToParquet: Boolean = true

  override def partitions: Int = 32

  override def skipTable: Boolean = false

  override def ignoreExtraColumnsInDataFrame: Boolean = true

  override def createDataFrame(sparkSession: SparkSession,
                               loadedDependencies: Map[String, DataFrame],
                               udfMap: Map[String, UserDefinedFunctionForDataLoader],
                               runtimeVariables: RuntimeVariables): DataFrame = {
    import sparkSession.implicits._

    val zh_providerIn = loadedDependencies("TEMP_ZH_PROV_PREMATCH").as[zh_provider]
    val provXref = broadcast(loadedDependencies("ZH_PROVIDER_MASTER_XREF")).as[zh_provider_master_xref]

    MapMasterIds.mapProviderIds(zh_providerIn.toDF, provXref.toDF, "localproviderid", "master_hgprovid")
  }

}
