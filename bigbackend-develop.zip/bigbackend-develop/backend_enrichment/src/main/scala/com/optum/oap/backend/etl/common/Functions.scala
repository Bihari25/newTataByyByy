package com.optum.oap.backend.etl.common

import org.apache.spark.sql.functions.{collect_list, struct, _}
import org.apache.spark.sql.types.{LongType, StructField, StructType}
import org.apache.spark.sql.{Column, DataFrame, Row, SparkSession}

import scala.reflect.runtime.universe._

object Functions {

  def standardize(col: String, df: DataFrame, removePattern: String, matchPattern: String, mismatchPattern: String): DataFrame = {
    val replaced = regexp_replace(trim(df(col)), removePattern, "")
    df.withColumn(col, when(replaced rlike matchPattern, when((replaced rlike mismatchPattern) && (!mismatchPattern.equals("")), null).otherwise(replaced)).otherwise(null))
  }

  def standardizeZip(col: String, df: DataFrame, zip5: Boolean = false): DataFrame = {
    val f = standardize(col, df, "", "^[0-9]{5}(\\-)?([0-9]{4})?$", "")

    if (zip5) {
      //      val df2 = f(col + "_TMP", df)
      f.withColumn(col, substring(f(col), 0, 5))
      //        .drop(col + "_TMP")
    } else f
  }

  /**
   * Convenience method to select the same cols as that of the case class
   *
   * * @tparam T
   * * @return
   */
  def selectColsFromCaseClass[T: TypeTag] = {
    typeOf[T].members.sorted.collect { case m: MethodSymbol if m.isCaseAccessor => m.name.toString }
  }

  /**
   * Convenience method to get a list of a case class from a grouped DataFrame
   *
   * @param sparkSession
   * * @tparam A
   * * @return
   */
  def collectListFromType[A <: Product with Serializable : TypeTag](sparkSession: SparkSession): Column = {
    import sparkSession.implicits._
    collect_list(struct(typeOf[A].members.sorted.collect {
      case m: MethodSymbol if m.isCaseAccessor => m
    }.map(m => $"${m.name}"): _*))
  }

  /**
   * Converts a null String to "0"
   *
   * @param in
   * @return
   */
  def nullTo0(in: String): String = {
    Option(in).getOrElse("0")
  }

  def appendRowNumberToDataframe(sparkSession: SparkSession, df: DataFrame, rowNumberName: String = "rownumber"): DataFrame = {
    // convert to RDD , append rownumber column and change it back to dataframe
    val newSchema = StructType(df.schema.fields ++ Array(StructField(rowNumberName, LongType, nullable = false)))
    val rddWithId = df.rdd.zipWithIndex
    sparkSession.createDataFrame(rddWithId.map { case (row, index) => Row.fromSeq(row.toSeq ++ Array(index + 1)) }, newSchema)
  }

  // Returns a table containing matching map predicate values
  def mpv(mpvTable: DataFrame, groupID: String, cdsid: Integer, dataSrc: String, entity: String, tableName: String,
          columnName: String): DataFrame = {
    val cdsidFil = if (cdsid != null) s" AND CLIENT_DS_ID='${cdsid}'" else ""

    mpvTable.filter(s"GROUPID='${groupID}' AND DATA_SRC='${dataSrc}' AND ENTITY='${entity}' AND TABLE_NAME='${tableName}' AND COLUMN_NAME='${columnName}'${cdsidFil}")
      .select("COLUMN_VALUE")
  }

  // Return a List of map predicate values
  def mpvList(mpvTable: DataFrame, groupID: String, cdsid: Integer, dataSrc: String, entity: String, tableName: String, columnName: String): List[String] = {
    mpv(mpvTable, groupID, cdsid, dataSrc, entity, tableName, columnName).rdd.map(r => r(0).toString).collect().toList.map(x => s"'${x}'")
  }

  /**
   * Captures the portion of a string in a value that matches a given regex
   */
  def regexParse(regex: String, value: Option[String], groupNumber: Int = 1): Option[String] = {
    if (value.isEmpty) None else {
      val pattern = ("(" + regex + ")").r
      pattern.findFirstMatchIn(value.get).map(_.group(groupNumber))
    }
  }
}
