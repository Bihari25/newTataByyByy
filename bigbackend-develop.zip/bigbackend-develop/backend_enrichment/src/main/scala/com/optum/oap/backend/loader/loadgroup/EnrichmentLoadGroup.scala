package com.optum.oap.backend.loader.loadgroup
import com.optum.oap.backend.etl.common.CDRConstants
import com.optum.oap.backend.etl.enrichment.FE_TO_BE
import com.optum.oap.backend.loader.{DataTableDependencies, DeltaDependencies, EnrichmentQueryRegistry, EnrichmentRunTimeVariables, NlpDependencies, StaticDependencies}
import com.optum.oap.backend.util.ImportResources.{CDR_COMMON_ENTITIES, CDR_DELTA_ENTITIES, CDR_MAPS_ENTITIES}
import com.optum.oap.sparkdataloader.{LoadFromHive, TableInfo}
import org.apache.spark.sql.SparkSession

trait EnrichmentLoadGroup extends LoadGroup {

  override def loadGroup: String = "enrichment"

  /** Determine the initial dependencies for the Enrichment loadgroup step
    *
    * Enrichment loadgroup initial dependency should include all tables(map and non-map) that aren't included in the
    * static dependencies. Dynamic depedencies include map tables, cdr_common tables that aren't getting enriched in enrichment step. E.g.
    *
    * {{{
    *   ZH_FACILITY,
    *   QGATE_PERSON_ID_STATUS,
    *   etc..
    * }}}
    *
    *
    */
  override def initialDependencies(runTimeVariables: EnrichmentRunTimeVariables, sparkSession: SparkSession): Seq[TableInfo[_ <: Product with Serializable]] = {
    import runTimeVariables._

    val nlpDB = {
      val groupSchema = s"${clientId.toLowerCase}_prd_cdr_be_nlp"  // always use the prd schema if it exists
      if (sparkSession.catalog.databaseExists(groupSchema) && !(cdrCycle.toLowerCase.contains("delta")))
        groupSchema
      else
        s"default_${environment.toLowerCase}_cdr_be_nlp"
    }

    val ecdrHiveDb: String = if (buildType == CDRConstants.DELTA_BUILD_TYPE) fullHiveDb else cdrSchema
    val baseDependencies = DataTableDependencies.dataInitialDependencies(cdrSchema, "CDR_FE_", true) ++
      DeltaDependencies.deltaInitialDependencies(ecdrHiveDb) ++ NlpDependencies.nlpInitialDependencies(nlpDB)

    val baseDependenciesSet = baseDependencies.map(_.name).toSet
    val feToBeRegistry = if (buildType.equalsIgnoreCase("Monthly")) {
      (CDR_COMMON_ENTITIES ++ CDR_MAPS_ENTITIES)
        .map(x => LoadFromHive[Empty](tableName = x.tableName, referenceName = Option(s"CDR_FE_${x.tableName}"), hiveDatabase = cdrSchema))
        .filter(entity => !baseDependenciesSet.contains(entity.name)).toList
    } else {
      (CDR_COMMON_ENTITIES ++ CDR_MAPS_ENTITIES ++ CDR_DELTA_ENTITIES)
        .map(x => LoadFromHive[Empty](tableName = x.tableName, referenceName = Option(s"CDR_FE_${x.tableName}"), hiveDatabase = cdrSchema))
        .filter(entity => !baseDependenciesSet.contains(entity.name)).toList
    }

    baseDependencies ++ feToBeRegistry
  }

  /**
    * In FE enrichment step, we are enriching few base tables. FE enrichment step copies
    * data from cdr_fe to cdr_be location. Using the same enrichment step to copy maps and remaining tables
    * from cdr_fe to cdr_be.
    * @param runTimeVariables
    * @param sparkSession
    * @return
    */
  override def queryRegistry(runTimeVariables: EnrichmentRunTimeVariables, sparkSession: SparkSession): Seq[TableInfo[_ <: Product with Serializable]] = {
    import runTimeVariables._
    super.refreshXRefTables(runTimeVariables, sparkSession)
    val enrichedQueryRegistry = EnrichmentQueryRegistry.enrichmentQueryRegistry ++
      EnrichmentQueryRegistry.patientMpiQueryRegistry(sparkSession, runTimeVariables) ++
      super.queryRegistry(runTimeVariables, sparkSession)

    val enrichedQueryRegistryEntities = enrichedQueryRegistry.map(_.name).toSet
    val feToBeRegistry = if (buildType.equalsIgnoreCase("Monthly")) {
      (CDR_COMMON_ENTITIES ++ CDR_MAPS_ENTITIES).map(x => FE_TO_BE(x.tableName)).filter(entity => !enrichedQueryRegistryEntities.contains(entity.name)).toList
    } else {
      (CDR_COMMON_ENTITIES ++ CDR_MAPS_ENTITIES ++ CDR_DELTA_ENTITIES).map(x => FE_TO_BE(x.tableName)).filter(entity => !enrichedQueryRegistryEntities.contains(entity.name)).toList
    }

    enrichedQueryRegistry ++ feToBeRegistry
  }
}

case class Empty()
