package com.optum.oap.backend.etl.patient_matching.data_table

import com.optum.oap.backend.cdrTempModel.pat_match_prep
import com.optum.oap.backend.etl.common.{CDRConstants, CleanPatientName, EnrichmentUtils, SSNValidation}
import com.optum.oap.backend.etl.patient_matching.PATIENT_MPI_UTILS
import com.optum.oap.backend.loader.EnrichmentRunTimeVariables
import com.optum.oap.cdr.models.{map_gender, mpi_custom, patient_id, patientdetail}
import com.optum.oap.sparkdataloader.{RuntimeVariables, TableInfo, UserDefinedFunctionForDataLoader}
import org.apache.spark.sql.expressions.Window
import org.apache.spark.sql.functions._
import org.apache.spark.sql.types.{LongType, StringType}
import org.apache.spark.sql.{DataFrame, SparkSession}

object MPI_CUSTOM_H542284 extends TableInfo[mpi_custom] {

  override def dependsOn = Set("PAT_MATCH_PREP", "PATIENTDETAIL_PREMATCH", "MAP_GENDER", "PATIENT_ID_PREMATCH", "ECDR_MPI_CUSTOM_H542284")

  override def name = "MPI_CUSTOM_H542284"

  override def createDataFrame(sparkSession: SparkSession,
                               loadedDependencies: Map[String, DataFrame],
                               udfMap: Map[String, UserDefinedFunctionForDataLoader],
                               runtimeVariables: RuntimeVariables): DataFrame = {
    import sparkSession.implicits._

    val tempPatMatchPrep = loadedDependencies("PAT_MATCH_PREP").as[pat_match_prep]
    val tempPatientId = loadedDependencies("PATIENT_ID_PREMATCH").as[patient_id]
    val patientDetail = loadedDependencies("PATIENTDETAIL_PREMATCH").as[patientdetail]
    val mapGender = broadcast(loadedDependencies("MAP_GENDER").as[map_gender])

    val dailyBuild = if (runtimeVariables.asInstanceOf[EnrichmentRunTimeVariables].buildType == CDRConstants.DELTA_BUILD_TYPE) true else false

    val tempPatAttrs = tempPatMatchPrep
      .where($"dob".isNotNull)
      .select(
        $"groupid",
        $"client_ds_id",
        $"patientid",
        $"hgpid",
        $"dob",
        upper($"fname").as("first_name"),
        upper($"lname").as("last_name"),
        CleanPatientName.cleanPatientName($"fname", lit(3)).as("fname"),
        CleanPatientName.cleanPatientName($"lname", lit(3)).as("lname")
      ).distinct

    val ssn = tempPatientId.as("tpi")
      .where(!trim(substring(regexp_replace($"idvalue", "-", ""), 1, 9)).isin(PATIENT_MPI_UTILS.getBadSSNs: _*))
      .where($"tpi.idtype" === lit("SSN"))
      .where(!SSNValidation.cleanAndValidate($"tpi.idvalue").isin(SSNValidation.INVALID_OUTCOMES: _*))
      .select(
        $"groupid",
        $"client_ds_id",
        $"patientid",
        trim(substring(regexp_replace($"idvalue", "-", ""), 1, 9)).as("ssn")
      ).distinct

    val mrnDf = tempPatientId.as("tpi")
      .where($"tpi.idtype" === lit("MRN"))
      .select(
        $"groupid",
        $"client_ds_id",
        $"patientid",
        trim(substring(regexp_replace($"idvalue", "-", ""), 1, 9)).as("mrn")
      ).distinct

    val dobWindow = Window.partitionBy($"dob")

    val dataDf = tempPatAttrs.as("p")
      .join(ssn.as("pid"), Seq("groupid", "client_ds_id", "patientid"), "left")
      .join(mrnDf.as("mrn"), Seq("groupid", "client_ds_id", "patientid"), "left")
      .join(patientDetail.as("pd").where($"pd.patientdetailtype" === lit("GENDER")),
        Seq("groupid", "client_ds_id", "patientid"), "left")
      .join(mapGender.as("mg"), $"pd.localvalue" === $"mg.mnemonic", "left")
      .select(
        $"p.groupid",
        $"p.client_ds_id",
        $"p.patientid",
        $"p.hgpid",
        $"p.dob".as("key_attr"),
        $"p.fname".as("attr_2"),
        $"p.lname".as("attr_3"),
        substring($"fname", 1, 3).as("attr_4"),
        substring($"lname", 1, 3).as("attr_5"),
        substring($"fname", 1, 5).as("attr_6"),
        $"mrn".as("attr_7"),
        $"mg.cui".as("attr_8"),
        $"pid.ssn".as("attr_9"),
        when($"client_ds_id".isin(lit(6967), lit(6964)), $"mrn")
          .otherwise(lit(null).cast(StringType)).as("attr_10"),
        lit(null).cast(StringType).as("attr_11"),
        lit(null).cast(StringType).as("attr_12"),
        size(collect_set("p.groupid").over(dobWindow)).as("group_cnt"),
        size(collect_set("p.hgpid").over(dobWindow)).cast(LongType).as("hgpids")
      )

    val ecdrDf = {
      if (dailyBuild) EnrichmentUtils.removeRowSourceAndModifiedDate(loadedDependencies("ECDR_MPI_CUSTOM_H542284")).as[mpi_custom]
      else sparkSession.emptyDataset[mpi_custom].as[mpi_custom]
    }.as("e")
      .select($"e.*")

    dataDf.unionByName(ecdrDf).distinct()
  }

}
