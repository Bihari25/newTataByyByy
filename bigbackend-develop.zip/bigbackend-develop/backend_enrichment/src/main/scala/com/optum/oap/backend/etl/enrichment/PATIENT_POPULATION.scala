package com.optum.oap.backend.etl.enrichment

import com.optum.oap.backend.etl.common.MapMasterIds
import com.optum.oap.cdr.models.{map_pop_seg, patient, patient_mpi, patient_population}
import com.optum.oap.sparkdataloader.{RuntimeVariables, TableInfo, UserDefinedFunctionForDataLoader}
import org.apache.spark.sql.{DataFrame, SparkSession}
import org.apache.spark.sql.functions._
import org.slf4j.LoggerFactory

object PATIENT_POPULATION extends TableInfo[patient_population] {

  val log = LoggerFactory.getLogger(this.getClass)

  override def dependsOn = Set("CDR_FE_PATIENT_POPULATION", "PATIENT_MPI", "PATIENT", "MAP_POP_SEG")

  override def name = "PATIENT_POPULATION"

  override def saveDataFrameToParquet: Boolean = true

  override def partitions: Int = 32

  override def skipTable: Boolean = false

  override def ignoreExtraColumnsInDataFrame: Boolean = true

  override def createDataFrame(sparkSession: SparkSession,
                               loadedDependencies: Map[String, DataFrame],
                               udfMap: Map[String, UserDefinedFunctionForDataLoader],
                               runtimeVariables: RuntimeVariables): DataFrame = {
    import sparkSession.implicits._

    val patient_populationDf = loadedDependencies("CDR_FE_PATIENT_POPULATION").as[patient_population]
    val patXref = loadedDependencies("PATIENT_MPI").as[patient_mpi]
    val patient = loadedDependencies("PATIENT").as[patient]
    val mapPopSeg = broadcast(loadedDependencies("MAP_POP_SEG")).as[map_pop_seg]
    val patient_populationIn = patient_populationDf.select($"client_ds_id", $"datasrc", $"groupid", $"grp_mpi", $"patientid", $"population_type_cui")
    val mappedPatientPopulation = MapMasterIds.mapPatientIds(patient_populationIn.toDF, patXref.toDF, false)

    val cols = getSelectList(mappedPatientPopulation.columns.toSet)

    val resultDF = patient.as("P")
      .join(mapPopSeg.as("M"), $"P.groupid" === $"M.groupid" && $"P.client_ds_id" === $"M.client_ds_id", "inner")
      .withColumn("population_type_cui", $"M.hts_code")
      .select(cols.head, cols.tail: _*)


    mappedPatientPopulation.unionByName(resultDF).distinct

  }

  def getSelectList(sourceCols: Set[String]): Array[String] = {
    sourceCols.map(s => if (!s.equals("population_type_cui")) "P." + s else s).toArray
  }

}
