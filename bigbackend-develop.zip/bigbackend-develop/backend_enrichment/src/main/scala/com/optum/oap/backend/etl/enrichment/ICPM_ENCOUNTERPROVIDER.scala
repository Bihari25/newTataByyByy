package com.optum.oap.backend.etl.enrichment

import com.optum.oap.backend.cdrTempModel.temp_med_claim
import com.optum.oap.cdr.models._
import com.optum.oap.sparkdataloader.{RuntimeVariables, TableInfo, UserDefinedFunctionForDataLoader}
import org.apache.spark.sql.expressions.Window
import org.apache.spark.sql.functions._
import org.apache.spark.sql.types.DataTypes
import org.apache.spark.sql.{DataFrame, SparkSession}
import org.slf4j.LoggerFactory

object ICPM_ENCOUNTERPROVIDER extends TableInfo[encounterprovider] {

  private val log = LoggerFactory.getLogger(this.getClass)

  override def dependsOn = Set("ICPM_TEMP_MED_CLAIM")

  override def name = "ICPM_ENCOUNTERPROVIDER"

  override def createDataFrame(sparkSession: SparkSession,
                               loadedDependencies: Map[String, DataFrame],
                               udfMap: Map[String, UserDefinedFunctionForDataLoader],
                               runtimeVariables: RuntimeVariables): DataFrame = {
    import sparkSession.implicits._

    val tempMedClaimIn = loadedDependencies("ICPM_TEMP_MED_CLAIM").as[temp_med_claim]

    tempMedClaimIn.select(
      $"groupid",
      $"client_ds_id",
      $"datasrc",
      $"service_date".as("encountertime"),
      $"member_id".as("patientid"),
      $"encounterid",
      expr("stack(5, " +
        "admit_prov_id, 'ADMIT_PROV', " +
        "attnd_prov_id, 'ATTEND_PROV', " +
        "billing_prov_id, 'BILLING_PROV', " +
        "referring_prov_id, 'REFER_PROV', " +
        "servicing_prov_id, 'SERV_PROV' )" +
        " as (localproviderid, providerrole_orig)"),
      lit(null).cast(DataTypes.StringType).as("facilityid"),
      lit(null).cast(DataTypes.StringType).as("grp_mpi"),
      lit(null).cast(DataTypes.LongType).as("hgpid"),
      lit(null).cast(DataTypes.StringType).as("mstrprovid")
      )
      .withColumn("providerid", when($"datasrc" === "int_claim_medical_p"
          && $"providerrole_orig".isin("BILLING_PROV", "REFER_PROV", "SERV_PROV"), $"localproviderid")
        .when($"datasrc" === "int_claim_medical_i"
          && $"providerrole_orig".isin("ADMIT_PROV", "ATTEND_PROV"), $"localproviderid")
        .otherwise(null))
      .withColumn("providerrole", concat_ws("", lit("CLM."), $"providerrole_orig"))
      .withColumn("rank_encp", row_number().over(Window.partitionBy($"client_ds_id", $"encounterid",
        $"providerid", $"providerrole").orderBy($"encountertime".asc_nulls_last)))
      .filter($"rank_encp" === 1
        && $"patientid".isNotNull
        && $"providerid".isNotNull
        && $"encountertime".isNotNull)
      .drop("localproviderid", "providerrole_orig", "rank_encp")
  }
}
