package com.optum.oap.backend.etl.summary

import com.optum.oap.cdr.models.{v_labcode_results, v_labcode_summary}
import com.optum.oap.sparkdataloader.{RuntimeVariables, TableInfo, UserDefinedFunctionForDataLoader}
import org.apache.spark.sql.expressions.Window
import org.apache.spark.sql.functions._
import org.apache.spark.sql.types.{IntegerType, StringType}
import org.apache.spark.sql.{DataFrame, SparkSession}
import org.slf4j.LoggerFactory

object V_LABCODE_SUMMARY extends TableInfo[v_labcode_summary] {

  val log = LoggerFactory.getLogger( this.getClass )

  override def dependsOn = Set( "V_LABCODE_RESULTS" )

  override def name = "V_LABCODE_SUMMARY"

  override def createDataFrame( sparkSession: SparkSession,
                                loadedDependencies: Map[String, DataFrame],
                                udfMap: Map[String, UserDefinedFunctionForDataLoader],
                                runtimeVariables: RuntimeVariables ): DataFrame = {

    import sparkSession.implicits._

    val labcode_results = loadedDependencies( "V_LABCODE_RESULTS" ).as[v_labcode_results]

    val groups = Window
      .partitionBy(
        'groupid, 'client_ds_id, 'code_value, 'dict_name, 'dict_def, 'ref_range, 'order_name, 'data_type, 'specimen_name
        , 'bodysite_name, 'unit_name, 'local_loinc_code )
      .orderBy(
        'localresult_cnt.desc_nulls_last, 'localresult.asc_nulls_last
      )

    val lr = labcode_results
      .filter( 'local_result_inferred.isNull && 'localresult.isNotNull )
      .groupBy(
        'groupid, 'client_ds_id, 'code_value, 'dict_name, 'dict_def, 'ref_range, 'order_name, 'data_type, 'specimen_name
        , 'bodysite_name, 'unit_name, 'local_loinc_code, upper( 'localresult ).as( "localresult" ) )
      .agg( count( lit( 1 ) ).as( "localresult_cnt" ) )

      .withColumn( "localresult_rank", row_number.over( groups ) )
      .withColumn( "localresult_formatted",
        when( 'localresult_rank.isin( 1, 2, 3 ),
          concat(
            when( length( 'localresult ) > 300, concat( substring( 'localresult, 1, 297 ), lit( "..." ) ) )
              .otherwise( 'localresult )
            , lit( " (" ), 'localresult_cnt.cast( StringType ), lit( ")" ) ) )
          .when( 'localresult_rank === 4, lit( "+" ) ).otherwise( null ) )

      .withColumn( "localresult_rank", struct( 'localresult_rank, 'localresult_formatted ) )
      .groupBy(
        'groupid, 'client_ds_id, 'code_value, 'dict_name, 'dict_def, 'ref_range, 'order_name, 'data_type, 'specimen_name
        , 'bodysite_name, 'unit_name, 'local_loinc_code )
      .agg( concat_ws( "; ", expr( "sort_array(collect_list(localresult_rank)).localresult_formatted" ) ).alias( "localresult_top" ) )

    labcode_results.createOrReplaceTempView( "labcode_results" )
    val cn = sparkSession.sql(
      """
        |select
        |		groupid, client_ds_id, code_value, dict_name, dict_def, ref_range, order_name, data_type, specimen_name
        |        , bodysite_name, unit_name, local_loinc_code
        |        , count( 1 ) as cnt
        |        , percentile( local_result_inferred, 0.1 ) as percentile10
        |        , percentile( local_result_inferred, 0.25 ) as percentile25
        |        , percentile( local_result_inferred, 0.5 ) as percentile50
        |        , percentile( local_result_inferred, 0.75 ) as percentile75
        |        , percentile( local_result_inferred, 0.9 ) as percentile90
        |        , sum( nvl2( groupid, 1, 0 ) * nvl2( local_result_inferred, 1, 0 )) as cnt_num
        |        , sum( nvl2( groupid, 1, 0 ) * nvl2( localresult, 0, 1 )) as cnt_null
        |from labcode_results
        |group by
        |		groupid, client_ds_id, code_value, dict_name, dict_def, ref_range, order_name, data_type, specimen_name
        |        , bodysite_name, unit_name, local_loinc_code
      """.stripMargin ).toDF()

    cn.as("cn").join( lr.as("lr")
      , $"cn.groupid" === $"lr.groupid" &&  $"cn.client_ds_id" === $"lr.client_ds_id" && $"cn.code_value" === $"lr.code_value" &&
          coalesce($"cn.dict_name", lit(1)) === coalesce($"lr.dict_name", lit(1)) && coalesce($"cn.dict_def",lit(1)) === coalesce($"lr.dict_def",lit(1))
          && coalesce($"cn.ref_range",lit("nulljoin")) === coalesce($"lr.ref_range",lit("nulljoin")) && coalesce($"cn.order_name",lit("nulljoin")) === coalesce($"lr.order_name",lit("nulljoin"))
          && coalesce($"cn.data_type",lit(1)) === coalesce($"lr.data_type",lit(1))
          && coalesce($"cn.specimen_name",lit("nulljoin")) === coalesce($"lr.specimen_name",lit("nulljoin")) && coalesce($"cn.unit_name",lit("nulljoin")) === coalesce($"lr.unit_name",lit("nulljoin"))
          && coalesce($"cn.local_loinc_code",lit(1)) === coalesce($"lr.local_loinc_code",lit(1)) &&  coalesce($"cn.bodysite_name",lit(1))  === coalesce($"lr.bodysite_name",lit(1))
    , "left_outer" )
      .select(
        $"cn.groupid",
        $"cn.client_ds_id", $"cn.code_value", $"cn.dict_name", $"cn.dict_def", $"cn.ref_range", $"cn.order_name", $"cn.data_type", $"cn.specimen_name"
        , $"cn.bodysite_name", $"cn.unit_name", $"cn.local_loinc_code", 'cnt.cast( IntegerType ).as( "cnt" )
        , 'percentile10, 'percentile25, 'percentile50, 'percentile75, 'percentile90
        , 'percentile10.as( "percentile10_num" )
        , 'percentile25.as( "percentile25_num" )
        , 'percentile50.as( "percentile50_num" )
        , 'percentile75.as( "percentile75_num" )
        , 'percentile90.as( "percentile90_num" )
        , substring( 'localresult_top, 1, 1000 ).as( "localresult_text" )
        , ('cnt_num / 'cnt).as( "percent_num" )
        , ('cnt_null / 'cnt).as( "percent_null" )
        , (('cnt - 'cnt_num - 'cnt_null) / ('cnt)).as( "percent_text" )
        , lit( 0 ).as( "cnt_localinf_notnull" )
        , lit( 0 ).as( "cnt_localres_null" )
        , 'cnt_num.cast( IntegerType ).as( "cnt_num" )
        , 'cnt_null.cast( IntegerType ).as( "cnt_null" )
        , ('cnt - 'cnt_num - 'cnt_null).cast( IntegerType ).as( "cnt_text" )
      )
  }
}
