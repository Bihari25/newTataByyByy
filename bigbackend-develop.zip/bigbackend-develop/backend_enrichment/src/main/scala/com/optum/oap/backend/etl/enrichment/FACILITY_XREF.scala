package com.optum.oap.backend.etl.enrichment

import com.optum.oap.backend.cdrTempModel.facility_xref
import com.optum.oap.cdr.models.zh_facility
import com.optum.oap.backend.etl.common.XrefUtil
import com.optum.oap.backend.loader.EnrichmentRunTimeVariables
import com.optum.oap.sparkdataloader.{RuntimeVariables, TableInfo, UserDefinedFunctionForDataLoader}
import org.apache.spark.sql.functions._
import org.apache.spark.sql.types.IntegerType
import org.apache.spark.sql.{DataFrame, SparkSession}
import org.slf4j.LoggerFactory

object FACILITY_XREF extends TableInfo[facility_xref] {

  val log = LoggerFactory.getLogger(this.getClass)

  override def dependsOn = Set("ZH_FACILITY", "COMMON_FACILITY_XREF", "CDR_FE_FACILITY_XREF")

  override def name = "FACILITY_XREF"

  override def createDataFrame(sparkSession: SparkSession,
                               loadedDependencies: Map[String, DataFrame],
                               udfMap: Map[String, UserDefinedFunctionForDataLoader],
                               runtimeVariables: RuntimeVariables): DataFrame = {
    import sparkSession.implicits._
    implicit val session = sparkSession

    val zhFacilityIn = loadedDependencies("ZH_FACILITY").as[zh_facility]
    val commFacilityXref = loadedDependencies("COMMON_FACILITY_XREF").as[facility_xref]

    val enrichmentRunTimeVariables = EnrichmentRunTimeVariables(runtimeVariables)

    if (!enrichmentRunTimeVariables.cdrSchema.equals("test")) {
      logger.warn(s"Refreshing $name table")
      sparkSession.catalog.recoverPartitions(s"${enrichmentRunTimeVariables.cdrSchema}.$name")
    }

    val numOfPartitions = Math.ceil(partitions * enrichmentRunTimeVariables.partitionMultiplier).toInt
    val xrefUtil = new XrefUtil()

    val facilityXref = if (commFacilityXref.isEmpty) {
      val feFacilityXref = loadedDependencies("CDR_FE_FACILITY_XREF").as[facility_xref]
      val df = feFacilityXref.select($"groupid", $"facilityid", $"hgfacid", $"client_ds_id",
        date_format(current_date(), "yyyyMMdd").cast(IntegerType).as("partition_date"),
        $"hgfacid".as("hgfacid_without_groupid"))

      xrefUtil.writeInitialXrefData(df, runtimeVariables, "FACILITY_XREF")
    } else {
      log.warn(s"FACILITY_XREF table is NOT empty at common location, count: ${commFacilityXref.count}")
      if (enrichmentRunTimeVariables.cdrSchema.equals("test")) {
        commFacilityXref
      } else {
        sparkSession.read.parquet(s"${enrichmentRunTimeVariables.commonPath}/$name")
      }
    }

    val diffFacDf = getNewFacilityRecords(sparkSession, facilityXref.toDF(), zhFacilityIn.toDF())

    val diffCount = diffFacDf.count()
    val returnDf = if (diffCount > 0) {
      logger.warn(s"Inside FACILITY_XREF diff df, count: ${diffCount}")
      xrefUtil.writeNewXrefRecords(facilityXref.toDF(), diffFacDf, $"hgfacid_without_groupid", "hgfacid", runtimeVariables, "FACILITY_XREF", numOfPartitions)
    } else {
      log.warn(s"As there are no new records, skipping writing to FACILITY_XREF")
      sparkSession.emptyDataset[facility_xref].toDF()
    }

    returnDf
  }

  /**
   *
   * @param sparkSession session
   * @param facilityXref facility_xref dataframe
   * @param zhFacilityIn zh_facility dataframe
   * @return returns the records that are in zh_facility but not in facility_xref when joined on facilityid and client_ds_id
   */
  def getNewFacilityRecords(sparkSession: SparkSession, facilityXref: DataFrame, zhFacilityIn: DataFrame) : DataFrame = {
    import sparkSession.implicits._
    zhFacilityIn.as("fac")
      .join(facilityXref.as("ref"), $"fac.groupid" === $"ref.groupid" && $"fac.facilityid" === $"ref.facilityid" && $"fac.client_ds_id" === $"ref.client_ds_id", "left_outer")
      .where($"ref.facilityid".isNull)
      .select($"fac.groupid",
        $"fac.facilityid",
        $"fac.client_ds_id").distinct().withColumn("partition_date",  date_format(current_date(), "yyyyMMdd").cast(IntegerType))
  }

}
