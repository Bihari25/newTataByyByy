package com.optum.oap.backend.etl.enrichment

import com.optum.oap.backend.etl.common.MapMasterIds
import com.optum.oap.cdr.models.{zh_provider_contact, zh_provider_master_xref}
import com.optum.oap.sparkdataloader.{RuntimeVariables, TableInfo, UserDefinedFunctionForDataLoader}
import org.apache.spark.sql.functions.broadcast
import org.apache.spark.sql.{DataFrame, SparkSession}
import org.slf4j.LoggerFactory

object ZH_PROVIDER_CONTACT extends TableInfo[zh_provider_contact] {

  val log = LoggerFactory.getLogger(this.getClass)

  override def dependsOn = Set("ZH_PROVIDER_MASTER_XREF", "CDR_FE_ZH_PROVIDER_CONTACT", "ICPM_ZH_PROVIDER_CONTACT")

  override def name = "ZH_PROVIDER_CONTACT"

  override def saveDataFrameToParquet: Boolean = true

  override def partitions: Int = 32

  override def skipTable: Boolean = false

  override def ignoreExtraColumnsInDataFrame: Boolean = true

  override def createDataFrame(sparkSession: SparkSession,
                               loadedDependencies: Map[String, DataFrame],
                               udfMap: Map[String, UserDefinedFunctionForDataLoader],
                               runtimeVariables: RuntimeVariables): DataFrame = {
    import sparkSession.implicits._

    val zh_provider_contactIn = loadedDependencies("CDR_FE_ZH_PROVIDER_CONTACT").drop("row_source","modified_date").as[zh_provider_contact]
    /* Dataframe from ICPM stage 2. This may be required for some client Ids. */
    val zhProviderContactIcpm = loadedDependencies("ICPM_ZH_PROVIDER_CONTACT").as[zh_provider_contact]
    val provXref = broadcast(loadedDependencies("ZH_PROVIDER_MASTER_XREF")).as[zh_provider_master_xref]

    val zhProviderContactUnion = zh_provider_contactIn.unionByName(zhProviderContactIcpm)

    MapMasterIds.mapProviderIds(zhProviderContactUnion.toDF, provXref.toDF, "local_provider_id", "master_hgprovid")
  }

}
