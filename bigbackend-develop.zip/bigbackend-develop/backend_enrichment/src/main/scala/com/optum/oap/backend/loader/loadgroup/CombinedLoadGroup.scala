package com.optum.oap.backend.loader.loadgroup
import com.optum.oap.backend.loader.{BeSummaryDependencies, BpoDependencies, DataTableDependencies, EnrichmentQueryRegistry, EnrichmentRunTimeVariables, GitHubBpoConfigReader, S3BpoConfigReader, StaticDependencies}
import com.optum.oap.sparkdataloader.TableInfo
import org.apache.spark.sql.SparkSession

trait CombinedLoadGroup extends LoadGroup {

  override def loadGroup: String = "combine"

  override def initialDependencies(runTimeVariables: EnrichmentRunTimeVariables, sparkSession: SparkSession): Seq[TableInfo[_ <: Product with Serializable]] = {
    import runTimeVariables._

    if (buildType.equalsIgnoreCase("Delta")) {
      DataTableDependencies.dataInitialDependencies(cdrSchema) ++
        StaticDependencies.staticInitialDependencies(cdrSchema) ++
        BeSummaryDependencies.cdrBeSummaryInitialDependencies(cdrSchema)
    } else {
      DataTableDependencies.dataInitialDependencies(cdrSchema) ++
        StaticDependencies.staticInitialDependencies(cdrSchema) ++
        BpoDependencies.bpoCombinedDependencies(cdrSchema) ++
        BeSummaryDependencies.cdrBeSummaryInitialDependencies(cdrSchema)
    }
  }

  override def queryRegistry(runTimeVariables: EnrichmentRunTimeVariables, sparkSession: SparkSession): Seq[TableInfo[_ <: Product with Serializable]] = {
    super.refreshXRefTables(runTimeVariables, sparkSession)
    if(runTimeVariables.buildType.equalsIgnoreCase("Delta")) {
      ( EnrichmentQueryRegistry.encgrpsQueryRegistry ++ EnrichmentQueryRegistry.summaryQueryRegistry(runTimeVariables)).distinct
    } else {
      val bpoConfigReader = if (runTimeVariables.clientBucket.isEmpty) GitHubBpoConfigReader() else S3BpoConfigReader()
      val bpoComponents = bpoConfigReader
        .constructBpoComponents(clientId = runTimeVariables.clientId,
          release = runTimeVariables.release,
          cdrCycle = runTimeVariables.cdrCycle)

      EnrichmentQueryRegistry.bpoQueryRegistry(bpoComponents) ++
        EnrichmentQueryRegistry.encgrpsQueryRegistry ++
        EnrichmentQueryRegistry.summaryQueryRegistry(runTimeVariables) ++ super.queryRegistry(runTimeVariables, sparkSession)
    }
  }
}
