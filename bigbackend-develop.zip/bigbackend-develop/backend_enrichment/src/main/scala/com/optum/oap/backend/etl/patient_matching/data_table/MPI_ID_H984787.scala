package com.optum.oap.backend.etl.patient_matching.data_table

import com.optum.oap.backend.cdrTempModel.patient_xref
import com.optum.oap.backend.etl.common.{CDRConstants, EnrichmentUtils, PartitionedDataOperations}
import com.optum.oap.backend.loader.EnrichmentRunTimeVariables
import com.optum.oap.cdr.models.{mpi_id, patient_id}
import com.optum.oap.sparkdataloader.{RuntimeVariables, TableInfo, UserDefinedFunctionForDataLoader}
import org.apache.spark.sql.expressions.Window
import org.apache.spark.sql.functions.{collect_set, concat, lit, size}
import org.apache.spark.sql.types.LongType
import org.apache.spark.sql.{DataFrame, SparkSession}

object MPI_ID_H984787 extends TableInfo[mpi_id] with PartitionedDataOperations {

  override def dependsOn: Set[String] = Set("PATIENT_ID_PREMATCH", "V_PATIENT_XREF", "ECDR_MPI_ID_H984787")

  override def name: String = "MPI_ID_H984787"


  override def createDataFrame(sparkSession: SparkSession,
                               loadedDependencies: Map[String, DataFrame],
                               udfMap: Map[String, UserDefinedFunctionForDataLoader],
                               runtimeVariables: RuntimeVariables): DataFrame = {

    import sparkSession.implicits._
    implicit val session = sparkSession
    val schema = EnrichmentRunTimeVariables(runtimeVariables).cdrSchema
    val dailyBuild = if (runtimeVariables.asInstanceOf[EnrichmentRunTimeVariables].buildType == CDRConstants.DELTA_BUILD_TYPE) true else false

    val client_ds_id_check = List(6211, 6284, 6287)

    val patientId = loadedDependencies("PATIENT_ID_PREMATCH").as[patient_id]
      .where($"idvalue".isNotNull && $"idtype" === lit("MRN") && $"client_ds_id".isin(client_ds_id_check: _*))
    val pXref = loadedDependencies("V_PATIENT_XREF").as[patient_xref]
    val patientXref = if(pXref.isEmpty) loadData(schema, "V_PATIENT_XREF").as[patient_xref] else pXref
    val window = Window.partitionBy(concat($"idvalue", $"client_ds_id"))

    val dataDf = patientId.as("a")
      .join(patientXref.as("b"), Seq("groupid", "client_ds_id", "patientid"), "inner")
      .groupBy($"a.groupid", $"a.client_ds_id", $"a.patientid", $"b.hgpid",
        concat($"idvalue", $"client_ds_id").as("idvalue"), $"a.idtype")
      .agg(
        size(collect_set("a.groupid").over(window)).as("group_cnt"),
        size(collect_set("b.hgpid").over(window)).cast(LongType).as("hgpids")
      )
      .withColumn("idqual", lit("MRN"))

    val ecdrDf = {
      if (dailyBuild) EnrichmentUtils.removeRowSourceAndModifiedDate(loadedDependencies("ECDR_MPI_ID_H984787")).as[mpi_id]
      else sparkSession.emptyDataset[mpi_id].as[mpi_id]
    }.as("e")
      .select($"e.*")

    dataDf.unionByName(ecdrDf).distinct()
  }


}
