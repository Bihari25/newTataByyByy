package com.optum.oap.backend.etl.patient_matching.data_table

import com.optum.oap.backend.cdrTempModel.pat_match_prep
import com.optum.oap.backend.etl.common.{CDRConstants, CleanPatientName, EnrichmentUtils}
import com.optum.oap.backend.loader.EnrichmentRunTimeVariables
import com.optum.oap.cdr.models.{map_gender, mpi_dsid, patientdetail}
import com.optum.oap.sparkdataloader.{RuntimeVariables, TableInfo, UserDefinedFunctionForDataLoader}
import org.apache.spark.sql.expressions.Window
import org.apache.spark.sql.functions._
import org.apache.spark.sql.types.{LongType, StringType}
import org.apache.spark.sql.{DataFrame, SparkSession}

object MPI_DSID extends TableInfo[mpi_dsid] {

  val partitionKey: String = "dob"

  override def dependsOn = Set("PAT_MATCH_PREP", "PATIENTDETAIL_PREMATCH", "MAP_GENDER", "ECDR_MPI_DSID")

  override def name = "MPI_DSID"

  override def saveDataFrameToParquet: Boolean = true

  override def createDataFrame(sparkSession: SparkSession,
                               loadedDependencies: Map[String, DataFrame],
                               udfMap: Map[String, UserDefinedFunctionForDataLoader],
                               runtimeVariables: RuntimeVariables): DataFrame = {
    import sparkSession.implicits._

    val dailyBuild = if (runtimeVariables.asInstanceOf[EnrichmentRunTimeVariables].buildType == CDRConstants.DELTA_BUILD_TYPE) true else false

    val patMatchPrep = loadedDependencies("PAT_MATCH_PREP")
      .where($"dob".isNotNull).as[pat_match_prep]
    val patientDetailGender = loadedDependencies("PATIENTDETAIL_PREMATCH")
      .where($"patientdetailtype" === lit("GENDER")).as[patientdetail]
    val patientDetailZipCode = loadedDependencies("PATIENTDETAIL_PREMATCH")
      .where($"patientdetailtype" === lit("ZIPCODE")).as[patientdetail]
    val mapGender = broadcast(loadedDependencies("MAP_GENDER").as[map_gender])
    val dobWindow = Window.partitionBy($"dob")

    val dataDf = patMatchPrep.as("ps")
      .join(patientDetailGender.as("pd"), Seq("client_ds_id", "patientid"), "left")
      .join(mapGender.as("mg"),
        $"mg.mnemonic" === $"pd.localvalue" && $"pd.groupid" === $"mg.groupid", "left")
      .join(patientDetailZipCode.as("pa"), Seq("client_ds_id", "patientid"), "left")
      .select( $"ps.groupid", $"ps.client_ds_id", $"ps.patientid", $"ps.hgpid", $"dob",
        $"mg.cui".as("gender"),
        upper($"fname").as("first_name"),
        upper($"lname").as("last_name"),
        upper(substring($"fname", 0, 1)).as("first_init"),
        upper(substring($"lname", 0, 1)).as("last_init"),
        upper(regexp_extract($"fname", "^([^ ,]{1,})", 1)).as("first_word"),
        when($"ps.client_ds_id".isInCollection(CDRConstants.STL_DS_IDS), "STL")
          .when($"ps.client_ds_id".isInCollection(CDRConstants.WIS_DS_IDS), "WIS")
          .otherwise(lit(null).cast(StringType)).as("dsid_grp"),
        when(substring(trim(upper($"fname")), 1, 4).isin("BABY", "TWIN", "FEMA", "MALE")
          && substring(trim(upper($"fname")), -2, 2).isin(" A", " B", " 1", " 2", "-A", "-B", "-1", "-2"), trim(upper($"fname")))
          .otherwise(CleanPatientName.cleanPatientName($"fname", lit(3))).as("adjfirst"),
        CleanPatientName.cleanPatientName($"lname", lit(3)).as("adjlast"),
        lit(null).cast(StringType).as("city"),
        lit(null).cast(StringType).as("state"),
        substring($"pa.localvalue", 0, 5).cast(StringType).as("zipcode")
      )
      .select(
        substring($"first_name", 1, 3).as("first_name"),
        $"last_name",
        $"zipcode",
        $"groupid",
        $"client_ds_id",
        $"patientid",
        $"hgpid",
        $"dob",
        $"gender",
        upper(substring($"adjfirst", 0, 1)).as("first_init"),
        upper(substring($"adjlast", 0, 1)).as("last_init"),
        when( substring(upper($"adjfirst"), -2, 1) === lit(" "),
          upper($"adjfirst").substr( lit(0), length($"adjfirst") - lit(2))
        ).otherwise(upper($"adjfirst")).as("first_no_int"),
        upper(regexp_extract($"adjfirst", "^([^ ,]{1,})", 1)).as("first_word"),
        $"dsid_grp",
        size(collect_set("groupid").over(dobWindow)).as("group_cnt"),
        size(collect_set("hgpid").over(dobWindow)).cast(LongType).as("hgpids"),
        $"adjfirst".as("adj_firstname"),
        $"adjlast".as("adj_lastname")
      ).distinct

    val ecdrDf = {
      if (dailyBuild) EnrichmentUtils.removeRowSourceAndModifiedDate(loadedDependencies("ECDR_MPI_DSID")).as[mpi_dsid]
      else sparkSession.emptyDataset[mpi_dsid].as[mpi_dsid]
    }.as("e")
      .select($"e.*")

    dataDf.unionByName(ecdrDf).distinct()
  }
}
