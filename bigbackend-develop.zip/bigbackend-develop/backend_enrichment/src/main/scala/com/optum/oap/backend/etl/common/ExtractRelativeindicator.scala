package com.optum.oap.backend.etl.common

import com.optum.oap.sparkdataloader.UserDefinedFunctionForDataLoader
import org.apache.spark.sql.SparkSession
import org.apache.spark.sql.expressions.UserDefinedFunction
import org.apache.spark.sql.functions.udf

object ExtractRelativeindicator extends UserDefinedFunctionForDataLoader {

  override def name: String = "extract_relativeindicator"

  val extract_relativeindicator: UserDefinedFunction = udf {

    p_txt: String => {

      /*
          Functions in Oracle can handle nulls as valid inputs, even if they primarily operate on a different datatype.
          Those types of functions return nulls if they get null inputs.
          But, Scala methods can't handle nulls this way, so to mimic this behaviour, handling NullPointerException
       */

      try {

        if ("(^|[^<>])[<>]($|[^<>])".r.findFirstIn(p_txt).isDefined) "[<>=]{1}[=]{0,1}".r.findFirstIn(p_txt).get
        else if ("( less | under | lesser )".r.findFirstIn(p_txt.toLowerCase()).isDefined) "<"
        else if ("( above | over | great | greater | \\+)".r.findFirstIn(p_txt.toLowerCase()).isDefined) ">"
        else null

      }
      catch {

        case _: Exception => null

      }
    }
  }

  override def registerMe(sparkSession: SparkSession): Unit = {
    sparkSession.udf.register(name, extract_relativeindicator)
  }
}