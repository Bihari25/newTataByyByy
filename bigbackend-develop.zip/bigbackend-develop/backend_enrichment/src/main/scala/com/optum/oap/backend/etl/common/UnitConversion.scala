package com.optum.oap.backend.etl.common

import com.optum.oap.backend.etl.common.UnitConversionFunction.UnitConversionFunction

import scala.math.BigDecimal
import scala.math.BigDecimal.RoundingMode
import scala.math.BigDecimal.RoundingMode.RoundingMode

trait UnitConversion {
  def applyUnitConversionFunction(srcValue: Double, function: UnitConversionFunction): java.lang.Double =
    function match {
      case UnitConversionFunction.LINEAR => srcValue
      case UnitConversionFunction.LOG10 => scala.math.log10(srcValue)
      case UnitConversionFunction.LOG2 => scala.math.log(srcValue) / scala.math.log(2)
      case UnitConversionFunction.TEMPTOC => farenheitToCelsius(srcValue)
      case UnitConversionFunction.TEMP_60_LOGIC => if (srcValue < 60) srcValue else farenheitToCelsius(srcValue)
      case _ => srcValue
    }

  def farenheitToCelsius(temperature: java.lang.Double): java.lang.Double = (temperature - 32) * 5 / 9

  def roundDouble(value: Double, precision: Int = 2, roundingMode: RoundingMode = RoundingMode.HALF_UP): Double = {
    BigDecimal(value).setScale(precision, roundingMode).toDouble
  }
}