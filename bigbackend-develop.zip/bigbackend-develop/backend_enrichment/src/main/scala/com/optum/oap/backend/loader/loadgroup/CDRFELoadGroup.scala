package com.optum.oap.backend.loader.loadgroup
import com.optum.oap.backend.etl.cdrfe.CDRFERegistry
import com.optum.oap.backend.etl.cdrfe.config.{CDRFEAWSConfigReader, CDRFEGithubConfigReader}
import com.optum.oap.backend.loader.EnrichmentRunTimeVariables
import com.optum.oap.sparkdataloader.TableInfo
import org.apache.spark.sql.SparkSession

trait CDRFELoadGroup extends LoadGroup {

  override def loadGroup: String = "cdrfe"

  override def initialDependencies(runTimeVariables: EnrichmentRunTimeVariables, sparkSession: SparkSession): Seq[TableInfo[_ <: Product with Serializable]] = {
    Seq.empty
  }

  override def queryRegistry(runTimeVariables: EnrichmentRunTimeVariables, sparkSession: SparkSession): Seq[TableInfo[_ <: Product with Serializable]] = {
    import runTimeVariables._
    val queryRegistry = if (isInAWS) {
      val feRegistry = new CDRFERegistry(runTimeVariables) with CDRFEAWSConfigReader
      feRegistry.getCDRFEEntities
    } else {
      val cdrFERegistry = new CDRFERegistry(runTimeVariables) with CDRFEGithubConfigReader
      cdrFERegistry.getCDRFEEntities
    }

    queryRegistry ++ super.queryRegistry(runTimeVariables, sparkSession)
  }
}
