package com.optum.oap.backend.etl.encgrps

import com.optum.oap.cdr.models.proc_icd_encgrp
import com.optum.oap.sparkdataloader.QueryAndMetadata

object PROC_ICD_ENCGRP extends QueryAndMetadata[proc_icd_encgrp] {
  override def name: String = "PROC_ICD_ENCGRP"

  override def partitions: Int = 32

  override def sparkSql: String =
    """
      |SELECT DISTINCT
      |    codetype,
      |    mappedcode,
      |    cui,
      |    is_ambulatory,
      |    cnt
      |  FROM
      |    mapproc_icd
    """.stripMargin

  override def dependsOn: Set[String] = Set("MAPPROC_ICD")
}
