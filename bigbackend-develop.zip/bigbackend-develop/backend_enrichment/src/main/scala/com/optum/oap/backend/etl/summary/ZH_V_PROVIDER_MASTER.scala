package com.optum.oap.backend.etl.summary

import com.optum.oap.cdr.models.{cui_specialty, map_provider_taxonomy, map_specialty, ref_primaryspecialty, specialty_group_cohort, zh_provider_master, zh_v_provider_master}
import com.optum.oap.sparkdataloader.{RuntimeVariables, TableInfo, UserDefinedFunctionForDataLoader}
import org.apache.spark.sql.types.StringType
import org.apache.spark.sql.{DataFrame, SparkSession}

object ZH_V_PROVIDER_MASTER extends TableInfo[zh_v_provider_master] {
  override def dependsOn: Set[String] = Set(
    "ZH_PROVIDER_MASTER",
    "MAP_SPECIALTY",
    "CUI_SPECIALTY",
    "SPECIALTY_GROUP_COHORT",
    "REF_PRIMARYSPECIALTY",
    "MAP_PROVIDER_TAXONOMY")

  override protected def createDataFrame(sparkSession: SparkSession,
                                         loadedDependencies: Map[String, DataFrame],
                                         udfMap: Map[String, UserDefinedFunctionForDataLoader],
                                         runtimeVariables: RuntimeVariables): DataFrame = {
    import sparkSession.implicits._
    import org.apache.spark.sql.functions._

    val zhProviderMaster = loadedDependencies("ZH_PROVIDER_MASTER").as[zh_provider_master]
    val mapSpeciality = broadcast(loadedDependencies("MAP_SPECIALTY")).as[map_specialty]
    val cuiSpeciality = broadcast(loadedDependencies("CUI_SPECIALTY")).as[cui_specialty]
    val specialityGroupCohort = loadedDependencies("SPECIALTY_GROUP_COHORT").as[specialty_group_cohort]
    val refPrimarySpeciality = broadcast(loadedDependencies("REF_PRIMARYSPECIALTY")).as[ref_primaryspecialty]
    val mapProviderTaxonomy = broadcast(loadedDependencies("MAP_PROVIDER_TAXONOMY")).as[map_provider_taxonomy]

    zhProviderMaster.as("p")
      .join(mapSpeciality.as("ms"), $"p.localprimaryspecialty" === $"ms.mnemonic", "left_outer")
      .join(cuiSpeciality.as("psc"), $"ms.cui" === $"psc.cui", "left_outer")
      .join(specialityGroupCohort.as("sgc").where($"sgc.cohort" === lit("CH001103")), $"ms.cui" === $"sgc.specialty_cui", "left_outer")
      .join(cuiSpeciality.as("csg"), $"sgc.specialty_group_cui" === $"csg.cui", "left_outer")
      .join(refPrimarySpeciality.as("ps"), $"p.npi" === $"ps.npi", "left_outer")
      .join(mapProviderTaxonomy.as("dsc"), $"ps.primarycode" === $"dsc.taxonomy_code", "left_outer")
      .join(cuiSpeciality.as("nsc"), $"dsc.specialty_cui" === $"nsc.cui", "left_outer")
      .join(specialityGroupCohort.as("nsgc").where($"nsgc.cohort" === lit("CH001103")), $"nsgc.specialty_cui" === $"dsc.specialty_cui", "left_outer")
      .join(cuiSpeciality.as("ncsg"), $"nsgc.specialty_group_cui" === $"ncsg.cui", "left_outer")
      .select(
        $"p.groupid".as("groupid"),
        $"p.master_hgprovid".as("master_hgprovid"),
        $"p.npi".as("npi"),
        trim($"p.providername").as("providername"),
        $"p.localprimaryspecialty".as("localprimaryspecialty"),
        $"p.primaryfacilityid".as("primaryfacilityid"),
        $"ms.cui".as("primaryspecialty"),
        $"psc.name".as("primspecname"),
        $"sgc.specialty_group_cui".as("primspecgrp"),
        $"csg.name".as("primspecgroupname"),
        $"ps.primarycode".as("npiprimarycode"),
        $"dsc.specialty_cui".as("npiprimaryspecialty"),
        $"nsc.name".as("npiprimspecname"),
        $"nsgc.specialty_group_cui".as("npiprimspecgroup"),
        $"ncsg.name".as("npiprimspecgroupname"),
        $"p.localclassification".as("localclassification"),
        $"p.providerexclusionflag".as("providerexclusionflag"),
        $"p.mappedcredentialtype".as("mappedcredentialtype"),
        lit(null).cast(StringType).as("npi_specialty_id"),
        lit(null).cast(StringType).as("prim_spec"),
        lit(null).cast(StringType).as("prim_spec_src"),
        lit(null).cast(StringType).as("specialty_id")
      ).as[zh_v_provider_master].toDF()
  }
}
