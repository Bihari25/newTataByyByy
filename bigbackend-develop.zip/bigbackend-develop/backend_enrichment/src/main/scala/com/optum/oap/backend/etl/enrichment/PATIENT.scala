package com.optum.oap.backend.etl.enrichment

import com.optum.oap.backend.etl.common.MapMasterIds
import com.optum.oap.cdr.models.{patient, patient_mpi}
import com.optum.oap.sparkdataloader.{RuntimeVariables, TableInfo, UserDefinedFunctionForDataLoader}
import org.apache.spark.sql.functions._
import org.apache.spark.sql.{DataFrame, SparkSession}
import org.slf4j.LoggerFactory

object PATIENT extends TableInfo[patient] {

  val log = LoggerFactory.getLogger(this.getClass)

  override def dependsOn = Set("PATIENT_XWALK_MAPPING", "PATIENT_MPI")

  override def name = "PATIENT"

  override def saveDataFrameToParquet: Boolean = true

  override def partitions: Int = 32

  override def skipTable: Boolean = false

  override def ignoreExtraColumnsInDataFrame: Boolean = true

  override def createDataFrame(sparkSession: SparkSession,
                               loadedDependencies: Map[String, DataFrame],
                               udfMap: Map[String, UserDefinedFunctionForDataLoader],
                               runtimeVariables: RuntimeVariables): DataFrame = {
    import sparkSession.implicits._

    val patientIn = loadedDependencies("PATIENT_XWALK_MAPPING").as[patient]
    val patXref = loadedDependencies("PATIENT_MPI").as[patient_mpi]

    val patientDates = patientIn.withColumn("dateofbirth", when(to_date($"dateofbirth") < lit("1800-01-01") || to_date($"dateofbirth") > date_add(current_date(),30), null).otherwise($"dateofbirth"))
      .withColumn("dateofdeath", when(to_date($"dateofdeath") < lit("1800-01-01") || to_date($"dateofdeath") > date_add(current_date(),30), null).otherwise($"dateofdeath"))

    MapMasterIds.mapPatientIds(patientDates.toDF, patXref.toDF, false)
  }


}
