package com.optum.oap.backend.loader.loadgroup
import com.optum.oap.backend.loader.{BeSummaryDependencies, DataTableDependencies, EnrichmentQueryRegistry, EnrichmentRunTimeVariables, InitialDependencies, StaticDependencies}
import com.optum.oap.sparkdataloader.TableInfo
import org.apache.spark.sql.SparkSession

trait SummaryLoadGroup extends LoadGroup {

  override def loadGroup: String = "summary"

  override def initialDependencies(runTimeVariables: EnrichmentRunTimeVariables, sparkSession: SparkSession): Seq[TableInfo[_ <: Product with Serializable]] = {
    import runTimeVariables._
    DataTableDependencies.dataInitialDependencies(cdrSchema) ++
      StaticDependencies.staticInitialDependencies(cdrSchema) ++
      BeSummaryDependencies.cdrBeSummaryInitialDependencies(cdrSchema)
  }

  override def queryRegistry(runTimeVariables: EnrichmentRunTimeVariables, sparkSession: SparkSession): Seq[TableInfo[_ <: Product with Serializable]] = {
    super.refreshXRefTables(runTimeVariables, sparkSession)
    EnrichmentQueryRegistry.summaryQueryRegistry(runTimeVariables) ++ super.queryRegistry(runTimeVariables, sparkSession)
  }
}
