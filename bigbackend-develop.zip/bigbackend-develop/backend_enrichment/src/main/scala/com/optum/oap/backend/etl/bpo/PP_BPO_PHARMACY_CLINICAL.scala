package com.optum.oap.backend.etl.bpo

import com.optum.oap.backend.cdrTempModel.{temp_bpo_calculate_params, temp_bpo_patients}
import com.optum.oap.backend.etl.bpo.BpoUtil.getBpoInputParameters
import com.optum.oap.backend.etl.common.TimestampTruncate
import com.optum.oap.cdr.models._
import com.optum.oap.sparkdataloader.{RuntimeVariables, TableInfo, UserDefinedFunctionForDataLoader}
import org.apache.spark.sql.expressions.Window
import org.apache.spark.sql.functions._
import org.apache.spark.sql.{DataFrame, SparkSession}

/**
  *
  * Copyright 2019 Optum Analytics
  *
  * Date: 6/10/19
  *
  * Creator: pavula1
  */
object PP_BPO_PHARMACY_CLINICAL extends TableInfo[pp_bpo_pharmacy_clinical] {
  override def dependsOn = Set("IMMUNIZATION", "MAP_DCC_CVX", "TEMP_BPO_CALCULATE_PARAMS", "RXORDER", "RX_PATIENT_REPORTED", "TEMP_BPO_PATIENTS")

  override def name = "PP_BPO_PHARMACY_CLINICAL"

  override def createDataFrame(sparkSession: SparkSession,
                               loadedDependencies: Map[String, DataFrame],
                               udfMap: Map[String, UserDefinedFunctionForDataLoader],
                               runtimeVariables: RuntimeVariables): DataFrame = {

    import com.optum.oap.backend.etl.common.Functions._
    import sparkSession.implicits._

    val immunization = loadedDependencies("IMMUNIZATION").as[immunization]
    val mapDcc = broadcast(loadedDependencies("MAP_DCC_CVX")).as[map_dcc_cvx]
    val tempParams = loadedDependencies("TEMP_BPO_CALCULATE_PARAMS").as[temp_bpo_calculate_params]
    val rxOrder = loadedDependencies("RXORDER").as[rxorder]
    val rxReported = loadedDependencies("RX_PATIENT_REPORTED").as[rx_patient_reported]
    val tempPatients = loadedDependencies("TEMP_BPO_PATIENTS").as[temp_bpo_patients]


    val inputParameters = getBpoInputParameters(sparkSession, tempParams)
    val extractStartDate = inputParameters.engineStartDate
    val extractEndDate = inputParameters.engineEndDate

    val immJoin = immunization.alias("imm")
      .join(mapDcc.alias("m"), $"imm.dcc" === $"m.dcc")
      .where($"grp_mpi".isNotNull && $"preferred" === "Y" && $"localdeferredreason".isNull
        && to_date(coalesce($"admindate", $"documenteddate")).between(lit(extractStartDate), lit(extractEndDate)))
      .select($"groupid",
        $"imm.client_ds_id",
        $"grp_mpi",
        lit("IMM").alias("src"),
        $"imm.dcc",
        $"cvx_code",
        TimestampTruncate.truncate(lit("DAY"), coalesce($"admindate", $"documenteddate")).alias("administration_date")
      )

    val rxJoin = rxOrder.alias("rx").join(mapDcc.alias("m"), $"rx.dcc" === $"m.dcc")
      .where($"grp_mpi".isNotNull && $"preferred" === "Y"
        && to_date($"issuedate").between(lit(extractStartDate) , lit(extractEndDate)))
      .select($"groupid",
        $"rx.client_ds_id",
        $"grp_mpi",
        lit("RXO").alias("src"),
        $"rx.dcc",
        $"cvx_code",
        TimestampTruncate.truncate(lit("DAY"), $"issuedate").alias("administration_date")
      )

    val rxRepoJoin = rxReported.alias("rx").join(mapDcc.alias("m"), $"rx.dcc" === $"m.dcc")
      .where($"grp_mpi".isNotNull && $"preferred" === "Y"
        && coalesce($"medreportedtime", $"actiontime").isNotNull
        && to_date(coalesce($"medreportedtime", $"actiontime")).between(lit(extractStartDate) , lit(extractEndDate)))
      .select($"groupid",
        $"rx.client_ds_id",
        $"grp_mpi",
        lit("RXR").alias("src"),
        $"rx.dcc",
        $"cvx_code",
        TimestampTruncate.truncate(lit("DAY"), coalesce($"medreportedtime", $"actiontime")).alias("administration_date")
      )

    val temp_bpo_cvx = immJoin.union(rxJoin).union(rxRepoJoin)

    val pat = tempPatients.select($"groupid", $"grp_mpi", $"payer",
      row_number().over(Window.partitionBy($"groupid", $"grp_mpi")
        .orderBy($"payer".desc)).alias("rw_id")
    )

    val df = temp_bpo_cvx.alias("t")
      .join(pat.alias("p"), $"t.groupid" === $"p.groupid" && $"t.grp_mpi" === $"p.grp_mpi")
      .where($"p.rw_id" === 1)
      .select(
        $"t.groupid",
        $"t.client_ds_id",
        $"t.grp_mpi",
        lit("CVX").alias("code_taxonomy"),
        $"t.cvx_code".alias("code"),
        $"t.administration_date",
        when($"p.payer" === 1, "PAYER").otherwise("PROVIDER").alias("healthplansource")
      ).distinct()


    //Add rownum
    val withRowNumberDf = appendRowNumberToDataframe(sparkSession, df)

    withRowNumberDf.select($"groupid",
      $"grp_mpi".alias("memberid"),
      concat(lit("PHC"), $"client_ds_id", lit("."), $"rownumber").alias("pharmacy_clinical_id"),
      $"code_taxonomy",
      $"code",
      $"administration_date",
      $"healthplansource"
    )

  }


}
