package com.optum.oap.backend.etl.common

import com.optum.oap.sparkdataloader.QueryAndMetadata

case class OutputColumn(name: String, sparkSqlDataType: Option[String] = None, oracleDataType: Option[String] = None)

case class calendar_data(serial_num: java.lang.Integer, cal_dt: String, dt_dayofmonth: java.lang.Integer, dt_day_name: String, dt_dayofweek: String, dt_dayofyear: java.lang.Integer, dt_weekofyear: java.lang.Integer, dt_quarter: java.lang.Integer, dt_month_mm: String, dt_month_name_abbrev: String, dt_month_name: String, dt_year: java.lang.Integer, dt_yr_month: String)

object CALENDAR extends QueryAndMetadata[calendar_data] {
  override def name: String = "CALENDAR"
  override def dependsOn: Set[String] = Set.empty[String]
  override def saveDataFrameToParquet: Boolean = true

  override def sparkSql: String =
    """
       select col.Serial_Num, col.CAL_DT, col.DT_DAYOFMONTH, col.DT_DAY_NAME, col.DT_DAYOFWEEK, col.DT_DAYOFYEAR, col.DT_WEEKOFYEAR, col.DT_QUARTER, col.DT_MONTH_MM, col.DT_MONTH_NAME_ABBREV, col.DT_MONTH_NAME, col.DT_YEAR, col.DT_yr_month
       from (
          select explode(calendarUDF(to_date('1801-01-01', 'yyyy-MM-dd'), to_date('2040-01-01', 'yyyy-MM-dd')))
       ) cal
    """

  def originalSql: String = """ """

  def outputColumns: Option[Seq[OutputColumn]] = Some(
    List(
      OutputColumn("Serial_Num", None, None),
      OutputColumn("CAL_DT", None, None),
      OutputColumn("DT_DAYOFMONTH", None, None),
      OutputColumn("DT_DAY_NAME", None, None),
      OutputColumn("DT_DAYOFWEEK", None, None),
      OutputColumn("DT_DAYOFYEAR", None, None),
      OutputColumn("DT_WEEKOFYEAR", None, None),
      OutputColumn("DT_QUARTER", None, None),
      OutputColumn("DT_MONTH_MM", None, None),
      OutputColumn("DT_MONTH_NAME_ABBREV", None, None),
      OutputColumn("DT_MONTH_NAME", None, None),
      OutputColumn("DT_YEAR", None, None),
      OutputColumn("DT_yr_month", None, None)
    ))

}
