package com.optum.oap.backend.etl.encgrps

import com.optum.oap.backend.cdrTempModel.temp_visit_enctr
import com.optum.oap.backend.etl.common.{CDRConstants, TimestampTruncate}
import com.optum.oap.sparkdataloader.{RuntimeVariables, TableInfo, UserDefinedFunctionForDataLoader}
import com.optum.oap.backend.loader.EnrichmentRunTimeVariables
import org.apache.spark.sql.functions._
import org.apache.spark.sql.types.DoubleType
import org.apache.spark.sql.{DataFrame, SparkSession}

object TEMP_VISIT_ENCTR extends TableInfo[temp_visit_enctr] {
  override def name: String = "TEMP_VISIT_ENCTR"

  override def partitions: Int = 512

  override def dependsOn: Set[String] = Set("ZH_FACILITY_ROLLUP","MAP_VISIT_EXCLUDE","MAP_ADMIT_SOURCE","MAP_PATIENT_TYPE","CLINICALENCOUNTER","MAP_DRG_TYPE","MAP_DISCHARGE_DISPOSITION","MAP_PREDICATE_VALUES","CLAIM")

  override protected def createDataFrame(sparkSession: SparkSession, loadedDependencies: Map[String, DataFrame],
                                         udfMap: Map[String, UserDefinedFunctionForDataLoader],
                                         runtimeVariables: RuntimeVariables): DataFrame = {

    import sparkSession.implicits._
    implicit val spark = sparkSession

    val zhFacilityRollup = broadcast(loadedDependencies("ZH_FACILITY_ROLLUP"))
    val mapVisitExclude = broadcast(loadedDependencies("MAP_VISIT_EXCLUDE"))
    val mapAdmitSource = broadcast(loadedDependencies("MAP_ADMIT_SOURCE"))
    val mapPatientType = broadcast(loadedDependencies("MAP_PATIENT_TYPE"))
    val clinicalEncounter = loadedDependencies("CLINICALENCOUNTER")
    val mapDrgType = broadcast(loadedDependencies("MAP_DRG_TYPE"))
    val mapDischargeDisposition = broadcast(loadedDependencies("MAP_DISCHARGE_DISPOSITION"))
    val mapPredicateValues = broadcast(
      loadedDependencies("MAP_PREDICATE_VALUES").where( $"data_src" === "ALL" and $"entity" === "ENCOUNTER_GRPS_ALL" and
          $"table_name" === "TEMP_VISIT_ENCTR" and $"column_name" === "ALTID_EXCL" and $"column_value" === "Y")
    )

    val tClaim = loadedDependencies("CLAIM").where($"mappedrev" >= "0100" && $"mappedrev" <= "0219")
    val tRBEnctr = tClaim.select($"client_ds_id", $"encounterid").distinct()

    val tRBEDsCollect = tRBEnctr.select($"client_ds_id").distinct().as[Int].collect()
    val tRBEDs = broadcast(dataframe(tRBEDsCollect: _*))

    val tempVisit = clinicalEncounter.as("ce")
      .where($"ce.grp_mpi".isNotNull and $"client_ds_id".isNotNull)
      .join(mapPatientType.as("pt"), $"ce.groupid" === $"pt.groupid" and $"ce.localpatienttype" === $"pt.local_code", "left_outer")
      .join(mapAdmitSource.as("mas"), $"ce.localadmitsource" === $"mas.localcode" and $"ce.groupid" === $"mas.groupid", "left_outer")
      .join(mapDischargeDisposition.as("mdd"), $"ce.localdischargedisposition" === $"mdd.mnemonic" and $"ce.groupid" === $"mdd.groupid", "left_outer")
      .join(mapDrgType.as("mdt"), $"mdt.groupid" === $"ce.groupid" and $"mdt.code" === coalesce($"ce.localdrgtype", lit("MSDRG")), "left_outer")
      .join(mapPredicateValues.as("mpv"), $"ce.groupid" === $"mpv.groupid" and $"ce.client_ds_id" === $"mpv.client_ds_id", "left_outer")
      .join(zhFacilityRollup.as("fr"), $"ce.groupid" === $"fr.groupid" and $"ce.client_ds_id" === $"fr.client_ds_id" and $"ce.facilityid" === $"fr.facility_id", "left_outer")
      .select(
        $"ce.groupid",
        $"ce.patientid",
        $"ce.grp_mpi",
        $"ce.hgpid",
        $"ce.client_ds_id",
        $"ce.localpatienttype",
        coalesce($"ce.inferred_pat_type", $"pt.cui", lit("CH999999")).as("patienttype"),
        $"ce.datasrc",
        when(
          not(coalesce($"pt.cui", lit("CH999999")).isin("CH000106","CH000107","CH000109","CH000113")), "SUPPORT"
        ).when(
          $"ce.datasrc".isin("encounters","abstractdata","encountervisit","hosp_patient","inp_discharges","patientencounter"), "MASTER-P"
        ).when(
          $"ce.datasrc".isin("patient_encounter", "hl7_Segment_Pv1_a") or $"ce.datasrc".startsWith("837I"), "MASTER-S"
        ).otherwise("PROF").as("datasrc_type"),
        $"ce.encounterid",
        $"ce.alt_encounterid",
        $"ce.arrivaltime".as("orig_arrivaltime"),
        when(
          $"ce.admittime".isNull or $"ce.admittime" > current_timestamp() or year($"ce.admittime") === "1900", $"ce.arrivaltime"
        ).when(
          $"ce.arrivaltime" > current_timestamp() or year($"ce.arrivaltime") === "1900", $"ce.admittime"
        ).when(
          to_date($"ce.admittime") > to_date($"ce.arrivaltime"), $"ce.arrivaltime"
        ).when(
          to_date($"ce.admittime") < to_date($"ce.arrivaltime"), $"ce.admittime"
        ).when(
          $"ce.admittime" === TimestampTruncate.truncate(lit("DAY"), $"ce.admittime"), $"ce.arrivaltime"
        ).when(
          $"ce.arrivaltime" === TimestampTruncate.truncate(lit("DAY"), $"ce.arrivaltime"), $"ce.admittime"
        ).otherwise(
          least($"ce.arrivaltime", $"ce.admittime")
        ).as("arrivaltime"),
        $"ce.admittime".as("orig_admittime"),
        when(
          $"ce.admittime".isNull or $"ce.admittime" > current_timestamp() or year($"ce.admittime") === "1900", $"ce.arrivaltime"
        ).when(
          $"ce.arrivaltime".isNull or $"ce.arrivaltime" > current_timestamp() or year($"ce.arrivaltime") === "1900", $"ce.admittime"
        ).when(
          to_date($"ce.admittime") =!= to_date($"ce.arrivaltime"), $"ce.admittime"
        ).otherwise(
          greatest($"ce.arrivaltime", $"ce.admittime")
        ).as("admittime"),
        $"ce.dischargetime".as("orig_dischargetime"),
        greatest(
          when($"ce.dischargetime" > current_timestamp() or year($"ce.dischargetime") === "1900", to_timestamp(lit("19000101"), CDRConstants.DATE_FORMAT_4Y2M2D)).otherwise($"ce.dischargetime"),
          when($"ce.admittime" > current_timestamp() or year($"ce.admittime") === "1900", to_timestamp(lit("19000101"), CDRConstants.DATE_FORMAT_4Y2M2D)).otherwise($"ce.admittime"),
          when($"ce.arrivaltime" > current_timestamp() or year($"ce.arrivaltime") === "1900" or $"ce.arrivaltime" > $"ce.dischargetime", to_timestamp(lit("19000101"), CDRConstants.DATE_FORMAT_4Y2M2D)).otherwise($"ce.arrivaltime")
        ).as("dischargetime"),
        $"ce.facilityid",
        when($"ce.groupid" === "H101623" and $"ce.datasrc".startsWith("837"), null).otherwise($"ce.localdrg").as("drg"),
        when($"ce.groupid" === "H101623" and $"ce.datasrc".startsWith("837"), null).otherwise($"mdt.cui").as("drgtypecui"),
        $"ce.localdischargedisposition",
        $"mdd.cui".as("disposition"),
        $"ce.localadmitsource",
        $"mas.cui".as("admitsource"),
        $"ce.aprdrg_cd",
        $"ce.aprdrg_soi",
        $"ce.aprdrg_rom",
        $"ce.totalcost",
        $"ce.totalcharge",
        $"ce.wasplannedflg",
        when($"ce.groupid".isin("H406239", "H690641"), $"ce.alt_encounterid").otherwise($"fr.master_facility_name").as("master_facility_name"),
        $"ce.elos",
        when($"fr.enctr_grp_flag" === "N" and coalesce($"ce.inferred_pat_type", $"pt.cui", lit("CH999999")).isin("CH000106","CH000107","CH000109","CH000113"), "Y").otherwise("N").as("excl_fac"),
        when(
          $"mpv.client_ds_id".isNotNull,
          when(
            $"ce.alt_encounterid".isNull or coalesce($"ce.alt_encounterid".cast(DoubleType), lit(0d)) === 0, "Y"
          ).otherwise("N")
        ).otherwise("N").as("altid_excl"),
        $"fr.siteofcare_name"
      ).distinct()

    val groupId = runtimeVariables.asInstanceOf[EnrichmentRunTimeVariables].clientId

    tempVisit.as("visit")
      .join(mapVisitExclude.as("mve"), $"mve.groupid" === $"visit.groupid" and $"mve.datasrc" === $"visit.datasrc" and $"mve.patient_type" === $"visit.patienttype", "left_outer")
      .join(tRBEnctr.as("rbent"), $"visit.groupid" === lit(groupId) && $"rbent.client_ds_id" === $"visit.client_ds_id" and $"rbent.encounterid" === $"visit.encounterid", "left_outer")
      .join(tRBEDs.as("rbds"), $"rbds.value" === $"visit.client_ds_id", "left_outer")
      .select(
          $"visit.groupid",
          $"patientid",
          $"hgpid",
          $"grp_mpi",
          $"visit.client_ds_id",
          $"localpatienttype",
          $"visit.patienttype",
          $"visit.datasrc",
          $"datasrc_type",
          $"visit.encounterid",
          $"alt_encounterid",
          $"orig_arrivaltime",
          when(
            $"arrivaltime" === $"admittime" and $"admittime" === $"dischargetime" and (
              minute($"arrivaltime") > 0 or (hour($"arrivaltime") =!= 0 and hour($"arrivaltime") =!= 12)
            ), TimestampTruncate.truncate(lit("DAY"), $"arrivaltime")
          ).otherwise($"arrivaltime").as("arrivaltime"),
          $"orig_admittime",
          when(
            $"admittime" < $"arrivaltime", $"arrivaltime"
          ).when(
            $"arrivaltime" === $"admittime" and $"admittime" === $"dischargetime" and (
              minute($"admittime") > 0 or (hour($"admittime") =!= 0 and hour($"admittime") =!= 12)
            ), TimestampTruncate.truncate(lit("DAY"), $"admittime")
          ).otherwise($"admittime").as("admittime"),
          $"orig_dischargetime",
          when(
            $"dischargetime" < $"arrivaltime", $"arrivaltime"
          ).when(
            $"arrivaltime" === $"admittime" and $"admittime" === $"dischargetime" and (
              minute($"dischargetime") > 0 or (hour($"dischargetime") =!= 0 and hour($"dischargetime") =!= 12)
            ), TimestampTruncate.truncate(lit("DAY"), $"dischargetime")
          ).otherwise($"dischargetime").as("dischargetime"),
          $"facilityid",
          $"drg",
          $"drgtypecui",
          $"localdischargedisposition",
          $"disposition",
          $"localadmitsource",
          $"admitsource",
          $"aprdrg_cd",
          $"aprdrg_soi",
          $"aprdrg_rom",
          $"totalcost",
          round($"totalcharge", 2).as("totalcharge"),
          $"wasplannedflg",
          $"master_facility_name",
          $"elos",
          when($"mve.groupid".isNotNull, "Y")
            .when($"visit.patienttype" === "CH000106" && to_date($"visit.arrivaltime","yyyyMMdd") === to_date($"visit.dischargetime","yyyyMMdd"), "Y")
            .otherwise("N").as("EXCL"),
          $"excl_fac",
          $"altid_excl",
          $"siteofcare_name"
        )
  }
}