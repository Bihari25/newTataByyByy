package com.optum.oap.backend.etl.common

import com.optum.oap.sparkdataloader.UserDefinedFunctionForDataLoader
import org.apache.spark.sql.SparkSession
import org.apache.spark.sql.expressions.UserDefinedFunction
import org.apache.spark.sql.functions.udf
import com.optum.oap.backend.etl.common.ExtractUom.extract_uom_anon
import com.optum.oap.backend.etl.common.ExtractUomRaw.extract_uom_raw_anon
import com.optum.oap.backend.etl.common.IsSafeToNumber.isSafeToNumberFunction

object ExtractValue extends UserDefinedFunctionForDataLoader {

  override def name: String = "extract_value"

  /*
    This function in Oracle can return nulls, integers and floating point values.
    v_numeric is the only 'variable' that will be returned and returns floating point values.
    Rest all that are returned are either nulls or integers (like -4000).
    v_numeric is a NUMBER type in Oracle, but SAFE_TO_NUMBER udf returns BigDecimal (includes padding after decimals).
    v_numeric cannot be returned to a BigDecimal because the result of expr.eval can only be converted to String.
    The converted string cannot be casted to Integer because of decimal values.
    The converted string cannot be casted to Int/Long/Decimal because these are primitive datatypes and cannot hold null, which means null cannot be returned from this udf.
    So, v_numeric is maintained as a string and hence, this udf returns a string as well.
   */

  val extract_value: UserDefinedFunction = udf {

    /*
      There is no support for defining default parameters for anon. functions passed to "udf" method.
      Hence, every time we call extract_value, "p_debug" should be initiated with null if no value is intended to be passed to it.
     */

    (p_txt: String, p_debug: Integer) => {

      try {

        /*
          PL/SQL table types are modelled as Lists
         */

        val g_exclude_txt = List("a1c", "err code", "triglycerides are >", "triglycerides >", "triglycerides exceed", "trig >", "trig. >", "valid", "error", "incorrect", "not cal", "out of linearity", "below linearity", "unable to", "cannot calc", "could not be calc", "noresult", "result unreliable", "too high", "not applicable", "n/a", "void", "disregard", "canceled", "cancelled", "not done", "not performed", " na ", "reference range", "reference interval", "phone", "call", "fax", "notified", "reported", "performed at", "perfrm'd at", "tnp", "qns", " not performed ", "contaminated", "incorrect patient", "wrong patient", "not sufficient", "unable to ", "reported to ")
        val g_months = List("january", "february", "march", "april", "may", "june", "july", "august", "september", "october", "november", "december", "jan", "feb", "mar", "apr", "jun", "jul", "aug", "sep", "oct", "nov", "dec")

        var v_txt = if (p_txt.trim.toLowerCase().isEmpty) null else p_txt.trim.toLowerCase()

        var v_uom_pos = 100

        val case_when_v_txt = if (v_txt.length < 25 || v_txt.slice(24, v_txt.length).indexOf(" ") == -1) v_txt.length else v_txt.slice(24, v_txt.length).indexOf(" ") + 25

        v_txt = v_txt.slice(0, case_when_v_txt)

        for (v_excl_txt <- g_exclude_txt if v_txt contains v_excl_txt) v_txt = v_txt.slice(0, v_txt.indexOf(v_excl_txt) + 1)

        val v_match = v_txt.replace("|", " ").replaceAll("(^| )[^0-9]{1,} [^0-9]{1,}($| )", " ").trim

        /*
          Anonymous functions cannot have multiple return points like normal methods.
          Multiple return points example - At lines 166 and 184 in extract_fns.sql:
          if (v_txt is null) then
            return null;
          .
          .
          .
          if (v_match is null) then
            return -4000 + p_debug;
          end if;
          .
          .
          .
          1. We cannot use return statements to mimic this behaviour.
          Because when returns are used inside anonymous functions, it will return to the caller method directly and not the anonymous function
          2. Also, scala blocks will always return the last expression, so, to not use returns, we can't do something like:
          if (v_match is null) -4000 + p_debug
          v_pos = 0
          .
          .
          .
          So, implementing the above mentioned Oracle code and other instances of multiple return points
          as an if-else construct, so the Scala blocks return the expected expressions.
         */

        if (v_match.isEmpty) if (p_debug == null) null else (-4000 + p_debug).toString else {

          val uom = extract_uom_anon(v_txt)
          var v_uom = if (uom != null) uom.toString else null

          val raw_uom = extract_uom_raw_anon(v_txt)
          val v_raw_uom = if (raw_uom != null) raw_uom.toString else null

          /*
            There are 3 if blocks in Oracle, but only the first block executes, the other 2 if blocks' conditions will always be false, so excluding those filters
           */

          if (v_raw_uom != null) v_uom_pos = v_txt.indexOf(v_raw_uom) + 1

          var v_nbr:String = null
          var v_numeric:String = null
          var return_v_numeric_flag = "unset"
          var v_pos = 0

          v_pos = v_pos + 1

          var v_prev_token = v_nbr

          val matches = if("[\\S]{1,}".r.findAllIn(v_match).toArray.isEmpty) null else "[\\S]{1,}".r.findAllIn(v_match).toArray
          v_nbr = matches(v_pos - 1).replace(",", "").trim.slice(0, 25)
          v_nbr = if (v_nbr == "") null else v_nbr

          /*
             There are 2 return points inside the loop in line 200. One gets hit when loop's exit condition is met and the other gets
             hit when none of the if conditions satisfies. So, this has to be modelled as the if-else approach explained previously.
             For that, to know which return statement to handle, we unset a flag variable before the loop and set it if none of the if conditions satisfy.
             Then, to exit the for loop to mimic the return behaviour, we check if the flag is set as a part of the loop's exit condition.
             Once, out of the loop, based on the flag's value, we return the desired expression with the if-else construct.
           */

          while (!(v_pos > 5 || v_nbr == null || return_v_numeric_flag == "set")){

            v_uom = if (v_uom == null) "" else v_uom

            val safe_to_number_v_numeric_1 = v_nbr.replace(v_uom, "").replaceAll("[+><=\"()*;]", "").slice(0, v_uom_pos - 1)
            v_numeric = if (isSafeToNumberFunction(safe_to_number_v_numeric_1) != false) safe_to_number_v_numeric_1.toString else null

            /*
              Always, v_uom != "ph", so excluding that filter
             */

            if (v_numeric == null) {
              val safe_to_number_v_numeric_2 = v_nbr.slice(0, v_uom_pos - 1).replaceAll("[+><=\"()*;]", "")
              v_numeric = if (isSafeToNumberFunction(safe_to_number_v_numeric_2) != false) safe_to_number_v_numeric_2.toString else null
            }

            /*
               There is no continue or break built-in to scala. So, we'd need to rewire the control flow without the necessity for
               continue statements. Implementing this through (!(condition_1 || condition_2 || condition_3))
             */

            if (v_numeric != null) {

              val condition_1 = "(^[0][0-9]{1}|^[0-9]{1,2}[\\.]([^0-9]|$))".r.findFirstIn(v_nbr).isDefined

              /* The below condition will never be true, hence commenting out:
                 val condition_2 = v_pos > 1 && v_nbr.length == 4 && g_months.contains(v_prev_token)
               */

              if (v_nbr.length <= 2) v_nbr = matches(if (v_pos == matches.length) matches.length - 1 else v_pos).replace(",", "").trim.slice(0, 25)
              val condition_3 = g_months.contains(v_nbr)

              if (!(condition_1 || condition_3)) return_v_numeric_flag = "set"
            }

            v_pos = v_pos + 1

            v_prev_token = v_nbr

            v_nbr = if (v_pos > matches.length) null else matches(v_pos - 1).replace(",", "").trim.slice(0, 25)
            v_nbr = if (v_nbr == "") null else v_nbr

          }

          if (return_v_numeric_flag == "set") v_numeric else if (p_debug == null) null else (-2000 + p_debug).toString

        }

      }
      catch{

        /*
          Functions in Oracle can handle nulls as valid inputs, even if they primarily operate on a different datatype.
          Those types of functions return nulls if they get null inputs.
          But, Scala methods can't handle nulls this way, so to mimic this behaviour, handling NullPointerException.
          Also, Oracle functions might return null even for valid non-null inputs - for empty string, unmatched regex_substr, etc.
          All these have to be handled manually depending on the return values of used Scala methods.
          Eg: trim returns empty string, regex.findFirstIn returns None, etc.
         */

        case e: NullPointerException => null
        case _: Exception => if (p_debug == null) null else (-1000 + p_debug).toString
      }
    }
  }

  override def registerMe(sparkSession: SparkSession): Unit = {
    sparkSession.udf.register(name, extract_value)
  }
}