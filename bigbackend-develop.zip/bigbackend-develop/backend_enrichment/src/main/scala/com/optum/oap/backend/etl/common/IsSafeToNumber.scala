package com.optum.oap.backend.etl.common

import com.optum.oap.sparkdataloader.UserDefinedFunctionForDataLoader
import org.apache.spark.sql.SparkSession
import org.apache.spark.sql.expressions.UserDefinedFunction
import org.apache.spark.sql.functions.udf

/**
  *
  * Copyright 2019 Optum Analytics
  *
  * Date: 5/1/19
  *
  * Creator: bpokharel(bishu)
  */
object IsSafeToNumber extends UserDefinedFunctionForDataLoader {

  /**
    * returns true if given string is safe to convert to number else returns false.
    * e.g
    *
    * 3 -->true
    * -3 -->true
    * 01.99 -->true
    * 1.90 -->true
    * sdf -->false
    * -1.0 -->true
    * 1w.12 -->false
    * 45.0 -->true
    * 0.12 -->true
    * 12. -->false
    * . -->false
    */

  val isSafeToNumberFunction =
    (str: String) => {
      if (str == null) {
        false
      } else {
        str.matches("^-?(\\d*)?(\\.\\d+)?$")
      }
    }

  val isSafeToNumber: UserDefinedFunction = udf {
    isSafeToNumberFunction
  }

  override def name: String = "IsSafeToNumber"

  override def registerMe(sparkSession: SparkSession): Unit = {
    sparkSession.udf.register(name, isSafeToNumber)
  }
}
