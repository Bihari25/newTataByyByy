package com.optum.oap.backend.etl.bpo

import com.optum.oap.cdr.models._
import com.optum.oap.sparkdataloader.{RuntimeVariables, TableInfo, UserDefinedFunctionForDataLoader}
import org.apache.spark.sql.functions.{broadcast, coalesce, lit}
import org.apache.spark.sql.types.StringType
import org.apache.spark.sql.{DataFrame, SparkSession}

object PP_BPO_PHYSICIAN_KEY extends TableInfo[pp_bpo_physician_key] {

  override def dependsOn = Set("PROV_SPEC", "ZH_PROVIDER_MASTER_XREF", "MAP_SPECIALTY", "ZO_SPECIALTY", "MAP_SPECIALTY_II",
    "PP_BPO_PROVIDER_DETAIL", "PP_BPO_PHARMACY_CLAIMS", "PP_BPO_MEDICAL_CLAIMS", "PP_BPO_MEMBER_DETAIL",
    "PP_BPO_PROVIDER_DETAIL_SPANS")

  override def name = "PP_BPO_PHYSICIAN_KEY"

  override def createDataFrame(sparkSession: SparkSession,
                               loadedDependencies: Map[String, DataFrame],
                               udfMap: Map[String, UserDefinedFunctionForDataLoader],
                               runtimeVariables: RuntimeVariables): DataFrame = {

    import sparkSession.implicits._

    val provSpec = loadedDependencies("PROV_SPEC").as[prov_spec]
    val zhProviderMasterXref = loadedDependencies("ZH_PROVIDER_MASTER_XREF").as[zh_provider_master_xref]
    val mapSpecialty = broadcast(loadedDependencies("MAP_SPECIALTY")).as[map_specialty]
    val zoSpecialty = broadcast(loadedDependencies("ZO_SPECIALTY")).as[zo_specialty]
    val ppBpoProviderDetail = loadedDependencies("PP_BPO_PROVIDER_DETAIL").as[pp_bpo_provider_detail]
    val mapSpecialtyII = broadcast(loadedDependencies("MAP_SPECIALTY_II")).as[map_specialty_ii]

    val ppBpoPharmacyClaims = loadedDependencies("PP_BPO_PHARMACY_CLAIMS").as[pp_bpo_pharmacy_claims]
    val ppBpoMedicalClaims = loadedDependencies("PP_BPO_MEDICAL_CLAIMS").as[pp_bpo_medical_claims]
    val ppBpoMemberDetail = loadedDependencies("PP_BPO_MEMBER_DETAIL").as[pp_bpo_member_detail]
    val ppBpoProviderDetailSpans = loadedDependencies("PP_BPO_PROVIDER_DETAIL_SPANS").as[pp_bpo_provider_detail_spans]

    // calculate first part of pp_bpo_physician_key which comes from bpo_physician_key.sql
    val clause1 = provSpec.as("ps")
      .join(zhProviderMasterXref.as("zpm"), Seq("groupid", "localproviderid", "client_ds_id"), "inner")
      .join(mapSpecialty.as("ms"), $"ms.mnemonic" === $"ps.localspecialtycode" && $"ms.groupid" === $"ps.groupid", "left_outer")
      .join(zoSpecialty.as("zs"), $"zs.hts_cui" === $"ms.cui", "left_outer")
      .join(mapSpecialtyII.as("msII"), $"ps.localspecialtycode" === $"msII.local_code" && $"ps.groupid" === $"msII.groupid", "left_outer")
      .where(coalesce($"msII.ii_code", $"zs.ii_code", lit("999")) =!= lit("999"))
      .where($"zpm.master_hgprovid".isNotNull)
      .select(
        $"ps.groupid"
        , $"zpm.master_hgprovid".cast(StringType).as("providerid")
        , $"zpm.master_hgprovid".cast(StringType).as("providerkey")
        , coalesce($"msII.ii_code", $"zs.ii_code", lit("999")).as("specialty")
      )

    val clause2 = ppBpoProviderDetail
      .select(
        $"groupid"
        , $"providerid"
        , $"providerid".as("providerkey")
        , $"specialty"
      )

    val ppBpoPhysicianKey = clause1
      .union(clause2)
      .distinct()

    // calculation of final part of pp_bpo_physician_key which comes from  bpo_physician_key_final.sql
    val clause3 = ppBpoPharmacyClaims.select($"prescprovider".as("providerid")).distinct()
      .union(ppBpoMedicalClaims.select($"serviceproviderid".as("providerid"))).distinct()
      .union(ppBpoMemberDetail.select($"pcpid".as("providerid")).distinct())
      .union(ppBpoPharmacyClaims.select($"pharmacyid").as("providerid").distinct())
      .union(ppBpoMedicalClaims.select($"billingproviderid").as("providerid").distinct())
      .union(ppBpoMedicalClaims.select($"orderingproviderid").as("providerid").distinct())
      .union(ppBpoProviderDetailSpans.where($"provaffiliationid".isNotNull).select($"providerid".as("providerid")).distinct())
      .union(ppBpoMedicalClaims.select($"refer_prov_id".as("providerid")).distinct())
      .distinct()

    ppBpoPhysicianKey.as("bpo")
      .join(clause3.as("c3"), Seq("providerid"), "inner")
      .select(
        $"bpo.groupid",
        $"bpo.providerid",
        $"bpo.providerkey",
        $"bpo.specialty"
      ).as[pp_bpo_physician_key].toDF()


  }
}
