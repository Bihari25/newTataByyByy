package com.optum.oap.backend.etl.summary

import com.optum.oap.backend.etl.common.IsSafeToNumber
import com.optum.oap.cdr.models.pft_result
import com.optum.oap.sparkdataloader.{RuntimeVariables, TableInfo, UserDefinedFunctionForDataLoader}
import org.apache.spark.sql.expressions.Window
import org.apache.spark.sql.types.{DecimalType, DoubleType}
import org.apache.spark.sql.{DataFrame, SparkSession}
import org.slf4j.LoggerFactory

/**
  *
  * Copyright 2019 Optum Analytics
  *
  * Date: 4/30/19
  *
  * Creator: bpokharel(bishu)
  */
object PFT_RESULT extends TableInfo[pft_result] {
  val log = LoggerFactory.getLogger(this.getClass)

  override def dependsOn =
    Set("OBSERVATION", "MAP_PREDICATE_VALUES")

  override def name = "PFT_RESULT"

  override def saveDataFrameToParquet: Boolean = true

  override def partitions: Int = 256

  override def skipTable: Boolean = false

  override def ignoreExtraColumnsInDataFrame: Boolean = true


  override def createDataFrame(
                                sparkSession: SparkSession,
                                loadedDependencies: Map[String, DataFrame],
                                udfMap: Map[String, UserDefinedFunctionForDataLoader],
                                runtimeVariables: RuntimeVariables
                              ): DataFrame = {
    import org.apache.spark.sql.functions._
    import sparkSession.implicits._

    val observation_DF = loadedDependencies("OBSERVATION")
    val map_predicate_values_DF = broadcast(loadedDependencies("MAP_PREDICATE_VALUES"))

    // define a dataframe equivalent to temp_pft_&grpid in the oracle etl
    val joined_temp_pft_DF1 =
      observation_DF.as("o_df")
        .join(map_predicate_values_DF.as("mpv_df"),
          $"o_df.groupid" === $"mpv_df.groupid" &&
            $"o_df.client_ds_id" === $"mpv_df.client_ds_id" &&
            $"o_df.datasrc" === $"mpv_df.data_src" &&
            $"mpv_df.entity" === lit("PFT_RESULT") &&
            $"mpv_df.column_name" === lit("DBLET_VS_TRIPLET") &&
            $"mpv_df.column_value" === lit("Y"),
          "left_outer"
        )
        .where($"o_df.obstype".isin("FVC", "FEV1", "FEV1_FVC_RATIO", "FEV1_FVC_PCT"))
        .filter(IsSafeToNumber.isSafeToNumber($"o_df.obsresult"))
        .withColumn("obsdtcoalesce", coalesce($"o_df.resultdate", $"o_df.obsdate"))
        .withColumn(
          "dblet_vs_triplet_flg",
          when(
            $"mpv_df.client_ds_id".isNull, lit(3))
            .otherwise(lit(2))
        )
        .select(
          "obsdtcoalesce",
          "dblet_vs_triplet_flg",
          "o_df.*"
        )

    /*
     * cast the obsresult to double. since we have already filtered the columns which are not safe, we should be good to filter those.
     * our resulting model has this column turned to double. so have to make this conversion
     */
    val joined_temp_pft_DF2 = joined_temp_pft_DF1
      .withColumn("obsresult_casted", joined_temp_pft_DF1.col("obsresult").cast(DoubleType))
      .withColumnRenamed("obsresult", "obsresult_tmp")

    val joined_temp_pft_DF3 = joined_temp_pft_DF2.withColumnRenamed("obsresult_casted", "obsresult")


    // creating copies for self join and renaming columns

    val cloned_Df1 =
      joined_temp_pft_DF3
        .toDF(joined_temp_pft_DF3.columns.map(_ + "_r1"): _*)
    val cloned_filtered_Df1 =
      cloned_Df1
        .where(cloned_Df1("obstype_r1").isin(lit("FEV1_FVC_RATIO")))
        .where(cloned_Df1("obsresult_r1").isNotNull)


    // fvc
    val cloned_Df2 =
      joined_temp_pft_DF3.toDF(joined_temp_pft_DF3.columns.map(_ + "_r2"): _*)
    val cloned_filtered_Df2 =
      cloned_Df2
        .where(cloned_Df2("obstype_r2") === lit("FVC"))
        .where(cloned_Df2("obsresult_r2").isNotNull)

    // fev
    val cloned_Df3 =
      joined_temp_pft_DF3
        .toDF(joined_temp_pft_DF3.columns.map(_ + "_r3"): _*)
    val cloned_filtered_Df3 = cloned_Df3
      .where(cloned_Df3("obstype_r3").isin(lit("FEV1")))
      .where(cloned_Df3("obsresult_r3").isNotNull)

    val joined_Df4 =
      cloned_filtered_Df1.as("cd1")
        .join(cloned_filtered_Df2.as("cd2"),
          $"cd1.patientid_r1" === $"cd2.patientid_r2" &&
            $"cd1.client_ds_id_r1" === $"cd2.client_ds_id_r2" &&
            coalesce($"cd1.encounterid_r1", lit("0")) === coalesce($"cd2.encounterid_r2", lit("0")) &&
            $"cd1.groupid_r1" === $"cd2.groupid_r2" &&
            $"cd1.datasrc_r1" === $"cd2.datasrc_r2" &&
            $"cd1.obsdtcoalesce_r1" === $"cd2.obsdtcoalesce_r2"
        )
        .join(cloned_filtered_Df3.as("cd3"),
          $"cd1.patientid_r1" === $"cd3.patientid_r3" &&
            $"cd1.client_ds_id_r1" === $"cd3.client_ds_id_r3" &&
            coalesce($"cd1.encounterid_r1", lit("0")) === coalesce($"cd3.encounterid_r3", lit("0")) &&
            $"cd1.groupid_r1" === $"cd3.groupid_r3" &&
            $"cd1.datasrc_r1" === $"cd3.datasrc_r3" &&
            $"cd1.obsdtcoalesce_r1" === $"cd3.obsdtcoalesce_r3"
        )
        .withColumn("ratio_valid",
          when($"cd2.obsresult_r2".cast(new DecimalType(10, 5)) === lit(0), lit(0))
            .when(abs(($"cd3.obsresult_r3".cast(new DecimalType(10, 5)) / $"cd2.obsresult_r2".cast(new DecimalType(10, 5))) - ($"cd1.obsresult_r1".cast(new DecimalType(10, 5)) / 100)) leq lit(0.01).cast(new DecimalType(10, 5)), lit(1))
            .otherwise(lit(0))
        )
        .select(
          $"groupid_r1".as("groupid"),
          $"datasrc_r1".as("datasrc"),
          $"facilityid_r1".as("facilityid"),
          $"encounterid_r1".as("encounterid"),
          $"patientid_r1".as("patientid"),
          $"obsdtcoalesce_r1".as("resultdate"),
          $"obsresult_r2".as("fvc"),
          $"obsresult_r3".as("fev1"),
          $"obsresult_r1".as("fev1_fvc_ratio"),
          $"client_ds_id_r1".as("client_ds_id"),
          $"grp_mpi_r1".as("grp_mpi"),
          $"hgpid_r1".as("hgpid"),
          $"ratio_valid".as("ratio_valid"),
          $"dblet_vs_triplet_flg_r1".as("dblet_vs_triplet_flg")
        )

    // final dataframe for first part of the code
    val joined_Df4_filtered =
      joined_Df4.as("jdf4")
        .where($"jdf4.ratio_valid" === lit(1))
        .where($"jdf4.dblet_vs_triplet_flg" === lit(3))
        .select(
          $"jdf4.groupid",
          $"jdf4.datasrc",
          $"jdf4.facilityid",
          $"jdf4.encounterid",
          $"jdf4.patientid",
          $"jdf4.resultdate",
          $"jdf4.fvc",
          $"jdf4.fev1",
          $"jdf4.fev1_fvc_ratio",
          $"jdf4.client_ds_id",
          $"jdf4.grp_mpi",
          $"jdf4.hgpid"
        )
        .distinct()

    //  ------------------------------------------------------ Doublets ---------------------------------------------------------------

    val cloned_Df4 =
      joined_temp_pft_DF3.toDF(joined_temp_pft_DF3.columns.map(_ + "_r4"): _*)

    val cloned_Df5 =
      joined_temp_pft_DF3.toDF(joined_temp_pft_DF3.columns.map(_ + "_r5"): _*)

    val partitionBy =
      Window
        .partitionBy(
          $"cd4.groupid_r4",
          $"cd4.datasrc_r4",
          $"cd4.facilityid_r4",
          $"cd4.encounterid_r4",
          $"cd4.patientid_r4",
          $"cd4.client_ds_id_r4",
          $"cd4.obsdtcoalesce_r4"
        )

    val joinedDf5 =
      cloned_Df4.as("cd4")
        .join(cloned_Df5.as("cd5"),
          $"cd4.patientid_r4" === $"cd5.patientid_r5" &&
            $"cd4.client_ds_id_r4" === $"cd5.client_ds_id_r5" &&
            coalesce($"cd4.encounterid_r4", lit("0")) === coalesce($"cd5.encounterid_r5", lit("0")) &&
            $"cd4.groupid_r4" === $"cd5.groupid_r5" &&
            $"cd4.obsdtcoalesce_r4" === $"cd5.obsdtcoalesce_r5"
        )
        .where($"cd4.obstype_r4" === lit("FVC"))
        .where($"cd5.obstype_r5" === lit("FEV1"))
        .where($"cd4.obsresult_r4".isNotNull)
        .where($"cd5.obsresult_r5".isNotNull)

        /*
         * countDistinct doesn't support parition by window function. so using collect_set with size function for workaround
         * https://stackoverflow.com/questions/45869186/pyspark-count-distinct-over-a-window
         */
        .withColumn("pair_cnt", size(collect_set(concat($"cd4.obsresult_r4", lit("/"), $"cd5.obsresult_r5")).over(partitionBy)))
        .withColumn("fev1_fvc_ratio",
          when($"obsresult_r4" === lit(0), lit(0))
            .otherwise(round($"obsresult_r5" / $"obsresult_r4", 3))
        )
        .withColumn("ratio_valid",
          when($"obsresult_r4" === lit(0), lit(0))
            .when(($"obsresult_r4" / $"obsresult_r5") between(lit(0), lit(100)), lit(1))
            .otherwise(lit(2))
        )
        .select(
          $"groupid_r4".as("groupid"),
          $"datasrc_r4".as("datasrc"),
          $"facilityid_r4".as("facilityid"),
          $"encounterid_r4".as("encounterid"),
          $"patientid_r4".as("patientid"),
          $"client_ds_id_r4".as("client_ds_id"),
          $"grp_mpi_r4".as("grp_mpi"),
          $"hgpid_r4".as("hgpid"),
          $"obsdtcoalesce_r4".as("resultdate"),
          $"obsresult_r4".as("fvc"),
          $"obsresult_r5".as("fev1"),
          $"pair_cnt",
          $"dblet_vs_triplet_flg_r4".as("dblet_vs_triplet_flg"),
          $"fev1_fvc_ratio",
          $"ratio_valid"
        )

    val filtered_selected = joinedDf5.as("jdf5")
      .where($"jdf5.pair_cnt" === lit(1))
      .where($"jdf5.dblet_vs_triplet_flg" === lit(2))
      .where($"jdf5.ratio_valid" === lit(1))
      .select(
        "groupid",
        "datasrc",
        "facilityid",
        "encounterid",
        "patientid",
        "resultdate",
        "fvc",
        "fev1",
        "fev1_fvc_ratio",
        "client_ds_id",
        "grp_mpi",
        "hgpid"
      )

    //  ------------------------------------------------------ End of Doublets ------------------------------------------------------------

    // finally union two dataframes(dblet and triplet) for final result.
    val final_DF =
      joined_Df4_filtered
        .union(filtered_selected)

    final_DF.select(
        "groupid",
        "datasrc",
        "facilityid",
        "encounterid",
        "patientid",
        "resultdate",
        "fvc",
        "fev1",
        "fev1_fvc_ratio",
        "client_ds_id",
        "grp_mpi",
        "hgpid"
      ).as[pft_result].toDF()
  }
}
