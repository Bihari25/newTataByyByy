package com.optum.oap.backend.etl.common

import org.apache.spark.sql._

trait PartitionedDataOperations {
  val partitionedSaveMode = SaveMode.Append
  val PARTITION_DATE = "partition_date"

  def loadData(schema: String, tableName: String)(implicit sparkSession: SparkSession): DataFrame = {
    val query = s"select * from $schema.$tableName"
    sparkSession.sql(query)
  }

  def writeData(df: DataFrame, path: String, partitionSize: Option[Int] = Some(64)): Unit = {
    if(partitionSize.isDefined) {
      df.coalesce(partitionSize.get).write.mode(partitionedSaveMode).partitionBy(PARTITION_DATE).parquet(path)
    } else {
      df.write.mode(partitionedSaveMode).partitionBy(PARTITION_DATE).parquet(path)
    }
  }

  def recoverPartitions(schema: String, tableName: String)(implicit sparkSession: SparkSession) = {
    sparkSession.catalog.recoverPartitions(s"$schema.$tableName")
  }
}
