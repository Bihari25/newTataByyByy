package com.optum.oap.backend.etl.enrichment

import com.optum.oap.backend.cdrTempModel.{temp_med_claim}
import com.optum.oap.cdr.models.{clinicalencounter, int_claim_labresult, int_claim_pharm, map_specialty_ii, ref_billtype_pos_xref, ref_cmsnpi, ref_ub04_rev_codes}
import com.optum.oap.sparkdataloader.{RuntimeVariables, TableInfo, UserDefinedFunctionForDataLoader}
import org.apache.spark.sql.expressions.Window
import org.apache.spark.sql.{DataFrame, SparkSession}
import org.slf4j.LoggerFactory
import org.apache.spark.sql.functions._
import org.apache.spark.sql.types.DataTypes

object ICPM_CLINICALENCOUNTER extends TableInfo[clinicalencounter] {

  private val log = LoggerFactory.getLogger(this.getClass)

  override def dependsOn = Set("INT_CLAIM_LABRESULT", "ICPM_TEMP_MED_CLAIM", "INT_CLAIM_PHARM")

  override def name = "ICPM_CLINICALENCOUNTER"

  override def createDataFrame(sparkSession: SparkSession,
                               loadedDependencies: Map[String, DataFrame],
                               udfMap: Map[String, UserDefinedFunctionForDataLoader],
                               runtimeVariables: RuntimeVariables): DataFrame = {

    import sparkSession.implicits._

    val cdrFeIntClaimLabresult = loadedDependencies("INT_CLAIM_LABRESULT").as[int_claim_labresult]
    val tempMedClaim = loadedDependencies("ICPM_TEMP_MED_CLAIM").as[temp_med_claim]
    val cdrFeIntClaimPharm = loadedDependencies("INT_CLAIM_PHARM").as[int_claim_pharm].filter(coalesce($"claim_adj_type", lit("K")) === "K")

    val labResultClinicalEncounter = cdrFeIntClaimLabresult.select(
      $"groupid"
      , lit("int_claim_labresult").as("datasrc")
      , $"client_ds_id"
      , coalesce($"result_date", $"collection_date").as("arrivaltime")
      , coalesce($"labresult_id", coalesce($"encounterid", $"claim_header_id")).as("encounterid")
      , $"member_id".as("patientid")
      , lit("POS.LAB").as("localpatienttype")
      , lit(null).cast(DataTypes.TimestampType).as("admittime")
      , lit(null).cast(DataTypes.StringType).as("admittingphysician")
      , lit(null).cast(DataTypes.StringType).as("alt_encounterid")
      , lit(null).cast(DataTypes.StringType).as("aprdrg_cd")
      , lit(null).cast(DataTypes.StringType).as("aprdrg_rom")
      , lit(null).cast(DataTypes.StringType).as("aprdrg_soi")
      , lit(null).cast(DataTypes.StringType).as("attendingphysician")
      , lit(null).cast(DataTypes.TimestampType).as("dischargetime")
      , lit(null).cast(DataTypes.DoubleType).as("elos")
      , lit(null).cast(DataTypes.StringType).as("facilityid")
      , lit(null).cast(DataTypes.StringType).as("grp_mpi")
      , lit(null).cast(DataTypes.LongType).as("hgpid")
      , lit(null).cast(DataTypes.StringType).as("inferred_pat_type")
      , lit(null).cast(DataTypes.StringType).as("inpatientlocation")
      , lit(null).cast(DataTypes.StringType).as("localaccountstatus")
      , lit(null).cast(DataTypes.StringType).as("localadmitsource")
      , lit(null).cast(DataTypes.StringType).as("admit_type_code")
      , lit(null).cast(DataTypes.StringType).as("localdischargedisposition")
      , lit(null).cast(DataTypes.StringType).as("localdrg")
      , lit(null).cast(DataTypes.StringType).as("localdrgoutlier")
      , lit(null).cast(DataTypes.StringType).as("localdrgtype")
      , lit(null).cast(DataTypes.StringType).as("localencountertype")
      , lit(null).cast(DataTypes.StringType).as("localfinancialclass")
      , lit(null).cast(DataTypes.StringType).as("localmdc")
      , lit(null).cast(DataTypes.StringType).as("pcpid")
      , lit(null).cast(DataTypes.StringType).as("referproviderid")
      , lit(null).cast(DataTypes.DoubleType).as("totalcharge")
      , lit(null).cast(DataTypes.DoubleType).as("totalcost")
      , lit(null).cast(DataTypes.StringType).as("visitid")
      , lit(null).cast(DataTypes.StringType).as("wasplannedflg")
      , lit(null).cast(DataTypes.TimestampType).as("ed_triage_dtm")
    ).withColumn("rank_enc", row_number().over(Window.partitionBy($"client_ds_id", $"encounterid")
      .orderBy($"arrivaltime".asc_nulls_last))).filter(
      $"rank_enc" === 1
        && $"encounterid".isNotNull
        && $"arrivaltime".isNotNull
        && $"patientid".isNotNull).drop("rank_enc")

    val pharmResultClinicalEncounter = cdrFeIntClaimPharm.select(
      $"groupid"
      , lit("int_claim_pharm").as("datasrc")
      , $"client_ds_id"
      , $"service_date".as("arrivaltime")
      , coalesce($"encounterid", concat_ws("", $"claim_id", lit("_"), $"service_date")).as("encounterid")
      , $"member_id".as("patientid")
      , $"contract_id"
      , lit("POS.MED").as("localpatienttype")
      , lit(null).cast(DataTypes.TimestampType).as("admittime")
      , lit(null).cast(DataTypes.StringType).as("admittingphysician")
      , lit(null).cast(DataTypes.StringType).as("alt_encounterid")
      , lit(null).cast(DataTypes.StringType).as("aprdrg_cd")
      , lit(null).cast(DataTypes.StringType).as("aprdrg_rom")
      , lit(null).cast(DataTypes.StringType).as("aprdrg_soi")
      , lit(null).cast(DataTypes.StringType).as("attendingphysician")
      , lit(null).cast(DataTypes.TimestampType).as("dischargetime")
      , lit(null).cast(DataTypes.DoubleType).as("elos")
      , lit(null).cast(DataTypes.StringType).as("facilityid")
      , lit(null).cast(DataTypes.StringType).as("grp_mpi")
      , lit(null).cast(DataTypes.LongType).as("hgpid")
      , lit(null).cast(DataTypes.StringType).as("inferred_pat_type")
      , lit(null).cast(DataTypes.StringType).as("inpatientlocation")
      , lit(null).cast(DataTypes.StringType).as("localaccountstatus")
      , lit(null).cast(DataTypes.StringType).as("localadmitsource")
      , lit(null).cast(DataTypes.StringType).as("admit_type_code")
      , lit(null).cast(DataTypes.StringType).as("localdischargedisposition")
      , lit(null).cast(DataTypes.StringType).as("localdrg")
      , lit(null).cast(DataTypes.StringType).as("localdrgoutlier")
      , lit(null).cast(DataTypes.StringType).as("localdrgtype")
      , lit(null).cast(DataTypes.StringType).as("localencountertype")
      , lit(null).cast(DataTypes.StringType).as("localfinancialclass")
      , lit(null).cast(DataTypes.StringType).as("localmdc")
      , lit(null).cast(DataTypes.StringType).as("pcpid")
      , lit(null).cast(DataTypes.StringType).as("referproviderid")
      , lit(null).cast(DataTypes.DoubleType).as("totalcharge")
      , lit(null).cast(DataTypes.DoubleType).as("totalcost")
      , lit(null).cast(DataTypes.StringType).as("visitid")
      , lit(null).cast(DataTypes.StringType).as("wasplannedflg")
      , lit(null).cast(DataTypes.TimestampType).as("ed_triage_dtm")
    ).withColumn("rank_enc", row_number().over(Window.partitionBy($"client_ds_id", $"contract_id", $"encounterid")
      .orderBy($"arrivaltime".asc_nulls_last))).filter(
      $"rank_enc" === 1
        && $"encounterid".isNotNull
        && $"arrivaltime".isNotNull
        && $"patientid".isNotNull
    ).drop("rank_enc", "contract_id")

    val clincEncMax = tempMedClaim
      .select(
        $"groupid"
        , $"client_ds_id"
        , $"datasrc"
        , $"encounterid"
        , $"servicing_prov_id"
        , $"localpatienttype"
        , $"arrivaltime"
        , $"admittime"
        , $"dischargetime"
        , $"localdrg"
        , $"localdrgtype"
        , $"localdrgoutlier"
        , $"aprdrg_cd"
        , $"aprdrg_soi"
        , $"aprdrg_rom"
        , $"member_id"
        , $"proc_code"
        , first("facility_code", true).over(Window.partitionBy($"encounterid").orderBy(when($"facility_code".isNotNull, $"service_date").otherwise(null).desc_nulls_last, $"facility_code".desc_nulls_last)).as("facility_code_mx")
        , first("discharge_status_code", true).over(Window.partitionBy($"encounterid").orderBy(when($"discharge_status_code".isNotNull, $"service_date").otherwise(null).desc_nulls_last, $"discharge_status_code".asc_nulls_last)).as("localdischargedisposition")
        , first("admit_source_code", true).over(Window.partitionBy($"encounterid").orderBy(when($"admit_source_code".isNotNull, $"service_date").otherwise(null).desc_nulls_last, $"admit_source_code".asc_nulls_last)).as("localadmitsource")
        , first("admit_type_code", true).over(Window.partitionBy($"encounterid").orderBy(when($"admit_type_code".isNotNull, $"service_date").otherwise(null).desc_nulls_last, $"admit_type_code".asc_nulls_last)).as("admit_type_code")
      )

    val clinEncDf1 = clincEncMax.where($"arrivaltime".isNotNull)
      .select(
        $"groupid"
        , $"client_ds_id"
        , $"datasrc"
        , $"encounterid"
        , when($"datasrc" === "int_claim_medical_i", coalesce($"facility_code_mx", $"servicing_prov_id"))
          .when($"datasrc" === "int_claim_medical_p", $"facility_code_mx")
          .as("facilityid")
        , $"localpatienttype"
        , $"arrivaltime"
        , $"admittime"
        , $"dischargetime"
        , $"localdischargedisposition"
        , $"localadmitsource"
        , $"admit_type_code"
        , $"localdrg"
        , $"localdrgtype"
        , $"localdrgoutlier"
        , $"aprdrg_cd"
        , $"aprdrg_soi"
        , $"aprdrg_rom"
        , $"member_id".as("patientid")
        , lit(null).cast(DataTypes.StringType).as("admittingphysician")
        , lit(null).cast(DataTypes.StringType).as("alt_encounterid")
        , lit(null).cast(DataTypes.StringType).as("attendingphysician")
        , lit(null).cast(DataTypes.DoubleType).as("elos")
        , lit(null).cast(DataTypes.StringType).as("grp_mpi")
        , lit(null).cast(DataTypes.LongType).as("hgpid")
        , lit(null).cast(DataTypes.StringType).as("inferred_pat_type")
        , lit(null).cast(DataTypes.StringType).as("inpatientlocation")
        , lit(null).cast(DataTypes.StringType).as("localaccountstatus")
        , lit(null).cast(DataTypes.StringType).as("localencountertype")
        , lit(null).cast(DataTypes.StringType).as("localfinancialclass")
        , lit(null).cast(DataTypes.StringType).as("localmdc")
        , lit(null).cast(DataTypes.StringType).as("pcpid")
        , lit(null).cast(DataTypes.StringType).as("referproviderid")
        , lit(null).cast(DataTypes.DoubleType).as("totalcharge")
        , lit(null).cast(DataTypes.DoubleType).as("totalcost")
        , lit(null).cast(DataTypes.StringType).as("visitid")
        , lit(null).cast(DataTypes.StringType).as("wasplannedflg")
        , row_number().over(Window.partitionBy($"encounterid").orderBy($"proc_code".desc_nulls_last)).as("rn")
        , lit(null).cast(DataTypes.TimestampType).as("ed_triage_dtm")
      )
      .filter($"rn" === 1)
      .drop($"rn")

    val clinEncDf = clinEncDf1.distinct()


    clinEncDf.unionByName(labResultClinicalEncounter).unionByName(pharmResultClinicalEncounter)


  }
}