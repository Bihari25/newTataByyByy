package com.optum.oap.backend.etl.encgrps

import com.optum.oap.backend.cdrTempModel.temp_providers
import com.optum.oap.sparkdataloader.QueryAndMetadata

object TEMP_PROVIDERS extends QueryAndMetadata[temp_providers] {
  override def name: String = "TEMP_PROVIDERS"

  override def sparkSql: String = """select
/*+ BROADCAST(s) */
p.*, s.ii_code
from
(select
/*+ BROADCAST(s1) */ /*+ BROADCAST(s2) */
sp.groupid, sp.MASTER_HGPROVID,
CASE when s1.ii_code is not null and s1.ii_code < '200' then sp.NPIPRIMARYSPECIALTY
when s2.ii_code is not null and s2.ii_code < '200' then sp.PRIMARYSPECIALTY
when entity_type_code = '2' then sp.NPIPRIMARYSPECIALTY
when (sp.PRIMARYSPECIALTY not in ('CH000831', 'CH000953') OR sp.NPIPRIMARYSPECIALTY is null) then sp.PRIMARYSPECIALTY
else sp.NPIPRIMARYSPECIALTY end specialty_cui
, cms.entity_type_code
, sp.NPIPRIMARYSPECIALTY, sp.PRIMARYSPECIALTY as LOCALPRIMARYSPECIALTY
, sp.providername, sp.npi
, case when coalesce(sp.PROVIDEREXCLUSIONFLAG,'N') = 'Y' then 1 else 0 end as PROVIDEREXCLUSION_ind
from ZH_V_PROVIDER_MASTER sp
LEFT OUTER JOIN REF_CMSNPI cms ON (cms.npi = sp.npi)
left outer join ZO_SPECIALTY s1 on sp.NPIPRIMARYSPECIALTY = s1.hts_cui
left outer join ZO_SPECIALTY s2 on sp.PRIMARYSPECIALTY = s2.hts_cui
) p
left outer join ZO_SPECIALTY s on p.specialty_cui = s.hts_cui"""

  override def dependsOn: Set[String] = Set("ZH_V_PROVIDER_MASTER", "REF_CMSNPI", "ZO_SPECIALTY") // @todo - needs REF_CMSNPI, ZO_SPECIALTY loaded from source tables
}
