package com.optum.oap.backend.etl.summary

import com.optum.oap.backend.cdrTempModel.facility_xref
import com.optum.oap.backend.etl.common.PartitionedDataOperations
import com.optum.oap.backend.loader.EnrichmentRunTimeVariables
import com.optum.oap.cdr.models.{facility_ext, zh_facility, zh_facility_rollup}
import com.optum.oap.sparkdataloader.{RuntimeVariables, TableInfo, UserDefinedFunctionForDataLoader}
import org.apache.spark.sql.expressions.Window
import org.apache.spark.sql.functions._
import org.apache.spark.sql.{DataFrame, SparkSession}
import org.slf4j.LoggerFactory

object FACILITY_EXT extends TableInfo[facility_ext] with PartitionedDataOperations {
  private val log = LoggerFactory.getLogger(this.getClass)

  override def dependsOn = Set("ZH_FACILITY", "V_FACILITY_XREF", "ZH_FACILITY_ROLLUP")

  override def name = "FACILITY_EXT"

  override def createDataFrame(sparkSession: SparkSession,
                               loadedDependencies: Map[String, DataFrame],
                               udfMap: Map[String, UserDefinedFunctionForDataLoader],
                               runtimeVariables: RuntimeVariables): DataFrame = {
    import sparkSession.implicits._

    implicit val session = sparkSession
    val schema = EnrichmentRunTimeVariables(runtimeVariables).cdrSchema
    val zhFacility = loadedDependencies("ZH_FACILITY").as[zh_facility]
    val facXref = loadedDependencies("V_FACILITY_XREF").as[facility_xref]
    val facilityXref = if(facXref.isEmpty) loadData(schema, "V_FACILITY_XREF").as[facility_xref] else facXref
    val zhFacilityRollup = loadedDependencies("ZH_FACILITY_ROLLUP").as[zh_facility_rollup]

    val df = zhFacility.as("zh")
      .join(facilityXref.as("fxref"), Seq("groupid", "client_ds_id", "facilityid"), "inner")
      .join(zhFacilityRollup.as("zhroll"), $"zh.groupid" === $"zhroll.groupid" && $"zh.client_ds_id" === $"zhroll.client_ds_id" && $"zh.facilityid" === $"zhroll.facility_id", "left_outer")
      .select(
        $"zh.groupid".as("groupid"),
        $"zh.client_ds_id".as("client_ds_id"),
        $"zh.facilityid".as("facilityid"),
        coalesce($"zhroll.siteofcare_name",$"zh.facilityname",lit("unknown or n/a")).as("temp_siteofcare"),
        $"zhroll.siteofcare_name".as("siteofcare_name"),
        coalesce($"zhroll.siteofcare_id", concat($"zh.client_ds_id", lit("."), $"zh.facilityid")).as("siteofcare_cd"),
        when($"zhroll.siteofcare_id".isNotNull, $"zhroll.siteofcare_postalcd").otherwise($"zh.facilitypostalcd").as("siteofcare_postal_cd"),
        $"zhroll.master_facility_id".as("master_facility_cd"),
        $"zhroll.master_facility_name".as("master_facility_nm"),
        when($"zhroll.enctr_grp_flag" === lit("N"), lit(0)).otherwise(lit(1)).as("enc_grp_ind"),
        $"zhroll.facilitypostalcd".as("facility_postal_cd"),
        when($"zhroll.soc_rollup_flag" === lit("Y"), lit(1)).otherwise(lit(0)).as("siteofcare_ind"),
        $"zhroll.patient_type_cui".as("patient_type_cui"),
        $"fxref.hgfacid".as("hgfacid"),
        when($"zhroll.siteofcare_id".isNotNull, 1).otherwise(0).as("soc_mapped_ind")
      )

    df.select(
      $"groupid",
      $"client_ds_id",
      $"facilityid",
      $"siteofcare_cd",
      coalesce(
        when(count(lit(1)).over(Window.partitionBy(upper($"temp_siteofcare"))) === lit(1) or $"soc_mapped_ind" === lit(1), $"temp_siteofcare")
          .otherwise(concat($"temp_siteofcare", lit(" ("), $"siteofcare_cd", lit(")")))).as("siteofcare_nm"),
      $"siteofcare_postal_cd",
      $"master_facility_cd",
      $"master_facility_nm",
      $"enc_grp_ind",
      $"facility_postal_cd",
      $"siteofcare_ind",
      $"patient_type_cui",
      $"hgfacid",
      when($"master_facility_cd".isNotNull, min($"hgfacid").over(Window.partitionBy($"groupid", $"master_facility_cd"))).otherwise(lit(null)).as("master_hgfacid"),
      min($"hgfacid").over(Window.partitionBy($"groupid", $"siteofcare_cd")).as("master_siteofcare_id")
    )
  }
}