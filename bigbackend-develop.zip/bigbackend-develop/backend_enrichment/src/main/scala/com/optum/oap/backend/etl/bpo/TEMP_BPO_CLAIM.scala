package com.optum.oap.backend.etl.bpo

import java.sql.Timestamp

import com.optum.oap.backend.cdrTempModel._
import com.optum.oap.backend.etl.bpo.BpoUtil.getBpoInputParameters
import com.optum.oap.backend.etl.common.{CDRConstants, IsSafeToNumber}
import com.optum.oap.backend.loader.EnrichmentRunTimeVariables
import com.optum.oap.cdr.models._
import com.optum.oap.sparkdataloader.{RuntimeVariables, TableInfo, UserDefinedFunctionForDataLoader}
import org.apache.spark.sql.functions.{lit, when, _}
import org.apache.spark.sql.types.{DecimalType, DoubleType, StringType, TimestampType}
import org.apache.spark.sql.{DataFrame, Dataset, SparkSession}
import org.joda.time.DateTime

/**
  *
  * Copyright 2019 Optum Analytics
  *
  * Date: 5/31/19
  *
  * Creator: bpokharel(bishu)
  */
object TEMP_BPO_CLAIM extends TableInfo[temp_bpo_claim] {

  override def dependsOn = Set(
    "CLAIM",
    "TEMP_BPO_PATIENTS",
    "MAP_PREDICATE_VALUES",
    "TEMP_PP_BPO_PROVIDER_DETAIL_SPANS",
    "CLINICALENCOUNTER",
    "MAP_PATIENT_TYPE",
    "MAP_DISCHARGE_DISPOSITION",
    "MAP_DRG_TYPE",
    "TEMP_BPO_CALCULATE_PARAMS",
    "DENIED_IND_ROLLUP",
    "ZH_PROVIDER",
    "MAP_ADMIT_SOURCE",
    "MAP_INP_ADMIT_TYPE"
  )

  override def name = "TEMP_BPO_CLAIM"

  override def partitions: Int = 512

  override def createDataFrame(sparkSession: SparkSession,
                               loadedDependencies: Map[String, DataFrame],
                               udfMap: Map[String, UserDefinedFunctionForDataLoader],
                               runtimeVariables: RuntimeVariables): DataFrame = {
    import sparkSession.implicits._

    val groupId = runtimeVariables.asInstanceOf[EnrichmentRunTimeVariables].clientId
    logger.warn(s"Running temp_bpo_claim for group $groupId")

    val claim_DS = loadedDependencies("CLAIM").as[claim]
    val temp_bpo_patients_DS = loadedDependencies("TEMP_BPO_PATIENTS").as[temp_bpo_patients]
    val map_predicate_values_DS = broadcast(loadedDependencies("MAP_PREDICATE_VALUES")).as[map_predicate_values]
    val pp_bpo_provider_detail_spans_DS = loadedDependencies("TEMP_PP_BPO_PROVIDER_DETAIL_SPANS").as[pp_bpo_provider_detail_spans]
    val clinicalencounter_DS = loadedDependencies("CLINICALENCOUNTER").as[clinicalencounter]
      .select($"admittime", $"aprdrg_cd", $"aprdrg_soi", $"client_ds_id", $"dischargetime", $"encounterid", $"facilityid", $"grp_mpi", $"localadmitsource",
        $"localdischargedisposition", $"localdrg", $"localdrgoutlier", $"localdrgtype", $"localpatienttype").as[clinicalencounter_lite]
    val map_patient_type_DS = broadcast(loadedDependencies("MAP_PATIENT_TYPE")).as[map_patient_type]
    val map_discharge_disposition_DS = broadcast(loadedDependencies("MAP_DISCHARGE_DISPOSITION")).as[map_discharge_disposition]
    val map_drg_type_DS = broadcast(loadedDependencies("MAP_DRG_TYPE")).as[map_drg_type]
    val temp_bpo_calculate_params_DS = broadcast(loadedDependencies("TEMP_BPO_CALCULATE_PARAMS")).as[temp_bpo_calculate_params]
    val denied_ind_rollup = broadcast(loadedDependencies("DENIED_IND_ROLLUP")).as[denied_ind_rollup]
    val zh_provider = loadedDependencies("ZH_PROVIDER").as[zh_provider]
    val zh_provider1 = zh_provider
      .select($"client_ds_id", $"localproviderid", $"master_hgprovid").as[temp_zo_provider]
    val map_admit_source = broadcast(loadedDependencies("MAP_ADMIT_SOURCE")).as[map_admit_source]

    val mapInpAdmitType = broadcast(loadedDependencies("MAP_INP_ADMIT_TYPE").as[map_inp_admit_type])

    val bpoInputParameters = getBpoInputParameters(sparkSession, temp_bpo_calculate_params_DS)
    val extractStartDate = bpoInputParameters.engineStartDate
    val extractEndDate = bpoInputParameters.engineEndDate


    val patDf = temp_bpo_patients_DS
      .select(
        $"grp_mpi"
      ).distinct()

    val common_claim_df = claim_DS.as("c").filter($"c.grp_mpi".isNotNull &&
      to_date($"servicedate").geq(extractStartDate) &&
      to_date($"servicedate").lt(date_add(to_date(lit(extractEndDate), CDRConstants.DATE_FORMAT_4Y2M2D), 1)))
      .join(patDf.as("pat"),
        $"pat.grp_mpi" === $"c.grp_mpi")
      .select($"c.*").as[claim]


    val filteredClinicalEncounter = clinicalencounter_DS.as("c").filter($"c.grp_mpi".isNotNull)
      .join(patDf.as("pat"),$"pat.grp_mpi" === $"c.grp_mpi").select($"c.*").as[clinicalencounter_lite]

    val deniedRollUps = denied_ind_rollup.as("m").where($"m.groupid" === lit(groupId) && $"denied_ind_rollup".isin("Y", "N"))
      .groupBy($"groupid", $"denied_flag")
      .agg(max($"denied_ind_rollup").as("denied_ind_rollup"))
      .select($"denied_flag", $"denied_ind_rollup").as[temp_denied_rollup].collect().map(x => x.denied_flag -> x.denied_ind_rollup).toMap

    val predicateValues = map_predicate_values_DS.as("m")
      .filter($"m.groupid" === lit(groupId)
        && ($"m.entity" === lit("PP_BPO_MEDICAL_CLAIMS"))
        && ($"m.column_name" === lit("PX_DX"))
        && ($"m.data_src" === lit("OADW"))).collect().map(_.client_ds_id).toSet
    val provider = zh_provider1.collect()
    val patientType = map_patient_type_DS.filter($"groupid" === lit(groupId)).collect().map(x => x.local_code.toLowerCase -> x.cui).toMap
    val dischargeDisposition = map_discharge_disposition_DS.filter($"groupid" === lit(groupId)).collect().map(x => x.mnemonic.toLowerCase -> x.cui).toMap
    val drgTypes = map_drg_type_DS.filter($"groupid" === lit(groupId)).collect().map(x => x.code.toLowerCase -> x.cui).toMap
    val admitSource = map_admit_source.filter($"groupid" === lit(groupId)).collect().map(x => x.localcode.toLowerCase -> x.cui).toMap

    val claimAndClinicalEncounter = joinClaimAndClinicalEncounter(sparkSession, common_claim_df, filteredClinicalEncounter, predicateValues, patientType, dischargeDisposition,
      drgTypes, admitSource, deniedRollUps, provider)

    val admitTypes = List("0", "1", "2", "3", "4", "5", "6", "7", "8", "9")

    val joinedDF = claimAndClinicalEncounter.as("clm")
      .join(pp_bpo_provider_detail_spans_DS.as("pds"),
        $"pds.providerid" === $"clm.claim_mstrprovid"
          && $"clm.servicedate".between($"pds.prov_effective_dt", $"pds.prov_end_dt")
        , "left_outer")
      .join(zh_provider.as("prov3"),
        $"prov3.groupid" === $"clm.groupid" && $"prov3.client_ds_id" === $"clm.client_ds_id" && $"prov3.localproviderid" === $"clm.referring_prov_id", "left_outer")
      .join(mapInpAdmitType.as("mInp"), $"mInp.groupid" === $"clm.groupid" && $"mInp.local_code" === $"clm.admit_type_code", "left_outer")
      .select(
        $"clm.groupid",
        $"clm.grp_mpi",
        $"clm.encounterid",
        $"clm.client_ds_id",
        $"clm.facilityid",
        $"clm.servicedate",
        $"clm.admittime",
        $"clm.dischargetime",
        $"clm.claim_mstrprovid".cast(StringType),
        $"clm.patientTypeCui".as("patienttype"),
        $"mappedrev".as("revenuecode"),
        when(length(coalesce($"clm.mappedcpt", $"clm.mappedhcpcs")) === lit(5), coalesce($"clm.mappedcpt", $"clm.mappedhcpcs"))
          .otherwise(lit(null).cast(StringType))
          .as("procedurecode"),
        $"localcpt",
        substring($"clm.mappedcptmod1", 1, 4).as("proceduremodifier"),
        substring($"clm.mappedcptmod2", 1, 4).as("proc_code_modifier2"),
        substring($"clm.mappedcptmod3", 1, 4).as("proc_code_modifier3"),
        substring($"clm.mappedcptmod4", 1, 4).as("proc_code_modifier4"),
        $"localdrg",
        $"clm.drgTypeCui".as("localdrggrouper"),
        $"clm.dischargeDispositionCui".as("disposition"),
        when(IsSafeToNumber.isSafeToNumber($"clm.quantity"), $"clm.quantity".cast(DoubleType))
          .otherwise(lit(null)).cast(DoubleType)
          .as("quantity"),
        $"clm.charge".cast(DecimalType(10, 2)).cast(DoubleType).as("requestedamount"),
        $"clm.paidamount".as("paidamount"),
        $"clm.allowedamount",
        coalesce($"clm.to_dt", $"clm.dischargetime").as("todate"),
        when($"clm.post_dt".gt($"clm.servicedate") && $"clm.post_dt".leq(current_timestamp()), $"clm.post_dt")
          .otherwise($"clm.servicedate").as("paymentdate"),
        $"clm.pos",
        $"clm.min_svc_date",
        $"clm.max_svc_date",
        $"clm.par_flag",
        $"clm.sourceId".as("sourceid"),
        $"clm.contract_id",
        $"pds.provider_status",
        $"clm.network_paid_status",
        $"clm.fee_for_service_amt".cast(DecimalType(16, 6)).cast(DoubleType).as("ffsamount"),
        $"clm.copay_amt".cast(DecimalType(16, 6)).cast(DoubleType).as("copayamount"),
        $"clm.coinsurance_amt".cast(DecimalType(16, 6)).cast(DoubleType).as("coinsamount"),
        $"clm.deductible_amt".cast(DecimalType(16, 6)).cast(DoubleType).as("deductamount"),
        $"clm.pat_liability_amt".cast(DecimalType(16, 6)).cast(DoubleType).as("patliabamount"),
        $"clm.coord_benefits_amt".cast(DecimalType(16, 6)).cast(DoubleType).as("cobamount"),
        $"clm.withhold_amt".cast(DecimalType(16, 6)).cast(DoubleType).as("withamount"),
        $"clm.capitation_amt".cast(DecimalType(16, 6)).cast(DoubleType).as("capamount"),
        lit(new Timestamp(DateTime.now().getMillis)).as("db_create_dt_tm"),
        $"clm.capsvcflag".as("capsvcflag"),
        $"clm.deniedflag".as("deniedflag"),
        $"clm.pseudoflag".as("pseudoflag"),
        $"clm.claimid",
        $"clm.prov_svc_ii_spec",
        $"clm.type_of_service",
        $"clm.other_1_amt".as("amt_oth1"),
        $"clm.other_2_amt".as("amt_oth2"),
        $"clm.other_3_amt".as("amt_oth3"),
        $"clm.other_4_amt".as("amt_oth4"),
        $"clm.billingproviderid".as("billingproviderid"),
        $"clm.orderingproviderid".as("orderingproviderid"),
        $"clm.type_of_bill_code".as("typeofbill"),
        $"clm.spec_rx_ind",
        $"clm.not_covered_amt",
        $"clm.other_carrier_pay_amt",
        $"clm.admin_fee_amt",
        $"clm.claim_prov_affil_id",
        $"clm.aprdrg_cd",
        $"clm.aprdrg_soi",
        $"clm.localdrgoutlier",
        $"clm.admitSourceCui".as("admitsourcecui"),
        $"clm.claim_prov_status_id",
        $"clm.denied_flag".as("denied_ind"),
        $"pds.provaffiliationid",
        $"cust_attr_1",
        $"cust_attr_2",
        $"cust_attr_3",
        $"cust_attr_4",
        $"cust_attr_5",
        $"cust_attr_6",
        $"cust_attr_7",
        $"cust_attr_8",
        $"cust_attr_9",
        $"cust_attr_10",
        $"cust_attr_11",
        $"cust_attr_12",
        $"cust_attr_13",
        $"cust_attr_14",
        $"cust_attr_15",
        $"cust_attr_16",
        $"cust_attr_17",
        $"cust_attr_18",
        $"cust_attr_19",
        $"cust_attr_20",
        $"prov3.master_hgprovid".cast(StringType).as("refer_prov_id"),
        when($"mInp.inp_admit_type".isNotNull && $"mInp.inp_admit_type".isin(admitTypes:_*), $"mInp.inp_admit_type")
          .when($"clm.admit_type_code".isin(admitTypes:_*), $"clm.admit_type_code")
          .otherwise(lit(null)).as("inp_admit_type")
      )

    joinedDF.as[temp_bpo_claim].toDF()

  }

  private def joinClaimAndClinicalEncounter(spark: SparkSession,
                                            claim: Dataset[claim],
                                            clinicalEncounter: Dataset[clinicalencounter_lite],
                                            predicateValues: Set[Integer],
                                            patientType: Map[String, String],
                                            dischargeDisposition: Map[String, String],
                                            drgTypes: Map[String, String],
                                            admitSource: Map[String, String],
                                            deniedRollUps: Map[String, String],
                                            zhProvider: Array[temp_zo_provider]): Dataset[claim_and_clinialencounter] = {
    import spark.implicits._

    implicit def ordered: Ordering[java.sql.Timestamp] = new Ordering[java.sql.Timestamp] {
      def compare(x: java.sql.Timestamp, y: java.sql.Timestamp): Int = x compareTo y
    }

    val pvdrMap = zhProvider.groupBy(_.client_ds_id).map(x => x._1 -> x._2.map(y => y.localproviderid -> y.master_hgprovid).toMap)

    val yOrN = Set("Y", "N")
    val groupedClaims = claim
      .withColumn("encounter_and_clientdsid", md5(concat_ws("", $"encounterid", $"client_ds_id", $"grp_mpi")))
      .groupBy($"encounter_and_clientdsid")
      .agg(collect_list(struct(classOf[claim].getDeclaredFields.toList.withFilter(!_.isSynthetic()).map(f => $"${f.getName}"): _*)).as("claims"))

    val groupedClinicalEncounters = clinicalEncounter
      .withColumn("encounter_and_clientdsid", md5(concat_ws("", $"encounterid", $"client_ds_id", $"grp_mpi")))
      .groupBy($"encounter_and_clientdsid")
      .agg(collect_list(struct(classOf[clinicalencounter_lite].getDeclaredFields.toList.withFilter(!_.isSynthetic()).map(f => $"${f.getName}"): _*)).as("clinical_encounters"))

    val combinedDf = groupedClaims.as("gclaim")
      .join(groupedClinicalEncounters.as("gclinical"), $"gclaim.encounter_and_clientdsid" === $"gclinical.encounter_and_clientdsid", "left_outer")
      .withColumn("final_encounterid", coalesce($"gclaim.encounter_and_clientdsid", $"gclinical.encounter_and_clientdsid"))
      .repartition(2048, $"final_encounterid")
      .as[temp_claim_and_clinicalencounter]

    combinedDf.mapPartitions(docs => {
      docs.toSeq.groupBy(_.final_encounterid).flatMap {
        case (encounterId, claims_and_clinical_encounters) => {
          claims_and_clinical_encounters.flatMap {
            case temp_claim_and_clinicalencounter(_, claimData, clinicalEncounterData) => {
              val min_svc_date = claimData.minBy(_.servicedate).servicedate
              val max_svc_date = claimData.maxBy(_.servicedate).servicedate
              val result = claimData.flatMap(cl => {
                val providerMap = pvdrMap(cl.client_ds_id)

                val deniedRollUpInd = deniedRollUps.get(cl.denied_flag)
                val capsvcflag = if (cl.capitated_service_flag != null && yOrN.contains(cl.capitated_service_flag)) cl.capitated_service_flag else null
                val pseudoflag = if (cl.pseudo_flag != null && yOrN.contains(cl.pseudo_flag)) cl.pseudo_flag else null
                val deniedflag = Seq(Some(cl.denied_flag), deniedRollUpInd).flatten.headOption.map(x => if (yOrN.contains(x)) x else null).orNull
                val billingproviderid = if (cl.localbillingproviderid != null) providerMap.get(cl.localbillingproviderid).orNull else null
                val orderingproviderid = if (cl.ordering_prov_id != null) providerMap.get(cl.ordering_prov_id).orNull else null
                val sourceId = if (predicateValues.contains(cl.client_ds_id)) cl.sourceid else "NA"

                // If clinicalencounterdata is null i.e. for a given encounterId in claim there is no matching encounter(s) in clinicalencounter then return claim_and_clinialencounter with null clinicalencounter values
                if (clinicalEncounterData == null) {
                  Seq(claim_and_clinialencounter(cl.groupid, cl.grp_mpi, cl.encounterid, cl.client_ds_id, null, cl.servicedate, null, null, cl.claim_mstrprovid, null, cl.mappedrev,
                    cl.mappedcpt, cl.mappedhcpcs, cl.localcpt, cl.mappedcptmod1, cl.mappedcptmod2, cl.mappedcptmod3, cl.mappedcptmod4, null, null, null, cl.quantity, cl.charge,
                    cl.paidamount, cl.allowedamount, cl.to_dt, cl.post_dt, cl.pos, min_svc_date, max_svc_date, cl.par_flag, sourceId, cl.contract_id, cl.network_paid_status, cl.fee_for_service_amt, cl.copay_amt,
                    cl.coinsurance_amt, cl.deductible_amt, cl.pat_liability_amt, cl.coord_benefits_amt, cl.withhold_amt, cl.capitation_amt, capsvcflag, deniedflag, pseudoflag, cl.claimid, cl.prov_svc_ii_spec,
                    cl.type_of_service, cl.other_1_amt, cl.other_2_amt, cl.other_3_amt, cl.other_4_amt, billingproviderid, orderingproviderid, cl.type_of_bill_code, cl.spec_rx_ind, cl.not_covered_amt,
                    cl.other_carrier_pay_amt, cl.admin_fee_amt, cl.claim_prov_affil_id, null, null, null, null, cl.claim_prov_status_id, cl.denied_flag,
                    cl.cust_attr_1, cl.cust_attr_2, cl.cust_attr_3, cl.cust_attr_4, cl.cust_attr_5, cl.cust_attr_6, cl.cust_attr_7, cl.cust_attr_8, cl.cust_attr_9, cl.cust_attr_10, cl.cust_attr_11, cl.cust_attr_12,
                    cl.cust_attr_13, cl.cust_attr_14, cl.cust_attr_15, cl.cust_attr_16, cl.cust_attr_17, cl.cust_attr_18, cl.cust_attr_19, cl.cust_attr_20,  cl.referring_prov_id, cl.admit_type_code))

                } else {
                  val (matchingClinicalEncounter, notMatchingClinicalEncounter) = clinicalEncounterData.partition(encounter => if (encounter != null) {
                    encounter.grp_mpi == cl.grp_mpi && encounter.client_ds_id == cl.client_ds_id
                  } else false)

                  val matchedClaims = matchingClinicalEncounter.map(encr => {
                    val patientTypeCui = if (encr.localpatienttype != null) patientType.get(encr.localpatienttype.toLowerCase).orNull else null
                    val dischargeDispositionCui = if (encr.localdischargedisposition != null) dischargeDisposition.get(encr.localdischargedisposition.toLowerCase).orNull else null
                    val drgTypeCui = if (encr.localdrgtype != null) drgTypes.get(encr.localdrgtype.toLowerCase).orNull else drgTypes.get("MSDRG".toLowerCase).orNull
                    val admitSourceCui = if (encr.localadmitsource != null) admitSource.get(encr.localadmitsource.toLowerCase).orNull else null

                    claim_and_clinialencounter(cl.groupid, cl.grp_mpi, cl.encounterid, cl.client_ds_id, encr.facilityid, cl.servicedate, encr.admittime, encr.dischargetime, cl.claim_mstrprovid, patientTypeCui, cl.mappedrev,
                      cl.mappedcpt, cl.mappedhcpcs, cl.localcpt, cl.mappedcptmod1, cl.mappedcptmod2, cl.mappedcptmod3, cl.mappedcptmod4, encr.localdrg, drgTypeCui, dischargeDispositionCui, cl.quantity, cl.charge,
                      cl.paidamount, cl.allowedamount, cl.to_dt, cl.post_dt, cl.pos, min_svc_date, max_svc_date, cl.par_flag, sourceId, cl.contract_id, cl.network_paid_status, cl.fee_for_service_amt, cl.copay_amt,
                      cl.coinsurance_amt, cl.deductible_amt, cl.pat_liability_amt, cl.coord_benefits_amt, cl.withhold_amt, cl.capitation_amt, capsvcflag, deniedflag, pseudoflag, cl.claimid, cl.prov_svc_ii_spec,
                      cl.type_of_service, cl.other_1_amt, cl.other_2_amt, cl.other_3_amt, cl.other_4_amt, billingproviderid, orderingproviderid, cl.type_of_bill_code, cl.spec_rx_ind, cl.not_covered_amt,
                      cl.other_carrier_pay_amt, cl.admin_fee_amt, cl.claim_prov_affil_id, encr.aprdrg_cd, encr.aprdrg_soi, encr.localdrgoutlier, admitSourceCui, cl.claim_prov_status_id, cl.denied_flag,
                      cl.cust_attr_1, cl.cust_attr_2, cl.cust_attr_3, cl.cust_attr_4, cl.cust_attr_5, cl.cust_attr_6, cl.cust_attr_7, cl.cust_attr_8, cl.cust_attr_9, cl.cust_attr_10, cl.cust_attr_11, cl.cust_attr_12,
                      cl.cust_attr_13, cl.cust_attr_14, cl.cust_attr_15, cl.cust_attr_16, cl.cust_attr_17, cl.cust_attr_18, cl.cust_attr_19, cl.cust_attr_20, cl.referring_prov_id, cl.admit_type_code)
                  })

                  val unmatchedClaims = notMatchingClinicalEncounter.map(encr => {
                    claim_and_clinialencounter(cl.groupid, cl.grp_mpi, cl.encounterid, cl.client_ds_id, null, cl.servicedate, null, null, cl.claim_mstrprovid, null, cl.mappedrev,
                      cl.mappedcpt, cl.mappedhcpcs, cl.localcpt, cl.mappedcptmod1, cl.mappedcptmod2, cl.mappedcptmod3, cl.mappedcptmod4, null, null, null, cl.quantity, cl.charge,
                      cl.paidamount, cl.allowedamount, cl.to_dt, cl.post_dt, cl.pos, min_svc_date, max_svc_date, cl.par_flag, sourceId, cl.contract_id, cl.network_paid_status, cl.fee_for_service_amt, cl.copay_amt,
                      cl.coinsurance_amt, cl.deductible_amt, cl.pat_liability_amt, cl.coord_benefits_amt, cl.withhold_amt, cl.capitation_amt, capsvcflag, deniedflag, pseudoflag, cl.claimid, cl.prov_svc_ii_spec,
                      cl.type_of_service, cl.other_1_amt, cl.other_2_amt, cl.other_3_amt, cl.other_4_amt, billingproviderid, orderingproviderid, cl.type_of_bill_code, cl.spec_rx_ind, cl.not_covered_amt,
                      cl.other_carrier_pay_amt, cl.admin_fee_amt, cl.claim_prov_affil_id, null, null, null, null, cl.claim_prov_status_id, cl.denied_flag,
                      cl.cust_attr_1, cl.cust_attr_2, cl.cust_attr_3, cl.cust_attr_4, cl.cust_attr_5, cl.cust_attr_6, cl.cust_attr_7, cl.cust_attr_8, cl.cust_attr_9, cl.cust_attr_10, cl.cust_attr_11, cl.cust_attr_12,
                      cl.cust_attr_13, cl.cust_attr_14, cl.cust_attr_15, cl.cust_attr_16, cl.cust_attr_17, cl.cust_attr_18, cl.cust_attr_19, cl.cust_attr_20, cl.referring_prov_id, cl.admit_type_code)
                  })

                  matchedClaims ++ unmatchedClaims
                }

              })
              result
            }
          }
        }
      }.toIterator
    }).as[claim_and_clinialencounter]
  }
}

case class claim_and_clinialencounter(groupid: String = null, grp_mpi: String = null, encounterid: String = null, client_ds_id: java.lang.Integer = null, facilityid: String = null, servicedate: java.sql.Timestamp = null,
                                      admittime: java.sql.Timestamp = null, dischargetime: java.sql.Timestamp = null, claim_mstrprovid: String = null, patientTypeCui: String = null, mappedrev: String = null,
                                      mappedcpt: String = null, mappedhcpcs: String = null, localcpt: String = null, mappedcptmod1: String = null, mappedcptmod2: String = null, mappedcptmod3: String = null, mappedcptmod4: String = null,
                                      localdrg: String = null, drgTypeCui: String = null, dischargeDispositionCui: String = null, quantity: String = null, charge: java.lang.Double = null, paidamount: java.lang.Double = null,
                                      allowedamount: java.lang.Double = null, to_dt: java.sql.Timestamp = null, post_dt: java.sql.Timestamp = null, pos: String = null, min_svc_date: java.sql.Timestamp = null,
                                      max_svc_date: java.sql.Timestamp = null, par_flag: String = null, sourceId: String = null, contract_id: String = null, network_paid_status: String = null, fee_for_service_amt: java.lang.Double = null,
                                      copay_amt: java.lang.Double = null, coinsurance_amt: java.lang.Double = null, deductible_amt: java.lang.Double = null, pat_liability_amt: java.lang.Double = null, coord_benefits_amt: java.lang.Double = null,
                                      withhold_amt: java.lang.Double = null, capitation_amt: java.lang.Double = null, capsvcflag: String = null, deniedflag: String = null, pseudoflag: String = null,
                                      claimid: String = null, prov_svc_ii_spec: java.lang.Integer = null, type_of_service: String = null, other_1_amt: java.lang.Double = null, other_2_amt: java.lang.Double = null,
                                      other_3_amt: java.lang.Double = null, other_4_amt: java.lang.Double = null, billingproviderid: String = null, orderingproviderid: String = null, type_of_bill_code: String = null,
                                      spec_rx_ind: String = null, not_covered_amt: java.lang.Double = null, other_carrier_pay_amt: java.lang.Double = null, admin_fee_amt: java.lang.Double = null, claim_prov_affil_id: String = null,
                                      aprdrg_cd: String = null, aprdrg_soi: String = null, localdrgoutlier: String = null, admitSourceCui: String = null, claim_prov_status_id: String = null,
                                      denied_flag: String = null, cust_attr_1: String = null, cust_attr_2: String = null, cust_attr_3: String = null, cust_attr_4: String = null, cust_attr_5: String = null, cust_attr_6: String = null,
                                      cust_attr_7: String = null, cust_attr_8: String = null, cust_attr_9: String = null, cust_attr_10: String = null, cust_attr_11: String = null, cust_attr_12: String = null,
                                      cust_attr_13: String = null, cust_attr_14: String = null, cust_attr_15: String = null, cust_attr_16: java.lang.Double = null, cust_attr_17: java.lang.Double = null,
                                      cust_attr_18: java.lang.Double = null, cust_attr_19: java.lang.Double = null, cust_attr_20: java.lang.Double = null, referring_prov_id: String = null, admit_type_code : String = null)
case class temp_claim_and_clinicalencounter(final_encounterid: String, claims: Seq[claim], clinical_encounters: Seq[clinicalencounter_lite])
case class temp_zo_provider(client_ds_id: java.lang.Integer = null, localproviderid: String = null, master_hgprovid: String = null)
case class temp_denied_rollup(denied_flag: String = null, denied_ind_rollup: String = null)
case class clinicalencounter_lite(admittime: java.sql.Timestamp = null, aprdrg_cd: String = null, aprdrg_soi: String = null, client_ds_id: java.lang.Integer = null,
                                  dischargetime: java.sql.Timestamp = null, encounterid: String = null, facilityid: String = null, grp_mpi: String = null, localadmitsource: String = null,
                                  localdischargedisposition: String = null, localdrg: String = null, localdrgoutlier: String = null, localdrgtype: String = null, localpatienttype: String = null)