package com.optum.oap.backend.etl.encgrps

import com.optum.oap.backend.cdrTempModel.{temp_enc_prov, temp_encounter_grp_prv}
import com.optum.oap.cdr.models.{map_provider_role, zh_provider, zh_provider_master_xref}
import com.optum.oap.sparkdataloader.{RuntimeVariables, TableInfo, UserDefinedFunctionForDataLoader}
import org.apache.spark.sql.expressions.Window
import org.apache.spark.sql.functions.{when, _}
import org.apache.spark.sql.types.LongType
import org.apache.spark.sql.{DataFrame, SparkSession}

object TEMP_ENCOUNTER_GRP_PRV extends TableInfo[temp_encounter_grp_prv] {

  override def dependsOn: Set[String] = Set("TEMP_ENC_PROV", "MAP_PROVIDER_ROLE", "ZH_PROVIDER_MASTER_XREF", "ZH_PROVIDER")

  override def name: String = "TEMP_ENCOUNTER_GRP_PRV"

  override def partitions: Int = 32

  override def createDataFrame(sparkSession: SparkSession,
                               loadedDependencies: Map[String, DataFrame],
                               udfMap: Map[String, UserDefinedFunctionForDataLoader],
                               runtimeVariables: RuntimeVariables): DataFrame = {

    import sparkSession.implicits._
    val tempEncProv = loadedDependencies("TEMP_ENC_PROV").as[temp_enc_prov]
    val mapProvRole = broadcast(loadedDependencies("MAP_PROVIDER_ROLE").as[map_provider_role])
    val zhProvMastRef = loadedDependencies("ZH_PROVIDER_MASTER_XREF").as[zh_provider_master_xref]
    val zhProv = loadedDependencies("ZH_PROVIDER").as[zh_provider]

    /*
    select   ep.groupid, ep.grp_mpi, ep.ENCOUNTER_GRP_NUM, ep.providerid, ep.client_ds_id,
    ep.encounterid, mr.cui as prov_role, pmx.master_hgprovid
      |,row_number() over (partition by ep.groupid, ep.grp_mpi, ep.ENCOUNTER_GRP_NUM, mr.cui
      |order by ep.groupid, ep.grp_mpi, ep.ENCOUNTER_GRP_NUM, mr.cui
      |, case when pmx.master_hgprovid is not null then 1 else 2 end
      |, encountertime desc nulls last
      |, case when encounteridtype = 'MASTER' then 1
      |when encounteridtype = 'ENCTR' then 2
      |when encounteridtype = 'ADD AS' then 3
      |when encounteridtype = 'ADD OT' then 4
      |when encounteridtype = 'ADD UN' then 5
      |when encounteridtype = 'ADD ER' then 6
      |when encounteridtype = 'ADD OB' then 7
      |when encounteridtype = 'ADD SD' then 8 else 9 end, ep.encounterid desc, ep.client_ds_id
      |,pmx.master_hgprovid desc nulls last) as provrank
      |from TEMP_ENC_PROV ep
      |inner join MAP_PROVIDER_ROLE mr on (ep.groupid = mr.groupid and ep.providerrole = mr.localcode)
      |left outer join ZH_PROVIDER_MASTER_XREF   pmx on (ep.groupid = pmx.groupid and ep.providerid = pmx.localproviderid and ep.client_ds_id = pmx.client_ds_id)
      |left outer join ZH_PROVIDER   p on (ep.groupid = p.groupid and ep.providerid = p.localproviderid and ep.client_ds_id = p.client_ds_id)
      |where (mr.cui in ('CH001417','CH001409','CH001408') and coalesce(p.providerexclusionflag,'N') = 'N')
      |or mr.cui = 'CH001815'  --am anticipating that we might have to flag the team providers as excluded from the ambulatory "most frequent" variables
     */

    val mrCuiList = List("CH001417", "CH001409", "CH001408")

    val tempDF = tempEncProv.as("ep")
      .join(mapProvRole.as("mr"),
        $"ep.groupid" === $"mr.groupid" and $"ep.providerrole" === $"mr.localcode", "inner")
      .join(zhProvMastRef.as("pmx"),
        $"ep.groupid" === $"pmx.groupid" and $"ep.providerid" === $"pmx.localproviderid"
          and $"ep.client_ds_id" === $"pmx.client_ds_id", "left_outer")
      .join(zhProv.as("p"),
        $"ep.groupid" === $"p.groupid" and $"ep.providerid" === $"p.localproviderid"
          and $"ep.client_ds_id" === $"p.client_ds_id", "left_outer")
      .where($"mr.cui".isin(mrCuiList: _*)
        .and(coalesce($"p.providerexclusionflag", lit("N")).equalTo("N"))
        .or($"mr.cui" === "CH001815"))
      .select($"ep.groupid", $"ep.grp_mpi", $"ep.ENCOUNTER_GRP_NUM",
        $"ep.providerid", $"ep.client_ds_id", $"ep.encounterid",
        $"mr.cui".as("prov_role"), $"pmx.master_hgprovid",
        row_number()
          .over(Window.partitionBy($"ep.groupid", $"ep.grp_mpi", $"ep.ENCOUNTER_GRP_NUM", $"mr.cui").
            orderBy($"p.groupid", $"ep.grp_mpi", $"ep.ENCOUNTER_GRP_NUM", $"mr.cui",
              when($"pmx.master_hgprovid".isNotNull, 1).otherwise(2),
              $"encountertime".desc_nulls_last,
              when($"encounteridtype" === "MASTER", 1).
                when($"encounteridtype" === "ENCTR", 2).
                when($"encounteridtype" === "ADD AS", 3).
                when($"encounteridtype" === "ADD OT", 4).
                when($"encounteridtype" === "ADD UN", 5).
                when($"encounteridtype" === "ADD ER", 6).
                when($"encounteridtype" === "ADD OB", 7).
                when($"encounteridtype" === "ADD SD", 8).otherwise(9),
              $"ep.encounterid".desc,
              $"ep.client_ds_id",
              $"pmx.master_hgprovid".desc_nulls_last)
          ).alias("provrank"))

    /*
      """
        |select ENCOUNTER_GRP_NUM
        |, max(case when provrank = 1 and prov_role = 'CH001408' then providerid else null end) as lastatt
        |, cast(max(case when provrank = 1 and prov_role = 'CH001408' then client_ds_id else null end) as long) as lastattphys_ds_id
        |, max(case when provrank = 1 and prov_role = 'CH001408' then master_hgprovid else null end) as lastattphys_mstr_id
        |, max(case when provrank = 1 and prov_role = 'CH001409' then providerid else null end) as ADMITTINGPHYSICIAN
        |, cast(max(case when provrank = 1 and prov_role = 'CH001409' then client_ds_id else null end) as long) as ADMITTINGPHYS_ds_id
        |, max(case when provrank = 1 and prov_role = 'CH001409' then master_hgprovid else null end) as ADMITTINGPHYS_mstr_id
        |, max(case when provrank = 1 and prov_role = 'CH001815' then providerid else null end) as lastattteam
        |, max(case when provrank = 1 and prov_role = 'CH001815' then client_ds_id else null end) as lastattteam_ds_id
        |, max(case when provrank = 1 and prov_role = 'CH001815' then master_hgprovid else null end) as lastattteam_mstr_id FROM (
        |select   ep.groupid, ep.grp_mpi, ep.ENCOUNTER_GRP_NUM, ep.providerid, ep.client_ds_id, ep.encounterid, mr.cui as prov_role, pmx.master_hgprovid
        |,row_number() over (partition by ep.groupid, ep.grp_mpi, ep.ENCOUNTER_GRP_NUM, mr.cui
        |order by ep.groupid, ep.grp_mpi, ep.ENCOUNTER_GRP_NUM, mr.cui
        |, case when pmx.master_hgprovid is not null then 1 else 2 end
        |, encountertime desc nulls last
        |, case when encounteridtype = 'MASTER' then 1
        |when encounteridtype = 'ENCTR' then 2
        |when encounteridtype = 'ADD AS' then 3
        |when encounteridtype = 'ADD OT' then 4
        |when encounteridtype = 'ADD UN' then 5
        |when encounteridtype = 'ADD ER' then 6
        |when encounteridtype = 'ADD OB' then 7
        |when encounteridtype = 'ADD SD' then 8 else 9 end, ep.encounterid desc, ep.client_ds_id
        |,pmx.master_hgprovid desc nulls last) as provrank
        |from TEMP_ENC_PROV ep
        |inner join MAP_PROVIDER_ROLE mr on (ep.groupid = mr.groupid and ep.providerrole = mr.localcode)
        |left outer join ZH_PROVIDER_MASTER_XREF   pmx on (ep.groupid = pmx.groupid and ep.providerid = pmx.localproviderid and ep.client_ds_id = pmx.client_ds_id)
        |left outer join ZH_PROVIDER   p on (ep.groupid = p.groupid and ep.providerid = p.localproviderid and ep.client_ds_id = p.client_ds_id)
        |where (mr.cui in ('CH001417','CH001409','CH001408') and coalesce(p.providerexclusionflag,'N') = 'N')
        |or mr.cui = 'CH001815'  --am anticipating that we might have to flag the team providers as excluded from the ambulatory "most frequent" variables
        |) temp
        |group by ENCOUNTER_GRP_NUM
      """.stripMargin
      */

    tempDF
      .groupBy($"ENCOUNTER_GRP_NUM")
      .agg(
        max(
          when($"provrank" === 1
            and $"prov_role" === "CH001408", $"providerid")
            .otherwise(null)
        ).as("lastatt"),
        max(
          when($"provrank" === 1
            and $"prov_role" === "CH001408", $"client_ds_id"
          ).otherwise(null).cast(LongType)
        ).as("lastattphys_ds_id"),
        max(
          when($"provrank" === 1
            and $"prov_role" === "CH001408", $"master_hgprovid")
            .otherwise(null)
        ).as("lastattphys_mstr_id"),
        max(
          when($"provrank" === 1
            and $"prov_role" === "CH001409", $"providerid")
            .otherwise(null)
        ).as("ADMITTINGPHYSICIAN"),
        max(
          when($"provrank" === 1
            and $"prov_role" === "CH001409", $"client_ds_id"
          ).otherwise(null).cast(LongType)
        ).as("ADMITTINGPHYS_ds_id"),
        max(
          when($"provrank" === 1
            and $"prov_role" === "CH001409", $"master_hgprovid")
            .otherwise(null)
        ).as("ADMITTINGPHYS_mstr_id"),
        max(
          when($"provrank" === 1
            and $"prov_role" === "CH001815", $"providerid")
            .otherwise(null)
        ).as("lastattteam"),
        max(
          when($"provrank" === 1
            and $"prov_role" === "CH001815", $"client_ds_id")
            .otherwise(null)
        ).as("lastattteam_ds_id"),
        max(
          when($"provrank" === 1
            and $"prov_role" === "CH001815", $"master_hgprovid")
            .otherwise(null)
        ).as("lastattteam_mstr_id")
      )
      .select($"ENCOUNTER_GRP_NUM",
        $"lastatt",
        $"lastattphys_ds_id",
        $"lastattphys_mstr_id",
        $"ADMITTINGPHYSICIAN",
        $"ADMITTINGPHYS_ds_id",
        $"ADMITTINGPHYS_mstr_id",
        $"lastattteam",
        $"lastattteam_ds_id",
        $"lastattteam_mstr_id"
      )
  }
}
