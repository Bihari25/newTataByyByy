package com.optum.oap.backend.etl.encgrps

import com.optum.oap.backend.cdrTempModel.temp_eeg_p1d
import com.optum.oap.sparkdataloader.QueryAndMetadata


//Assign PrinDx to encounters when one is missing.
object TEMP_EEG_P1D extends QueryAndMetadata[temp_eeg_p1d] {
  override def name: String = "TEMP_EEG_P1D"

  override def partitions: Int = 32

  override def sparkSql: String =
    """
      |SELECT
      |    *
      |FROM
      |    (
      |        SELECT
      |            ce.groupid,
      |            ce.client_ds_id,
      |            ce.encounterid,
      |            ce.grp_mpi,
      |            d.prindx,
      |            d.prindx_codetype,
      |            ROW_NUMBER() OVER(
      |                PARTITION BY ce.groupid,ce.client_ds_id,ce.encounterid
      |                ORDER BY
      |                    datediff(to_date(least(ce.dischargetime,d.dischargetime)), to_date(greatest(ce.arrivaltime,d.arrivaltime))) DESC,
      |                    d.client_ds_id,d.encounterid
      |            ) AS dx_order
      |        FROM
      |            (
      |                SELECT  /*+  BROADCASTJOIN(f) */
      |                    ce.groupid,
      |                    ce.client_ds_id,
      |                    ce.encounterid,
      |                    ce.grp_mpi,
      |                    coalesce(ce.master_facility_name,f.master_facility_name) AS master_facility_name,
      |                    ce.arrivaltime,
      |                    ce.dischargetime,
      |                    ce.patienttype,
      |                    ce.prindx
      |                FROM
      |                    temp_eeg_p1a ce
      |                    LEFT OUTER JOIN temp_eeg_p1f f ON ( ce.groupid = f.groupid
      |                                                        AND ce.client_ds_id = f.client_ds_id
      |                                                        AND ce.encounterid = f.encounterid
      |                                                        AND ce.grp_mpi = f.grp_mpi )
      |            ) ce
      |            INNER JOIN (
      |                SELECT /*+  BROADCASTJOIN(f) */
      |                    ce.groupid,
      |                    ce.client_ds_id,
      |                    ce.encounterid,
      |                    ce.grp_mpi,
      |                    coalesce(ce.master_facility_name,f.master_facility_name) AS master_facility_name,
      |                    ce.arrivaltime,
      |                    ce.dischargetime,
      |                    ce.patienttype,
      |                    ce.prindx,
      |                    prindx_codetype
      |                FROM
      |                    temp_eeg_p1a ce
      |                    LEFT OUTER JOIN temp_eeg_p1f f ON ( ce.groupid = f.groupid
      |                                                        AND ce.client_ds_id = f.client_ds_id
      |                                                        AND ce.encounterid = f.encounterid
      |                                                        AND ce.grp_mpi = f.grp_mpi )
      |            ) d ON ( ce.grp_mpi = d.grp_mpi
      |                     AND ce.patienttype = d.patienttype
      |                     AND coalesce(ce.master_facility_name,'N/A') = coalesce(d.master_facility_name,'N/A')
      |                     AND ce.prindx IS NULL
      |                     AND d.prindx IS NOT NULL
      |                     AND datediff(to_date(least(ce.dischargetime,d.dischargetime)), to_date(greatest(ce.arrivaltime,d.arrivaltime))) + 1 > 1  --must overlap by more than one day
      |                 )
      |    )
      |WHERE
      |    dx_order = 1
    """.stripMargin

  override def dependsOn: Set[String] = Set("TEMP_EEG_P1A","TEMP_EEG_P1F")
}