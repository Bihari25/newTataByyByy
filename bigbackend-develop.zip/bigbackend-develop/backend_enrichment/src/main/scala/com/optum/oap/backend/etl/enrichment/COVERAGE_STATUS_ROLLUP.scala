package com.optum.oap.backend.etl.enrichment

import com.optum.oap.backend.etl.common.MapMasterIds
import com.optum.oap.backend.loader.EnrichmentRunTimeVariables
import com.optum.oap.cdr.models.{coverage_status_rollup, int_claim_member, map_coverage_status}
import com.optum.oap.sparkdataloader.{RuntimeVariables, TableInfo, UserDefinedFunctionForDataLoader}
import org.apache.hadoop.yarn.webapp.hamlet.HamletSpec.SUB
import org.apache.spark
import org.apache.spark.sql.expressions.Window
import org.apache.spark.sql.{DataFrame, SparkSession}
import org.slf4j.LoggerFactory
import org.apache.spark.sql.functions.{coalesce, length, regexp_replace, _}
import org.apache.spark.sql.types.DataTypes
import org.apache.spark.sql.types._


object COVERAGE_STATUS_ROLLUP extends TableInfo[coverage_status_rollup] {

  private val log = LoggerFactory.getLogger(this.getClass)

  override def dependsOn = Set("CDR_FE_COVERAGE_STATUS_ROLLUP", "INT_CLAIM_MEMBER", "MAP_COVERAGE_STATUS")

  override def name = "COVERAGE_STATUS_ROLLUP"

  override def partitions: Int = 32

  override def createDataFrame(sparkSession: SparkSession,
                               loadedDependencies: Map[String, DataFrame],
                               udfMap: Map[String, UserDefinedFunctionForDataLoader],
                               runtimeVariables: RuntimeVariables): DataFrame = {

    import sparkSession.implicits._

    val cdrCoverageStatusRollup = loadedDependencies("CDR_FE_COVERAGE_STATUS_ROLLUP").as[coverage_status_rollup]

    val intClaimMemberDf = loadedDependencies("INT_CLAIM_MEMBER").as[int_claim_member]

    val mapCoverageStatusDf = broadcast(loadedDependencies("MAP_COVERAGE_STATUS")).as[map_coverage_status]

    val groupId = runtimeVariables.asInstanceOf[EnrichmentRunTimeVariables].clientId

    //Frontend CoverageStatus Rollup table
    val cdrFeCSRollup1 = cdrCoverageStatusRollup.select(
      $"groupid",
      $"client_ds_id",
      $"datasrc",
      $"subscriber_relation",
      $"coverage_status_desc",
      $"coverage_status_lv2",
      $"coverage_status_lv2_desc",
      $"coverage_status_lv1",
      $"coverage_status_lv1_desc",
      $"coverage_status_rollup"
    )

    //Filtering Frontend CoverageStatus Rollup table
    val cdrFeCSR = cdrFeCSRollup1
      .dropDuplicates("subscriber_relation")
      .select("*")

    //getting the records from intclaimmember whose COVERAGE_STATUS_CODE is not in the CoverageStatus rollup
    val iCM2 = intClaimMemberDf.as("a").join(cdrFeCSR.as("b"), $"a.coverage_status_code" === $"b.subscriber_relation", "left")
      .select($"a.groupid",
        $"a.client_ds_id",
        lit("int_claim_member").cast(StringType).as("datasrc"),
        $"a.coverage_status_code".as("subscriber_relation"),
        concat(lit("UNDEFINED ("), $"a.coverage_status_code" , lit(")")).as("coverage_status_desc"),
        $"b.coverage_status_lv2",
        $"b.coverage_status_lv2_desc",
        $"b.coverage_status_lv1",
        $"b.coverage_status_lv1_desc",
        $"b.coverage_status_rollup"
      )
      .where(($"a.coverage_status_code" isNotNull) && (length($"a.coverage_status_code") <=30)&& ($"b.subscriber_relation" isNull))
      .groupBy($"a.groupid",$"subscriber_relation"
        ,$"datasrc",$"coverage_status_desc",$"b.coverage_status_lv2",
        $"b.coverage_status_lv2_desc",
        $"b.coverage_status_lv1",
        $"b.coverage_status_lv1_desc",
        $"b.coverage_status_rollup")
      .agg(min($"a.client_ds_id").as("client_ds_id"))

    //union the missed records from intclaimmember and the original table
    val unionCovStatRollup = cdrFeCSRollup1.unionByName(iCM2)

    //Applying the additional logic and loading to the backend table.
    val rollup = unionCovStatRollup.as("a").join(mapCoverageStatusDf.as("b"),($"a.subscriber_relation" === $"b.localcode") && ($"b.groupid" === groupId), "left")
      .select(
        $"a.groupid"
      ,$"client_ds_id"
      ,$"datasrc"
      ,$"subscriber_relation"
      ,substring(coalesce($"coverage_status_desc", concat(lit("UNDEFINED ("),$"subscriber_relation",lit(")"))),1,150).as("coverage_status_desc")
      ,substring(coalesce($"coverage_status_lv2", concat(lit("3."),$"subscriber_relation")),1,30).as("coverage_status_lv2")
      ,substring(when($"coverage_status_lv2".isNull,coalesce($"coverage_status_desc",concat(lit("UNDEFINED ("),$"subscriber_relation",lit(")"))))
        .otherwise(coalesce($"coverage_status_lv2_desc",concat(lit("UNDEFINED ("),$"coverage_status_lv2",lit(")")))) ,1,150)
        .as("coverage_status_lv2_desc")
      ,substring(when($"coverage_status_lv1".isNotNull,$"a.coverage_status_lv1")
        .otherwise(when($"coverage_status_lv2".isNotNull,concat(lit("2."),$"coverage_status_lv2"))
          .otherwise(concat(lit("3."),$"subscriber_relation"))),1,30).as("coverage_status_lv1")
      ,substring(when($"coverage_status_lv1".isNull,
        when($"a.coverage_status_lv2".isNull,coalesce($"coverage_status_desc",concat(lit("UNDEFINED ("),$"subscriber_relation",lit(")")) ))
          .otherwise(coalesce($"coverage_status_lv2_desc",concat(lit("UNDEFINED ("),$"coverage_status_lv2",lit(")")) )))
        .otherwise(coalesce($"coverage_status_lv1_desc",concat(lit("UNDEFINED ("),$"coverage_status_lv1",lit(")")))),1,150).as("coverage_status_lv1_desc")
        ,when(upper(when($"coverage_status_rollup" === lit("SUB"),lit("0"))
          .otherwise(when($"coverage_status_rollup" === lit("SPS"),lit("1"))
            .otherwise(when($"coverage_status_rollup" === lit("DEP"),lit("2"))
                        .otherwise(when($"coverage_status_rollup" isNull ,lit("3"))
                        .otherwise($"coverage_status_rollup"))
            )))
          .isin ("0", "1", "2") ,upper(when($"coverage_status_rollup" === lit("SUB"),lit("0"))
          .otherwise(when($"coverage_status_rollup" === lit("SPS"),lit("1"))
            .otherwise(when($"coverage_status_rollup" === lit("DEP"),lit("2"))
                       .otherwise($"coverage_status_rollup")))))
          .otherwise(
            when(($"b.CUI") === lit("CH004070"),lit("0"))
              .otherwise(when(($"b.CUI") === lit("CH004071"),lit("1"))
                .otherwise(when(($"b.CUI") === lit("CH004072"),lit("2"))))).as("coverage_status_rollup")
      ,row_number().over(Window.partitionBy($"subscriber_relation")
        .orderBy(
          when($"coverage_status_desc".isNotNull, lit(0)).otherwise(lit(1)),
          when($"coverage_status_lv2".isNotNull, lit(0)).otherwise(lit(1)),
          when($"coverage_status_lv1".isNotNull, lit(0)).otherwise(lit(1)),
          $"coverage_status_desc",
          $"coverage_status_lv2",
          $"coverage_status_lv1")).as("rn")
    )
      .where(($"subscriber_relation" isNotNull) && (length($"subscriber_relation") <=30) && ($"rn"=== 1))
      .drop($"rn")

    rollup.as[coverage_status_rollup].toDF()
  }
}