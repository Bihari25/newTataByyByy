package com.optum.oap.backend.etl.bpo

import com.optum.oap.backend.cdrTempModel.{temp_bpo_calculate_params, temp_bpo_insurance, temp_bpo_patients}
import com.optum.oap.backend.etl.bpo.BpoUtil.getBpoInputParameters
import com.optum.oap.backend.etl.common.{CDRConstants, IsSafeToNumber, calendar_data}
import com.optum.oap.backend.loader.EnrichmentRunTimeVariables
import com.optum.oap.cdr.models._
import com.optum.oap.sparkdataloader.{RuntimeVariables, TableInfo, UserDefinedFunctionForDataLoader}
import org.apache.spark.sql.expressions.Window
import org.apache.spark.sql.functions.{to_date, _}
import org.apache.spark.sql.types.{DoubleType, IntegerType, StringType, TimestampType}
import org.apache.spark.sql.{DataFrame, SparkSession}

/**
  *
  * Copyright 2019 Optum Analytics
  *
  * Date: 5/20/19
  *
  * Creator: pavula1
  */
object TEMP_BPO_INSURANCE extends TableInfo[temp_bpo_insurance] {
  override def dependsOn = Set("PROV_PAT_REL", "ZO_BPO_MAP_EMPLOYER", "PAT_RISK_ATTRIB", "PATIENT_ATTRIBUTE", "CLAIM_MEMBER_MONTHS",
    "TEMP_BPO_PATIENTS", "TEMP_BPO_CALCULATE_PARAMS", "CALENDAR", "PATIENT_ID", "CONTRACT_ROLLUP")

  override def name = "TEMP_BPO_INSURANCE"

  override def createDataFrame(sparkSession: SparkSession,
                               loadedDependencies: Map[String, DataFrame],
                               udfMap: Map[String, UserDefinedFunctionForDataLoader],
                               runtimeVariables: RuntimeVariables): DataFrame = {

    import sparkSession.implicits._

    val provPatRel = loadedDependencies("PROV_PAT_REL").as[prov_pat_rel]

    val mapEmployer = broadcast(loadedDependencies("ZO_BPO_MAP_EMPLOYER")).as[zo_bpo_map_employer]

    val patRiskAttrib = loadedDependencies("PAT_RISK_ATTRIB").as[pat_risk_attrib]

    val patientAttribute = loadedDependencies("PATIENT_ATTRIBUTE").as[patient_attribute]

    val memberMonths = loadedDependencies("CLAIM_MEMBER_MONTHS").as[claim_member_months]

    val tempBpoPatients = loadedDependencies("TEMP_BPO_PATIENTS").as[temp_bpo_patients]

    val tempParams = broadcast(loadedDependencies("TEMP_BPO_CALCULATE_PARAMS")).as[temp_bpo_calculate_params]

    val calendar = broadcast(loadedDependencies("CALENDAR")).as[calendar_data]

    val patientId = loadedDependencies("PATIENT_ID").as[patient_id]

    val contractRollup = broadcast(loadedDependencies("CONTRACT_ROLLUP")).as[contract_rollup]

    val inputParameters = getBpoInputParameters(sparkSession, tempParams)
    val startDate = inputParameters.engineStartDate
    val endDate = inputParameters.engineEndDate

    val pprJoin = provPatRel.alias("p").filter($"mstrprovid".isNotNull && $"localrelshipcode" === "PCP")
      .join(mapEmployer.alias("pyr"), Seq("groupid", "client_ds_id"), "inner")
      .select($"pyr.employeraccountid",
        $"p.groupid",
        $"p.grp_mpi",
        $"p.startdate",
        coalesce($"p.enddate", current_date()).alias("enddate"),
        $"p.mstrprovid".alias("pcpid"),
        $"p.prov_affil_id".as("pcp_affil")
      )
      .distinct()

    val praJoin = patRiskAttrib.alias("p").filter($"grp_mpi".isNotNull && $"start_date".isNotNull)
      .join(mapEmployer.alias("pyr"), Seq("groupid", "client_ds_id"), "inner")
      .select($"pyr.employeraccountid",
        $"p.groupid",
        $"p.grp_mpi",
        $"p.start_date",
        coalesce($"p.end_date", current_date()).alias("end_date"),
        $"p.at_risk_status",
        $"p.risk_type"
      )
      .distinct()

    val ptr1 = patientAttribute.where(
      ($"attribute_type_cui".isin("CH004044", "CH004045", "CH004046", "CH004047") && length($"attribute_value") <= 30) ||
        $"attribute_type_cui".isin("CH004024", "CH004025", "CH004026", "CH004027", "CH004028", "CH004029", "CH004030", "CH004031", "CH004032", "CH004033", "CH004034", "CH004035", "CH004036", "CH004037", "CH004038") ||
        ($"attribute_type_cui".isin("CH004039", "CH004040", "CH004041", "CH004042", "CH004043") && IsSafeToNumber.isSafeToNumber($"attribute_value")))
      .select($"grp_mpi",
        $"attribute_type_cui",
        $"attribute_value",
        $"eff_date",
        $"end_date",
        row_number().over(Window.partitionBy($"grp_mpi", $"attribute_type_cui")
          .orderBy($"client_ds_id", $"datasrc", $"attribute_value", $"eff_date".desc_nulls_last, $"end_date".desc_nulls_first)).alias("rwid")
      )
      .where($"rwid" === 1)

    val ptrJoin = ptr1
      .groupBy($"grp_mpi", $"eff_date", $"end_date")
      .pivot(
        "attribute_type_cui",
        Seq("CH004024",
          "CH004025",
          "CH004026",
          "CH004027",
          "CH004028",
          "CH004029",
          "CH004030",
          "CH004031",
          "CH004032",
          "CH004033",
          "CH004034",
          "CH004035",
          "CH004036",
          "CH004037",
          "CH004038",
          "CH004039",
          "CH004040",
          "CH004041",
          "CH004042",
          "CH004043",
          "CH004044",
          "CH004045",
          "CH004046",
          "CH004047"
        )).agg(max($"attribute_value")).select($"grp_mpi",
      $"eff_date",
      $"end_date",
      $"CH004024".alias("cust_mem_attr1"),
      $"CH004025".alias("cust_mem_attr2"),
      $"CH004026".alias("cust_mem_attr3"),
      $"CH004027".alias("cust_mem_attr4"),
      $"CH004028".alias("cust_mem_attr5"),
      $"CH004029".alias("cust_mem_attr6"),
      $"CH004030".alias("cust_mem_attr7"),
      $"CH004031".alias("cust_mem_attr8"),
      $"CH004032".alias("cust_mem_attr9"),
      $"CH004033".alias("cust_mem_attr10"),
      $"CH004034".alias("cust_mem_attr11"),
      $"CH004035".alias("cust_mem_attr12"),
      $"CH004036".alias("cust_mem_attr13"),
      $"CH004037".alias("cust_mem_attr14"),
      $"CH004038".alias("cust_mem_attr15"),
      $"CH004039".cast(DoubleType).alias("cust_mem_attr16"),
      $"CH004040".cast(DoubleType).alias("cust_mem_attr17"),
      $"CH004041".cast(DoubleType).alias("cust_mem_attr18"),
      $"CH004042".cast(DoubleType).alias("cust_mem_attr19"),
      $"CH004043".cast(DoubleType).alias("cust_mem_attr20"),
      $"CH004044".alias("mem_userdef_1"),
      $"CH004045".alias("mem_userdef_2"),
      $"CH004046".alias("mem_userdef_3"),
      $"CH004047".alias("mem_userdef_4")
    )

    val mthJoin = memberMonths.where($"effective_date".between(to_timestamp(lit(startDate), CDRConstants.DATE_FORMAT_4Y2M2D), to_timestamp(lit(endDate), CDRConstants.DATE_FORMAT_4Y2M2D)))
      .select($"groupid",
        $"product_code",
        $"claims_year",
        $"claims_month",
        $"effective_date",
        $"claim_count",
        $"rx_count",
        $"dental_count"
      ).groupBy("groupid", "product_code", "claims_year", "claims_month", "effective_date")
      .agg(sum($"claim_count").alias("pyr_claim_count"), sum($"rx_count").alias("pyr_rx_count"), sum($"dental_count").alias("pyr_dental_count"))

    val pts = tempBpoPatients.where($"payer" === 1)
      .select($"groupid",
        $"grp_mpi",
        $"mapped_gender",
        $"dob",
        $"contract_id"
      ).distinct()

    val tempPid = patientId.as("pid")
      .where($"pid.idtype".isin("NAT_ID", "NAT2_ID") && length($"pid.idtype") <= 30)
      .join(mapEmployer.as("pyr"),  $"pid.groupid" === $"pyr.groupid" && $"pid.client_ds_id" === $"pyr.client_ds_id", "inner")
      .select($"pid.groupid", $"grp_mpi", $"employeraccountid", $"idtype")

    val pid = patientId.as("pid")
      .where($"pid.idtype".isin("NAT_ID", "NAT2_ID") && length($"pid.idtype") <= 30)
      .join(mapEmployer.as("pyr"), $"pid.groupid" === $"pyr.groupid" && $"pid.client_ds_id" === $"pyr.client_ds_id", "inner")
      .groupBy($"pid.groupid", $"grp_mpi", $"employeraccountid")
      .agg(max($"pid.patientid").as("max_patient_id"))
      .join(tempPid, Seq("groupid", "grp_mpi", "employeraccountid"), "inner")
      .select(
        $"pid.groupid".as("groupid"),
        $"pid.grp_mpi".as("grp_mpi"),
        $"pyr.employeraccountid".as("employeraccountid"),
        when($"idtype" === lit("NAT_ID"), $"max_patient_id").as("sec_member_id_1"),
        when($"idtype" === lit("NAT2_ID"), $"max_patient_id").as("sec_member_id_2")
    )

    val partitionMultiplier = EnrichmentRunTimeVariables(runtimeVariables).partitionMultiplier
    val repNum = Math.ceil(partitions * partitionMultiplier).toInt

    val allJoin = pts.alias("pat")
      .join(
        mthJoin.alias("mth").where($"mth.pyr_claim_count" > 0),
        $"pat.groupid" === $"mth.groupid", "inner")
      .join(tempBpoPatients.alias("ins"),
        $"ins.groupid" === $"pat.groupid" &&
          $"ins.grp_mpi" === $"pat.grp_mpi" &&
          $"mth.product_code" === $"ins.employeraccountid", "inner")
      .where(to_date(date_format($"mth.effective_date", "yyyyMM"), "yyyyMM").between(to_date(date_format($"ins.effective_date", "yyyyMM"), "yyyyMM"), to_date(date_format($"ins.end_date", "yyyyMM"), "yyyyMM")) && $"payer" === 1)
      .join(memberMonths.alias("c"),
        $"pat.groupid" === $"c.groupid" &&
          $"ins.grp_mpi" === $"c.grp_mpi" &&
          $"mth.claims_year" === $"c.claims_year" &&
          $"mth.claims_month" === $"c.claims_month" &&
          $"c.product_code" === $"ins.employeraccountid" &&
          to_date($"c.effective_date").between(to_date(lit(startDate), CDRConstants.DATE_FORMAT_4Y2M2D), to_date(lit(endDate), CDRConstants.DATE_FORMAT_4Y2M2D)),
        "left_outer")
      .join(pprJoin.alias("ppr"),
        $"ppr.groupid" === $"pat.groupid" &&
          $"ppr.grp_mpi" === $"pat.grp_mpi" &&
          $"ppr.employeraccountid" === $"ins.employeraccountid" &&
          $"mth.effective_date".between($"ppr.startdate", $"ppr.enddate"), "left_outer")
      .join(praJoin.alias("pra"),
        $"pra.groupid" === $"pat.groupid" &&
          $"pra.grp_mpi" === $"pat.grp_mpi" &&
          $"pra.employeraccountid" === $"ins.employeraccountid" &&
          $"mth.effective_date".between($"pra.start_date", $"pra.end_date"), "left_outer")
      .join(ptrJoin.alias("ptr"),
        $"ptr.grp_mpi" === $"pat.grp_mpi" &&
          $"mth.effective_date".between($"ptr.eff_date", $"ptr.end_date"), "left_outer")
      .join(pid.as("pid"),
      $"pat.groupid" === $"pid.groupid" &&
        $"pat.grp_mpi" === $"pid.grp_mpi" &&
        $"pid.employeraccountid" === $"ins.employeraccountid", "left_outer")
      .join(contractRollup.as("cr"),
      $"pat.groupid" === $"cr.groupid" &&
      $"pat.contract_id" === $"cr.contract_id", "left_outer")
      .select(
        $"pat.*", $"mth.*", $"ins.*",
        $"c.claim_paid_amount".as("claim_paid_amount"),
        $"c.rx_paid_amount".as("rx_paid_amount"),
        $"c.claim_count".as("claim_count"),
        $"c.rx_count".as("rx_count"),
        $"ppr.pcpid".as("pcpid"),
        $"ppr.pcp_affil".as("pcp_affil"),
        $"ppr.enddate".as("enddate"),
        $"ppr.startdate".as("startdate"),
        $"pra.at_risk_status".as("at_risk_status"),
        $"pra.risk_type".as("risk_type"),
        $"cr.contract_hier".as("contract_hier"),
        $"cust_mem_attr1".as("cust_mem_attr1"),
        $"cust_mem_attr2".as("cust_mem_attr2"),
        $"cust_mem_attr3".as("cust_mem_attr3"),
        $"cust_mem_attr4".as("cust_mem_attr4"),
        $"cust_mem_attr5".as("cust_mem_attr5"),
        $"cust_mem_attr6".as("cust_mem_attr6"),
        $"cust_mem_attr7".as("cust_mem_attr7"),
        $"cust_mem_attr8".as("cust_mem_attr8"),
        $"cust_mem_attr9".as("cust_mem_attr9"),
        $"cust_mem_attr10".as("cust_mem_attr10"),
        $"cust_mem_attr11".as("cust_mem_attr11"),
        $"cust_mem_attr12".as("cust_mem_attr12"),
        $"cust_mem_attr13".as("cust_mem_attr13"),
        $"cust_mem_attr14".as("cust_mem_attr14"),
        $"cust_mem_attr15".as("cust_mem_attr15"),
        $"cust_mem_attr16".as("cust_mem_attr16"),
        $"cust_mem_attr17".as("cust_mem_attr17"),
        $"cust_mem_attr18".as("cust_mem_attr18"),
        $"cust_mem_attr19".as("cust_mem_attr19"),
        $"cust_mem_attr20".as("cust_mem_attr20"),
        $"mem_userdef_1",
        $"mem_userdef_2",
        $"mem_userdef_3",
        $"mem_userdef_4",
        $"sec_member_id_1",
        $"sec_member_id_2"
      )
      .repartition(repNum, $"pat.groupid", $"pat.grp_mpi", $"mth.effective_date", $"ins.employeraccountid")
      .select(
        $"pat.groupid",
        $"pat.grp_mpi",
        $"pat.dob",
        $"pat.mapped_gender",
        lit("PAYER").alias("healthplansource"),
        $"ins.employeraccountid",
        $"mth.effective_date".alias("member_start"),
        date_sub(add_months($"mth.effective_date", 1), 1).alias("member_end"),
        $"productcode",
        $"pcpid",
        when($"ins.pharmacy_benefit_flag" === "N", "N")
          .when($"mth.pyr_rx_count" > 0, "Y").otherwise("N").alias("pharmacy"),
        lit("PA").alias("product_source"),
        $"ins.lineofbusinessid",
        $"ins.mapped_race",
        $"ins.mapped_ethnicity",
        $"ins.mapped_language",
        row_number().over(Window.partitionBy($"pat.groupid", $"pat.grp_mpi", $"mth.effective_date")
          .orderBy(
            coalesce($"contract_hier",lit(99)),
            $"ins.effective_date".desc,
            $"ins.end_date".desc,
            $"ins.contract_id",
            $"enddate".desc,
            $"startdate".desc,
            $"pcpid".asc_nulls_last,
            $"at_risk_status".desc
            )
        ).alias("prodrank"),
        row_number().over(Window.partitionBy($"pat.groupid", $"pat.grp_mpi", $"mth.effective_date", $"ins.employeraccountid")
          .orderBy(
            coalesce($"contract_hier",lit(99)),
            $"ins.effective_date".desc,
            $"ins.end_date".desc,
            $"ins.contract_id".desc,
            $"enddate".desc,
            $"startdate".desc,
            $"pcpid".asc_nulls_last,
            $"at_risk_status".desc)
        ).alias("payrank"),
        size(collect_set($"ins.employeraccountid")
          .over(Window.partitionBy($"pat.groupid", $"pat.grp_mpi"))).alias("distinct_pyrcnt"),
        $"ins.date_of_death",
        $"ins.contract_id",
        $"at_risk_status",
        $"cust_mem_attr1",
        $"cust_mem_attr2",
        $"cust_mem_attr3",
        $"cust_mem_attr4",
        $"cust_mem_attr5",
        $"cust_mem_attr6",
        $"ins.subscriberid",
        $"ins.subscriberflag",
        $"ins.coverage_status",
        $"ins.emp_acct_id",
        $"ins.contracttype",
        $"ins.benefitplan",
        $"ins.coverageclasscode",
        when($"ins.dental_benefit_ind" === lit(0), lit("N"))
          .when(coalesce($"mth.pyr_dental_count", lit(0)) === lit(0), lit("N"))
          .otherwise(lit("Y")).as("dental_benefit"),
        $"ins.medical_benefit_ind",
        $"ins.mh_benefit_ind",
        $"ins.employee_type",
        $"ins.hra_ind",
        $"ins.hsa_ind",
        $"ins.product_dtl_code",
        $"pcp_affil",
        $"risk_type",
        $"mem_userdef_1",
        $"mem_userdef_2",
        $"mem_userdef_3",
        $"mem_userdef_4",
        $"cust_mem_attr7",
        $"cust_mem_attr8",
        $"cust_mem_attr9",
        $"cust_mem_attr10",
        $"cust_mem_attr11",
        $"cust_mem_attr12",
        $"cust_mem_attr13",
        $"cust_mem_attr14",
        $"cust_mem_attr15",
        $"cust_mem_attr16",
        $"cust_mem_attr17",
        $"cust_mem_attr18",
        $"cust_mem_attr19",
        $"cust_mem_attr20",
        $"sec_member_id_1",
        $"sec_member_id_2"
        )


    val calLevel = calendar.select($"SERIAL_NUM".as("level"))
    val crossedDataTemp = tempParams.crossJoin(calLevel)
      .where($"level" <= months_between(date_add(to_date($"engineenddate", CDRConstants.DATE_FORMAT_4Y2M2D), 1), to_date($"engineStartDate3", CDRConstants.DATE_FORMAT_4Y2M2D))).alias("crossedTemp")

    val crossedTemp = crossedDataTemp.select(expr(s"add_months(to_date(engineStartDate3, '${CDRConstants.DATE_FORMAT_4Y2M2D}'), level - 1)").alias("months"))

    val insSelect = allJoin.select($"grp_mpi", $"member_start").distinct()

    val tempSelect = tempBpoPatients.
      select($"groupid",
        $"grp_mpi",
        $"mapped_gender",
        $"dob",
        $"mapped_race",
        $"mapped_ethnicity",
        $"mapped_language",
        $"date_of_death").distinct()


    val result = tempSelect.alias("temp").crossJoin(crossedTemp.alias("dates"))
      .join(insSelect.alias("ins"), $"temp.grp_mpi" === $"ins.grp_mpi" && date_format($"dates.months", "yyyyMM") === date_format($"ins.member_start", "yyyyMM"), "left_outer")
      .where($"ins.grp_mpi".isNull)
      .select(
        $"temp.groupid",
        $"temp.grp_mpi",
        $"temp.dob",
        $"temp.mapped_gender",
        lit("PROVIDER").alias("healthplansource"),
        lit(null).cast(StringType).alias("employeraccountid"),
        $"dates.months".alias("member_start"),
        last_day($"dates.months").cast(TimestampType).alias("member_end"),
        lit(null).cast(StringType).alias("productcode"),
        lit(null).cast(StringType).alias("pcpid"),
        when(date_format($"dates.months", "yyyyMM") === date_format(lit(endDate), "yyyyMM"), "Y").otherwise("N").alias("pharmacy"),
        lit(null).cast(StringType).alias("product_source"),
        lit(null).cast(IntegerType).alias("lineofbusinessid"),
        $"temp.mapped_race",
        $"temp.mapped_ethnicity",
        $"temp.mapped_language",
        lit(1).alias("prodrank"),
        lit(null).cast(IntegerType).alias("payrank"),
        lit(null).cast(IntegerType).alias("distinct_pyrcnt"),
        $"temp.date_of_death",
        lit(null).cast(StringType).alias("contract_id"),
        lit(null).cast(StringType).alias("at_risk_status"),
        lit(null).cast(StringType).alias("cust_mem_attr1"),
        lit(null).cast(StringType).alias("cust_mem_attr2"),
        lit(null).cast(StringType).alias("cust_mem_attr3"),
        lit(null).cast(StringType).alias("cust_mem_attr4"),
        lit(null).cast(StringType).alias("cust_mem_attr5"),
        lit(null).cast(StringType).alias("cust_mem_attr6"),
        lit(null).cast(StringType).alias("subscriberid"),
        lit(null).cast(StringType).alias("subscriberflag"),
        lit(null).cast(StringType).alias("coverage_status"),
        lit(null).cast(StringType).alias("emp_acct_id"),
        lit(null).cast(StringType).alias("contracttype"),
        lit(null).cast(StringType).alias("benefitplan"),
        lit(null).cast(StringType).alias("coverageclasscode"),
        lit(null).cast(StringType).alias("dental_benefit"),
        lit(null).cast(IntegerType).alias("medical_benefit_ind"),
        lit(null).cast(IntegerType).alias("mh_benefit_ind"),
        lit(null).cast(StringType).alias("employee_type"),
        lit(null).cast(IntegerType).alias("hra_ind"),
        lit(null).cast(IntegerType).alias("hsa_ind"),
        lit(null).cast(StringType).alias("product_dtl_code"),
        lit(null).cast(StringType).alias("pcp_affil"),
        lit(null).cast(StringType).alias("risk_type"),
        lit(null).cast(StringType).alias("mem_userdef_1"),
        lit(null).cast(StringType).alias("mem_userdef_2"),
        lit(null).cast(StringType).alias("mem_userdef_3"),
        lit(null).cast(StringType).alias("mem_userdef_4"),
        lit(null).cast(StringType).alias("cust_mem_attr7"),
        lit(null).cast(StringType).alias("cust_mem_attr8"),
        lit(null).cast(StringType).alias("cust_mem_attr9"),
        lit(null).cast(StringType).alias("cust_mem_attr10"),
        lit(null).cast(StringType).alias("cust_mem_attr11"),
        lit(null).cast(StringType).alias("cust_mem_attr12"),
        lit(null).cast(StringType).alias("cust_mem_attr13"),
        lit(null).cast(StringType).alias("cust_mem_attr14"),
        lit(null).cast(StringType).alias("cust_mem_attr15"),
        lit(null).cast(DoubleType).alias("cust_mem_attr16"),
        lit(null).cast(DoubleType).alias("cust_mem_attr17"),
        lit(null).cast(DoubleType).alias("cust_mem_attr18"),
        lit(null).cast(DoubleType).alias("cust_mem_attr19"),
        lit(null).cast(DoubleType).alias("cust_mem_attr20"),
        lit(null).cast(StringType).alias("sec_member_id_1"),
        lit(null).cast(StringType).alias("sec_member_id_2")
      )

    allJoin.unionByName(result)

  }
}