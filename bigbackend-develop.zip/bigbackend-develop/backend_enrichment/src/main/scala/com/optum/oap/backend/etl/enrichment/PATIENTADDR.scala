package com.optum.oap.backend.etl.enrichment

import com.optum.oap.backend.etl.common.MapMasterIds
import com.optum.oap.cdr.models.{patient_mpi, patientaddr}
import com.optum.oap.sparkdataloader.{RuntimeVariables, TableInfo, UserDefinedFunctionForDataLoader}
import org.apache.spark.sql.{DataFrame, SparkSession}
import org.slf4j.LoggerFactory

object PATIENTADDR extends TableInfo[patientaddr] {

  val log = LoggerFactory.getLogger(this.getClass)

  override def dependsOn = Set("CDR_FE_PATIENTADDR", "ICPM_PATIENTADDR", "PATIENT_MPI")

  override def name = "PATIENTADDR"

  override def saveDataFrameToParquet: Boolean = true

  override def partitions: Int = 32

  override def skipTable: Boolean = false

  override def ignoreExtraColumnsInDataFrame: Boolean = true

  override def createDataFrame(sparkSession: SparkSession,
                               loadedDependencies: Map[String, DataFrame],
                               udfMap: Map[String, UserDefinedFunctionForDataLoader],
                               runtimeVariables: RuntimeVariables): DataFrame = {
    import sparkSession.implicits._

    val patientaddrIn = loadedDependencies("CDR_FE_PATIENTADDR")
                    .drop("ROW_SOURCE","MODIFIED_DATE").as[patientaddr]

    //Load df from ICPM Patient Address
    val icpmPatientaddr = loadedDependencies("ICPM_PATIENTADDR").as[patientaddr]

    //Union Patientaddress data coming from FE & ICPM Patient address
    val unionPatientaddr = patientaddrIn.unionByName(icpmPatientaddr)

    val patXref = loadedDependencies("PATIENT_MPI").as[patient_mpi]

    MapMasterIds.mapPatientIds(unionPatientaddr.toDF, patXref.toDF, false)
  }


}
