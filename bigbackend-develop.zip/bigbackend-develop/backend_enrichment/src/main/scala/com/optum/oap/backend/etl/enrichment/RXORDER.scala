package com.optum.oap.backend.etl.enrichment

import com.optum.oap.backend.etl.common.{MapMasterIds, MapMedication}
import com.optum.oap.backend.loader.EnrichmentRunTimeVariables
import com.optum.oap.cdr.models._
import com.optum.oap.sparkdataloader.{RuntimeVariables, TableInfo, UserDefinedFunctionForDataLoader}
import org.apache.spark.sql.functions._
import org.apache.spark.sql.{DataFrame, SparkSession}
import org.slf4j.LoggerFactory

object RXORDER extends TableInfo[rxorder] {

  val log = LoggerFactory.getLogger(this.getClass)

  override def dependsOn = Set("PATIENT_MPI", "ICPM_RXORDER", "ZH_PROVIDER_MASTER_XREF", "CDR_FE_RXORDER", "ZH_MED_MAP_DCC", "REF_HTS_NDC_CURRENT", "MAP_MED_ORDER_STATUS")

  override def name = "RXORDER"

  override def saveDataFrameToParquet: Boolean = true

  override def partitions: Int = 128

  override def skipTable: Boolean = false

  override def ignoreExtraColumnsInDataFrame: Boolean = true

  override def createDataFrame(sparkSession: SparkSession,
                               loadedDependencies: Map[String, DataFrame],
                               udfMap: Map[String, UserDefinedFunctionForDataLoader],
                               runtimeVariables: RuntimeVariables): DataFrame = {
    import sparkSession.implicits._

    val partitionMultiplier = EnrichmentRunTimeVariables(runtimeVariables).partitionMultiplier
    val rxorder = loadedDependencies("CDR_FE_RXORDER").drop(
      "row_source", "modified_date").as[rxorder]
    val icpmRxOrder = loadedDependencies("ICPM_RXORDER").as[rxorder]
    val rxOrderUnion = rxorder.unionByName(icpmRxOrder)
    val rxorderIn = rxOrderUnion.select(rxOrderUnion.columns.map {
      colName => {
        colName.toLowerCase match {
          case "localform" | "localroute" | "localstrengthunit"  => trim(rxOrderUnion.col(colName)).as(colName)
          case _ => rxOrderUnion.col(colName)
        }
      }
    }:_*)

    val provXref = broadcast(loadedDependencies("ZH_PROVIDER_MASTER_XREF")).as[zh_provider_master_xref]
    val patXref = loadedDependencies("PATIENT_MPI").as[patient_mpi]
    val mapDccDf = broadcast(loadedDependencies("ZH_MED_MAP_DCC")).as[zh_med_map_dcc]
    val refHtsNdcCurrent = broadcast(loadedDependencies("REF_HTS_NDC_CURRENT")
      .as[ref_hts_ndc_current]
      .select($"dcc", $"hts_generic", $"hts_generic_ext", $"hum_gen_med_key", $"hum_med_key", $"ndc")
      .as[mapped_ref_hts_ndc_current])
    val medOrderStatus = broadcast(loadedDependencies("MAP_MED_ORDER_STATUS")).as[map_med_order_status]

    val mappedRxIdDf = MapMasterIds.mapProviderIds(MapMasterIds.mapPatientIds(rxorderIn.toDF, patXref.toDF, filterIds = false), provXref.toDF(), "localproviderid", "mstrprovid")
    val repNum = Math.ceil(partitions * partitionMultiplier).toInt
    val repartitionedRxOrder = mappedRxIdDf.repartition(repNum, $"groupid", $"datasrc", $"client_ds_id", $"localmedcode")
    val joinedRxMedDf = MapMedication.applyMedMap(repartitionedRxOrder, true, mapDccDf.toDF(), refHtsNdcCurrent.toDF(), "localmedcode", dccFlag = true)
    val cols = getSelectList(joinedRxMedDf.columns.toSet)

    val resultDF = joinedRxMedDf.as("medrx")
      .join(medOrderStatus.as("m"),
        joinedRxMedDf("groupid") === medOrderStatus("groupid") and
          joinedRxMedDf("orderstatus") === medOrderStatus("localcode"), "left_outer"
      )
      .withColumn(
        "active_med_flag",
        when(joinedRxMedDf("ordervsprescription") === lit("P") and joinedRxMedDf("discontinuedate").isNotNull and joinedRxMedDf("discontinuedate").between(joinedRxMedDf("issuedate"), current_date()), lit("N"))
          .when(joinedRxMedDf("ordervsprescription") === lit("P") and joinedRxMedDf("discontinuereason").isNotNull, lit("N"))
          .when(joinedRxMedDf("ordervsprescription") === lit("P") and joinedRxMedDf("expiredate").between(joinedRxMedDf("issuedate"), current_date()), lit("N"))
          .when(joinedRxMedDf("ordervsprescription") === lit("P") and medOrderStatus("cui").isin(lit("CH001593"), lit("CH001594"), lit("CH001595"), lit("CH001596")), lit("N"))
          .otherwise(lit("Y"))
      ).select(cols.head, cols.tail: _*)

    resultDF.repartition(Math.ceil(partitions * partitionMultiplier).toInt)

  }

  def getSelectList(sourceCols: Set[String]): Array[String] = {
    sourceCols.map(s => if (s.equalsIgnoreCase("active_med_flag")) s else  "medrx." + s).toArray
  }
}

case class mapped_ref_hts_ndc_current(dcc: String = null,
                                      hts_generic: String = null,
                                      hts_generic_ext: String = null,
                                      hum_gen_med_key: String = null,
                                      hum_med_key: String = null,
                                      ndc: String = null)
