package com.optum.oap.backend.etl.cdrfe.config

trait CDRFEGithubConfigReader extends CDRFEConfigReader {

  override def getCDRFEConfg: Seq[cdrfe_data_source] = {
    import enrichmentRunTimeVariables._
    val configUrl = s"https://github.optum.com/raw/DataFactoryEnablement/cdrfe-config/develop/CDRFE/$environment/config/$release/${clientId}_config.csv"
    val source = scala.io.Source.fromURL(configUrl)
    source
      .getLines()
      .toSeq
      .tail
      .filter(line => line.nonEmpty)
      .map(line => {
        val items = line.split(",")
        val isActive = true // isActive flag has been removed from the cdrfe-config
        val cdsId = items(0).toInt
        val cdsName = items(1)
        val framework = items(2)
        cdrfe_data_source(isActive, cdsId, cdsName, framework)
      }).filter(_.active)
  }
}
