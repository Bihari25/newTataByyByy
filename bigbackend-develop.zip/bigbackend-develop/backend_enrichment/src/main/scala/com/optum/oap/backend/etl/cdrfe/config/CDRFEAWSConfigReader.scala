package com.optum.oap.backend.etl.cdrfe.config

import com.amazonaws.services.s3.model.GetObjectRequest
import com.optum.oap.awsutils.AWSClientConfig
import com.optum.oap.backend.etl.common.CDRConstants

trait CDRFEAWSConfigReader extends CDRFEConfigReader {

  override def getCDRFEConfg: Seq[cdrfe_data_source] = {
    import enrichmentRunTimeVariables._
    val awsS3Client = AWSClientConfig.default.createS3Client()
    val obj = awsS3Client.getObject(new GetObjectRequest(CDRConstants.OAPCONFIG_BUCKET_NAME, s"CDRFE/$environment/config/$release/${clientId}_config.csv"))
    val s3BufferedSource = scala.io.Source.fromInputStream(obj.getObjectContent)
    s3BufferedSource
      .getLines()
      .toSeq
      .tail
      .filter(line => line.nonEmpty)
      .map(line => {
        val items = line.split(",")
        val isActive = true // isActive flag has been removed from the cdrfe-config
        val cdsId = items(0).toInt
        val cdsName = items(1)
        val framework = items(2)
        cdrfe_data_source(isActive, cdsId, cdsName, framework)
      }).filter(_.active)
  }
}
