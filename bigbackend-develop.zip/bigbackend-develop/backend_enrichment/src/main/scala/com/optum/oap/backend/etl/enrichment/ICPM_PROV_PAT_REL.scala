package com.optum.oap.backend.etl.enrichment

import com.optum.oap.cdr.models.{int_claim_member, prov_pat_rel}
import com.optum.oap.sparkdataloader.{RuntimeVariables, TableInfo, UserDefinedFunctionForDataLoader}
import org.apache.spark.sql.functions._
import com.optum.oap.backend.etl.common.SafeToDate.safeToDate
import org.apache.spark.sql.expressions.Window
import org.apache.spark.sql.types.{DataTypes, LongType}
import org.apache.spark.sql.{DataFrame, SparkSession}
import org.slf4j.LoggerFactory

object ICPM_PROV_PAT_REL extends TableInfo[prov_pat_rel] {

  private val log = LoggerFactory.getLogger(this.getClass)

  override def dependsOn = Set("INT_CLAIM_MEMBER")

  override def name = "ICPM_PROV_PAT_REL"

  override def createDataFrame(sparkSession: SparkSession,
                               loadedDependencies: Map[String, DataFrame],
                               udfMap: Map[String, UserDefinedFunctionForDataLoader],
                               runtimeVariables: RuntimeVariables): DataFrame = {

    import sparkSession.implicits._

    val cdrFeIntClaimMember = loadedDependencies("INT_CLAIM_MEMBER").as[int_claim_member]

    val contractMemberPcpStartdatePartition = Window.partitionBy("client_ds_id",
      "contract_id", "patientid", "providerid", "startdate")
      .orderBy(desc_nulls_first("enddate"))


    cdrFeIntClaimMember.select(
      col("groupid")
      , lit("int_claim").as("datasrc")
      , col("client_ds_id")
      , lit("PCP").as("localrelshipcode")
      , col("member_id").as("patientid")
      , coalesce(col("pcp_start_date"), col("member_eff_date")
        , safeToDate(col("eligibile_member_month"), lit("yyyyMM"))).as("startdate")
      , col("pcp_id").as("providerid")
      , col("contract_id")
      , col("pcp_prov_affil_id").as("prov_affil_id")
      , when(datediff(current_timestamp(),
        coalesce(col("Pcp_end_Date"), col("Member_end_Date")
        ))
        <= lit(90), null)
        .otherwise(coalesce(col("Pcp_end_Date"),
          col("Member_end_Date")))
        .as("enddate"),
      lit(null).cast(DataTypes.StringType).as("mstrprovid"),
      lit(null).cast(DataTypes.StringType).as("grp_mpi"),
      lit(null).cast(DataTypes.LongType).as("hgpid"),
      lit(null).cast(DataTypes.StringType).as("plan_level_cd")
    ).filter(col("patientid").isNotNull
      && col("providerid").isNotNull
      && col("startdate").isNotNull
    ).withColumn("rank_startdate",
      row_number().over(contractMemberPcpStartdatePartition))
      .filter(col("rank_startdate") === 1)
      .drop("rank_startdate")

  }

}
