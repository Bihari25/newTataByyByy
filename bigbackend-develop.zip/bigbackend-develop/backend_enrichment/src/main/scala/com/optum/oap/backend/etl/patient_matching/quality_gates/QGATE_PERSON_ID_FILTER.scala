package com.optum.oap.backend.etl.patient_matching.quality_gates

import com.optum.oap.backend.cdrTempModel.qgate_person_id_status
import com.optum.oap.backend.etl.common.CDRConstants
import com.optum.oap.cdr.models.{qgate_new_evidence_person_id, qgate_person_id_filter, qgate_person_id_suspects}
import com.optum.oap.sparkdataloader.{RuntimeVariables, TableInfo, UserDefinedFunctionForDataLoader}
import org.apache.spark.sql.functions.lit
import org.apache.spark.sql.{DataFrame, SparkSession}

object QGATE_PERSON_ID_FILTER extends TableInfo[qgate_person_id_filter]{

  override def dependsOn: Set[String] = Set("QGATE_PERSON_ID_SUSPECTS", "QGATE_NEW_EVIDENCE_PERSON_ID", "QGATE_PERSON_ID_STATUS")
  override def name = "QGATE_PERSON_ID_FILTER"

  override def createDataFrame(sparkSession: SparkSession,
                               loadedDependencies: Map[String, DataFrame],
                               udfMap: Map[String, UserDefinedFunctionForDataLoader],
                               runtimeVariables: RuntimeVariables): DataFrame = {

    import sparkSession.implicits._

    val personSuspects = loadedDependencies("QGATE_PERSON_ID_SUSPECTS").drop("row_source","modified_date").as[qgate_person_id_suspects]
    val evidence = loadedDependencies("QGATE_NEW_EVIDENCE_PERSON_ID").drop("row_source","modified_date").as[qgate_new_evidence_person_id]
    val personStatus = loadedDependencies("QGATE_PERSON_ID_STATUS").drop("row_source","modified_date").as[qgate_person_id_status]

    val result1 = personStatus
      .where($"status_cd".isInCollection(CDRConstants.CLEARED_AND_REFFERED_2_CLIENT_STATUS_IDS))
      .select($"groupid", $"personid", $"status_cd")


    val clause = personStatus.where($"status_cd" === lit("C")).select($"groupid", $"personid").except(evidence.select($"groupid", $"personid"))

    val result2 = personSuspects.select($"groupid", $"personid").except(clause).as("v")
      .join(result1.as("f"), $"f.groupid" === $"v.groupid" && $"f.personid" === $"v.personid", "left_outer")
      .where($"f.groupid".isNull)
      .select(
        $"v.groupid",
        $"v.personid",
        lit("S").as("status_cd")
      )

    result1.union(result2)

  }

}
