package com.optum.oap.backend.etl.encgrps

import com.optum.oap.backend.cdrTempModel.temp_eg_ins_null
import com.optum.oap.cdr.models.{insurance, map_financial_class}
import com.optum.oap.sparkdataloader.{QueryAndMetadata, RuntimeVariables, TableInfo, UserDefinedFunctionForDataLoader}
import org.apache.spark.sql.{DataFrame, SparkSession}

object TEMP_EG_INS_NULL extends TableInfo[temp_eg_ins_null] {

  override def name: String = "TEMP_EG_INS_NULL"

  override def dependsOn: Set[String] = Set("INSURANCE","MAP_FINANCIAL_CLASS")

  override protected def createDataFrame(sparkSession: SparkSession,
                                         loadedDependencies: Map[String, DataFrame],
                                         udfMap: Map[String, UserDefinedFunctionForDataLoader],
                                         runtimeVariables: RuntimeVariables): DataFrame = {

    import sparkSession.implicits._
    import org.apache.spark.sql.functions._
    import com.optum.oap.backend.etl.common.TimestampTruncate

    val insurance = loadedDependencies("INSURANCE").as[insurance]
    val mapFinancialClass = loadedDependencies("MAP_FINANCIAL_CLASS").as[map_financial_class]

    val result = insurance.as("px")
      .join(broadcast(mapFinancialClass).as("mfc"), $"px.groupid" === $"mfc.groupid" && $"px.plantype" === $"mfc.mnemonic", "leftouter")
      .where($"px.encounterid".isNull && coalesce($"mfc.cui", $"px.mappedplanfincode").isNotNull)
      .select(
        $"px.groupid",
        $"px.datasrc",
        $"px.encounterid",
        $"px.patientid",
        $"px.sourceid",
        TimestampTruncate.truncate(lit("DAY"), $"px.ins_timestamp").as("ins_timestamp"),
        $"px.insuranceorder",
        $"px.payorcode",
        $"px.payorname",
        $"px.plantype",
        $"px.plancode",
        $"px.planname",
        $"px.groupnbr",
        $"px.policynumber",
        TimestampTruncate.truncate(lit("DAY"), $"px.enrollstartdt").as("enrollstartdt"),
        TimestampTruncate.truncate(lit("DAY"), $"px.enrollenddt").as("enrollenddt"),
        $"px.mappedpayorcode",
        $"px.client_ds_id",
        $"px.hgpid",
        $"px.grp_mpi",
        $"px.mappedplanfincode",
        $"px.pharmacy_benefit_flag",
        $"px.product_code",
        $"px.product_name",
        coalesce($"mfc.cui", $"px.mappedplanfincode").as("finclass"),
        $"mfc.cui".as("mfc_cui")
      )

    result
  }
}
