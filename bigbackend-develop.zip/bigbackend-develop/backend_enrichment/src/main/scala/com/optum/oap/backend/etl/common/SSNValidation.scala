package com.optum.oap.backend.etl.common

import com.optum.oap.sparkdataloader.UserDefinedFunctionForDataLoader
import org.apache.spark.sql.SparkSession
import org.apache.spark.sql.expressions.UserDefinedFunction
import org.apache.spark.sql.functions.udf

object SSNValidation extends UserDefinedFunctionForDataLoader {
  val INVALID_LEN: String = "LEN"
  val INVALID_NULL: String = "NULL"
  val INVALID_DIGT: String = "DIGT"
  val INVALID_SAME: String = "SAME"
  val INVALID_OUTCOMES: Seq[String] = Seq(INVALID_DIGT, INVALID_LEN, INVALID_NULL, INVALID_SAME)

  val cleanAndValidate: UserDefinedFunction = udf {
    (ssn: String) => {
      val parsedSsn = Option(ssn).getOrElse("").replaceAll("[^0-9]", "")
      parsedSsn match {
        case _ if Option(ssn).isEmpty => INVALID_NULL
        case _ if parsedSsn.length == 0 => INVALID_NULL
        case _ if parsedSsn.length != 9 => INVALID_LEN
        case _ if (parsedSsn.charAt(0).toString == "9") || (parsedSsn.substring(0, 3) == "000") || (parsedSsn.substring(0, 3) == "666") || (parsedSsn.substring(3,5) == "00") ||(parsedSsn.substring(5, 9) == "0000") => INVALID_DIGT
        case _ if parsedSsn.replaceAll(parsedSsn.charAt(0).toString, "").length == 0 => INVALID_SAME
        case _ => parsedSsn
      }
    }
  }

  def stringHasOneUniqiueChar(input: String): Boolean = {
    for (index <- 0 until input.length-1) {
      if (input.charAt(index) != input.charAt(index + 1)) return false
    }
    true
  }

  override def registerMe(sparkSession: SparkSession): Unit = {
    sparkSession.udf.register(name, cleanAndValidate)
  }

  override def name: String = "SSNValidation"
}