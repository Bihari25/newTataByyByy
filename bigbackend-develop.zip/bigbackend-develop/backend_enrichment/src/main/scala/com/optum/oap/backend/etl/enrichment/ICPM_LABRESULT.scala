package com.optum.oap.backend.etl.enrichment

import com.optum.oap.cdr.models.labresult
import com.optum.oap.sparkdataloader.{RuntimeVariables, TableInfo, UserDefinedFunctionForDataLoader}
import org.apache.spark.sql.functions.lit
import org.apache.spark.sql.types.DataTypes
import org.apache.spark.sql.{DataFrame, SparkSession}
import org.slf4j.LoggerFactory

object ICPM_LABRESULT extends TableInfo[labresult] {

  private val log = LoggerFactory.getLogger(this.getClass)

  override def dependsOn = Set("ICPM_LABRESULT_CACHE", "NON_NUMERIC_LABRESULT")

  override def name = "ICPM_LABRESULT"

  override def partitions: Int = 32

  override def createDataFrame(sparkSession: SparkSession,
                               loadedDependencies: Map[String, DataFrame],
                               udfMap: Map[String, UserDefinedFunctionForDataLoader],
                               runtimeVariables: RuntimeVariables): DataFrame = {

    import sparkSession.implicits._

    val icpmLabresultCache = loadedDependencies("ICPM_LABRESULT_CACHE").as[labresult]
    val nonNumericLabResult = loadedDependencies("NON_NUMERIC_LABRESULT").as[labresult].toDF()

    icpmLabresultCache.filter($"localresult_numeric".isNotNull)
      .select($"groupid"
        , $"datasrc"
        , $"labresultid"
        , $"patientid"
        , $"datecollected"
        , $"labordereddate"
        , $"dateavailable"
        , $"labresult_date"
        , $"localresult"
        , $"localresult_numeric"
        , $"localresult_numeric".as("localresult_inferred")
        , $"localcode"
        , $"localname"
        , $"normalrange"
        , $"localunits"
        , $"client_ds_id"
        , $"localspecimentype"
        , $"localtestname"
        , $"local_loinc_code"
        , $"encounterid"
        , $"resulttype"
        , lit(null).cast(DataTypes.StringType).as("facilityid")
        , lit(null).cast(DataTypes.StringType).as("grp_mpi")
        , lit(null).cast(DataTypes.LongType).as("hgpid")
        , lit(null).cast(DataTypes.StringType).as("laborderid")
        , lit(null).cast(DataTypes.StringType).as("locallisresource")
        , lit(null).cast(DataTypes.StringType).as("localunits_inferred")
        , lit(null).cast(DataTypes.StringType).as("mapped_qual_code")
        , lit(null).cast(DataTypes.StringType).as("mappedcode")
        , lit(null).cast(DataTypes.StringType).as("mappedloinc")
        , lit(null).cast(DataTypes.StringType).as("mappedname")
        , lit(null).cast(DataTypes.StringType).as("mappedunits")
        , lit(null).cast(DataTypes.DoubleType).as("normalizedvalue")
        , lit(null).cast(DataTypes.StringType).as("relativeindicator")
        , lit(null).cast(DataTypes.StringType).as("resultstatus")
        , lit(null).cast(DataTypes.StringType).as("statuscode")
      )
      .unionByName(nonNumericLabResult)

  }
}
