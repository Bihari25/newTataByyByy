package com.optum.oap.backend.etl.enrichment

import com.optum.oap.backend.loader.EnrichmentRunTimeVariables
import com.optum.oap.cdr.models.{int_claim_labresult, zh_lab_dict}
import com.optum.oap.backend.cdrTempModel.ref_term_dict_loinc_partial
import com.optum.oap.sparkdataloader.{RuntimeVariables, TableInfo, UserDefinedFunctionForDataLoader}
import org.apache.spark.sql.expressions.Window
import org.apache.spark.sql.functions._
import org.apache.spark.sql.types.DataTypes
import org.apache.spark.sql.{DataFrame, SparkSession}
import org.slf4j.LoggerFactory


object ICPM_ZH_LAB_DICT extends TableInfo[zh_lab_dict] {

  private val log = LoggerFactory.getLogger(this.getClass)

  override def dependsOn = Set("INT_CLAIM_LABRESULT", "REF_TERM_DICT_LOINC")

  override def name = "ICPM_ZH_LAB_DICT"

  override def createDataFrame(sparkSession: SparkSession,
                               loadedDependencies: Map[String, DataFrame],
                               udfMap: Map[String, UserDefinedFunctionForDataLoader],
                               runtimeVariables: RuntimeVariables): DataFrame = {

    import sparkSession.implicits._

    val intClaimLabResultDf = loadedDependencies("INT_CLAIM_LABRESULT").as[int_claim_labresult]
    val refTermDictLoincDf = broadcast(loadedDependencies("REF_TERM_DICT_LOINC").as[ref_term_dict_loinc_partial])

    val localName = coalesce($"tdl.Long_Common_Name", $"lab.Loinc_Name", $"lab.Result_Name", $"lab.test_order_name")


    intClaimLabResultDf.as("lab")
      .join(refTermDictLoincDf.as("tdl"), $"lab.loinc_code" === $"tdl.loinc_num" ,"left")
      .withColumn("rank_labdict"
        , row_number.over(Window.partitionBy($"lab.client_ds_id", $"lab.Result_Code")
          .orderBy(length(lower(coalesce(localName))).desc_nulls_last)))
      .where($"Result_Code".isNotNull && $"rank_labdict" === "1")
      .select($"lab.groupid".as("groupid")
        ,$"lab.client_ds_id"
        ,$"lab.Result_Code".as("localcode")
        ,$"lab.Loinc_Code".as("local_loinc_code")
        ,lower(localName).as("localdesc")
        ,lower(localName).as("localname")
        ,lit(null).cast(DataTypes.StringType).as("localunits")
        ,lit(null).cast(DataTypes.StringType).as("localbodysite")
        ,lit(null).cast(DataTypes.StringType).as("localdatatype")
        ,lit(null).cast(DataTypes.StringType).as("localrefrange")
        ,lit(null).cast(DataTypes.StringType).as("localspecimentype")
      )
  }
}