package com.optum.oap.backend.loader

import org.slf4j.LoggerFactory


abstract class BpoConfigReader() {
  private val logger = LoggerFactory.getLogger(this.getClass)

  def constructBpoComponents(clientId: String, release: String, cdrCycle: String): Set[String] = {

    val overwrittenConfigLines = constructLines(clientId, release, cdrCycle, isOverride = true)
    val components = if (overwrittenConfigLines.isEmpty) {
      logger.warn("using release config")
      val releaseSpecificConfigLines = constructLines(clientId, release, cdrCycle, isOverride = false)
      releaseSpecificConfigLines.map(item => item.split(",").last)
    } else {
      logger.warn("using override config")
      overwrittenConfigLines.map(item => item.split(",").dropRight(1).last)
    }
    logger.warn(s"[clientid=$clientId,release=$release,cdrCycle=$cdrCycle components=$components]")
    components
  }

  def constructLines(clientId: String, release: String, cdrCycle: String, isOverride: Boolean): Set[String]
}


