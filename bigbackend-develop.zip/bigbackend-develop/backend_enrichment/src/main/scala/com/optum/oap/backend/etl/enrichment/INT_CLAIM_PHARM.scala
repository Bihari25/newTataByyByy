package com.optum.oap.backend.etl.enrichment

import com.optum.oap.backend.etl.common.IsSafeToNumber
import com.optum.oap.backend.loader.EnrichmentRunTimeVariables
import com.optum.oap.cdr.models.{int_claim_pharm, map_predicate_values}
import com.optum.oap.sparkdataloader.{RuntimeVariables, TableInfo, UserDefinedFunctionForDataLoader}
import org.apache.spark.sql.expressions.Window
import org.apache.spark.sql.functions._
import org.apache.spark.sql.types.DataTypes
import org.apache.spark.sql.{DataFrame, SparkSession}
import org.slf4j.LoggerFactory

import scala.util.{Failure, Success, Try}


object INT_CLAIM_PHARM extends TableInfo[int_claim_pharm] with INT_CLAIM_CLEANUP {

  private val log = LoggerFactory.getLogger(this.getClass)

  override def dependsOn = Set("CDR_FE_INT_CLAIM_PHARM", "MAP_PREDICATE_VALUES")

  override def name = "INT_CLAIM_PHARM"

  override def ignoreExtraColumnsInDataFrame: Boolean = true

  override def regexReplaceColumns: Set[String] = Set("denied_flag", "network_paid_status", "spec_rx_ind")

  override def createDataFrame(sparkSession: SparkSession,
                               loadedDependencies: Map[String, DataFrame],
                               udfMap: Map[String, UserDefinedFunctionForDataLoader],
                               runtimeVariables: RuntimeVariables): DataFrame = {

    import sparkSession.implicits._

    val pharmIn = loadedDependencies("CDR_FE_INT_CLAIM_PHARM")
    val mapPredicateValues = broadcast(loadedDependencies("MAP_PREDICATE_VALUES")).as[map_predicate_values]
    val groupId = runtimeVariables.asInstanceOf[EnrichmentRunTimeVariables].clientId
    val intClaimPharmIn1 = cleanUp(groupId, mapPredicateValues.toDF(), pharmIn).drop("row_source", "modified_date")
      .select($"*"
        , monotonically_increasing_id().as("rowid")
      )
/*
    val intClaimPharmIn1 = rxDf.drop("row_source", "modified_date")
      .select($"*"
        , monotonically_increasing_id().as("rowid")
    ) */

    // Old Approach using round() and format_number()
    //    val intClaimPharmIn=intClaimPharmIn1.columns.filter(_.endsWith("_amount")).foldLeft(intClaimPharmIn1)
    //    { (acc,x) => acc.withColumn(x, regexp_replace(format_number(col(x), 2), ",", "")).withColumn(x, col(x).cast(DataTypes.DoubleType)) }

    def parseColumns(inputDf: DataFrame, modColumns: List[String]): DataFrame = {
      val pd = Try({
        val df = modColumns.foldLeft(inputDf) {
          (acc, x) =>
            acc.withColumn(x, regexp_extract(col(x)
              .cast(DataTypes.StringType), "^[-+]?\\d+.\\d{0,2}", 0))
              .withColumn(x, col(x).cast(DataTypes.DoubleType))
        }
        df
      })
      pd match {
        case Success(v) => v
        case Failure(problem) => inputDf
      }
    }

    val modColumns =  List("allowed_amount", "coinsurance_amount", "copay_amount",
      "deductible_amount", "patient_liability_amount", "payment_amount", "requested_amount", "quantity_per_fill")

    val intClaimPharmIn = parseColumns(intClaimPharmIn1, modColumns)

    //val mapPredicateVal = broadcast(loadedDependencies("MAP_PREDICATE_VALUES")).as[map_predicate_values]

    //val groupId = runtimeVariables.asInstanceOf[EnrichmentRunTimeVariables].clientId

    val mpvListValue = mapPredicateValues.filter(
      $"data_src" === "OADW"
        && $"entity" === "PPV2"
        && $"table_name" === "PPV2"
        && $"groupid" === lit(groupId)
        && $"column_value" === "1").select(
      $"client_ds_id").distinct.collect().map(_.getInt(0).toString)

    val pharmClaimAdj = intClaimPharmIn.alias("m")
      .filter($"m.client_ds_id".isin(mpvListValue: _*))
      .select($"m.*"
        , when(coalesce($"m.requested_amount", lit(0)).geq(0)
          && coalesce($"m.allowed_amount", lit(0)).geq(0)
          && coalesce($"m.payment_amount", lit(0)).geq(0)
          , lit("P"))
          .when($"m.requested_amount".lt(0)
            && $"m.allowed_amount".lt(0)
            && $"m.payment_amount".lt(0)
            , lit("N"))
          .otherwise(lit("M")).as("adj1")
        , abs(coalesce($"m.payment_amount", lit(0))).as("abs_payment_amount")
        , abs(coalesce($"m.allowed_amount", lit(0))).as("abs_allowed_amount")
        , abs(coalesce($"m.requested_amount", lit(0))).as("abs_requested_amount")
        , $"rowid".as("id_row")
        , row_number().over(Window.partitionBy($"client_ds_id").orderBy($"client_ds_id")).as("sourcecode")
        , when($"m.pseudo_flag" === "Y", lit("NO")).otherwise(lit("YES")).as("incl")
      )

    val commonPharmAdjRnPartition = Window
      .partitionBy($"client_ds_id", $"contract_id", $"member_id", $"service_date"
        , $"ndc", $"abs_payment_amount"
        , $"abs_allowed_amount", $"abs_requested_amount")
      .orderBy($"presc_prov_id".desc_nulls_last, $"pay_process_date".desc_nulls_last)

    val pharmAdjRn = pharmClaimAdj.alias("a1")
      .filter($"a1.adj1" === "P" && $"a1.incl" === "YES")
      .select($"a1.*"
        , row_number().over(commonPharmAdjRnPartition).as("rn")
      )
      .unionByName(pharmClaimAdj.alias("a2")
        .filter($"a2.adj1" === "N" && $"a2.incl" === "YES")
        .select($"a2.*"
          , row_number().over(commonPharmAdjRnPartition).as("rn")
        ))
      .unionByName(pharmClaimAdj.alias("a3")
        .filter($"a3.adj1" === "M" && $"a3.incl" === "YES")
        .select($"a3.*"
          , row_number().over(commonPharmAdjRnPartition).as("rn")
        ))

    val w = Window.partitionBy($"client_ds_id", $"contract_id", $"member_id", $"service_date", $"ndc").orderBy(
      $"abs_payment_amount".asc_nulls_last, $"abs_allowed_amount".asc_nulls_last
      , $"abs_requested_amount".asc_nulls_last, $"rn".asc_nulls_last, $"pay_process_date".asc_nulls_last)

    val pharmAdjRnWithPrevNext = pharmAdjRn.orderBy($"abs_payment_amount".asc_nulls_last, $"abs_allowed_amount".asc_nulls_last,
      $"abs_requested_amount".asc_nulls_last, $"rn".asc_nulls_last, $"pay_process_date".asc_nulls_last)
      .select($"*"
        , lag($"abs_requested_amount", 1).over(w).as("prev_abs_requested_amount")
        , lead($"abs_requested_amount", 1).over(w).as("next_abs_requested_amount")
        , lag($"abs_payment_amount", 1).over(w).as("prev_abs_payment_amount")
        , lead($"abs_payment_amount", 1).over(w).as("next_abs_payment_amount")
        , lag($"abs_allowed_amount", 1).over(w).as("prev_abs_allowed_amount")
        , lead($"abs_allowed_amount", 1).over(w).as("next_abs_allowed_amount")
        , lag($"adj1", 1).over(w).as("prev_adj1")
        , lead($"adj1", 1).over(w).as("next_adj1")
        , lag($"rn", 1).over(w).as("prev_rn")
        , lead($"rn", 1).over(w).as("next_rn")
      )

    val adjBackoutNomix = pharmAdjRnWithPrevNext.filter(
        (
          $"abs_requested_amount" === $"prev_abs_requested_amount"
            && $"abs_allowed_amount" === $"prev_abs_allowed_amount"
            && $"abs_payment_amount" === $"prev_abs_payment_amount"
            && $"adj1" === "N"
            && $"prev_adj1" === "P"
            && $"rn" === $"prev_rn"
          ) ||
          (
            $"abs_requested_amount" === $"prev_abs_requested_amount"
              && $"abs_allowed_amount" === $"prev_abs_allowed_amount"
              && $"abs_payment_amount" === $"prev_abs_payment_amount"
              && $"adj1" === "P"
              && $"prev_adj1" === "N"
              && $"rn" === $"prev_rn"
            ) ||
          (
            $"abs_requested_amount" === $"next_abs_requested_amount"
              && $"abs_allowed_amount" === $"next_abs_allowed_amount"
              && $"abs_payment_amount" === $"next_abs_payment_amount"
              && $"adj1" === "P"
              && $"next_adj1" === "N"
              && $"rn" === $"next_rn"
            ) ||
          (
            $"abs_requested_amount" === $"next_abs_requested_amount"
              && $"abs_allowed_amount" === $"next_abs_allowed_amount"
              && $"abs_payment_amount" === $"next_abs_payment_amount"
              && $"adj1" === "N"
              && $"next_adj1" === "P"
              && $"rn" === $"next_rn"
            )
    ).withColumn("revised_adj1",
      when($"adj1" === "P" && $"next_adj1" === "N" && $"rn" === $"next_rn", lit("B"))
        .when($"adj1" === "N" && $"prev_adj1" === "P" && $"rn" === $"prev_rn", lit("B"))
        .when($"adj1" === "P" && $"prev_adj1" === "N" && $"rn" === $"prev_rn", lit("B"))
        .when($"adj1" === "N" && $"next_adj1" === "P" && $"rn" === $"next_rn", lit("B"))
        .otherwise($"adj1")).select("client_ds_id", "id_row", "revised_adj1")

    val pharmAdjRnMerged = pharmAdjRn.as("med").join(
      adjBackoutNomix.as("adj"), $"med.id_row" === $"adj.id_row"
        && $"med.client_ds_id" === $"adj.client_ds_id"
      , "left_outer"
    ).select($"med.*"
      , when(
        $"adj.id_row".isNotNull
          && $"adj.client_ds_id".isNotNull, $"adj.revised_adj1"
      ).otherwise($"med.adj1").as("adj1_new")
    ).drop("adj1").withColumnRenamed("adj1_new", "adj1")

    val mpvList2 = mapPredicateValues.filter(
      $"data_src" === "OADW"
        && $"table_name" === "INT_CLAIM_PHARM"
        && $"groupid" === groupId
        && $"column_name" === "MIX_BK").select(
      $"client_ds_id"
    ).distinct.collect().map(_.getInt(0).toString)

    val mergedNoMixWithPrevNext = pharmAdjRnMerged.filter($"client_ds_id".isin(mpvList2: _*)).orderBy(
      $"abs_payment_amount".asc_nulls_last, $"abs_allowed_amount".asc_nulls_last,
      $"abs_requested_amount".asc_nulls_last, $"rn".asc_nulls_last, $"pay_process_date".asc_nulls_last)
      .select($"*"
        , lag($"abs_requested_amount", 1).over(w).as("prev_abs_requested_amount")
        , lead($"abs_requested_amount", 1).over(w).as("next_abs_requested_amount")
        , lag($"abs_payment_amount", 1).over(w).as("prev_abs_payment_amount")
        , lead($"abs_payment_amount", 1).over(w).as("next_abs_payment_amount")
        , lag($"abs_allowed_amount", 1).over(w).as("prev_abs_allowed_amount")
        , lead($"abs_allowed_amount", 1).over(w).as("next_abs_allowed_amount")
        , lag($"adj1", 1).over(w).as("prev_adj1")
        , lead($"adj1", 1).over(w).as("next_adj1")
        , lag($"rn", 1).over(w).as("prev_rn")
        , lead($"rn", 1).over(w).as("next_rn")
      )

    val adjBackoutMix = mergedNoMixWithPrevNext.filter(
      (
        $"abs_requested_amount" === $"prev_abs_requested_amount"
          && $"abs_allowed_amount" === $"prev_abs_allowed_amount"
          && $"abs_payment_amount" === $"prev_abs_payment_amount"
          && $"adj1" === "M"
          && $"prev_adj1" === "P"
          && $"rn" === $"prev_rn"
        ) ||
        (
          $"abs_requested_amount" === $"prev_abs_requested_amount"
            && $"abs_allowed_amount" === $"prev_abs_allowed_amount"
            && $"abs_payment_amount" === $"prev_abs_payment_amount"
            && $"adj1" === "P"
            && $"prev_adj1" === "M"
            && $"rn" === $"prev_rn"
          ) ||
        (
          $"abs_requested_amount" === $"next_abs_requested_amount"
            && $"abs_allowed_amount" === $"next_abs_allowed_amount"
            && $"abs_payment_amount" === $"next_abs_payment_amount"
            && $"adj1" === "P"
            && $"next_adj1" === "M"
            && $"rn" === $"next_rn"
          ) ||
        (
          $"abs_requested_amount" === $"next_abs_requested_amount"
            && $"abs_allowed_amount" === $"next_abs_allowed_amount"
            && $"abs_payment_amount" === $"next_abs_payment_amount"
            && $"adj1" === "M"
            && $"next_adj1" === "P"
            && $"rn" === $"next_rn"
          )
    ).withColumn("revised_adj1",
      when($"adj1" === "P" && $"next_adj1" === "M" && $"rn" === $"next_rn", lit("B"))
        .when($"adj1" === "M" && $"prev_adj1" === "P" && $"rn" === $"prev_rn", lit("B"))
        .when($"adj1" === "P" && $"prev_adj1" === "M" && $"rn" === $"prev_rn", lit("B"))
        .when($"adj1" === "M" && $"next_adj1" === "P" && $"rn" === $"next_rn", lit("B"))
        .otherwise($"adj1")).select("client_ds_id", "id_row", "revised_adj1")

    val pharmAdjRnMerged2 = pharmAdjRnMerged.as("med").join(
      adjBackoutMix.as("adj"), $"med.id_row" === $"adj.id_row"
        && $"med.client_ds_id" === $"adj.client_ds_id"
      , "left_outer"
    ).select($"med.*"
      , when(
        $"adj.id_row".isNotNull
          && $"adj.client_ds_id".isNotNull, $"adj.revised_adj1"
      ).otherwise($"med.adj1").as("adj1_new")
    ).drop("adj1").withColumnRenamed("adj1_new", "adj1")

    //Temp table to populate flag 2 and 2 based
    val mpv_adj2_list = mapPredicateValues.filter(
      $"data_src" === "OADW"
        && $"entity" === "PPV2"
        && $"table_name" === "INT_CLAIM_PHARM"
        && $"groupid" === groupId
        && $"column_name" === "ADJ2_FILTER").select(
      $"client_ds_id"
    ).distinct.collect().map(_.getInt(0).toString)

    val mpv_adj3_list = mapPredicateValues.filter(
      $"data_src" === "OADW"
        && $"entity" === "PPV2"
        && $"table_name" === "INT_CLAIM_PHARM"
        && $"groupid" === groupId
        && $"column_name" === "ADJ3_FILTER").select(
      $"client_ds_id"
    ).distinct.collect().map(_.getInt(0).toString)

    val commonWindow = Window.partitionBy($"client_ds_id", $"contract_id", $"member_id", $"service_date", $"ndc")

    val filterCountValues = pharmAdjRnMerged2.where($"incl" === "YES").select(
      $"adj1".as("adj_pre_flg1")
      , size(collect_set($"adj1").over(commonWindow)).as("distinct_adj1_cnt")
      , count("*").over(commonWindow).as("grp_cnt")
      , count(when($"adj1" === "B", $"adj1").otherwise(lit(null))).over(commonWindow).as("backout_cnt")
      , count(when($"adj1" === "P", $"adj1").otherwise(lit(null))).over(commonWindow).as("positive_cnt")
      , count(when($"adj1" === "N", $"adj1").otherwise(lit(null))).over(commonWindow).as("negative_cnt")
      , count(when($"adj1" === "P" && coalesce($"allowed_amount", lit(0)) === 0, lit(1))).over(commonWindow).as("cnt_allowed_0")
      , count(when($"adj1" === "P" && $"allowed_amount" > 0, lit(1))).over(commonWindow).as("cnt_allowed_postive")
      , when($"adj1" === "P"
        && coalesce($"allowed_amount", lit(0)) === 0
        , row_number().over(commonWindow.orderBy(
          when($"adj1" === "P", lit(1)).otherwise(lit(2))
          , when(coalesce($"allowed_amount", lit(0)) === 0, lit(1)).otherwise(lit(2))
          , $"pay_process_date".desc_nulls_last
          , coalesce($"requested_amount", lit(0)).desc_nulls_last
          , coalesce($"payment_amount", lit(0)).desc_nulls_last
          , when(IsSafeToNumber.isSafeToNumber($"quantity_per_fill"), $"quantity_per_fill").otherwise(null).desc_nulls_last
          , $"rn"))).otherwise(lit(null)).as("rnk_allowed_0")
      , $"*"
    )

    val filterFlag3And2 = filterCountValues.select(
      $"adj_pre_flg1".as("adj_pre_flg_1")
      , $"client_ds_id"
      , $"sourcecode"
      , $"id_row"
      , $"contract_id"
      , $"member_id"
      , $"service_date"
      , $"ndc"
      , $"presc_prov_id"
      , $"pay_process_date"
      , $"quantity_per_fill"
      , when($"grp_cnt" === 1 && $"adj1".isin("P", "M"), lit(null))
        .when($"distinct_adj1_cnt" === 1 && $"adj1" === "B", lit("B"))
        .when($"grp_cnt" - $"backout_cnt" === $"positive_cnt" && $"positive_cnt" === 1, lit("R"))
        .when($"grp_cnt" - $"backout_cnt" === $"negative_cnt", lit("O"))
        .when($"grp_cnt" - $"backout_cnt" === $"positive_cnt" && $"positive_cnt" > 1, lit("P"))
        .when($"grp_cnt" > "1" && $"positive_cnt" === $"negative_cnt" && $"positive_cnt" > "0" && $"negative_cnt" > 0, lit("X"))
        .otherwise("M").as("adj_pre_flg_3")
      , when($"adj_pre_flg1".isin("B", "N", "M"), lit("D"))
        .when($"adj_pre_flg1" === "P" && $"allowed_amount" > 0, lit("K"))
        .when($"cnt_allowed_0" > 0 && $"rnk_allowed_0" === 1 && $"cnt_allowed_postive" === 0, lit("Z"))
        .otherwise(lit("D")).as("adj_pre_flg_2")
    )

    val adjPreFlags = filterFlag3And2.select(
      $"client_ds_id"
      , $"adj_pre_flg_1"
      , $"adj_pre_flg_2"
      , $"adj_pre_flg_3"
      , $"sourcecode".cast(DataTypes.StringType)
      , $"id_row"
      , $"contract_id"
      , $"member_id"
      , $"service_date"
      , $"ndc"
      , $"presc_prov_id"
      , $"pay_process_date"
      , $"quantity_per_fill"
      , when($"adj_pre_flg_2".isin(mpv_adj2_list: _*) || $"adj_pre_flg_3".isin(mpv_adj3_list: _*), lit("D"))
        .when($"adj_pre_flg_2" === "D" || $"adj_pre_flg_3".isin("M", "X"), lit("D"))
        .otherwise("K").as("claim_adj_type")
    )

    val pharmClaimAdj1 = pharmClaimAdj.alias("mc").filter($"mc.incl" === "NO").select($"mc.client_ds_id"
      , lit("P").cast(DataTypes.StringType).as("adj_pre_flg_1")
      , when(coalesce($"mc.allowed_amount", lit(0)) === 0, lit("Z")).otherwise(lit("K")).as("adj_pre_flg_2")
      , lit(null).cast(DataTypes.StringType).as("adj_pre_flg_3")
      , $"mc.sourcecode".cast(DataTypes.StringType)
      , $"mc.id_row"
      , $"contract_id"
      , $"member_id"
      , $"service_date"
      , $"ndc"
      , $"presc_prov_id"
      , $"pay_process_date"
      , $"quantity_per_fill"
      , lit(null).cast(DataTypes.StringType).as("claim_adj_type")
    )

    val adjPreFlagsFinal = adjPreFlags.unionByName(pharmClaimAdj1)

    val mpvDedupeList = mapPredicateValues.filter(
      $"data_src" === "OADW"
        && $"entity" === "PPV2"
        && $"table_name" === "INT_CLAIM_PHARM"
        && $"groupid" === groupId
        && $"column_name" === "DEDUP_RX"
        && $"column_value" === 1).select(
      $"client_ds_id").distinct.collect().map(_.getInt(0).toString)

    val adjRxFilter1 = adjPreFlagsFinal.as("a").select(
      $"a.*"
      , when($"client_ds_id".isin(mpvDedupeList: _*)
        && $"adj_pre_flg_2" === "K"
        && $"adj_pre_flg_3" === "P"
        , lit("Y"))
        .otherwise(lit("N")).as("incl_row")
    )

    val adjRxFilter11 = List("quantity_per_fill").foldLeft(adjRxFilter1) {
      (acc, x) =>
        acc.withColumn(x, regexp_extract(col(x).
          cast(DataTypes.StringType), "^[-+]?\\d+.\\d{0,2}", 0))
          .withColumn(x, col(x).cast(DataTypes.DoubleType))
    }


    val adjRxFilter2 = adjRxFilter11.as("b").select(
      $"b.*"
      , when($"incl_row" === "Y",
        row_number().over(commonWindow.orderBy($"pay_process_date".desc_nulls_last,
          $"quantity_per_fill".desc_nulls_last, $"presc_prov_id".asc_nulls_last, $"id_row")))
        .otherwise(lit("0")).as("rn")
    )

    val rxAdjMpvDedupe = adjRxFilter2.as("x").filter($"client_ds_id".isin(mpvListValue: _*)).select(
      $"x.*"
      , when($"rn".isin("0", "1")
        , $"claim_adj_type")
        .otherwise(lit("D")).as("claim_adj_type_final")
    )

    intClaimPharmIn.alias("med")
      .withColumnRenamed("adj_pre_flg_1", "med_adj_pre_flg_1")
      .withColumnRenamed("adj_pre_flg_2", "med_adj_pre_flg_2")
      .withColumnRenamed("adj_pre_flg_3", "med_adj_pre_flg_3")
      .withColumnRenamed("source_code", "med_source_code")
      .withColumnRenamed("claim_adj_type", "med_claim_adj_type")
      .join(rxAdjMpvDedupe.alias("adj"),
        $"med.rowid" === $"adj.id_row" && $"med.client_ds_id" === $"adj.client_ds_id"
        , "left_outer").select(
      $"med.*"
      , coalesce($"adj.sourcecode", $"med_source_code").as("source_code")
      , $"adj.claim_adj_type_final".as("claim_adj_type")
      , $"adj.adj_pre_flg_1".as("adj_pre_flg_1")
      , $"adj.adj_pre_flg_2".as("adj_pre_flg_2")
      , $"adj.adj_pre_flg_3".as("adj_pre_flg_3")
    ).drop("med_adj_pre_flg_1", "med_adj_pre_flg_2", "med_adj_pre_flg_3", "med_claim_adj_type", "id_row", "sourcecode", "rowid")
      .as[int_claim_pharm].toDF()


  }
}