package com.optum.oap.backend.etl.enrichment

import com.optum.oap.backend.cdrTempModel.{facility_xref, validation}
import com.optum.oap.backend.etl.common.PartitionedDataOperations
import com.optum.oap.backend.loader.EnrichmentRunTimeVariables
import com.optum.oap.sparkdataloader.{RuntimeVariables, TableInfo, UserDefinedFunctionForDataLoader}
import org.apache.spark.sql.functions.lit
import org.apache.spark.sql.{DataFrame, SparkSession}
import org.slf4j.LoggerFactory

import java.text.SimpleDateFormat
import java.util.Date

object FACILITY_XREF_VALIDATION extends TableInfo[validation] with PartitionedDataOperations {

  val log = LoggerFactory.getLogger(this.getClass)

  override def dependsOn = Set("V_FACILITY_XREF")

  override def name = "FACILITY_XREF_VALIDATION"

  private val date = new SimpleDateFormat("yyyyMMdd").format(new Date()).toInt

  override def createDataFrame(sparkSession: SparkSession,
                               loadedDependencies: Map[String, DataFrame],
                               udfMap: Map[String, UserDefinedFunctionForDataLoader],
                               runtimeVariables: RuntimeVariables): DataFrame = {
    import sparkSession.implicits._

    implicit val session = sparkSession
    val schema = EnrichmentRunTimeVariables(runtimeVariables).cdrSchema

    val facXref = loadedDependencies("V_FACILITY_XREF").as[facility_xref]
    val facilityXref = if(facXref.isEmpty) loadData(schema, "V_FACILITY_XREF").as[facility_xref] else facXref

    val currentFacilityXref = facilityXref.where($"partition_date" === lit(date))
    val distHgfacids = currentFacilityXref.select($"hgfacid").distinct()

    if(distHgfacids.count() != currentFacilityXref.count()) {
      throw FacilityXrefMismatchException("Validation Failure: The count of facility_xref not matched with distinct count of hgfacids" )
    }
    Seq.empty[validation].toDF()
  }

  final case class FacilityXrefMismatchException(message: String = "", exception: Throwable = null) extends Exception(message)
}