
package com.optum.oap.backend.etl.summary

import com.optum.oap.backend.etl.common.{CDRConstants, EnrichmentUtils, IsSafeToNumber}
import com.optum.oap.backend.loader.EnrichmentRunTimeVariables
import com.optum.oap.cdr.models.{patient_grp_mpi_diff, patient_summary}
import com.optum.oap.sparkdataloader.{RuntimeVariables, TableInfo, UserDefinedFunctionForDataLoader}
import org.apache.spark.sql.functions.{broadcast, coalesce, lit, when}
import org.apache.spark.sql.types.{LongType, StringType}
import org.apache.spark.sql.{DataFrame, SparkSession}
import org.slf4j.LoggerFactory

import scala.util.{Failure, Success, Try}

object PATIENT_GRP_MPI_DIFF extends TableInfo[patient_grp_mpi_diff] {
  val log = LoggerFactory.getLogger(this.getClass)

  override def dependsOn = Set("PATIENT_SUMMARY", "CLIENT_ATTRIBUTE")

  override def createDataFrame(sparkSession: SparkSession,
                               loadedDependencies: Map[String, DataFrame],
                               udfMap: Map[String, UserDefinedFunctionForDataLoader],
                               runtimeVariables: RuntimeVariables): DataFrame = {
    import sparkSession.implicits._

    val patSumDf_org = loadedDependencies("PATIENT_SUMMARY")
    val client_attribute_Df = broadcast(loadedDependencies("CLIENT_ATTRIBUTE"))

    val releaseCycle = EnrichmentRunTimeVariables(runtimeVariables).release
    val grpid = EnrichmentRunTimeVariables(runtimeVariables).clientId
    val env = EnrichmentRunTimeVariables(runtimeVariables).environment

    if (!releaseCycle.matches("\\d{6}")) {
      if (env.equals("prd"))
        throw new Exception(s"release cycle supplied $releaseCycle is not in YYYYMM format for production run")
    }

    val dailyBuild = if (runtimeVariables.asInstanceOf[EnrichmentRunTimeVariables].buildType == CDRConstants.DELTA_BUILD_TYPE) true else false

    if (dailyBuild) {
      sparkSession.emptyDataset[patient_grp_mpi_diff].toDF()
    } else {

      val prevmonth_monthlydb: Option[String] = Try(getMostRecentExistingReleaseIfAny(sparkSession, releaseCycle,grpid, env, -1)
        .orElse(getMostRecentExistingReleaseIfAny(sparkSession, releaseCycle,grpid, env, -2))
        .orElse(getMostRecentExistingReleaseIfAny(sparkSession, releaseCycle,grpid, env, -3)))
        .getOrElse(None)

      if (prevmonth_monthlydb.isDefined) {
        log.warn(s"using $prevmonth_monthlydb monthly db for comparision")
        val prev_patSumDf_org_option = constructPreviousMonthPatientSummary(sparkSession, prevmonth_monthlydb.get)
        val result = {
          if (env.equals("prd")) {
            val prev_patSumDf = prev_patSumDf_org_option.getOrElse(throw new Exception(s"looks like schema exists but path is missing for PATIENT_SUMMARY table in  $prevmonth_monthlydb prod schema.HOW DID THIS HAPPEN ?"))
            processDiff(sparkSession, patSumDf_org.toDF(), prev_patSumDf, client_attribute_Df.toDF())
          } else {
            if (prev_patSumDf_org_option.isSuccess) {
              log.warn(s"comparing previous month release using database $prevmonth_monthlydb for non-prod build")
              processDiff(sparkSession, patSumDf_org.toDF(), prev_patSumDf_org_option.get, client_attribute_Df.toDF())
            } else {
              log.warn(s"error executing query.most probably schema exists but external path is deleted for PATIENT_SUMMARY in schema $prevmonth_monthlydb. continuing since this is non-prod build")
              constructWithOnlyCurrentMonth(sparkSession, patSumDf_org)
            }
          }
        }
        result
      } else {
        log.warn(s"previous three month db doesn't exist.")
        constructWithOnlyCurrentMonth(sparkSession, patSumDf_org)
      }
    }
  }

  def getMostRecentExistingReleaseIfAny(sparkSession: SparkSession, releaseCycle : String, grpid: String, env: String, numberOfLookBack: Int): Option[String] = {
    val previousReleaseCycle = EnrichmentUtils.getPreviousRelease(releaseCycle, numberOfLookBack)
    val previousReleaseCycleValue = previousReleaseCycle.getOrElse("")
    val prevmonth_monthlydb = s"${grpid}_${env}_cdr_be_cdr_$previousReleaseCycleValue"
    val prevmonth_monthlydb_exists = {
      if (previousReleaseCycle.isEmpty) false
      else sparkSession.catalog.databaseExists(prevmonth_monthlydb)
    }
    if (prevmonth_monthlydb_exists) {
      Option(prevmonth_monthlydb)
    } else {
      None
    }
  }

  def constructPreviousMonthPatientSummary(sparkSession: SparkSession, prevmonth_monthlydb: String): Try[DataFrame] = {
    import sparkSession.implicits._
    try {
      val prev_patSumDf_org = sparkSession.sql(s"select * from $prevmonth_monthlydb.PATIENT_SUMMARY")
      Success(prev_patSumDf_org.toDF())
    } catch {
      case ex: Throwable =>
        log.warn(s"error message : ${ex.getMessage}")
        ex.printStackTrace()
        Failure(ex)
    }
  }

  def constructWithOnlyCurrentMonth(sparkSession: SparkSession, currentSummaryOrig: DataFrame): DataFrame = {
    import sparkSession.implicits._
    currentSummaryOrig.select(
      $"groupid",
      $"client_ds_id",
      lit("NA").as("datasrc"),
      $"patientid",
      $"hgpid",
      $"grp_mpi".as("new_grp_mpi"),
      lit(null).cast(StringType).as("old_grp_mpi"),
      lit("NEW_PATIENT").as("MPI_STATUS")
    )
  }

  // keeping in a separate method to make this functionality testable
  def processDiff(sparkSession: SparkSession, currentSummaryOrig: DataFrame, previousSummaryOrig: DataFrame, client_attribute_Df: DataFrame): DataFrame = {
    import sparkSession.implicits._

    val currentSummary = currentSummaryOrig.select(
      $"groupid",
      $"client_ds_id",
      lit("NA").as("datasrc"),
      $"patientid",
      $"hgpid",
      $"grp_mpi",
      when(IsSafeToNumber.isSafeToNumber($"grp_mpi"), $"grp_mpi".cast(LongType))
        .otherwise(lit(null)).cast(LongType).as("grp_mpi_num")
    )

    val previousSummary = previousSummaryOrig.select(
      $"groupid",
      $"client_ds_id",
      lit("NA").as("datasrc"),
      $"patientid",
      $"hgpid",
      $"grp_mpi",
      when(IsSafeToNumber.isSafeToNumber($"grp_mpi"), $"grp_mpi".cast(LongType))
        .otherwise(lit(null)).cast(LongType).as("grp_mpi_num")
    )

    val diff = currentSummary.as("nt")
      .join(previousSummary.as("ot"),
        $"nt.groupid" === $"ot.groupid" &&
          $"nt.client_ds_id" === $"ot.client_ds_id" &&
          $"nt.patientid" === $"ot.patientid",
        "full_outer")
      .join(client_attribute_Df.as("ca"), coalesce($"nt.groupid", $"ot.groupid") === $"ca.client_id")
      .select(
        coalesce($"nt.groupid", $"ot.groupid").as("groupid"),
        coalesce($"nt.client_ds_id", $"ot.client_ds_id").as("client_ds_id"),
        coalesce($"nt.datasrc", $"ot.datasrc").as("datasrc"),
        coalesce($"nt.patientid", $"ot.patientid").as("patientid"),
        $"nt.hgpid".as("hgpid"),
        $"nt.grp_mpi".as("new_grp_mpi"),
        $"ot.grp_mpi".as("old_grp_mpi"),
        when($"nt.grp_mpi_num".isNotNull && $"ot.grp_mpi_num".isNotNull && $"ot.grp_mpi_num" === $"nt.grp_mpi_num", lit("NO_CHANGE"))
          .when($"nt.grp_mpi_num".isNotNull && $"ot.grp_mpi_num".isNotNull && $"ot.grp_mpi_num".lt($"nt.grp_mpi_num"), lit("SPLIT"))
          .when($"nt.grp_mpi_num".isNotNull && $"ot.grp_mpi_num".isNotNull && $"ot.grp_mpi_num".gt($"nt.grp_mpi_num"), lit("MERGED"))
          .when($"ot.patientid".isNull && $"nt.grp_mpi_num".isNotNull, lit("NEW_PATIENT"))
          .when($"ot.patientid".isNotNull && $"nt.patientid".isNull, lit("REMOVED"))
          .when($"nt.hgpid".isNull && $"nt.patientid".isNotNull, lit("RESTRICTED"))
          .when($"ot.hgpid".isNull && $"ot.patientid".isNotNull && $"nt.grp_mpi".isNotNull, lit("CLEARED")).as("mpi_status")
      )

    val result = diff.select(
      $"groupid",
      $"client_ds_id",
      $"datasrc",
      $"patientid",
      $"hgpid",
      $"new_grp_mpi",
      $"old_grp_mpi",
      $"mpi_status"
    )
    result
  }

}
