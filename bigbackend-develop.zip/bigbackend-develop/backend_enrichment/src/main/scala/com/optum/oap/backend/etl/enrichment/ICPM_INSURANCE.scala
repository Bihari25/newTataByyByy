package com.optum.oap.backend.etl.enrichment

import com.optum.oap.backend.etl.common.IsSafeToNumber
import com.optum.oap.backend.etl.common.SafeToDate.safeToDate
import com.optum.oap.cdr.models.{insurance, int_claim_member}
import com.optum.oap.sparkdataloader.{RuntimeVariables, TableInfo, UserDefinedFunctionForDataLoader}
import org.apache.spark.sql.expressions.Window
import org.apache.spark.sql.functions._
import org.apache.spark.sql.types.DataTypes
import org.apache.spark.sql.{DataFrame, SparkSession}
import org.slf4j.LoggerFactory

object ICPM_INSURANCE extends TableInfo[insurance] {

  private val log = LoggerFactory.getLogger(this.getClass)

  override def dependsOn = Set("INT_CLAIM_MEMBER")

  override def name = "ICPM_INSURANCE"

  override def createDataFrame(sparkSession: SparkSession,
                               loadedDependencies: Map[String, DataFrame],
                               udfMap: Map[String, UserDefinedFunctionForDataLoader],
                               runtimeVariables: RuntimeVariables): DataFrame = {
    import sparkSession.implicits._

    val intClaimMemberIn = loadedDependencies("INT_CLAIM_MEMBER").as[int_claim_member]

    val intClaimMemberDf = intClaimMemberIn.select(
      lit("int_claim_member").as("datasrc")
      ,$"groupid"
      ,$"client_ds_id"
      ,$"Member_Id".as("patientid")
      ,when($"Member_Eff_Date".isNull && $"Member_End_Date".isNull && $"Eligibile_Member_Month".isNull, 3)
        .when($"Member_Eff_Date".isNull && $"Member_End_Date".isNull && $"Eligibile_Member_Month".isNotNull, 2)
        .otherwise(1).as("Mem_date")
      ,$"Member_Eff_Date"
      ,$"Member_End_Date"
      ,$"Financial_Class".as("plantype")
      ,$"Payer_Code".as("payorcode")
      ,$"Payer_Name".as("payorname")
      ,$"plan_Code".as("plancode")
      ,$"plan_Name".as("planname")
      ,$"Pharmacy_Benefit_Flag".as("rx_benefit_flag")
      ,$"Eligibile_Member_Month".as("Eligibile_Member_Month")
      ,$"product_code"
      ,$"product_name"
      ,$"contract_id"
      ,$"subscriber_id"
      ,$"subscriber_flag"
      ,$"coverage_status_code".as("subscriber_relation")
      ,$"emp_acct_id"
      ,$"contract_type_code"
      ,$"benefit_plan_code"
      ,$"coverage_class_code"
      ,when(IsSafeToNumber.isSafeToNumber($"dental_benefit_ind"), $"dental_benefit_ind").otherwise(null).as("dental_benefit_ind")
      ,$"employee_type"
      ,when(IsSafeToNumber.isSafeToNumber($"hra_ind"), $"hra_ind").otherwise(null).as("hra_ind")
      ,when(IsSafeToNumber.isSafeToNumber($"hsa_ind"), $"hsa_ind").otherwise(null).as("hsa_ind")
      ,when(IsSafeToNumber.isSafeToNumber($"medical_benefit_flag"), $"medical_benefit_flag").otherwise(null).as("medical_benefit_ind")
      ,when(IsSafeToNumber.isSafeToNumber($"mh_benefit_ind"), $"mh_benefit_ind").otherwise(null).as("mh_benefit_ind")
    )

    val disIntClaimMemberDf = intClaimMemberDf.select(
      $"groupid"
      ,$"datasrc"
      ,$"client_ds_id"
      ,coalesce($"Member_Eff_Date", safeToDate(col("Eligibile_Member_Month"), lit("yyyyMM"))).as("ins_timestamp")
      ,$"patientid"
      ,when($"Mem_date" === 3, lit(null))
        .when($"Mem_date" === 2, last_day(safeToDate(col("Eligibile_Member_Month"), lit("yyyyMM"))))
        .otherwise($"Member_End_Date").as("enrollenddt")
      ,when($"Mem_date" === 3, lit(null))
          .when($"Mem_date" === 2, safeToDate(col("Eligibile_Member_Month"), lit("yyyyMM")))
          .otherwise($"Member_Eff_Date").as("enrollstartdt")
      ,$"plantype"
      ,$"payorcode"
      ,$"payorname"
      ,$"plancode"
      ,$"rx_benefit_flag"
      ,$"PRODUCT_CODE"
      ,$"PRODUCT_NAME"
      ,$"contract_id"
      ,$"subscriber_id"
      ,$"subscriber_flag"
      ,$"subscriber_relation"
      ,$"emp_acct_id"
      ,$"contract_type_code"
      ,$"benefit_plan_code"
      ,$"coverage_class_code"
      ,$"dental_benefit_ind"
      ,$"employee_type"
      ,$"hra_ind"
      ,$"hsa_ind"
      ,$"medical_benefit_ind".cast(DataTypes.IntegerType)
      ,$"mh_benefit_ind"
      ,$"planname"
      ,lit(null).cast(DataTypes.StringType).as("encounterid")
      ,lit(null).cast(DataTypes.StringType).as("groupnbr")
      ,lit(null).cast(DataTypes.StringType).as("grp_mpi")
      ,lit(null).cast(DataTypes.LongType).as("hgpid")
      ,lit(null).cast(DataTypes.IntegerType).as("insuranceorder")
      ,lit(null).cast(DataTypes.StringType).as("mappedpayorcode")
      ,lit(null).cast(DataTypes.StringType).as("mappedplanfincode")
      ,lit(null).cast(DataTypes.StringType).as("policynumber")
      ,lit(null).cast(DataTypes.StringType).as("sourceid")
      ,lit(null).cast(DataTypes.StringType).as("facilityid")
    ).distinct()

    val insuranceDf = disIntClaimMemberDf.where($"ins_timestamp".isNotNull && $"patientid".isNotNull).select(
      max($"rx_benefit_flag").over(Window.partitionBy($"contract_id", $"patientid", $"payorcode", $"enrollstartdt", $"enrollenddt")).as("pharmacy_benefit_flag")
      ,$"*"
    )

    insuranceDf.drop($"rx_benefit_flag")

  }
}