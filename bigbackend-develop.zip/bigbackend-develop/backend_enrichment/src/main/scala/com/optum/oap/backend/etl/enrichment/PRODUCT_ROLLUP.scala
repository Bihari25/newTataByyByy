package com.optum.oap.backend.etl.enrichment

import com.optum.oap.backend.etl.common.MapMasterIds
import com.optum.oap.backend.loader.EnrichmentRunTimeVariables
import com.optum.oap.cdr.models.{product_rollup, int_claim_member}
import com.optum.oap.sparkdataloader.{RuntimeVariables, TableInfo, UserDefinedFunctionForDataLoader}
import org.apache.hadoop.yarn.webapp.hamlet.HamletSpec.SUB
import org.apache.spark.sql.expressions.Window
import org.apache.spark.sql.{DataFrame, SparkSession}
import org.slf4j.LoggerFactory
import org.apache.spark.sql.functions.{coalesce, length, regexp_replace, _}
import org.apache.spark.sql.types.DataTypes
import org.apache.spark.sql.types._

object PRODUCT_ROLLUP extends TableInfo[product_rollup] {

  private val log = LoggerFactory.getLogger(this.getClass)

  override def dependsOn = Set("CDR_FE_PRODUCT_ROLLUP", "INT_CLAIM_MEMBER")

  override def name = "PRODUCT_ROLLUP"

  override def partitions: Int = 32

  override def createDataFrame(sparkSession: SparkSession,
                               loadedDependencies: Map[String, DataFrame],
                               udfMap: Map[String, UserDefinedFunctionForDataLoader],
                               runtimeVariables: RuntimeVariables): DataFrame = {

    import sparkSession.implicits._

    val cdrProductRollup = loadedDependencies("CDR_FE_PRODUCT_ROLLUP").as[product_rollup]

    val intClaimMemDf = loadedDependencies("INT_CLAIM_MEMBER").as[int_claim_member]

    //Frontend Product Rollup table
    val cdrFeProductRollup1 = cdrProductRollup.select(
      $"groupid",
      $"client_ds_id",
      $"datasrc",
      $"product_code",
      $"product_desc",
      $"product_lv2",
      $"product_lv2_desc",
      $"product_lv1",
      $"product_lv1_desc"
    )

    //Filtering Frontend Product Rollup table
    val cdrFePR = cdrFeProductRollup1
      .dropDuplicates("PRODUCT_CODE")

    //getting the records from intclaimmember whose emp_acct_id is not in the Product Rollup
    val iCM2 = intClaimMemDf.as("a").join(cdrFePR.as("b"), ($"a.product_code" === $"b.product_code"), "left")
      .select($"a.groupid",
        $"a.client_ds_id",
        lit("int_claim_member") as("datasrc"),
        $"a.product_code",
        substring(coalesce($"a.product_name",concat(lit("UNDEFINED ("), $"a.product_code",lit(")"))),1,150).as("product_desc"),
        $"b.product_lv2",
        $"b.product_lv2_desc",
        $"b.product_lv1",
        $"b.product_lv1_desc"
      )
      .where(($"a.product_code" isNotNull) && (length($"a.product_code") <=30) && ($"b.product_code" isNull))
      .groupBy(
        $"a.groupid",
        $"a.product_code",
        $"datasrc",
        $"product_desc",
        $"b.product_lv2",
        $"b.product_lv2_desc",
        $"b.product_lv1",
        $"b.product_lv1_desc")
      .agg(min($"a.client_ds_id").as("client_ds_id"))

    //union the missed records from intclaimmember and the original table
    val unionProductRollup = cdrFeProductRollup1.unionByName(iCM2)

    //Applying the additional logic and loading to the backend table.
    val rollup = unionProductRollup.select(
      $"groupid"
      ,$"client_ds_id"
      ,$"datasrc"
      ,$"product_code"
      ,substring(coalesce($"product_desc", concat(lit("UNDEFINED ("),$"product_code",lit(")"))),1,150).as("product_desc")
      ,substring(coalesce($"product_lv2", concat(lit("3."),$"product_code")),1,30).as("product_lv2")
      ,substring(when($"product_lv2".isNull,coalesce($"product_desc",concat(lit("UNDEFINED ("),$"product_code",lit(")"))))
        .otherwise(coalesce($"product_lv2_desc",concat(lit("UNDEFINED ("),$"product_lv2",lit(")")))) ,1,150)
        .as("product_lv2_desc")
      ,substring(when($"product_lv1".isNotNull,$"product_lv1")
        .otherwise(when($"product_lv2".isNotNull,concat(lit("2."),$"product_lv2"))
          .otherwise(concat(lit("3."),$"product_code"))),1,30).as("product_lv1")
      ,substring(when($"product_lv1".isNull,
        when($"product_lv2".isNull,coalesce($"product_desc",concat(lit("UNDEFINED ("),$"product_code",lit(")")) ))
          .otherwise(coalesce($"product_lv2_desc",concat(lit("UNDEFINED ("),$"product_lv2",lit(")")) )))
        .otherwise(coalesce($"product_lv1_desc",concat(lit("UNDEFINED ("),$"product_lv1",lit(")")))),1,150).as("product_lv1_desc")
      ,row_number().over(Window.partitionBy($"product_code")
        .orderBy(
          when($"product_desc".isNotNull, lit(0)).otherwise(lit(1)),
          when($"product_lv2".isNotNull, lit(0)).otherwise(lit(1)),
          when($"product_lv1".isNotNull, lit(0)).otherwise(lit(1)),
          $"product_desc",$"product_lv2",$"product_lv1"
        )).as("rn")
    )
      .where((unionProductRollup("product_code") isNotNull) && (length(unionProductRollup("product_code")) <=30) && ($"rn"=== 1))
      .drop($"rn")
    rollup.toDF()
  }
}