package com.optum.oap.backend.etl.encgrps

import java.sql.Timestamp
import java.time.temporal.ChronoUnit
import java.time.{LocalDate, LocalDateTime}

import com.optum.oap.backend.cdrTempModel._
import com.optum.oap.backend.loader.EnrichmentRunTimeVariables
import com.optum.oap.sparkdataloader.{RuntimeVariables, TableInfo, UserDefinedFunctionForDataLoader}
import com.optum.oap.sparklib.UniqueLongGenerator
import org.apache.spark.TaskContext
import org.apache.spark.sql.functions._
import org.apache.spark.sql.{DataFrame, Dataset, SparkSession}

import scala.collection.mutable

object TEMP_EEG extends TableInfo[temp_eeg] {

  val MASTER_ENCOUNTER_TYPE = "MASTER"
  val ENCTR_ENCOUNTER_TYPE = "ENCTR"
  val MASTER_106_CUI = "CH000106"
  val MASTER_107_CUI = "CH000107"
  val MASTER_109_CUI = "CH000109"
  val MASTER_113_CUI = "CH000113"
  val MASTER_CUI_SET = Set(MASTER_106_CUI, MASTER_107_CUI, MASTER_109_CUI, MASTER_113_CUI)

  override def name: String = "TEMP_EEG"

  override def dependsOn: Set[String] = Set("TEMP_EEG_P1", "TEMP_EEG_PROV", "TEMP_VISIT_ENCTR", "TEMP_EEG_PDX")

  override def partitions: Int = 512

  override protected def createDataFrame(sparkSession: SparkSession, loadedDependencies: Map[String, DataFrame], udfMap: Map[String, UserDefinedFunctionForDataLoader], runtimeVariables: RuntimeVariables): DataFrame = {

    import sparkSession.implicits._

    val tempEEGP1 = loadedDependencies("TEMP_EEG_P1").as[temp_eeg_p1]
    val tempVisitEncounter = loadedDependencies("TEMP_VISIT_ENCTR").as[temp_visit_enctr]
    val tempEEGProv = loadedDependencies("TEMP_EEG_PROV").as[temp_eeg_prov]
    val tempEEGPdx = loadedDependencies("TEMP_EEG_PDX").as[temp_eeg_pdx]

    val partitionMultiplier = EnrichmentRunTimeVariables(runtimeVariables).partitionMultiplier
    val ds = calculateEverything(sparkSession, tempEEGP1, tempVisitEncounter, tempEEGProv, tempEEGPdx, partitionMultiplier)

    ds.toDF()
  }

  private def calculateEverything(sparkSession: SparkSession,
                                  tempEEGP1: Dataset[temp_eeg_p1],
                                  tempVisitEncounter: Dataset[temp_visit_enctr],
                                  tempEEGProv: Dataset[temp_eeg_prov],
                                  tempEEGPdx: Dataset[temp_eeg_pdx],
                                  partitionMultiplier: Double): Dataset[temp_eeg] = {

    import sparkSession.implicits._

    val fullVisits = tempVisitEncounter.as("eeg")
      .join(tempEEGPdx.as("pdx"), $"eeg.client_ds_id" === $"pdx.client_ds_id" and $"eeg.encounterid" === $"pdx.encounterid" and $"eeg.grp_mpi" === $"pdx.grp_mpi", "left_outer")
      .join(tempEEGProv.as("prov"), $"eeg.client_ds_id" === $"prov.client_ds_id" and $"eeg.encounterid" === $"prov.encounterid" and $"eeg.grp_mpi" === $"prov.grp_mpi", "left_outer")
      .select(
        $"eeg.*", $"prov.prov_id", $"pdx.prindx", $"pdx.prindx_codetype", $"pdx.hosp_dx_flag"
      )
      .as[VisitEncounterWithProviderAndPrindx]

    val encounterDocuments = tempEEGP1.as("eeg")
      .groupBy("grp_mpi")
      .agg(collect_list(struct(classOf[temp_eeg_p1].getDeclaredFields.toList.withFilter(!_.isSynthetic()).map(f => $"${f.getName}"): _*)).as("encounters"))
      .join(
        fullVisits
          .groupBy($"grp_mpi")
          .agg(collect_list(struct(classOf[VisitEncounterWithProviderAndPrindx].getDeclaredFields.toList.withFilter(!_.isSynthetic()).map(f => $"${f.getName}"): _*)).as("visitEncounters"))
          .as("v"),
        $"v.grp_mpi" === $"eeg.grp_mpi",
        "full_outer"
      )
      .withColumn("final_mpi", coalesce($"eeg.grp_mpi", $"v.grp_mpi"))
      .repartition(Math.ceil(partitions * partitionMultiplier).toInt, $"final_mpi")
      .as[EncountersDoc]

    encounterDocuments.mapPartitions(docs => {

      val generator = UniqueLongGenerator(TaskContext.getPartitionId.toLong)

      docs.toSeq.groupBy(_.final_mpi).flatMap {
        case (_, patientDocs) =>
          val (allEncounters, allVisitEncounters) = patientDocs.foldLeft((Seq.empty[temp_eeg_p1], Seq.empty[VisitEncounterWithProviderAndPrindx])) {
            case ((incomingTempEegP1, incomingVE), doc) =>
              val encounters = if (doc.encounters == null) {
                Seq.empty[temp_eeg_p1]
              } else {
                doc.encounters
              }

              val visitEncounters = if (doc.visitEncounters == null) {
                Seq.empty
              } else {
                doc.visitEncounters
              }

              (incomingTempEegP1 ++ encounters, incomingVE ++ visitEncounters)
          }

          val groups = mutable.Map.empty[Long, EncounterGroupDetails]

          val groupedNonExcludedEncounters = groupIncludedEncounters(allEncounters, groups, generator)

          val groupedExcluded = groupExcludedEncounters(allEncounters, groups)

          val supportingPatienttypeEncounters = groupSupportingVisitEncounters(allVisitEncounters, groups)

          val allEncountersSoFar = groupedNonExcludedEncounters ++ groupedExcluded ++ supportingPatienttypeEncounters

          val additionalCopies = groupAdditionalCopies(allEncountersSoFar, groups)

          val allWithCopies = allEncountersSoFar ++ additionalCopies

          val splitVisitEncounters = splitVisitEncountersByProvIdNull(allVisitEncounters, allWithCopies)

          val provIdNotNull = splitVisitEncounters.withNonNullProvId
          val provIdNull = splitVisitEncounters.withNullProvId

          val groupedFromProvIdNotNull = groupFromProvIdNotNull(provIdNotNull, groups, generator)

          val allWithNotNull = allWithCopies ++ groupedFromProvIdNotNull

          val encountersFromNull = groupFromProvIdNull(provIdNull, groups, allWithNotNull.toSeq, generator)

          allWithNotNull ++ encountersFromNull
      }.toIterator
    })
  }

  private def groupIncludedEncounters(encounters: Seq[temp_eeg_p1], groups: mutable.Map[Long, EncounterGroupDetails], generator: UniqueLongGenerator): Iterable[temp_eeg] = {
    encounters
      .filter(_.excl == "N")
        .sortBy(e => (e.enc_order, e.patienttype))
        .map(encounter => {

          lazy val encounterArrivalDate = truncateTimestampToDate(encounter.arrivaltime)
          // select relevant group
          val relevantGroup = if (groups.isEmpty) {
            EncounterGroupDetails()
          } else {
            val validGroups = groups.filter {
              case (_, details) =>
                val groupDischarge = details.truncatedDischargeDate.plusDays(1)

                encounter.patienttype == details.masterPatienttype && dateBetween(encounterArrivalDate, details.truncatedArrivalDate, groupDischarge)
            }

            if (validGroups.isEmpty) {
              EncounterGroupDetails()
            } else {
              val sortMethod: (EncounterGroupDetails, EncounterGroupDetails) => Boolean = encounterGroupSortForIncluded(encounter)
              val sortedGroups = validGroups.values.toSeq.sortWith(sortMethod)

              val topGroup = sortedGroups.head

              topGroup
            }
          }

          lazy val daysBetweenEncounterAndGroup = daysBetween(encounter, relevantGroup)

          lazy val encounterDischargeDate = truncateTimestampToDate(encounter.dischargetime)

          val (encounterIdType, encounterGroupNumber: java.lang.Long) = if (relevantGroup.groupNumber == null) {
            (MASTER_ENCOUNTER_TYPE, generator.generateUniqueId)
          } else if (encounter.master_facility_name != null &&
            relevantGroup.minMasterFacilityName != null &&
            relevantGroup.minMasterFacilityName != encounter.master_facility_name) {
            (MASTER_ENCOUNTER_TYPE, generator.generateUniqueId)
          } else if (daysBetweenEncounterAndGroup == 0 && MASTER_CUI_SET.contains(encounter.patienttype)) {
            (MASTER_ENCOUNTER_TYPE, generator.generateUniqueId)
          } else if (daysBetweenEncounterAndGroup == 0) {
            (ENCTR_ENCOUNTER_TYPE, relevantGroup.groupNumber)
          } else if (daysBetweenEncounterAndGroup > 1) {
            (ENCTR_ENCOUNTER_TYPE, relevantGroup.groupNumber)
          } else if (encounterArrivalDate.isAfter(relevantGroup.truncatedArrivalDate) && encounterArrivalDate.isBefore(relevantGroup.truncatedDischargeDate)) { // group dates should not be null since groupNumber is not null
            (ENCTR_ENCOUNTER_TYPE, relevantGroup.groupNumber)
          } else if (encounter.patienttype == MASTER_106_CUI &&
            relevantGroup.prindx.exists(_ != null) && encounter.prindx != null && !relevantGroup.prindx.contains(encounter.prindx) &&
            encounterDischargeDate.isAfter(encounterArrivalDate)) {
            (MASTER_ENCOUNTER_TYPE, generator.generateUniqueId)
          } else {
            (ENCTR_ENCOUNTER_TYPE, relevantGroup.groupNumber)
          }

          val outputMerged = temp_eeg(
            groupid = encounter.groupid,
            grp_mpi = encounter.grp_mpi,
            master_facility_name = encounter.master_facility_name,
            patienttype = encounter.patienttype,
            arrivaltime = encounter.arrivaltime,
            dischargetime = encounter.dischargetime,
            disposition = encounter.disposition,
            client_ds_id = encounter.client_ds_id,
            encounterid = encounter.encounterid,
            alt_encounterid = encounter.alt_encounterid,
            datasrc = encounter.datasrc,
            los = encounter.los,
            enc_order = encounter.enc_order,
            excl = encounter.excl,
            encounteridtype = encounterIdType,
            encounter_grp_num = encounterGroupNumber,
            prindx = encounter.prindx,
            prindx_codetype = encounter.prindx_codetype,
            hosp_dx_flag = encounter.hosp_dx_flag,
            prov_id = encounter.prov_id
          )

          val newGroup = EncounterGroupDetails.fromEncounter(outputMerged)

          val finalGroup = if (encounterIdType == MASTER_ENCOUNTER_TYPE) {
            mergeEncounterGroups(EncounterGroupDetails(), newGroup)
          } else {
            mergeEncounterGroups(relevantGroup, newGroup)
          }

          // update the group
          groups.put(finalGroup.groupNumber, finalGroup)

          outputMerged
        })

  }

  private def groupExcludedEncounters(encounters: Seq[temp_eeg_p1], groups: mutable.Map[Long, EncounterGroupDetails]): Iterable[temp_eeg] = {
    encounters.filter(_.excl == "Y").sortBy(e => (e.enc_order, e.patienttype)).flatMap(encounter => {
      lazy val arrival = truncateTimestampToDate(encounter.arrivaltime)
      lazy val discharge = truncateTimestampToDate(encounter.dischargetime)
      val validGroups = groups.filter {
        case (_, details) =>
          (encounter.master_facility_name == null || encounter.master_facility_name == details.maxMasterFacilityName) &&
            dateBetween(arrival, details.truncatedArrivalDate, details.truncatedDischargeDate) && dateBetween(discharge, details.truncatedArrivalDate, details.truncatedDischargeDate)
      }

      if (validGroups.isEmpty) {
        None
      } else {
        val sortMethod: (EncounterGroupDetails, EncounterGroupDetails) => Boolean = encounterGroupSortForExcluded(encounter)
        val relevantGroup = validGroups.values.toSeq.sortWith(sortMethod).head

        val encounterIdType = if (encounter.patienttype == relevantGroup.masterPatienttype) {
          Some(ENCTR_ENCOUNTER_TYPE)
        } else if (encounter.patienttype == MASTER_109_CUI && relevantGroup.masterPatienttype == MASTER_106_CUI) {
          Some("ADD ER")
        } else if (encounter.patienttype == MASTER_107_CUI && relevantGroup.masterPatienttype == MASTER_106_CUI) {
          Some("ADD OB")
        } else if (encounter.patienttype == MASTER_113_CUI && relevantGroup.masterPatienttype == MASTER_106_CUI) {
          Some("ADD SD")
        } else if (encounter.patienttype == MASTER_109_CUI && relevantGroup.masterPatienttype == MASTER_107_CUI) {
          Some("ADD ER")
        } else {
          None
        }

        encounterIdType.map(idType => {

          val outputMerged = temp_eeg(
            groupid = encounter.groupid,
            grp_mpi = encounter.grp_mpi,
            master_facility_name = encounter.master_facility_name,
            patienttype = encounter.patienttype,
            arrivaltime = encounter.arrivaltime,
            dischargetime = encounter.dischargetime,
            disposition = encounter.disposition,
            client_ds_id = encounter.client_ds_id,
            encounterid = encounter.encounterid,
            alt_encounterid = encounter.alt_encounterid,
            datasrc = encounter.datasrc,
            los = encounter.los,
            enc_order = encounter.enc_order,
            excl = encounter.excl,
            encounteridtype = idType,
            encounter_grp_num = relevantGroup.groupNumber,
            prindx = encounter.prindx,
            prindx_codetype = encounter.prindx_codetype,
            hosp_dx_flag = encounter.hosp_dx_flag,
            prov_id = encounter.prov_id
          )

          // enctr can affect downstream calculation
          if (idType == ENCTR_ENCOUNTER_TYPE) {
            val newGroup = EncounterGroupDetails.fromEncounter(outputMerged)

            val finalGroup = mergeEncounterGroups(relevantGroup, newGroup)

            // update the group
            groups.put(finalGroup.groupNumber, finalGroup)
          }

          outputMerged
        })
      }
    })
  }

  private def groupSupportingVisitEncounters(visitEncounters: Iterable[VisitEncounterWithProviderAndPrindx], groups: mutable.Map[Long, EncounterGroupDetails]): Iterable[temp_eeg] = {
    visitEncounters.filter(
      ve => ve.excl_fac == "N" &&
        Set("CH000924","CH000935","CH000936","CH000937","CH000662","CH999999","CH999990").contains(ve.patienttype)
    ).flatMap(visitEncounter => {

      lazy val arrival = truncateTimestampToDate(visitEncounter.arrivaltime)
      lazy val discharge = truncateTimestampToDate(visitEncounter.dischargetime)

      val validGroups = groups.filter {
        case (_, details) =>
          (visitEncounter.master_facility_name == null || visitEncounter.master_facility_name == details.maxMasterFacilityName) &&
            dateBetween(arrival, details.truncatedArrivalDate, details.truncatedDischargeDate) && dateBetween(discharge, details.truncatedArrivalDate, details.truncatedDischargeDate)
      }

      if (validGroups.isEmpty) {
        None
      } else {
        val sortMethod: (EncounterGroupDetails, EncounterGroupDetails) => Boolean = encounterGroupSortForIncludedVisitEncounters(visitEncounter)
        val selectedGroup = validGroups.values.toSeq.sortWith(sortMethod).head

        val encounterIdType = if (Set("CH000924","CH000935","CH000936","CH000937").contains(visitEncounter.patienttype)) {
          "ADD AS"
        } else if (visitEncounter.patienttype == "CH000662") {
          "ADD OT"
        } else if (Set("CH999999","CH999990").contains(visitEncounter.patienttype)) {
          "ADD UN"
        } else {
          throw new NotImplementedError(s"""Unmatched patienttype "${visitEncounter.patienttype}" found during calculation of visitEncounters.""")
        }

        val los = daysBetweenDates(arrival, discharge)

        // this specifically leaves out prindx, prindx_codetype, and hosp_dx_flag columns to follow Oracle
        Some(
          temp_eeg(
            groupid = visitEncounter.groupid,
            grp_mpi = visitEncounter.grp_mpi,
            master_facility_name = visitEncounter.master_facility_name,
            patienttype = visitEncounter.patienttype,
            arrivaltime = visitEncounter.arrivaltime,
            dischargetime = visitEncounter.dischargetime,
            disposition = visitEncounter.disposition,
            client_ds_id = visitEncounter.client_ds_id,
            encounterid = visitEncounter.encounterid,
            alt_encounterid = visitEncounter.alt_encounterid,
            datasrc = visitEncounter.datasrc,
            los = los.intValue(),
            enc_order = 0,
            excl = visitEncounter.excl,
            encounteridtype = encounterIdType,
            encounter_grp_num = selectedGroup.groupNumber,
            prov_id = visitEncounter.prov_id
          )
        )
      }
    })
  }

  private def groupAdditionalCopies(encounters: Iterable[temp_eeg], groups: mutable.Map[Long, EncounterGroupDetails]): Iterable[temp_eeg] = {
    val sourceGroups = groups.filter {
      case (_, details) =>
        details.masterPatienttype == MASTER_107_CUI || details.masterPatienttype == MASTER_109_CUI || details.masterPatienttype == MASTER_113_CUI
    }

    val targetGroups = groups.filter {
      case (_, details) =>
        details.masterPatienttype == MASTER_106_CUI
    }

    encounters.filter(e => sourceGroups.keySet.contains(e.encounter_grp_num)).flatMap(encounter => {

      val sourceGroup = groups(encounter.encounter_grp_num)

      val validGroups = targetGroups.filter {
        case (_, details) =>
          (sourceGroup.maxMasterFacilityName == null || sourceGroup.maxMasterFacilityName == details.maxMasterFacilityName) &&
            ((timestampBetween(sourceGroup.dischargetime.toLocalDateTime, details.truncatedArrivalDate.atStartOfDay(), details.dischargetime.toLocalDateTime) && sourceGroup.arrivaltime.before(details.dischargetime)) ||
              (sourceGroup.truncatedDischargeDate == details.truncatedArrivalDate.minusDays(1) && sourceGroup.dischargetime.toLocalDateTime != sourceGroup.truncatedDischargeDate.atStartOfDay() && sourceGroup.arrivaltime == sourceGroup.dischargetime))
      }

      if (validGroups.isEmpty) {
        None
      } else {
        val selectedGroup = validGroups.values.toSeq.sortWith((group1, group2) => {
          val arrivalResultG1 = group1.truncatedArrivalDate match {
            case x if x == sourceGroup.truncatedArrivalDate => 1
            case x if x == sourceGroup.truncatedArrivalDate.plusDays(1) => 2
            case _ => 3
          }

          val arrivalResultG2 = group2.truncatedArrivalDate match {
            case x if x == sourceGroup.truncatedArrivalDate => 1
            case x if x == sourceGroup.truncatedArrivalDate.plusDays(1) => 2
            case _ => 3
          }

          if (arrivalResultG1 != arrivalResultG2) {
            arrivalResultG1 < arrivalResultG2
          } else {
            group1.groupNumber < group2.groupNumber
          }
        }).head

        val los = daysBetweenDates(truncateTimestampToDate(encounter.arrivaltime), truncateTimestampToDate(encounter.dischargetime))

        val encounterIdType = sourceGroup.masterPatienttype match {
          case MASTER_107_CUI => "ADD OB"
          case MASTER_109_CUI => "ADD ER"
          case MASTER_113_CUI => "ADD SD"
          case x => throw new NotImplementedError(s"""Unmatched patient type "$x" when comparing sourceGroup.masterPatienttype""")
        }

        Some(
          encounter.copy(
            enc_order = 0,
            los = los.intValue(),
            encounter_grp_num = selectedGroup.groupNumber,
            encounteridtype = encounterIdType,
            prindx = null,
            prindx_codetype = null,
            hosp_dx_flag = null
          )
        )
      }
    })
  }

  private def splitVisitEncountersByProvIdNull(visitEncounters: Seq[VisitEncounterWithProviderAndPrindx], encounters: Iterable[temp_eeg]): SplitVisitEncounters = {
    val existingDSIDAndEncounterId = encounters.map(encounter => (encounter.client_ds_id, encounter.encounterid)).toSet
    val (provIdNull, provIdNotNull) = visitEncounters.filter(ve => {
      val daysBetween = daysBetweenDates(truncateTimestampToDate(ve.arrivaltime), truncateTimestampToDate(ve.dischargetime))
      !Set("CH000795","CH003031","CH003032").contains(ve.patienttype) && daysBetween >= 0 && !existingDSIDAndEncounterId.contains((ve.client_ds_id, ve.encounterid))
    }).groupBy(
      ve => (ve.patienttype, ve.prov_id, truncateTimestampToDate(ve.arrivaltime))
    ).flatMap {
      case (_, groupedVEs) =>
        groupedVEs.sortWith((l, r) => {
          if (l.siteofcare_name != r.siteofcare_name) {
            if (l.siteofcare_name == null) {
              false
            } else if (r.siteofcare_name == null) {
              true
            } else {
              l.siteofcare_name < r.siteofcare_name
            }
          } else {
            if (l.encounterid != r.encounterid) {
              l.encounterid < r.encounterid
            } else {
              l.client_ds_id < r.client_ds_id
            }
          }
        }).zipWithIndex
    }.map {
      case (ve, enc_order) =>

        val patienttype = ve.patienttype match {
          case MASTER_106_CUI => "CH003527"
          case MASTER_107_CUI => "CH003528"
          case MASTER_109_CUI => "CH003529"
          case MASTER_113_CUI => "CH003530"
          case _ => ve.patienttype
        }
        val los = daysBetweenDates(truncateTimestampToDate(ve.arrivaltime), truncateTimestampToDate(ve.dischargetime))

        temp_eeg(
          groupid = ve.groupid,
          grp_mpi = ve.grp_mpi,
          master_facility_name = ve.siteofcare_name,
          patienttype = patienttype,
          arrivaltime = ve.arrivaltime,
          dischargetime = ve.dischargetime,
          disposition = ve.disposition,
          client_ds_id = ve.client_ds_id,
          encounterid = ve.encounterid,
          alt_encounterid = ve.alt_encounterid,
          datasrc = ve.datasrc,
          los = los.intValue() + 1,
          enc_order = enc_order + 1, // zipWithIndex is 0 based and this needs to start at 1
          excl = "N",
          prov_id = ve.prov_id,
          prindx = ve.prindx,
          prindx_codetype = ve.prindx_codetype,
          hosp_dx_flag = ve.hosp_dx_flag
        )
    }.toList.partition(_.prov_id == null)

    SplitVisitEncounters(provIdNull, provIdNotNull)
  }

  private def groupFromProvIdNotNull(encounters: Seq[temp_eeg], groups: mutable.Map[Long, EncounterGroupDetails], generator: UniqueLongGenerator): Iterable[temp_eeg] = {
    val groupedFromProvIdNotNull = encounters.sortBy(_.enc_order).flatMap(encounter => {
      if (encounter.enc_order == 1) {

        val updatedEncounter = encounter.copy(
          encounter_grp_num = generator.generateUniqueId,
          encounteridtype = MASTER_ENCOUNTER_TYPE
        )

        // create a new group and update it in the map.
        val group = EncounterGroupDetails.fromEncounter(updatedEncounter)

        groups.put(group.groupNumber, group)

        Seq(updatedEncounter)
      } else {
        lazy val arrivalDate = truncateTimestampToDate(encounter.arrivaltime)
        // add into a new group and pass it along as part of the output to later update the map.
        val validGroups = groups.filter {
          case (_, details) =>
            details.masterPatienttype == encounter.patienttype &&
              details.prov_id.contains(encounter.prov_id) &&
              details.truncatedArrivalDates.contains(arrivalDate)
        }.values

        validGroups.map(details => {
          encounter.copy(
            encounter_grp_num = details.groupNumber,
            encounteridtype = ENCTR_ENCOUNTER_TYPE
          )
        })
      }
    })

    // have to update groups separately for enc_order > 1
    groupedFromProvIdNotNull.filter(_.enc_order != 1).foreach(encounter => {
      val relevantGroup = groups(encounter.encounter_grp_num)

      val newGroup = EncounterGroupDetails.fromEncounter(encounter)

      val finalGroup = mergeEncounterGroups(relevantGroup, newGroup)

      // update the group
      groups.put(finalGroup.groupNumber, finalGroup)
    })

    groupedFromProvIdNotNull
  }

  private def groupFromProvIdNull(encounters: Seq[temp_eeg], groups: mutable.Map[Long, EncounterGroupDetails], allPrevious: Seq[temp_eeg], generator: UniqueLongGenerator): Iterable[temp_eeg] = {

    def findGroupForEncounter(encounter: temp_eeg, allowNewGroup: Boolean): Seq[EncounterGroupDetails] = {
      lazy val arrivalDate = truncateTimestampToDate(encounter.arrivaltime)
      val validGroups = groups.filter {
        case (_, details) =>
          encounter.patienttype == details.masterPatienttype &&
            details.truncatedArrivalDates.contains(arrivalDate)
      }.values.toSeq

      if (allowNewGroup && validGroups.isEmpty) {
        Seq(EncounterGroupDetails())
      } else {
        validGroups
      }
    }

    def mergeEncounterAndGroupIn(encounter: temp_eeg, group: EncounterGroupDetails): temp_eeg = {
      val groupFromEncounter = EncounterGroupDetails.fromEncounter(encounter)
      val merge1 = mergeEncounterGroups(group, groupFromEncounter)
      val finalMerge = if (groups.contains(merge1.groupNumber)) {
        mergeEncounterGroups(groups(merge1.groupNumber), merge1)
      } else {
        merge1
      }

      groups.put(finalMerge.groupNumber, finalMerge)

      encounter
    }

    def groupEncounters(encountersToGroup: Seq[temp_eeg], allowNewGroup: Boolean, previousRows: Seq[temp_eeg]): Iterable[temp_eeg] = {
      encountersToGroup.flatMap(encounter => {
        val validGroups = findGroupForEncounter(encounter, allowNewGroup)

        if (validGroups.isEmpty) {
          None
        } else {

          val topGroup = if (validGroups.size == 1) {
            validGroups.head
          } else {
            val matchingRows = previousRows.filter(r => validGroups.map(_.groupNumber).toSet.contains(r.encounter_grp_num))

            val sortMethod: (temp_eeg, temp_eeg) => Boolean = encounterSortForVisitEncountersWithNullProvId(encounter)
            val topMatchingRow = matchingRows.sortWith(sortMethod).head
            groups(topMatchingRow.encounter_grp_num)
          }

          val (encounterGroupNumber: java.lang.Long, encounterIdType) = if (topGroup.groupNumber == null) {
            (generator.generateUniqueId, MASTER_ENCOUNTER_TYPE)
          } else {
            (topGroup.groupNumber, ENCTR_ENCOUNTER_TYPE)
          }

          val finalEncounter = encounter.copy(
            encounter_grp_num = encounterGroupNumber,
            encounteridtype = encounterIdType
          )

          Some((finalEncounter, topGroup))
        }
      }).map(x => mergeEncounterAndGroupIn(x._1, x._2))
    }

    // '1' and 'not 1' have to be done separately
    //   every row with '1' can affect every row with 'not 1' but cannot affect other rows with '1'
    //   also, rows with 'not 1' cannot create a new group, and cannot affect each other
    val encountersFromNullWithEncOrder1 = groupEncounters(encounters.filter(_.enc_order == 1), allowNewGroup = true, allPrevious)

    val encountersFromNullWithEncOrderNot1 = groupEncounters(encounters.filter(_.enc_order != 1), allowNewGroup = false, allPrevious ++ encountersFromNullWithEncOrder1)

    encountersFromNullWithEncOrder1 ++ encountersFromNullWithEncOrderNot1
  }

  private def encounterGroupSortForIncluded(encounter: temp_eeg_p1)(group1: EncounterGroupDetails, group2: EncounterGroupDetails): Boolean = {
    val daysBetweenG1 = daysBetween(encounter, group1)
    val daysBetweenG2 = daysBetween(encounter, group2)

    val resultG1 = daysBetweenG1 match {
      case x if x > 1 => 1
      case 1 => 2
      case _ => 3
    }

    val resultG2 = daysBetweenG2 match {
      case x if x > 1 => 1
      case 1 => 2
      case _ => 3
    }

    // check if overlap 'type' is the same. >1, 1, or 0
    if (resultG1 != resultG2) {
      resultG1 < resultG2
    } else {

      val masterResultG1 = matchStrings(encounter.master_facility_name, group1.minMasterFacilityName)
      val masterResultG2 = matchStrings(encounter.master_facility_name, group2.minMasterFacilityName)

      // check if master_facility_name is the same
      if (masterResultG1 != masterResultG2) {
        masterResultG1 < masterResultG2
      } else {
        // Note: This matches Oracle, but it should be using the standard matchStrings instead
        val prindxResultG1 = group1.prindx.map(pdx => matchStringsNullLast(encounter.prindx, pdx)).min
        val prindxResultG2 = group2.prindx.map(pdx => matchStringsNullLast(encounter.prindx, pdx)).min

        // check if prindx is the same
        if (prindxResultG1 != prindxResultG2) {
          prindxResultG1 < prindxResultG2
        } else {

          // check if days between is the same
          if (daysBetweenG1 != daysBetweenG2) {
            daysBetweenG1 > daysBetweenG2
          } else {
            // final tiebreaker is the group number
            group1.groupNumber < group2.groupNumber
          }
        }
      }
    }
  }

  private def encounterGroupSortForExcluded(encounter: temp_eeg_p1)(group1: EncounterGroupDetails, group2: EncounterGroupDetails): Boolean = {

    val patientTypeResultG1 = group1.masterPatienttype match {
      case encounter.patienttype => 1
      case MASTER_106_CUI => 2
      case MASTER_107_CUI => 3
      case _ => 4
    }

    val patientTypeResultG2 = group2.masterPatienttype match {
      case encounter.patienttype => 1
      case MASTER_106_CUI => 2
      case MASTER_107_CUI => 3
      case _ => 4
    }

    if (patientTypeResultG1 != patientTypeResultG2) {
      patientTypeResultG1 < patientTypeResultG2
    } else {
      val daysBetweenG1 = daysBetween(encounter, group1)
      val daysBetweenG2 = daysBetween(encounter, group2)

      val daysBetweenResultG1 = daysBetweenG1 match {
        case x if x >= 2 => 1
        case _ => 2
      }
      val daysBetweenResultG2 = daysBetweenG2 match {
        case x if x >= 2 => 1
        case _ => 2
      }

      if (daysBetweenResultG1 != daysBetweenResultG2) {
        daysBetweenResultG1 < daysBetweenResultG2
      } else {
        /** could be improved by checking against all group.prindx instead of the max
          * val prindxResultG1 = group1.prindx.map(pdx => matchStrings(encounter.prindx, pdx, 2))
          * val prindxResultG1 = group2.prindx.map(pdx => matchStrings(encounter.prindx, pdx, 2))
          */
        val prindxResultG1 = matchStrings(encounter.prindx, maxNullLast(group1.prindx), 2)
        val prindxResultG2 = matchStrings(encounter.prindx, maxNullLast(group2.prindx), 2)

        if (prindxResultG1 != prindxResultG2) {
          prindxResultG1 < prindxResultG2
        } else {
          // could possibly be improved by checking against all group.prov_id instead of the max
          val provIdResultG1 = maxNullLast(group1.prov_id) match {
            case x if x == null | encounter.prov_id == null => 2
            case encounter.prov_id => 1
            case _ => 2
          }

          val provIdResultG2 = maxNullLast(group2.prov_id) match {
            case x if x == null | encounter.prov_id == null => 2
            case encounter.prov_id => 1
            case _ => 2
          }

          if (provIdResultG1 != provIdResultG2) {
            provIdResultG1 < provIdResultG2
          } else {
            if (daysBetweenG1 != daysBetweenG2) {
              daysBetweenG1 > daysBetweenG2
            } else {
              group1.groupNumber < group2.groupNumber
            }
          }
        }
      }
    }
  }

  private def encounterGroupSortForIncludedVisitEncounters(visitEncounter: VisitEncounterWithProviderAndPrindx)(group1: EncounterGroupDetails, group2: EncounterGroupDetails): Boolean = {
    val daysBetweenG1 = daysBetween(visitEncounter, group1)
    val daysBetweenG2 = daysBetween(visitEncounter, group2)

    if (daysBetweenG1 != daysBetweenG2) {
      daysBetweenG1 > daysBetweenG2
    } else {

      val patientTypeResultG1 = group1.masterPatienttype match {
        case MASTER_107_CUI => 1
        case MASTER_109_CUI => 2
        case MASTER_113_CUI => 3
        case _ => 4
      }

      val patientTypeResultG2 = group2.masterPatienttype match {
        case MASTER_107_CUI => 1
        case MASTER_109_CUI => 2
        case MASTER_113_CUI => 3
        case _ => 4
      }

      if (patientTypeResultG1 != patientTypeResultG2) {
        patientTypeResultG1 < patientTypeResultG2
      } else {
        val masterFacilityResultG1 = matchStrings(visitEncounter.master_facility_name, group1.maxMasterFacilityName, 2)
        val masterFacilityResultG2 = matchStrings(visitEncounter.master_facility_name, group2.maxMasterFacilityName, 2)

        if (masterFacilityResultG1 != masterFacilityResultG2) {
          masterFacilityResultG1 < masterFacilityResultG2
        } else {
          group1.groupNumber < group2.groupNumber
        }
      }
    }
  }

  private def encounterSortForVisitEncountersWithNullProvId(encounter: temp_eeg)(left: temp_eeg, right: temp_eeg): Boolean = {
    val lFacilityResult = matchStrings(encounter.master_facility_name, left.master_facility_name)
    val rFacilityResult = matchStrings(encounter.master_facility_name, right.master_facility_name)

    if (lFacilityResult != rFacilityResult) {
      lFacilityResult < rFacilityResult
    } else {
      val lPrindxResult = matchStrings(encounter.prindx, left.prindx)
      val rPrindxResult = matchStrings(encounter.prindx, right.prindx)

      if (lPrindxResult != rPrindxResult) {
        lPrindxResult < rPrindxResult
      } else {
        if (left.encounterid != right.encounterid) {
          left.encounterid < right.encounterid
        } else {
          left.client_ds_id < right.client_ds_id
        }
      }
    }
  }

  private def mergeEncounterGroups(oldDetails: EncounterGroupDetails, newDetails: EncounterGroupDetails): EncounterGroupDetails = {
    oldDetails.copy(
      groupNumber = if (oldDetails.groupNumber == null) {
        newDetails.groupNumber
      } else {
        oldDetails.groupNumber
      },
      // arrival time can be changed via a new time when either the existing is @ 00:00:00 or the encounter is earlier in the same day
      arrivaltime = if (oldDetails.arrivaltime == null) {
        newDetails.arrivaltime
      } else if (newDetails.truncatedArrivalDate == oldDetails.truncatedArrivalDate) { // encounterArrivalDate will either be == or after groupArrivalDate
        if (oldDetails.truncatedArrivalDate.atStartOfDay() == oldDetails.arrivaltime.toLocalDateTime) {
          newDetails.arrivaltime
        } else if (newDetails.truncatedArrivalDate.atStartOfDay() == newDetails.arrivaltime.toLocalDateTime) {
          oldDetails.arrivaltime
        } else if (newDetails.arrivaltime.before(oldDetails.arrivaltime)) {
          newDetails.arrivaltime
        } else {
          oldDetails.arrivaltime
        }
      }
      else {
        oldDetails.arrivaltime
      },
      // discharge time can be extended
      dischargetime = if (oldDetails.dischargetime == null) {
        newDetails.dischargetime
      } else if (oldDetails.dischargetime.before(newDetails.dischargetime)) {
        newDetails.dischargetime
      } else {
        oldDetails.dischargetime
      },
      // add the encounter prindx to the Set for the group
      prindx = if (oldDetails.prindx == null) {
        newDetails.prindx
      } else if (newDetails.prindx != null) {
        oldDetails.prindx ++ newDetails.prindx
      } else {
        Set.empty
      },
      // if masterPatienttype is null, then we are creating a new group
      masterPatienttype = if (oldDetails.masterPatienttype == null) {
        newDetails.masterPatienttype
      } else {
        oldDetails.masterPatienttype
      },
      prov_id = if (oldDetails.prov_id == null) {
        newDetails.prov_id
      } else if (newDetails.prov_id != null) {
        oldDetails.prov_id ++ newDetails.prov_id
      } else {
        Set.empty
      },
      allArrivalTimes = if (oldDetails.allArrivalTimes == null) {
        Set(newDetails.arrivaltime)
      } else {
        oldDetails.allArrivalTimes + newDetails.arrivaltime
      },
      minEncounterId = if (oldDetails.minEncounterId == null) {
        newDetails.minEncounterId
      } else if (newDetails.minEncounterId == null) {
        oldDetails.minEncounterId
      } else {
        newDetails.minEncounterId match {
          case x if x > oldDetails.minEncounterId => oldDetails.minEncounterId
          case x if x <= oldDetails.minEncounterId => x
        }
      },
      minClientDsId = if (oldDetails.minClientDsId == null) {
        newDetails.minClientDsId
      } else if (newDetails.minClientDsId == null) {
        oldDetails.minClientDsId
      } else {
        newDetails.minClientDsId match {
          case x if x > oldDetails.minClientDsId => oldDetails.minClientDsId
          case x if x <= oldDetails.minClientDsId => x
        }
      },
      encounterIds = if (oldDetails.encounterIds == null) {
        newDetails.encounterIds
      } else if (newDetails.encounterIds != null) {
        oldDetails.encounterIds ++ newDetails.encounterIds
      } else {
        Set.empty
      },
      masterFacilityNames = if (oldDetails.masterFacilityNames == null) {
        newDetails.masterFacilityNames
      } else if (newDetails.masterFacilityNames != null) {
        oldDetails.masterFacilityNames ++ newDetails.masterFacilityNames
      } else {
        Set.empty
      }
    )
  }

  private def timestampBetween(toCheck: LocalDateTime, toCheckIsAfter: LocalDateTime, toCheckIsBefore: LocalDateTime): Boolean = {
    (toCheck == toCheckIsAfter || toCheck.isAfter(toCheckIsAfter)) && (toCheck == toCheckIsBefore || toCheck.isBefore(toCheckIsBefore))
  }

  private def dateBetween(toCheck: LocalDate, toCheckIsAfter: LocalDate, toCheckIsBefore: LocalDate): Boolean = {
    (toCheck == toCheckIsAfter || toCheck.isAfter(toCheckIsAfter)) && (toCheck == toCheckIsBefore || toCheck.isBefore(toCheckIsBefore))
  }

  private def daysBetween(encounter: temp_eeg_p1, group: EncounterGroupDetails): Long = {
    daysBetween(truncateTimestampToDate(encounter.arrivaltime), group.truncatedArrivalDate, truncateTimestampToDate(encounter.dischargetime), group.truncatedDischargeDate)
  }

  private def daysBetween(encounter: VisitEncounterWithProviderAndPrindx, group: EncounterGroupDetails): Long = {
    daysBetween(truncateTimestampToDate(encounter.arrivaltime), group.truncatedArrivalDate, truncateTimestampToDate(encounter.dischargetime), group.truncatedDischargeDate)
  }

  def daysBetween(arrivalDate: LocalDate, groupArrival: LocalDate, dischargeDate: LocalDate, groupDischarge: LocalDate): Long = {
    val leastDischarge = leastLocalDate(groupDischarge, dischargeDate)
    val greatestArrival = maxLocalDate(groupArrival, arrivalDate)

    val daysBetween = daysBetweenDates(greatestArrival, leastDischarge) + 1

    daysBetween
  }

  private def daysBetweenDates(left: LocalDate, right: LocalDate): Long = {
    ChronoUnit.DAYS.between(left, right)
  }

  private def leastLocalDate(localDate1: LocalDate, localDate2: LocalDate): LocalDate = {
    if (localDate1.isBefore(localDate2)) {
      localDate1
    } else {
      localDate2
    }
  }

  private def maxLocalDate(localDate1: LocalDate, localDate2: LocalDate): LocalDate = {
    if (localDate1.isAfter(localDate2)) {
      localDate1
    } else {
      localDate2
    }
  }

  def truncateTimestampToDate(timestamp: Timestamp): LocalDate = {
    if (timestamp == null) {
      null
    } else {
      timestamp.toLocalDateTime.toLocalDate
    }
  }

  private def matchStrings(input: String, toMatch: String, nonMatchValue: Int = 3): Int = {
    input match {
      case x if x == null | (toMatch == null) => 2
      case x if x == toMatch => 1
      case _ => nonMatchValue
    }
  }

  private def matchStringsNullLast(input: String, toMatch: String): Int = {
    input match {
      case x if x == null | (toMatch == null) => 3
      case x if x == toMatch => 1
      case _ => 2
    }
  }

  def minNullLast[A <: Comparable[A]](list: Iterable[A]): A = {
    list.toSeq.sortWith {
      case (l, r) =>
        if (l == null) {
          false
        } else if (r == null) {
          true
        } else {
          l.compareTo(r) < 1
        }
    }.head
  }

  def maxNullLast[A <: Comparable[A]](list: Iterable[A]): A = {
    list.toSeq.sortWith {
      case (l, r) =>
        if (l == null) {
          false
        } else if (r == null) {
          true
        } else {
          l.compareTo(r) >= 1
        }
    }.head
  }
}

case class VisitEncounterWithProviderAndPrindx(groupid: String = null, patientid: String = null, grp_mpi: String = null,
                                               hgpid: java.lang.Long = null, client_ds_id: java.lang.Integer = null,
                                               localpatienttype: String = null, patienttype: String = null, datasrc: String = null,
                                               datasrc_type: String = null, encounterid: String = null, alt_encounterid: String = null,
                                               orig_arrivaltime: java.sql.Timestamp = null, arrivaltime: java.sql.Timestamp = null,
                                               orig_admittime: java.sql.Timestamp = null, admittime: java.sql.Timestamp = null,
                                               orig_dischargetime: java.sql.Timestamp = null, dischargetime: java.sql.Timestamp = null,
                                               facilityid: String = null, drg: String = null, drgtypecui: String = null,
                                               localdischargedisposition: String = null, disposition: String = null,
                                               localadmitsource: String = null, admitsource: String = null, aprdrg_cd: String = null,
                                               aprdrg_soi: String = null, aprdrg_rom: String = null, totalcost: java.lang.Double = null,
                                               totalcharge: java.lang.Double = null, wasplannedflg: String = null,
                                               master_facility_name: String = null, elos: java.lang.Double = null,
                                               excl: String = null, excl_fac: String = null, altid_excl: String = null,
                                               siteofcare_name: String = null,
                                               prov_id: java.lang.Long = null, prindx: String = null, prindx_codetype: String = null,
                                               hosp_dx_flag: String = null)

object EncounterGroupDetails {
  def fromEncounter(encounter: temp_eeg): EncounterGroupDetails = {
    new EncounterGroupDetails(
      groupNumber = encounter.encounter_grp_num,
      arrivaltime = encounter.arrivaltime,
      dischargetime = encounter.dischargetime,
      prindx = Set(encounter.prindx),
      masterPatienttype = encounter.patienttype,
      prov_id = Set(encounter.prov_id),
      allArrivalTimes = Set(encounter.arrivaltime),
      minEncounterId = encounter.encounterid,
      minClientDsId = encounter.client_ds_id,
      encounterIds = Set(encounter.encounterid),
      masterFacilityNames = Set(encounter.master_facility_name)
    )
  }
}

case class SplitVisitEncounters(withNullProvId: Seq[temp_eeg], withNonNullProvId: Seq[temp_eeg])

case class EncounterGroupDetails(groupNumber: java.lang.Long = null, arrivaltime: Timestamp = null, dischargetime: Timestamp = null,
                                 prindx: Set[String] = Set.empty, masterPatienttype: String = null,
                                 prov_id: Set[java.lang.Long] = Set.empty, allArrivalTimes: Set[Timestamp] = Set.empty, minEncounterId: String = null,
                                 minClientDsId: java.lang.Integer = null, encounterIds: Set[String] = Set.empty, masterFacilityNames: Set[String] = Set.empty) {
  lazy val truncatedArrivalDate: LocalDate = TEMP_EEG.truncateTimestampToDate(arrivaltime)
  lazy val truncatedDischargeDate: LocalDate = TEMP_EEG.truncateTimestampToDate(dischargetime)
  lazy val truncatedArrivalDates: Set[LocalDate] = allArrivalTimes.map(TEMP_EEG.truncateTimestampToDate)

  lazy val maxMasterFacilityName: String = TEMP_EEG.maxNullLast(masterFacilityNames)
  lazy val minMasterFacilityName: String = TEMP_EEG.minNullLast(masterFacilityNames)

  override def toString: String = {
    val sb = StringBuilder.newBuilder

    sb.append("{\n")
    sb.append(s"  groupNumber = $groupNumber\n")
    sb.append(s"  arrivaltime = $arrivaltime\n")
    sb.append(s"  dischargetime = $dischargetime\n")
    sb.append(s"  prindx = $prindx\n")
    sb.append(s"  masterPatienttype = $masterPatienttype\n")
    sb.append(s"  prov_id = $prov_id\n")
    sb.append(s"  allArrivalTimes = $allArrivalTimes\n")
    sb.append(s"  minEncounterId = $minEncounterId\n")
    sb.append(s"  minClientDsId = $minClientDsId\n")
    sb.append(s"  encounterIds = $encounterIds\n")
    sb.append(s"  masterFacilityNames = $masterFacilityNames\n")
    sb.append("}\n")
    sb.mkString
  }
}

case class EncountersDoc(final_mpi: String, encounters: Seq[temp_eeg_p1], visitEncounters: Seq[VisitEncounterWithProviderAndPrindx])

case class GroupedEncounters(grp_mpi: String, patienttype: String, encounter_grp_num: java.lang.Long, grouped_encounters: Seq[temp_eeg])
case class GroupedEncountersWithFinalId(grp_mpi: String, patienttype: String, grouped_encounters: Seq[temp_eeg], grouped_id: Long)