package com.optum.oap.backend.etl.enrichment

import com.optum.oap.backend.etl.common.{MapEntry, MapMasterIds, MatchRegExPattern}
import com.optum.oap.cdr.models.{insurance, patient_mpi, zcm_insure_co_map_pattern, zcm_insure_plan_map_pattern}
import com.optum.oap.sparkdataloader.{RuntimeVariables, TableInfo, UserDefinedFunctionForDataLoader}
import org.apache.spark.sql.{DataFrame, SparkSession}

object INSURANCE extends TableInfo[insurance] {

  override def dependsOn = Set("CDR_FE_INSURANCE", "PATIENT_MPI", "CDR_FE_ZCM_INSURE_CO_MAP_PATTERN", "CDR_FE_ZCM_INSURE_PLAN_MAP_PATTERN", "ICPM_INSURANCE")

  override def name = "INSURANCE"

  override def ignoreExtraColumnsInDataFrame: Boolean = true

  override def createDataFrame(sparkSession: SparkSession,
                               loadedDependencies: Map[String, DataFrame],
                               udfMap: Map[String, UserDefinedFunctionForDataLoader],
                               runtimeVariables: RuntimeVariables): DataFrame = {

    import sparkSession.implicits._
    import org.apache.spark.sql.functions._

    val insuranceIn = loadedDependencies("CDR_FE_INSURANCE")
      .drop("row_source","modified_date").as[insurance]
      .unionByName(loadedDependencies("ICPM_INSURANCE").as[insurance])

    val patXref = loadedDependencies("PATIENT_MPI").as[patient_mpi]


    val zcmInsCoMap = broadcast(loadedDependencies("CDR_FE_ZCM_INSURE_CO_MAP_PATTERN")).as[zcm_insure_co_map_pattern]
    val zcmInsPlanMap = broadcast(loadedDependencies("CDR_FE_ZCM_INSURE_PLAN_MAP_PATTERN")).as[zcm_insure_plan_map_pattern]

    //collect the distinct payor and plan names
    val payorPlans = insuranceIn.filter("payorname IS NOT NULL or planname IS NOT NULL").select($"planname", coalesce($"payorname", $"planname").as("payor_plan")).distinct

    //convert the maps to arrays of regex pattern/cui pairs
    val insCoMap = zcmInsCoMap.select("groupid", "priority", "txt_pattern", "cui").orderBy(col("groupid").desc, col("priority"))
      .agg(collect_list(struct($"txt_pattern", $"cui", $"priority", $"groupid")).as("entries")).as[GroupEntries]
    val insPlanMap = zcmInsPlanMap.select("groupid", "priority", "txt_pattern", "cui").orderBy(col("groupid").desc, col("priority"))
      .agg(collect_list(struct($"txt_pattern", $"cui", $"priority", $"groupid")).as("entries")).as[GroupEntries]

    //Match the distinct values using the regex patterns, returning the corresponding cui
    val payorMap = payorPlans.filter("payor_plan is not null").select("payor_plan").distinct.crossJoin(insCoMap)
      .withColumn("mappedpayorcode", MatchRegExPattern.matchRegExPattern($"payor_plan", $"entries"))
      .filter("mappedpayorcode is not null")
      .select($"payor_plan".as("map_payor_plan"), $"mappedpayorcode")

    val planMap = payorPlans.filter("planname is not null").select($"planname").distinct.crossJoin(insPlanMap)
      .withColumn("mappedplanfincode", MatchRegExPattern.matchRegExPattern($"planname", $"entries"))
      .filter("mappedplanfincode is not null")
      .select($"planname".as("map_planname"), $"mappedplanfincode")

    //populate the mapped columns in the Insurance table
    val mappedIns = insuranceIn.drop("mappedplanfincode", "mappedpayorcode")
      .withColumn("ins_payor_plan", coalesce($"payorname", $"planname"))
      .join(broadcast(payorMap), $"ins_payor_plan" <=> $"map_payor_plan", "left_outer")
      .join(broadcast(planMap), insuranceIn("planname") <=> planMap("map_planname"), "left_outer")
      .withColumn("mappedpayorcode", when(insuranceIn("payorname").isNotNull && payorMap("mappedpayorcode").isNull,
        lit("CH001202")).otherwise(payorMap("mappedpayorcode")))
      .withColumn("mappedplanfincode", when(insuranceIn("planname").isNotNull && planMap("mappedplanfincode").isNull,
        lit("CH000102")).otherwise(planMap("mappedplanfincode")))
      .drop("map_payor_plan", "ins_payor_plan", "map_planname")

    MapMasterIds.mapPatientIds(mappedIns.toDF, patXref.toDF, false)

  }


}


case class GroupEntries(entries: Array[MapEntry])
