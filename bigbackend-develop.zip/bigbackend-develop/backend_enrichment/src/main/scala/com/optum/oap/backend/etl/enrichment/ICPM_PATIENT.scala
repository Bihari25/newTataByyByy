package com.optum.oap.backend.etl.enrichment

import com.optum.oap.backend.cdrTempModel.temp_icpm_patient_patientdetail_patientcontact
import com.optum.oap.cdr.models.patient
import com.optum.oap.sparkdataloader.{RuntimeVariables, TableInfo, UserDefinedFunctionForDataLoader}
import org.apache.spark.sql.functions._
import org.apache.spark.sql.types.DataTypes
import org.apache.spark.sql.{DataFrame, SparkSession}
import org.slf4j.LoggerFactory

object ICPM_PATIENT
        extends TableInfo[patient] {

  private val log = LoggerFactory.getLogger(this.getClass)

  override def dependsOn = Set("ICPM_PATIENT_INTERMEDIATE")

  override def name = "ICPM_PATIENT"

  override def partitions: Int = 32

  override def createDataFrame(sparkSession: SparkSession,
                               loadedDependencies: Map[String, DataFrame],
                               udfMap: Map[String, UserDefinedFunctionForDataLoader],
                               runtimeVariables: RuntimeVariables): DataFrame = {

    import sparkSession.implicits._

    val cdrFePatientIntermediate = loadedDependencies("ICPM_PATIENT_INTERMEDIATE")
            .as[temp_icpm_patient_patientdetail_patientcontact]

    cdrFePatientIntermediate
      .filter($"rank_pat" === lit(1) && $"patientid".isNotNull)
      .select(
      $"patientid"
        ,$"medicalrecordnumber"
        ,$"groupid"
        ,$"datasrc"
        ,$"dob".as("dateofbirth")
        ,$"dod".as("dateofdeath")
        ,$"client_ds_id"
        ,lit(null).cast(DataTypes.StringType).as("facilityid")
        ,lit(null).cast(DataTypes.StringType).as("inactive_flag")
        ,lit(null).cast(DataTypes.StringType).as("grp_mpi")
        ,lit(null).cast(DataTypes.LongType).as("hgpid")
    )




  }

}
