package com.optum.oap.backend.etl.enrichment

import com.optum.oap.backend.loader.EnrichmentRunTimeVariables
import com.optum.oap.cdr.models.{int_claim_prov, map_prov_contact_type, prov_client_rel, zh_provider_contact}
import com.optum.oap.sparkdataloader.{RuntimeVariables, TableInfo, UserDefinedFunctionForDataLoader}
import org.apache.spark.sql.expressions.Window
import org.apache.spark.sql.functions.{col, lit, _}
import org.apache.spark.sql.types.DataTypes
import org.apache.spark.sql.{DataFrame, SparkSession}
import org.slf4j.LoggerFactory

object ICPM_ZH_PROVIDER_CONTACT extends TableInfo[zh_provider_contact] {

  private val log = LoggerFactory.getLogger(this.getClass)

  override def dependsOn = Set("INT_CLAIM_PROV", "MAP_PROV_CONTACT_TYPE")

  override def name = "ICPM_ZH_PROVIDER_CONTACT"

  override def createDataFrame(sparkSession: SparkSession,
                               loadedDependencies: Map[String, DataFrame],
                               udfMap: Map[String, UserDefinedFunctionForDataLoader],
                               runtimeVariables: RuntimeVariables): DataFrame = {
    import sparkSession.implicits._

    val intClaimProvDf = loadedDependencies("INT_CLAIM_PROV").as[int_claim_prov]
    val mapProvContactTypeDf = broadcast(loadedDependencies("MAP_PROV_CONTACT_TYPE").as[map_prov_contact_type])

    val updateDate = coalesce($"icp.update_dt", $"icp.eff_date")

    val intClaimProv = intClaimProvDf.as("icp")
      .where(updateDate.isNotNull && coalesce($"icp.prov_addr_1", $"icp.prov_addr_2",
        $"icp.prov_city", $"icp.prov_state_code", $"icp.prov_zip_code", $"icp.prov_email", $"icp.prov_phone").isNotNull)
      .join(mapProvContactTypeDf.as("mpc"), $"mpc.groupid" === $"icp.groupid", "left_outer")
      .select($"icp.groupid"
        , lit("int_claim_prov").as("datasrc")
        , $"client_ds_id"
        , updateDate.as("update_date")
        , lit("PROVIDER").as("local_contact_type")
        , $"icp.prov_id".as("local_provider_id")
        , $"icp.prov_addr_1".as("address_line1")
        , $"icp.prov_addr_2".as("address_line2")
        , $"icp.prov_city".as("city")
        , $"icp.Prov_Email".as("email_address")
        , $"mpc.hts_code".as("mapped_contact_type")
        , $"icp.prov_state_code".as("state")
        , $"icp.prov_phone".as("work_phone")
        , $"icp.prov_zip_code".as("zipcode")
        , $"icp.prov_addr_lat".as("address_latitude")
        , $"icp.prov_addr_lon".as("address_longitude")
        , lit(null).cast(DataTypes.StringType).as("master_hgprovid")
        , lit(null).cast(DataTypes.StringType).as("work_fax")
        , row_number().over(Window.partitionBy($"icp.prov_id", $"icp.client_ds_id")
          .orderBy($"icp.update_dt".desc_nulls_first, $"icp.end_date".desc_nulls_first, $"icp.eff_date".desc_nulls_last)).as("row_num")
      )

    intClaimProv.where($"row_num" === 1).drop("row_num")
  }
}