package com.optum.oap.backend.etl.patient_matching.data_table

import com.optum.oap.backend.cdrTempModel.pat_match_prep
import com.optum.oap.backend.etl.common._
import com.optum.oap.backend.etl.patient_matching.PATIENT_MPI_UTILS
import com.optum.oap.backend.loader.EnrichmentRunTimeVariables
import com.optum.oap.cdr.models._
import com.optum.oap.sparkdataloader.{RuntimeVariables, TableInfo, UserDefinedFunctionForDataLoader}
import org.apache.spark.sql.expressions.Window
import org.apache.spark.sql.functions._
import org.apache.spark.sql.types.{IntegerType, LongType, StringType}
import org.apache.spark.sql.{DataFrame, SparkSession}

object MPI_CUSTOM extends TableInfo[mpi_custom] {

  override def dependsOn = Set("PAT_MATCH_PREP", "PATIENTDETAIL_PREMATCH", "MAP_GENDER", "PATIENT_ID_PREMATCH", "ECDR_MPI_CUSTOM")

  override def name = "MPI_CUSTOM"

  override def createDataFrame(sparkSession: SparkSession,
                               loadedDependencies: Map[String, DataFrame],
                               udfMap: Map[String, UserDefinedFunctionForDataLoader],
                               runtimeVariables: RuntimeVariables): DataFrame = {
    import sparkSession.implicits._

    val tempPatMatchPrep = loadedDependencies("PAT_MATCH_PREP").as[pat_match_prep]
    val patientId = loadedDependencies("PATIENT_ID_PREMATCH").as[patient_id]
    val mapGender = broadcast(loadedDependencies("MAP_GENDER").as[map_gender])
    val patientDetail = loadedDependencies("PATIENTDETAIL_PREMATCH").distinct.as[patientdetail]

    val dailyBuild = if (runtimeVariables.asInstanceOf[EnrichmentRunTimeVariables].buildType == CDRConstants.DELTA_BUILD_TYPE) true else false



    /*
      select /*+ parallel(4) */ p.groupid,p.client_ds_id,p.patientid,p.hgpid
        ,dob as key_attr
        ,fname as attr_2
        ,lname as attr_3
        ,substr(fname,1,1) as attr_4
        ,substr(fname,1,3) as attr_5
        ,substr(fname,1,5) as attr_6
        ,mrn as attr_7
        ,mg.cui as attr_8
        ,ssn as attr_9
        ,substr(pz.localvalue,1,5) as attr_10
        ,substr(lname,1,1) as attr_11
        ,substr(lname,1,3) as attr_12
        ,count(distinct p.groupid) over (partition by dob) as group_cnt
        ,count(distinct p.hgpid) over (partition by dob) as hgpids
      from (
      select distinct ps.groupid,ps.client_ds_id,ps.patientid,ps.hgpid
          ,dob
          ,upper(fname) as first_name
          ,upper(lname) as last_name
          ,clean_name(fname) as fname
          ,clean_name(lname) as lname
      from temp_pat_attrs partition (P_GRPID) ps
      where dob is not null
      ) p
      left outer join (select distinct groupid,client_ds_id,patientid
                         ,trim(substr(replace(idvalue,'-'),1,9)) as ssn
          from temp_patient_id partition (P_GRPID) tpi
          where trim(substr(replace(idvalue,'-'),1,9)) not in (select ssn from cdr_common.bad_ssn)
              and idtype = 'SSN' and validate_ssn(idvalue) = 'Y'
      ) pid on (p.groupid = pid.groupid AND p.client_ds_id = pid.client_ds_id AND p.patientid = pid.patientid)
      left outer join (select distinct groupid,client_ds_id,patientid
                         ,trim(substr(replace(idvalue,'-'),1,9)) as mrn
          from temp_patient_id partition (P_GRPID) tpi
          where idtype = 'MRN'
      ) mrn on (p.groupid = mrn.groupid AND p.client_ds_id = mrn.client_ds_id AND p.patientid = mrn.patientid)
      left outer join temp_patientdetail partition (P_GRPID) pd on (p.client_ds_id = pd.client_ds_id AND p.patientid = pd.patientid AND pd.patientdetailtype = 'GENDER')
      left outer join map_gender mg on (pd.localvalue = mg.mnemonic AND pd.groupid = mg.groupid AND mg.cui in ('CH000034','CH000033'))
      left outer join temp_patientdetail partition (P_GRPID) pz on (p.client_ds_id = pz.client_ds_id AND p.patientid = pz.patientid AND pz.patientdetailtype = 'ZIPCODE')

     */
    val ps = tempPatMatchPrep
      .where($"dob".isNotNull)
      .select(
        $"groupid", $"client_ds_id", $"patientid", $"hgpid", $"dob",
        upper($"fname").as("first_name"),
        upper($"lname").as("last_name"),
        CleanPatientName.cleanPatientName($"fname", lit(3)).as("fname"),
        CleanPatientName.cleanPatientName($"lname", lit(3)).as("lname")
      ).distinct

    val pid = patientId.as("tpi")
      .where(!trim(substring(regexp_replace($"idvalue", "-", ""), 0, 9)).isin(PATIENT_MPI_UTILS.getBadSSNs: _*) &&
        $"idtype" === lit("SSN") && !SSNValidation.cleanAndValidate($"idvalue").isin(SSNValidation.INVALID_OUTCOMES: _*)
      )
      .select(
        $"groupid", $"client_ds_id", $"patientid",
        trim(substring(regexp_replace($"idvalue", "-", ""), 0, 9)).as("ssn")
      ).distinct

    val mrn = patientId.as("tpi")
      .where($"idtype" === lit("MRN"))
      .select(
        $"groupid", $"client_ds_id", $"patientid",
        substring(regexp_replace($"idvalue", "-", ""), 0, 9).as("mrn")
      ).distinct

    val dobGrouping = ps.as("t").
      groupBy($"dob")
      .agg(
        size(collect_set("hgpid")).as("hgpids")
      ).select(
      $"dob",
      $"hgpids"
    )

    val dataDf = ps.as("ps")
      .join(pid.as("pid"), Seq("groupid", "client_ds_id", "patientid"), "left_outer")
      .join(mrn.as("mrn"), Seq("groupid", "client_ds_id", "patientid"), "left_outer")
      .join(patientDetail.as("pd").where($"pd.patientdetailtype" === lit("GENDER")),
        Seq("groupid", "client_ds_id", "patientid"), "left_outer")
      .join(mapGender.as("mg").where($"mg.cui".isInCollection(CDRConstants.MALE_AND_FEMALE_CUIS)), $"pd.localvalue" === $"mg.mnemonic", "left")
      .join(patientDetail.as("pz").where($"pz.patientdetailtype" === lit("ZIPCODE")),
        Seq("groupid", "client_ds_id", "patientid"), "left_outer")
      .join(dobGrouping.as("dg"), Seq("dob"))
      .select(
        $"ps.groupid",
        $"ps.client_ds_id",
        $"ps.patientid",
        $"ps.hgpid",
        $"ps.dob".as("key_attr"),
        $"ps.fname".as("attr_2"),
        $"ps.lname".as("attr_3"),
        substring($"ps.fname", 1,1).as("attr_4"),
        substring($"ps.fname", 1,3).as("attr_5"),
        substring($"ps.fname", 1, 5).as("attr_6"),
        $"mrn".as("attr_7"),
        $"mg.cui".as("attr_8"),
        $"ssn".as("attr_9"),
        substring($"pz.localvalue", 1, 5).as("attr_10"),
        soundex($"ps.fname").as("attr_11"),
        substring($"ps.lname", 1, 3).as("attr_12"),
        lit(1).cast(IntegerType).as("group_cnt"),
        $"dg.hgpids".as("hgpids")
      )

    val ecdrDf = {
      if (dailyBuild) EnrichmentUtils.removeRowSourceAndModifiedDate(loadedDependencies("ECDR_MPI_CUSTOM")).as[mpi_custom]
      else sparkSession.emptyDataset[mpi_custom].as[mpi_custom]
    }.as("e")
      .select($"e.*")

    dataDf.unionByName(ecdrDf).distinct()
  }

}
