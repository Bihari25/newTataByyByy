package com.optum.oap.backend.loader

import com.optum.oap.backend.etl.common.CDRConstants
import com.optum.oap.cdr.models.{mpi_data_table, mpi_data_table_group, mpi_rule}
import com.optum.oap.sparkdataloader.{LoadFromHive, UserDefinedFunctionForDataLoader}
import org.apache.spark.sql.functions.{concat, lit, upper, when}
import org.apache.spark.sql.{DataFrame, Dataset, SparkSession}
import org.slf4j.LoggerFactory
import org.apache.spark.sql.types.IntegerType

import scala.util.parsing.json.JSON

object ClientConfiguration {
  def apply(clientId: String): ClientConfiguration = new ClientConfiguration(clientId, None)

  def apply(clientId: String, overrideConfig: String): ClientConfiguration = new ClientConfiguration(clientId, Some(overrideConfig))
}

class ClientConfiguration(clientId: String, overrideConfig: Option[String] = None) {
  private val clientConfigFile = "client_configuration.json"
  private val log = LoggerFactory.getLogger(this.getClass)

  val MPI_DATA_TABLE_GROUP = "mpi_data_table_group.csv"

  def loadConfigurationFromJSON: client_configuration = {

    log.warn(" === Loading configuration from internal JSON")
    val resPath = this.getClass.getClassLoader.getResourceAsStream(clientConfigFile)
    val clientConfigRaw = overrideConfig.getOrElse(scala.io.Source.fromInputStream(resPath).getLines.mkString("\n"))
    val parsedConfig = JSON.parseFull(clientConfigRaw)
    val clientToRawMap = parsedConfig.getOrElse(throw new IllegalStateException("Cannot parse JSON"))
      .asInstanceOf[Map[String, List[mpi_rule_config]]]
    val classyClientConfig = clientToRawMap.map(config => {
      val clientConfig = config._2.asInstanceOf[Map[String, Any]]
      val patMatchRules = clientConfig("pat_match_rules").asInstanceOf[Seq[Map[String, Any]]].map(rule => {
        mpi_rule_config(
          etlName = rule("etlName").asInstanceOf[String],
          ruleFieldNames = rule("ruleFieldNames").asInstanceOf[Seq[String]].toSet,
          uniqueFieldNames = rule("uniqueFieldNames").asInstanceOf[Seq[String]].toSet,
          active = rule("active").asInstanceOf[Boolean],
          ruleNbr = rule("rule_nbr").asInstanceOf[Double].toInt,
          score = rule("score").asInstanceOf[Double].toInt
        )
      }).filter(_.active) // only include active rules

      (config._1, client_configuration(pat_match_rules = patMatchRules))
    })

    val config = classyClientConfig.getOrElse(clientId, classyClientConfig("default"))

    log.warn("Configuration: " + config.toString)
    config
  }

  def loadMpiDataTableGroup(sparkSession: SparkSession) =  {
    import sparkSession.implicits._
    val resPath = this.getClass.getClassLoader.getResourceAsStream(MPI_DATA_TABLE_GROUP)
    val metadata = scala.io.Source.fromInputStream(resPath).getLines.toList.tail.map(line => line.split(",").map(_.trim))

    metadata
      .filter(cols => {
        cols.length == 4
      })
      .map(cols => {
      mpi_data_table_group(data_table_name = cols(0), data_table_sql = cols(1), groupid = cols(2))
    }).toDF()

  }

  def loadConfigurationFromCdrFe(sparkSession: SparkSession, runtimeVariables: EnrichmentRunTimeVariables): client_configuration = {
    import sparkSession.implicits._
    log.warn(" === Loading configuration from CDR FE configuration tables")
    try {
      val mpiRule = LoadFromHive[mpi_rule](tableName = "MPI_RULE", referenceName = None, hiveDatabase = runtimeVariables.cdrSchema, saveDataFrameToParquet = false)
        .createDataFrame(sparkSession, Map.empty[String, DataFrame], Map.empty[String, UserDefinedFunctionForDataLoader], runtimeVariables)
      val mpiDataTableGroup = loadMpiDataTableGroup(sparkSession)

      val configQuery = mpiRule.as("a")
        .join(mpiDataTableGroup.as("b"),
          $"b.groupid" === $"a.groupid" && $"a.rule_data_table" === $"b.data_table_name", "left"
        )
        .where($"a.groupid" === lit(runtimeVariables.clientId) && $"score" >= lit(CDRConstants.MPI_RULE_SCORE_MIN))
        .select(
          when($"b.data_table_name".isNotNull, upper(concat($"a.rule_data_table", lit("_"), $"a.groupid")))
            .otherwise(upper($"a.rule_data_table"))
            .as("etlName"),
          $"a.rule_fields".as("ruleFieldNames"),
          $"a.rule_nbr".as("rule_nbr"),
          $"a.score".as("score").cast(IntegerType),
          $"a.uniq_fields".as("uniqueFieldNames")
        ).distinct

      val configQueryCollected = configQuery.collect()

      val config = client_configuration(pat_match_rules = configQueryCollected.map(ruleRow => {
        val rules: Option[String] = Option(ruleRow.getAs[String]("ruleFieldNames"))
        val uniques: Option[String] = Option(ruleRow.getAs[String]("uniqueFieldNames"))

        mpi_rule_config(
          etlName = ruleRow.getAs[String]("etlName"),
          ruleFieldNames = rules.map(_.split(",").map(_.trim).toSet).getOrElse(Set.empty[String]),
          uniqueFieldNames = uniques.map(_.split(",").map(_.trim).toSet).getOrElse(Set.empty[String]),
          active = true,
          ruleNbr = ruleRow.getAs[Integer]("rule_nbr"),
          score = ruleRow.getAs[Integer]("score")
        )
      })
      )

      log.warn("Configuration: " + config.toString)
      config
    } catch {
      case e: Throwable => {
        e.printStackTrace
        val env = EnrichmentRunTimeVariables(runtimeVariables).environment
        log.warn("Unable to load ClientConfiguration from CDR FE resources. Falling back to Internal JSON based configuration instead:\n")
        if (env.equals("dev")) {
          // if prod only load from config tables. Later on , once we move all config out of oracle we can permanently read from external location
          // to fix QIT, continue loading from resource if environment is dev.
          loadConfigurationFromJSON
        } else throw e
      }
    }
  }
}

case class client_configuration(pat_match_rules: Seq[mpi_rule_config]) {
  override def toString: String = {
    "pat_match_rules: \n" + pat_match_rules.map(rule => {
      val ruleFields = if (rule.ruleFieldNames.isEmpty) "None" else rule.ruleFieldNames.mkString(", ")
      val uniqueFields = if (rule.uniqueFieldNames.isEmpty) "None" else rule.uniqueFieldNames.mkString(", ")
      s" ETL:${rule.etlName}: rule_fields:$ruleFields unique_fields:$uniqueFields\n"
    }
    ).mkString("")
  }
}

case class mpi_rule_config(ruleNbr: java.lang.Integer = null,
                           score: java.lang.Integer = null,
                           etlName: String, // name of the ETL to include in the query registry
                           ruleFieldNames: Set[String], // names of the fields to group by in the query
                           uniqueFieldNames: Set[String], // names of the fields to enforce uniqueness over for matching
                           active: Boolean) // when active, is applied, when inactive, is skipped, by configuration
