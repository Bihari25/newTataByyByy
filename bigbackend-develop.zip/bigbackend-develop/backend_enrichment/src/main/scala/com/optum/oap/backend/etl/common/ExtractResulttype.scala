package com.optum.oap.backend.etl.common

import com.optum.oap.sparkdataloader.UserDefinedFunctionForDataLoader
import org.apache.spark.sql.SparkSession
import org.apache.spark.sql.expressions.UserDefinedFunction
import org.apache.spark.sql.functions.udf

object ExtractResulttype extends UserDefinedFunctionForDataLoader {

  override def name: String = "extract_resulttype"

  val extract_resulttype: UserDefinedFunction = udf {

    p_txt: String => {

      /*
          Functions in Oracle can handle nulls as valid inputs, even if they primarily operate on a different datatype.
          Those types of functions return nulls if they get null inputs.
          But, Scala methods can't handle nulls this way, so to mimic this behaviour, handling NullPointerException
       */

      try {

        val v_txt = p_txt.toLowerCase

        if ("(posi| pos |^pos )".r.findFirstIn(v_txt).isDefined) "CH000651"
        else if ("neg".r.findFirstIn(v_txt).isDefined) "CH000652"
        else if ("moderat".r.findFirstIn(v_txt).isDefined) "CH000MOD"
        else if ("(wnl|^nl|^[ :;]?normal)".r.findFirstIn(v_txt).isDefined) "CH001203"
        else null

      }
      catch {

        case e: NullPointerException => "CH000654"
        case _: Exception => null

      }
    }
  }

  override def registerMe(sparkSession: SparkSession): Unit = {
    sparkSession.udf.register(name, extract_resulttype)
  }
}