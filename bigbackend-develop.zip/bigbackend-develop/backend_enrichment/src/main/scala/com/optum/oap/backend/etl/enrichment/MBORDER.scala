package com.optum.oap.backend.etl.enrichment

import com.optum.oap.backend.etl.common.{MapMasterIds, MatchRegExPattern}
import com.optum.oap.cdr.models.{mborder, patient_mpi, zcm_micro_proc_pattern, zcm_specimen_source_pattern}
import com.optum.oap.sparkdataloader.{RuntimeVariables, TableInfo, UserDefinedFunctionForDataLoader}
import org.apache.spark.sql.functions._
import org.apache.spark.sql.{DataFrame, SparkSession}
import org.slf4j.LoggerFactory

object MBORDER extends TableInfo[mborder] {

  val log = LoggerFactory.getLogger(this.getClass)

  override def dependsOn = Set("CDR_FE_MBORDER", "PATIENT_MPI", "CDR_FE_ZCM_MICRO_PROC_PATTERN", "CDR_FE_ZCM_SPECIMEN_SOURCE_PATTERN")

  override def name = "MBORDER"

  override def ignoreExtraColumnsInDataFrame: Boolean = true

  override def createDataFrame(sparkSession: SparkSession,
                               loadedDependencies: Map[String, DataFrame],
                               udfMap: Map[String, UserDefinedFunctionForDataLoader],
                               runtimeVariables: RuntimeVariables): DataFrame = {
    import sparkSession.implicits._

    val mborderIn = loadedDependencies("CDR_FE_MBORDER").as[mborder]
    val patXref = loadedDependencies("PATIENT_MPI").as[patient_mpi]
    val zcmMicroProcMap = broadcast(loadedDependencies("CDR_FE_ZCM_MICRO_PROC_PATTERN").as[zcm_micro_proc_pattern])
    val zcmSpecimenSourceMap = broadcast(loadedDependencies("CDR_FE_ZCM_SPECIMEN_SOURCE_PATTERN").as[zcm_specimen_source_pattern])

    //collect the distinct values in the 3 possible fields
    val specNames = mborderIn.filter("localspecimenname IS NOT NULL")
      .select("localspecimenname").distinct
    val specSources = mborderIn.filter("localspecimensource IS NOT NULL")
      .select("localspecimensource").distinct
    val orderDescs = mborderIn.filter("localorderdesc IS NOT NULL")
      .select("localorderdesc").distinct

    //convert the maps to arrays of regex pattern/cui pairs
    val mbSpecSrcMap = zcmSpecimenSourceMap.select("groupid", "priority", "txt_pattern", "cui")
      .agg(collect_list(struct($"txt_pattern", $"cui", $"priority", $"groupid")).as("entries"))
      .as[GroupEntries]

    val mbProcSrcMap = zcmMicroProcMap.select("groupid", "priority", "txt_pattern", "cui")
      .agg(collect_list(struct($"txt_pattern", $"cui", $"priority", $"groupid")).as("entries")).as[GroupEntries]

    //Match the distinct values using the regex patterns, returning the corresponding cui
    val nameMap = specNames.crossJoin(mbSpecSrcMap)
      .withColumn("mapped_localspecimenname", MatchRegExPattern.matchRegExPattern($"localspecimenname", $"entries"))
      .filter("mapped_localspecimenname is not null")
      .select($"localspecimenname".as("map_localspecimenname"), $"mapped_localspecimenname")
    val sourceMap = specSources.crossJoin(mbSpecSrcMap)
      .withColumn("mapped_localspecimensource", MatchRegExPattern.matchRegExPattern($"localspecimensource", $"entries"))
      .filter("mapped_localspecimensource is not null")
      .select($"localspecimensource".as("map_localspecimensource"), $"mapped_localspecimensource")
    val descMap = orderDescs.crossJoin(mbSpecSrcMap)
      .withColumn("mapped_localorderdesc", MatchRegExPattern.matchRegExPattern($"localorderdesc", $"entries"))
      .filter("mapped_localorderdesc is not null")
      .select($"localorderdesc".as("map_localorderdesc"), $"mapped_localorderdesc")

    val mbProcDescMap = orderDescs.crossJoin(mbProcSrcMap)
      .withColumn("mapped_proclocalorderdesc", MatchRegExPattern.matchRegExPattern($"localorderdesc", $"entries"))
      .select($"localorderdesc".as("map_proclocalorderdesc"), $"mapped_proclocalorderdesc")

    val mbWithMapSpecSrc = mborderIn.drop("hts_specimen_source")
      .join(nameMap, $"localspecimenname" <=> $"map_localspecimenname", "left_outer")
      .join(sourceMap, $"localspecimensource" <=> $"map_localspecimensource", "left_outer")
      .join(descMap, $"localorderdesc" <=> $"map_localorderdesc", "left_outer")
      .join(mbProcDescMap, $"localorderdesc" <=> $"map_proclocalorderdesc", "left_outer")
      .withColumn("hts_specimen_source", coalesce($"mapped_localspecimenname", $"mapped_localspecimensource", $"mapped_localorderdesc"))
      .withColumn("hts_micro_proc", $"mapped_proclocalorderdesc")
      .withColumn("mborder_date", coalesce($"dateordered", $"datecollected", $"datereceived"))
      .drop("map_localspecimensource", "mapped_localspecimensource", "map_localspecimenname", "mapped_localspecimenname", "map_localorderdesc", "mapped_localorderdesc", "map_proclocalorderdesc", "mapped_proclocalorderdesc")

    MapMasterIds.mapPatientIds(mbWithMapSpecSrc.toDF, patXref.toDF, false)
  }


}
