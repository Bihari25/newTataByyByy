package com.optum.oap.backend.etl.bpo.bpo_pyr_hedis_qme

import com.optum.oap.backend.cdrTempModel.{hedis_monthly_enr_extract_qme, hedis_monthly_phm_extract_qme}
import com.optum.oap.cdr.models.{denied_ind_rollup, pp_bpo_member_detail, pp_bpo_pharmacy_claims, pp_bpo_provider_detail}
import com.optum.oap.sparkdataloader.{RuntimeVariables, TableInfo, UserDefinedFunctionForDataLoader}
import org.apache.spark.sql.types.IntegerType
import org.apache.spark.sql.functions._
import org.apache.spark.sql.types.StringType
import org.apache.spark.sql.{DataFrame, SparkSession}

object HEDIS_MONTHLY_PHM_EXTRACT_QME extends TableInfo[hedis_monthly_phm_extract_qme] {

  override def dependsOn: Set[String] = Set("PP_BPO_MEMBER_DETAIL","DENIED_IND_ROLLUP","PP_BPO_PHARMACY_CLAIMS","PP_BPO_PROVIDER_DETAIL")

  override def name = "HEDIS_MONTHLY_PHM_EXTRACT_QME"

  override def createDataFrame(sparkSession: SparkSession,
                               loadedDependencies: Map[String, DataFrame],
                               udfMap: Map[String, UserDefinedFunctionForDataLoader],
                               runtimeVariables: RuntimeVariables): DataFrame = {

      import sparkSession.implicits._

      val denied_ind_rollup = broadcast(loadedDependencies("DENIED_IND_ROLLUP")).as[denied_ind_rollup]
      val hedis_patients = loadedDependencies("PP_BPO_MEMBER_DETAIL").as[pp_bpo_member_detail]
      val pp_bpo_pharmacy_claims = loadedDependencies("PP_BPO_PHARMACY_CLAIMS").as[pp_bpo_pharmacy_claims]
      val pp_bpo_provider_detail = loadedDependencies("PP_BPO_PROVIDER_DETAIL").as[pp_bpo_provider_detail]

      val denied = denied_ind_rollup.groupBy($"groupid", $"denied_flag").agg(max($"denied_ind_rollup").as("denied_ind_rollup")).select($"denied_flag", $"denied_ind_rollup").dropDuplicates(Seq("denied_flag"))

      val hedis_patients_final= hedis_patients.where($"lineofbusinessid".isNotNull && $"healthplansource" === lit("PAYER")).select($"memberid").distinct

     pp_bpo_pharmacy_claims.alias("pc").join(hedis_patients_final.as("hp"), $"pc.MEMBERID" === $"hp.MEMBERID", "inner").join(denied.as("dr"), $"pc.DENIEDFLAG" === $"dr.DENIED_FLAG", "left").join( pp_bpo_provider_detail.as("bpd1"),$"pc.PRESCPROVIDER" === $"bpd1.PROVIDERID","left").join( pp_bpo_provider_detail.as("bpd2"),$"pc.PHARMACYID" === $"bpd2.PROVIDERID","left").where($"pc.healthplansource" === lit("PAYER")).select(
          $"pc.MEMBERID".as("MemberID"),
          $"CLAIMHEADER".as("ClaimHeaderID"),
          date_format($"SERVICEDATE", "yyyy-MM-dd").cast(StringType).as("ServiceDate"),
          $"NDC".as("NationalDrugCode"),
          $"DAYSSUPPLY".cast(StringType).as("DaysSupply"),
          $"pc.HEALTHPLANSOURCE".as("HealthPlanSource"),
          when(coalesce($"dr.DENIED_IND_ROLLUP", $"pc.DENIEDFLAG").isin("Y","Yes","YES","1"), lit("Y")).otherwise(lit("N")).as("IsDenied"),
          $"PRESCPROVIDER".as("PrescribingProviderID"),
          $"pc.DEA".as("DEANumber"),
          $"pc.MAPSOURCE".as("MapSource"),
          $"QUANTITY_DISPENSED".cast(StringType).as("QuantityDispensed"),
          $"bpd1.NPI".as("ProviderNPI"),
          $"bpd2.NPI".as("PharmacyNPI"),
          $"QUANTITY".cast(StringType).as("MetricQuantity")
      )
  }

}
