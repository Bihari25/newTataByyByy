package com.optum.oap.backend.etl.encgrps

import com.optum.oap.backend.cdrTempModel.temp_enc_grp_eprv
import com.optum.oap.sparkdataloader.QueryAndMetadata


object TEMP_ENC_GRP_EPRV extends QueryAndMetadata[temp_enc_grp_eprv] {
  override def name: String = "TEMP_ENC_GRP_EPRV"

  override def sparkSql: String =
    """select  *
from
(select  eeg.groupid, eeg.encounter_grp_num
, row_number() over (partition by eeg.ENCOUNTER_GRP_NUM
order by datasrc_excl
,case when eeg.ENCOUNTERIDTYPE in ('MASTER','ENCTR') then 1 else 2 end
,case when eeg.patienttype in ('CH000106','CH000107','CH000109','CH000113','CH000795','CH003031','CH003032') and ii_code < '200' then 1
when eeg.patienttype in ('CH000106','CH000107','CH000109','CH000113','CH000795','CH003031','CH003032') and entity_type_code = '2' then 2
when eeg.patienttype not in ('CH000106','CH000107','CH000109','CH000113','CH000795','CH003031','CH003032') and ii_code >= '200' then 3
when eeg.patienttype not in ('CH000106','CH000107','CH000109','CH000113','CH000795','CH003031','CH003032') and entity_type_code <> '2' then 4
else 99 end
,case when providerrole = 'CH001413' then 1  --visit provider
when providerrole = 'CH001417' then 2  --performing provider
when providerrole = 'CH001418' then 3  --billing provider
else 99 end
, min_prov_dtm
, prov_id
) as provrank
,prov.prov_id  as event_prov_id
from ENCOUNTER_ENCOUNTER_GRP  eeg
inner join temp_eeg_prov prov on (prov.groupid = eeg.groupid and prov.encounterid = eeg.encounterid and prov.client_ds_id = eeg.client_ds_id)
)
where provrank = 1"""

  override def dependsOn: Set[String] = Set("ENCOUNTER_ENCOUNTER_GRP", "TEMP_EEG_PROV")
}
