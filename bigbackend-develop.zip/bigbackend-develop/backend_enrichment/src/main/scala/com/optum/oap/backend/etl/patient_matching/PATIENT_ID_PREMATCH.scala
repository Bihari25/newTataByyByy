package com.optum.oap.backend.etl.patient_matching

import com.optum.oap.cdr.models.{patient, patient_id}
import com.optum.oap.sparkdataloader.{RuntimeVariables, TableInfo, UserDefinedFunctionForDataLoader}
import org.apache.spark.sql.functions.{lit, regexp_replace}
import org.apache.spark.sql.types.{IntegerType, StringType}
import org.apache.spark.sql.{DataFrame, SparkSession}

/**
  * Creator: bishu
  * Date: 10/21/20
  */
object PATIENT_ID_PREMATCH extends TableInfo[patient_id] {

  override def dependsOn = Set("PATIENT_ID_XWALK_MAPPING", "PATIENT_XWALK_MAPPING")


  override def createDataFrame(sparkSession: SparkSession,
                               loadedDependencies: Map[String, DataFrame],
                               udfMap: Map[String, UserDefinedFunctionForDataLoader],
                               runtimeVariables: RuntimeVariables): DataFrame = {
    import sparkSession.implicits._

    val patient_idIn = loadedDependencies("PATIENT_ID_XWALK_MAPPING").as[patient_id]
    val patient_DF = loadedDependencies("PATIENT_XWALK_MAPPING").as[patient]

    val df1 = patient_DF.as("a")
      .join(patient_idIn.as("ex"),
        $"a.client_ds_id" === $"ex.client_ds_id" &&
          $"a.patientid" === $"ex.patientid" &&
          $"ex.idtype" === lit("MRN") &&
          $"ex.datasrc" === lit("CDR") &&
          $"a.medicalrecordnumber" === $"ex.idvalue",
        "left_outer"
      )
      .where($"a.medicalrecordnumber".isNotNull)
      .where($"ex.patientid".isNull)
      .where($"a.inactive_flag" === lit("N") || $"a.inactive_flag" === lit("F") || $"a.inactive_flag".isNull)
      .select(
        $"a.groupid",
        $"a.client_ds_id",
        $"a.patientid",
        lit("CDR").as("datasrc"),
        lit("MRN").as("idtype"),
        $"a.medicalrecordnumber".as("idvalue"),
        $"a.hgpid",
        $"a.grp_mpi"
      )

    val df2 = patient_DF.as("a")
      .join(patient_idIn.as("ex"),
        $"a.client_ds_id" === $"ex.client_ds_id" &&
          $"a.patientid" === $"ex.patientid" &&
          $"ex.idtype" === lit("PATID") &&
          $"ex.datasrc" === lit("CDR") &&
          $"a.patientid" === $"ex.idvalue",
        "left_outer"
      ).select(
      $"a.groupid",
      $"a.client_ds_id",
      $"a.patientid",
      lit("CDR").as("datasrc"),
      lit("PATID").as("idtype"),
      $"a.patientid".as("idvalue"),
      $"a.hgpid",
      $"a.grp_mpi"
    )
      .where($"ex.patientid".isNull)
      .where($"a.inactive_flag" === lit("N") || $"a.inactive_flag" === lit("F") || $"a.inactive_flag".isNull)

    val regex = "\\t|\\n|\\r|\\f|\\b"
    val unionDf = df1.union(df2)
    val patient_idOut = unionDf.select(
      $"groupid",
      $"client_ds_id",
      $"patientid",
      $"datasrc",
      $"idtype",
      regexp_replace($"idvalue", regex, "").as("idvalue"),
      $"hgpid",
      lit(null).cast(StringType).as("id_subtype"),
      $"grp_mpi"
    )

    val patient_id_initial_DF = patient_idIn.select(
      $"groupid",
      $"client_ds_id",
      $"patientid",
      $"datasrc",
      $"idtype",
      $"idvalue",
      $"hgpid",
      $"id_subtype",
      $"grp_mpi"
    )

    // union final result with original value in FE
    val result_Df = patient_idOut.union(patient_id_initial_DF)
      .select(
        $"groupid",
        $"client_ds_id".cast(IntegerType),
        $"patientid",
        $"datasrc",
        $"idtype",
        $"idvalue",
        $"hgpid",
        $"id_subtype",
        $"grp_mpi"
      )
    result_Df
  }
}
