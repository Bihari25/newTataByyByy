package com.optum.oap.backend.etl.summary

import com.optum.oap.cdr.models.{patient_count, patient_summary_grp_mpi, zip3_pat_cnt}
import com.optum.oap.sparkdataloader.{RuntimeVariables, TableInfo, UserDefinedFunctionForDataLoader}
import org.apache.spark.sql.functions._
import org.apache.spark.sql.types.IntegerType
import org.apache.spark.sql.{DataFrame, SparkSession}
import org.slf4j.LoggerFactory

object ZIP3_PAT_CNT extends TableInfo[zip3_pat_cnt] {

  val log = LoggerFactory.getLogger( this.getClass )

  override def dependsOn = Set( "PATIENT_COUNT", "PATIENT_SUMMARY_GRP_MPI" )

  override def name = "ZIP3_PAT_CNT"

  override def saveDataFrameToParquet: Boolean = true

  override def partitions: Int = 32

  override def skipTable: Boolean = false

  override def ignoreExtraColumnsInDataFrame: Boolean = false

  override def createDataFrame( sparkSession: SparkSession,
                                loadedDependencies: Map[String, DataFrame],
                                udfMap: Map[String, UserDefinedFunctionForDataLoader],
                                runtimeVariables: RuntimeVariables ): DataFrame = {

    import sparkSession.implicits._

    val pat_count = loadedDependencies( "PATIENT_COUNT" ).as[patient_count]
      .filter( 'year >= 2005 )
      .select( 'groupid, 'grp_mpi )

    val pat_summary = loadedDependencies( "PATIENT_SUMMARY_GRP_MPI" ).as[patient_summary_grp_mpi]
      .select(
        'groupid
        , 'grp_mpi
        , substring( 'mapped_zipcode, 1, 3 ).alias( "zip3" )
      )

    pat_count.join( pat_summary, Seq( "groupid", "grp_mpi" ), "inner" )
      .groupBy( 'groupid, 'zip3 )
      .agg(
        countDistinct( concat( 'groupid, 'grp_mpi ) ).cast( IntegerType ).alias( "pat_count" )
      )
      .select(
        'groupid, 'zip3, 'pat_count
      )
  }
}
