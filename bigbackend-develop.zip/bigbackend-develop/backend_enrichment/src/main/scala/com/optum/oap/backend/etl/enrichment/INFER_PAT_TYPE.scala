package com.optum.oap.backend.etl.enrichment

import com.optum.oap.backend.cdrTempModel.infer_pat_type
import com.optum.oap.backend.etl.common.Functions
import com.optum.oap.cdr.models.{map_pat_type_order, pat_type_evidence}
import com.optum.oap.sparkdataloader.{RuntimeVariables, TableInfo, UserDefinedFunctionForDataLoader}
import org.apache.spark.sql.expressions.Window
import org.apache.spark.sql.{DataFrame, SparkSession}
import org.apache.spark.sql.functions._

object INFER_PAT_TYPE extends TableInfo[infer_pat_type] {

  override def name: String = "INFER_PAT_TYPE"

  override def dependsOn: Set[String] = Set("MAP_PAT_TYPE_ORDER", "PAT_TYPE_EVIDENCE")

  override protected def createDataFrame(sparkSession: SparkSession, loadedDependencies: Map[String, DataFrame],
                                         udfMap: Map[String, UserDefinedFunctionForDataLoader], runtimeVariables: RuntimeVariables): DataFrame = {

    import sparkSession.implicits._
    val mapPatTypeOrder = broadcast(loadedDependencies("MAP_PAT_TYPE_ORDER")).as[map_pat_type_order]
    val inference = loadedDependencies("PAT_TYPE_EVIDENCE").as[pat_type_evidence]

    val window = Window.orderBy($"pto.pat_type_order").partitionBy( $"pte.groupid",$"pte.client_ds_id",$"pte.encounterid")

    val base = inference.as("pte")
      .join(mapPatTypeOrder.as("pto"), $"pte.pat_type_cui" === $"pto.pat_type_cui")

    val counts = base
      .groupBy($"pte.groupid",$"pte.client_ds_id",$"pte.encounterid")
        .agg(countDistinct($"pto.pat_type_cui").as("pto_cui_cnt"))

    val tempPtypeInfer = base
      .withColumn("rank", dense_rank().over(window))
      .where($"rank" === 1)
      .groupBy($"pto.pat_type_order", $"pte.groupid",$"pte.client_ds_id",$"pte.encounterid", $"pto.pat_type_cui")
      .agg(
        min($"pto.pat_type_cui").as("inferred_ptype"),
        min($"pto.pat_type_order").as("inferred_order"),
          $"groupid",
          $"client_ds_id",
          $"encounterid"
      )
      .join(counts.as("c"), Seq("groupid", "client_ds_id", "encounterid"))

    val cols = Functions.selectColsFromCaseClass[infer_pat_type]

    tempPtypeInfer.select(cols.head, cols.tail: _*)
  }
}
