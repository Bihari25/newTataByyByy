package com.optum.oap.backend.etl.common

import com.optum.oap.backend.loader.EnrichmentRunTimeVariables
import com.optum.oap.sparkdataloader.RuntimeVariables
import org.apache.spark.sql._
import org.apache.spark.sql.functions.{concat, substring_index, _}
import org.apache.spark.sql.types.{LongType, StructField, StructType}
import org.slf4j.LoggerFactory

class XrefUtil extends PartitionedDataOperations {

  val log = LoggerFactory.getLogger(this.getClass)

  /**
    *
    * @param df Dataframe on which needs the increasing ids
    * @param maxId The Id to start with
    * @param withoutPrefixCol The Colum wihtout the prefix of groupid
    * @param withPrefixCol the actual column name
    * @param lpadLength lenght of to lpad the id
    * @return Returns the dataframe after generating the id and prepending it with the groupid and lpadding with the provided length
    */
  def generateXrefIds(df: DataFrame, maxId: Long, withoutPrefixCol: Column, withPrefixCol: String, lpadLength: Int)(implicit sparkSession: SparkSession): DataFrame = {
    import sparkSession.implicits._
    val newSchema = StructType(df.schema.fields ++ Array(StructField(withoutPrefixCol.toString(), LongType, nullable = false)))
    val rddWithId = df.rdd.zipWithIndex
    val withRowNumberDf = sparkSession.createDataFrame(rddWithId.map { case (row, index) => Row.fromSeq(row.toSeq ++ Array(index + maxId + 1)) }, newSchema)
      .withColumn(withPrefixCol, concat(substring_index($"groupid", "H", -1), lpad(withoutPrefixCol, lpadLength, "0")).cast(LongType))

    withRowNumberDf
  }

  /**
    *
    * @param loadedDf The df to get the exisitng maxId
    * @param newDf The df with the new records
    * @param withoutPrefixCol The Colum wihtout the prefix of groupid
    * @param withPrefixCol The actual column name
    * @param runtimeVariables runtimeVariables
    * @param tableName Name of the Table where the new records will be inserted. for eg PROVDER_XREF
    * @return
    */
  def writeNewXrefRecords(loadedDf: DataFrame, newDf: DataFrame, withoutPrefixCol: Column, withPrefixCol: String, runtimeVariables: RuntimeVariables, tableName: String, partitionSize: Int)(implicit sparkSession: SparkSession) : DataFrame = {

      log.warn(s"There are new records to write to $tableName")
      val schema = EnrichmentRunTimeVariables(runtimeVariables).cdrSchema
      val commonPath = EnrichmentRunTimeVariables(runtimeVariables).commonPath
      val maxIdDf = loadedDf.select(max(withoutPrefixCol))
      val curMaxXrefId = if (!maxIdDf.first().isNullAt(0)) maxIdDf.first().getLong(0)  else 0

      val withRowNumberDf = generateXrefIds(newDf, curMaxXrefId, withoutPrefixCol, withPrefixCol, getLpadLength(tableName))

      recoverPartitions(schema, tableName)
      val latestXref = loadData(schema, tableName)
      val latestMaxXrefDf = latestXref.select(max(withoutPrefixCol))
      val latestMaxXrefId = if (!latestMaxXrefDf.first().isNullAt(0)) maxIdDf.first().getLong(0)  else 0
      if (curMaxXrefId != latestMaxXrefId) {
        throw XRefMaxIdMismatchException(s"The $tableName is updated with another build/process, please try again")
      } else {
        log.warn(s"Writing $tableName to location: $commonPath/$tableName Partition $partitionSize")
        writeData(withRowNumberDf, s"$commonPath/$tableName", Some(partitionSize))
        recoverPartitions(schema, tableName)
        withRowNumberDf
      }
  }

  /**
    *
    * @param xRef The xRef records will need to be written Initially
    * @param runtimeVariables runtimeVariables
    * @param tableName Name of the Table where the new records will be inserted. for eg PROVDER_XREF
    * @return returns the dataframe that's just written by loading it from the hive again.
    */
  def writeInitialXrefData(xRef: DataFrame, runtimeVariables: RuntimeVariables, tableName: String)(implicit sparkSession: SparkSession): DataFrame = {
    log.warn(s"$tableName Table is empty Initially at common location")
    val schema = EnrichmentRunTimeVariables(runtimeVariables).cdrSchema
    val commonPath = EnrichmentRunTimeVariables(runtimeVariables).commonPath

    log.warn(s"Writing $tableName to location: $commonPath/$tableName")
    writeData(xRef, s"$commonPath/$tableName")
    log.warn(s" Writing INITIAL $tableName Table to $commonPath/$tableName is completed")
    recoverPartitions(schema, tableName)
    log.warn(s"Loading $schema.$tableName from Hive")
    loadData(schema, tableName)

  }

  def getLpadLength(tableName: String): Int = {
    tableName match {
      case "PROVIDER_XREF" => 9
      case "FACILITY_XREF" => 9
      case "PATIENT_XREF" => 11
      case _ => throw new IllegalArgumentException(s"Invalid TABLE NAME!")
    }
  }

  final case class XRefMaxIdMismatchException(message: String = "", exception: Throwable = null) extends Exception(message)

}

