package com.optum.oap.backend.etl.enrichment

import com.optum.oap.backend.loader.EnrichmentRunTimeVariables
import com.optum.oap.cdr.models.{int_claim_prov, prov_affil}
import com.optum.oap.sparkdataloader.{RuntimeVariables, TableInfo, UserDefinedFunctionForDataLoader}
import org.apache.spark.sql.expressions.Window
import org.apache.spark.sql.{DataFrame, SparkSession}
import org.slf4j.LoggerFactory
import org.apache.spark.sql.functions.{first, upper, _}
import org.apache.spark.sql.types.DataTypes

object ICPM_PROV_AFFIL extends TableInfo[prov_affil] {

  private val log = LoggerFactory.getLogger(this.getClass)

  override def dependsOn = Set("INT_CLAIM_PROV")

  override def name = "ICPM_PROV_AFFIL"

  override def createDataFrame(sparkSession: SparkSession,
                               loadedDependencies: Map[String, DataFrame],
                               udfMap: Map[String, UserDefinedFunctionForDataLoader],
                               runtimeVariables: RuntimeVariables): DataFrame = {

    import sparkSession.implicits._

    val cdrFeIntClaimProv = loadedDependencies("INT_CLAIM_PROV").as[int_claim_prov]

    val groupId = runtimeVariables.asInstanceOf[EnrichmentRunTimeVariables].clientId

    cdrFeIntClaimProv
        .filter($"prov_affil_id".isNotNull)
      .select($"client_ds_id"
        , lit("int_claim_prov").as("datasrc")
        , $"eff_date"
        , $"end_date"
        , lit(groupId).as("groupid")
        , $"prov_id".as("localproviderid")
        , lit(null).cast(DataTypes.StringType).as("master_hgprovid")
        , $"prov_affil_id"
        , upper(first("primary_span", true).over(Window.partitionBy($"client_ds_id", $"eff_date", $"end_date", $"prov_id", $"prov_affil_id").orderBy($"primary_span".desc_nulls_last))).as("primary_span")
        ).distinct()
  }

}
