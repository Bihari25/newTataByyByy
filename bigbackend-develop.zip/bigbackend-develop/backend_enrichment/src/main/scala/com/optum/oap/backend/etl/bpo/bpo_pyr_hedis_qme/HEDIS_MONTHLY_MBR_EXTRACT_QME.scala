package com.optum.oap.backend.etl.bpo.bpo_pyr_hedis_qme

import com.optum.oap.backend.cdrTempModel.{hedis_monthly_ecd_extract_qme, hedis_monthly_mbr_extract_qme}
import com.optum.oap.cdr.models.{pp_bpo_clinical_documentation, pp_bpo_member_detail, pp_bpo_pharmacy_clinical}
import com.optum.oap.sparkdataloader.{RuntimeVariables, TableInfo, UserDefinedFunctionForDataLoader}
import org.apache.spark.sql.functions._
import org.apache.spark.sql.types.StringType
import org.apache.spark.sql.{DataFrame, SparkSession}

object HEDIS_MONTHLY_MBR_EXTRACT_QME extends TableInfo[hedis_monthly_mbr_extract_qme] {

  override def dependsOn: Set[String] = Set("PP_BPO_MEMBER_DETAIL")

  override def name = "HEDIS_MONTHLY_MBR_EXTRACT_QME"

  override def createDataFrame(sparkSession: SparkSession,
                               loadedDependencies: Map[String, DataFrame],
                               udfMap: Map[String, UserDefinedFunctionForDataLoader],
                               runtimeVariables: RuntimeVariables): DataFrame = {

      import sparkSession.implicits._

      val pp_bpo_member_detail = loadedDependencies("PP_BPO_MEMBER_DETAIL").as[pp_bpo_member_detail]

      pp_bpo_member_detail.where($"lineofbusinessid".isNotNull && $"healthplansource" === lit("PAYER")).select(
          $"memberid".as("MemberID"),
          date_format($"DOB",  "yyyy-MM-dd").cast(StringType).as("DateofBirth"),
          $"GENDER".as("GenderCode"),
          $"FIRSTNAME".as("FirstName"),
          lit(null).cast(StringType).as("MiddleName") ,
          $"LASTNAME".as("LastName"),
          $"ADDRESS1".as("AddressLine1"),
          $"ADDRESS2".as("AddressLine2"),
          $"CITY".as("City"),
          $"STATE".as("StateCode"),
          $"ZIPCODE".as("ZipCode"),
          $"PHONE".as("PhoneNumber"),
          $"EMAIL".as("Email"),
          $"COUNTY".as("CountyName"),
          $"GUARDIAN_FIRST_NAME".as("GuardianFirstName"),
          $"GUARDIAN_MIDDLE_NAME".as("GuardianMiddleName"),
          $"GUARDIAN_LAST_NAME".as("GuardianLastName"),
          $"RACE".cast(StringType).as("RaceCode"),
          $"RACE_DATASRC".as("RaceDataSourceCode"),
          $"ETHNICITY".cast(StringType).as("EthnicityCode"),
          $"ETHNICITY_DATASRC".as("EthnicityDataSourceCode"),
          $"SPOKEN_LANGUAGE".as("SpokenLanguageCode"),
          $"SPOKEN_LANGUAGE_DATASRC".as("SpokenLanguageDataSourceCode"),
          $"WRITTEN_LANGUAGE".as("WrittenLanguageCode"),
          $"WRITTEN_LANGUAGE_DATASRC".as("WrittenLanguageDataSourceCode"),
          $"OTHER_LANGUAGE".as("OtherLanguageCode"),
          $"OTHER_LANGUAGE_DATASRC".as("OtherLanguageDataSourceCode"),
          $"MEMBER_REGION".as("Region"),
          date_format($"DATE_OF_DEATH",  "yyyy-MM-dd").cast(StringType).as("DateofDeath"),
          $"DECEASED_FLAG".as("IsDeceased"),
          lit(null).cast(StringType).as("MEMUserDefined_1"),
          lit(null).cast(StringType).as("MEMUserDefined_2"),
          lit(null).cast(StringType).as("MEMUserDefined_3")
      ).dropDuplicates(Seq("MEMBERID"))

  }

}
