package com.optum.oap.backend.etl.bpo

import java.sql.Timestamp

import com.optum.oap.backend.cdrTempModel.{temp_bpo_calculate_params, temp_bpo_insurance}
import com.optum.oap.backend.etl.common.CDRConstants
import com.optum.oap.backend.etl.common.Functions.nullTo0
import org.apache.spark.sql.functions._
import org.apache.spark.sql.types.{StringType, TimestampType}
import org.apache.spark.sql.{DataFrame, Dataset, SparkSession}

import scala.util.Try

/**
  *
  * Copyright 2019 Optum Analytics
  *
  * Date: 6/6/19
  *
  * Creator: pavula1
  */
object BpoUtil {

  def getBpoInputParameters(sparkSession: SparkSession, df: Dataset[temp_bpo_calculate_params]): temp_bpo_calculate_params = {
    import sparkSession.implicits._

    val inputParameters = df.select($"engineStartDate", $"engineStartDate2", $"engineStartDate3", $"engineEndDate", $"startDate").as[temp_bpo_calculate_params]

    if (inputParameters.count() >= 1) {
      inputParameters.first()
    } else {
      temp_bpo_calculate_params() //This should not be the case but had to add this to satisfy integration test.
    }

  }

  // this is the MATCH_RECOGNIZE
  // the base case is an empty window (Option.empty) and no finished windows (Seq.empty)
  // as we iterate through the ordered list, use the window to compare to the current and put finished windows into the list
  def windowForMatch(sortedByMemberStart: Seq[temp_bpo_insurance], checkEmp: Boolean): Seq[temp_bpo_insurance] = {
    val windowed = sortedByMemberStart.foldLeft((Option.empty[temp_bpo_insurance], Seq.empty[temp_bpo_insurance])) {
      case ((prevOption, finished), current) =>

        if (prevOption.isEmpty) {
          // first record, just use everything in current
          (Some(current), finished)

        } else {
          // there is an existing window, determine if current belongs in it
          val prev = prevOption.get

          // uses lazy to avoid computation if all the previous comparisons don't match
          lazy val compareMemberEnd = Timestamp.valueOf(prev.member_end.toLocalDateTime.plusDays(1))

          if (
            (!checkEmp || nullTo0(current.employeraccountid) == nullTo0(prev.employeraccountid)) &&
              nullTo0(current.pcpid) == nullTo0(prev.pcpid) &&
              nullTo0(current.pharmacy) == nullTo0(prev.pharmacy) &&
              nullTo0(current.contract_id) == nullTo0(prev.contract_id) &&
              nullTo0(current.coverage_status) == nullTo0(prev.coverage_status) &&
              nullTo0(current.emp_acct_id) == nullTo0(prev.emp_acct_id) &&
              nullTo0(current.contracttype) == nullTo0(prev.contracttype) &&
              nullTo0(current.benefitplan) == nullTo0(prev.benefitplan) &&
              nullTo0(current.subscriberid) == nullTo0(prev.subscriberid) &&
              nullTo0(current.subscriberflag) == nullTo0(prev.subscriberflag) &&
              nullTo0(current.at_risk_status) == nullTo0(prev.at_risk_status) &&
              nullTo0(current.product_dtl_code) == nullTo0(prev.product_dtl_code) &&
              nullTo0(current.employee_type) == nullTo0(prev.employee_type) &&
              nullTo0(Try(current.lineofbusinessid.toString).getOrElse("0")) == nullTo0(Try(prev.lineofbusinessid.toString).getOrElse("0")) &&
              nullTo0(current.pcp_affil) == nullTo0(prev.pcp_affil) &&
              nullTo0(current.cust_mem_attr1) == nullTo0(prev.cust_mem_attr1) &&
              nullTo0(current.cust_mem_attr2) == nullTo0(prev.cust_mem_attr2) &&
              nullTo0(current.cust_mem_attr3) == nullTo0(prev.cust_mem_attr3) &&
              nullTo0(current.cust_mem_attr4) == nullTo0(prev.cust_mem_attr4) &&
              nullTo0(current.cust_mem_attr5) == nullTo0(prev.cust_mem_attr5) &&
              nullTo0(current.cust_mem_attr6) == nullTo0(prev.cust_mem_attr6) &&
              (current.member_start == compareMemberEnd || current.member_start.before(compareMemberEnd))
          ) {
            // still in the window, put the current member_end into the previous. do not alter finished as this window is not finished
            (Some(prev.copy(member_end = current.member_end)), finished)
          } else {
            // not in the same window, use the new current as the start of the window and put prev into finished
            (Some(current), finished :+ prev)

          }

        }
    }


    // have to put the very last window into the return sequence
    val result = windowed._1 match {
      case Some(lastWindow) => windowed._2 :+ lastWindow
      case None => windowed._2
    }

    result

  }

  /**
    * returns a DF with a selected columns, these are the same selections in pp_bpo_member_detail, pp_bpo_member_detail_ii
    * @param windowedIns
    * @param ecds
    * @param sparkSession
    * @return
    */
  def bpoDetailAndII(windowedIns: DataFrame, ecds: DataFrame)(sparkSession: SparkSession): DataFrame = {
    import sparkSession.implicits._

    windowedIns.alias("mr").join(ecds.alias("e"), $"e.grp_mpi" === $"mr.grp_mpi", "left")
      .select($"groupid",
        $"mr.grp_mpi".cast(StringType).alias("memberid"),
        when($"dob".isNull, $"member_start")
          .when(to_timestamp($"member_start") < to_timestamp(coalesce($"dob", lit("19000101")), CDRConstants.DATE_FORMAT_4Y2M2D),
            to_timestamp(concat(substring(coalesce($"dob", lit("19000101")), 1, 6), lit("01")), CDRConstants.DATE_FORMAT_4Y2M2D))
          .otherwise($"member_start").alias("effectivedate"),
        $"member_end".alias("enddate"),
        to_timestamp($"dob", CDRConstants.DATE_FORMAT_4Y2M2D).alias("dob"),
        when($"mapped_gender" === "CH000034", "M")
          .when($"mapped_gender" === "CH000033", "F").alias("gender"),
        $"pcpid",
        $"pharmacy",
        $"productcode",
        $"subscriberid",
        $"healthplansource",
        $"employeraccountid",
        $"coverageclasscode",
        $"subscriberflag",
        lit("*").cast(StringType).alias("mapsource"),
        $"lineofbusinessid",
        when($"mapped_race" === "CH000055", 1)
          .when($"mapped_race" === "CH000053", 2)
          .when($"mapped_race" === "CH000051", 3)
          .when($"mapped_race" === "CH000052", 4)
          .when($"mapped_race" === "CH000054", 5)
          .when($"mapped_race" === "CH001643", 7)
          .otherwise(9).alias("race"),
        lit("29").cast(StringType).alias("race_datasrc"),
        when($"mapped_ethnicity" === "CH000057", 11)
          .when($"mapped_ethnicity" === "CH000058", 12)
          .otherwise(19).alias("ethnicity"),
        lit("99").cast(StringType).alias("ethnicity_datasrc"),
        when(coalesce($"mapped_language", lit("CH999999")) === "CH002130", "31")
          .when(coalesce($"mapped_language", lit("CH999999")).isin("CH002186", "CH999999", "CH999990"), "39")
          .otherwise("32").alias("spoken_language"),
        lit("49").alias("spoken_language_datasrc"),
        lit("Y").alias("mh_inpatient_benefit"),
        lit("Y").alias("mh_intensive_benefit"),
        lit("Y").alias("mh_outpatient_benefit"),
        lit("Y").alias("cd_inpatient_benefit"),
        lit("Y").alias("cd_intensive_benefit"),
        lit("Y").alias("cd_outpatient_benefit"),
        lit("N").alias("hospice_benefit"),
        $"date_of_death",
        when($"date_of_death".isNull, "N").otherwise("Y").alias("deceased_flag"),
        when($"e.grp_mpi".isNull, "N").otherwise("Y").alias("ecds_flag"),
        lit("Y").cast(StringType).alias("primary_coverage_flag"),
        $"groupid".alias("mcoid"),
        $"contract_id",
        $"at_risk_status",
        $"cust_mem_attr1",
        $"cust_mem_attr2",
        $"cust_mem_attr3",
        $"cust_mem_attr4",
        $"cust_mem_attr5",
        $"cust_mem_attr6",
        $"coverage_status".alias("coveragestatus"),
        $"emp_acct_id",
        $"contracttype",
        $"benefitplan",
        coalesce($"dental_benefit",lit("Y")).as("dental_benefit"),
        when(coalesce($"medical_benefit_ind", lit(1)) === lit(1), lit("Y")).otherwise(lit("N")).as("medical"),
        when(coalesce($"mh_benefit_ind", lit(1)) === lit(1), lit("Y")).otherwise(lit("N")).as("mentalhealth"),
        $"employee_type",
        coalesce($"hra_ind", lit(0)).as("hra_ind"),
        coalesce($"hsa_ind", lit(0)).as("hsa_ind"),
        $"product_dtl_code",
        $"pcp_affil",
        $"risk_type",
        $"mem_userdef_1",
        $"mem_userdef_2",
        $"mem_userdef_3",
        $"mem_userdef_4",
        $"cust_mem_attr7",
        $"cust_mem_attr8",
        $"cust_mem_attr9",
        $"cust_mem_attr10",
        $"cust_mem_attr11",
        $"cust_mem_attr12",
        $"cust_mem_attr13",
        $"cust_mem_attr14",
        $"cust_mem_attr15",
        $"cust_mem_attr16",
        $"cust_mem_attr17",
        $"cust_mem_attr18",
        $"cust_mem_attr19",
        $"cust_mem_attr20",
        $"sec_member_id_1",
        $"sec_member_id_2",
        //These were not populated in the script, so just setting them to null since the case class have them
        lit(null).cast(StringType).alias("addl_pcp_prov_spclty_cd"),
        lit(null).cast(StringType).alias("address1"),
        lit(null).cast(StringType).alias("address2"),
        lit(null).cast(StringType).alias("city"),
        lit(null).cast(StringType).alias("county"),
        lit(null).cast(StringType).alias("custom_risk_maker_01"),
        lit(null).cast(StringType).alias("custom_risk_maker_02"),
        lit(null).cast(StringType).alias("custom_risk_maker_03"),
        lit(null).cast(StringType).alias("custom_risk_maker_04"),
        lit(null).cast(StringType).alias("custom_risk_maker_05"),
        lit(null).cast(StringType).alias("custom_risk_maker_06"),
        lit(null).cast(StringType).alias("custom_risk_maker_07"),
        lit(null).cast(StringType).alias("custom_risk_maker_08"),
        lit(null).cast(StringType).alias("custom_risk_maker_09"),
        lit(null).cast(StringType).alias("custom_risk_maker_10"),
        lit(null).cast(StringType).alias("firstname"),
        lit(null).cast(StringType).alias("guardian_first_name"),
        lit(null).cast(StringType).alias("guardian_last_name"),
        lit(null).cast(StringType).alias("guardian_middle_name"),
        lit(null).cast(StringType).alias("healthplanname"),
        lit(null).cast(TimestampType).alias("ins_timestamp"),
        lit(null).cast(StringType).alias("lastname"),
        lit(null).cast(StringType).alias("member_region"),
        lit(null).cast(StringType).alias("other_language"),
        lit(null).cast(StringType).alias("other_language_datasrc"),
        lit(null).cast(StringType).alias("pcp_prov_spclty"),
        lit(null).cast(StringType).alias("phone"),
        lit(null).cast(StringType).alias("population_id"),
        lit(null).cast(StringType).alias("product_source"),
        lit(null).cast(StringType).alias("prov_org_id"),
        lit(null).cast(StringType).alias("state"),
        lit(null).cast(StringType).alias("written_language"),
        lit(null).cast(StringType).alias("written_language_datasrc"),
        lit(null).cast(StringType).alias("zipcode"),
        lit(null).cast(StringType).alias("email")
      )
  }

}
