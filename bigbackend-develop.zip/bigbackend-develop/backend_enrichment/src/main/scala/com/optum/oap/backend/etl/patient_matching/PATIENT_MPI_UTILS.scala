package com.optum.oap.backend.etl.patient_matching

import com.optum.oap.backend.cdrTempModel.qgate_person_id_status
import com.optum.oap.backend.etl.common.EnrichmentUtils
import com.optum.oap.backend.etl.summary.PATIENT_GRP_MPI_DIFF.getMostRecentExistingReleaseIfAny
import org.apache.spark.sql.{DataFrame, Dataset, Encoder, SparkSession}
import org.slf4j.LoggerFactory

import scala.util.Try

object PATIENT_MPI_UTILS {

  val log = LoggerFactory.getLogger(this.getClass)

  val BAD_SSN_RESOURCENAME = "bad_ssn.txt"

  lazy val getBadSSNs: Seq[String] = {
    val resPath = this.getClass.getClassLoader.getResourceAsStream(BAD_SSN_RESOURCENAME)
    val metadata = scala.io.Source.fromInputStream(resPath).getLines
    metadata.filter(!_.isEmpty).filter(line => !line.startsWith("/**")).toSeq
  }

  def getPreviousExisitingDb(sparkSession: SparkSession,  releaseCycle: String, grpid: String, env: String) = {
    Try(getMostRecentExistingReleaseIfAny(sparkSession, releaseCycle,grpid, env, -1)
      .orElse(getMostRecentExistingReleaseIfAny(sparkSession, releaseCycle,grpid, env, -2))
      .orElse(getMostRecentExistingReleaseIfAny(sparkSession, releaseCycle,grpid, env, -3)))
      .getOrElse(None)
  }

  def getPreviousCycleTable[T:Encoder](sparkSession: SparkSession, releaseCycle: String, grpid: String, env: String, table: String) = {
    import sparkSession.implicits._
    if (!releaseCycle.matches("\\d{6}")) {
      if (env.equals("prd"))
        throw new Exception(s"release cycle supplied $releaseCycle is not in YYYYMM format for production run")
    }

    val prevmonth_monthlydb: Option[String] = getPreviousExisitingDb(sparkSession, releaseCycle, grpid, env)
    if (prevmonth_monthlydb.isDefined) {
      val prevQgatePersonIdStatus = sparkSession.sql(s"select * from ${prevmonth_monthlydb.get}.$table")
      prevQgatePersonIdStatus.drop("row_source", "modified_date")
    } else {
      log.warn(s"No previous db were found returning empty $table")
      Seq.empty[T].toDF()
    }
  }

}
