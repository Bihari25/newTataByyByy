package com.optum.oap.backend.etl.patient_matching.data_table

import com.optum.oap.backend.cdrTempModel.pat_match_prep
import com.optum.oap.backend.etl.common.{CDRConstants, CleanPatientName, EnrichmentUtils}
import com.optum.oap.backend.loader.EnrichmentRunTimeVariables
import com.optum.oap.cdr.models.{mpi_custom, patient_id}
import com.optum.oap.sparkdataloader.{RuntimeVariables, TableInfo, UserDefinedFunctionForDataLoader}
import org.apache.spark.sql.expressions.Window
import org.apache.spark.sql.functions.{collect_set, lit, size, upper}
import org.apache.spark.sql.types.{LongType, StringType}
import org.apache.spark.sql.{DataFrame, SparkSession}

object MPI_CUSTOM_H592196 extends TableInfo[mpi_custom] {

  override def dependsOn: Set[String] = Set("PAT_MATCH_PREP", "PATIENT_ID_PREMATCH", "ECDR_MPI_CUSTOM_H592196")

  override def name = "MPI_CUSTOM_H592196"

  override protected def createDataFrame(sparkSession: SparkSession,
                                         loadedDependencies: Map[String, DataFrame],
                                         udfMap: Map[String, UserDefinedFunctionForDataLoader],
                                         runtimeVariables: RuntimeVariables): DataFrame = {

    import sparkSession.implicits._


    val tempPatMatchPrep = loadedDependencies("PAT_MATCH_PREP").as[pat_match_prep]
    val tempPatientId = loadedDependencies("PATIENT_ID_PREMATCH").as[patient_id]

    val dailyBuild = if (runtimeVariables.asInstanceOf[EnrichmentRunTimeVariables].buildType == CDRConstants.DELTA_BUILD_TYPE) true else false

    val tempPatAttr = tempPatMatchPrep
      .where($"dob".isNotNull)
      .select(
        $"groupid",
        $"client_ds_id",
        $"patientid",
        $"hgpid",
        $"dob",
        upper($"fname").as("first_name"),
        upper($"lname").as("last_name"),
        CleanPatientName.cleanPatientName($"fname", lit(3)).as("fname"),
        CleanPatientName.cleanPatientName($"lname", lit(3)).as("lname")
      ).distinct

    val tempPatientIdValDf = tempPatientId
      .where($"idtype" === lit("ALT_PRSN"))
      .select(
        $"groupid",
        $"client_ds_id",
        $"patientid",
        $"idvalue".as("alt_prsn")
      ).distinct

    val dobWindow = Window.partitionBy($"dob")

    val dataDf = tempPatAttr.as("p")
      .join(tempPatientIdValDf.as("pid"), Seq("groupid", "client_ds_id", "patientid"), "left")
      .select(
        $"p.groupid",
        $"p.client_ds_id",
        $"p.patientid",
        $"p.hgpid",
        $"p.dob".as("key_attr"),
        $"p.fname".as("attr_2"),
        $"p.lname".as("attr_3"),
        $"alt_prsn".as("attr_4"),
        lit(null).cast(StringType).as("attr_5"),
        lit(null).cast(StringType).as("attr_6"),
        lit(null).cast(StringType).as("attr_7"),
        lit(null).cast(StringType).as("attr_8"),
        lit(null).cast(StringType).as("attr_9"),
        lit(null).cast(StringType).as("attr_10"),
        lit(null).cast(StringType).as("attr_11"),
        lit(null).cast(StringType).as("attr_12"),
        size(collect_set($"p.groupid").over(dobWindow)).as("group_cnt"),
        size(collect_set($"p.hgpid").over(dobWindow)).cast(LongType).as("hgpids")
      )

    val ecdrDf = {
      if (dailyBuild) EnrichmentUtils.removeRowSourceAndModifiedDate(loadedDependencies("ECDR_MPI_CUSTOM_H592196")).as[mpi_custom]
      else sparkSession.emptyDataset[mpi_custom].as[mpi_custom]
    }.as("e")
      .select($"e.*")

    dataDf.unionByName(ecdrDf).distinct()

  }

}
