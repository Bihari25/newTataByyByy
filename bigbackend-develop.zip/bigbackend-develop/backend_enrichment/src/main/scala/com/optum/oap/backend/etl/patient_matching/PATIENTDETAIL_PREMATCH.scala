package com.optum.oap.backend.etl.patient_matching

import com.optum.oap.cdr.models.{patientaddr, patientdetail}
import com.optum.oap.sparkdataloader.{RuntimeVariables, TableInfo, UserDefinedFunctionForDataLoader}
import org.apache.spark.sql.functions._
import org.apache.spark.sql.types.{LongType, StringType}
import org.apache.spark.sql.{Column, DataFrame, SparkSession}

object PATIENTDETAIL_PREMATCH extends TableInfo[patientdetail] {

  override def dependsOn = Set("CDR_FE_PATIENTDETAIL", "CDR_FE_PATIENTADDR","ICPM_PATIENT_DETAIL","ICPM_PATIENTADDR")

  override def name = "PATIENTDETAIL_PREMATCH"

  override def saveDataFrameToParquet: Boolean = true

  override def createDataFrame(sparkSession: SparkSession,
                               loadedDependencies: Map[String, DataFrame],
                               udfMap: Map[String, UserDefinedFunctionForDataLoader],
                               runtimeVariables: RuntimeVariables): DataFrame = {
    import sparkSession.implicits._

    val patientdetailIn = loadedDependencies("CDR_FE_PATIENTDETAIL").drop("row_source","modified_date").as[patientdetail]
    val patientdetailIcpm = loadedDependencies("ICPM_PATIENT_DETAIL").as[patientdetail]
    val patientdetailUnion = patientdetailIn.unionByName(patientdetailIcpm)

    val patAddr = loadedDependencies("CDR_FE_PATIENTADDR").drop("row_source","modified_date").as[patientaddr]
    val patAddrIcpm = loadedDependencies("ICPM_PATIENTADDR").as[patientaddr]
    val patientAddrUnion = patAddr.unionByName(patAddrIcpm)

    val df1 = patientdetailUnion.where($"patientdetailtype" === "ZIPCODE")
      .select($"groupid", $"client_ds_id", $"datasrc", $"patientid", checkZipCode($"localvalue").as("zipcode"))

    val df2 = patientAddrUnion.where($"zipcode".isNotNull)
      .select($"groupid", $"client_ds_id", $"datasrc", $"patientid",
        checkZipCode($"zipcode").as("zipcode"))

    val df3 = df2.except(df1)

    val df4 = patientAddrUnion.as("a").join(df3.as("e"),
      $"a.groupid" === $"e.groupid" && $"a.client_ds_id" === $"e.client_ds_id" && $"a.datasrc" === $"e.datasrc" && $"a.patientid" === $"e.patientid" && checkZipCode($"a.zipcode") === $"e.zipcode",
      "inner"
    ).select($"a.groupid",
      $"a.client_ds_id",
      $"a.datasrc",
      $"a.patientid",
      $"a.zipcode",
      $"address_date",
      lit("ZIPCODE").as("patientdetailtype")
    ).groupBy($"groupid", $"client_ds_id", $"datasrc", $"patientid", $"zipcode", $"patientdetailtype")
      .agg(max($"address_date").as("patdetail_timestamp"))

    val finalDf = df4.select($"groupid",
      $"client_ds_id",
      $"datasrc",
      $"patientid",
      $"patdetail_timestamp",
      $"patientdetailtype",
      checkZipCode($"zipcode").as("localvalue"),
      lit(null).cast(StringType).as("encounterid"),
      lit(null).cast(StringType).as("facilityid"),
      lit(null).cast(StringType).as("grp_mpi"),
      lit(null).cast(LongType).as("hgpid"),
      lit(null).cast(StringType).as("patientdetailqual"),
      lit(null).cast(StringType).as("patientdetailstatus")
    )

    val detail = patientdetailUnion.select($"groupid",
      $"client_ds_id",
      $"datasrc",
      $"patientid",
      $"patdetail_timestamp",
      $"patientdetailtype",
      when($"patientdetailtype" =!= "ZIPCODE", $"localvalue")
        .when($"patientdetailtype" === "ZIPCODE" && $"localvalue".rlike("^[0-9]{5}(-)?([0-9]{4})?$"), $"localvalue".substr(1, 5))
        .otherwise(lit(null))
        .as("localvalue"),
      $"encounterid",
      $"facilityid",
      $"grp_mpi",
      $"hgpid",
      $"patientdetailqual",
      $"patientdetailstatus"
    )

    finalDf.unionByName(detail)
  }

  def checkZipCode(column: Column): Column = {
    when(translate(trim(column), "O", "0").rlike("^[0-9]{5}(-)?([0-9]{4})?$"), column.substr(1, 5)).otherwise(null)

  }

}
