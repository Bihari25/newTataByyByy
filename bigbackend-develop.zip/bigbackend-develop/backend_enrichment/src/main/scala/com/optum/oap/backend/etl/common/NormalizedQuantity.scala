package com.optum.oap.backend.etl.common

import com.optum.oap.backend.etl.common.UnitConversionFunction.UnitConversionFunction

object NormalizedQuantity extends UnitConversion {
  /**
   * Method to convert the *_quantity values coming in from the TREATMENT_ORDERED and TREATMENT_ADMINISTERED tables into
   * a normalized quantity.
   *
   * @return returns the string converted value of the calculation to be used in a single row result of the table
   */
  def derive(p_DATA_TYPE: String,
             p_BEGIN_RANGE: Option[Int],
             p_END_RANGE: Option[Int],
             p_ROUND_PREC: Option[Int],
             p_TREATMENT_TYPE_STD_UNITS: Option[String],
             p_localresult: Option[String],
             p_LOCALUNIT_CUI: Option[String],
             p_conv_factor: Option[java.lang.Double],
             p_FUNCTION_APPLIED: Option[String]): String = {
    val numericTypes = Set("f", "n")
    // if the incoming value is null or the data type is not supported, result = null.
    if (p_localresult.isEmpty || !numericTypes.contains(p_DATA_TYPE.toLowerCase)) null else {
      val maxLength = scala.math.min(p_localresult.get.length, 250)
      val cleanedValue = p_localresult.get.substring(0, maxLength).replaceAll("[/+]", "")
      val parsedValue = scala.util.Try[java.lang.Double](cleanedValue.toDouble).toOption

      // conversion if necessary
      if (parsedValue.isDefined) {
        val value = parsedValue.get
        val typeUnits = p_TREATMENT_TYPE_STD_UNITS.getOrElse("0")
        val localUnitCui = p_LOCALUNIT_CUI.getOrElse("0")
        val convertedResult = if (typeUnits != localUnitCui) {
          val conversionFactor: java.lang.Double = p_conv_factor.getOrElse(1.0)
          val convertedValue = value * conversionFactor
          val conversionType: UnitConversionFunction = UnitConversionFunction.values.find(
            _.toString.toLowerCase == p_FUNCTION_APPLIED.getOrElse(UnitConversionFunction.LINEAR.toString).toLowerCase
          ).getOrElse(UnitConversionFunction.LINEAR)
          applyUnitConversionFunction(convertedValue, conversionType)
        } else value

        val rangeLimitedValue = // range limitation if necessary
          if (p_BEGIN_RANGE.isDefined && p_END_RANGE.isDefined &&
            !(convertedResult >= p_BEGIN_RANGE.get.toDouble && convertedResult <= p_END_RANGE.get.toDouble)
          ) None
          else Some(convertedResult)

        // rounding
        rangeLimitedValue.map(x => {
          roundDouble(x, p_ROUND_PREC.getOrElse(2))
        }).map(_.toString).orNull
      } else null
    }
  }
}