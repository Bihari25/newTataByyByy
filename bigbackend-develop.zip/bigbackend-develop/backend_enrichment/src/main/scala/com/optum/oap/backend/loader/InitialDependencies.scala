package com.optum.oap.backend.loader

import com.optum.oap.backend.cdrTempModel._
import com.optum.oap.cdr.models._
import com.optum.oap.sparkdataloader.LoadFromHive


object DataTableDependencies {
  def dataInitialDependencies(cdrDB: String, namePrefix: String = "", isCDRFE: Boolean =  false) = {
    Seq(
      LoadFromHive[account_rollup](tableName = "ACCOUNT_ROLLUP", referenceName = Option(namePrefix + "ACCOUNT_ROLLUP"), hiveDatabase = cdrDB),
      LoadFromHive[allergy](tableName = "ALLERGY", referenceName = Option(namePrefix + "ALLERGY"), hiveDatabase = cdrDB),
      LoadFromHive[appointment](tableName = "APPOINTMENT", referenceName = Option(namePrefix + "APPOINTMENT"), hiveDatabase = cdrDB),
      LoadFromHive[benefit_plan_rollup](tableName = "BENEFIT_PLAN_ROLLUP", referenceName = Option(namePrefix + "BENEFIT_PLAN_ROLLUP"), hiveDatabase = cdrDB),
      LoadFromHive[biz_segment_rollup](tableName = "BIZ_SEGMENT_ROLLUP", referenceName = Option(namePrefix + "BIZ_SEGMENT_ROLLUP"), hiveDatabase = cdrDB),
      LoadFromHive[claim](tableName = "CLAIM", referenceName = Option(namePrefix + "CLAIM"), hiveDatabase = cdrDB),
      LoadFromHive[cc_case](tableName = "CC_CASE", referenceName = Option(namePrefix + "CC_CASE"), hiveDatabase = cdrDB),
      LoadFromHive[cc_case_status_history](tableName = "CC_CASE_STATUS_HISTORY", referenceName = Option(namePrefix + "CC_CASE_STATUS_HISTORY"), hiveDatabase = cdrDB),
      LoadFromHive[cc_case_tier_history](tableName = "CC_CASE_TIER_HISTORY", referenceName = Option(namePrefix + "CC_CASE_TIER_HISTORY"), hiveDatabase = cdrDB),
      LoadFromHive[clinicalencounter](tableName = "CLINICALENCOUNTER", referenceName = Option(namePrefix + "CLINICALENCOUNTER"), hiveDatabase = cdrDB),
      LoadFromHive[contract_rollup](tableName = "CONTRACT_ROLLUP", referenceName = Option(namePrefix + "CONTRACT_ROLLUP"), hiveDatabase = cdrDB),
      LoadFromHive[contract_type_rollup](tableName = "CONTRACT_TYPE_ROLLUP", referenceName = Option(namePrefix + "CONTRACT_TYPE_ROLLUP"), hiveDatabase = cdrDB),
      LoadFromHive[coverage_status_rollup](tableName = "COVERAGE_STATUS_ROLLUP", referenceName = Option(namePrefix + "COVERAGE_STATUS_ROLLUP"), hiveDatabase = cdrDB),
      LoadFromHive[diagnosis](tableName = "DIAGNOSIS", referenceName = Option(namePrefix + "DIAGNOSIS"), hiveDatabase = cdrDB),
      LoadFromHive[denied_ind_rollup](tableName = "DENIED_IND_ROLLUP", referenceName = Option(namePrefix + "DENIED_IND_ROLLUP"), hiveDatabase = cdrDB),
      LoadFromHive[employee_type_rollup](tableName = "EMPLOYEE_TYPE_ROLLUP", referenceName = Option(namePrefix + "EMPLOYEE_TYPE_ROLLUP"), hiveDatabase = cdrDB),
      LoadFromHive[encountercarearea](tableName = "ENCOUNTERCAREAREA", referenceName = Option(namePrefix + "ENCOUNTERCAREAREA"), hiveDatabase = cdrDB),
      LoadFromHive[encounterprovider](tableName = "ENCOUNTERPROVIDER", referenceName = Option(namePrefix + "ENCOUNTERPROVIDER"), hiveDatabase = cdrDB),
      LoadFromHive[encounterreason](tableName = "ENCOUNTERREASON", referenceName = Option(namePrefix + "ENCOUNTERREASON"), hiveDatabase = cdrDB),
      LoadFromHive[health_maintenance](tableName = "HEALTH_MAINTENANCE", referenceName = Option(namePrefix + "HEALTH_MAINTENANCE"), hiveDatabase = cdrDB),
      LoadFromHive[immunization](tableName = "IMMUNIZATION", referenceName = Option(namePrefix + "IMMUNIZATION"), hiveDatabase = cdrDB),
      LoadFromHive[insurance](tableName = "INSURANCE", referenceName = Option(namePrefix + "INSURANCE"), hiveDatabase = cdrDB),
      LoadFromHive[int_claim_med_icpm](tableName = "INT_CLAIM_MEDICAL", referenceName = Option(namePrefix + "INT_CLAIM_MEDICAL"), hiveDatabase = cdrDB),
      LoadFromHive[int_claim_member](tableName = "INT_CLAIM_MEMBER", referenceName = Option(namePrefix + "INT_CLAIM_MEMBER"), hiveDatabase = cdrDB),
      LoadFromHive[int_claim_prov](tableName = "INT_CLAIM_PROV", referenceName = Option(namePrefix + "INT_CLAIM_PROV"), hiveDatabase = cdrDB),
      LoadFromHive[int_claim_pharm](tableName = "INT_CLAIM_PHARM", referenceName = Option(namePrefix + "INT_CLAIM_PHARM"), hiveDatabase = cdrDB),
      LoadFromHive[laborder](tableName = "LABORDER", referenceName = Option(namePrefix + "LABORDER"), hiveDatabase = cdrDB),
      LoadFromHive[labresult](tableName = "LABRESULT", referenceName = Option(namePrefix + "LABRESULT"), hiveDatabase = cdrDB),
      LoadFromHive[mborder](tableName = "MBORDER", referenceName = Option(namePrefix + "MBORDER"), hiveDatabase = cdrDB),
      LoadFromHive[mbresult](tableName = "MBRESULT", referenceName = Option(namePrefix + "MBRESULT"), hiveDatabase = cdrDB),
      LoadFromHive[mem_userdef_rollup](tableName = "MEM_USERDEF_ROLLUP", referenceName = Option(namePrefix + "MEM_USERDEF_ROLLUP"), hiveDatabase = cdrDB),
      LoadFromHive[netwrk_paid_status_rollup](tableName = "NETWRK_PAID_STATUS_ROLLUP", referenceName = Option(namePrefix + "NETWRK_PAID_STATUS_ROLLUP"), hiveDatabase = cdrDB),
      LoadFromHive[observation](tableName = "OBSERVATION", referenceName = Option(namePrefix + "OBSERVATION"), hiveDatabase = cdrDB),
      LoadFromHive[p3_pat_assmt_result](tableName = "P3_PAT_ASSMT_RESULT", referenceName = Option(namePrefix + "P3_PAT_ASSMT_RESULT"), hiveDatabase = cdrDB),
      LoadFromHive[patient](tableName = "PATIENT", referenceName = Option(namePrefix + "PATIENT"), hiveDatabase = cdrDB),
      LoadFromHive[patientaddr](tableName = "PATIENTADDR", referenceName = Option(namePrefix + "PATIENTADDR"), hiveDatabase = cdrDB),
      LoadFromHive[patientcontact](tableName = "PATIENTCONTACT", referenceName = Option(namePrefix + "PATIENTCONTACT"), hiveDatabase = cdrDB),
      LoadFromHive[patientdetail](tableName = "PATIENTDETAIL", referenceName = Option(namePrefix + "PATIENTDETAIL"), hiveDatabase = cdrDB),
      LoadFromHive[patient_attribute](tableName = "PATIENT_ATTRIBUTE", referenceName = Option(namePrefix + "PATIENT_ATTRIBUTE"), hiveDatabase = cdrDB),
      LoadFromHive[patient_care_pathway](tableName = "PATIENT_CARE_PATHWAY", referenceName = Option(namePrefix + "PATIENT_CARE_PATHWAY"), hiveDatabase = cdrDB),
      LoadFromHive[patient_id](tableName = "PATIENT_ID", referenceName = Option(namePrefix + "PATIENT_ID"), hiveDatabase = cdrDB),
      LoadFromHive[patient_population](tableName = "PATIENT_POPULATION", referenceName = Option(namePrefix + "PATIENT_POPULATION"), hiveDatabase = cdrDB),
      LoadFromHive[pat_risk_attrib](tableName = "PAT_RISK_ATTRIB", referenceName = Option(namePrefix + "PAT_RISK_ATTRIB"), hiveDatabase = cdrDB),
      LoadFromHive[premium](tableName = "PREMIUM", referenceName = Option(namePrefix + "PREMIUM"), hiveDatabase = cdrDB),
      LoadFromHive[proceduredo](tableName = "PROCEDUREDO", referenceName = Option(namePrefix + "PROCEDUREDO"), hiveDatabase = cdrDB),
      LoadFromHive[proceduredrug](tableName = "PROCEDUREDRUG", referenceName = Option(namePrefix + "PROCEDUREDRUG"), hiveDatabase = cdrDB),
      LoadFromHive[product_rollup](tableName = "PRODUCT_ROLLUP", referenceName = Option(namePrefix + "PRODUCT_ROLLUP"), hiveDatabase = cdrDB),
      LoadFromHive[prov_affil](tableName = "PROV_AFFIL", referenceName = Option(namePrefix + "PROV_AFFIL"), hiveDatabase = cdrDB),
      LoadFromHive[prov_affil_rollup](tableName = "PROV_AFFIL_ROLLUP", referenceName = Option(namePrefix + "PROV_AFFIL_ROLLUP"), hiveDatabase = cdrDB),
      LoadFromHive[prov_client_rel](tableName = "PROV_CLIENT_REL", referenceName = Option(namePrefix + "PROV_CLIENT_REL"), hiveDatabase = cdrDB),
      LoadFromHive[prov_fac_rel](tableName = "PROV_FAC_REL", referenceName = Option(namePrefix + "PROV_FAC_REL"), hiveDatabase = cdrDB),
      LoadFromHive[prov_pat_rel](tableName = "PROV_PAT_REL", referenceName = Option(namePrefix + "PROV_PAT_REL"), hiveDatabase = cdrDB),
      LoadFromHive[prov_spec](tableName = "PROV_SPEC", referenceName = Option(namePrefix + "PROV_SPEC"), hiveDatabase = cdrDB),
      LoadFromHive[prov_status_rollup](tableName = "PROV_STATUS_ROLLUP", referenceName = Option(namePrefix + "PROV_STATUS_ROLLUP"), hiveDatabase = cdrDB),
      LoadFromHive[prov_userdef_rollup](tableName = "PROV_USERDEF_ROLLUP", referenceName = Option(namePrefix + "PROV_USERDEF_ROLLUP"), hiveDatabase = cdrDB),
      LoadFromHive[risk_status_rollup](tableName = "RISK_STATUS_ROLLUP", referenceName = Option(namePrefix + "RISK_STATUS_ROLLUP"), hiveDatabase = cdrDB),
      LoadFromHive[risk_type_rollup](tableName = "RISK_TYPE_ROLLUP", referenceName = Option(namePrefix + "RISK_TYPE_ROLLUP"), hiveDatabase = cdrDB),
      LoadFromHive[rxadmin](tableName = "RXADMIN", referenceName = Option(namePrefix + "RXADMIN"), hiveDatabase = cdrDB),
      LoadFromHive[rxorder](tableName = "RXORDER", referenceName = Option(namePrefix + "RXORDER"), hiveDatabase = cdrDB),
      LoadFromHive[prof_bill_chrg](tableName = "PROF_BILL_CHRG", referenceName = Option(namePrefix + "PROF_BILL_CHRG"), hiveDatabase = cdrDB),
      LoadFromHive[rx_patient_reported]("RX_PATIENT_REPORTED", referenceName = Option(namePrefix + "RX_PATIENT_REPORTED"), hiveDatabase = cdrDB),
      LoadFromHive[specialty_rx_rollup](tableName = "SPECIALTY_RX_ROLLUP", referenceName = Option(namePrefix + "SPECIALTY_RX_ROLLUP"), hiveDatabase = cdrDB),
      LoadFromHive[treatment_administered](tableName = "TREATMENT_ADMINISTERED", referenceName = Option(namePrefix + "TREATMENT_ADMINISTERED"), hiveDatabase = cdrDB),
      LoadFromHive[treatment_ordered](tableName = "TREATMENT_ORDERED", referenceName = Option(namePrefix + "TREATMENT_ORDERED"), hiveDatabase = cdrDB),
      LoadFromHive[zcm_cult_org_excl]("ZCM_CULT_ORG_EXCL", referenceName = Option(namePrefix + "ZCM_CULT_ORG_EXCL"), hiveDatabase = cdrDB),
      LoadFromHive[zcm_cult_org_found]("ZCM_CULT_ORG_FOUND", referenceName = Option(namePrefix + "ZCM_CULT_ORG_FOUND"), hiveDatabase = cdrDB),
      LoadFromHive[zcm_micro_antibiotic_pattern]("ZCM_MICRO_ANTIBIOTIC_PATTERN", referenceName = Option(namePrefix + "ZCM_MICRO_ANTIBIOTIC_PATTERN"), hiveDatabase = cdrDB),
      LoadFromHive[zcm_micro_cult_unit_pattern]("ZCM_MICRO_CULT_UNIT_PATTERN", referenceName = Option(namePrefix + "ZCM_MICRO_CULT_UNIT_PATTERN"), hiveDatabase = cdrDB),
      LoadFromHive[zcm_micro_cult_val_pattern]("ZCM_MICRO_CULT_VAL_PATTERN", referenceName = Option(namePrefix + "ZCM_MICRO_CULT_VAL_PATTERN"), hiveDatabase = cdrDB),
      LoadFromHive[zcm_micro_growth_pattern]("ZCM_MICRO_GROWTH_PATTERN", referenceName = Option(namePrefix + "ZCM_MICRO_GROWTH_PATTERN"), hiveDatabase = cdrDB),
      LoadFromHive[zcm_micro_sens_result_pattern]("ZCM_MICRO_SENS_RESULT_PATTERN", referenceName = Option(namePrefix + "ZCM_MICRO_SENS_RESULT_PATTERN"), hiveDatabase = cdrDB),
      LoadFromHive[zcm_micro_reslt_stats_pattern]("ZCM_MICRO_RESLT_STATS_PATTERN", referenceName = Option(namePrefix + "ZCM_MICRO_RESLT_STATS_PATTERN"), hiveDatabase = cdrDB),
      LoadFromHive[zh_prov_attribute](tableName = "ZH_PROV_ATTRIBUTE", referenceName = Option(namePrefix + "ZH_PROV_ATTRIBUTE"), hiveDatabase = cdrDB),
      LoadFromHive[zh_provider](tableName = "ZH_PROVIDER", referenceName = Option(namePrefix + "ZH_PROVIDER"), hiveDatabase = cdrDB),
      LoadFromHive[zcm_insure_co_map_pattern](tableName = "ZCM_INSURE_CO_MAP_PATTERN", referenceName = Option(namePrefix + "ZCM_INSURE_CO_MAP_PATTERN"), hiveDatabase = cdrDB),
      LoadFromHive[zcm_insure_plan_map_pattern](tableName = "ZCM_INSURE_PLAN_MAP_PATTERN", referenceName = Option(namePrefix + "ZCM_INSURE_PLAN_MAP_PATTERN"), hiveDatabase = cdrDB),
      LoadFromHive[zcm_micro_proc_pattern](tableName = "ZCM_MICRO_PROC_PATTERN", referenceName = Option(namePrefix + "ZCM_MICRO_PROC_PATTERN"), hiveDatabase = cdrDB),
      LoadFromHive[zcm_specimen_source_pattern](tableName = "ZCM_SPECIMEN_SOURCE_PATTERN", referenceName = Option(namePrefix + "ZCM_SPECIMEN_SOURCE_PATTERN"), hiveDatabase = cdrDB),
      LoadFromHive[zh_facility](tableName = "ZH_FACILITY", referenceName = Option(namePrefix + "ZH_FACILITY"), hiveDatabase = cdrDB),
      LoadFromHive[zh_lab_dict](tableName = "ZH_LAB_DICT", referenceName = Option(namePrefix + "ZH_LAB_DICT"), hiveDatabase = cdrDB),
      LoadFromHive[zh_provider_contact](tableName = "ZH_PROVIDER_CONTACT", referenceName = Option(namePrefix + "ZH_PROVIDER_CONTACT"), hiveDatabase = cdrDB),
      LoadFromHive[zh_provider_identifier](tableName = "ZH_PROVIDER_IDENTIFIER", referenceName = Option(namePrefix + "ZH_PROVIDER_IDENTIFIER"), hiveDatabase = cdrDB),
      LoadFromHive[provider_xref](tableName = "CDR_FE_PROVIDER_XREF", referenceName = None, hiveDatabase = cdrDB),
      LoadFromHive[provider_xref](tableName = "PROVIDER_XREF", referenceName = Option("COMMON_PROVIDER_XREF"), hiveDatabase = cdrDB),
      LoadFromHive[provider_xref](tableName = "V_PROVIDER_XREF", referenceName = None, hiveDatabase = cdrDB, dependsOn = if(isCDRFE) Set("PROVIDER_XREF") else Set.empty[String]),
      LoadFromHive[patient_xref](tableName = "CDR_FE_PATIENT_XREF", referenceName = None, hiveDatabase = cdrDB),
      LoadFromHive[patient_xref](tableName = "PATIENT_XREF", referenceName = Option("COMMON_PATIENT_XREF"), hiveDatabase = cdrDB),
      LoadFromHive[patient_xref](tableName = "V_PATIENT_XREF", referenceName = None, hiveDatabase = cdrDB, dependsOn = if(isCDRFE) Set("PATIENT_XREF") else Set.empty[String]),
      LoadFromHive[facility_xref](tableName = "CDR_FE_FACILITY_XREF", referenceName = None, hiveDatabase = cdrDB),
      LoadFromHive[facility_xref](tableName = "FACILITY_XREF", referenceName = Option("COMMON_FACILITY_XREF"), hiveDatabase = cdrDB),
      LoadFromHive[facility_xref](tableName = "V_FACILITY_XREF", referenceName = None, hiveDatabase = cdrDB, dependsOn = if(isCDRFE) Set("FACILITY_XREF") else Set.empty[String])
    )
  }
}

object BeEncounterDependencies {
  def cdrBeEncounterInitialDependencies(cdrDB: String, namePrefix: String = "") = {
    Seq(
      LoadFromHive[zh_provider_master_xref](tableName = "ZH_PROVIDER_MASTER_XREF", referenceName = None, hiveDatabase = cdrDB),
      LoadFromHive[zh_v_provider_master](tableName = "ZH_V_PROVIDER_MASTER", referenceName = None, hiveDatabase = cdrDB)
    )
  }

}

object BeSummaryDependencies {
  def cdrBeSummaryInitialDependencies(cdrDB: String, namePrefix: String = "") = {
    Seq(
      LoadFromHive[zh_provider_master_xref](tableName = "ZH_PROVIDER_MASTER_XREF", referenceName = None, hiveDatabase = cdrDB)
    )
  }

}

object StaticDependencies {
  def staticInitialDependencies(cdrDB: String) = {
    Seq(
      LoadFromHive[mpi_patient_merge](tableName = "MPI_PATIENT_MERGE", referenceName = None, hiveDatabase = cdrDB),
      LoadFromHive[cui_specialty](tableName = "CUI_SPECIALTY", referenceName = None, hiveDatabase = cdrDB),
      LoadFromHive[specialty_group_cohort](tableName = "SPECIALTY_GROUP_COHORT", referenceName = None, hiveDatabase = cdrDB),
      LoadFromHive[qgate_new_evidence_patient_id](tableName = "QGATE_NEW_EVIDENCE_PATIENT_ID", referenceName = None, hiveDatabase = cdrDB),
      LoadFromHive[qgate_new_evidence_person_id](tableName = "QGATE_NEW_EVIDENCE_PERSON_ID", referenceName = None, hiveDatabase = cdrDB),
      LoadFromHive[client_attribute](tableName = "CLIENT_ATTRIBUTE", referenceName = None, hiveDatabase = cdrDB),
      LoadFromHive[cui_unit](tableName = "CUI_UNIT", referenceName = None, hiveDatabase = cdrDB),
      LoadFromHive[map_admit_source](tableName = "MAP_ADMIT_SOURCE", referenceName = None, hiveDatabase = cdrDB),
      LoadFromHive[map_care_area](tableName = "MAP_CARE_AREA", referenceName = None, hiveDatabase = cdrDB),
      LoadFromHive[map_contact_src](tableName = "MAP_CONTACT_SRC", referenceName = None, hiveDatabase = cdrDB),
      LoadFromHive[map_deceased_indicator](tableName = "MAP_DECEASED_INDICATOR", referenceName = None, hiveDatabase = cdrDB),
      LoadFromHive[map_diagnosis](tableName = "MAP_DIAGNOSIS", referenceName = None, hiveDatabase = cdrDB),
      LoadFromHive[map_discharge_disposition](tableName = "MAP_DISCHARGE_DISPOSITION", referenceName = None, hiveDatabase = cdrDB),
      LoadFromHive[map_domain_cdsid_priority](tableName = "MAP_DOMAIN_CDSID_PRIORITY", referenceName = None, hiveDatabase = cdrDB),
      LoadFromHive[map_drg_type](tableName = "MAP_DRG_TYPE", referenceName = None, hiveDatabase = cdrDB),
      LoadFromHive[map_employee_type](tableName = "MAP_EMPLOYEE_TYPE", referenceName = None, hiveDatabase = cdrDB),
      LoadFromHive[map_ethnicity](tableName = "MAP_ETHNICITY", referenceName = None, hiveDatabase = cdrDB),
      LoadFromHive[map_fac_order](tableName = "MAP_FAC_ORDER", referenceName = None, hiveDatabase = cdrDB),
      LoadFromHive[map_financial_class](tableName = "MAP_FINANCIAL_CLASS", referenceName = None, hiveDatabase = cdrDB),
      LoadFromHive[map_gender](tableName = "MAP_GENDER", referenceName = None, hiveDatabase = cdrDB),
      LoadFromHive[map_inp_admit_type](tableName = "MAP_INP_ADMIT_TYPE", referenceName = None, hiveDatabase = cdrDB),
      LoadFromHive[map_language](tableName = "MAP_LANGUAGE", referenceName = None, hiveDatabase = cdrDB),
      LoadFromHive[map_marital_status](tableName = "MAP_MARITAL_STATUS", referenceName = None, hiveDatabase = cdrDB),
      LoadFromHive[map_med_order_status](tableName = "MAP_MED_ORDER_STATUS", referenceName = None, hiveDatabase = cdrDB),
      LoadFromHive[map_network_paid_status](tableName = "MAP_NETWORK_PAID_STATUS", referenceName = None, hiveDatabase = cdrDB),
      LoadFromHive[map_observation](tableName = "MAP_OBSERVATION", referenceName = None, hiveDatabase = cdrDB),
      LoadFromHive[map_patient_type](tableName = "MAP_PATIENT_TYPE", referenceName = None, hiveDatabase = cdrDB),
      LoadFromHive[map_pcp_order](tableName = "MAP_PCP_ORDER", referenceName = None, hiveDatabase = cdrDB),
      LoadFromHive[map_predicate_values](tableName = "MAP_PREDICATE_VALUES", referenceName = None, hiveDatabase = cdrDB),
      LoadFromHive[map_provider_taxonomy](tableName = "MAP_PROVIDER_TAXONOMY", referenceName = None, hiveDatabase = cdrDB),
      LoadFromHive[map_pop_seg](tableName = "MAP_POP_SEG", referenceName = None, hiveDatabase = cdrDB),
      LoadFromHive[map_procedure](tableName = "MAP_PROCEDURE", referenceName = None, hiveDatabase = cdrDB),
      LoadFromHive[map_prov_status](tableName = "MAP_PROV_STATUS", referenceName = None, hiveDatabase = cdrDB),
      LoadFromHive[map_prov_contact_type](tableName = "MAP_PROV_CONTACT_TYPE", referenceName = None, hiveDatabase = cdrDB),
      LoadFromHive[map_provider_role](tableName = "MAP_PROVIDER_ROLE", referenceName = None, hiveDatabase = cdrDB),
      LoadFromHive[map_ptrep_med_category](tableName = "MAP_PTREP_MED_CATEGORY", referenceName = None, hiveDatabase = cdrDB),
      LoadFromHive[map_race](tableName = "MAP_RACE", referenceName = None, hiveDatabase = cdrDB),
      LoadFromHive[map_service](tableName = "MAP_SERVICE", referenceName = None, hiveDatabase = cdrDB),
      LoadFromHive[map_treatment_type](tableName = "MAP_TREATMENT_TYPE", referenceName = None, hiveDatabase = cdrDB),
      LoadFromHive[map_visit_charge](tableName = "MAP_VISIT_CHARGE", referenceName = None, hiveDatabase = cdrDB),
      LoadFromHive[map_visit_exclude](tableName = "MAP_VISIT_EXCLUDE", referenceName = None, hiveDatabase = cdrDB),
      LoadFromHive[map_prob_list](tableName = "MAP_PROB_LIST", referenceName = None, hiveDatabase = cdrDB),
      LoadFromHive[mpi_hum_rule](tableName = "MPI_HUM_RULE", referenceName = None, hiveDatabase = cdrDB),
      LoadFromHive[mpi_grp_rule](tableName = "MPI_GRP_RULE", referenceName = None, hiveDatabase = cdrDB),
      LoadFromHive[mv_client_data_src](tableName = "MV_CLIENT_DATA_SRC", referenceName = None, hiveDatabase = cdrDB),
      LoadFromHive[provider_classification](tableName = "PROVIDER_CLASSIFICATION", referenceName = None, hiveDatabase = cdrDB),
      LoadFromHive[ref_cmsnpi](tableName = "REF_CMSNPI", referenceName = None, hiveDatabase = cdrDB),
      LoadFromHive[ref_billtype_pos_xref](tableName = "REF_BILLTYPE_POS_XREF", referenceName = None, hiveDatabase = cdrDB),
      LoadFromHive[ref_map_ccs_icdx_dx](tableName = "REF_MAP_CCS_ICDX_DX", referenceName = None, hiveDatabase = cdrDB),
      LoadFromHive[ref_map_ccs_icdx_px](tableName = "REF_MAP_CCS_ICDX_PX", referenceName = None, hiveDatabase = cdrDB),
      LoadFromHive[ref_term_dict_loinc_partial](tableName = "REF_TERM_DICT_LOINC", referenceName = None, hiveDatabase = cdrDB),
      LoadFromHive[ref_ladmf](tableName = "REF_LADMF", referenceName = None, hiveDatabase = cdrDB),
      LoadFromHive[ref_imap_region](tableName = "REF_IMAP_REGION", referenceName = None, hiveDatabase = cdrDB),
      LoadFromHive[ref_primaryspecialty](tableName = "REF_PRIMARYSPECIALTY", referenceName = None, hiveDatabase = cdrDB),
      LoadFromHive[ref_vw_ref_drg_reference](tableName = "REF_VW_REF_DRG_REFERENCE", referenceName = None, hiveDatabase = cdrDB),
      LoadFromHive[zcm_client_ds_priority](tableName = "ZCM_CLIENT_DS_PRIORITY", referenceName = None, hiveDatabase = cdrDB),
      LoadFromHive[zcm_datasrc_priority](tableName = "ZCM_DATASRC_PRIORITY", referenceName = None, hiveDatabase = cdrDB),
      LoadFromHive[zcm_qualitative_results](tableName = "ZCM_QUALITATIVE_RESULTS", referenceName = None, hiveDatabase = cdrDB),
      LoadFromHive[zcm_provider_match_rule](tableName = "ZCM_PROVIDER_MATCH_RULE", referenceName = None, hiveDatabase = cdrDB),
      LoadFromHive[zcm_obstype](tableName = "ZCM_OBSTYPE", referenceName = None, hiveDatabase = cdrDB),
      LoadFromHive[unit_conversion](tableName = "UNIT_CONVERSION", referenceName = None, hiveDatabase = cdrDB),
      LoadFromHive[zh_facility_rollup](tableName = "ZH_FACILITY_ROLLUP", referenceName = None, hiveDatabase = cdrDB),
      LoadFromHive[org_rollup](tableName = "ORG_ROLLUP", referenceName = None, hiveDatabase = cdrDB),
      LoadFromHive[zo_specialty](tableName = "ZO_SPECIALTY", referenceName = None, hiveDatabase = cdrDB),
      LoadFromHive[ref_cpt4](tableName = "REF_CPT4", referenceName = None, hiveDatabase = cdrDB),
      LoadFromHive[ref_diag_codes](tableName = "REF_DIAG_CODES", referenceName = None, hiveDatabase = cdrDB),
      LoadFromHive[pat_id_xwalk](tableName = "PAT_ID_XWALK", referenceName = None, hiveDatabase = cdrDB),
      LoadFromHive[ref_hcpcs](tableName = "REF_HCPCS", referenceName = None, hiveDatabase = cdrDB),
      LoadFromHive[ref_icd9_px](tableName = "REF_ICD9_PX", referenceName = None, hiveDatabase = cdrDB),
      LoadFromHive[ref_icd0_px](tableName = "REF_ICD0_PX", referenceName = None, hiveDatabase = cdrDB),
      LoadFromHive[ref_ub04_rev_codes](tableName = "REF_UB04_REV_CODES", referenceName = None, hiveDatabase = cdrDB),
      LoadFromHive[zo_bpo_map_employer](tableName = "ZO_BPO_MAP_EMPLOYER", referenceName = None, hiveDatabase = cdrDB),
      LoadFromHive[map_coverage_status](tableName = "MAP_COVERAGE_STATUS", referenceName = None, hiveDatabase = cdrDB),
      LoadFromHive[map_dcc_cvx](tableName = "MAP_DCC_CVX", referenceName = None, hiveDatabase = cdrDB),
      LoadFromHive[map_denied_ind](tableName = "MAP_DENIED_IND", referenceName = None, hiveDatabase = cdrDB),
      LoadFromHive[map_generic_status](tableName = "MAP_GENERIC_STATUS", referenceName = None, hiveDatabase = cdrDB),
      LoadFromHive[map_formulary_indicator](tableName = "MAP_FORMULARY_INDICATOR", referenceName = None, hiveDatabase = cdrDB),
      LoadFromHive[map_hts_term](tableName = "MAP_HTS_TERM", referenceName = None, hiveDatabase = cdrDB),
      LoadFromHive[map_lab_codes](tableName = "MAP_LAB_CODES", referenceName = None, hiveDatabase = cdrDB),
      LoadFromHive[map_lab_loinc](tableName = "MAP_LAB_LOINC", referenceName = None, hiveDatabase = cdrDB),
      LoadFromHive[map_local_codetype](tableName = "MAP_LOCAL_CODETYPE", referenceName = None, hiveDatabase = cdrDB),
      LoadFromHive[map_smoking_cessation](tableName = "MAP_SMOKING_CESSATION", referenceName = None, hiveDatabase = cdrDB),
      LoadFromHive[map_smoking_status](tableName = "MAP_SMOKING_STATUS", referenceName = None, hiveDatabase = cdrDB),
      LoadFromHive[map_specialty](tableName = "MAP_SPECIALTY", referenceName = None, hiveDatabase = cdrDB),
      LoadFromHive[map_qual_num_result](tableName = "MAP_QUAL_NUM_RESULT", referenceName = None, hiveDatabase = cdrDB),
      LoadFromHive[map_qual_text_result](tableName = "MAP_QUAL_TEXT_RESULT", referenceName = None, hiveDatabase = cdrDB),
      LoadFromHive[map_tobacco_cessation](tableName = "MAP_TOBACCO_CESSATION", referenceName = None, hiveDatabase = cdrDB),
      LoadFromHive[map_unit](tableName = "MAP_UNIT", referenceName = None, hiveDatabase = cdrDB),
      LoadFromHive[map_tobacco_use](tableName = "MAP_TOBACCO_USE", referenceName = None, hiveDatabase = cdrDB),
      LoadFromHive[mv_hts_domain_concept](tableName = "MV_HTS_DOMAIN_CONCEPT", referenceName = None, hiveDatabase = cdrDB),
      LoadFromHive[zo_bpo_loinc_units](tableName = "ZO_BPO_LOINC_UNITS", referenceName = None, hiveDatabase = cdrDB),
      LoadFromHive[map_poa](tableName = "MAP_POA", referenceName = None, hiveDatabase = cdrDB),
      LoadFromHive[int_claim_labresult](tableName = "INT_CLAIM_LABRESULT", referenceName = None, hiveDatabase = cdrDB),
      LoadFromHive[zo_discharge_disposition](tableName = "ZO_DISCHARGE_DISPOSITION", referenceName = None, hiveDatabase = cdrDB),
      LoadFromHive[zo_place_of_service](tableName = "ZO_PLACE_OF_SERVICE", referenceName = None, hiveDatabase = cdrDB),
      LoadFromHive[zo_poa](tableName = "ZO_POA", referenceName = None, hiveDatabase = cdrDB),
      LoadFromHive[map_specialty_ii](tableName = "MAP_SPECIALTY_II", referenceName = None, hiveDatabase = cdrDB),
      LoadFromHive[map_ins_pat_type](tableName = "MAP_INS_PAT_TYPE", referenceName = None, hiveDatabase = cdrDB),
      LoadFromHive[map_risk_status](tableName = "MAP_RISK_STATUS", referenceName = None, hiveDatabase = cdrDB),
      LoadFromHive[map_pat_type_evidence](tableName = "MAP_PAT_TYPE_EVIDENCE", referenceName = None, hiveDatabase = cdrDB),
      LoadFromHive[map_pat_type_order](tableName = "MAP_PAT_TYPE_ORDER", referenceName = None, hiveDatabase = cdrDB),
      LoadFromHive[ref_hts_ndc_current](tableName = "REF_HTS_NDC_CURRENT", referenceName = None, hiveDatabase = cdrDB),
      LoadFromHive[zh_med_map_dcc](tableName = "ZH_MED_MAP_DCC", referenceName = None, hiveDatabase = cdrDB),
      LoadFromHive[ref_commercial_zipcodes](tableName = "REF_COMMERCIAL_ZIPCODES", referenceName = None, hiveDatabase = cdrDB),
      LoadFromHive[map_rx_fulfillment_type](tableName = "MAP_RX_FULFILLMENT_TYPE", referenceName = None, hiveDatabase = cdrDB),
      LoadFromHive[map_daw](tableName = "MAP_DAW", referenceName = None, hiveDatabase = cdrDB),
      LoadFromHive[zo_daw](tableName = "ZO_DAW", referenceName = None, hiveDatabase = cdrDB),
      LoadFromHive[zo_admit_source](tableName = "ZO_ADMIT_SOURCE", referenceName = None, hiveDatabase = cdrDB),
      LoadFromHive[unit_refrange_lab_map](tableName = "UNIT_REFRANGE_LAB_MAP", referenceName = None, hiveDatabase = cdrDB),
      LoadFromHive[unit_remap](tableName = "UNIT_REMAP", referenceName = None, hiveDatabase = cdrDB),
      LoadFromHive[v_metadata_lab](tableName = "V_METADATA_LAB", referenceName = None, hiveDatabase = cdrDB),
      LoadFromHive[zcm_lab_name_pattern](tableName = "ZCM_LAB_NAME_PATTERN", referenceName = None, hiveDatabase = cdrDB),
      LoadFromHive[zcm_credential_map_pattern](tableName = "ZCM_CREDENTIAL_MAP_PATTERN", referenceName = None, hiveDatabase = cdrDB),
      LoadFromHive[zh_specialty_tier](tableName = "ZH_SPECIALTY_TIER", referenceName = None, hiveDatabase = cdrDB),
      LoadFromHive[zcm_treatment_type](tableName = "ZCM_TREATMENT_TYPE", referenceName = None, hiveDatabase = cdrDB),
      LoadFromHive[mpi_data_src_build_sets](tableName = "MPI_DATA_SRC_BUILD_SETS", referenceName = None, hiveDatabase = cdrDB),
      LoadFromHive[ref_custom_proc_mapped_values](tableName = "REF_CUSTOM_PROC_MAPPED_VALUES", referenceName = None, hiveDatabase = cdrDB),
      LoadFromHive[ref_cms_assign_proc_cds](tableName = "REF_CMS_ASSIGN_PROC_CDS", referenceName = None, hiveDatabase = cdrDB),
      LoadFromHive[ref_cms_assign_spec_cds](tableName = "REF_CMS_ASSIGN_SPEC_CDS", referenceName = None, hiveDatabase = cdrDB)
    )
  }
}

object DeltaDependencies {
  def deltaInitialDependencies(cdrDB: String, namePrefix: String = "ECDR_") = {
    Seq(
      LoadFromHive[zh_provider_master_xref](tableName = "ZH_PROVIDER_MASTER_XREF", referenceName = Option(namePrefix + "ZH_PROVIDER_MASTER_XREF"), hiveDatabase = cdrDB),
      LoadFromHive[zh_provider](tableName = "ZH_PROVIDER", referenceName = Option(namePrefix + "ZH_PROVIDER"), hiveDatabase = cdrDB),
      LoadFromHive[patient_mpi](tableName = "PATIENT_MPI", referenceName = Option(namePrefix + "PATIENT_MPI"), hiveDatabase = cdrDB),
      LoadFromHive[mpi_custom](tableName = "MPI_CUSTOM", referenceName = Option(namePrefix + "MPI_CUSTOM"), hiveDatabase = cdrDB),
      LoadFromHive[mpi_custom](tableName = "MPI_CUSTOM_H328218", referenceName = Option(namePrefix + "MPI_CUSTOM_H328218"), hiveDatabase = cdrDB),
      LoadFromHive[mpi_custom](tableName = "MPI_CUSTOM_H430416", referenceName = Option(namePrefix + "MPI_CUSTOM_H430416"), hiveDatabase = cdrDB),
      LoadFromHive[mpi_custom](tableName = "MPI_CUSTOM_H451171", referenceName = Option(namePrefix + "MPI_CUSTOM_H451171"), hiveDatabase = cdrDB),
      LoadFromHive[mpi_custom](tableName = "MPI_CUSTOM_H542284", referenceName = Option(namePrefix + "MPI_CUSTOM_H542284"), hiveDatabase = cdrDB),
      LoadFromHive[mpi_custom](tableName = "MPI_CUSTOM_H557454", referenceName = Option(namePrefix + "MPI_CUSTOM_H557454"), hiveDatabase = cdrDB),
      LoadFromHive[mpi_custom](tableName = "MPI_CUSTOM_H592196", referenceName = Option(namePrefix + "MPI_CUSTOM_H592196"), hiveDatabase = cdrDB),
      LoadFromHive[mpi_custom](tableName = "MPI_CUSTOM_H941216", referenceName = Option(namePrefix + "MPI_CUSTOM_H941216"), hiveDatabase = cdrDB),
      LoadFromHive[mpi_custom](tableName = "MPI_CUSTOM_H969755", referenceName = Option(namePrefix + "MPI_CUSTOM_H969755"), hiveDatabase = cdrDB),
      LoadFromHive[mpi_custom](tableName = "MPI_CUSTOM_H984197", referenceName = Option(namePrefix + "MPI_CUSTOM_H984197"), hiveDatabase = cdrDB),
      LoadFromHive[mpi_custom](tableName = "MPI_CUSTOM_H984216", referenceName = Option(namePrefix + "MPI_CUSTOM_H984216"), hiveDatabase = cdrDB),
      LoadFromHive[mpi_dob](tableName = "MPI_DOB", referenceName = Option(namePrefix + "MPI_DOB"), hiveDatabase = cdrDB),
      LoadFromHive[mpi_dsid](tableName = "MPI_DSID", referenceName = Option(namePrefix + "MPI_DSID"), hiveDatabase = cdrDB),
      LoadFromHive[mpi_empi](tableName = "MPI_EMPI", referenceName = Option(namePrefix + "MPI_EMPI"), hiveDatabase = cdrDB),
      LoadFromHive[mpi_id](tableName = "MPI_ID_H984787", referenceName = Option(namePrefix + "MPI_ID_H984787"), hiveDatabase = cdrDB),
      LoadFromHive[mpi_id](tableName = "MPI_ID", referenceName = Option(namePrefix + "MPI_ID"), hiveDatabase = cdrDB),
      LoadFromHive[mpi_merge](tableName = "MPI_MERGE", referenceName = Option(namePrefix + "MPI_MERGE"), hiveDatabase = cdrDB),
      LoadFromHive[mpi_ssn](tableName = "MPI_SSN", referenceName = Option(namePrefix + "MPI_SSN"), hiveDatabase = cdrDB),
      LoadFromHive[patientaddr](tableName = "PATIENTADDR", referenceName = Option(namePrefix + "PATIENTADDR"), hiveDatabase = cdrDB),
      LoadFromHive[patientdetail](tableName = "PATIENTDETAIL_PREMATCH", referenceName = Option(namePrefix + "PATIENTDETAIL_PREMATCH"), hiveDatabase = cdrDB)
    )
  }
}

object BpoDependencies {
  def bpoInitialDependencies(cdrDB: String) = {
    Seq(
      LoadFromHive[patient_summary](tableName = "PATIENT_SUMMARY", referenceName = None, hiveDatabase = cdrDB),
      LoadFromHive[patient_summary_grp_mpi](tableName = "PATIENT_SUMMARY_GRP_MPI", referenceName = None, hiveDatabase = cdrDB),
      LoadFromHive[zh_prov_contact_summary](tableName = "ZH_PROV_CONTACT_SUMMARY", referenceName = None, hiveDatabase = cdrDB),
      LoadFromHive[zh_provider_master_xref](tableName = "ZH_PROVIDER_MASTER_XREF", referenceName = None, hiveDatabase = cdrDB),
      LoadFromHive[zh_provider_master](tableName = "ZH_PROVIDER_MASTER", referenceName = None, hiveDatabase = cdrDB),
      LoadFromHive[patient_mpi](tableName = "PATIENT_MPI", referenceName = None, hiveDatabase = cdrDB),
      LoadFromHive[schema_init](tableName = "SCHEMA_INIT", referenceName = None, hiveDatabase = cdrDB)
    )
  }

  def bpoCombinedDependencies(cdrDB: String) = {
    Seq(
      LoadFromHive[patient_mpi](tableName = "PATIENT_MPI", referenceName = None, hiveDatabase = cdrDB),
      LoadFromHive[schema_init](tableName = "SCHEMA_INIT", referenceName = None, hiveDatabase = cdrDB)
    )
  }
}

object NlpDependencies {
  def nlpInitialDependencies(nlpDB: String) = {
    Seq(
      LoadFromHive[concept_event_result_parent_2](tableName = "CONCEPT_EVENT_RESULT_PARENT_2", referenceName = None, hiveDatabase = nlpDB),
      LoadFromHive[concept_event_2](tableName = "CONCEPT_EVENT_2", referenceName = None, hiveDatabase = nlpDB)
    )
  }
}

/**
  * This object is no longer being used. This is only used in a unit test for validating the correctness of initial dependnecies
  */
object InitialDependencies {
  def allInitialDependencies(cdrDB: String, isCDRFE: Boolean = false, summaryEtlsOnly: Boolean = false, bpoEtlsOnly: Boolean = false, combinedEtls: Boolean = false, buildType: String =  "Monthly", ecdrHiveDb: String, nlpDB: String)  = {
    if (bpoEtlsOnly)
      DataTableDependencies.dataInitialDependencies(cdrDB, if (isCDRFE) "CDR_FE_" else "") ++ StaticDependencies.staticInitialDependencies(cdrDB) ++ BpoDependencies.bpoInitialDependencies(cdrDB)
    else if (isCDRFE) {
      DataTableDependencies.dataInitialDependencies(cdrDB, if (isCDRFE) "CDR_FE_" else "", isCDRFE) ++ StaticDependencies.staticInitialDependencies(cdrDB) ++ DeltaDependencies.deltaInitialDependencies(ecdrHiveDb) ++ NlpDependencies.nlpInitialDependencies(nlpDB)
    } else if (summaryEtlsOnly | ( combinedEtls & buildType.equalsIgnoreCase("delta"))) {
      DataTableDependencies.dataInitialDependencies(cdrDB) ++ StaticDependencies.staticInitialDependencies(cdrDB) ++ BeSummaryDependencies.cdrBeSummaryInitialDependencies(cdrDB)
    } else if (combinedEtls){
      DataTableDependencies.dataInitialDependencies(cdrDB) ++ StaticDependencies.staticInitialDependencies(cdrDB) ++ BpoDependencies.bpoCombinedDependencies(cdrDB) ++ BeSummaryDependencies.cdrBeSummaryInitialDependencies(cdrDB)
    } else {
      DataTableDependencies.dataInitialDependencies(cdrDB) ++ StaticDependencies.staticInitialDependencies(cdrDB) ++ BeEncounterDependencies.cdrBeEncounterInitialDependencies(cdrDB)
    }
  }
}
