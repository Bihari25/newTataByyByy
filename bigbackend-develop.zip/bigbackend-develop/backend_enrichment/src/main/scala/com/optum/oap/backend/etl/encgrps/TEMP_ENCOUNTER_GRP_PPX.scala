
package com.optum.oap.backend.etl.encgrps

import com.optum.oap.backend.cdrTempModel.temp_encounter_grp_ppx
import com.optum.oap.sparkdataloader.QueryAndMetadata


object TEMP_ENCOUNTER_GRP_PPX extends QueryAndMetadata[temp_encounter_grp_ppx] {
  override def name: String = "TEMP_ENCOUNTER_GRP_PPX"

  override def partitions: Int = 32

  override def sparkSql: String =
    """
      |select ENCOUNTER_GRP_NUM, max(prinpx) as prinpx , max(codetype) as codetype from (
      |select px.groupid, px.grp_mpi, ENCOUNTER_GRP_NUM, px.mappedcode as prinpx, px.encounterid, px.client_ds_id,localprincipleindicator
      |, CODETYPE, ICD_VER
      |  ,row_number() over (partition by px.groupid, px.grp_mpi, ENCOUNTER_GRP_NUM
      |               order by px.groupid, px.grp_mpi, ENCOUNTER_GRP_NUM
      |                  , case when encounteridtype = 'MASTER' then 1
      |                         when encounteridtype = 'ENCTR' then 2
      |                         when encounteridtype = 'ADD AS' then 3
      |                         when encounteridtype = 'ADD OT' then 4
      |                         when encounteridtype = 'ADD UN' then 5
      |                         when encounteridtype = 'ADD ER' then 6
      |                         when encounteridtype = 'ADD OB' then 7
      |                         when encounteridtype = 'ADD SD' then 8 else 9 end
      |                  , proceduredate desc, px.encounterid desc, px.mappedcode) as pxrank
      |from
      |TEMP_ENCOUNTER_PRINPX px
      |where localprincipleindicator = 'Y')
      |where pxrank = 1
      |group by ENCOUNTER_GRP_NUM
    """.stripMargin

  override def dependsOn: Set[String] = Set("TEMP_ENCOUNTER_PRINPX")
}
