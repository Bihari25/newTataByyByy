package com.optum.oap.backend.etl.bpo

import com.optum.oap.backend.cdrTempModel.{temp_bpo_prov_attr_spans, temp_bpo_provider_detail}
import com.optum.oap.backend.etl.common.IsSafeToNumber
import com.optum.oap.backend.loader.EnrichmentRunTimeVariables
import com.optum.oap.cdr.models._
import com.optum.oap.sparkdataloader.{RuntimeVariables, TableInfo, UserDefinedFunctionForDataLoader}
import org.apache.spark.sql.expressions.Window
import org.apache.spark.sql.functions.{coalesce, _}
import org.apache.spark.sql.types.{DoubleType, LongType, StringType}
import org.apache.spark.sql.{DataFrame, SparkSession}

object TEMP_BPO_PROV_ATTR_SPANS extends TableInfo[temp_bpo_prov_attr_spans]{

  override def name = "TEMP_BPO_PROV_ATTR_SPANS"

  override def dependsOn: Set[String] = Set("PP_BPO_MEMBER_DETAIL", "ZH_PROV_ATTRIBUTE", "TEMP_BPO_PROVIDER_DETAIL")

  override def createDataFrame(sparkSession: SparkSession, loadedDependencies: Map[String, DataFrame], udfMap: Map[String, UserDefinedFunctionForDataLoader], runtimeVariables: RuntimeVariables): DataFrame = {
    import com.optum.oap.backend.etl.common.Functions._
    import sparkSession.implicits._

    val ppBpoMemberDetail = loadedDependencies("PP_BPO_MEMBER_DETAIL").as[pp_bpo_member_detail]
    val tempZhProvAttribute = loadedDependencies("ZH_PROV_ATTRIBUTE").as[zh_prov_attribute]
    val tempBpoProviderDetail = loadedDependencies("TEMP_BPO_PROVIDER_DETAIL").as[temp_bpo_provider_detail]

    val grpid = EnrichmentRunTimeVariables(runtimeVariables).clientId

    val dfltDates = ppBpoMemberDetail
      .where($"healthplansource" === lit("PAYER"))
      .select(
        to_timestamp(trunc(min($"effectivedate"), "MONTH")).as("eff_date"),
        to_timestamp(last_day(max($"enddate"))).as("end_date")
      )

    val spanWindow = Window.partitionBy($"pa.master_hgprovid")

    val intermediateDf = tempZhProvAttribute.as("pa")
      .crossJoin(dfltDates.as("dd"))
      .where($"pa.eff_date" <= coalesce($"pa.end_date", $"dd.end_date"))
      .join(tempBpoProviderDetail.as("tmp"), when(IsSafeToNumber.isSafeToNumber($"tmp.providerid"), $"tmp.providerid").otherwise(null) === $"pa.master_hgprovid", "inner")
      .select(
        $"pa.master_hgprovid",
        $"dd.eff_date".as("init_date"),
        $"pa.eff_date",
        coalesce($"pa.end_date", $"dd.end_date").as("end_date"),
        max(coalesce($"pa.end_date", $"dd.end_date")).over(spanWindow).as("max_end_date")
      ).distinct

    val dataList = List("init_date","eff_date","end_date")

    val allDates = intermediateDf
      .select($"master_hgprovid",
        expr("stack(4,'init_date', init_date, 'eff_date', eff_date, 'end_date', end_date, 'next_start_date', end_date) as (date_type, date_value) "))
      .where($"date_type".isin(dataList: _*) || ($"date_type" === lit("next_start_date") && month(to_date($"date_value")) < month(to_date($"max_end_date"))))
      .select(
        $"master_hgprovid",
        when($"date_type" === lit("next_start_date"), date_add(last_day($"date_value"), 1))
          .otherwise(trunc($"date_value", "MONTH")).as("date_value")
      ).distinct

    val spanWindowDate = Window.partitionBy($"al.master_hgprovid").orderBy($"al.date_value")

    val allSpans = allDates.as("al")
      .select($"al.master_hgprovid",
        $"al.date_value".as("start_date"),
        coalesce(add_months(last_day(lead($"al.date_value", 1).over(spanWindowDate)), - 1), last_day($"al.date_value")).as("end_date"))

    val provAttr = tempZhProvAttribute
      .groupBy($"groupid", $"client_ds_id", $"localproviderid", $"master_hgprovid", $"eff_date", $"end_date", $"primary_span")
      .pivot("attribute_type_cui", Seq("CH002486", "CH002487", "CH002488", "CH002489", "CH002987", "CH002988", "CH003906", "CH003907", "CH003908", "CH003909", "CH003910", "CH003911", "CH003912", "CH003913", "CH003914", "CH003915", "CH003916", "CH003917", "CH003918", "CH003919", "CH004048", "CH004049"))
      .agg(max("attribute_value"))
      .select(
        $"groupid",
        $"client_ds_id",
        $"localproviderid",
        $"master_hgprovid",
        $"eff_date",
        $"end_date",
        $"CH002486".cast(StringType).as("cust_prov_attr1"),
        $"CH002487".cast(StringType).as("cust_prov_attr2"),
        $"CH002488".cast(StringType).as("cust_prov_attr3"),
        $"CH002489".cast(StringType).as("cust_prov_attr4"),
        $"CH002987".cast(StringType).as("cust_prov_attr5"),
        $"CH002988".cast(StringType).as("cust_prov_attr6"),
        $"CH003906".cast(StringType).as("cust_prov_attr7"),
        $"CH003907".cast(StringType).as("cust_prov_attr8"),
        $"CH003908".cast(StringType).as("cust_prov_attr9"),
        $"CH003909".cast(StringType).as("cust_prov_attr10"),
        $"CH003910".cast(StringType).as("cust_prov_attr11"),
        $"CH003911".cast(StringType).as("cust_prov_attr12"),
        $"CH003912".cast(StringType).as("cust_prov_attr13"),
        $"CH003913".cast(StringType).as("cust_prov_attr14"),
        $"CH003914".cast(StringType).as("cust_prov_attr15"),
        when(IsSafeToNumber.isSafeToNumber($"CH003915"),$"CH003915").cast(DoubleType).as("cust_prov_attr16"),
        when(IsSafeToNumber.isSafeToNumber($"CH003916"),$"CH003916").cast(DoubleType).as("cust_prov_attr17"),
        when(IsSafeToNumber.isSafeToNumber($"CH003917"),$"CH003917").cast(DoubleType).as("cust_prov_attr18"),
        when(IsSafeToNumber.isSafeToNumber($"CH003918"),$"CH003918").cast(DoubleType).as("cust_prov_attr19"),
        when(IsSafeToNumber.isSafeToNumber($"CH003919"),$"CH003919").cast(DoubleType).as("cust_prov_attr20"),
        when(length($"CH004048") <= 100, $"CH004048").cast(StringType).as("prov_userdef_1"),
        when(length($"CH004049") <= 30, $"CH004049").cast(StringType).as("prov_userdef_2"),
        $"primary_span"
      )

    val intermediateDf1 = allSpans.as("sp")
      .crossJoin(dfltDates.as("dd"))
      .join(provAttr.as("pa"), $"pa.master_hgprovid" === $"sp.master_hgprovid" && $"pa.eff_date" <= coalesce($"pa.end_date", current_date()) && $"pa.eff_date".between($"sp.start_date", $"sp.end_date"), "left")
      .select(
        $"sp.master_hgprovid",
        $"sp.start_date",
        $"sp.end_date",
        $"cust_prov_attr1",
        $"cust_prov_attr2",
        $"cust_prov_attr3",
        $"cust_prov_attr4",
        $"cust_prov_attr5",
        $"cust_prov_attr6",
        $"cust_prov_attr7",
        $"cust_prov_attr8",
        $"cust_prov_attr9",
        $"cust_prov_attr10",
        $"cust_prov_attr11",
        $"cust_prov_attr12",
        $"cust_prov_attr13",
        $"cust_prov_attr14",
        $"cust_prov_attr15",
        $"cust_prov_attr16",
        $"cust_prov_attr17",
        $"cust_prov_attr18",
        $"cust_prov_attr19",
        $"cust_prov_attr20",
        $"prov_userdef_1",
        $"prov_userdef_2",
        $"primary_span"
      ).distinct()

    val intermediateDf2 = allSpans.as("sp")
      .crossJoin(dfltDates.as("dd"))
      .join(provAttr.as("pa"), $"pa.master_hgprovid" === $"sp.master_hgprovid" && $"pa.eff_date" <= coalesce($"pa.end_date", current_date()) && coalesce($"pa.end_date", $"dd.end_date").between($"sp.start_date", $"sp.end_date"), "left")
      .select(
        $"sp.master_hgprovid",
        $"sp.start_date",
        $"sp.end_date",
        $"cust_prov_attr1",
        $"cust_prov_attr2",
        $"cust_prov_attr3",
        $"cust_prov_attr4",
        $"cust_prov_attr5",
        $"cust_prov_attr6",
        $"cust_prov_attr7",
        $"cust_prov_attr8",
        $"cust_prov_attr9",
        $"cust_prov_attr10",
        $"cust_prov_attr11",
        $"cust_prov_attr12",
        $"cust_prov_attr13",
        $"cust_prov_attr14",
        $"cust_prov_attr15",
        $"cust_prov_attr16",
        $"cust_prov_attr17",
        $"cust_prov_attr18",
        $"cust_prov_attr19",
        $"cust_prov_attr20",
        $"prov_userdef_1",
        $"prov_userdef_2",
        $"primary_span"
      ).distinct()

    val intermediateDf3 = allSpans.as("sp")
      .crossJoin(dfltDates.as("dd"))
      .join(provAttr.as("pa"), $"pa.master_hgprovid" === $"sp.master_hgprovid" && $"pa.eff_date" <= coalesce($"pa.end_date", current_date()) && $"sp.start_date" > $"pa.eff_date" && $"sp.end_date" <= coalesce($"pa.end_date", $"dd.end_date"), "left")
      .select(
        $"sp.master_hgprovid",
        $"sp.start_date",
        $"sp.end_date",
        $"cust_prov_attr1",
        $"cust_prov_attr2",
        $"cust_prov_attr3",
        $"cust_prov_attr4",
        $"cust_prov_attr5",
        $"cust_prov_attr6",
        $"cust_prov_attr7",
        $"cust_prov_attr8",
        $"cust_prov_attr9",
        $"cust_prov_attr10",
        $"cust_prov_attr11",
        $"cust_prov_attr12",
        $"cust_prov_attr13",
        $"cust_prov_attr14",
        $"cust_prov_attr15",
        $"cust_prov_attr16",
        $"cust_prov_attr17",
        $"cust_prov_attr18",
        $"cust_prov_attr19",
        $"cust_prov_attr20",
        $"prov_userdef_1",
        $"prov_userdef_2",
        $"primary_span"
      ).distinct()

    def attrWindow(attr: String) = Window.partitionBy($"master_hgprovid", $"start_date", $"end_date")
      .orderBy(when(upper($"primary_span") === lit("Y"), lit(1)).
      when(upper($"primary_span") === lit("N"), lit(3)).
      otherwise(lit(2))
      ,col(attr).desc)


    val intermediateRsltSet4 = intermediateDf1
      .union(intermediateDf2)
      .union(intermediateDf3)
      .select(lit(grpid).as("groupid"),
        $"master_hgprovid",
        $"start_date",
        $"end_date",
        collect_list($"cust_prov_attr1").over(attrWindow("cust_prov_attr1")).as("cust_prov_attr1"),
        collect_list($"cust_prov_attr2").over(attrWindow("cust_prov_attr2")).as("cust_prov_attr2"),
        collect_list($"cust_prov_attr3").over(attrWindow("cust_prov_attr3")).as("cust_prov_attr3"),
        collect_list($"cust_prov_attr4").over(attrWindow("cust_prov_attr4")).as("cust_prov_attr4"),
        collect_list($"cust_prov_attr5").over(attrWindow("cust_prov_attr5")).as("cust_prov_attr5"),
        collect_list($"cust_prov_attr6").over(attrWindow("cust_prov_attr6")).as("cust_prov_attr6"),
        collect_list($"cust_prov_attr7").over(attrWindow("cust_prov_attr7")).as("cust_prov_attr7"),
        collect_list($"cust_prov_attr8").over(attrWindow("cust_prov_attr8")).as("cust_prov_attr8"),
        collect_list($"cust_prov_attr9").over(attrWindow("cust_prov_attr9")).as("cust_prov_attr9"),
        collect_list($"cust_prov_attr10").over(attrWindow("cust_prov_attr10")).as("cust_prov_attr10"),
        collect_list($"cust_prov_attr11").over(attrWindow("cust_prov_attr11")).as("cust_prov_attr11"),
        collect_list($"cust_prov_attr12").over(attrWindow("cust_prov_attr12")).as("cust_prov_attr12"),
        collect_list($"cust_prov_attr13").over(attrWindow("cust_prov_attr13")).as("cust_prov_attr13"),
        collect_list($"cust_prov_attr14").over(attrWindow("cust_prov_attr14")).as("cust_prov_attr14"),
        collect_list($"cust_prov_attr15").over(attrWindow("cust_prov_attr15")).as("cust_prov_attr15"),
        collect_list($"cust_prov_attr16").over(attrWindow("cust_prov_attr16")).as("cust_prov_attr16"),
        collect_list($"cust_prov_attr17").over(attrWindow("cust_prov_attr17")).as("cust_prov_attr17"),
        collect_list($"cust_prov_attr18").over(attrWindow("cust_prov_attr18")).as("cust_prov_attr18"),
        collect_list($"cust_prov_attr19").over(attrWindow("cust_prov_attr19")).as("cust_prov_attr19"),
        collect_list($"cust_prov_attr20").over(attrWindow("cust_prov_attr20")).as("cust_prov_attr20"),
        collect_list($"prov_userdef_1").over(attrWindow("prov_userdef_1")).as("prov_userdef_1"),
        collect_list($"prov_userdef_2").over(attrWindow("prov_userdef_2")).as("prov_userdef_2")
    )

      .groupBy($"master_hgprovid", $"start_date", $"end_date")
      .agg(max($"cust_prov_attr1").getItem(0).as("cust_prov_attr1"),
        max($"cust_prov_attr2").getItem(0).as("cust_prov_attr2"),
        max($"cust_prov_attr3").getItem(0).as("cust_prov_attr3"),
        max($"cust_prov_attr4").getItem(0).as("cust_prov_attr4"),
        max($"cust_prov_attr5").getItem(0).as("cust_prov_attr5"),
        max($"cust_prov_attr6").getItem(0).as("cust_prov_attr6"),
        max($"cust_prov_attr7").getItem(0).as("cust_prov_attr7"),
        max($"cust_prov_attr8").getItem(0).as("cust_prov_attr8"),
        max($"cust_prov_attr9").getItem(0).as("cust_prov_attr9"),
        max($"cust_prov_attr10").getItem(0).as("cust_prov_attr10"),
        max($"cust_prov_attr11").getItem(0).as("cust_prov_attr11"),
        max($"cust_prov_attr12").getItem(0).as("cust_prov_attr12"),
        max($"cust_prov_attr13").getItem(0).as("cust_prov_attr13"),
        max($"cust_prov_attr14").getItem(0).as("cust_prov_attr14"),
        max($"cust_prov_attr15").getItem(0).as("cust_prov_attr15"),
        max($"cust_prov_attr16").getItem(0).as("cust_prov_attr16"),
        max($"cust_prov_attr17").getItem(0).as("cust_prov_attr17"),
        max($"cust_prov_attr18").getItem(0).as("cust_prov_attr18"),
        max($"cust_prov_attr19").getItem(0).as("cust_prov_attr19"),
        max($"cust_prov_attr20").getItem(0).as("cust_prov_attr20"),
        max($"prov_userdef_1").getItem(0).as("prov_userdef_1"),
        max($"prov_userdef_2").getItem(0).as("prov_userdef_2"))
      .select(
        lit(grpid).as("groupid"),
        $"master_hgprovid",
        $"start_date",
        $"end_date",
        $"cust_prov_attr1",
        $"cust_prov_attr2",
        $"cust_prov_attr3",
        $"cust_prov_attr4",
        $"cust_prov_attr5",
        $"cust_prov_attr6",
        $"cust_prov_attr7",
        $"cust_prov_attr8",
        $"cust_prov_attr9",
        $"cust_prov_attr10",
        $"cust_prov_attr11",
        $"cust_prov_attr12",
        $"cust_prov_attr13",
        $"cust_prov_attr14",
        $"cust_prov_attr15",
        $"cust_prov_attr16",
        $"cust_prov_attr17",
        $"cust_prov_attr18",
        $"cust_prov_attr19",
        $"cust_prov_attr20",
        $"prov_userdef_1",
        $"prov_userdef_2"
      )

    val windowIns = intermediateRsltSet4
      .groupBy($"master_hgprovid")
      .agg(
        collectListFromType[temp_bpo_prov_attr_spans](sparkSession).as("attrSpansList")
      )
      .as[AttrSpansPerHgProvId]
      .flatMap(attrSpansDoc => {
        val sortedByStartDate = attrSpansDoc.attrSpansList.sortWith {
          case (left, right) =>
            if(left.start_date == null) {
              false
            } else if(right.start_date == null) {
              true
            } else {
              left.start_date.before(right.start_date)
            }
        }
        val window = sortedByStartDate.foldLeft((Option.empty[temp_bpo_prov_attr_spans], Seq.empty[temp_bpo_prov_attr_spans])) {
          case((prevOption, finished), current) =>
            if(prevOption.isEmpty) {
              (Some(current), finished)
            } else {
              val prev = prevOption.get
              if (
                  nullTo0(current.cust_prov_attr1) == nullTo0(prev.cust_prov_attr1) &&
                  nullTo0(current.cust_prov_attr2) == nullTo0(prev.cust_prov_attr2) &&
                  nullTo0(current.cust_prov_attr3) == nullTo0(prev.cust_prov_attr3) &&
                  nullTo0(current.cust_prov_attr4) == nullTo0(prev.cust_prov_attr4) &&
                  nullTo0(current.cust_prov_attr5) == nullTo0(prev.cust_prov_attr5) &&
                  nullTo0(current.cust_prov_attr6) == nullTo0(prev.cust_prov_attr6) &&
                  nullTo0(current.cust_prov_attr7) == nullTo0(prev.cust_prov_attr7) &&
                  nullTo0(current.cust_prov_attr8) == nullTo0(prev.cust_prov_attr8) &&
                    nullTo0(current.cust_prov_attr9) == nullTo0(prev.cust_prov_attr9) &&
                    nullTo0(current.cust_prov_attr10) == nullTo0(prev.cust_prov_attr10) &&
                    nullTo0(current.cust_prov_attr11) == nullTo0(prev.cust_prov_attr11) &&
                    nullTo0(current.cust_prov_attr12) == nullTo0(prev.cust_prov_attr12) &&
                    nullTo0(current.cust_prov_attr13) == nullTo0(prev.cust_prov_attr13) &&
                    nullTo0(current.cust_prov_attr14) == nullTo0(prev.cust_prov_attr14) &&
                    nullTo0(current.cust_prov_attr15) == nullTo0(prev.cust_prov_attr15) &&
                    current.cust_prov_attr16 == prev.cust_prov_attr16 &&
                    current.cust_prov_attr17 == prev.cust_prov_attr17 &&
                    current.cust_prov_attr18 == prev.cust_prov_attr18 &&
                    current.cust_prov_attr19 == prev.cust_prov_attr19 &&
                    current.cust_prov_attr20 == prev.cust_prov_attr20 &&
                    nullTo0(current.prov_userdef_1) == nullTo0(prev.prov_userdef_1) &&
                    nullTo0(current.prov_userdef_2) == nullTo0(prev.prov_userdef_2)
              ) {
                (Some(prev.copy(end_date = current.end_date)),finished)
              } else {
                (Some(current),finished :+ prev)
              }
            }
        }
        val result = window._1 match {
          case Some(lastWindow) => window._2 :+ lastWindow
          case None => window._2
        }
        result

      })

    windowIns.toDF().select($"*").orderBy($"groupid", $"master_hgprovid", $"start_date", $"end_date")
  }

}

case class AttrSpansPerHgProvId(master_hgprovid: String, attrSpansList: Seq[temp_bpo_prov_attr_spans])
