package com.optum.oap.backend.etl.patient_matching.data_table

import com.optum.oap.backend.cdrTempModel.pat_match_prep
import com.optum.oap.backend.etl.common.{CDRConstants, CleanPatientName, EnrichmentUtils}
import com.optum.oap.backend.loader.EnrichmentRunTimeVariables
import com.optum.oap.cdr.models.mpi_custom
import com.optum.oap.sparkdataloader.{RuntimeVariables, TableInfo, UserDefinedFunctionForDataLoader}
import org.apache.spark.sql.expressions.Window
import org.apache.spark.sql.functions._
import org.apache.spark.sql.types.{IntegerType, LongType, StringType}
import org.apache.spark.sql.{DataFrame, SparkSession}

object MPI_CUSTOM_H328218 extends TableInfo[mpi_custom] {

  override def dependsOn = Set("PAT_MATCH_PREP", "ECDR_MPI_CUSTOM_H328218")

  override def name = "MPI_CUSTOM_H328218"

  override def createDataFrame(sparkSession: SparkSession,
                               loadedDependencies: Map[String, DataFrame],
                               udfMap: Map[String, UserDefinedFunctionForDataLoader],
                               runtimeVariables: RuntimeVariables): DataFrame = {
    import sparkSession.implicits._

    val dailyBuild = if (runtimeVariables.asInstanceOf[EnrichmentRunTimeVariables].buildType == CDRConstants.DELTA_BUILD_TYPE) true else false

    val tempPatMatchPrep = loadedDependencies("PAT_MATCH_PREP").as[pat_match_prep]

    val tempPatAttrs_DF = tempPatMatchPrep
      .where($"dob".isNotNull)
      .select(
        $"groupid",
        $"client_ds_id",
        $"patientid",
        $"hgpid",
        $"dob",
        upper($"fname").as("first_name"),
        upper($"lname").as("last_name"),
        CleanPatientName.cleanPatientName($"fname", lit(3)).as("fname"),
        CleanPatientName.cleanPatientName($"lname", lit(3)).as("lname")
      ).distinct

    val dobGrouping = tempPatAttrs_DF.as("t").
      groupBy($"dob")
      .agg(
        size(collect_set("hgpid")).as("hgpids")
      ).select(
      $"dob",
      $"hgpids"
    )

    val dobWindow = Window.partitionBy($"dob")
    val subSelect_DF = tempPatAttrs_DF.as("p")
      .join(dobGrouping.as("dg"), Seq("dob"))
      .select(
        $"p.groupid",
        $"p.client_ds_id",
        $"p.patientid",
        $"p.hgpid",
        $"p.dob".as("key_attr"),
        $"p.fname".as("attr_2"),
        $"p.lname".as("attr_3"),
        substring($"p.fname", 1, 3).as("attr_4"),
        substring($"p.lname", 1, 3).as("attr_5"),
        substring($"p.fname", 1, 5).as("attr_6"),
        upper(regexp_extract($"fname", "^([^ ,]{1,})", 1)).as("attr_7"),
        $"p.first_name".as("attr_8"),
        $"p.last_name".as("attr_9"),
        lit(null).cast(StringType).as("attr_10"),
        substring($"p.lname", 1, 13).as("attr_11"),
        substring($"p.fname", 1, 8).as("attr_12"),
        $"dg.hgpids".cast(LongType).as("hgpids"),
        lit(1).cast(IntegerType).as("group_cnt")
      )

    val dataDf = subSelect_DF.as("x").select(
      $"x.groupid",
      $"x.client_ds_id",
      $"x.patientid",
      $"x.hgpid",
      $"x.key_attr",
      when(
        upper($"x.attr_2").isInCollection(CDRConstants.BABY_INDICATORS), lit(null).cast(StringType)
      ).otherwise($"x.attr_2").as("attr_2"),
      $"x.attr_3",
      $"x.attr_4",
      $"x.attr_5",
      $"x.attr_6",
      when(
        upper($"x.attr_7").isInCollection(CDRConstants.BABY_INDICATORS), lit(null).cast(StringType)
      ).otherwise($"x.attr_7").as("attr_7"),
      $"x.attr_8",
      $"x.attr_9",
      $"x.attr_10",
      $"x.attr_11",
      when(
        upper($"x.attr_12").isInCollection(CDRConstants.BABY_INDICATORS), lit(null).cast(StringType)
      ).otherwise($"x.attr_12").as("attr_12"),
      $"x.group_cnt",
      $"x.hgpids"
    )

    val ecdrDf = {
      if (dailyBuild) EnrichmentUtils.removeRowSourceAndModifiedDate(loadedDependencies("ECDR_MPI_CUSTOM_H328218")).as[mpi_custom]
      else sparkSession.emptyDataset[mpi_custom].as[mpi_custom]
    }.as("e")
      .select($"e.*")

    dataDf.unionByName(ecdrDf).distinct()
  }
}
