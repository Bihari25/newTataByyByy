package com.optum.oap.backend.etl.encgrps

import com.optum.oap.cdr.models.diag_icd_encgrp
import com.optum.oap.sparkdataloader.QueryAndMetadata

object DIAG_ICD_ENCGRP extends QueryAndMetadata[diag_icd_encgrp] {
  override def name: String = "DIAG_ICD_ENCGRP"

  override def partitions: Int = 32

  override def sparkSql: String =
    """
      | SELECT DISTINCT
      |    codetype,
      |    mappeddiagnosis,
      |    cui,
      |    is_ambulatory,
      |    cnt
      |  FROM
      |    mapdiag_icd
    """.stripMargin

  override def dependsOn: Set[String] = Set("MAPDIAG_ICD")
}

