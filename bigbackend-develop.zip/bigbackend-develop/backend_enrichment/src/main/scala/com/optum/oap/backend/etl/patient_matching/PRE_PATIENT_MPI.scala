package com.optum.oap.backend.etl.patient_matching

import com.optum.oap.backend.cdrTempModel.patient_xref
import com.optum.oap.backend.etl.common.{CDRConstants, EnrichmentUtils}
import com.optum.oap.backend.loader.EnrichmentRunTimeVariables
import com.optum.oap.cdr.models._
import com.optum.oap.sparkdataloader.{RuntimeVariables, TableInfo, UserDefinedFunctionForDataLoader}
import org.apache.spark.sql.expressions.Window
import org.apache.spark.sql.functions._
import org.apache.spark.sql.types.IntegerType
import org.apache.spark.sql.{DataFrame, SparkSession}
import org.slf4j.LoggerFactory

import scala.annotation.tailrec
import scala.collection.mutable

/**
  * Creator: bishu
  * Date: 10/12/20
  */
object PRE_PATIENT_MPI extends TableInfo[patient_mpi] {
  val log = LoggerFactory.getLogger(this.getClass)

  override def partitions: Int = 128

  override def dependsOn = Set(
    "PATIENT_MPI_ALL_RULES",
    "PATIENT_XWALK_MAPPING",
    "V_PATIENT_XREF",
    "MV_CLIENT_DATA_SRC",
    "QGATE_PATIENT_ID_FILTER",
    "ECDR_PATIENT_MPI"
  )

  val seperator = ":"

  override def createDataFrame(sparkSession: SparkSession,
                               loadedDependencies: Map[String, DataFrame],
                               udfMap: Map[String, UserDefinedFunctionForDataLoader],
                               runtimeVariables: RuntimeVariables): DataFrame = {
    import sparkSession.implicits._

    val patient_mpi_all_rules_Df = loadedDependencies("PATIENT_MPI_ALL_RULES").as[patient_mpi_all_rules]
    val patient_Df = loadedDependencies("PATIENT_XWALK_MAPPING").as[patient]
    val patient_xref_Df = loadedDependencies("V_PATIENT_XREF").as[patient_xref]
    val mv_client_data_src_Df = broadcast(loadedDependencies("MV_CLIENT_DATA_SRC").as[mv_client_data_src])
    val qgate_patient_id_filter_Df = loadedDependencies("QGATE_PATIENT_ID_FILTER").as[qgate_patient_id_filter]
    val grpid = EnrichmentRunTimeVariables(runtimeVariables).clientId

    val dailyBuild = if (runtimeVariables.asInstanceOf[EnrichmentRunTimeVariables].buildType == CDRConstants.DELTA_BUILD_TYPE) true else false

    val calcDf = patient_mpi_all_rules_Df
      .groupBy($"groupid", $"client_ds_id", $"patientid", $"hgpid", $"grp_mpi")
      .agg(
        max($"match_cnt").as("match_cnt"),
        min($"rule_nbr").as("rule_nbr"),
        max($"score").as("score")
      ).select(
      $"groupid",
      $"client_ds_id",
      $"patientid",
      $"hgpid",
      $"grp_mpi",
      $"match_cnt",
      $"rule_nbr",
      $"score"
    )

    val filteredDF = calcDf.as("a")
      .join(patient_xref_Df.as("x"), $"a.grp_mpi" === $"x.hgpid")
      .join(mv_client_data_src_Df.as("cds"), $"x.groupid" === $"cds.client_id" && $"x.client_ds_id" === $"cds.client_data_src_id")
      .select(
        $"a.groupid",
        $"a.client_ds_id",
        $"a.patientid",
        $"a.hgpid",
        $"a.grp_mpi",
        $"a.match_cnt",
        $"a.rule_nbr",
        $"a.score"
      )

    val groupedByHgpid = filteredDF.as("fe")
      .groupBy($"fe.hgpid".as("hgpid"))
      .agg(collect_list(struct(classOf[patient_mpi_all_rules].getDeclaredFields.toList.withFilter(!_.isSynthetic()).map(f => $"${f.getName}"): _*)).as("mpiRuleList"))
      .as[all_rules_by_hgpid]
      .flatMap(grpByHgpids => {
        val allSortedMatches = grpByHgpids.mpiRuleList.sorted[patient_mpi_all_rules](new Ordering[patient_mpi_all_rules] {
          def compare(x: patient_mpi_all_rules, y: patient_mpi_all_rules): Int = {
            val comparebyGrpmpi = x.grp_mpi.toLong compareTo y.grp_mpi.toLong
            if (comparebyGrpmpi != 0) comparebyGrpmpi
            else x.rule_nbr.toInt compareTo x.rule_nbr.toInt
          }
        })
        val allGrpmpis = allSortedMatches.map(pm => pm.grp_mpi).toSet.reduce(_ + seperator + _)
        val lg = allSortedMatches.head
        Seq(
          patient_mpi_all_rules_more(groupid = lg.groupid, client_ds_id = lg.client_ds_id, patientid = lg.patientid, hgpid = lg.hgpid, grp_mpi = lg.grp_mpi, match_cnt = lg.match_cnt, rule_nbr = lg.rule_nbr, score = lg.score, associated_ids = allGrpmpis)
        )
      })
      .select(
        $"groupid",
        $"client_ds_id",
        $"patientid",
        $"hgpid",
        $"grp_mpi",
        $"match_cnt",
        $"rule_nbr",
        $"score",
        $"associated_ids"
      )

    val oldGrpmpi2NewGrpmpiMapping = generateMappingOfOldtoNewGrpmpi(sparkSession, groupedByHgpid)

    val resolvedGrpMpiDf = groupedByHgpid.as("x")
      .join(oldGrpmpi2NewGrpmpiMapping.as("y"), $"x.grp_mpi" === $"y.oldgrpmpi", "left")
      .select(
        $"x.groupid",
        $"x.client_ds_id",
        $"x.patientid",
        $"x.hgpid",
        coalesce($"y.newgrpmpi", $"x.grp_mpi").as("grp_mpi"),
        $"x.match_cnt",
        $"x.rule_nbr",
        $"x.score"
      )

    val tmpDf1 = patient_Df.as("pat")
      .join(patient_xref_Df.as("pxf"), Seq("groupid", "client_ds_id", "patientid"))
      .select(
        $"pat.groupid".as("groupid"),
        $"pat.client_ds_id".as("client_ds_id"),
        $"pat.patientid".as("patientid"),
        $"pxf.hgpid".as("hgpid")
      )
      .distinct()

    val tmpDf2 = resolvedGrpMpiDf.as("mpi").select($"groupid", $"hgpid").distinct()

    val onlyInPatientTable = tmpDf1.as("ps")
      .join(tmpDf2.as("mpi"), Seq("hgpid", "groupid"), "left")
      .where($"mpi.hgpid".isNull)
      .join(qgate_patient_id_filter_Df.as("pf"), Seq("groupid", "client_ds_id", "patientid"), "left")
      .where($"pf.groupid".isNull)
      .select(
        $"ps.groupid",
        $"ps.client_ds_id",
        $"ps.patientid",
        $"ps.hgpid",
        $"ps.hgpid".as("grp_mpi"),
        lit(0).as("match_cnt"),
        lit(null).cast(IntegerType).as("rule_nbr"),
        lit(null).cast(IntegerType).as("score")
      )

    val allPatientDf = resolvedGrpMpiDf.union(onlyInPatientTable)

    val dataDf = {
      if (grpid.equalsIgnoreCase("H667594")) filter_mpi_results(sparkSession = sparkSession, patientMpi = allPatientDf, groupid = grpid, clientDsId = "57", requireAll = false, minDsCnt = 1)
      else if (grpid.equalsIgnoreCase("H729838")) filter_mpi_results(sparkSession = sparkSession, patientMpi = allPatientDf, groupid = grpid, clientDsId = "3069,3262,3123,3941,4243,4242,4442,4582,4581", requireAll = false, minDsCnt = 1)
      else allPatientDf
    }

    val resultDf = {
      if (dailyBuild) {
        val ecdrData = EnrichmentUtils.removeRowSourceAndModifiedDate(loadedDependencies("ECDR_PATIENT_MPI"))

        // find new patient ids that are seen today and append to all the ones found till yesterday
        val newIds = dataDf.as("m")
          .join(ecdrData.as("e"), $"m.hgpid" === $"e.hgpid", "left_anti")
          .select($"m.*")

        ecdrData.unionByName(newIds)
      } else dataDf
    }

    resultDf
  }

  // generate a mapping of old grpmpi to new grpmpi
  def generateMappingOfOldtoNewGrpmpi(sparkSession: SparkSession, groupedByHpgid: DataFrame): DataFrame = {
    import sparkSession.implicits._

    val collectedByGrpmpis = groupedByHpgid.groupBy($"groupid", $"grp_mpi")
      .agg(
        concat_ws(seperator, collect_set($"associated_ids")).as("associated_ids")
      ).select($"groupid", concat_ws(seperator, array_distinct(split($"associated_ids", seperator))).as("associated_ids"), $"grp_mpi".as("potential_grp_mpi"))

    val old_to_new_mapping_df = collectedByGrpmpis
      .groupBy($"groupid")
      .agg(collect_list(struct(classOf[potential_mapping].getDeclaredFields.toList.withFilter(!_.isSynthetic()).map(f => $"${f.getName}"): _*)).as("allRows"))
      .as[grouped_potential_mapping]
      .flatMap(data => {
        val allRowsInput = data.allRows.map(x => potential_mapping_enhanced(associated_ids_set = x.associated_ids.split(seperator).toSet, potential_grp_mpi = x.potential_grp_mpi))
        val resolvedAll = mergeGrpmpi(allRowsInput)

        val transformedResult = for {
          i <- resolvedAll
          j <- i.associated_ids_set
        } yield old_to_new_mapping(oldgrpmpi = j, newgrpmpi = i.potential_grp_mpi)
        transformedResult
      }
      )

    val calculatedMapping = old_to_new_mapping_df.groupBy($"oldgrpmpi")
      .agg(
        min($"newgrpmpi").as("newgrpmpi")
      ).select(
      $"oldgrpmpi",
      $"newgrpmpi"
    )

    calculatedMapping
  }

  def filter_mpi_results(sparkSession: SparkSession, patientMpi: DataFrame, groupid: String, clientDsId: String, requireAll: Boolean, minDsCnt: Integer): DataFrame = {

    import sparkSession.implicits._

    val dsCount = if (requireAll) clientDsId.replaceAll("[^,]", "").length() + 1
    else 1

    val clientDsIds: List[Int] = clientDsId.split(",").toList.map(x => x.toInt)
    val groupIdWindow = Window.partitionBy($"groupid", $"grp_mpi")

    val dsListCount = if (requireAll) {
      size(collect_set(when($"client_ds_id".isin(clientDsIds: _*), $"client_ds_id").otherwise(lit(null))).over(groupIdWindow))
    }
    else {
      max(when($"client_ds_id".isin(clientDsIds: _*), lit(1)).otherwise(lit(0))).over(groupIdWindow)
    }
    val dsIdClause = $"ds_list_cnt" >= lit(dsCount)

    val dsCountCheck = {
      if (minDsCnt > 1) size(collect_set($"client_ds_id").over(groupIdWindow)).as("ds_id_cnt")
      else lit(null).as("ds_id_cnt")
    }

    val dsCountWhere = {
      if (minDsCnt > 1) $"ds_id_cnt" >= minDsCnt
      else lit(true)
    }

    if (clientDsId != null) {
      val temp = patientMpi
        .withColumn("ds_list_cnt", dsListCount)
        .withColumn("ds_id_cnt", dsCountCheck)
      temp
        .where($"groupid" === groupid && dsIdClause && dsCountWhere)
        .select(
          $"groupid",
          $"client_ds_id",
          $"patientid",
          $"hgpid",
          $"grp_mpi",
          $"match_cnt",
          $"rule_nbr",
          $"score"
        )
    }
    else {
      Seq.empty[patient_mpi].toDF()
    }
  }

  def mergeGrpmpi(inp: Seq[potential_mapping_enhanced]): Seq[potential_mapping_enhanced] = {
    @tailrec
    def resolveDependency(cnt: Int, input: Seq[potential_mapping_enhanced]): Seq[potential_mapping_enhanced] = {
      if (cnt >= CDRConstants.PATIENT_MPI_MAX_ITERATION) input
      else {
        val mergedData = input

        //construct a map for lookup
        val m1: mutable.HashMap[String, String] = mutable.HashMap()
        var recordUpdated = 0
        for {
          x <- mergedData
          y <- x.associated_ids_set
        } yield {
          if (m1.contains(y)) {
            val old_min = m1(y)
            val new_min = if (x.potential_grp_mpi.toLong < old_min.toLong) x.potential_grp_mpi else old_min
            m1.put(y, new_min)
          } else {
            m1.put(y, x.potential_grp_mpi)
          }
        }

        val translated_sequence = mergedData.map(x => {
          val gps = x.associated_ids_set
          // get smallest of all the grouping set
          val sg = gps.map(x => m1(x).toLong).min
          // calculate new grouping set and minimum
          val newMin = if (sg < x.potential_grp_mpi.toLong) sg else x.potential_grp_mpi.toLong
          val nd = {
            if (newMin < x.potential_grp_mpi.toLong) {
              val newGrpSet = x.associated_ids_set ++ Set(newMin.toString)
              recordUpdated = recordUpdated + 1
              potential_mapping_enhanced(newGrpSet, newMin.toString)
            } else x
          }
          nd
        })
        if (recordUpdated < 1) translated_sequence
        else resolveDependency(cnt + 1, translated_sequence)
      }
    }

    val result = resolveDependency(0, inp)

    result.distinct
  }


  case class old_to_new_mapping(oldgrpmpi: String, newgrpmpi: String)

  case class potential_mapping(associated_ids: String, potential_grp_mpi: String) // @param associated_ids ":" seperated list of ids which are grouped together

  case class potential_mapping_enhanced(associated_ids_set: Set[String], potential_grp_mpi: String) // enhanced version of potential_mapping for easy comparision

  case class grouped_potential_mapping(groupId: String, allRows: Seq[potential_mapping])

  case class grouped_associatedids(associated_ids: String, mappingList: Seq[potential_mapping])

  case class all_rules_by_hgpid(hgpid: String, mpiRuleList: Seq[patient_mpi_all_rules])

  case class patient_mpi_all_rules_more(client_ds_id: java.lang.Integer = null, groupid: String = null, grp_mpi: String = null, hgpid: java.lang.Long = null, match_cnt: java.lang.Integer = null, patientid: String = null, rule_nbr: java.lang.Integer = null, score: java.lang.Integer = null, associated_ids: String = null)

}
