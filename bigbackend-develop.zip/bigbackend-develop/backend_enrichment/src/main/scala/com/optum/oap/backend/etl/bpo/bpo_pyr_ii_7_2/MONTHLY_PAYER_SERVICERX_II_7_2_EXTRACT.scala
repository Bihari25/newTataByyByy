package com.optum.oap.backend.etl.bpo.bpo_pyr_ii_7_2

import com.optum.oap.backend.cdrTempModel.monthly_payer_servicerx_ii_7_2_extract
import com.optum.oap.cdr.models._
import com.optum.oap.sparkdataloader.{RuntimeVariables, TableInfo, UserDefinedFunctionForDataLoader}
import org.apache.spark.sql.functions._
import org.apache.spark.sql.types.StringType
import org.apache.spark.sql.{DataFrame, SparkSession}

object MONTHLY_PAYER_SERVICERX_II_7_2_EXTRACT extends TableInfo[monthly_payer_servicerx_ii_7_2_extract] {

  override def dependsOn = Set("NETWRK_PAID_STATUS_ROLLUP", "PROV_STATUS_ROLLUP", "MAP_PREDICATE_VALUES", "PP_BPO_PHARMACY_CLAIMS", "PP_BPO_MEMBER_DETAIL", "PP_BPO_MEMBER_DETAIL_II")

  override def name = "MONTHLY_PAYER_SERVICERX_II_7_2_EXTRACT"

  override def createDataFrame(sparkSession: SparkSession,
                               loadedDependencies: Map[String, DataFrame],
                               udfMap: Map[String, UserDefinedFunctionForDataLoader],
                               runtimeVariables: RuntimeVariables): DataFrame = {

    import sparkSession.implicits._

    val ppBpoPharmacyClaims = loadedDependencies("PP_BPO_PHARMACY_CLAIMS").where($"healthplansource" === "PAYER").as[pp_bpo_pharmacy_claims]
    val ppBpoMemberDetail = loadedDependencies("PP_BPO_MEMBER_DETAIL").as[pp_bpo_member_detail]
    val ppBpoMemberDetailII = loadedDependencies("PP_BPO_MEMBER_DETAIL_II").as[pp_bpo_member_detail_ii]
    val provStatusRollUp = loadedDependencies("PROV_STATUS_ROLLUP").as[prov_status_rollup]
    val netwrkPaidStatusRollup = broadcast(loadedDependencies("NETWRK_PAID_STATUS_ROLLUP").as[netwrk_paid_status_rollup])
    val mapPredicateValues = broadcast(loadedDependencies("MAP_PREDICATE_VALUES")).as[map_predicate_values]

    val psr_df = provStatusRollUp.select($"prov_status_rollup", $"prov_status_id").distinct()
    val nspr_df = netwrkPaidStatusRollup.select($"network_paid_status_rollup", $"network_paid_status").distinct()
    val mpv_df = mapPredicateValues
      .where($"data_src" === "OADW" && $"table_name" === "PP_BPO_MEDICAL_CLAIMS" && $"entity" === "PP_BPO_MEDICAL_CLAIMS" && $"column_name" === "CLM_PASS")
      .select($"groupid").withColumn("mpv_exists", lit("Y")).distinct()

    val result_DF = ppBpoPharmacyClaims.alias("clm")
      .join(ppBpoMemberDetail.as("mbr"), $"mbr.memberid" === $"clm.memberid" && $"mbr.healthplansource" === $"clm.healthplansource" && $"clm.servicedate".between($"mbr.effectivedate", $"mbr.enddate"), "left")
      .join(ppBpoMemberDetailII.as("ii"), $"ii.memberid" === $"clm.memberid" && $"ii.healthplansource" === $"clm.healthplansource" && $"clm.servicedate".between($"ii.effectivedate", $"ii.enddate") && $"clm.employeraccountid" === $"ii.employeraccountid", "left_outer")
      .join(psr_df.alias("psr"), $"psr.prov_status_id" === $"clm.provider_status", "left")
      .join(nspr_df.as("nspr"), $"nspr.network_paid_status" === $"clm.network_paid_status", "left")
      .join(mpv_df.as("mpv"), $"mpv.groupid" === $"clm.groupid", "left")
      .where($"clm.healthplansource" === "PAYER" && ($"mpv.mpv_exists" === "Y" || $"clm.employeraccountid" === $"mbr.employeraccountid" || $"ii.memberid".isNotNull))
      .select($"clm.memberid".as("member"),
        $"claimheader".as("clm_id_n"),
        date_format($"servicedate", "yyyy-MM-dd").as("dos"),
        date_format($"paymentdate", "yyyy-MM-dd").as("pay_dt"),
        $"ndc".as("ndc"),
        coalesce($"quantity", lit(0)).cast(StringType).as("met_qty"),
        when($"prescprovider" === 0, 999).otherwise($"prescprovider").as("pres_prv"),
        $"pharmacyid".as("provider"),
        $"dea".as("dea"),
        coalesce($"dayssupply", lit(0)).cast(StringType).as("day_sup"),
        $"formulary".as("formulary"),
        $"pharmacytype".as("channel"),
        substring_index($"claimheader", ".", -1).as("uniq_rec_id"),
        $"genericstatus".as("gbo"),
        coalesce($"coinsamount", lit(0)).cast(StringType).as("amt_coin"),
        coalesce($"copayamount", lit(0)).cast(StringType).as("amt_cop"),
        coalesce($"deductamount", lit(0)).cast(StringType).as("amt_ded"),
        coalesce($"allowedamount", lit(0)).cast(StringType).as("amt_eqv"),
        round(coalesce($"paidamount", lit(0)), 2).cast(StringType).as("amt_pay"),
        coalesce($"requestedamount", lit(0)).cast(StringType).as("amt_req"),
        coalesce($"patliabamount", lit(0)).cast(StringType).as("amt_liab"),
        lit(null).cast(StringType).cast(StringType).as("amt_np"),
        $"other_1_amt".cast(StringType).as("amt_oth1"),
        $"other_2_amt".cast(StringType).as("amt_oth2"),
        $"other_3_amt".cast(StringType).as("amt_oth3"),
        $"other_4_amt".cast(StringType).as("amt_oth4"),
        when($"pseudoflag" === "Y" || $"pseudoflag" === "1" || $"deniedflag" === 'Y' || $"deniedflag" === '1', 1).otherwise(0).cast(StringType).as("pseudo"),
        when($"network_paid_status_rollup" === "Y" || $"network_paid_status_rollup" === "1", 1).otherwise(0).cast(StringType).as("network_status"),
        $"clm.network_paid_status".as("network_paid_status"),
        $"provider_status".as("provider_status"),
        $"clm.contract_id".as("contract"),
        $"denied_ind".as("denied_ind"),
        $"spec_rx_ind".as("spec_rx_n"),
        coalesce($"daw", lit(0)).cast(StringType).as("daw"),
        coalesce($"fillnum", lit(0)).cast(StringType).as("refill_num"),
        coalesce($"coord_benefits_amt", lit(0)).cast(StringType).as("amt_cob"),
        coalesce($"dispensingfee", lit(0)).cast(StringType).as("amt_disp"),
        coalesce($"ingredientcost", lit(0)).cast(StringType).as("amt_ingr"),
        coalesce($"not_covered_amt", lit(0)).cast(StringType).as("amt_not_covered"),
        coalesce($"other_carrier_pay_amt", lit(0)).cast(StringType).as("amt_other_carrier_pay"),
        coalesce($"admin_fee_amt", lit(0)).cast(StringType).as("amt_admin_fee"),
        coalesce($"sales_tax_amt", lit(0)).cast(StringType).as("amt_sales_tax"),
        $"capitated_service_ind".cast(StringType).as("cap_flag"),
        coalesce($"adjusted_rx_cnt", lit(0)).cast(StringType).as("rx_count_n"),
        lit(1).cast(StringType).as("map_srce_e"),
        lit(1).cast(StringType).as("map_srce_p"),
        lit(1).cast(StringType).as("map_srce_n"),
        $"cust_attr_1".as("cust_rx_1"),
        $"cust_attr_2".as("cust_rx_2"),
        $"cust_attr_3".as("cust_rx_3"),
        $"cust_attr_4".as("cust_rx_4"),
        $"cust_attr_5".as("cust_rx_5"),
        $"cust_attr_6".as("cust_rx_6"),
        $"cust_attr_7".as("cust_rx_7"),
        $"cust_attr_8".as("cust_rx_8"),
        $"cust_attr_9".as("cust_rx_9"),
        $"cust_attr_10".as("cust_rx_10"),
        $"cust_attr_11".as("cust_rx_11"),
        $"cust_attr_12".as("cust_rx_12"),
        $"cust_attr_13".as("cust_rx_13"),
        $"cust_attr_14".as("cust_rx_14"),
        $"cust_attr_15".as("cust_rx_15"),
        $"cust_attr_16".cast(StringType).as("cust_rx_16"),
        $"cust_attr_17".cast(StringType).as("cust_rx_17"),
        $"cust_attr_18".cast(StringType).as("cust_rx_18"),
        $"cust_attr_19".cast(StringType).as("cust_rx_19"),
        $"cust_attr_20".cast(StringType).as("cust_rx_20"),
        $"claimheader".as("cust_rx_pk_id")
      )
    result_DF.as[monthly_payer_servicerx_ii_7_2_extract].toDF()
  }
}
