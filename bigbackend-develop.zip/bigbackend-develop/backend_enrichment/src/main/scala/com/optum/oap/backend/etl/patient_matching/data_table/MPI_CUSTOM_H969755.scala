package com.optum.oap.backend.etl.patient_matching.data_table

import com.optum.oap.backend.cdrTempModel.pat_match_prep
import com.optum.oap.backend.etl.common.{CDRConstants, CleanPatientName, EnrichmentUtils}
import com.optum.oap.backend.loader.EnrichmentRunTimeVariables
import com.optum.oap.cdr.models.{mpi_custom, patient_id}
import com.optum.oap.sparkdataloader.{RuntimeVariables, TableInfo, UserDefinedFunctionForDataLoader}
import org.apache.spark.sql.expressions.Window
import org.apache.spark.sql.functions._
import org.apache.spark.sql.types.{LongType, StringType}
import org.apache.spark.sql.{DataFrame, SparkSession}

object MPI_CUSTOM_H969755 extends TableInfo[mpi_custom] {

  override def dependsOn = Set("PAT_MATCH_PREP", "PATIENT_ID_PREMATCH", "ECDR_MPI_CUSTOM_H969755")

  override def name = "MPI_CUSTOM_H969755"

  override def createDataFrame(sparkSession: SparkSession,
                               loadedDependencies: Map[String, DataFrame],
                               udfMap: Map[String, UserDefinedFunctionForDataLoader],
                               runtimeVariables: RuntimeVariables): DataFrame = {
    import sparkSession.implicits._

    val dailyBuild = if (runtimeVariables.asInstanceOf[EnrichmentRunTimeVariables].buildType == CDRConstants.DELTA_BUILD_TYPE) true else false

    val tempPatMatchPrep = loadedDependencies("PAT_MATCH_PREP").as[pat_match_prep]
    val tempPatientId = loadedDependencies("PATIENT_ID_PREMATCH").as[patient_id]

    val tempPatAttrs_DF = tempPatMatchPrep
      .where($"dob".isNotNull)
      .select(
        $"groupid",
        $"client_ds_id",
        $"patientid",
        $"hgpid",
        $"dob",
        upper($"fname").as("first_name"),
        upper($"lname").as("last_name"),
        CleanPatientName.cleanPatientName($"fname", lit(3)).as("fname"),
        CleanPatientName.cleanPatientName($"lname", lit(3)).as("lname")
      ).distinct


    val tempPatientId_MEMBER_DF = tempPatientId.as("tpi")
      .where($"tpi.idtype" === lit("MEMBERID") && $"tpi.datasrc" === lit("demographics") && $"tpi.client_ds_id" === lit(8608))
      .select(
        $"groupid",
        $"client_ds_id",
        $"patientid",
        $"idvalue",
        $"idtype",
        $"id_subtype"
      ).distinct

    val dobWindow = Window.partitionBy($"dob")
    val dataDf = tempPatAttrs_DF.as("p")
      .join(tempPatientId_MEMBER_DF.as("pid"), Seq("groupid", "client_ds_id", "patientid"), "left")
      .select(
        $"p.groupid",
        $"p.client_ds_id",
        $"p.patientid",
        $"p.hgpid",
        $"p.dob".as("key_attr"),
        $"p.fname".as("attr_2"),
        $"p.lname".as("attr_3"),
        substring($"fname", 1, 1).as("attr_4"),
        substring($"fname", 1, 3).as("attr_5"),
        substring($"fname", 1, 5).as("attr_6"),
        when($"idtype" === "MEMBERID", $"idvalue")
          .when($"p.client_ds_id"
            .isin(lit(8631),lit(8632),lit(8633),lit(8634),lit(8635),lit(8636),lit(8637),lit(8670),lit(9068)), $"p.patientid")
          .otherwise(lit(null)).as("attr_7"),
        when($"idtype" === "MEMBERID", $"id_subtype")
          .when($"p.client_ds_id".isin(lit(8631)), "CHACO")
          .when($"p.client_ds_id".isin(lit(8632), lit(8637)), "FCHP")
          .when($"p.client_ds_id".isin(lit(8633)), "BCBS")
          .when($"p.client_ds_id".isin(lit(8634)), "TUFTS_C")
          .when($"p.client_ds_id".isin(lit(8635)), "TUFTS_M")
          .when($"p.client_ds_id".isin(lit(8636)), "HPHC")
          .when($"p.client_ds_id".isin(lit(8670)), "NGACO")
          .when($"p.client_ds_id".isin(lit(9068)), "FCHP")
          .otherwise(lit(null).cast(StringType)).as("attr_8"),
        lit(null).cast(StringType).as("attr_9"),
        lit(null).cast(StringType).as("attr_10"),
        lit(null).cast(StringType).as("attr_11"),
        lit(null).cast(StringType).as("attr_12"),
        size(collect_set("p.groupid").over(dobWindow)).as("group_cnt"),
        size(collect_set("p.hgpid").over(dobWindow)).cast(LongType).as("hgpids")
      )

    val ecdrDf = {
      if (dailyBuild) EnrichmentUtils.removeRowSourceAndModifiedDate(loadedDependencies("ECDR_MPI_CUSTOM_H969755")).as[mpi_custom]
      else sparkSession.emptyDataset[mpi_custom].as[mpi_custom]
    }.as("e")
      .select($"e.*")

    dataDf.unionByName(ecdrDf).distinct()

  }
}
