package com.optum.oap.backend.etl.enrichment

import java.text.SimpleDateFormat

import com.optum.oap.backend.etl.common.{CDRConstants, EnrichmentUtils}
import com.optum.oap.backend.loader.EnrichmentRunTimeVariables
import com.optum.oap.cdr.models.schema_init
import com.optum.oap.sparkdataloader.{RuntimeVariables, TableInfo, UserDefinedFunctionForDataLoader}
import org.apache.spark.sql.{DataFrame, SparkSession}
import java.util.Calendar

import com.optum.oap.backend.etl.enrichment.FACILITY_XREF_VALIDATION.FacilityXrefMismatchException

object SCHEMA_INIT extends TableInfo[schema_init]{

  override def dependsOn: Set[String] = Set.empty


  override def name = "SCHEMA_INIT"

  override def createDataFrame(sparkSession: SparkSession, loadedDependencies: Map[String, DataFrame], udfMap: Map[String, UserDefinedFunctionForDataLoader], runtimeVariables: RuntimeVariables): DataFrame = {
    import sparkSession.implicits._

    lazy val cdrContractVersion = EnrichmentUtils.getCDRProperties()

    val releaseCycle = runtimeVariables.asInstanceOf[EnrichmentRunTimeVariables].release

    val now = Calendar.getInstance().getTime
    val simpleDateFormat = new SimpleDateFormat("yyyyMMdd")
    val currentDate = simpleDateFormat.format(now)

    val dailyBuild = if (runtimeVariables.asInstanceOf[EnrichmentRunTimeVariables].buildType == CDRConstants.DELTA_BUILD_TYPE) true else false
    val is_monthly_flag = if (dailyBuild) "Delta" else "Y"

    val cdrContract = cdrContractVersion("CDR_CONTRACT_VERSION")
    val contractVersion = cdrContractVersion("CDR_VERSION")

    if(cdrContract.isEmpty || contractVersion.isEmpty) {
      throw SchemaInitContractInfoException("CDR contract info is missing")
    }

    println(cdrContract.get,contractVersion.get )

    val cdrInfo = List(
      schema_init(attribute = "release_cycle", value = releaseCycle, description = "Monthly release cycle of this schema"),
      schema_init(attribute = "created", value = currentDate, description = "Date of the schema creation"),
      schema_init(attribute = "is_monthly_flg", value = is_monthly_flag, description = "Monthly vs Delta Flag"),
      schema_init(attribute = "cdr-contract", value = cdrContract.get, description = "CDR contract version"),
      schema_init(attribute = "cdr-version", value = contractVersion.get, description = "CDR build version")
    ).toDF


    cdrInfo
  }

  final case class SchemaInitContractInfoException(message: String = "", exception: Throwable = null) extends Exception(message)

}