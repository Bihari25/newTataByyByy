package com.optum.oap.backend.etl.enrichment

import com.optum.oap.backend.etl.common.MapMasterIds
import com.optum.oap.cdr.models._
import com.optum.oap.sparkdataloader.{RuntimeVariables, TableInfo, UserDefinedFunctionForDataLoader}
import org.apache.spark.sql.functions._
import org.apache.spark.sql.{DataFrame, SparkSession}
import org.slf4j.LoggerFactory

object PROCEDUREDO extends TableInfo[proceduredo] {
  val log = LoggerFactory.getLogger(this.getClass)

  override def dependsOn = Set("CDR_FE_PROCEDUREDO", "REF_CPT4", "REF_HCPCS", "REF_ICD9_PX", "REF_ICD0_PX",
    "REF_UB04_REV_CODES","PATIENT_MPI", "ZH_PROVIDER_MASTER_XREF", "ICPM_PROCEDURE")

  override def name = "PROCEDUREDO"

  override def saveDataFrameToParquet: Boolean = true

  override def partitions: Int = 512

  override def skipTable: Boolean = false

  override def ignoreExtraColumnsInDataFrame: Boolean = true

  override def createDataFrame(sparkSession: SparkSession,
                               loadedDependencies: Map[String, DataFrame],
                               udfMap: Map[String, UserDefinedFunctionForDataLoader],
                               runtimeVariables: RuntimeVariables): DataFrame = {

    import sparkSession.implicits._
    implicit val spark = sparkSession

    val proceduredo = loadedDependencies("CDR_FE_PROCEDUREDO").drop("row_source", "modified_date").as[proceduredo]

    val icpmProcedureIn = loadedDependencies("ICPM_PROCEDURE").as[proceduredo]

    val procedureUnion = proceduredo.unionByName(icpmProcedureIn)

    val ref_cpt4 = broadcast(dataframe(loadedDependencies("REF_CPT4").as[ref_cpt4].select($"procedure_code").as[procedure_code].collect(): _*))

    val ref_hcpcs = broadcast(dataframe(loadedDependencies("REF_HCPCS").as[ref_hcpcs].select($"procedure_code").as[procedure_code].collect(): _*))

    val ref_icd9 = broadcast(dataframe(loadedDependencies("REF_ICD9_PX").as[ref_icd9_px].select($"procedure_code").as[procedure_code].collect(): _*))

    val ref_icd0 = broadcast(dataframe(loadedDependencies("REF_ICD0_PX").as[ref_icd0_px].select($"procedure_code").as[procedure_code].collect(): _*))

    val ref_rev_codes = broadcast(loadedDependencies("REF_UB04_REV_CODES")).as[ref_ub04_rev_codes]

    val patXREF = loadedDependencies("PATIENT_MPI").as[patient_mpi]

    val provXREF = broadcast(loadedDependencies("ZH_PROVIDER_MASTER_XREF")).as[zh_provider_master_xref]

    val srcProc = procedureUnion.select(
      $"datasrc".alias("datasrc1"),
      $"client_ds_id".alias("client_ds_id1"),
      $"ORIG_CODETYPE",
      $"ORIG_MAPPEDCODE"
    ).groupBy("datasrc1", "client_ds_id1")
      .agg(when(sum(when($"ORIG_CODETYPE".isNotNull || $"ORIG_MAPPEDCODE".isNotNull, 1).otherwise(0)) === 0, 0).otherwise(1)
        .as("is_orig")).as[is_orig_procedure].collect()

    val procSrc = dataframe(srcProc: _*)

    val joinedDf = procedureUnion.alias("tp")
      .join(broadcast(procSrc).alias("src"), $"src.datasrc1" === $"tp.datasrc" && $"src.client_ds_id1" === $"tp.client_ds_id", "left_outer")
      .join(ref_cpt4.alias("CP"),
        upper(regexp_replace($"CP.PROCEDURE_CODE", "\\.", "")) ===
          when($"src.is_orig" === 1, upper(regexp_replace($"tp.ORIG_MAPPEDCODE", "\\.", "")))
            .otherwise(upper(regexp_replace($"tp.MAPPEDCODE", "\\.", ""))),
        "left_outer")
      .join(ref_hcpcs.alias("HP"),
        upper(regexp_replace($"HP.PROCEDURE_CODE", "\\.", "")) ===
          when($"src.is_orig" === 1, upper(regexp_replace($"tp.ORIG_MAPPEDCODE", "\\.", "")))
            .otherwise(upper(regexp_replace($"tp.MAPPEDCODE", "\\.", ""))),
        "left_outer")
      .join(ref_icd9.alias("I9"),
        upper(regexp_replace($"I9.PROCEDURE_CODE", "\\.", "")) ===
          when($"src.is_orig" === 1, upper(regexp_replace($"tp.ORIG_MAPPEDCODE", "\\.", "")))
            .otherwise(upper(regexp_replace($"tp.MAPPEDCODE", "\\.", ""))),
        "left_outer")
      .join(ref_icd0.alias("I0"),
        upper(regexp_replace($"I0.PROCEDURE_CODE", "\\.", "")) ===
          when($"src.is_orig" === 1, upper(regexp_replace($"tp.ORIG_MAPPEDCODE", "\\.", "")))
            .otherwise(upper(regexp_replace($"tp.MAPPEDCODE", "\\.", ""))),
        "left_outer")
      .join(ref_rev_codes.alias("rc"),
        upper(regexp_replace($"rc.REV_CODE", "\\.", "")) ===
          lpad(when($"src.is_orig" === 1, upper(regexp_replace($"tp.ORIG_MAPPEDCODE", "\\.", "")))
            .otherwise(upper(regexp_replace($"tp.MAPPEDCODE", "\\.", ""))), 4, "0"),
        "left_outer")


    val mainSelect = joinedDf.select($"tp.*", $"HP.PROCEDURE_CODE", $"CP.PROCEDURE_CODE", $"I9.PROCEDURE_CODE", $"I0.PROCEDURE_CODE",
      $"rc.rev_code".alias("in_rev_dict"),
      upper(regexp_replace(trim(when($"is_orig" === 1, $"ORIG_MAPPEDCODE").otherwise($"MAPPEDCODE")), "\\.", "")).alias("clean_mc"),
      when($"is_orig" === 1, $"ORIG_MAPPEDCODE").otherwise($"MAPPEDCODE").alias("ORIG_MC_MOD"),
      when($"is_orig" === 1, $"ORIG_CODETYPE").otherwise($"CODETYPE").alias("ORIG_CT_MOD"))

    val finalSelect = mainSelect.select($"tp.*", $"clean_mc", $"ORIG_MC_MOD", $"ORIG_CT_MOD", $"in_rev_dict",
      when($"ORIG_CT_MOD".isNotNull && !upper($"ORIG_CT_MOD").isin("CPT4", "HCPCS", "ICD10", "ICD9"), $"CODETYPE")
        .when(upper($"ORIG_CT_MOD") === "CPT4",
          when($"ORIG_MC_MOD".rlike("^[0-9]{4}[0-9A-Z]$"), "CPT4")
            .when($"HP.PROCEDURE_CODE".isNotNull && $"ORIG_MC_MOD".rlike("^[A-Z][0-9]{4}$"), "HCPCS")
            .when($"I9.PROCEDURE_CODE".isNotNull && $"ORIG_MC_MOD".rlike("^[0-9]{2,2}\\.?[0-9]{1,2}$"), "ICD9")
            .when($"I0.PROCEDURE_CODE".isNotNull && $"ORIG_MC_MOD".rlike("^[0-9A-Z]{1}[0-9A-Z]{6}$"), "ICD10").otherwise("UNKNOWN")
        )
        .when(upper($"ORIG_CT_MOD") === "HCPCS",
          when($"ORIG_MC_MOD".rlike("^[A-Z][0-9]{4}$"), "HCPCS")
            .when($"CP.PROCEDURE_CODE".isNotNull && $"ORIG_MC_MOD".rlike("^[0-9]{4}[0-9A-Z]$"), "CPT4")
            .when($"I9.PROCEDURE_CODE".isNotNull && $"ORIG_MC_MOD".rlike("^[0-9]{2,2}\\.?[0-9]{1,2}$"), "ICD9")
            .when($"I0.PROCEDURE_CODE".isNotNull && $"ORIG_MC_MOD".rlike("^[0-9A-Z]{1}[0-9A-Z]{6}$"), "ICD10").otherwise("UNKNOWN")
        )
        .when(upper($"ORIG_CT_MOD") === "ICD9",
          when($"ORIG_MC_MOD".rlike("^[0-9]{2,2}\\.?[0-9]{1,2}$"), "ICD9")
            .when($"CP.PROCEDURE_CODE".isNotNull && $"ORIG_MC_MOD".rlike("^[0-9]{4}[0-9A-Z]$"), "CPT4")
            .when($"HP.PROCEDURE_CODE".isNotNull && $"ORIG_MC_MOD".rlike("^[A-Z][0-9]{4}$"), "HCPCS")
            .when($"I0.PROCEDURE_CODE".isNotNull && $"ORIG_MC_MOD".rlike("^[0-9A-Z]{1}[0-9A-Z]{6}$"), "ICD10").otherwise("UNKNOWN")
        )
        .when(upper($"ORIG_CT_MOD") === "ICD10",
          when($"I0.PROCEDURE_CODE".isNotNull && $"ORIG_MC_MOD".rlike("^[0-9A-Z]{1}[0-9A-Z]{6}$"), "ICD10")
            .when($"CP.PROCEDURE_CODE".isNotNull && $"ORIG_MC_MOD".rlike("^[0-9]{4}[0-9A-Z]$"), "CPT4")
            .when($"HP.PROCEDURE_CODE".isNotNull && $"ORIG_MC_MOD".rlike("^[A-Z][0-9]{4}$"), "HCPCS")
            .when($"I9.PROCEDURE_CODE".isNotNull && $"ORIG_MC_MOD".rlike("^[0-9]{2,2}\\.?[0-9]{1,2}$"), "ICD9")
            .otherwise("UNKNOWN")
        )
        .when($"ORIG_CT_MOD".isNull || !upper($"ORIG_CT_MOD").isin("CPT4", "HCPCS", "ICD10", "ICD9"),
          when($"ORIG_MC_MOD".rlike("^[0-9]{4}[0-9A-Z]$"), "CPT4")
            .when($"ORIG_MC_MOD".rlike("^[A-Z][0-9]{4}$"), "HCPCS")
            .when($"ORIG_MC_MOD".rlike("^[0-9]{2,2}\\.?[0-9]{1,2}$"), "ICD9")
            .when($"I0.PROCEDURE_CODE".isNotNull && $"ORIG_MC_MOD".rlike("^[0-9A-Z]{1}[0-9A-Z]{6}$"), "ICD10").otherwise("UNKNOWN")
        ).otherwise("UNKNOWN").alias("ct_mod")

    ).alias("p")

    val finalResult = finalSelect.select($"p.*",
      when($"ct_mod" === "ICD9" && coalesce(length($"clean_mc"), lit(0)).between(3, 4),
        concat(substring($"clean_mc", 1, 2), lit("."), $"clean_mc".substr(lit(3), length($"clean_mc") - 1)))
        .when($"ct_mod" === "ICD9", $"clean_mc")
        .when($"ct_mod" === "REV" && $"in_rev_dict".isNotNull, $"in_rev_dict")
        .otherwise($"ORIG_MC_MOD").alias("mc_mod")
    ).withColumn("ORIG_MAPPEDCODE", $"ORIG_MC_MOD")
      .withColumn("ORIG_CODETYPE", $"ORIG_CT_MOD")
      .withColumn("MAPPEDCODE", $"mc_mod")
      .withColumn("CODETYPE", $"ct_mod")
      .drop("clean_mc", "in_rev_dict", "mc_mod", "ORIG_MC_MOD", "ORIG_CT_MOD", "ct_mod")

    //Materialize MasterIds
    MapMasterIds.mapProviderIds(MapMasterIds.mapPatientIds(finalResult, patXREF.toDF(), false), provXREF.toDF(), "performingproviderid", "performing_mstrprovid")

  }
}

case class is_orig_procedure(datasrc1: String, client_ds_id1: Integer, is_orig: Integer)
case class procedure_code(procedure_code: String)
