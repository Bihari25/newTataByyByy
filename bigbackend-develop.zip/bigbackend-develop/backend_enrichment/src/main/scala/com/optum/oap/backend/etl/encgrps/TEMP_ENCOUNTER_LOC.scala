package com.optum.oap.backend.etl.encgrps

import com.optum.oap.backend.cdrTempModel.temp_encounter_loc
import com.optum.oap.cdr.models.{encounter_encounter_grp, encountercarearea, map_care_area, map_service}
import com.optum.oap.sparkdataloader.{RuntimeVariables, TableInfo, UserDefinedFunctionForDataLoader}
import org.apache.spark.sql.functions._
import org.apache.spark.sql.{DataFrame, SparkSession}

object TEMP_ENCOUNTER_LOC extends TableInfo[temp_encounter_loc] {

  override def dependsOn = Set("ENCOUNTERCAREAREA", "ENCOUNTER_ENCOUNTER_GRP", "MAP_CARE_AREA", "MAP_SERVICE")

  override def name = "TEMP_ENCOUNTER_LOC"

  override def createDataFrame(sparkSession: SparkSession,
                               loadedDependencies: Map[String, DataFrame],
                               udfMap: Map[String, UserDefinedFunctionForDataLoader],
                               runtimeVariables: RuntimeVariables): DataFrame = {
    import sparkSession.implicits._

    val encntrCrArea = loadedDependencies("ENCOUNTERCAREAREA").as[encountercarearea]
    val encntrGrp = loadedDependencies("ENCOUNTER_ENCOUNTER_GRP").as[encounter_encounter_grp]
    val mapCareArea = broadcast(loadedDependencies("MAP_CARE_AREA").as[map_care_area])
    val mapService = broadcast(loadedDependencies("MAP_SERVICE").as[map_service])
    val enctrIDtypes = Seq("ADD ER", "ADD OB", "ADD SD")

    /*
    select  eca.groupid, eeg.grp_mpi, eeg.ENCOUNTER_GRP_NUM, eca.encounterid, eca.client_ds_id, eca.datasrc as ca_datasrc, eca.localcareareacode
  , eca.careareastarttime
  , eca.careareaendtime
  , eca.servicecode
  , mca.cui as carearea
  , ms.cui as service
  , eca.locallocationname
  , eeg.encounteridtype
 from
 ENCOUNTERCAREAREA eca
 inner join ENCOUNTER_ENCOUNTER_GRP eeg on (eca.groupid = eeg.groupid and eca.encounterid = eeg.encounterid and eca.client_ds_id = eeg.client_ds_id)
 left outer join MAP_CARE_AREA mca on (eca.groupid = mca.groupid and eca.localcareareacode = mca.local_code)
 left outer join MAP_SERVICE ms on (eca.groupid = ms.groupid and eca.servicecode = ms.mnemonic)
 where coalesce(eca.localcareareacode,eca.servicecode,eca.locallocationname) is not null
 and eeg.encounteridtype not in ('ADD ER','ADD OB','ADD SD')
 group by eca.groupid, eeg.grp_mpi, eeg.ENCOUNTER_GRP_NUM, eca.encounterid, eca.client_ds_id, eca.datasrc, eca.localcareareacode, eca.careareastarttime, eca.careareaendtime, eca.servicecode
  , mca.cui, ms.cui,eca.locallocationname, eeg.encounteridtype
     */

    encntrCrArea.as("eca")
      .join(encntrGrp.as("eeg"), $"eca.groupid" === $"eeg.groupid" && $"eca.encounterid" === $"eeg.encounterid" && $"eca.client_ds_id" === $"eeg.client_ds_id", "inner")
      .join(mapCareArea.as("mca"), $"eca.groupid" === $"mca.groupid" && $"eca.localcareareacode" === $"mca.local_code", "left_outer")
      .join(mapService.as("ms"), $"eca.groupid" === $"ms.groupid" && $"eca.servicecode" === $"ms.mnemonic", "left_outer")
      .where(
        coalesce($"eca.localcareareacode", $"eca.servicecode", $"eca.locallocationname").isNotNull
          .and(not($"eeg.encounteridtype".isin(enctrIDtypes: _*)))).select($"eca.groupid", $"eeg.grp_mpi", $"eeg.ENCOUNTER_GRP_NUM", $"eca.encounterid",
      $"eca.client_ds_id", $"eca.datasrc", $"eca.localcareareacode", $"eca.careareastarttime",
      $"eca.careareaendtime", $"eca.servicecode"
      , $"mca.cui", $"ms.cui", $"eca.locallocationname", $"eeg.encounteridtype").
      select($"eca.groupid", $"eeg.grp_mpi", $"eeg.ENCOUNTER_GRP_NUM", $"eca.encounterid",
        $"eca.client_ds_id", $"eca.datasrc".as("ca_datasrc"), $"eca.localcareareacode", $"eca.careareastarttime",
        $"eca.careareaendtime", $"eca.servicecode"
        , $"mca.cui".as("carearea"), $"ms.cui".as("service"), $"eca.locallocationname", $"eeg.encounteridtype").distinct()

  }

}
