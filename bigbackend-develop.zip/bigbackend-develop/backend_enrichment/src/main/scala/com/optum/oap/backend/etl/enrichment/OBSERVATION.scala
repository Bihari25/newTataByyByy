package com.optum.oap.backend.etl.enrichment

import com.optum.oap.backend.etl.common.{Functions, MapMasterIds, Observations}
import com.optum.oap.backend.loader.EnrichmentRunTimeVariables
import com.optum.oap.backend.cdrTempModel.{observation_nlp_smoking}
import com.optum.oap.cdr.models._
import com.optum.oap.sparkdataloader.{RuntimeVariables, TableInfo, UserDefinedFunctionForDataLoader}
import org.apache.spark.sql.functions._
import org.apache.spark.sql.types._
import org.apache.spark.sql.{DataFrame, SparkSession}

object OBSERVATION extends TableInfo[observation] {
  override def dependsOn = Set("CDR_FE_OBSERVATION", "OBSERVATION_NLP", "OBSERVATION_NLP_SMOKING", "PATIENT_MPI", "PATIENT",
    "ZCM_OBSTYPE_CODE", "ZCM_OBSTYPE", "UNIT_CONVERSION", "ZCM_CLIENT_DS_PRIORITY")

  override def name = "OBSERVATION"

  override def saveDataFrameToParquet: Boolean = true

  override def partitions: Int = 128

  override def skipTable: Boolean = false

  override def ignoreExtraColumnsInDataFrame: Boolean = true

  override def createDataFrame(sparkSession: SparkSession,
                               loadedDependencies: Map[String, DataFrame],
                               udfMap: Map[String, UserDefinedFunctionForDataLoader],
                               runtimeVariables: RuntimeVariables): DataFrame = {
    import sparkSession.implicits._

    val partitionMultiplier = EnrichmentRunTimeVariables(runtimeVariables).partitionMultiplier
    val observationIn = loadedDependencies("CDR_FE_OBSERVATION").where($"datasrc" =!= lit("IMPUTED")).as[observation]
    val observationNLPIn = loadedDependencies("OBSERVATION_NLP").where($"datasrc" === lit("nlp")).as[observation]
    val observationNlpSmoking = loadedDependencies("OBSERVATION_NLP_SMOKING").as[observation_nlp_smoking]
    val patXref = loadedDependencies("PATIENT_MPI").as[patient_mpi]
    val zcmObstype = broadcast(loadedDependencies("ZCM_OBSTYPE")).as[zcm_obstype]
    val zcmObstypeCode = broadcast(loadedDependencies("ZCM_OBSTYPE_CODE")).as[zcm_obstype_code]
    val zcmClientDsPriority = broadcast(loadedDependencies("ZCM_CLIENT_DS_PRIORITY")).as[zcm_client_ds_priority]
    val patientDobs = Observations.getPatientDobs(sparkSession, loadedDependencies("PATIENT").as[patient], zcmClientDsPriority)
    val unitConversionData = Observations.queryUnitConversionData(sparkSession, loadedDependencies("UNIT_CONVERSION").as[unit_conversion])
    // this requires zcm_obstype_code to contain at least one row for obstype BMI or the ETL will fail (QueryIntegrationTest, for instance)

    val roundPrecNum = try {
      zcmObstype.where($"obstype" === lit("BMI")).select($"round_prec").first()
        .getAs[Integer]("round_prec")
    } catch {
      case _: Throwable => throw new IllegalStateException("ZCM_OBSTYPE missing row for BMI configuration")
    }

    // first union nlp result, normalize the obsresult, validate the ht's/wt's and master the patient records...
    val combined_observationIn = observationIn.drop("row_source", "modified_date").toDF
      .union(observationNLPIn.drop("row_source", "modified_date").toDF)
      .union(observationNlpSmoking.drop("row_source").toDF)

    val masteredObservations = MapMasterIds.mapPatientIds(combined_observationIn, patXref.toDF, filterIds = false).as("o")
      .join(broadcast(zcmObstypeCode).as("z"),
        $"o.datasrc" === $"z.datasrc" && $"o.localcode" === $"z.obscode" && $"o.obstype" === $"z.obstype", "left"
      )
      .join(patientDobs, Seq("grp_mpi"), "left")
      .select(Observations.getZcmJoinedObservationsColSelect(sparkSession): _*)
      .map(row => Observations.normalizeObsResultByRow(row, unitConversionData, roundPrecNum))
      .toDF

    // now generate rows for the BMI measurements...
    val bmiObservations = Observations.deriveBmiRows(sparkSession, masteredObservations, roundPrecNum)

    // lastly, union all results together
    val obsCols = Functions.selectColsFromCaseClass[observation]
    masteredObservations.select(obsCols.head, obsCols.tail: _*)
      .union(bmiObservations.select(obsCols.head, obsCols.tail: _*)).repartition(Math.ceil(partitions * partitionMultiplier).toInt)
  }
}
