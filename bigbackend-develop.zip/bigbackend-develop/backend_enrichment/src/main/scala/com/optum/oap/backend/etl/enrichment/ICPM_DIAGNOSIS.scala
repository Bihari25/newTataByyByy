package com.optum.oap.backend.etl.enrichment

import com.optum.oap.backend.cdrTempModel.temp_med_claim
import com.optum.oap.backend.etl.common.Functions.mpvList
import com.optum.oap.backend.etl.common.IsSafeToNumber
import com.optum.oap.backend.loader.EnrichmentRunTimeVariables
import com.optum.oap.cdr.models._
import com.optum.oap.sparkdataloader.{RuntimeVariables, TableInfo, UserDefinedFunctionForDataLoader}
import org.apache.spark.sql.expressions.Window
import org.apache.spark.sql.functions._
import org.apache.spark.sql.types.{DataTypes, IntegerType}
import org.apache.spark.sql.{DataFrame, SparkSession}
import org.slf4j.LoggerFactory

object ICPM_DIAGNOSIS extends TableInfo[diagnosis] {

  private val log = LoggerFactory.getLogger(this.getClass)

  override def dependsOn = Set("ICPM_TEMP_MED_CLAIM", "MAP_LOCAL_CODETYPE")

  override def name = "ICPM_DIAGNOSIS"

  override def createDataFrame(sparkSession: SparkSession,
                               loadedDependencies: Map[String, DataFrame],
                               udfMap: Map[String, UserDefinedFunctionForDataLoader],
                               runtimeVariables: RuntimeVariables): DataFrame = {
    import sparkSession.implicits._

    val tempMedClaimIn = loadedDependencies("ICPM_TEMP_MED_CLAIM").as[temp_med_claim]

    val mapLocalCodetypeIn = broadcast(loadedDependencies("MAP_LOCAL_CODETYPE")).as[map_local_codetype]

    val cdrFeDiag = tempMedClaimIn.select(
      $"groupid",
      $"client_ds_id",
      $"service_date".as("dx_timestamp"),
      $"member_id".as("patientid"),
      $"pay_process_date",
      $"encounterid",
      $"datasrc",
      $"source_code".as("sourceid"),
      expr("stack(25, " +
        "icd_diag_cd1, icd_diag_cd1_type, icd_diag_cd1_adm_diag_flag, icd_diag_cd1_poa_indicator, 'CODE1', " +
        "icd_diag_cd2, icd_diag_cd2_type, icd_diag_cd2_adm_diag_flag, icd_diag_cd2_poa_indicator, 'CODE2', " +
        "icd_diag_cd3, icd_diag_cd3_type, icd_diag_cd3_adm_diag_flag, icd_diag_cd3_poa_indicator, 'CODE3', " +
        "icd_diag_cd4, icd_diag_cd4_type, icd_diag_cd4_adm_diag_flag, icd_diag_cd4_poa_indicator, 'CODE4', " +
        "icd_diag_cd5, icd_diag_cd5_type, icd_diag_cd5_adm_diag_flag, icd_diag_cd5_poa_indicator, 'CODE5', " +
        "icd_diag_cd6, icd_diag_cd6_type, icd_diag_cd6_adm_diag_flag, icd_diag_cd6_poa_indicator, 'CODE6', " +
        "icd_diag_cd7, icd_diag_cd7_type, icd_diag_cd7_adm_diag_flag, icd_diag_cd7_poa_indicator, 'CODE7', " +
        "icd_diag_cd8, icd_diag_cd8_type, icd_diag_cd8_adm_diag_flag, icd_diag_cd8_poa_indicator, 'CODE8', " +
        "icd_diag_cd9, icd_diag_cd9_type, icd_diag_cd9_adm_diag_flag, icd_diag_cd9_poa_indicator, 'CODE9', " +
        "icd_diag_cd10, icd_diag_cd10_type, icd_diag_cd10_adm_diag_flag, icd_diag_cd10_poa_indicator, 'CODE10', " +
        "icd_diag_cd11, icd_diag_cd11_type, icd_diag_cd11_adm_diag_flag, icd_diag_cd11_poa_indicator, 'CODE11', " +
        "icd_diag_cd12, icd_diag_cd12_type, icd_diag_cd12_adm_diag_flag, icd_diag_cd12_poa_indicator, 'CODE12', " +
        "icd_diag_cd13, icd_diag_cd13_type, icd_diag_cd13_adm_diag_flag, icd_diag_cd13_poa_indicator, 'CODE13', " +
        "icd_diag_cd14, icd_diag_cd14_type, icd_diag_cd14_adm_diag_flag, icd_diag_cd14_poa_indicator, 'CODE14', " +
        "icd_diag_cd15, icd_diag_cd15_type, icd_diag_cd15_adm_diag_flag, icd_diag_cd15_poa_indicator, 'CODE15', " +
        "icd_diag_cd16, icd_diag_cd16_type, icd_diag_cd16_adm_diag_flag, icd_diag_cd16_poa_indicator, 'CODE16', " +
        "icd_diag_cd17, icd_diag_cd17_type, icd_diag_cd17_adm_diag_flag, icd_diag_cd17_poa_indicator, 'CODE17', " +
        "icd_diag_cd18, icd_diag_cd18_type, icd_diag_cd18_adm_diag_flag, icd_diag_cd18_poa_indicator, 'CODE18', " +
        "icd_diag_cd19, icd_diag_cd19_type, icd_diag_cd19_adm_diag_flag, icd_diag_cd19_poa_indicator, 'CODE19', " +
        "icd_diag_cd20, icd_diag_cd20_type, icd_diag_cd20_adm_diag_flag, icd_diag_cd20_poa_indicator, 'CODE20', " +
        "icd_diag_cd21, icd_diag_cd21_type, icd_diag_cd21_adm_diag_flag, icd_diag_cd21_poa_indicator, 'CODE21', " +
        "icd_diag_cd22, icd_diag_cd22_type, icd_diag_cd22_adm_diag_flag, icd_diag_cd22_poa_indicator, 'CODE22', " +
        "icd_diag_cd23, icd_diag_cd23_type, icd_diag_cd23_adm_diag_flag, icd_diag_cd23_poa_indicator, 'CODE23', " +
        "icd_diag_cd24, icd_diag_cd24_type, icd_diag_cd24_adm_diag_flag, icd_diag_cd24_poa_indicator, 'CODE24', " +
        "icd_diag_cd25, icd_diag_cd25_type, icd_diag_cd25_adm_diag_flag, icd_diag_cd25_poa_indicator, 'CODE25') " +
        " as (localdiagnosis, codetype, localadmitflg, localpresentonadmission, source)")
    ).filter($"localdiagnosis".isNotNull)

    cdrFeDiag.alias("mc")
      .join(mapLocalCodetypeIn.alias("mlc"), $"mc.codetype" === $"mlc.localcode", "left_outer")
      .filter($"mc.dx_timestamp".isNotNull && $"mc.patientid".isNotNull)
      .select(
        $"mc.groupid",
        $"mc.client_ds_id",
        $"mc.datasrc",
        $"mc.dx_timestamp",
        $"mc.localdiagnosis",
        $"mc.patientid",
        coalesce($"mlc.mappedvalue", $"mc.codetype").as("codetype"),
        $"mc.encounterid",
        when($"mc.datasrc" === "int_claim_medical_i", lit("Y")).otherwise(lit("N")).as("hosp_dx_flag"),
        when($"mc.localadmitflg".isNull, lit("N")).otherwise($"mc.localadmitflg").as("localadmitflg"),
        $"mc.localpresentonadmission",
        when($"mc.source" === "CODE1", lit(1)).otherwise(lit(0)).as("primarydiagnosis"),
        $"mc.sourceid",
        $"mc.localdiagnosis".as("mappeddiagnosis"),
        $"mc.pay_process_date",
        when($"mc.source".like("CODE%"),
          when(IsSafeToNumber.isSafeToNumber(substring($"mc.source", 5, 2)), substring($"mc.source", 5, 2)).otherwise(null))
          .otherwise(null).cast(IntegerType).as("seq"),
        lit(null).cast(DataTypes.StringType).as("facilityid"),
        lit(null).cast(DataTypes.StringType).as("grp_mpi"),
        lit(null).cast(DataTypes.LongType).as("hgpid"),
        lit(null).cast(DataTypes.StringType).as("localdiagnosisstatus"),
        lit(null).cast(DataTypes.StringType).as("localdiagnosisproviderid"),
        lit(null).cast(DataTypes.StringType).as("mappeddiagnosisstatus"),
        lit(null).cast(DataTypes.StringType).as("localdischargeflg"),
        lit(null).cast(DataTypes.StringType).as("localactiveind"),
        lit(null).cast(DataTypes.TimestampType).as("resolutiondate"),
        lit(null).cast(DataTypes.StringType).as("orig_codetype"),
        lit(null).cast(DataTypes.StringType).as("orig_mappeddiagnosis"),
        lit(null).cast(DataTypes.StringType).as("charge_id"),
        lit(null).cast(DataTypes.IntegerType).as("chronic_ind"),
        lit(null).cast(DataTypes.StringType).as("local_diag_desc"),
        lit(null).cast(DataTypes.StringType).as("local_severity"),
        lit(null).cast(DataTypes.StringType).as("problem_record_id"),
        lit(null).cast(DataTypes.TimestampType).as("recorded_dtm")
      )
      .withColumn("rank_diag", row_number().over(Window.partitionBy($"client_ds_id", $"sourceid", $"encounterid",
        $"dx_timestamp", $"localdiagnosis", $"hosp_dx_flag", $"patientid")
        .orderBy($"primarydiagnosis".desc_nulls_last, $"pay_process_date".desc_nulls_last)))
      .filter(
        $"rank_diag" === 1
          && $"dx_timestamp".isNotNull
          && $"patientid".isNotNull).drop("rank_diag", "pay_process_date")

  }
}
