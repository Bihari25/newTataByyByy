package com.optum.oap.backend.etl.enrichment

import com.optum.oap.backend.cdrTempModel.int_claim_med_icpm
import com.optum.oap.backend.etl.common.Functions.mpvList
import com.optum.oap.backend.etl.common.IsSafeToNumber
import com.optum.oap.backend.loader.EnrichmentRunTimeVariables
import com.optum.oap.cdr.models.map_predicate_values
import com.optum.oap.sparkdataloader.{RuntimeVariables, TableInfo, UserDefinedFunctionForDataLoader}
import org.apache.spark.sql.expressions.Window
import org.apache.spark.sql.functions._
import org.apache.spark.sql.types.DataTypes
import org.apache.spark.sql.{DataFrame, SparkSession}
import org.slf4j.LoggerFactory

import scala.util.{Failure, Success, Try}

object INT_CLAIM_MEDICAL extends TableInfo[int_claim_med_icpm] with INT_CLAIM_CLEANUP {

  private val log = LoggerFactory.getLogger(this.getClass)

  override def dependsOn = Set("CDR_FE_INT_CLAIM_MEDICAL", "MAP_PREDICATE_VALUES")

  override def name = "INT_CLAIM_MEDICAL"

  override def ignoreExtraColumnsInDataFrame: Boolean = true

  override def regexReplaceColumns: Set[String] = Set("denied_flag", "network_paid_status", "serv_prov_affil_id", "spec_rx_ind")

  override def createDataFrame(sparkSession: SparkSession,
                               loadedDependencies: Map[String, DataFrame],
                               udfMap: Map[String, UserDefinedFunctionForDataLoader],
                               runtimeVariables: RuntimeVariables): DataFrame = {
    import sparkSession.implicits._

    val medIn = loadedDependencies("CDR_FE_INT_CLAIM_MEDICAL")
    val mapPredicateValues = broadcast(loadedDependencies("MAP_PREDICATE_VALUES")).as[map_predicate_values]
    val groupId = runtimeVariables.asInstanceOf[EnrichmentRunTimeVariables].clientId
    val intClaimMedicalIn1 = cleanUp(groupId, mapPredicateValues.toDF(), medIn).drop("row_source", "modified_date")
      .select($"*"
        ,monotonically_increasing_id().as("rowid")
      )

    def parseColumns(inputDf: DataFrame, modColumns: List[String]): DataFrame = {
      val pd = Try({
        val df = modColumns.foldLeft(inputDf) {
          (acc, x) =>
            acc.withColumn(x, regexp_extract(col(x)
              .cast(DataTypes.StringType), "^[-+]?\\d+.\\d{0,2}", 0))
              .withColumn(x, col(x).cast(DataTypes.DoubleType))
        }
        df
      })
      pd match {
        case Success(v) => v
        case Failure(problem) => inputDf
      }
    }

    val modColumns =  List("allowed_amt", "payment_amt", "requested_amt")

    val intClaimMedicalInParsedAmt = parseColumns(intClaimMedicalIn1, modColumns)

    val intClaimMedicalIn = List("quantity_of_service").foldLeft(intClaimMedicalInParsedAmt) {
      (acc, x) => acc.withColumn(x, regexp_extract(col(x), "^[-+]?\\d+.\\d{0,2}", 0))
    }

    // Get mpvListValue
    val mpvListValue = mapPredicateValues.filter(
      $"data_src" === "OADW" && $"entity" === "PPV2"
        && $"table_name" === "PPV2"
        && $"groupid" === lit(groupId)
        && $"column_value" === "1")
      .select($"client_ds_id").distinct.collect().map(_.getInt(0).toString)

    //Step2 : Create temp_med_claim_adj
    // CREATE TABLE THAT EVALUATES THE COST FIELDS, SETTING THEM TO P, N, M
    // ALSO GENERATE THE ABS AMT FOR EACH COST FIELD FOR THE NEXT STEP IN THE PROCESS

    val medClaimAdj = intClaimMedicalIn.alias("m")
      .filter($"m.client_ds_id".isin(mpvListValue: _*))
      .select($"m.*"
        ,when(coalesce($"m.requested_amt", lit(0)).geq(0) && coalesce($"m.allowed_amt", lit(0)).geq(0) && coalesce($"m.payment_amt", lit(0)).geq(0), lit("P"))
          .when($"m.requested_amt".lt(0) && $"m.allowed_amt".lt(0) && $"m.payment_amt".lt(0), lit("N"))
          .otherwise(lit("M")).as("adj1")
        ,abs(coalesce($"m.payment_amt", lit(0))).as("abs_payment_amt")
        ,abs(coalesce($"m.allowed_amt", lit(0))).as("abs_allowed_amt")
        ,abs(coalesce($"m.requested_amt", lit(0))).as("abs_requested_amt")
        ,$"m.rowid".as("id_row")
        ,row_number().over(Window.partitionBy($"client_ds_id").orderBy($"client_ds_id")).as("sourcecode")
        ,when($"m.pseudo_flag" === "Y", lit("NO")).otherwise(lit("YES")).as("incl")
      )

    //Step3 : Create temp_med_adj_rn
    // Build temp table to get rank of P/M/N based on partition business keys and absolute amounts.
    // This ranking is done to get sequential records for the consecutive processing in match_recognize.

    val commonMedAdjRnPartition = Window
      .partitionBy($"client_ds_id", $"contract_id", $"member_id", $"service_date"
        ,$"servicing_prov_id", $"revenue_code", $"proc_code", $"proc_cd_modifier_1", $"abs_payment_amt"
        ,$"abs_allowed_amt", $"abs_requested_amt")
      .orderBy($"pay_process_date".desc_nulls_last, $"claim_header_id".asc_nulls_last)

    val medAdjRn = medClaimAdj.alias("a1")
      .filter($"a1.adj1" === "P" && $"a1.incl" === "YES")
      .select($"a1.*"
        ,row_number().over(commonMedAdjRnPartition).as("rn")
      )
      .unionByName(medClaimAdj.alias("a2")
        .filter($"a2.adj1" === "N" && $"a2.incl" === "YES")
        .select($"a2.*"
          ,row_number().over(commonMedAdjRnPartition).as("rn")
        ))
      .unionByName(medClaimAdj.alias("a3")
        .filter($"a3.adj1" === "M" && $"a3.incl" === "YES")
        .select($"a3.*"
          ,row_number().over(commonMedAdjRnPartition).as("rn")
        ))

    // Step4a : Create temp_adj_backout_nomix - ALL SOURCES/CLIENTS IN PROCESS
    // Build table to mark the back out records for  P and N record sets only.
    // Step 3 ranks each record as part of a set and step 4 pairs N/P records to find pairs
    // These are updated to B.

    // Using lag function:
    val w = Window.partitionBy($"client_ds_id", $"contract_id", $"member_id", $"service_date", $"servicing_prov_id"
      , $"revenue_code", $"proc_code", $"proc_cd_modifier_1")
      .orderBy($"abs_payment_amt", $"abs_allowed_amt", $"abs_requested_amt", $"rn", $"pay_process_date")

    val medAdjRnWithPrevNext = medAdjRn.alias("m").orderBy( $"abs_payment_amt".asc_nulls_last, $"abs_allowed_amt".asc_nulls_last,
      $"abs_requested_amt".asc_nulls_last, $"rn".asc_nulls_last, $"pay_process_date".asc_nulls_last)
      .select( $"m.*",
        lag($"m.abs_requested_amt", 1).over(w).as("prev_abs_requested_amt"),
        lead($"m.abs_requested_amt", 1).over(w).as("next_abs_requested_amt"),
        lag($"m.abs_payment_amt", 1).over(w).as("prev_abs_payment_amt"),
        lead($"m.abs_payment_amt", 1).over(w).as("next_abs_payment_amt"),
        lag($"m.abs_allowed_amt", 1).over(w).as("prev_abs_allowed_amt"),
        lead($"m.abs_allowed_amt", 1).over(w).as("next_abs_allowed_amt"),
        lag($"m.adj1", 1).over(w).as("prev_adj1"),
        lead($"m.adj1", 1).over(w).as("next_adj1"),
        lag($"m.rn", 1).over(w).as("prev_rn"),
        lead($"m.rn", 1).over(w).as("next_rn")
      )

    val adjBackoutNomix = medAdjRnWithPrevNext.filter(
      (
        $"abs_requested_amt" === $"prev_abs_requested_amt"
          &&  $"abs_allowed_amt" === $"prev_abs_allowed_amt"
          &&  $"abs_payment_amt" === $"prev_abs_payment_amt"
          &&  $"adj1"  === "N"
          &&  $"prev_adj1" === "P"
          &&  $"rn" === $"prev_rn"
        ) ||
        (
          $"abs_requested_amt" === $"prev_abs_requested_amt"
            &&  $"abs_allowed_amt" === $"prev_abs_allowed_amt"
            &&  $"abs_payment_amt" === $"prev_abs_payment_amt"
            &&  $"adj1" === "P"
            &&  $"prev_adj1"  === "N"
            &&  $"rn" === $"prev_rn"
          ) ||
        (
          $"abs_requested_amt" === $"next_abs_requested_amt"
            &&  $"abs_allowed_amt" === $"next_abs_allowed_amt"
            &&  $"abs_payment_amt" === $"next_abs_payment_amt"
            &&  $"adj1" === "P"
            &&  $"next_adj1"  === "N"
            &&  $"rn" === $"next_rn"
          ) ||
        (
          $"abs_requested_amt" === $"next_abs_requested_amt"
            &&  $"abs_allowed_amt" === $"next_abs_allowed_amt"
            &&  $"abs_payment_amt" === $"next_abs_payment_amt"
            &&  $"adj1" === "N"
            &&  $"next_adj1"  === "P"
            &&  $"rn" === $"next_rn"
          )
    ).withColumn("revised_adj1",
      when($"adj1" === "P" && $"next_adj1" === "N" && $"rn" ===  $"next_rn", lit("B"))
        .when($"adj1" === "N" && $"prev_adj1" === "P" && $"rn" ===  $"prev_rn", lit("B"))
        .when($"adj1" === "P" && $"prev_adj1" === "N" && $"rn" ===  $"prev_rn", lit("B"))
        .when($"adj1" === "N" && $"next_adj1" === "P" && $"rn" ===  $"next_rn", lit("B"))
        .otherwise($"adj1")).select("client_ds_id", "id_row", "revised_adj1")

    //Step4b : Merge
    // RECORDS MUST BE MERGED BACK AND UPDATED TO B FOR THE N/P PAIRS BEFORE PROCEEDING TO THE NEXT (OPTIONAL) STEP
    val medAdjRnMergedNoMix = medAdjRn.as("med").join(
      adjBackoutNomix.as("adj"), $"med.id_row" === $"adj.id_row"
        && $"med.client_ds_id" === $"adj.client_ds_id"
      , "left_outer"
    ).select($"med.*"
      , when(
        $"adj.id_row".isNotNull
          && $"adj.client_ds_id".isNotNull, $"adj.revised_adj1"
      ).otherwise($"med.adj1").as("adj1_new")
    ).drop("adj1").withColumnRenamed("adj1_new", "adj1")

    // STEP 4 - OPTIONAL PROCESSING STEP
    // This code is only run  if client ds id MPV is set up to run this step.
    // It build table to mark the back out records for P and M record sets only.
    // This is optional because not all clients may want to back out a positive record paired with Mixed dollar record as a backout pair.
    // Step 3 ranks each record as part of a set and IF the record sets are not found as a pair of N/P, the only other combo option is P/M
    // These are updated to B.

    val mpvMixBkList = mapPredicateValues.filter($"data_src" === "OADW"
      && $"table_name" === "INT_CLAIM_MEDICAL"
      && $"groupid" === lit(groupId)
      && $"column_name" === "MIX_BK")
      .select($"client_ds_id").distinct.collect().map(_.getInt(0).toString)

    val medAdjRnWithPrevNextMix = medAdjRnMergedNoMix.alias("m")
      .filter($"m.incl" === "YES" && $"m.client_ds_id".isin(mpvListValue: _*))
      .orderBy( $"abs_payment_amt".asc_nulls_last, $"abs_allowed_amt".asc_nulls_last, $"abs_requested_amt".asc_nulls_last
        , $"rn".asc_nulls_last, $"pay_process_date".asc_nulls_last)
      .select($"m.*",
        lag($"m.abs_requested_amt", 1).over(w).as("prev_abs_requested_amt"),
        lead($"m.abs_requested_amt", 1).over(w).as("next_abs_requested_amt"),
        lag($"m.abs_payment_amt", 1).over(w).as("prev_abs_payment_amt"),
        lead($"m.abs_payment_amt", 1).over(w).as("next_abs_payment_amt"),
        lag($"m.abs_allowed_amt", 1).over(w).as("prev_abs_allowed_amt"),
        lead($"m.abs_allowed_amt", 1).over(w).as("next_abs_allowed_amt"),
        lag($"m.adj1", 1).over(w).as("prev_adj1"),
        lead($"m.adj1", 1).over(w).as("next_adj1"),
        lag($"m.rn", 1).over(w).as("prev_rn"),
        lead($"m.rn", 1).over(w).as("next_rn")
      )

    val adjBackoutMix = medAdjRnWithPrevNextMix.filter(
      (
        $"abs_requested_amt" === $"prev_abs_requested_amt"
          &&  $"abs_allowed_amt" === $"prev_abs_allowed_amt"
          &&  $"abs_payment_amt" === $"prev_abs_payment_amt"
          && $"adj1"  === "M"
          &&  $"prev_adj1" === "P"
          && $"rn" === $"prev_rn"
        ) ||
        (
          $"abs_requested_amt" === $"prev_abs_requested_amt"
            &&  $"abs_allowed_amt" === $"prev_abs_allowed_amt"
            &&  $"abs_payment_amt" === $"prev_abs_payment_amt"
            && $"adj1" === "P"
            &&  $"prev_adj1"  === "M"
            && $"rn" === $"prev_rn"
          ) ||
        (
          $"abs_requested_amt" === $"next_abs_requested_amt"
            &&  $"abs_allowed_amt" === $"next_abs_allowed_amt"
            &&  $"abs_payment_amt" === $"next_abs_payment_amt"
            && $"adj1" === "P"
            &&  $"next_adj1"  === "M"
            && $"rn" === $"next_rn"
          ) ||
        (
          $"abs_requested_amt" === $"next_abs_requested_amt"
            &&  $"abs_allowed_amt" === $"next_abs_allowed_amt"
            &&  $"abs_payment_amt" === $"next_abs_payment_amt"
            && $"adj1" === "M"
            &&  $"next_adj1"  === "P"
            && $"rn" === $"next_rn"
          )
    ).withColumn("revised_adj1",
      when($"adj1" === "P" && $"next_adj1" === "M" && $"rn" ===  $"next_rn", lit("B"))
        .when($"adj1" === "M" && $"prev_adj1" === "P" && $"rn" ===  $"prev_rn", lit("B"))
        .when($"adj1" === "P" && $"prev_adj1" === "M" && $"rn" ===  $"prev_rn", lit("B"))
        .when($"adj1" === "M" && $"next_adj1" === "P" && $"rn" ===  $"next_rn", lit("B"))
        .otherwise($"adj1")).select("client_ds_id", "id_row", "revised_adj1")

    //Step4b : Merge
    // RECORDS MUST BE MERGED BACK AND UPDATED TO B FOR THE N/P PAIRS BEFORE PROCEEDING TO THE NEXT (OPTIONAL) STEP
    val medAdjRnMerged = medAdjRnMergedNoMix.as("med").join(
      adjBackoutMix.as("adj"), $"med.id_row" === $"adj.id_row"
        && $"med.client_ds_id" === $"adj.client_ds_id"
      , "left_outer"
    ).select($"med.*"
      , when(
        $"adj.id_row".isNotNull
          && $"adj.client_ds_id".isNotNull, $"adj.revised_adj1"
      ).otherwise($"med.adj1").as("adj1_new")
    ).drop("adj1").withColumnRenamed("adj1_new", "adj1")

    // STEP 7
    // SET THE FINAL FLAG BASED ON DEFAULTS IF MPV NOT ACTIVATED
    // IF MPV RULES ROW EXIST, THEN SETTINGS ARE CURRENTLY ON THE CLIENT LEVEL
    // ADJUSTMENT FLAG 2 AND 3 ARE SEPARATE RULES THAT OVERRIDE THE FINAL EVAUATION ON WHAT TO SET TO K (KEEP)
    // ONLY ROWS SET TO K ARE KEPT FOR PROCESSING FORWARD INTO CLINICAL ENCOUNTER, PROCEDUREDO, DIAGNOSIS, CLAIM ETC.

    val mpv_adj2_list = mpvList(loadedDependencies("MAP_PREDICATE_VALUES"),
      groupId,
      null,
      "OADW",
      "PPV2",
      "INT_CLAIM_MEDICAL",
      "ADJ2_FILTER"
    ).mkString(",")

    val mpv_adj3_list = mpvList(loadedDependencies("MAP_PREDICATE_VALUES"),
      groupId,
      null,
      "OADW",
      "PPV2",
      "INT_CLAIM_MEDICAL",
      "ADJ3_FILTER"
    ).mkString(",")

    val filterCountValues = medAdjRnMerged.where($"incl" === "YES").select(
      $"adj1".as("adj_pre_flg1")
      ,size(collect_set($"adj1").over(Window.partitionBy($"client_ds_id", $"contract_id", $"member_id", $"service_date",$"servicing_prov_id", $"revenue_code", $"proc_code", $"proc_cd_modifier_1"))).as("distinct_adj1_cnt")
      ,count("*").over(Window.partitionBy($"client_ds_id", $"contract_id", $"member_id", $"service_date",$"servicing_prov_id", $"revenue_code", $"proc_code", $"proc_cd_modifier_1")).as("grp_cnt")
      ,count(when($"adj1" === "B", $"adj1").otherwise(lit(null))).over(Window.partitionBy($"client_ds_id", $"contract_id", $"member_id", $"service_date",$"servicing_prov_id", $"revenue_code", $"proc_code", $"proc_cd_modifier_1")).as("backout_cnt")
      ,count(when($"adj1" === "P", $"adj1").otherwise(lit(null))).over(Window.partitionBy($"client_ds_id", $"contract_id", $"member_id", $"service_date",$"servicing_prov_id", $"revenue_code", $"proc_code", $"proc_cd_modifier_1")).as("positive_cnt")
      ,count(when($"adj1" === "N", $"adj1").otherwise(lit(null))).over(Window.partitionBy($"client_ds_id", $"contract_id", $"member_id", $"service_date",$"servicing_prov_id", $"revenue_code", $"proc_code", $"proc_cd_modifier_1")).as("negative_cnt")
      ,count(when($"adj1" === "P" && coalesce($"allowed_amt", lit(0)) === 0, lit(1))).over(Window.partitionBy($"client_ds_id", $"contract_id", $"member_id", $"service_date",$"servicing_prov_id", $"revenue_code", $"proc_code", $"proc_cd_modifier_1")).as("cnt_allowed_0")
      ,count(when($"adj1" === "P" && $"allowed_amt" > 0, lit(1))).over(Window.partitionBy($"client_ds_id", $"contract_id", $"member_id", $"service_date",$"servicing_prov_id", $"revenue_code", $"proc_code", $"proc_cd_modifier_1")).as("cnt_allowed_postive")
      ,when($"adj1" === "P"
        && coalesce($"allowed_amt"
        , lit(0)) === 0
        , row_number().over(
          Window.partitionBy(
            $"client_ds_id"
            , $"contract_id"
            , $"member_id"
            , $"service_date"
            , $"servicing_prov_id"
            , $"revenue_code"
            , $"proc_code"
            , $"proc_cd_modifier_1").orderBy(
            when($"adj1" === "P", lit(1)).otherwise(lit(2))
            , when(coalesce($"allowed_amt", lit(0)) === 0, lit(1)).otherwise(lit(2))
            , $"pay_process_date".desc_nulls_last
            , coalesce($"requested_amt", lit(0)).desc_nulls_last
            , coalesce($"payment_amt", lit(0)).desc_nulls_last
            , when(IsSafeToNumber.isSafeToNumber($"quantity_of_service"), $"quantity_of_service").otherwise(null).desc_nulls_last
            , $"rn"))).otherwise(
        lit(null)).as("rnk_allowed_0")
      ,$"*"
    )

    // STEP 5
    // SET FLAG 3 BASED ON SPECIFIC RULES
    // STEP 6
    // SET FLAG 2 BASED ON SPECIFIC RULES

    val filterFlag3And2 = filterCountValues.select(
      $"adj_pre_flg1".as("adj_pre_flg_1")
      ,$"client_ds_id"
      ,$"sourcecode"
      ,$"id_row"
      ,when($"grp_cnt" === "1" && $"adj1".isin("P","M"), lit(null))
        .when($"distinct_adj1_cnt" === 1 && $"adj1" === "B",  lit("B"))
        .when($"grp_cnt" - $"backout_cnt" === $"positive_cnt" && $"positive_cnt" === 1, lit("R"))
        .when($"grp_cnt" - $"backout_cnt" === $"negative_cnt" , lit("O"))
        .when($"grp_cnt" - $"backout_cnt" === $"positive_cnt" && $"positive_cnt" > 1, lit("P"))
        .when($"grp_cnt" > "1" && $"positive_cnt" === $"negative_cnt" && $"positive_cnt" > "0" && $"negative_cnt"  > 0, lit("X"))
        .otherwise("M").as("adj_pre_flg_3")
      ,when( $"adj_pre_flg1".isin("B","N","M"), lit("D"))
        .when( $"adj_pre_flg1" === "P" && $"allowed_amt" > 0, lit("K"))
        .when($"cnt_allowed_0" > 0 && $"rnk_allowed_0" === 1 && $"cnt_allowed_postive" === 0, lit("Z"))
        .otherwise(lit("D")).as("adj_pre_flg_2")
    )

    val adjPreFlags = filterFlag3And2.select(
      $"client_ds_id"
      ,$"adj_pre_flg_1"
      ,$"adj_pre_flg_2"
      ,$"adj_pre_flg_3"
      ,$"sourcecode".cast(DataTypes.StringType)
      ,$"id_row"
      ,when($"adj_pre_flg_2".isin(mpv_adj2_list) || $"adj_pre_flg_3".isin(mpv_adj3_list), lit("D"))
        .when($"adj_pre_flg_2" === "D" || $"adj_pre_flg_3".isin("M","X"),lit("D"))
        .otherwise("K").as("claim_adj_type")
    )

    val medClaimAdj1 = medClaimAdj.alias("mc")
      .filter($"mc.incl" === "NO")
      .select($"mc.client_ds_id"
        ,lit("P").cast(DataTypes.StringType).as("adj_pre_flg_1")
        ,when(coalesce($"mc.allowed_amt", lit(0)) === 0, lit("Z")).otherwise(lit("K")).as("adj_pre_flg_2")
        ,lit(null).cast(DataTypes.StringType).as("adj_pre_flg_3")
        ,$"mc.sourcecode".cast(DataTypes.StringType)
        ,$"mc.id_row"
        ,lit(null).cast(DataTypes.StringType).as("claim_adj_type")
      )

    val adjPreFlagsFinal = adjPreFlags.unionByName(medClaimAdj1)
      .filter($"client_ds_id".isin(mpvListValue: _*))

    intClaimMedicalIn.alias("med")
      .withColumnRenamed("source_code", "med_source_code")
      .withColumnRenamed("claim_adj_type", "med_claim_adj_type")
      .withColumnRenamed("adj_pre_flg_1", "med_adj_pre_flg_1")
      .withColumnRenamed("adj_pre_flg_2", "med_adj_pre_flg_2")
      .withColumnRenamed("adj_pre_flg_3", "med_adj_pre_flg_3")
      .join(adjPreFlagsFinal.alias("adj"),
        $"med.rowid" === $"adj.id_row" && $"med.client_ds_id" === $"adj.client_ds_id"
        , "left_outer")
      .select(
        $"med.*"
        , coalesce($"adj.sourcecode", $"med_source_code").as("source_code")
        , $"adj.claim_adj_type".as("claim_adj_type")
        , $"adj.adj_pre_flg_1".as("adj_pre_flg_1")
        , $"adj.adj_pre_flg_2".as("adj_pre_flg_2")
        , $"adj.adj_pre_flg_3".as("adj_pre_flg_3")
      ).drop("med_adj_pre_flg_1","med_adj_pre_flg_2", "med_adj_pre_flg_3", "med_claim_adj_type",  "id_row", "sourcecode", "rowid")

  }
}