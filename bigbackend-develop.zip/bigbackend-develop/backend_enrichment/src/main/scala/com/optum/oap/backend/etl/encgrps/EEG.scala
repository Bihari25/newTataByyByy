
package com.optum.oap.backend.etl.encgrps

import com.optum.oap.cdr.models.eeg
import com.optum.oap.sparkdataloader.QueryAndMetadata

object EEG extends QueryAndMetadata[eeg] {
  override def name: String = "EEG"

  override def partitions: Int = 32

  override def sparkSql: String =
    """
      |SELECT
      |    groupid,
      |    grp_mpi,
      |    encounter_grp_num AS encounter_grp_num_eeg,
      |    patienttype AS patienttype_eeg,
      |    MIN(arrivaltime) AS arrivaltime_eeg,
      |    MAX(dischargetime) AS dischargetime_eeg,
      |    MAX(master_facility_name) AS master_facility_name_eeg
      |FROM
      |    temp_eeg
      |WHERE
      |    patienttype IN (
      |        'CH000107',
      |        'CH000109',
      |        'CH000113'
      |    )
      |    AND rtrim(encounteridtype) IN (
      |        'MASTER',
      |        'ENCTR'
      |    )
      |GROUP BY
      |    groupid,
      |    grp_mpi,
      |    encounter_grp_num,
      |    patienttype
    """.stripMargin

  override def dependsOn: Set[String] = Set("TEMP_EEG")
}