package com.optum.oap.backend.etl.encgrps

import com.optum.oap.backend.cdrTempModel.temp_encounter_clm_chg
import com.optum.oap.sparkdataloader.{RuntimeVariables, TableInfo, UserDefinedFunctionForDataLoader}
import org.apache.spark.sql.functions._
import org.apache.spark.sql.{DataFrame, SparkSession}

object TEMP_ENCOUNTER_CLM_CHG extends TableInfo[temp_encounter_clm_chg] {
  override def name: String = "TEMP_ENCOUNTER_CLM_CHG"

  override def dependsOn: Set[String] = Set("CLAIM","ENCOUNTER_ENCOUNTER_GRP","MAP_VISIT_CHARGE")

  override protected def createDataFrame(sparkSession: SparkSession, loadedDependencies: Map[String, DataFrame],
                                         udfMap: Map[String, UserDefinedFunctionForDataLoader], runtimeVariables: RuntimeVariables): DataFrame = {

    import sparkSession.implicits._

    val claim = loadedDependencies("CLAIM").where($"charge".isNotNull)
    val encounterEncounterGrp = loadedDependencies("ENCOUNTER_ENCOUNTER_GRP").where(not($"encounteridtype".isin("ADD ER", "ADD OB", "ADD SD")))
    val mapVisitCharge = broadcast(loadedDependencies("MAP_VISIT_CHARGE"))

    val baseDF = claim.as("px")
      .join(encounterEncounterGrp.as("eeg"), $"px.groupid" === $"eeg.groupid" and $"px.encounterid" === $"eeg.encounterid" and $"px.client_ds_id" === $"eeg.client_ds_id")

    val nullChargeFlag = baseDF
      .join(mapVisitCharge.as("zvc"), $"px.groupid" === $"zvc.groupid" and $"px.datasrc" === $"zvc.datasrc", "left_outer")
      .where($"zvc.CHARGE_FLAG".isNull)
      .select(
        $"px.groupid",
        $"eeg.grp_mpi",
        $"ENCOUNTER_GRP_NUM",
        $"px.client_ds_id",
        $"px.encounterid",
        $"charge",
        $"servicedate",
        coalesce($"mappedcpt", $"mappedhcpcs", $"mappedicd9").as("cpt_coalesced")
      ).distinct()

    val sumChargeFlag = baseDF
      .join(mapVisitCharge.as("zvc").where($"zvc.CHARGE_FLAG" === "SUM"), $"px.groupid" === $"zvc.groupid" and $"px.datasrc" === $"zvc.datasrc")
      .withColumn("cpt_coalesced", coalesce($"mappedcpt", $"mappedhcpcs", $"mappedicd9"))
      .groupBy($"px.groupid", $"eeg.grp_mpi", $"ENCOUNTER_GRP_NUM", $"px.client_ds_id", $"px.encounterid", $"servicedate", $"cpt_coalesced")
      .agg(
        sum($"charge").as("charge")
      ).select(
        $"px.groupid",
        $"eeg.grp_mpi",
        $"ENCOUNTER_GRP_NUM",
        $"px.client_ds_id",
        $"px.encounterid",
        $"charge",
        $"servicedate",
        $"cpt_coalesced"
      )

    nullChargeFlag.union(sumChargeFlag)
      .groupBy($"groupid", $"grp_mpi", $"ENCOUNTER_GRP_NUM", $"client_ds_id", $"encounterid")
      .agg(
        round(sum($"charge"), 2).as("totchg")
      )
  }
}

