package com.optum.oap.backend.etl.encgrps

import com.optum.oap.backend.cdrTempModel.{temp_eeg_prov_all, temp_visit_enctr}
import com.optum.oap.cdr.models.{claim, encounterprovider, map_provider_role, proceduredo}
import com.optum.oap.sparkdataloader.{RuntimeVariables, TableInfo, UserDefinedFunctionForDataLoader}
import org.apache.spark.sql.types.DataTypes
import org.apache.spark.sql.{DataFrame, SparkSession}

object TEMP_EEG_PROV_ALL extends TableInfo[temp_eeg_prov_all] {

  override def partitions: Int = 256

  override def dependsOn: Set[String] = Set("TEMP_VISIT_ENCTR", "ENCOUNTERPROVIDER", "MAP_PROVIDER_ROLE", "CLAIM", "PROCEDUREDO")

  override protected def createDataFrame(sparkSession: SparkSession,
                                         loadedDependencies: Map[String, DataFrame],
                                         udfMap: Map[String, UserDefinedFunctionForDataLoader],
                                         runtimeVariables: RuntimeVariables): DataFrame = {
    import sparkSession.implicits._
    import org.apache.spark.sql.functions._

    val tempVisitEnctr = loadedDependencies("TEMP_VISIT_ENCTR").as[temp_visit_enctr]
    val encounterProvider = loadedDependencies("ENCOUNTERPROVIDER").as[encounterprovider]
    val mapProviderRole = loadedDependencies("MAP_PROVIDER_ROLE").as[map_provider_role]
    val claim = loadedDependencies("CLAIM").as[claim]
    val proceduredo = loadedDependencies("PROCEDUREDO").as[proceduredo]

    /*
    SELECT
      |            ep.groupid,
      |            ep.grp_mpi,
      |            ep.client_ds_id,
      |            ep.encounterid,
      |            mp.cui AS providerrole,
      |            ep.mstrprovid AS prov_id,
      |            ep.encountertime,
      |            patienttype,
      |            excl AS datasrc_excl
      |        FROM
      |            encounterprovider ep
      |            INNER JOIN temp_visit_enctr ce ON ( ce.groupid = ep.groupid
      |                                                AND ce.client_ds_id = ep.client_ds_id
      |                                                AND ce.grp_mpi = ep.grp_mpi
      |                                                AND ce.encounterid = ep.encounterid )
      |            LEFT OUTER JOIN map_provider_role mp ON ( mp.groupid = ep.groupid
      |                                                      AND mp.localcode = ep.providerrole )
      |        WHERE
      |            ep.grp_mpi IS NOT NULL
      |            AND ep.mstrprovid IS NOT NULL
      |            AND ep.encounterid IS NOT NULL
      |            AND coalesce(mp.cui,'CH999999') != 'CH001410' --referring
     */
    val encounterGrpJoin = encounterProvider.as("ep")
      .join(tempVisitEnctr.as("ce"), $"ep.groupid" === $"ce.groupid" &&
        $"ep.client_ds_id" === $"ce.client_ds_id" &&
        $"ce.grp_mpi" === $"ep.grp_mpi" &&
        $"ce.encounterid" === $"ep.encounterid")
      .join(broadcast(mapProviderRole).as("mp"), $"mp.groupid" === $"ep.groupid" && $"mp.localcode" === $"ep.providerrole", "leftouter")
      .where($"ep.grp_mpi".isNotNull && $"ep.mstrprovid".isNotNull && $"ep.encounterid".isNotNull && coalesce($"mp.cui", lit("CH999999")) =!= lit("CH001410"))
      .select(
        $"ep.groupid",
        $"ep.grp_mpi",
        $"ep.client_ds_id",
        $"ep.encounterid",
        $"mp.cui".as("providerrole"),
        $"ep.mstrprovid".as("prov_id"),
        $"ep.encountertime",
        $"patienttype",
        $"excl".as("datasrc_excl")
      )

    /*
   SELECT
      |            ep.groupid,
      |            ep.grp_mpi,
      |            ep.client_ds_id,
      |            ep.encounterid,
      |            'CH001417' AS providerrole,
      |            ep.performing_mstrprovid,
      |            proceduredate,
      |            patienttype,
      |            excl AS datasrc_excl
      |        FROM
      |            proceduredo ep
      |            INNER JOIN temp_visit_enctr ce ON ( ep.groupid = ce.groupid
      |                                                AND ep.client_ds_id = ce.client_ds_id
      |                                                AND ep.encounterid = ce.encounterid
      |                                                AND ep.grp_mpi = ce.grp_mpi )
      |        WHERE
      |            ep.grp_mpi IS NOT NULL
      |            AND ep.performing_mstrprovid IS NOT NULL
      |            AND ep.encounterid IS NOT NULL
     */
    val procedureDoJoin = proceduredo.as("ep")
      .join(tempVisitEnctr.as("ce"), $"ep.groupid" === $"ce.groupid" &&
        $"ep.client_ds_id" === $"ce.client_ds_id" &&
        $"ce.grp_mpi" === $"ep.grp_mpi" &&
        $"ce.encounterid" === $"ep.encounterid")
      .where($"ep.grp_mpi".isNotNull && $"ep.performing_mstrprovid".isNotNull && $"ep.encounterid".isNotNull)
      .select(
        $"ep.groupid",
        $"ep.grp_mpi",
        $"ep.client_ds_id",
        $"ep.encounterid",
        lit("CH001417").as("providerrole"),
        $"ep.performing_mstrprovid".as("prov_id"),
        $"ep.proceduredate".as("encountertime"),
        $"patienttype",
        $"excl".as("datasrc_excl")
      )

    /*
    SELECT
      |            ep.groupid,
      |            ep.grp_mpi,
      |            ep.client_ds_id,
      |            ep.encounterid,
      |            'CH001417' AS providerrole,
      |            ep.claim_mstrprovid,
      |            servicedate,
      |            patienttype,
      |            excl AS datasrc_excl
      |        FROM
      |            claim ep
      |            INNER JOIN temp_visit_enctr ce ON ( ep.groupid = ce.groupid
      |                                                AND ep.client_ds_id = ce.client_ds_id
      |                                                AND ep.encounterid = ce.encounterid
      |                                                AND ep.grp_mpi = ce.grp_mpi )
      |        WHERE
      |            ep.grp_mpi IS NOT NULL
      |            AND ep.claim_mstrprovid IS NOT NULL
      |            AND ep.encounterid IS NOT NULL
     */
    val claimJoin = claim.as("ep")
      .join(tempVisitEnctr.as("ce"), $"ep.groupid" === $"ce.groupid" &&
        $"ep.client_ds_id" === $"ce.client_ds_id" &&
        $"ce.grp_mpi" === $"ep.grp_mpi" &&
        $"ce.encounterid" === $"ep.encounterid")
      .where($"ep.grp_mpi".isNotNull && $"ep.claim_mstrprovid".isNotNull && $"ep.encounterid".isNotNull)
      .select(
        $"ep.groupid",
        $"ep.grp_mpi",
        $"ep.client_ds_id",
        $"ep.encounterid",
        lit("CH001417").as("providerrole"),
        $"ep.claim_mstrprovid".as("prov_id"),
        $"ep.servicedate".as("encountertime"),
        $"patienttype",
        $"excl".as("datasrc_excl")
      )

    val result = encounterGrpJoin
      .union(procedureDoJoin)
      .union(claimJoin)
      .groupBy(
        $"groupid",
        $"grp_mpi",
        $"client_ds_id",
        $"encounterid",
        $"providerrole",
        $"prov_id".cast(DataTypes.LongType).as("prov_id"),
        $"patienttype",
        $"datasrc_excl"
      ).agg(min($"encountertime").as("min_prov_dtm"), max($"encountertime").as("max_prov_dtm"))

    result
  }
}