package com.optum.oap.backend.etl.common

import com.optum.oap.backend.etl.common.UnitConversionFunction.UnitConversionFunction
import com.optum.oap.sparkdataloader.UserDefinedFunctionForDataLoader
import org.apache.spark.sql.SparkSession
import org.apache.spark.sql.expressions.UserDefinedFunction
import org.apache.spark.sql.functions.udf

object UnitConv extends UserDefinedFunctionForDataLoader with UnitConversion {

  def applyUnitConv(value: Double, func: String):Double = {
    val conversionType: UnitConversionFunction = UnitConversionFunction.values.find(
      _.toString.toLowerCase == func.toLowerCase
    ).getOrElse(UnitConversionFunction.LINEAR)
    applyUnitConversionFunction(value, conversionType)
  }

  val applyUnitConvFunction :UserDefinedFunction  = udf(applyUnitConv _)

  override def name: String = "applyUnitConvFunction"

  override def registerMe(sparkSession: SparkSession): Unit = {
    sparkSession.udf.register(name, applyUnitConvFunction)
  }

}


