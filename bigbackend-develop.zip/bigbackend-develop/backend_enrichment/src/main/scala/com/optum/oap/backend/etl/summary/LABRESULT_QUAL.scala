package com.optum.oap.backend.etl.summary

import com.optum.oap.cdr.models.labresult_qual
import com.optum.oap.sparkdataloader.{RuntimeVariables, TableInfo, UserDefinedFunctionForDataLoader}
import org.apache.spark.sql.expressions.Window
import org.apache.spark.sql.types.{LongType, TimestampType}
import org.apache.spark.sql.{DataFrame, SparkSession}
import org.slf4j.LoggerFactory

/**
  *
  * Copyright 2019 Optum Analytics
  *
  * Date: 4/24/19
  *
  * Creator: bpokharel(bishu)
  */
object LABRESULT_QUAL extends TableInfo[labresult_qual] {

  val log = LoggerFactory.getLogger(this.getClass)

  override def dependsOn =
    Set("LABRESULT", "ZCM_QUALITATIVE_RESULTS")

  override def name = "LABRESULT_QUAL"

  override def saveDataFrameToParquet: Boolean = true

  override def partitions: Int = 256

  override def skipTable: Boolean = false

  override def ignoreExtraColumnsInDataFrame: Boolean = true

  override def createDataFrame(
                                sparkSession: SparkSession,
                                loadedDependencies: Map[String, DataFrame],
                                udfMap: Map[String, UserDefinedFunctionForDataLoader],
                                runtimeVariables: RuntimeVariables
                              ): DataFrame = {

    import org.apache.spark.sql.functions._
    import sparkSession.implicits._

    val labresult_DF = loadedDependencies("LABRESULT")
    val zcm_qualitative_results_DF = loadedDependencies("ZCM_QUALITATIVE_RESULTS")


    val partitionBy = Window
      .partitionBy($"lr.grp_mpi", to_date(coalesce($"lr.datecollected", $"lr.dateavailable")))
      .orderBy($"zqr.qualitativeresult_rank".desc_nulls_last)

    // join labresult and zcm_qualitative_results
    val joined_DF =
      labresult_DF.as("lr").join(
        broadcast(zcm_qualitative_results_DF).as("zqr"),
        $"lr.mappedcode" === $"zqr.mappedcode" &&
          $"lr.normalizedvalue".geq($"zqr.std_value_low") &&
          $"lr.normalizedvalue".lt($"zqr.std_value_high")
      )
        .where(coalesce($"lr.datecollected", $"lr.dateavailable").isNotNull)
        .withColumn("day_rank", row_number().over(partitionBy))
        .select($"lr.groupid",
          $"lr.grp_mpi",
          $"lr.mappedcode".as("htslabcode"),
          coalesce($"lr.datecollected", $"lr.dateavailable"),
          coalesce($"lr.datecollected", $"lr.dateavailable").as("resultdate"),
          $"lr.localresult_inferred",
          $"lr.normalizedvalue".as("standard_value"),
          $"zqr.qualitativeresult".as("qual_result"),
          $"zqr.htsresultgroup",
          $"zqr.interval_days",
          $"zqr.is_positive",
          $"day_rank"
        )

    val filterd_DF=joined_DF.filter("day_rank = 1 ")
    /*
     * I didn't find inbuilt support for date intervals thus converting to seconds for calculation.
     */
    val window1 = Window
      .partitionBy(filterd_DF("grp_mpi"))
      .orderBy(to_date(filterd_DF("resultdate")).cast(TimestampType).cast(LongType))
      // adding 1 hour to 180 days to account for 1 hour in day light savings.
      .rangeBetween(-secondsInNDays(180) - 3600, secondsInNDays(180) + 3600)

    val df2 = filterd_DF
      .withColumn("max_qualitativeresult", max(coalesce(filterd_DF("qual_result"), lit("CHBAD"))).over(window1))
      .withColumn("min_qualitativeresult", min(coalesce(filterd_DF("qual_result"), lit("CHBAD"))).over(window1))
      .withColumn("number_positive", sum(filterd_DF("is_positive")).over(window1))
      .withColumn("number_tests", sum(lit(1)).over(window1))
      .select(
        $"groupid",
        $"grp_mpi",
        $"htsresultgroup",
        $"resultdate",
        $"htslabcode",
        $"qual_result".as("htslabresult"),
        $"max_qualitativeresult",
        $"min_qualitativeresult",
        $"number_positive",
        $"number_tests"
      )

    val finalDf = labresult_DF.as("tld")
      .join(df2.alias("df2"),
        $"tld.groupid" === $"df2.groupid"
          && $"tld.grp_mpi" === $"df2.grp_mpi"
          && to_date(coalesce($"tld.datecollected", $"tld.dateavailable")) === to_date($"df2.resultdate")
      )
      .join(zcm_qualitative_results_DF.alias("zcrren"),
        $"tld.mappedcode" === $"zcrren.mappedcode"
          && $"tld.normalizedvalue".geq($"zcrren.std_value_low")
          && $"tld.normalizedvalue".lt($"zcrren.std_value_high")
      )
      .filter(coalesce($"tld.datecollected", $"tld.dateavailable").isNotNull)
      .withColumn(
        "qualitativeresult_new",
        when($"df2.number_positive".gt(1), $"df2.max_qualitativeresult")
          .when($"df2.number_tests".leq(1), lit(null))
          .when($"df2.number_tests".geq(1) and $"df2.number_positive".lt(2), $"df2.min_qualitativeresult")
          .otherwise($"zcrren.qualitativeresult"))
      .withColumn("resultdate", coalesce($"tld.datecollected", $"tld.dateavailable"))
      .select(
        $"tld.groupid",
        $"tld.patientid",
        $"df2.htsresultgroup",
        $"resultdate",
        $"tld.mappedcode".as("htslabcode"),
        $"zcrren.qualitativeresult".as("htslabresult"),
        $"qualitativeresult_new".as("qualitativeresult"),
        $"tld.client_ds_id",
        $"tld.hgpid",
        $"tld.grp_mpi"
      )

    finalDf.as[labresult_qual].toDF()
  }

  /*
    * @param nDay number of days
    * Hive timestamp is interpreted as UNIX timestamp in seconds
    * https://stackoverflow.com/questions/33207164/spark-window-functions-rangebetween-dates
    */
  def secondsInNDays(nDay: Long): Long = {
    nDay * 24 * 60 * 60
  }
}
