package com.optum.oap.backend.etl.enrichment

import com.optum.oap.backend.cdrTempModel.int_claim_med_proc
import com.optum.oap.backend.etl.common.IsSafeToNumber
import com.optum.oap.cdr.models._
import com.optum.oap.sparkdataloader.{RuntimeVariables, TableInfo, UserDefinedFunctionForDataLoader}
import org.apache.spark.sql.expressions.Window
import org.apache.spark.sql.functions._
import org.apache.spark.sql.types.{DataTypes, IntegerType}
import org.apache.spark.sql.{DataFrame, SparkSession}
import org.slf4j.LoggerFactory

object ICPM_PROCEDURE extends TableInfo[proceduredo] {

  private val log = LoggerFactory.getLogger(this.getClass)

  override def dependsOn = Set("ICPM_TEMP_MED_CLAIM")

  override def name = "ICPM_PROCEDURE"

  override def createDataFrame(sparkSession: SparkSession,
                               loadedDependencies: Map[String, DataFrame],
                               udfMap: Map[String, UserDefinedFunctionForDataLoader],
                               runtimeVariables: RuntimeVariables): DataFrame = {
    import sparkSession.implicits._

    val tempMedClaimIn = loadedDependencies("ICPM_TEMP_MED_CLAIM") //.as[int_claim_med_proc]

    val medClaim = tempMedClaimIn.alias("mc")
      .select($"mc.*",
        lit(null).cast(DataTypes.StringType).as("proctype"),
        lit(null).cast(DataTypes.StringType).as("revtype")
      )

    val cdrFeProc = medClaim.select(
      $"groupid",
      $"datasrc",
      $"client_ds_id",
      $"pay_process_date",
      $"member_id".as("patientid"),
      $"service_date".as("proceduredate"),
      $"service_date".as("actualprocdate"),
      $"encounterid",
      when($"datasrc" === "int_claim_medical_i", lit("Y")).otherwise(lit("N")).as("hosp_px_flag"),
      $"billing_prov_id".as("localbillingproviderid"),
      $"ordering_prov_id".as("orderingproviderid"),
      when($"datasrc" === "int_claim_medical_p", $"servicing_prov_id").otherwise(null).as("performingproviderid"),
      $"referring_prov_id".as("referproviderid"),
      $"source_code".as("sourceid"),
      expr("stack(28, " +
        "icd_proc_cd_1, icd_proc_cd_1_type, 'CODE1', " +
        "icd_proc_cd_2, icd_proc_cd_2_type, 'CODE2', " +
        "icd_proc_cd_3, icd_proc_cd_3_type, 'CODE3', " +
        "icd_proc_cd_4, icd_proc_cd_4_type, 'CODE4', " +
        "icd_proc_cd_5, icd_proc_cd_5_type, 'CODE5', " +
        "icd_proc_cd_6, icd_proc_cd_6_type, 'CODE6', " +
        "icd_proc_cd_7, icd_proc_cd_7_type, 'CODE7', " +
        "icd_proc_cd_8, icd_proc_cd_8_type, 'CODE8', " +
        "icd_proc_cd_9, icd_proc_cd_9_type, 'CODE9', " +
        "icd_proc_cd_10, icd_proc_cd_10_type, 'CODE10', " +
        "icd_proc_cd_11, icd_proc_cd_11_type, 'CODE11', " +
        "icd_proc_cd_12, icd_proc_cd_12_type, 'CODE12', " +
        "icd_proc_cd_13, Icd_Proc_Cd_13_Type, 'CODE13', " +
        "icd_proc_cd_14, icd_proc_cd_14_type, 'CODE14', " +
        "icd_proc_cd_15, icd_proc_cd_15_type, 'CODE15', " +
        "icd_proc_cd_16, icd_proc_cd_16_type, 'CODE16', " +
        "icd_proc_cd_17, icd_proc_cd_17_type, 'CODE17', " +
        "icd_proc_cd_18, icd_proc_cd_18_type, 'CODE18', " +
        "icd_proc_cd_19, icd_proc_cd_19_type, 'CODE19', " +
        "icd_proc_cd_20, icd_proc_cd_20_type, 'CODE20', " +
        "icd_proc_cd_21, icd_proc_cd_21_type, 'CODE21', " +
        "icd_proc_cd_22, icd_proc_cd_22_type, 'CODE22', " +
        "icd_proc_cd_23, icd_proc_cd_23_type, 'CODE23', " +
        "icd_proc_cd_24, icd_proc_cd_24_type, 'CODE24', " +
        "icd_proc_cd_25, icd_proc_cd_25_type, 'CODE25', " +
        "principle_proc_cd, principle_proc_icd_type, 'PRINCIPLE_PROC_CD', " +
        "proc_code, proctype, 'PROC_CODE', " +
        "revenue_code, revtype, 'REV_CODE') " +
        " as (procedure_code, proc_type, source)")
    ).filter($"procedure_code".isNotNull)

    cdrFeProc.alias("pr")
      .filter($"pr.proceduredate".isNotNull && $"pr.patientid".isNotNull)
      .select(
        $"pr.groupid",
        $"pr.client_ds_id",
        $"pr.datasrc",
        $"pr.procedure_code".as("localcode"),
        $"pr.patientid",
        $"pr.proceduredate",
        $"pr.actualprocdate",
        $"pr.encounterid",
        $"pr.hosp_px_flag",
        $"pr.localbillingproviderid",
        $"pr.orderingproviderid",
        $"pr.performingproviderid",
        when($"pr.source" === "PRINCIPLE_PROC_CD", lit("Y")).otherwise("N").as("localprincipleindicator"),
        $"pr.referproviderid",
        $"pr.sourceid",
        when($"pr.source" === "REV_CODE", lpad($"pr.procedure_code", 4, "0"))
            .when($"pr.source" === "PROC_CODE", substring($"pr.procedure_code", 1, 5))
            .otherwise($"pr.procedure_code").as("mappedcode"),
        when($"pr.source" === "REV_CODE", lit("REV")).otherwise($"pr.proc_type").as("codetype"),
        when($"pr.source".like("CODE%"),
          when(IsSafeToNumber.isSafeToNumber(substring($"pr.source", 5, 2)), substring($"pr.source", 5, 2)).otherwise(null))
          .otherwise(null).cast(IntegerType).as("procseq"),
        $"pr.pay_process_date",
        lit(null).cast(DataTypes.StringType).as("facilityid"),
        lit(null).cast(DataTypes.StringType).as("grp_mpi"),
        lit(null).cast(DataTypes.LongType).as("hgpid"),
        lit(null).cast(DataTypes.StringType).as("procedurecodesourcetable"),
        lit(null).cast(DataTypes.StringType).as("localname"),
        lit(null).cast(DataTypes.StringType).as("performing_mstrprovid"),
        lit(null).cast(DataTypes.TimestampType).as("proc_end_date"),
        lit(null).cast(DataTypes.StringType).as("orig_mappedcode"),
        lit(null).cast(DataTypes.StringType).as("orig_codetype")
      )
      .withColumn("rank_proc", row_number().over(Window.partitionBy($"client_ds_id", $"sourceid", $"encounterid",
        $"localcode", $"hosp_px_flag", $"localprincipleindicator", $"proceduredate", $"procseq")
        .orderBy($"pay_process_date".desc_nulls_last)))
      .filter(
        $"rank_proc" === 1
          && $"pr.proceduredate".isNotNull
          && $"pr.patientid".isNotNull).drop("rank_proc", "pay_process_date")
  }
}
