package com.optum.oap.backend.etl.summary

import com.optum.oap.cdr.models.prov_pat_rel_summary
import com.optum.oap.sparkdataloader.{RuntimeVariables, TableInfo, UserDefinedFunctionForDataLoader}
import org.apache.spark.sql.expressions.Window
import org.apache.spark.sql.functions._
import org.apache.spark.sql.types.{StringType, TimestampType}
import org.apache.spark.sql.{DataFrame, SparkSession}
import org.slf4j.LoggerFactory


object PROV_PAT_REL_SUMMARY extends TableInfo[prov_pat_rel_summary] {
  val log = LoggerFactory.getLogger(this.getClass)
  override def dependsOn =  Set("PROV_PAT_REL", "MAP_PCP_ORDER", "ZH_PROVIDER_MASTER")

  override def name = "PROV_PAT_REL_SUMMARY"

  override def saveDataFrameToParquet: Boolean = true
  override def partitions: Int = 32
  override def skipTable: Boolean = false
  override def ignoreExtraColumnsInDataFrame: Boolean = false

  override def createDataFrame (sparkSession: SparkSession,
                                loadedDependencies: Map[String, DataFrame],
                                udfMap: Map[String, UserDefinedFunctionForDataLoader],
                                runtimeVariables: RuntimeVariables): DataFrame = {

    val prov_pat_relDF = loadedDependencies("PROV_PAT_REL")

    val map_pcp_order_DF = broadcast(loadedDependencies("MAP_PCP_ORDER"))

    val zh_provider_master_DF = loadedDependencies("ZH_PROVIDER_MASTER")

    val prov_pat_relDF1 = prov_pat_relDF.filter("GRP_MPI is not null and localrelshipcode='PCP'")

    val map_pcp_order_DF1 = map_pcp_order_DF.filter("coalesce(pcp_exclude_flg, 'N') <> 'Y' ")
      .withColumn("pcp_order", coalesce(map_pcp_order_DF("pcp_order"), lit(99)))

    val zh_provider_master_DF1 = zh_provider_master_DF.withColumnRenamed("master_hgprovid", "mstrprovid")
      .withColumn("providerexclusionflag", coalesce(zh_provider_master_DF("providerexclusionflag"), lit("N")))
    val joinedDF1 =
      prov_pat_relDF1
        .withColumn("startdate", to_date(prov_pat_relDF1("startdate")))
        .withColumn("enddate", to_date(coalesce(prov_pat_relDF1("enddate"), concat(year(current_date()), lit("-12-31")))))
        .join(broadcast(map_pcp_order_DF1), Seq("groupid", "client_ds_id", "datasrc"), "left_outer")
        .withColumn("pcp_order", coalesce(map_pcp_order_DF1("pcp_order"), lit(99)))

    val group1 = joinedDF1.groupBy("groupid", "grp_mpi", "pcp_order")


    val group1agg = group1.agg(
      min(to_date(joinedDF1("startdate"))).as("min_startdate"),
      max(to_date(coalesce(joinedDF1("enddate"), concat(year(current_date()), lit("-12-31"))))).as("max_enddate")
    )
      .withColumnRenamed("groupid", "groupid_agg")
      .withColumnRenamed("grp_mpi", "grp_mpi_agg")
      .withColumnRenamed("pcp_order", "pcp_order_agg")

    val joinedDF2 =
      joinedDF1
        .join(zh_provider_master_DF1, Seq("groupid", "mstrprovid"), "left_outer")
        .select("groupid", "datasrc", "providerid", "localrelshipcode", "startdate",
          "enddate", "client_ds_id", "grp_mpi", "mstrprovid",
          "pcp_order", "providerexclusionflag", "prov_affil_id").distinct

    val JoinDF3 = joinedDF2
      .join(group1agg,
        joinedDF2("groupid") === group1agg("groupid_agg") and
          joinedDF2("grp_mpi") === group1agg("grp_mpi_agg") and
          joinedDF2("pcp_order").gt(group1agg("pcp_order_agg"))
        , "left_outer")
      .drop("groupid_agg", "grp_mpi_agg", "pcp_order_agg")

    val c_df1 = JoinDF3.select("groupid", "datasrc", "providerid", "localrelshipcode"
      , "startdate", "enddate", "client_ds_id", "grp_mpi", "mstrprovid"
      , "pcp_order", "providerexclusionflag", "min_startdate", "max_enddate", "prov_affil_id")

    val c_df2 = c_df1.groupBy("groupid", "datasrc", "providerid", "localrelshipcode", "startdate"
      , "enddate", "client_ds_id", "grp_mpi", "mstrprovid"
      , "pcp_order", "providerexclusionflag", "prov_affil_id")
      .agg(
        min("min_startdate").as("min_startdate"),
        max("max_enddate").as("max_enddate")
      )

    val c_df3 = c_df2.orderBy(
      c_df2("grp_mpi"), c_df2("startdate"), c_df2("enddate"),
      c_df2("providerexclusionflag").desc,
      c_df2("mstrprovid"), c_df2("client_ds_id").desc,
      c_df2("providerid").desc
    )

    val c_df4 = c_df3.filter(
      "min_startdate is null or " +
        " startdate < min_startdate " +
        " or startdate > max_enddate "

    )

    val group = Window.partitionBy(c_df4("groupid"), c_df4("grp_mpi"))
      .orderBy(c_df4("groupid"), c_df4("grp_mpi"), c_df4("startdate"),
        c_df4("enddate"), c_df4("providerexclusionflag").desc_nulls_first,
        c_df4("mstrprovid").asc_nulls_first, c_df4("client_ds_id").desc,
        c_df4("providerid").desc, c_df4("min_startdate").asc, c_df4("max_enddate").desc,
        c_df4("datasrc"))

    val lead1 = c_df4.withColumn("leadstartdate", lead("startdate", 1).over(group))

    val lead2 = lead1.withColumn("leadstartdate",
      least(coalesce(
        date_sub(lead1("leadstartdate"), 1), lead1("enddate")
      ), lead1("enddate"))
    )

    val lead3 = lead2.withColumn("enddate", when(lead2("leadstartdate")
      === to_date(concat(year(current_date()), lit("-12-31"))), null)
      .otherwise(lead2("leadstartdate")))

    val c_df5 = lead3.filter(" enddate >= startdate or enddate is null ")
        .withColumn("startdate", lead3("startdate").cast(TimestampType))
        .withColumn("enddate", lead3("enddate").cast(TimestampType))
        .withColumn("contract_id", lit(null).cast(StringType))

    c_df5.select("groupid", "datasrc", "providerid", "localrelshipcode",
      "startdate", "enddate", "client_ds_id", "grp_mpi", "mstrprovid", "contract_id", "prov_affil_id")

  }
}