package com.optum.oap.backend.etl.enrichment

import com.optum.oap.backend.etl.common.{MapMasterIds, MatchRegExPattern, UnitConv}
import com.optum.oap.backend.loader.EnrichmentRunTimeVariables
import com.optum.oap.cdr.models._
import com.optum.oap.sparkdataloader.{RuntimeVariables, TableInfo, UserDefinedFunctionForDataLoader}
import org.apache.spark.sql.expressions.Window
import org.apache.spark.sql.functions._
import org.apache.spark.sql.types.DoubleType
import org.apache.spark.sql.{DataFrame, Dataset, SparkSession}
import org.slf4j.LoggerFactory
import scala.util.Try

import java.util.regex.Pattern

object LABRESULT extends TableInfo[labresult] {

  val log = LoggerFactory.getLogger(this.getClass)

  val nonAliasCols: Set[String] = Set("labresult_date", "mappedcode", "mappedname", "normalizedvalue", "resulttype", "mappedloinc", "mapped_qual_code", "mappedunits", "localunits")

  override def dependsOn = Set("CDR_FE_LABRESULT", "ICPM_LABRESULT", "PATIENT_MPI", "UNIT_REFRANGE_LAB_MAP", "MAP_LAB_CODES", "UNIT_REMAP", "MAP_UNIT", "V_METADATA_LAB", "UNIT_CONVERSION",
    "MAP_HTS_TERM", "MAP_LAB_LOINC", "ZCM_LAB_NAME_PATTERN", "MV_HTS_DOMAIN_CONCEPT", "MAP_QUAL_TEXT_RESULT", "MAP_QUAL_NUM_RESULT")

  override def name = "LABRESULT"

  override def saveDataFrameToParquet: Boolean = true

  override def partitions: Int = 256

  override def skipTable: Boolean = false

  override def ignoreExtraColumnsInDataFrame: Boolean = true

  override def createDataFrame(sparkSession: SparkSession,
                               loadedDependencies: Map[String, DataFrame],
                               udfMap: Map[String, UserDefinedFunctionForDataLoader],
                               runtimeVariables: RuntimeVariables): DataFrame = {
    import sparkSession.implicits._

    val labresultIn = loadedDependencies("CDR_FE_LABRESULT").drop("row_source","modified_date").as[labresult]
    val patXref = loadedDependencies("PATIENT_MPI").as[patient_mpi]
    val unitRefrangeLabMap = broadcast(loadedDependencies("UNIT_REFRANGE_LAB_MAP")).as[unit_refrange_lab_map]
    val mapLabCodes = broadcast(loadedDependencies("MAP_LAB_CODES")).as[map_lab_codes]
    val unitRemap = broadcast(loadedDependencies("UNIT_REMAP")).as[unit_remap]
    val mapUnit = broadcast(loadedDependencies("MAP_UNIT")).as[map_unit]
    val vMetaDataLab = broadcast(loadedDependencies("V_METADATA_LAB")).as[v_metadata_lab]
    val unitConversion = broadcast(loadedDependencies("UNIT_CONVERSION")).as[unit_conversion]
    val mapHtsTerm = broadcast(loadedDependencies("MAP_HTS_TERM")).as[map_hts_term]
    val mapLabLoinc = broadcast(loadedDependencies("MAP_LAB_LOINC")).as[map_lab_loinc]
    val zcmLabMapPattern = broadcast(loadedDependencies("ZCM_LAB_NAME_PATTERN")).as[zcm_lab_name_pattern]
    val mvHtsDomainConcept = broadcast(loadedDependencies("MV_HTS_DOMAIN_CONCEPT")).as[mv_hts_domain_concept]
    val mapQualTextResult = broadcast(loadedDependencies("MAP_QUAL_TEXT_RESULT")).as[map_qual_text_result]
    val mapQualNumResult = broadcast(loadedDependencies("MAP_QUAL_NUM_RESULT")).as[map_qual_num_result]
    val labResultICPM = loadedDependencies("ICPM_LABRESULT").as[labresult]
    val labResultUnion = labresultIn.unionByName(labResultICPM)


    val mappedLabResult = MapMasterIds.mapPatientIds(labResultUnion.toDF, patXref.toDF, false)

    val partitionMultiplier = EnrichmentRunTimeVariables(runtimeVariables).partitionMultiplier

    val cols = mappedLabResult.columns.toSet

    val minTermCodes = mapHtsTerm
      .filter($"preferred" === lit("Y") && $"terminology_cui" === lit("CH002050"))
      .groupBy($"hts_cui")
      .agg(min($"term_code").as("term_code"))

    val tempLabresult = mappedLabResult
      .withColumn("normalrange", trim($"normalrange"))
      .withColumn("localunits", lower($"localunits"))
      .withColumn("localresult_inferred", coalesce($"localresult_numeric", $"localresult_inferred"))
      .select(
        $"*",
        regexp_extract($"normalrange".substr(lit(1),instr($"normalrange", "-") - 1), "([0-9]*[.]{0,1}[0-9]*)", 1).cast(DoubleType).as("range_low"),
        regexp_extract($"normalrange".substr(instr($"normalrange", "-") + 1, length($"normalrange")), "([0-9]*[.]{0,1}[0-9]*)", 1).cast(DoubleType).as("range_high"),
        upper($"normalrange").as("nrml_rng")
      )
      .drop("mappedname", "mappedunits", "mappedcode", "mappedloinc", "normalizedvalue", "resulttype")

    val mbUnitRefrangeLabMap = unitRefrangeLabMap.withColumn("localrange_lower_double", $"localrange_lower".cast(DoubleType))

    val selectCols = getSelectList(cols, nonAliasCols, "a")

    val dfJoin = tempLabresult.as("a")
      .join(mbUnitRefrangeLabMap.as("rm"), getUnitRefrange(sparkSession, "rm", false), "left_outer")
      .join(mbUnitRefrangeLabMap.as("crm"), getUnitRefrange(sparkSession, "crm", true), "left_outer")
      .join(mapLabCodes.where(coalesce($"mapping_context", lit("HTS")) === lit("HTS")).as("d"), $"a.groupid" === $"d.groupid" && $"a.localcode" === $"d.mnemonic" && $"a.client_ds_id" === $"d.client_ds_id", "left_outer")
      .join(mapUnit.as("mu"), lower(coalesce($"a.localunits", $"a.localunits_inferred")) === $"mu.localcode", "left_outer")

    val remapJoinClient  = getUnitMapClient(sparkSession, dfJoin, unitRemap)
    val remapJoin  = getUnitMap(sparkSession, remapJoinClient, unitRemap)

    val tempLab = remapJoin
      .join(vMetaDataLab.as("mdl"), coalesce($"crm.hts_lab_cui", $"rm.hts_lab_cui", $"d.cui") === $"mdl.cui", "left_outer")
      .join(unitConversion.where($"hts_test" === lit("CH999999")).as("uc"), $"uc.src_unit" === coalesce($"clgulu.unit", $"clgu.unit", $"cur.unit", $"lgulu.unit", $"lgu.unit", $"ur.unit", $"mu.cui") && $"uc.dest_unit" === $"mdl.unit", "left_outer")
      .join(unitConversion.where($"hts_test" =!= lit("CH999999")).as("ucl"), $"ucl.src_unit" === coalesce($"clgulu.unit", $"clgu.unit", $"cur.unit", $"lgulu.unit", $"lgu.unit", $"ur.unit", $"mu.cui") && $"ucl.dest_unit" === $"mdl.unit" && $"ucl.hts_test" === coalesce($"crm.hts_lab_cui", $"rm.hts_lab_cui", $"d.cui"), "left_outer")
      .join(broadcast(minTermCodes.as("mht")), $"mht.hts_cui" === coalesce($"crm.hts_lab_cui", $"rm.hts_lab_cui", $"d.cui"), "left_outer")
      .withColumn("new_normalizedvalue", when($"relativeindicator" === lit("<"), lit(-.01)).
        when($"relativeindicator" === lit(">"), lit(.01)).
        otherwise(lit(0)) +
        when(coalesce($"clgulu.unit", $"clgu.unit", $"cur.unit", $"lgulu.unit", $"lgu.unit", $"ur.unit", $"mu.cui") === $"mdl.unit", $"localresult_inferred").
          when(coalesce($"ucl.conv_fact", $"uc.conv_fact").isNotNull, round(UnitConv.applyUnitConvFunction($"localresult_inferred" * coalesce($"ucl.conv_fact", $"uc.conv_fact"),coalesce($"ucl.function_applied", $"uc.function_applied")), 2)).
          otherwise(lit(null)))
      .withColumn("labresult_date",coalesce($"datecollected",$"dateavailable", $"labordereddate", $"labresult_date"))
      .select($"*",
        $"mdl.hts_test_name".as("mappedname"),
        coalesce($"crm.hts_lab_cui", $"rm.hts_lab_cui", $"d.cui").as("mappedcode"),
        when($"new_normalizedvalue".isNotNull, $"mdl.unit").otherwise(coalesce($"clgu.unit", $"cur.unit", $"lgu.unit", $"ur.unit", $"mu.cui")).as("mappedunits"),
        $"mht.term_code".as("mappedloinc"),
        when($"relativeindicator" === lit("<"), round($"new_normalizedvalue", 2))
          .when($"relativeindicator" === lit(">"), round($"new_normalizedvalue", 2))
          .otherwise($"new_normalizedvalue").as("normalizedvalue"),
        when(($"new_normalizedvalue" < $"mdl.semantic_val_min") || ($"new_normalizedvalue" > $"mdl.semantic_val_max"), lit("CH999990"))
          .when($"localresult".isNull, lit("CH999999"))
          .otherwise(lit(null)).as("resulttype")
      )
      .select(selectCols.head, selectCols.tail:_*)


    val uniqueLoinc = mapLabLoinc.select($"loinc").distinct

    val tmpUniLocres = tempLab
      .join(uniqueLoinc.as("mll"), coalesce($"local_loinc_code", $"localcode") === $"loinc", "left_outer")
      .groupBy(
        $"groupid",
        $"localresult",
        when($"localresult".isNotNull && $"mappedcode".isNotNull, $"localresult_numeric")
          .otherwise(lit(null)).as("localresult_numeric"),
        when($"localresult".isNotNull && $"mappedcode".isNotNull, $"mappedcode")
          .otherwise(lit(null)).as("mappedcode"),
        when($"mappedcode".isNull, coalesce($"local_loinc_code", $"localcode"))
          .otherwise(lit(null)).as("local_loinc_code"),
        when($"mappedcode".isNull, lower($"localname"))
          .otherwise(lit(null)).as("localname")
      )
      .agg(count(lit(1)).as("cnt"))
      .select(
        $"groupid",
        $"mappedcode",
        $"local_loinc_code",
        $"localresult_numeric",
        $"localname",
        $"localresult"
      )

    val mbLabMap = zcmLabMapPattern
      .groupBy($"groupid", $"cui", $"priority")
      .agg(collect_list(struct(regexp_replace($"txt_pattern", Pattern.quote("||"), "|").as("txt_pattern"), $"cui", $"priority", $"groupid")).as("entries")).as[GroupEntries]


      val tmpLabNameLkupArr = tmpUniLocres.crossJoin(mbLabMap)
        .withColumn("matchVal", MatchRegExPattern.matchRegExPattern($"localname", $"entries"))
        .where($"matchval".isNotNull)
        .withColumn("rownbr", row_number().over(Window.partitionBy($"localname").orderBy($"a.groupid".desc, $"priority".asc_nulls_last)))
        .where($"rownbr" === lit(1))
        .join(mvHtsDomainConcept.where($"domain_cui" === lit("CH001281")).as("dc"), $"cui" === $"concept_cui", "inner")
        .select(
          $"localname",
          $"cui",
          $"concept_name"
        ).collect()

      val tmpLabNameLkup = broadcast(tmpLabNameLkupArr
        .toSeq
        .map(r => temp_lab_name_lookup(Try(r(0).toString).getOrElse(null), Try(r(1).toString).getOrElse(null), Try(r(2).toString).getOrElse(null))).toDF()
        .toDF())

    val loincMap = mapLabLoinc
      .withColumn("rownbr", row_number().over(Window.partitionBy($"loinc", $"cui").orderBy($"groupid".desc)))
      .where($"rownbr" === lit(1))

    val mbQualTextResult = mapQualTextResult
      .withColumn("txt_pattern", concat(lit("(?i)"), $"txt_pattern"))
      .groupBy("lab_code")
      .agg(collect_list(struct(regexp_replace($"txt_pattern", Pattern.quote("||"), "|").as("txt_pattern"), $"qual_result_code".as("cui"),  $"qual_result_code".substr(lit(3),length($"qual_result_code")).as("priority"), lit("ALL").as("groupid"))).as("entries")).as[GroupEntries]

      val txtRes = tmpUniLocres.as("r")
        .join(loincMap.as("mll"), $"r.mappedcode".isNull && $"r.local_loinc_code"  === $"mll.loinc", "left_outer")
        .join(tmpLabNameLkup.as("tnl"), $"r.localname" === $"tnl.localname" && $"r.mappedcode".isNull, "left_outer")
        .join(broadcast(mbQualTextResult).as("mt"), coalesce($"r.mappedcode", $"mll.cui", $"tnl.cui") === $"mt.lab_code", "left_outer")
        .withColumn("rtn_txt_cui", when($"entries".isNotNull, MatchRegExPattern.matchRegExPattern(lower($"localresult"), $"entries")).otherwise(null))
        .withColumn("nrn", row_number().over(Window.partitionBy($"localresult", coalesce($"r.mappedcode", $"mll.cui", $"tnl.cui")).orderBy($"rtn_txt_cui")))
        .where($"nrn" === lit(1))
        .select(
          $"r.groupid",
          $"localresult",
          $"localresult_numeric",
          coalesce($"r.mappedcode", $"mll.cui", $"tnl.cui").as("mappedcode"),
          $"rtn_txt_cui"
        )

      val tempNumRes = txtRes.as("r2")
        .join(mapQualNumResult.as("mn"), $"r2.mappedcode" === $"mn.lab_code", "left_outer")
        .withColumn("rtn_cui",
          when($"r2.localresult_numeric".isNotNull && $"r2.rtn_txt_cui".isNull,
            when($"r2.localresult_numeric" >= $"mn.ref_rng_min" && $"r2.localresult_numeric" < $"mn.ref_rng_max", $"mn.qual_result_code").otherwise(null)).
            otherwise($"r2.rtn_txt_cui"))
        .withColumn("nrn", row_number().over(Window.partitionBy($"localresult", $"mappedcode").orderBy($"rtn_cui")))
        .where($"nrn" === lit(1))
        .withColumnRenamed("mappedcode", "cuimappedcode")
        .select(
          $"groupid",
          $"cuimappedcode",
          $"localresult",
          $"rtn_cui"
        )

        val tempLoincMap = mapLabLoinc.as("m")
        .join(mvHtsDomainConcept.where($"domain_cui" === lit("CH001281")).as("dc"), $"m.cui" === $"dc.concept_cui", "inner")
        .withColumn("rownbr", row_number().over(Window.partitionBy($"loinc", $"cui").orderBy($"groupid".desc)))
        .where($"rownbr" === lit(1))

    val  numRes = tempNumRes.collect()
      .toSeq
      .map(r => num_res(r(0).toString, Try(r(1).toString).getOrElse(null), Try(r(2).toString).getOrElse(null), Try(r(3).toString).getOrElse(null)))
      .toDF()

    val finalSelectCols = getSelectList(cols, nonAliasCols, "src")


    val tempLabRep = tempLab.repartition($"groupid", $"mappedcode", $"localresult")

    val df = tempLabRep.as("src")
      .join(broadcast(tempLoincMap).as("mll"), coalesce($"src.local_loinc_code", $"src.localcode") === $"mll.loinc", "left_outer")
      .join(tmpLabNameLkup.as("tnl"), lower($"src.localname") === $"tnl.localname", "left_outer")
      .join(broadcast(numRes).as("cui"), $"src.groupid" === $"cui.groupid" && coalesce($"src.mappedcode", $"mll.cui", $"tnl.cui") === $"cui.cuimappedcode" && $"src.localresult" === $"cui.localresult", "left_outer")
        .withColumn("resulttype", when($"cui.rtn_cui" === lit("CH999990"), lit("CH999990"))
          .when($"cui.rtn_cui" === lit("CH000654"), lit("CH999990"))
          .otherwise($"src.resulttype"))
        .withColumn("mapped_qual_code", $"cui.rtn_cui")
        .withColumn("mappedname", coalesce($"src.mappedname", $"mll.concept_name", $"tnl.concept_name"))
        .withColumn("mappedcode", coalesce($"src.mappedcode", $"mll.cui", $"tnl.cui"))
        .withColumn("localunits", regexp_replace($"src.localunits", "[{}]", ""))

    df.select(finalSelectCols.head, finalSelectCols.tail:_*).repartition(Math.ceil(partitions * partitionMultiplier).toInt)

  }

  def getSelectList(cols: Set[String], nonAliasCols: Set[String], alias: String) = {
    cols.map(s => if(nonAliasCols.contains(s)) s else alias + "." + s).toArray
  }

  def getUnitRefrange(sparkSession: SparkSession, al: String, include: Boolean) = {
    import sparkSession.implicits._

    val rangeCond = when($"nrml_rng".isNull && $"$al.localrange_lower" === lit("NULL"), lit("Y"))
      .when(coalesce(upper($"$al.localrange_lower"), lit("NULL")) === lit("ANY"), lit("Y"))
      .when($"$al.range_indicator" === lit("L") && $"nrml_rng".isNotNull && $"range_low".isNull && $"$al.localrange_compare" === lit("=") && $"nrml_rng" === $"$al.localrange_lower", lit("Y"))
      .when($"$al.range_indicator" === lit("L") && $"$al.localrange_compare" === lit(">") && $"$al.localrange_lower_double".isNotNull && ($"range_low" > $"$al.localrange_lower_double"), lit("Y"))
      .when($"$al.range_indicator" === lit("L") && $"$al.localrange_compare" === lit(">=") && $"$al.localrange_lower_double".isNotNull && ($"range_low" >= $"$al.localrange_lower_double"), lit("Y"))
      .when($"$al.range_indicator" === lit("L") && $"$al.localrange_compare" === lit("<=") && $"$al.localrange_lower_double".isNotNull && ($"range_low" <= $"$al.localrange_lower_double"), lit("Y"))
      .when($"$al.range_indicator" === lit("L") && $"$al.localrange_compare" === lit("<") && $"$al.localrange_lower_double".isNotNull && ($"range_low" < $"$al.localrange_lower_double"), lit("Y"))
      .when($"$al.range_indicator" === lit("L") && $"$al.localrange_compare" === lit("=") && $"$al.localrange_lower_double".isNotNull && ($"range_low" === $"$al.localrange_lower_double"), lit("Y"))
      .when($"$al.range_indicator" === lit("H") && $"nrml_rng".isNotNull && $"range_high".isNull && $"$al.localrange_compare" === lit("=") && $"nrml_rng" === $"$al.localrange_lower", lit("Y"))
      .when($"$al.range_indicator" === lit("H") && $"$al.localrange_compare" === lit(">") && $"$al.localrange_lower_double".isNotNull && ($"range_high" > $"$al.localrange_lower_double"), lit("Y"))
      .when($"$al.range_indicator" === lit("H") && $"$al.localrange_compare" === lit(">=") && $"$al.localrange_lower_double".isNotNull && ($"range_high" >= $"$al.localrange_lower_double"), lit("Y"))
      .when($"$al.range_indicator" === lit("H") && $"$al.localrange_compare" === lit("<=") && $"$al.localrange_lower_double".isNotNull && ($"range_high" <= $"$al.localrange_lower_double"), lit("Y"))
      .when($"$al.range_indicator" === lit("H") && $"$al.localrange_compare" === lit("<") && $"$al.localrange_lower_double".isNotNull && ($"range_high" < $"$al.localrange_lower_double"), lit("Y"))
      .when($"$al.range_indicator" === lit("H") && $"$al.localrange_compare" === lit("=") && $"$al.localrange_lower_double".isNotNull && ($"range_high" === $"$al.localrange_lower_double"), lit("Y"))
      .otherwise(lit("N"))  === lit("Y")

    val cond = if(include) $"$al.client_ds_id" === $"a.client_ds_id"  else coalesce($"$al.client_ds_id", lit("NULL")) === "NULL"
    val mbUnitRefrangeJoinCond = $"a.groupid" === $"$al.groupid" && cond && $"a.localcode" === $"$al.local_code" &&
      coalesce(lower($"a.localunits"), lit("NULL")) === when($"$al.local_units" === lit("ANY"), coalesce(lower($"a.localunits"), lit("NULL")))
        .when($"$al.local_units" === lit("NULL"), lit("NULL"))
        .otherwise($"$al.local_units") &&
      coalesce(lower($"a.localtestname"), lit("NULL")) === when($"$al.ordername" === lit("ANY"), coalesce(lower($"a.localtestname"), lit("NULL")))
        .when($"$al.ordername" === lit("NULL"), lit("NULL"))
        .otherwise($"$al.ordername") && rangeCond

    mbUnitRefrangeJoinCond
  }

  def getUnitMap(sparkSession: SparkSession, df: DataFrame, unitRemap: Dataset[unit_remap]) = {
    import sparkSession.implicits._

    df.join(unitRemap.as("lgu"), $"a.groupid" === $"lgu.groupid" && coalesce($"lgu.client_ds_id", lit("NULL")) === "NULL" && coalesce($"crm.hts_lab_cui", $"rm.hts_lab_cui", $"d.cui") === $"lgu.lab" && $"lgu.local_unit" === lit("NULL") &&
      coalesce($"mu.cui", when(coalesce($"a.localunits", $"a.localunits_inferred").isNotNull, lit("CH999990")).otherwise(lit("CH999999")))=== $"lgu.remap"
      && $"a.localcode" === coalesce($"lgu.local_lab_code", $"a.localcode") && coalesce($"lgu.local_lab_code", lit("NULL")) =!= lit("NULL"), "left_outer")
      .join(unitRemap.as("ur"), $"a.groupid" === $"ur.groupid" && coalesce($"ur.client_ds_id", lit("NULL")) === "NULL" && coalesce($"crm.hts_lab_cui", $"rm.hts_lab_cui", $"d.cui") === $"ur.lab" && $"ur.local_unit" === lit("NULL") &&
        coalesce($"mu.cui", when(coalesce($"a.localunits", $"a.localunits_inferred").isNotNull, lit("CH999990")).otherwise(lit("CH999999")))=== $"ur.remap"
        && coalesce($"ur.local_lab_code", lit("NULL"))=== lit("NULL"), "left_outer")
      .join(unitRemap.as("lgulu"), $"a.groupid" === $"lgulu.groupid" && coalesce($"lgulu.client_ds_id", lit("NULL")) === "NULL" && coalesce($"crm.hts_lab_cui", $"rm.hts_lab_cui", $"d.cui") === $"lgulu.lab" && $"lgulu.local_unit" =!= lit("NULL") && lower(coalesce($"a.localunits", $"a.localunits_inferred")) === $"lgulu.local_unit" && $"a.localcode" === coalesce($"lgulu.local_lab_code", $"a.localcode") &&
        coalesce($"a.localcode", lit("a")) === coalesce($"lgulu.local_lab_code", lit("a")), "left_outer")
  }

  def getUnitMapClient(sparkSession: SparkSession, df: DataFrame, unitRemap: Dataset[unit_remap]) = {
    import sparkSession.implicits._

    df.join(unitRemap.as("clgu"), $"a.groupid" === $"clgu.groupid" && $"a.client_ds_id" === $"clgu.client_ds_id" && coalesce($"crm.hts_lab_cui", $"rm.hts_lab_cui", $"d.cui") === $"clgu.lab" && $"clgu.local_unit" === lit("NULL") &&
      coalesce($"mu.cui", when(coalesce($"a.localunits", $"a.localunits_inferred").isNotNull, lit("CH999990")).otherwise(lit("CH999999")))=== $"clgu.remap"
      && $"a.localcode" === coalesce($"clgu.local_lab_code", $"a.localcode") && coalesce($"clgu.local_lab_code", lit("NULL")) =!= lit("NULL"), "left_outer")
      .join(unitRemap.as("cur"), $"a.groupid" === $"cur.groupid" && $"a.client_ds_id" === $"cur.client_ds_id" && coalesce($"crm.hts_lab_cui", $"rm.hts_lab_cui", $"d.cui") === $"cur.lab" && $"cur.local_unit" === lit("NULL") &&
        coalesce($"mu.cui", when(coalesce($"a.localunits", $"a.localunits_inferred").isNotNull, lit("CH999990")).otherwise(lit("CH999999")))=== $"cur.remap"
        && coalesce($"cur.local_lab_code", lit("NULL"))=== lit("NULL"), "left_outer")
      .join(unitRemap.as("clgulu"), $"a.groupid" === $"clgulu.groupid" && $"a.client_ds_id" === $"clgulu.client_ds_id" && coalesce($"crm.hts_lab_cui", $"rm.hts_lab_cui", $"d.cui") === $"clgulu.lab"  && $"clgulu.local_unit" =!= lit("NULL") && lower(coalesce($"a.localunits", $"a.localunits_inferred")) === $"clgulu.local_unit" && $"a.localcode" === coalesce($"clgulu.local_lab_code", $"a.localcode") &&
        coalesce($"a.localcode", lit("a")) === coalesce($"clgulu.local_lab_code", lit("a")), "left_outer")
  }

}


case class  num_res(groupid: String  = null, cuimappedcode:  String = null, localresult: String =  null, rtn_cui: String = null)

case class temp_lab_name_lookup(localname: String = null,  cui: String = null, concept_name: String = null)