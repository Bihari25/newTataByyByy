package com.optum.oap.backend.etl.enrichment

import com.optum.oap.backend.etl.common.{MapMasterIds, NormalizedQuantity}
import com.optum.oap.cdr.models.{patient_mpi, treatment_administered, zcm_treatment_type_code, zh_provider_master_xref}
import com.optum.oap.sparkdataloader.{RuntimeVariables, TableInfo, UserDefinedFunctionForDataLoader}
import org.apache.spark.sql.{DataFrame, SparkSession}
import org.apache.spark.sql.functions.broadcast


object TREATMENT_ADMINISTERED extends TableInfo[treatment_administered] {
  override def dependsOn = Set("PATIENT_MPI", "ZH_PROVIDER_MASTER_XREF", "CDR_FE_TREATMENT_ADMINISTERED", "ZCM_TREATMENT_TYPE_CODE")

  override def name = "TREATMENT_ADMINISTERED"

  override def saveDataFrameToParquet: Boolean = true

  override def partitions: Int = 32

  override def skipTable: Boolean = false

  override def ignoreExtraColumnsInDataFrame: Boolean = true

  override def createDataFrame(sparkSession: SparkSession,
                               loadedDependencies: Map[String, DataFrame],
                               udfMap: Map[String, UserDefinedFunctionForDataLoader],
                               runtimeVariables: RuntimeVariables): DataFrame = {
    import sparkSession.implicits._

    val treatment_administeredIn = loadedDependencies("CDR_FE_TREATMENT_ADMINISTERED").as[treatment_administered]
    val provXref = broadcast(loadedDependencies("ZH_PROVIDER_MASTER_XREF")).as[zh_provider_master_xref]
    val patXref = loadedDependencies("PATIENT_MPI").as[patient_mpi]
    val treatmentTypeCodes = loadedDependencies("ZCM_TREATMENT_TYPE_CODE").as[zcm_treatment_type_code].drop("groupid")

    val masteredDf = MapMasterIds.mapProviderIds(MapMasterIds.mapPatientIds(treatment_administeredIn.toDF, patXref.toDF, filterIds=false), provXref.toDF(), "administered_prov_id", "master_hgprovid")

    masteredDf.as("a")
      .join(broadcast(treatmentTypeCodes).as("z"),
        $"a.localcode" === $"z.local_code" and $"a.cui" === $"z.treatment_type_cui"
      ).map(row => {
      val administered_quantity = row.getAs[String]("administered_quantity")

      treatment_administered(
        client_ds_id = row.getAs[Integer]("client_ds_id"),
        cui = row.getAs[String]("cui"),
        datasrc = row.getAs[String]("datasrc"),
        encounterid = row.getAs[String]("encounterid"),
        groupid = row.getAs[String]("groupid"),
        grp_mpi = row.getAs[String]("grp_mpi"),
        hgpid = row.getAs[java.lang.Long]("hgpid"),
        local_unit = row.getAs[String]("local_unit"),
        localcode = row.getAs[String]("localcode"),
        master_hgprovid = row.getAs[String]("master_hgprovid"),
        normalized_quantity = NormalizedQuantity.derive(
          p_DATA_TYPE = row.getAs[String]("data_type"),
          p_BEGIN_RANGE = Option(row.getAs[Int]("begin_range")),
          p_END_RANGE = Option(row.getAs[Int]("end_range")),
          p_ROUND_PREC = Option(row.getAs[Int]("round_prec")),
          p_TREATMENT_TYPE_STD_UNITS = Option(row.getAs[String]("treatment_type_std_units")),
          p_localresult = Option(administered_quantity),
          p_LOCALUNIT_CUI = Option(row.getAs[String]("localunit_cui")),
          p_conv_factor = Option(row.getAs[java.lang.Double]("conv_fact")),
          p_FUNCTION_APPLIED = Option(row.getAs[String]("function_applied"))
        ),
        administered_date = row.getAs[java.sql.Timestamp]("administered_date"),
        order_id = row.getAs[String]("order_id"),
        administered_id = row.getAs[String]("administered_id"),
        administered_prov_id = row.getAs[String]("administered_prov_id"),
        administered_quantity = administered_quantity,
        patientid = row.getAs[String]("patientid"),
        std_unit_cui = row.getAs[String]("std_unit_cui")
      )
    })
  }.toDF
}
