package com.optum.oap.backend.etl.enrichment

import com.optum.oap.backend.etl.common.MapMasterIds
import com.optum.oap.cdr.models.{patient_care_pathway, patient_mpi}
import com.optum.oap.sparkdataloader.{RuntimeVariables, TableInfo, UserDefinedFunctionForDataLoader}
import org.apache.spark.sql.{DataFrame, SparkSession}
import org.slf4j.LoggerFactory

object PATIENT_CARE_PATHWAY extends TableInfo[patient_care_pathway] {

  val log = LoggerFactory.getLogger(this.getClass)

  override def dependsOn = Set("CDR_FE_PATIENT_CARE_PATHWAY", "PATIENT_MPI")

  override def name = "PATIENT_CARE_PATHWAY"

  override def saveDataFrameToParquet: Boolean = true

  override def partitions: Int = 32

  override def skipTable: Boolean = false

  override def ignoreExtraColumnsInDataFrame: Boolean = true

  override def createDataFrame(sparkSession: SparkSession,
                               loadedDependencies: Map[String, DataFrame],
                               udfMap: Map[String, UserDefinedFunctionForDataLoader],
                               runtimeVariables: RuntimeVariables): DataFrame = {
    import sparkSession.implicits._

    val patient_care_pathwayIn = loadedDependencies("CDR_FE_PATIENT_CARE_PATHWAY").as[patient_care_pathway]
    val patXref = loadedDependencies("PATIENT_MPI").as[patient_mpi]

    MapMasterIds.mapPatientIds(patient_care_pathwayIn.toDF, patXref.toDF, false)
  }


}
