package com.optum.oap.backend.etl.patient_matching.data_table

import com.optum.oap.backend.cdrTempModel.{mpi_patient_merge, patient_xref}
import com.optum.oap.backend.etl.common.{CDRConstants, EnrichmentUtils, PartitionedDataOperations}
import com.optum.oap.backend.loader.EnrichmentRunTimeVariables
import com.optum.oap.cdr.models.mpi_merge
import com.optum.oap.sparkdataloader.{RuntimeVariables, TableInfo, UserDefinedFunctionForDataLoader}
import org.apache.spark.sql.expressions.Window
import org.apache.spark.sql.functions.{collect_set, lit, size, trim}
import org.apache.spark.sql.types.LongType
import org.apache.spark.sql.{DataFrame, SparkSession}

object MPI_MERGE extends TableInfo[mpi_merge] with PartitionedDataOperations {

  val partitionKey: String = "merge_id"

  override def dependsOn = Set("MPI_PATIENT_MERGE", "V_PATIENT_XREF", "ECDR_MPI_MERGE")

  override def name = "MPI_MERGE"

  override def saveDataFrameToParquet: Boolean = true

  override def createDataFrame(sparkSession: SparkSession,
                               loadedDependencies: Map[String, DataFrame],
                               udfMap: Map[String, UserDefinedFunctionForDataLoader],
                               runtimeVariables: RuntimeVariables): DataFrame = {
    import sparkSession.implicits._
    val dailyBuild = if (runtimeVariables.asInstanceOf[EnrichmentRunTimeVariables].buildType == CDRConstants.DELTA_BUILD_TYPE) true else false

    implicit val session = sparkSession
    val schema = EnrichmentRunTimeVariables(runtimeVariables).cdrSchema
    val mpiPatientMerge = loadedDependencies("MPI_PATIENT_MERGE").as[mpi_patient_merge]
    val pXref = loadedDependencies("V_PATIENT_XREF").as[patient_xref]
    val patientXref = if(pXref.isEmpty) loadData(schema, "V_PATIENT_XREF").as[patient_xref] else pXref

    val dataDf = mpiPatientMerge.as("a")
      .join(patientXref.as("b"), Seq("client_ds_id", "patientid"))
      .groupBy($"a.groupid", $"a.client_ds_id", $"b.hgpid", $"a.patientid", trim($"a.merge_id").as("merge_id"))
      .agg(
        lit(1).as("group_cnt"),
        size(collect_set("b.hgpid").over(Window.partitionBy(trim($"merge_id")))).cast(LongType).as("hgpids")
      )

    val ecdrDf = {
      if (dailyBuild) EnrichmentUtils.removeRowSourceAndModifiedDate(loadedDependencies("ECDR_MPI_MERGE")).as[mpi_merge]
      else sparkSession.emptyDataset[mpi_merge].as[mpi_merge]
    }.as("e")
      .select($"e.*")

    dataDf.unionByName(ecdrDf).distinct()
  }
}
