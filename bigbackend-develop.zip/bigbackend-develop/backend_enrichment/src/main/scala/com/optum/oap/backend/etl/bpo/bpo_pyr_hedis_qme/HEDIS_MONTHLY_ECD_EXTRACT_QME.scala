package com.optum.oap.backend.etl.bpo.bpo_pyr_hedis_qme

import com.optum.oap.backend.cdrTempModel.{hedis_monthly_ecd_extract_qme}
import com.optum.oap.cdr.models.{pp_bpo_clinical_documentation, pp_bpo_member_detail, pp_bpo_pharmacy_clinical}
import com.optum.oap.sparkdataloader.{RuntimeVariables, TableInfo, UserDefinedFunctionForDataLoader}
import org.apache.spark.sql.functions._
import org.apache.spark.sql.types.StringType
import org.apache.spark.sql.{DataFrame, SparkSession}

object HEDIS_MONTHLY_ECD_EXTRACT_QME extends TableInfo[hedis_monthly_ecd_extract_qme] {

  override def dependsOn: Set[String] = Set("PP_BPO_MEMBER_DETAIL","PP_BPO_PHARMACY_CLINICAL","PP_BPO_CLINICAL_DOCUMENTATION")

  override def name = "HEDIS_MONTHLY_ECD_EXTRACT_QME"

  override def createDataFrame(sparkSession: SparkSession,
                               loadedDependencies: Map[String, DataFrame],
                               udfMap: Map[String, UserDefinedFunctionForDataLoader],
                               runtimeVariables: RuntimeVariables): DataFrame = {

      import sparkSession.implicits._

      val hedis_patients = loadedDependencies("PP_BPO_MEMBER_DETAIL").as[pp_bpo_member_detail]
      val pp_bpo_pharmacy_clinical = loadedDependencies("PP_BPO_PHARMACY_CLINICAL").as[pp_bpo_pharmacy_clinical]
      val pp_bpo_pharmacy_clinical_documentation = loadedDependencies("PP_BPO_CLINICAL_DOCUMENTATION").as[pp_bpo_clinical_documentation]

      val hedis_patients_final = hedis_patients.where($"lineofbusinessid".isNotNull && $"healthplansource" === lit("PAYER")).select($"memberid").distinct

      val final_pp_bpo_pharmacy_clinical = pp_bpo_pharmacy_clinical.alias("bpc").where($"bpc.healthplansource" === lit("PAYER")).join(hedis_patients_final.as("hpf"), $"hpf.memberid" === $"bpc.memberid", "inner").select(
          $"bpc.memberid".as("MemberID"),
          $"PHARMACY_CLINICAL_ID".as("RecordID"),
          lit("R").as("RecordType"),
          $"CODE_TAXONOMY".as("CodeTaxonomy"),
          $"CODE".as("Code"),
          date_format($"ADMINISTRATION_DATE", "yyyy-MM-dd").cast(StringType).as("CodeStartDate"),
          lit(null).cast(StringType).as("CodeEndDate"),
          lit(null).cast(StringType).as("OrderedDate"),
          lit(null).cast(StringType).as("Quantity"),
          lit(null).cast(StringType).as("Attribute"),
          lit(null).cast(StringType).as("Result"),
          lit(null).cast(StringType).as("ResultValueFlag"),
          lit(null).cast(StringType).as("TypeFlag"),
          lit(null).cast(StringType).as("PHQ9Version"),
          $"HEALTHPLANSOURCE".as("HealthPlanSource"),
          lit(null).cast(StringType).as("Status"),
          lit(null).cast(StringType).as("ProviderID"),
          lit(null).cast(StringType).as("SpecialtyCode"),
          lit("SS").as("MapSource")
      )


      val final_pp_bpo_pharmacy_clinical_documentation = pp_bpo_pharmacy_clinical_documentation.alias("bpcd").where($"bpcd.healthplansource" === lit("PAYER")).join(hedis_patients_final.as("hpf"), $"hpf.memberid" === $"bpcd.memberid", "inner").select(
          $"bpcd.memberid".as("MemberID"),
          $"clinical_document_id".as("RecordID"),
          lit("C").as("RecordType"),
          $"CODE_TAXONOMY".as("CodeTaxonomy"),
          $"CODE".as("Code"),
          date_format($"DOCUMENTATION_DATE", "yyyy-MM-dd").cast(StringType).as("CodeStartDate"),
          lit(null).cast(StringType).as("CodeEndDate"),
          lit(null).cast(StringType).as("OrderedDate"),
          lit(null).cast(StringType).as("Quantity"),
          lit(null).cast(StringType).as("Attribute"),
          $"RESULT".cast(StringType).as("Result"),
          lit(null).cast(StringType).as("ResultValueFlag"),
          lit(null).cast(StringType).as("TypeFlag"),
          $"PHQ9_VERSION".as("PHQ9Version"),
          $"HEALTHPLANSOURCE".as("HealthPlanSource"),
          lit(null).cast(StringType).as("Status"),
          lit(null).cast(StringType).as("ProviderID"),
          lit(null).cast(StringType).as("SpecialtyCode"),
          lit("SS").as("MapSource")
      )
      final_pp_bpo_pharmacy_clinical.union(final_pp_bpo_pharmacy_clinical_documentation)
  }

}
