package com.optum.oap.backend.etl.common

import com.optum.oap.sparkdataloader.UserDefinedFunctionForDataLoader
import org.apache.spark.sql.expressions.UserDefinedFunction
import org.apache.spark.sql.functions.udf
import org.apache.spark.sql.{Row, SparkSession}

object MatchRegExPattern extends UserDefinedFunctionForDataLoader {

  val matchRegExPattern: UserDefinedFunction = udf { (input: String, data: Seq[Row]) => {
    val allMatches = data.view map { r: Row => matchPattern(input, MapEntry(r(0).toString, r(1).toString, r(2).toString, r(3).toString)) } collect { case Some(x) => x }
    if (allMatches.nonEmpty) {
      val allSortedMatches = allMatches.sorted[MapEntry](new Ordering[MapEntry] {
        def compare(x: MapEntry, y: MapEntry): Int = {
          if (isGroupSpecificPattern(x.groupId) && isGroupSpecificPattern(y.groupId)) x.priority.toDouble compareTo y.priority.toDouble
          else if (!isGroupSpecificPattern(x.groupId) && !isGroupSpecificPattern(y.groupId)) x.priority.toDouble compareTo y.priority.toDouble
          else if (!isGroupSpecificPattern(x.groupId) && isGroupSpecificPattern(y.groupId)) 1
          else -1
        }
      })
      allSortedMatches.head.cui
    } else null
  }
  }

  def isGroupSpecificPattern(x: String): Boolean = {
    if (x == null) false
    else if (x.toUpperCase.startsWith("H") && x.length == 7) true
    else false
  }

  def replace_posix_classes(x: String): String = {
    val replace = Map("[:upper:]" -> "\\p{Upper}", "[:lower:]" -> "\\p{Lower}", "[:blank:]" -> "\\p{Blank}",
      "[:alpha:]" -> "\\p{Alpha}", "[:digit:]" -> "\\p{Digit}", "[:alnum:]" -> "\\p{Alnum}", "[:punct:]" -> "\\p{Punct}",
      "[:blank:]" -> "\\p{Blank}", "[:space:]" -> "\\p{Space}", "[:print:]" -> "\\p{Print}")

    var replaced_string = x
    for ((k, v) <- replace) {
      replaced_string = replaced_string.replace(k, v)
    }
    replaced_string
  }

  def matchPattern(input: String, mapEntry: MapEntry): Option[MapEntry] = {
    val p = replace_posix_classes(mapEntry.txt_pattern).r
    val wasMatched = if (input == null) {
      Option(null)
    } else if (p.findFirstIn(input).isDefined) {
      p.findFirstIn(input)
    } else {
      if (p.toString == mapEntry.txt_pattern) {
        mapEntry.txt_pattern.toLowerCase.r.findFirstIn(input.toLowerCase)
      }
      else{
        Option(null)
      }
    }
    wasMatched.map(x => {
      mapEntry
    })
  }

  override def registerMe(sparkSession: SparkSession): Unit = {
    sparkSession.udf.register(name, matchRegExPattern)
  }

  override def name: String = "MatchRegExPattern"

}

case class MapEntry(txt_pattern: String, cui: String, priority: String, groupId: String)
