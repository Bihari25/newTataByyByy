package com.optum.oap.backend.etl.summary

import com.optum.oap.cdr.models.prov_fac_rel_summary
import com.optum.oap.sparkdataloader.{RuntimeVariables, TableInfo, UserDefinedFunctionForDataLoader}
import org.apache.spark.sql.expressions.Window
import org.apache.spark.sql.functions._
import org.apache.spark.sql.types.TimestampType
import org.apache.spark.sql.{DataFrame, SparkSession}
import org.slf4j.LoggerFactory


object  PROV_FAC_REL_SUMMARY extends TableInfo[prov_fac_rel_summary] {
  val log = LoggerFactory.getLogger(this.getClass)
  override def dependsOn =  Set("PROV_FAC_REL","MAP_FAC_ORDER","ZH_PROVIDER_MASTER")

  override def name = "PROV_FAC_REL_SUMMARY"

  override def saveDataFrameToParquet: Boolean = true
  override def partitions: Int = 32
  override def skipTable: Boolean = false
  override def ignoreExtraColumnsInDataFrame: Boolean = false

  override def createDataFrame (sparkSession: SparkSession,
                                loadedDependencies: Map[String, DataFrame],
                                udfMap: Map[String, UserDefinedFunctionForDataLoader],
                                runtimeVariables: RuntimeVariables): DataFrame = {

    //reading  etl
    val prov_fac_relDF = loadedDependencies("PROV_FAC_REL")

    val map_fac_order_DF = broadcast(loadedDependencies("MAP_FAC_ORDER"))

    val zh_provider_master_DF = loadedDependencies("ZH_PROVIDER_MASTER")

    //Testing - read etl from hdfs
    /*  var path = "" //put path here
      path = "hdfs://somhorton1/optum-dev/cdrscale/scratch_workspace/nratnani/prov_fac_relDF"
      val prov_fac_relDF = spark.read.parquet(path).cache()

      path = "hdfs://somhorton1/optum-dev/cdrscale/scratch_workspace/nratnani/map_fac_order_DF"
      val map_fac_order_DF = spark.read.parquet(path).cache()

      path = "hdfs://somhorton1/optum-dev/cdrscale/scratch_workspace/nratnani/zh_provider_master_DF"
      val zh_provider_master_DF = spark.read.parquet(path).cache()

      path = "hdfs://somhorton1/optum-dev/cdrscale/scratch_workspace/nratnani/schema_init"
      val schema_init_DF = spark.read.parquet(path).cache()

  */
    //After reading etl script starts from here
    val prov_fac_relDF1 = prov_fac_relDF.filter("facilityid is not null and localrelshipcode='PRIMARY'")

    val map_fac_order_DF1 = map_fac_order_DF.filter("coalesce(fac_exclude_flg, 'N') <> 'Y' ")
      .withColumn("fac_order", coalesce(map_fac_order_DF("fac_order"), lit(99)))

    val zh_provider_master_DF1 = zh_provider_master_DF.withColumnRenamed("master_hgprovid", "mstrprovid")
      .withColumn("providerexclusionflag", coalesce(zh_provider_master_DF("providerexclusionflag"), lit("N")))

    val joinedDF1 =
      prov_fac_relDF1
        .withColumn("startdate", to_date(prov_fac_relDF1("startdate")))
        .withColumn("enddate", to_date(coalesce(prov_fac_relDF1("enddate"), concat(year(current_date()), lit("-12-31")))))
        .join(broadcast(map_fac_order_DF1), Seq("groupid", "client_ds_id", "datasrc"), "left_outer")

    val group1 = joinedDF1.groupBy("groupid", "facilityid", "fac_order")

    val group1agg = group1.agg(
      min(to_date(joinedDF1("startdate"))).as("min_startdate"),
      max(to_date(coalesce(joinedDF1("enddate"), concat(year(current_date()), lit("-12-31"))))).as("max_enddate")
    )
      .withColumnRenamed("groupid", "groupid_agg")
      .withColumnRenamed("facilityid", "facilityid_agg")
      .withColumnRenamed("fac_order", "fac_order_agg")


    val joinedDF2 =
      joinedDF1
        .join(zh_provider_master_DF1, Seq("groupid", "mstrprovid"), "left_outer")

    val b_df = joinedDF2.select("groupid", "datasrc", "providerid", "localrelshipcode"
      , "startdate", "enddate", "client_ds_id", "facilityid", "mstrprovid"
      , "fac_order", "providerexclusionflag")
      .distinct

    val JoinDF3 = b_df
      .join(group1agg,
        b_df("groupid") === group1agg("groupid_agg") and
          b_df("facilityid") === group1agg("facilityid_agg") and
          b_df("fac_order").gt(group1agg("fac_order_agg"))
        , "left_outer")
      .drop("groupid_agg", "facilityid_agg", "fac_order_agg")


    val c_df1 = JoinDF3.select("groupid", "datasrc", "providerid", "localrelshipcode"
      , "startdate", "enddate", "client_ds_id", "facilityid", "mstrprovid"
      , "fac_order", "providerexclusionflag", "min_startdate", "max_enddate")

    val c_df2 = c_df1.groupBy("groupid", "datasrc", "providerid", "localrelshipcode", "startdate"
      , "enddate", "client_ds_id", "facilityid", "mstrprovid"
      , "fac_order", "providerexclusionflag")
      .agg(
        min("min_startdate").as("min_startdate"),
        max("max_enddate").as("max_enddate")
      )

    val c_df3 = c_df2.orderBy(
      c_df2("facilityid"), c_df2("startdate"), c_df2("enddate"),
      c_df2("providerexclusionflag").desc,
      c_df2("mstrprovid"), c_df2("client_ds_id").desc,
      c_df2("providerid").desc
    )

    val c_df4 = c_df3.filter(
      "min_startdate is null or " +
        " startdate < min_startdate " +
        " or startdate > max_enddate "

    )

    val window1 = Window.partitionBy(c_df4("groupid"), c_df4("mstrprovid")) ///we want all these sequences to be within mstrprovid
      .orderBy(c_df4("groupid"), c_df4("startdate"),
      c_df4("enddate"), c_df4("providerexclusionflag").desc, c_df4("facilityid").asc_nulls_first,
      c_df4("client_ds_id").desc, c_df4("providerid").desc)

    val lead1 = c_df4.withColumn("leadstartdate", lead("startdate", 1).over(window1))

    val lead2 = lead1.withColumn("leadstartdate",
      least(coalesce(
        date_sub(lead1("leadstartdate"), 1), lead1("enddate")
      ), lead1("enddate"))
    )

    val lead3 = lead2.withColumn("enddate", when(lead2("leadstartdate")
      === to_date(concat(year(current_date()), lit("-12-31"))), null)
      .otherwise(lead2("leadstartdate")))

    var c_df5 = lead3.filter(" enddate >= startdate or enddate is null ")
        .withColumn("startdate", lead3("startdate").cast(TimestampType))
        .withColumn("enddate", lead3("enddate").cast(TimestampType))

    c_df5.select("groupid", "datasrc", "facilityid", "localrelshipcode","startdate", "enddate", "mstrprovid","client_ds_id")

  }
}