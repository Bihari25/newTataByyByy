package com.optum.oap.backend.etl.metrics

import com.optum.oap.backend.cdrTempModel.etl_run_time
import com.optum.oap.backend.loader.EnrichmentRunTimeVariables
import org.apache.spark.sql.functions._
import com.optum.oap.sparkdataloader.{RuntimeVariables, TableInfo, UserDefinedFunctionForDataLoader}
import org.apache.spark.sql.types.LongType
import org.apache.spark.sql.{DataFrame, SaveMode, SparkSession}

object ETL_RUN_TIME extends TableInfo[etl_run_time]{

  override def dependsOn = Set.empty[String]

  override def name = "ETL_RUN_TIME"

  override def saveMode: SaveMode = SaveMode.Append

  override def createDataFrame(sparkSession: SparkSession, loadedDependencies: Map[String, DataFrame], udfMap: Map[String, UserDefinedFunctionForDataLoader], runtimeVariables: RuntimeVariables): DataFrame = {
    import sparkSession.implicits._

    val buildMetrics = runtimeVariables.asInstanceOf[EnrichmentRunTimeVariables].buildMetrics

    buildMetrics match {
      case Some(metrics) => {

        val log: Seq[String] = metrics.split("\\n")
        val buildType: String = runtimeVariables.asInstanceOf[EnrichmentRunTimeVariables].buildType
        val cdrCycle: String = runtimeVariables.asInstanceOf[EnrichmentRunTimeVariables].cdrCycle
        val enrichmentStep : String = runtimeVariables.asInstanceOf[EnrichmentRunTimeVariables].loadGroups

        val tablePattern = "^Table ([a-zA-Z_]*) .*".r

        val timePattern = "(([01]\\d|2[0123]):[012345]\\d:[012345]\\d)".r

        val result = log.filter(line => tablePattern.findAllIn(line).nonEmpty).map(line => {
          val tableName = tablePattern.findFirstMatchIn(line).get.group(1)

          val times = timePattern.findAllIn(line)
          val startTime = times.next()
          val endTime = times.next()
          temp_etl_run_time(build_type = buildType, cdr_cycle = cdrCycle, enrichment_step = enrichmentStep, start_time = startTime, end_time = endTime, table_name = tableName)
        })


        result.toDF()
          .withColumn("start_time", to_timestamp($"start_time"))
          .withColumn("end_time", to_timestamp($"end_time"))
          .select(
            $"build_type",
            $"cdr_cycle",
            $"enrichment_step",
            ($"end_time".cast(LongType) - $"start_time".cast(LongType)).as("time_taken"),
            $"table_name"
          )
      }
      case _ => Seq.empty[etl_run_time].toDF
    }
  }
}
case class temp_etl_run_time(build_type: String = null, cdr_cycle: String = null, enrichment_step: String = null, start_time: String = null, end_time: String = null, table_name: String = null)