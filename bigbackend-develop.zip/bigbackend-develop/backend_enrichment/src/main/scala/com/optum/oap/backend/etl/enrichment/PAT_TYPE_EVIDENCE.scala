package com.optum.oap.backend.etl.enrichment

import com.optum.oap.cdr.models.{claim, diagnosis, encountercarearea, pat_type_evidence}
import com.optum.oap.sparkdataloader.{QueryAndMetadata, RuntimeVariables, TableInfo, UserDefinedFunctionForDataLoader}
import org.apache.spark.sql.functions._
import org.apache.spark.sql.{DataFrame, SparkSession}

object PAT_TYPE_EVIDENCE extends TableInfo[pat_type_evidence] {

  override def dependsOn: Set[String] = Set("ENCOUNTERCAREAREA", "MAP_PREDICATE_VALUES", "MAP_CARE_AREA", "MAP_PAT_TYPE_EVIDENCE", "MAP_SERVICE", "CLAIM", "DIAGNOSIS", "CDR_FE_CLINICALENCOUNTER", "ZH_FACILITY_ROLLUP", "INSURANCE", "MAP_INS_PAT_TYPE")

  override def name: String = "PAT_TYPE_EVIDENCE"

  override def createDataFrame(sparkSession: SparkSession,
                               loadedDependencies: Map[String, DataFrame],
                               udfMap: Map[String, UserDefinedFunctionForDataLoader],
                               runtimeVariables: RuntimeVariables): DataFrame = {
    import sparkSession.implicits._

    val clm = loadedDependencies("CLAIM").as[claim]
    val mapPatTypeEvidence = broadcast(loadedDependencies("MAP_PAT_TYPE_EVIDENCE"))
    val encounterCareArea = loadedDependencies("ENCOUNTERCAREAREA").as[encountercarearea]
    val mapCareArea = broadcast(loadedDependencies("MAP_CARE_AREA"))
    val mapService = broadcast(loadedDependencies("MAP_SERVICE"))
    val diagnosis = loadedDependencies("DIAGNOSIS").as[diagnosis]
    val clinicalEncounter = loadedDependencies("CDR_FE_CLINICALENCOUNTER")
    val zhFacilityRollup = broadcast(loadedDependencies("ZH_FACILITY_ROLLUP"))
    val insurance = loadedDependencies("INSURANCE")
    val mapInsPatType = broadcast(loadedDependencies("MAP_INS_PAT_TYPE"))

    val mpv = broadcast(loadedDependencies("MAP_PREDICATE_VALUES")
      .select($"client_ds_id")
      .where($"data_src" === "CDR_INFERPT" && $"entity" === "CLINICALENCOUNTER" && $"table_name" === "CLINICALENCOUNTER" && $"column_name" === "CLIENT_DS_ID" && upper($"column_value") === "YES")
      .as("mpv"))

    // care area evidence
    val careAreaEvidence = encounterCareArea.where($"encounterid".isNotNull).as("eca")
      .join(mpv.as("mpv"), $"mpv.client_ds_id" === $"eca.client_ds_id")
      .join(mapCareArea.as("mca"), $"eca.groupid" === $"mca.groupid" && $"eca.localcareareacode" === $"mca.local_code", "left_outer")
      .join(mapPatTypeEvidence
        .where($"pat_type_cui".isNotNull)
        .as("meca"), $"mca.cui" === $"meca.mappedcode" && $"meca.evidence_type" === "CARE", "left_outer")
      .join(mapService.as("ms"), $"eca.groupid" === $"ms.groupid" && $"eca.servicecode" === $"ms.mnemonic", "left_outer")
      .join(mapPatTypeEvidence
        .where($"pat_type_cui".isNotNull)
        .as("mcas"), $"ms.cui" === $"mcas.mappedcode" && $"mcas.evidence_type" === "SERVICE", "left_outer")
      .select(
        $"eca.groupid",
        $"eca.client_ds_id",
        $"eca.encounterid",
        when($"meca.pat_type_cui".isNotNull, "CARE")
          .otherwise(null).as("ca_ev_type"),
        $"meca.pat_type_cui".as("ca_pt_cui"),
        when($"mcas.pat_type_cui".isNotNull, "SERVICE")
          .otherwise(null).as("svc_ev_type"),
        $"mcas.pat_type_cui".as("svc_pt_cui")
      ).distinct()


    // claim evidence
    val claimEvidence = clm.where($"encounterid".isNotNull).as("clm")
      .join(mpv, $"mpv.client_ds_id" === $"clm.client_ds_id")
      .join(mapPatTypeEvidence
        .as("meprocmod"),
        ($"clm.mappedcptmod1" === $"meprocmod.mappedcode" || $"clm.mappedcptmod2" === $"meprocmod.mappedcode" || $"clm.mappedcptmod3" === $"meprocmod.mappedcode" || $"clm.mappedcptmod4" === $"meprocmod.mappedcode") && $"meprocmod.evidence_type" === lit("PROCMOD"), "left_outer")
      .join(mapPatTypeEvidence
        .as("mecpt"), $"clm.mappedcpt" === $"mecpt.mappedcode" && ($"mecpt.evidence_type" === "HCPCS" || $"mecpt.evidence_type" === "CPT4"), "left_outer")
      .join(mapPatTypeEvidence
        .as("mepos"), $"clm.pos" === $"mepos.mappedcode" && $"mepos.evidence_type" === "POS", "left_outer")
      .join(mapPatTypeEvidence
        .as("merev"), $"clm.mappedrev" === $"merev.mappedcode" && $"merev.evidence_type" === "REV", "left_outer")
      .where(coalesce($"mecpt.pat_type_cui", $"mepos.pat_type_cui", $"merev.pat_type_cui",$"meprocmod.pat_type_cui").isNotNull)
      .select($"clm.groupid", $"clm.client_ds_id", $"clm.encounterid",
        $"mecpt.evidence_type".as("cpt_ev_type"),
        $"mepos.evidence_type".as("pos_ev_type"),
        $"merev.evidence_type".as("rev_ev_type"),
        $"meprocmod.evidence_type".as("proc_ev_type"),
        $"mecpt.pat_type_cui".as("cpt_pt_cui"),
        $"mepos.pat_type_cui".as("pos_pt_cui"),
        $"merev.pat_type_cui".as("rev_pt_cui"),
        $"meprocmod.pat_type_cui".as("proc_pt_cui")
      ).select($"groupid", $"client_ds_id", $"encounterid", $"cpt_ev_type", $"pos_ev_type", $"rev_ev_type", $"proc_ev_type", $"cpt_pt_cui", $"pos_pt_cui", $"rev_pt_cui", $"proc_pt_cui")

    // diag evidence
    val diagEvidence = diagnosis.where($"encounterid".isNotNull && $"groupid".isNotNull && $"client_ds_id".isNotNull &&
      $"codetype".isin("ICD9", "ICD10") && $"PRIMARYDIAGNOSIS" === 1)
      .as("diag")
      .join(mpv, $"mpv.client_ds_id" === $"diag.client_ds_id")
      .join(mapPatTypeEvidence.where($"pat_type_cui".isNotNull).as("mediag"),
        $"diag.mappeddiagnosis" === $"mediag.mappedcode" &&
          $"diag.codetype" === when($"mediag.evidence_type" === lit("PRINDX9"), lit("ICD9"))
              .when($"mediag.evidence_type" === lit("PRINDX10"), lit("ICD10")), "left_outer")
      .select($"diag.groupid",
        $"diag.client_ds_id",
        $"diag.encounterid",
        $"mediag.evidence_type",
        $"mediag.pat_type_cui")

    // encounter evidence
    val encounterEvidence =
      clinicalEncounter.as("ce")
        .join(mpv, $"mpv.client_ds_id" === $"ce.client_ds_id")
        .join(mapPatTypeEvidence
          .where($"pat_type_cui".isNotNull)
          .as("med"), $"ce.localdrg" === $"med.mappedcode" && $"med.evidence_type" === "MSDRG", "left_outer")
        .join(zhFacilityRollup
          .where($"patient_type_cui".isNotNull)
          .as("fr"), $"ce.groupid" === $"fr.groupid" && $"ce.client_ds_id" === $"fr.client_ds_id" && $"ce.facilityid" === $"fr.facility_id", "left_outer")
        .select($"ce.groupid",
          $"ce.client_ds_id",
          $"ce.encounterid",
          $"med.pat_type_cui".as("drg_pt_type"),
          $"med.evidence_type".as("drg_ev_type"),
          $"fr.patient_type_cui".as("fac_pt_type")).distinct()

    // insurance evidence
    val insuranceEvidence = insurance.where($"encounterid".isNotNull && $"groupid".isNotNull && $"client_ds_id".isNotNull)
      .as("ins")
      .join(mpv, $"mpv.client_ds_id" === $"ins.client_ds_id")
      .join(mapInsPatType.where($"pat_type_cui".isNotNull).as("ins_evd"), $"ins.GROUPID" === $"ins_evd.GROUPID" &&
        $"ins_evd.localcode" === when($"ins_evd.mappedfield" === lit("PLANNAME"), $"ins.planname")
          .when($"ins_evd.mappedfield" === "PLANCODE", $"ins.plancode"), "left_outer")
      .where($"ins_evd.pat_type_cui".isNotNull)
      .select(
        $"ins.groupid",
        $"ins.client_ds_id",
        $"ins.encounterid",
        $"ins_evd.MAPPEDFIELD".as("evidence_type"),
        $"ins_evd.pat_type_cui".as("pat_type_cui"))


    // combine
    val evidence = careAreaEvidence.where($"ca_pt_cui".isNotNull)
      .select($"groupid", $"client_ds_id", $"encounterid", $"ca_ev_type".as("evidence_type"), $"ca_pt_cui".as("pat_type_cui"))
      .union(careAreaEvidence.select($"groupid", $"client_ds_id", $"encounterid", $"svc_ev_type".as("evidence_type"), $"svc_pt_cui".as("pat_type_cui"))
        .where($"svc_pt_cui".isNotNull))
      .union(claimEvidence.select($"groupid", $"client_ds_id", $"encounterid", $"cpt_ev_type".as("evidence_type"), $"cpt_pt_cui".as("pat_type_cui"))
        .where($"cpt_pt_cui".isNotNull).distinct)
      .union(claimEvidence.select($"groupid", $"client_ds_id", $"encounterid", $"pos_ev_type".as("evidence_type"), $"pos_pt_cui".as("pat_type_cui"))
        .where($"pos_pt_cui".isNotNull).distinct)
      .union(claimEvidence.select($"groupid", $"client_ds_id", $"encounterid", $"rev_ev_type".as("evidence_type"), $"rev_pt_cui".as("pat_type_cui"))
        .where($"rev_pt_cui".isNotNull).distinct)
      .union(claimEvidence.select($"groupid", $"client_ds_id", $"encounterid", $"proc_ev_type".as("evidence_type"), $"proc_pt_cui".as("pat_type_cui"))
        .where($"proc_pt_cui".isNotNull).distinct)
      .union(diagEvidence)
      .union(encounterEvidence.select($"groupid", $"client_ds_id", $"encounterid", $"drg_ev_type".as("evidence_type"), $"drg_pt_type".as("pat_type_cui"))
        .where($"drg_pt_type".isNotNull))
      .union(encounterEvidence.select($"groupid", $"client_ds_id", $"encounterid", $"fac_pt_type".as("pat_type_cui")).withColumn("evidence_type", lit("FAC"))
        .where($"fac_pt_type".isNotNull))
      .union(insuranceEvidence)
        .where($"pat_type_cui".isNotNull && $"evidence_type".isNotNull)

    evidence
  }
}