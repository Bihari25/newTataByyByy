package com.optum.oap.backend.etl.common

import com.optum.oap.sparkdataloader.UserDefinedFunctionForDataLoader
import org.apache.spark.sql.SparkSession
import org.apache.spark.sql.expressions.UserDefinedFunction
import org.apache.spark.sql.functions.udf

/**
  *
  * Copyright 2019 Optum Analytics
  *
  * Date: 10/10/2019
  *
  * Creator: rrogers2
  */

object CleanPunct extends UserDefinedFunctionForDataLoader {

  val cleanPunctUDF: UserDefinedFunction = udf { inStr: String => {
    cleanPunct(inStr)
  }
  }

  def cleanPunct(inStr: String): String = {
    if (inStr == null) {
      null
    } else {
      val cleaned = inStr.toUpperCase.replaceAll("[-.]", "").replaceAll("[,]", " ")
      val split = cleaned.split(" ").toList
      split.mkString(" ").replaceAll("[ ]{2,}", " ").trim
    }
  }

  override def registerMe(sparkSession: SparkSession): Unit = {
    sparkSession.udf.register(name, cleanPunctUDF)
  }

  override def name: String = "cleanPunct"

}