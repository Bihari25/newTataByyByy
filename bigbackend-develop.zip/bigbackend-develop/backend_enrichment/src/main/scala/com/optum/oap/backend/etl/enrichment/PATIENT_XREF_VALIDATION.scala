package com.optum.oap.backend.etl.enrichment

import com.optum.oap.backend.cdrTempModel.{patient_xref, validation}
import com.optum.oap.backend.etl.common.PartitionedDataOperations
import com.optum.oap.backend.etl.enrichment.FACILITY_XREF_VALIDATION.date
import com.optum.oap.backend.loader.EnrichmentRunTimeVariables
import com.optum.oap.cdr.models.patient
import com.optum.oap.sparkdataloader.{RuntimeVariables, TableInfo, UserDefinedFunctionForDataLoader}
import org.apache.spark.sql.functions.lit
import org.apache.spark.sql.{DataFrame, SparkSession}
import org.slf4j.LoggerFactory

import java.text.SimpleDateFormat
import java.util.Date

/**
  *
  * Copyright 2021 Optum Analytics
  *
  * Date: 02/17/21
  *
  * Creator: pavula
  */
object PATIENT_XREF_VALIDATION extends TableInfo[validation] with PartitionedDataOperations {

  val log = LoggerFactory.getLogger(this.getClass)

  override def dependsOn = Set("V_PATIENT_XREF")

  override def name = "PATIENT_XREF_VALIDATION"

  private val date = new SimpleDateFormat("yyyyMMdd").format(new Date()).toInt

  override def createDataFrame(sparkSession: SparkSession,
                               loadedDependencies: Map[String, DataFrame],
                               udfMap: Map[String, UserDefinedFunctionForDataLoader],
                               runtimeVariables: RuntimeVariables): DataFrame = {
    import sparkSession.implicits._

    implicit val session = sparkSession
    val schema = EnrichmentRunTimeVariables(runtimeVariables).cdrSchema
    val pXref = loadedDependencies("V_PATIENT_XREF").as[patient_xref]
    val patientXref = if(pXref.isEmpty) loadData(schema, "V_PATIENT_XREF").as[patient_xref] else pXref

    val currentPatientXref = patientXref.where($"partition_date" === lit(date))
    val distinctHgpid = currentPatientXref.select($"hgpid").distinct()

    if(distinctHgpid.count() != currentPatientXref.count()) {
      throw PatientXrefMismatchException("The count of patient_xref did not match to distinct count of hgpid, something went wrong." )
    }

    Seq.empty[validation].toDF()
  }

  final case class PatientXrefMismatchException(message: String = "", exception: Throwable = null) extends Exception(message)
}
