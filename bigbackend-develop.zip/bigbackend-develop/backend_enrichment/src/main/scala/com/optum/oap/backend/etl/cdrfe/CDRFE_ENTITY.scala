package com.optum.oap.backend.etl.cdrfe

import com.optum.oap.backend.util.ImportResources.CDR_TABLE_PARTITION_MAP
import com.optum.oap.sparkdataloader.{RuntimeVariables, TableInfo, UserDefinedFunctionForDataLoader}
import org.apache.spark.sql.functions.lit
import org.apache.spark.sql.types.{StructField, StructType}
import org.apache.spark.sql.{Column, DataFrame, Row, SparkSession}

import scala.util.{Failure, Success, Try}

/**
  * Case class for representing CDRBE model that should be copied directly from CDRFE HDFS/S3 location.
  * @param cdrBeTableName table name from the cdr_common.txt file
  * @param clientDSIds List of client_ds_ids
  * @param dependsOn
  */
class CDRFE_ENTITY(cdrBeTableName: String,
                        dataSources: Seq[CDRFEDataSource],
                        predicate: Column = lit(true))
  extends TableInfo[EmptySchema]
    with CDRBESchemaHelper {

  override val dependsOn: Set[String] = Set.empty[String]

  override def name: String = cdrBeTableName.toUpperCase

  override def ignoreExtraColumnsInDataFrame: Boolean = true

  private val cdrFETableName = CDRFE_TABLE_CROSS_WALK.getOrElse(cdrBeTableName, cdrBeTableName)

  private val cdrbeTableSchema = schemaForTable(cdrBeTableName)

  override def skipCoalesce: Boolean = true

  override protected def createDataFrame(sparkSession: SparkSession,
                                         loadedDependencies: Map[String, DataFrame],
                                         udfMap: Map[String, UserDefinedFunctionForDataLoader],
                                         runtimeVariables: RuntimeVariables): DataFrame = {

    val output = dataSources.map(f = source => {
      val entity = Try(sparkSession
        .read
        .parquet(s"${source.dataSourcePath}/$cdrFETableName")
        .where(predicate)
        .drop(columnsToIgnore: _*))

      entity match {
        case Success(dataframe) => castToCDRBESchema(dataframe, cdrbeTableSchema)
        case Failure(exception) => {
          logger.warn(s"${source.cdsId} doesn't contain the $cdrFETableName table. Returning empty dataframe. Exception $exception")
          val structType = StructType(cdrbeTableSchema.map(record => StructField(record.fieldName.toLowerCase, record.sparkDataType)))
          sparkSession.createDataFrame(sparkSession.sparkContext.emptyRDD[Row], structType)
        }
      }
    })

    output.reduce(_ unionByName _).repartition(CDR_TABLE_PARTITION_MAP.getOrElse(name, partitions))
  }
}

object CDRFE_ENTITY {
  def apply(cdrBeTableName: String,
            dataSources: Seq[CDRFEDataSource],
            predicate: Column = lit(true)): CDRFE_ENTITY = new CDRFE_ENTITY(cdrBeTableName, dataSources, predicate)
}
