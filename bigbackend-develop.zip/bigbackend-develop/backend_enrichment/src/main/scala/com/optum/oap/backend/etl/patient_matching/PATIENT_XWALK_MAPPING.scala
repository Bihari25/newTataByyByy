package com.optum.oap.backend.etl.patient_matching

import com.optum.oap.backend.loader.EnrichmentRunTimeVariables
import com.optum.oap.cdr.models.{pat_id_xwalk, patient}
import com.optum.oap.sparkdataloader.{RuntimeVariables, TableInfo, UserDefinedFunctionForDataLoader}
import org.apache.spark.sql.functions.{broadcast, lit, when}
import org.apache.spark.sql.{DataFrame, SparkSession}

/**
  * Creator: bishu
  * Date: 11/25/20
  */
object PATIENT_XWALK_MAPPING extends TableInfo[patient] {

  override def dependsOn = Set("CDR_FE_PATIENT", "PAT_ID_XWALK_TRANSITIVE","ICPM_PATIENT")

  override def createDataFrame(sparkSession: SparkSession,
                               loadedDependencies: Map[String, DataFrame],
                               udfMap: Map[String, UserDefinedFunctionForDataLoader],
                               runtimeVariables: RuntimeVariables): DataFrame = {
    import sparkSession.implicits._

    val patientIn = loadedDependencies("CDR_FE_PATIENT").drop("row_source","modified_date").as[patient]
    val patIdXwalk = loadedDependencies("PAT_ID_XWALK_TRANSITIVE").as[pat_id_xwalk]
    val patientIcpm = loadedDependencies("ICPM_PATIENT").as[patient]

    val patientUnion = patientIn.unionByName(patientIcpm)

    val grpid = EnrichmentRunTimeVariables(runtimeVariables).clientId

    val patIdXwalkMini = broadcast(patIdXwalk.select(
      $"groupid",
      $"old_id",
      $"new_id",
      $"client_ds_id"
    ))

    val ab_where_clause = {
      if (grpid.trim.equalsIgnoreCase("H984216")) $"a.client_ds_id" === $"b.client_ds_id"
      else $"a.groupid" === $"b.groupid"
    }

    // now that dependencies has been resolved, apply this to MRN mapping
    val mappedMrn = patientUnion.as("a")
      .join(patIdXwalkMini.as("b"), $"a.medicalrecordnumber" === $"b.old_id" && ab_where_clause, "left")
      .withColumn("mrn",
        when($"a.medicalrecordnumber" === $"b.old_id", $"b.new_id")
          .otherwise($"a.medicalrecordnumber"))
      .select(
        $"a.client_ds_id",
        $"a.datasrc",
        $"a.dateofbirth",
        $"a.dateofdeath",
        $"a.groupid",
        $"a.grp_mpi",
        $"a.hgpid",
        $"a.inactive_flag",
        $"a.patientid",
        $"a.facilityid",
        $"mrn".as("medicalrecordnumber") // replace with new medical record number
      )

    mappedMrn
  }
}
