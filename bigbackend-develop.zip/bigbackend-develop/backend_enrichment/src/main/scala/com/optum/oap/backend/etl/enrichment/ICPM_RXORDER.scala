package com.optum.oap.backend.etl.enrichment

import com.optum.oap.backend.etl.common.NormalizeNDC
import com.optum.oap.backend.loader.EnrichmentRunTimeVariables
import com.optum.oap.cdr.models.{int_claim_pharm, rxorder}
import com.optum.oap.backend.etl.common.{CDRConstants, IsSafeToNumber}
import com.optum.oap.sparkdataloader.{RuntimeVariables, TableInfo, UserDefinedFunctionForDataLoader}
import org.apache.spark.sql.expressions.Window
import org.apache.spark.sql.{DataFrame, SparkSession}
import org.slf4j.LoggerFactory
import org.apache.spark.sql.functions.{lit, when, _}
import org.apache.spark.sql.types.{DataTypes, DoubleType, IntegerType, StringType}


object ICPM_RXORDER extends TableInfo[rxorder] {

  private val log = LoggerFactory.getLogger(this.getClass)

  override def dependsOn = Set("INT_CLAIM_PHARM")

  override def name = "ICPM_RXORDER"

  override def createDataFrame(sparkSession: SparkSession,
                               loadedDependencies: Map[String, DataFrame],
                               udfMap: Map[String, UserDefinedFunctionForDataLoader],
                               runtimeVariables: RuntimeVariables): DataFrame = {

    import sparkSession.implicits._

    val intClaimPharmIn = loadedDependencies("INT_CLAIM_PHARM").as[int_claim_pharm]

    intClaimPharmIn.select(
      $"groupid"
      , lit("int_claim_pharm").as("datasrc")
      , $"client_ds_id"
      , $"service_date".as("issuedate")
      , lit("P").as("ordervsprescription")
      , $"member_id".as("patientid")
      , $"rx_id".as("rxid")
      , $"days_supply".as("localdaysupplied")
      , coalesce($"encounterid", concat($"claim_id", lit("_"), $"service_date")).as("encounterid")
      , $"ndc_name".as("localdescription")
      , $"ndc".as("localmedcode")
      , NormalizeNDC.normalize($"ndc").as("localndc")
      , $"Presc_Prov_Id".as("localproviderid")
      , $"quantity_per_fill".cast(StringType).as("quantityperfill")
      , lit("1").as("venue")
      , lit("CH002047").as("ordertype")
      , $"pay_process_date".as("post_dt")
      , $"contract_id"
      , $"network_paid_status"
      , $"generic_status"
      , $"formulary_indicator"
      , round($"copay_amount", 2).as("copay_amt")
      , round($"coinsurance_amount", 2).as("coinsurance_amt")
      , round($"deductible_amount", 2).as("deductable_amt")
      , round($"patient_liability_amount", 2).as("pat_liability_amt")
      , round($"admin_fee_amt", 2).as("admin_fee_amt")
      , round($"coord_benefits_amt", 2).as("coord_benefits_amt")
      , round($"not_covered_amt", 2).as("not_covered_amt")
      , round($"sales_tax_amt", 2).as("sales_tax_amt")
      , round($"other_carrier_pay_amt", 2).as("other_carrier_pay_amt")
      , round($"other_1_amt", 2).as("other_1_amt")
      , round($"other_2_amt", 2).as("other_2_amt")
      , round($"other_3_amt", 2).as("other_3_amt")
      , round($"other_4_amt", 2).as("other_4_amt")
      , $"adjusted_rx_cnt"
      , $"capitated_service_ind"
      , round($"dispensing_fee", 2).as("dispensing_fee")
      , $"fulfillment_type_cd"
      , round($"ingredient_cost_paid", 2).as("ingredient_cost_paid")
      , $"localdaw"
      , $"pharmacy_id"
      , $"presc_prov_status_id"
      , $"refill_num"
      , $"spec_rx_ind"
      , $"denied_flag"
      , $"pseudo_flag"
      , round($"allowed_amount", 2).as("allowedamount")
      , round($"requested_amount", 2).as("charge")
      , round($"Payment_Amount", 2).as("paidamount")
      , $"ii_cust_attr_1".as("cust_attr_1")
      , $"ii_cust_attr_2".as("cust_attr_2")
      , $"ii_cust_attr_3".as("cust_attr_3")
      , $"ii_cust_attr_4".as("cust_attr_4")
      , $"ii_cust_attr_5".as("cust_attr_5")
      , $"ii_cust_attr_6".as("cust_attr_6")
      , $"ii_cust_attr_7".as("cust_attr_7")
      , $"ii_cust_attr_8".as("cust_attr_8")
      , $"ii_cust_attr_9".as("cust_attr_9")
      , $"ii_cust_attr_10".as("cust_attr_10")
      , $"ii_cust_attr_11".as("cust_attr_11")
      , $"ii_cust_attr_12".as("cust_attr_12")
      , $"ii_cust_attr_13".as("cust_attr_13")
      , $"ii_cust_attr_14".as("cust_attr_14")
      , $"ii_cust_attr_15".as("cust_attr_15")
      , when(IsSafeToNumber.isSafeToNumber($"ii_cust_attr_16"), $"ii_cust_attr_16")
        .otherwise(lit(null))
        .as("cust_attr_16")
      , when(IsSafeToNumber.isSafeToNumber($"ii_cust_attr_17"), $"ii_cust_attr_17")
        .otherwise(lit(null))
        .as("cust_attr_17")
      , when(IsSafeToNumber.isSafeToNumber($"ii_cust_attr_18"), $"ii_cust_attr_18")
        .otherwise(lit(null))
        .as("cust_attr_18")
      , when(IsSafeToNumber.isSafeToNumber($"ii_cust_attr_19"), $"ii_cust_attr_19")
        .otherwise(lit(null))
        .as("cust_attr_19")
      , when(IsSafeToNumber.isSafeToNumber($"ii_cust_attr_20"), $"ii_cust_attr_20")
        .otherwise(lit(null))
        .as("cust_attr_20")
      , $"presc_prov_affil_id"
      , lit(null).cast(DataTypes.StringType).as("active_med_flag")
      , lit(null).cast(DataTypes.StringType).as("altmedcode")
      , lit(null).cast(DataTypes.StringType).as("dcc")
      , lit(null).cast(DataTypes.TimestampType).as("discontinuedate")
      , lit(null).cast(DataTypes.StringType).as("discontinuereason")
      , lit(null).cast(DataTypes.TimestampType).as("expiredate")
      , lit(null).cast(DataTypes.StringType).as("facilityid")
      , lit(null).cast(DataTypes.IntegerType).as("fillnum")
      , lit(null).cast(DataTypes.StringType).as("grp_mpi")
      , lit(null).cast(DataTypes.LongType).as("hgpid")
      , lit(null).cast(DataTypes.StringType).as("hts_generic")
      , lit(null).cast(DataTypes.StringType).as("hts_generic_ext")
      , lit(null).cast(DataTypes.StringType).as("hum_gen_med_key")
      , lit(null).cast(DataTypes.StringType).as("hum_med_key")
      , lit(null).cast(DataTypes.StringType).as("localdescription_phi")
      , lit(null).cast(DataTypes.StringType).as("localdischargemedflg")
      , lit(null).cast(DataTypes.StringType).as("localdosefreq")
      , lit(null).cast(DataTypes.StringType).as("localdoseunit")
      , lit(null).cast(DataTypes.StringType).as("localduration")
      , lit(null).cast(DataTypes.StringType).as("localform")
      , lit(null).cast(DataTypes.StringType).as("localgenericdesc")
      , lit(null).cast(DataTypes.StringType).as("localgpi")
      , lit(null).cast(DataTypes.StringType).as("localinfusionduration")
      , lit(null).cast(DataTypes.StringType).as("localinfusionrate")
      , lit(null).cast(DataTypes.StringType).as("localinfusionvolume")
      , lit(null).cast(DataTypes.StringType).as("localqtyofdoseunit")
      , lit(null).cast(DataTypes.StringType).as("localroute")
      , lit(null).cast(DataTypes.StringType).as("localstrengthperdoseunit")
      , lit(null).cast(DataTypes.StringType).as("localstrengthunit")
      , lit(null).cast(DataTypes.StringType).as("localtotaldose")
      , lit(null).cast(DataTypes.StringType).as("map_used")
      , lit(null).cast(DataTypes.StringType).as("mappedgpi")
      , lit(null).cast(DataTypes.IntegerType).as("mappedgpi_conf")
      , lit(null).cast(DataTypes.StringType).as("mappedndc")
      , lit(null).cast(DataTypes.IntegerType).as("mappedndc_conf")
      , lit(null).cast(DataTypes.StringType).as("mstrprovid")
      , lit(null).cast(DataTypes.StringType).as("ndc11")
      , lit(null).cast(DataTypes.StringType).as("orderstatus")
      , lit(null).cast(DataTypes.StringType).as("rxnorm_code")
      , lit(null).cast(DataTypes.StringType).as("signature"))
      .where((coalesce($"claim_adj_type", lit("K")) === "K") && $"patientid".isNotNull && $"rxid".isNotNull)
      .distinct()

  }
}