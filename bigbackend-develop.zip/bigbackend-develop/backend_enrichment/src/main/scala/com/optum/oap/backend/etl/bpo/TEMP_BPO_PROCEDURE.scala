package com.optum.oap.backend.etl.bpo

import java.sql.Timestamp

import com.optum.oap.backend.cdrTempModel.{temp_bpo_calculate_params, temp_bpo_patients, temp_bpo_procedure}
import com.optum.oap.backend.etl.bpo.BpoUtil.getBpoInputParameters
import com.optum.oap.backend.etl.common.IsSafeToNumber
import com.optum.oap.cdr.models._
import com.optum.oap.sparkdataloader.{RuntimeVariables, TableInfo, UserDefinedFunctionForDataLoader}
import org.apache.spark.sql.expressions.Window
import org.apache.spark.sql.functions._
import org.apache.spark.sql.types.{IntegerType, StringType, TimestampType}
import org.apache.spark.sql.{DataFrame, SparkSession}
import org.joda.time.DateTime

/**
  *
  * Copyright 2019 Optum Analytics
  *
  * Date: 6/3/19
  *
  * Creator: bpokharel(bishu)
  *
  */
object TEMP_BPO_PROCEDURE extends TableInfo[temp_bpo_procedure] {

  override def dependsOn = Set(
    "PROCEDUREDO",
    "TEMP_BPO_PATIENTS",
    "CLINICALENCOUNTER",
    "MAP_PATIENT_TYPE",
    "MAP_DISCHARGE_DISPOSITION",
    "MAP_DRG_TYPE",
    "MAP_PREDICATE_VALUES",
    "TEMP_BPO_CALCULATE_PARAMS"
  )

  override def name = "TEMP_BPO_PROCEDURE"

  override def createDataFrame(sparkSession: SparkSession,
                               loadedDependencies: Map[String, DataFrame],
                               udfMap: Map[String, UserDefinedFunctionForDataLoader],
                               runtimeVariables: RuntimeVariables): DataFrame = {
    import sparkSession.implicits._

    val proceduredo_DS = loadedDependencies("PROCEDUREDO").as[proceduredo]
    val temp_bpo_patients_DS = loadedDependencies("TEMP_BPO_PATIENTS").as[temp_bpo_patients]
    val clinicalencounter_DS = loadedDependencies("CLINICALENCOUNTER").as[clinicalencounter]
    val map_patient_type_DS = broadcast(loadedDependencies("MAP_PATIENT_TYPE")).as[map_patient_type]
    val map_discharge_disposition_DS = broadcast(loadedDependencies("MAP_DISCHARGE_DISPOSITION")).as[map_discharge_disposition]
    val map_drg_type_DS = broadcast(loadedDependencies("MAP_DRG_TYPE")).as[map_drg_type]
    val map_predicate_values_DS = broadcast(loadedDependencies("MAP_PREDICATE_VALUES")).as[map_predicate_values]
    val temp_bpo_calculate_params_DS = broadcast(loadedDependencies("TEMP_BPO_CALCULATE_PARAMS")).as[temp_bpo_calculate_params]

    val bpoInputParameters = getBpoInputParameters(sparkSession, temp_bpo_calculate_params_DS)
    val extractStartDate = bpoInputParameters.engineStartDate

    val patDf = temp_bpo_patients_DS
      .select(
        $"groupid",
        $"grp_mpi"
      ).distinct()

    val joinedDf = proceduredo_DS.as("a")
      .join(patDf.as("pat"),
        ($"a.groupid" === $"pat.groupid")
          && ($"a.grp_mpi" === $"pat.grp_mpi")
      )
      .join(map_predicate_values_DS.as("m"),
        ($"m.groupid" === $"a.groupid")
          && ($"m.client_ds_id" === $"a.client_ds_id")
          && ($"m.entity" === lit("PP_BPO_MEDICAL_CLAIMS"))
          && ($"m.column_name" === lit("PX_DX"))
          && ($"m.data_src" === lit("OADW"))
        , "left_outer"
      )
      .where(to_date($"a.proceduredate").geq(extractStartDate))
      .where($"a.codetype".isin(lit("ICD9"), lit("ICD10")))
      .where($"a.mappedcode".isNotNull)
      .where($"a.grp_mpi".isNotNull)
      .where(length($"a.mappedcode").leq(lit(7)))
      .withColumn("sourceid",
        when(
          $"m.client_ds_id".isNull, lit("NA"))
          .otherwise($"a.sourceid")
      )
      .withColumn("servicedate", to_date($"a.proceduredate"))
      .groupBy(
        $"a.groupid",
        $"a.encounterid",
        $"a.client_ds_id",
        $"a.grp_mpi",
        $"a.mappedcode",
        $"a.codetype",
        $"servicedate",
        $"a.performing_mstrprovid",
        $"sourceid"
      )
      .agg(
        min(when(IsSafeToNumber.isSafeToNumber($"a.procseq".cast(StringType)), $"a.procseq").otherwise(lit(99))).as("procseq"),
        max(when(upper($"a.localprincipleindicator") === lit("Y"), lit(1)).otherwise(lit(0))).as("principleindicator")
      ).select(
      $"a.groupid",
      $"a.encounterid",
      $"a.client_ds_id",
      $"a.grp_mpi",
      $"a.mappedcode",
      $"a.codetype",
      $"servicedate",
      $"a.performing_mstrprovid",
      $"procseq",
      $"principleindicator",
      $"sourceid"
    )

    val df1 = joinedDf.as("p")
      .withColumn("pxseq",
        row_number().over(
          Window.partitionBy($"p.groupid", $"p.encounterid", $"p.client_ds_id", $"p.grp_mpi", $"p.codetype", $"p.servicedate", $"p.performing_mstrprovid", $"p.sourceid")
            .orderBy($"p.principleindicator".desc, $"p.procseq", $"p.mappedcode")
        )
      )

    val joinedDf1 = df1.as("clm")
      .join(clinicalencounter_DS.as("ce"),
        ($"ce.groupid" === $"clm.groupid")
          && ($"ce.encounterid" === $"clm.encounterid")
          && ($"ce.client_ds_id" === $"clm.client_ds_id")
          && ($"ce.grp_mpi" === $"clm.grp_mpi")
      )
      .join(map_patient_type_DS.as("mp"),
        ($"ce.groupid" === $"mp.groupid")
          && ($"ce.localpatienttype" === $"mp.local_code")
        , "left_outer"
      )
      .join(map_discharge_disposition_DS.as("md"),
        ($"clm.groupid" === $"mp.groupid")
          && ($"ce.localdischargedisposition" === $"md.mnemonic")
        , "left_outer"
      )
      .join(map_drg_type_DS.as("mdt"),
        ($"clm.groupid" === $"mdt.groupid")
          && (coalesce($"ce.localdrgtype", lit("MSDRG")) === $"mdt.code")
        , "left_outer"
      )
      .where($"clm.pxseq".leq(lit(25)))
      .groupBy(
        $"clm.groupid",
        $"clm.encounterid",
        $"clm.client_ds_id",
        $"clm.grp_mpi",
        $"clm.servicedate",
        $"clm.performing_mstrprovid",
        $"ce.facilityid",
        $"ce.admittime",
        $"ce.dischargetime",
        $"mp.cui",
        $"ce.localdrg",
        $"mdt.cui",
        $"md.cui",
        $"clm.codetype",
        $"clm.sourceid"
      )
      .agg(
        max(when($"clm.pxseq" === lit(1), $"clm.mappedcode").otherwise(lit(null).cast(StringType))).as("icdproc1"),
        max(when($"clm.pxseq" === lit(2), $"clm.mappedcode").otherwise(lit(null).cast(StringType))).as("icdproc2"),
        max(when($"clm.pxseq" === lit(3), $"clm.mappedcode").otherwise(lit(null).cast(StringType))).as("icdproc3"),
        max(when($"clm.pxseq" === lit(4), $"clm.mappedcode").otherwise(lit(null).cast(StringType))).as("icdproc4"),
        max(when($"clm.pxseq" === lit(5), $"clm.mappedcode").otherwise(lit(null).cast(StringType))).as("icdproc5"),
        max(when($"clm.pxseq" === lit(6), $"clm.mappedcode").otherwise(lit(null).cast(StringType))).as("icdproc6"),
        max(when($"clm.pxseq" === lit(7), $"clm.mappedcode").otherwise(lit(null).cast(StringType))).as("icd_proc_7"),
        max(when($"clm.pxseq" === lit(8), $"clm.mappedcode").otherwise(lit(null).cast(StringType))).as("icd_proc_8"),
        max(when($"clm.pxseq" === lit(9), $"clm.mappedcode").otherwise(lit(null).cast(StringType))).as("icd_proc_9"),
        max(when($"clm.pxseq" === lit(10), $"clm.mappedcode").otherwise(lit(null).cast(StringType))).as("icd_proc_10"),
        max(when($"clm.pxseq" === lit(11), $"clm.mappedcode").otherwise(lit(null).cast(StringType))).as("icd_proc_11"),
        max(when($"clm.pxseq" === lit(12), $"clm.mappedcode").otherwise(lit(null).cast(StringType))).as("icd_proc_12"),
        max(when($"clm.pxseq" === lit(13), $"clm.mappedcode").otherwise(lit(null).cast(StringType))).as("icd_proc_13"),
        max(when($"clm.pxseq" === lit(14), $"clm.mappedcode").otherwise(lit(null).cast(StringType))).as("icd_proc_14"),
        max(when($"clm.pxseq" === lit(15), $"clm.mappedcode").otherwise(lit(null).cast(StringType))).as("icd_proc_15"),
        max(when($"clm.pxseq" === lit(16), $"clm.mappedcode").otherwise(lit(null).cast(StringType))).as("icd_proc_16"),
        max(when($"clm.pxseq" === lit(17), $"clm.mappedcode").otherwise(lit(null).cast(StringType))).as("icd_proc_17"),
        max(when($"clm.pxseq" === lit(18), $"clm.mappedcode").otherwise(lit(null).cast(StringType))).as("icd_proc_18"),
        max(when($"clm.pxseq" === lit(19), $"clm.mappedcode").otherwise(lit(null).cast(StringType))).as("icd_proc_19"),
        max(when($"clm.pxseq" === lit(20), $"clm.mappedcode").otherwise(lit(null).cast(StringType))).as("icd_proc_20"),
        max(when($"clm.pxseq" === lit(21), $"clm.mappedcode").otherwise(lit(null).cast(StringType))).as("icd_proc_21"),
        max(when($"clm.pxseq" === lit(22), $"clm.mappedcode").otherwise(lit(null).cast(StringType))).as("icd_proc_22"),
        max(when($"clm.pxseq" === lit(23), $"clm.mappedcode").otherwise(lit(null).cast(StringType))).as("icd_proc_23"),
        max(when($"clm.pxseq" === lit(24), $"clm.mappedcode").otherwise(lit(null).cast(StringType))).as("icd_proc_24"),
        max(when($"clm.pxseq" === lit(25), $"clm.mappedcode").otherwise(lit(null).cast(StringType))).as("icd_proc_25"),
        max(lit(1)).as("quantity")
      )
      .select(
        $"clm.groupid",
        $"clm.encounterid",
        $"clm.client_ds_id",
        $"clm.grp_mpi",
        $"clm.servicedate".cast(TimestampType),
        $"clm.performing_mstrprovid".cast(StringType),
        $"ce.facilityid",
        $"ce.admittime",
        $"ce.dischargetime",
        $"mp.cui".as("patienttype"),
        $"ce.localdrg",
        $"mdt.cui".as("localdrggrouper"),
        $"md.cui".as("disposition"),
        $"quantity",
        $"clm.codetype",
        $"icdproc1",
        $"icdproc2",
        $"icdproc3",
        $"icdproc4",
        $"icdproc5",
        $"icdproc6",
        $"icd_proc_7",
        $"icd_proc_8",
        $"icd_proc_9",
        $"icd_proc_10",
        $"icd_proc_11",
        $"icd_proc_12",
        $"icd_proc_13",
        $"icd_proc_14",
        $"icd_proc_15",
        $"icd_proc_16",
        $"icd_proc_17",
        $"icd_proc_18",
        $"icd_proc_19",
        $"icd_proc_20",
        $"icd_proc_21",
        $"icd_proc_22",
        $"icd_proc_23",
        $"icd_proc_24",
        $"icd_proc_25",
        $"clm.sourceid",
        lit(null).cast(IntegerType).alias("principleindicator"),
        lit(null).cast(IntegerType).alias("procseq"),
        lit(new Timestamp(DateTime.now().getMillis)).as("db_create_dt_tm")
      )

    joinedDf1.as[temp_bpo_procedure].toDF()

  }

}
