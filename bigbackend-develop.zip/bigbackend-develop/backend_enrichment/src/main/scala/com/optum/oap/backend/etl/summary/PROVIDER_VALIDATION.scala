package com.optum.oap.backend.etl.summary

import com.optum.oap.backend.cdrTempModel.validation
import com.optum.oap.cdr.models._
import com.optum.oap.sparkdataloader.{RuntimeVariables, TableInfo, UserDefinedFunctionForDataLoader}
import org.apache.spark.sql.functions.broadcast
import org.apache.spark.sql.{DataFrame, SparkSession}

/**
  *
  * Copyright 2020 Optum Analytics
  *
  * Date: 12/17/20
  *
  * Creator: pavula
  */
object PROVIDER_VALIDATION extends TableInfo[validation] {

  override def dependsOn =
    Set("ZH_PROVIDER_MASTER_XREF", "ZH_PROVIDER_MASTER", "ZH_PROVIDER")

  override def name = "PROVIDER_VALIDATION"

  override def createDataFrame(sparkSession: SparkSession,
                               loadedDependencies: Map[String, DataFrame],
                               udfMap: Map[String, UserDefinedFunctionForDataLoader],
                               runtimeVariables: RuntimeVariables): DataFrame = {
    import sparkSession.implicits._

    val zh_prov = loadedDependencies("ZH_PROVIDER").as[zh_provider]
    val zh_prov_xref = broadcast(loadedDependencies("ZH_PROVIDER_MASTER_XREF")).as[zh_provider_master_xref]
    val zh_provider_master = broadcast(loadedDependencies("ZH_PROVIDER_MASTER")).as[zh_provider_master]

    val zh_xref_count = zh_prov.as("zh").join(zh_prov_xref.alias("xref"),
      $"zh.client_ds_id" === $"xref.client_ds_id" &&  $"zh.groupid" === $"xref.groupid" &&  $"zh.localproviderid" === $"xref.localproviderid", "inner").count

    if(zh_xref_count != zh_prov_xref.count() || zh_xref_count != zh_prov.count()) {
      throw ProviderCountMismatchException("The Individual count of zh_provider or zh_provider_master_xref did not match to client_ds_id and localproviderid combination." )
    }

    val master_count = zh_prov.as("zh").join(zh_prov_xref.alias("xref"),
      $"zh.master_hgprovid" === $"xref.master_hgprovid" &&  $"zh.groupid" === $"xref.groupid", "inner").select($"zh.master_hgprovid").distinct().count()

    if(master_count != zh_provider_master.count()) {
      throw ProviderCountMismatchException("Number of distinct master providers in zh_provider and zh_provider_master_xref not same as zh_provider_master count")
    }

    Seq.empty[validation].toDF()
  }

  final case class ProviderCountMismatchException(message: String = "", exception: Throwable = null) extends Exception(message)
}
