package com.optum.oap.backend.etl.encgrps

import com.optum.oap.backend.cdrTempModel.temp_encounter_grp_ccs
import com.optum.oap.sparkdataloader.QueryAndMetadata


object TEMP_ENCOUNTER_GRP_CCS extends QueryAndMetadata[temp_encounter_grp_ccs] {
  override def name: String = "TEMP_ENCOUNTER_GRP_CCS"

  override def sparkSql: String =
    """select /*+ BROADCAST(cd) */ dx.groupid, dx.grp_mpi, dx.ENCOUNTER_GRP_NUM, ccs_category as ccs_cat, max(primarydiagnosis) as primarydiagnosis
from TEMP_ENCOUNTER_PRINDX dx
inner join REF_MAP_CCS_ICDX_DX cd on ( REGEXP_REPLACE (dx.mappeddiagnosis, '\\.', "")  =  REGEXP_REPLACE (cd.icd_cm_code, '\\.', "")  and dx.icd_ver = cd.icd_version)
group by dx.groupid, dx.grp_mpi, dx.ENCOUNTER_GRP_NUM, ccs_category"""

  override def dependsOn: Set[String] = Set("TEMP_ENCOUNTER_PRINDX", "REF_MAP_CCS_ICDX_DX")
}
