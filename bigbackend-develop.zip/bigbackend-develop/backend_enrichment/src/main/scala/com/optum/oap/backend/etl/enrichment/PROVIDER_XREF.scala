package com.optum.oap.backend.etl.enrichment

import com.optum.oap.backend.cdrTempModel.provider_xref
import com.optum.oap.backend.etl.common.XrefUtil
import com.optum.oap.backend.etl.enrichment.PATIENT_XREF.{logger, name, partitions}
import com.optum.oap.backend.loader.EnrichmentRunTimeVariables
import com.optum.oap.cdr.models.zh_provider
import com.optum.oap.sparkdataloader.{RuntimeVariables, TableInfo, UserDefinedFunctionForDataLoader}
import org.apache.spark.sql.functions._
import org.apache.spark.sql.types.IntegerType
import org.apache.spark.sql.{DataFrame, SparkSession}
import org.slf4j.LoggerFactory

object PROVIDER_XREF extends TableInfo[provider_xref] {

  val log = LoggerFactory.getLogger(this.getClass)

  override def dependsOn = Set("TEMP_ZH_PROV_PREMATCH", "COMMON_PROVIDER_XREF", "CDR_FE_PROVIDER_XREF")

  override def name = "PROVIDER_XREF"

  override def createDataFrame(sparkSession: SparkSession,
                               loadedDependencies: Map[String, DataFrame],
                               udfMap: Map[String, UserDefinedFunctionForDataLoader],
                               runtimeVariables: RuntimeVariables): DataFrame = {
    import sparkSession.implicits._
    implicit val session = sparkSession

    val zh_providerIn = loadedDependencies("TEMP_ZH_PROV_PREMATCH").as[zh_provider]
    val commonProvXref = loadedDependencies("COMMON_PROVIDER_XREF").as[provider_xref]

    val enrichmentRunTimeVariables = EnrichmentRunTimeVariables(runtimeVariables)

    if (!enrichmentRunTimeVariables.cdrSchema.equals("test")) {
      logger.warn(s"Refreshing $name table")
      sparkSession.catalog.recoverPartitions(s"${enrichmentRunTimeVariables.cdrSchema}.$name")
    }

    val numOfPartitions = Math.ceil(partitions * enrichmentRunTimeVariables.partitionMultiplier).toInt

    val xrefUtil = new XrefUtil()

    /*
      This is only executed once, when we first import the PROVIDER_XREF to the common location
   */
    val loadedDf = if (commonProvXref.isEmpty) {
      val provXref = loadedDependencies("CDR_FE_PROVIDER_XREF").as[provider_xref]
      val df = provXref.select($"groupid", $"providerid", $"hgprovid", $"client_ds_id",
        date_format(current_date(), "yyyyMMdd").cast(IntegerType).as("partition_date"),
        $"hgprovid".as("hgprovid_without_groupid"))

      xrefUtil.writeInitialXrefData(df, runtimeVariables, "PROVIDER_XREF")
    } else {
      log.warn(s"PROVIDER_XREF Table is NOT empty at common location ${commonProvXref.count}")
      if (enrichmentRunTimeVariables.cdrSchema.equals("test")) {
        commonProvXref
      }
      else {
        sparkSession.read.parquet(s"${enrichmentRunTimeVariables.commonPath}/$name")
      }
    }


    val newDf = getNewProviderRecords(sparkSession, loadedDf.toDF(), zh_providerIn.toDF())

    val count = newDf.count()

    val returnDf = if (count > 0) {
      logger.warn(s"INSIDE PROVIDER_XREF diffDf count  ${count}")
      xrefUtil.writeNewXrefRecords(loadedDf.toDF(), newDf, $"hgprovid_without_groupid", "hgprovid", runtimeVariables, "PROVIDER_XREF", numOfPartitions)
    } else {
      log.warn(s" There are no new PROVIDER_XREF Records so skipping writing to PROVIDER_XREF")
      sparkSession.emptyDataset[provider_xref].toDF()
    }

    returnDf
  }

  /**
    *
    * @param sparkSession session
    * @param loadedDf provider_xref dataframe
    * @param zh_providerIn zh_proivder dataframe
    * @return returns the records that are in zh_provider but not in provider_xref when joined on to providerid and client_ds_id
    */
  def getNewProviderRecords(sparkSession: SparkSession, loadedDf: DataFrame, zh_providerIn: DataFrame) : DataFrame = {
    import sparkSession.implicits._
    zh_providerIn.as("prov")
      .join(loadedDf.as("ref"), $"prov.groupid" === $"ref.groupid" && $"prov.localproviderid" === $"ref.providerid" && $"prov.client_ds_id" === $"ref.client_ds_id", "left_outer")
      .where($"ref.providerid".isNull)
      .select($"prov.groupid",
        $"prov.localproviderid".as("providerid"),
        $"prov.client_ds_id").distinct().withColumn("partition_date",  date_format(current_date(), "yyyyMMdd").cast(IntegerType))

  }

  }
