package com.optum.oap.backend.etl.encgrps

import com.optum.oap.backend.cdrTempModel.temp_encounter_grp_loc
import com.optum.oap.sparkdataloader.QueryAndMetadata

object TEMP_ENCOUNTER_GRP_LOC extends QueryAndMetadata[temp_encounter_grp_loc] {
  override def name: String = "TEMP_ENCOUNTER_GRP_LOC"

  override def sparkSql: String =
    """
      |select ENCOUNTER_GRP_NUM
      |                    , max(case when locrank = 1 then locallocationname else null end) as lastloc
      |                    , max(case when carank = 1 then localcareareacode else null end) as lastca
      |                    , max(case when svcrank = 1 then service else null end) as service
      |                    , max(case when svcrank = 1 then servicecode else null end) as servicecode
      |                    , MAX(CASE WHEN CAREAREA = 'CH000020' THEN 1 ELSE 0 END) has_ed_eca
      |FROM (
      |select   el.groupid, el.grp_mpi, el.ENCOUNTER_GRP_NUM, el.localcareareacode, el.service, el.encounterid, el.client_ds_id, el.locallocationname, el.servicecode, el.carearea
      |,row_number() over (partition by el.groupid, el.grp_mpi, el.ENCOUNTER_GRP_NUM
      |order by el.groupid, el.grp_mpi, el.ENCOUNTER_GRP_NUM, case when el.carearea is not null then 1 else 2 end
      |, coalesce(el.careareaendtime,el.careareastarttime) desc, el.careareastarttime desc
      |, case when encounteridtype = 'MASTER' then 1
      |when encounteridtype = 'ENCTR' then 2
      |when encounteridtype = 'ADD AS' then 3
      |when encounteridtype = 'ADD OT' then 4
      |when encounteridtype = 'ADD UN' then 5 else 6 end, el.encounterid) as carank
      |,row_number() over (partition by el.groupid, el.grp_mpi, el.ENCOUNTER_GRP_NUM
      |order by el.groupid, el.grp_mpi, el.ENCOUNTER_GRP_NUM, case when el.locallocationname is not null then 1 else 2 end
      |, coalesce(el.careareaendtime,el.careareastarttime) desc, el.careareastarttime desc
      |, case when encounteridtype = 'MASTER' then 1
      |when encounteridtype = 'ENCTR' then 2
      |when encounteridtype = 'ADD AS' then 3
      |when encounteridtype = 'ADD OT' then 4
      |when encounteridtype = 'ADD UN' then 5 else 6 end, el.encounterid)  as locrank
      |,row_number() over (partition by el.groupid, el.grp_mpi, el.ENCOUNTER_GRP_NUM
      |order by el.groupid, el.grp_mpi, el.ENCOUNTER_GRP_NUM, case when el.service is not null then 1 else 2 end
      |, coalesce(el.careareaendtime,el.careareastarttime) desc, el.careareastarttime desc
      |, case when encounteridtype = 'MASTER' then 1
      |when encounteridtype = 'ENCTR' then 2
      |when encounteridtype = 'ADD AS' then 3
      |when encounteridtype = 'ADD OT' then 4
      |when encounteridtype = 'ADD UN' then 5 else 6 end, el.encounterid) as svcrank
      |from
      |TEMP_ENCOUNTER_LOC el
      |where 1=1)
      |group by ENCOUNTER_GRP_NUM
    """.stripMargin

  override def dependsOn: Set[String] = Set("TEMP_ENCOUNTER_LOC")
}