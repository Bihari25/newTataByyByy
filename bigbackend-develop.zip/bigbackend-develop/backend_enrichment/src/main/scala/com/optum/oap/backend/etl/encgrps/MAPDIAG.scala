
package com.optum.oap.backend.etl.encgrps

import com.optum.oap.cdr.models.mapdiag
import com.optum.oap.sparkdataloader.QueryAndMetadata


object MAPDIAG extends QueryAndMetadata[mapdiag] {
  override def name: String = "MAPDIAG"

  override def sparkSql: String =
    """
      |SELECT
      |    dx.codetype,
      |    dx.mappeddiagnosis,
      |    cui,
      |    is_ambulatory,
      |    cnt
      |FROM
      |    (
      |        SELECT /*+ BROADCASTJOIN(md) */
      |            'CCS_CAT' AS codetype,
      |            ccs_cat AS mappeddiagnosis,
      |            CAST(COUNT(*) AS INT) AS cnt
      |        FROM
      |            temp_encounter_grp_ccs
      |        GROUP BY
      |            ccs_cat
      |    ) dx
      |    INNER JOIN map_diagnosis md ON ( dx.codetype = md.codetype
      |                                     AND dx.mappeddiagnosis LIKE md.mappedcode )
    """.stripMargin

  override def dependsOn: Set[String] = Set("MAP_DIAGNOSIS", "TEMP_ENCOUNTER_GRP_CCS")
}
