package com.optum.oap.backend.etl.patient_matching

import com.optum.oap.backend.loader.EnrichmentRunTimeVariables
import com.optum.oap.cdr.models.{pat_id_xwalk, patient_id}
import com.optum.oap.sparkdataloader.{RuntimeVariables, TableInfo, UserDefinedFunctionForDataLoader}
import org.apache.spark.sql.functions.{broadcast, lit, when}
import org.apache.spark.sql.{DataFrame, SparkSession}

/**
  * Creator: bishu
  * Date: 11/25/20
  */
object PATIENT_ID_XWALK_MAPPING extends TableInfo[patient_id] {

  override def dependsOn = Set("CDR_FE_PATIENT_ID", "PAT_ID_XWALK_TRANSITIVE", "ICPM_PATIENTID")

  override def createDataFrame(sparkSession: SparkSession,
                               loadedDependencies: Map[String, DataFrame],
                               udfMap: Map[String, UserDefinedFunctionForDataLoader],
                               runtimeVariables: RuntimeVariables): DataFrame = {
    import sparkSession.implicits._

    val patient_idIn = loadedDependencies("CDR_FE_PATIENT_ID").drop("row_source","modified_date").as[patient_id]
    val patientIdIcpm = loadedDependencies("ICPM_PATIENTID").as[patient_id]
    val patIdXwalk = loadedDependencies("PAT_ID_XWALK_TRANSITIVE").as[pat_id_xwalk]

    val patientIdunion = patient_idIn.unionByName(patientIdIcpm)

    val patIdXwalkMini = broadcast(patIdXwalk.select(
      $"groupid",
      $"old_id",
      $"new_id",
      $"client_ds_id"
    ))

    val grpid = EnrichmentRunTimeVariables(runtimeVariables).clientId

    val nonMrn = patientIdunion.as("p")
      .where($"p.idtype".notEqual(lit("MRN")))
      .select(
    $"p.groupid",
    $"p.client_ds_id",
    $"p.patientid",
    $"p.datasrc",
    $"p.idtype",
    $"idvalue",
    $"p.hgpid",
    $"p.id_subtype",
    $"p.grp_mpi"
    )

    val ab_where_clause = {
      if (grpid.trim().equalsIgnoreCase("H984216")) $"p.client_ds_id" === $"t.client_ds_id"
      else $"p.groupid" === $"t.groupid"
    }

    val mappedMrn = patientIdunion.as("p")
      .join(patIdXwalkMini.as("t"), $"p.idvalue" === $"t.old_id" && ab_where_clause, "left")
      .where($"p.idtype" === lit("MRN"))
      .withColumn("idvalue_mod",
        when($"p.idvalue" === $"t.old_id", $"t.new_id")
          .otherwise($"p.idvalue"))
      .select(
        $"p.groupid",
        $"p.client_ds_id",
        $"p.patientid",
        $"p.datasrc",
        $"p.idtype",
        $"idvalue_mod".as("idvalue"),
        $"p.hgpid",
        $"p.id_subtype",
        $"p.grp_mpi"
      )

    nonMrn.union(mappedMrn)
  }


}
