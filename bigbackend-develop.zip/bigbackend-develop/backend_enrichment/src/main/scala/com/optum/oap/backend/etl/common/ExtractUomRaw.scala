package com.optum.oap.backend.etl.common

import com.optum.oap.sparkdataloader.UserDefinedFunctionForDataLoader
import org.apache.spark.sql.SparkSession
import org.apache.spark.sql.expressions.UserDefinedFunction
import org.apache.spark.sql.functions.udf
import com.optum.oap.backend.etl.common.ExtractUom.extract_uom_common

object ExtractUomRaw extends UserDefinedFunctionForDataLoader {

  override def name: String = "extract_uom_raw"

  val extract_uom_raw_anon =

  /* Oracle's functions has the ability to return one variable when referenced in a sql query,
     while being able to return multiple variables when referenced inside of another function.
     This is enabled by using the "out" keyword for function parameters.
     extract_uom is one such function.
     It returns the v_uom variable  when referenced inside a sql query (nonnumeric_labs_localresult_25.sql)
     and returns both v_uom and p_raw_uom variables when referenced inside of other functions (extract_fns.extract_value).
     So, to enable this behaviour, two functions, extract_uom and extract_uom_raw are implemented to return
     v_uom and p_raw_uom respectively.
  */

    (p_txt: String) => {

      /*
          Functions in Oracle can handle nulls as valid inputs, even if they primarily operate on a different datatype.
          Those types of functions return nulls if they get null inputs.
          But, Scala methods can't handle nulls this way, so to mimic this behaviour, handling NullPointerException
       */

      try {

        var (v_uom, p_raw_uom) = extract_uom_common(p_txt)

        if (p_txt.contains(" per ")) { p_raw_uom = v_uom.replace("/", " per ") }

        p_raw_uom

      }
      catch {

        case _: Exception => null

      }
    }

  val extract_uom_raw: UserDefinedFunction = udf {

    extract_uom_raw_anon

  }

  override def registerMe(sparkSession: SparkSession): Unit = {
    sparkSession.udf.register(name, extract_uom_raw)
  }
}