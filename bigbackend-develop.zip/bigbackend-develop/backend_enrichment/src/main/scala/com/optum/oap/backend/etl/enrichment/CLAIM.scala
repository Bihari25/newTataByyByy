package com.optum.oap.backend.etl.enrichment

import com.optum.oap.backend.etl.common.MapMasterIds
import com.optum.oap.cdr.models.{claim, patient_mpi, zh_provider_master_xref}
import com.optum.oap.sparkdataloader.{RuntimeVariables, TableInfo, UserDefinedFunctionForDataLoader}
import org.apache.spark.sql.functions.broadcast
import org.apache.spark.sql.types.StringType
import org.apache.spark.sql.{DataFrame, SparkSession}
import org.slf4j.LoggerFactory

object CLAIM extends TableInfo[claim] {

  val log = LoggerFactory.getLogger(this.getClass)

  override def dependsOn = Set("PATIENT_MPI", "ZH_PROVIDER_MASTER_XREF", "CDR_FE_CLAIM", "ICPM_CLAIM")

  override def name = "CLAIM"

  override def saveDataFrameToParquet: Boolean = true

  override def partitions: Int = 32

  override def skipTable: Boolean = false

  override def ignoreExtraColumnsInDataFrame: Boolean = true

  override def createDataFrame(sparkSession: SparkSession,
                               loadedDependencies: Map[String, DataFrame],
                               udfMap: Map[String, UserDefinedFunctionForDataLoader],
                               runtimeVariables: RuntimeVariables): DataFrame = {
    import sparkSession.implicits._

    val claimIn = loadedDependencies("CDR_FE_CLAIM").drop("row_source", "modified_date").as[claim]
    val provXref = broadcast(loadedDependencies("ZH_PROVIDER_MASTER_XREF")).as[zh_provider_master_xref]
    val patXref = loadedDependencies("PATIENT_MPI").as[patient_mpi]
    val claimIcpm = loadedDependencies("ICPM_CLAIM").as[claim]

    val claimUnion = claimIn.unionByName(claimIcpm)
    val patientIdMap = MapMasterIds.mapPatientIds(claimUnion.toDF, patXref.toDF, false)

    MapMasterIds.mapProviderIds(patientIdMap.withColumn("hgpid", $"hgpid".cast(StringType)), provXref.toDF(), "claimproviderid", "claim_mstrprovid")
  }
}
