package com.optum.oap.backend.etl.enrichment

import com.optum.oap.backend.etl.common.MapMasterIds
import com.optum.oap.backend.loader.EnrichmentRunTimeVariables
import com.optum.oap.cdr.models.{benefit_plan_rollup, int_claim_member}
import com.optum.oap.sparkdataloader.{RuntimeVariables, TableInfo, UserDefinedFunctionForDataLoader}
import org.apache.spark.sql.expressions.Window
import org.apache.spark.sql.{DataFrame, SparkSession}
import org.slf4j.LoggerFactory
import org.apache.spark.sql.functions.{coalesce, length, regexp_replace, _}
import org.apache.spark.sql.types.DataTypes
import org.apache.spark.sql.types._

object BENEFIT_PLAN_ROLLUP extends TableInfo[benefit_plan_rollup] {

  private val log = LoggerFactory.getLogger(this.getClass)

  override def dependsOn = Set("INT_CLAIM_MEMBER", "CDR_FE_BENEFIT_PLAN_ROLLUP")

  override def name = "BENEFIT_PLAN_ROLLUP"

  override def createDataFrame(sparkSession: SparkSession,
                               loadedDependencies: Map[String, DataFrame],
                               udfMap: Map[String, UserDefinedFunctionForDataLoader],
                               runtimeVariables: RuntimeVariables): DataFrame = {

    import sparkSession.implicits._

    val cdrBenefitPlanRollup = loadedDependencies("CDR_FE_BENEFIT_PLAN_ROLLUP").as[benefit_plan_rollup]

    val intClaimMember = loadedDependencies("INT_CLAIM_MEMBER").as[int_claim_member]

    //Frontend Benefit plan Rollup table
    val cdrFeBenefitPlanRollup = cdrBenefitPlanRollup.select(
      $"GROUPID",
      $"CLIENT_DS_ID",
      $"DATASRC",
      $"BENEFIT_PLAN_CODE",
      $"BENEFIT_PLAN_DESC",
      $"BENEFIT_PLAN_LV2",
      $"BENEFIT_PLAN_LV2_DESC",
      $"BENEFIT_PLAN_LV1",
      $"BENEFIT_PLAN_LV1_DESC"
    )

    //Filtering Frontend Benefit plan Rollup table
    val cdrFeBenefitPlanRollup1 = cdrFeBenefitPlanRollup
      .dropDuplicates("BENEFIT_PLAN_CODE")
      .select("*")

    //getting the records from intclaimmember whose BENEFIT_PLAN_CODE is not in the Benefit planrollup
    val intClaimMember1 = intClaimMember.join(cdrFeBenefitPlanRollup1, intClaimMember("BENEFIT_PLAN_CODE") === cdrFeBenefitPlanRollup1("BENEFIT_PLAN_CODE"), "left")
      .select(intClaimMember("GROUPID"),
        intClaimMember("CLIENT_DS_ID"),
        lit("int_claim_member").cast(StringType).as("DATASRC"),
        intClaimMember("BENEFIT_PLAN_CODE").as("BENEFIT_PLAN_CODE"),
        substring(concat(lit("UNDEFINED ("), intClaimMember("BENEFIT_PLAN_CODE"), lit(")")), 1, 150).as("BENEFIT_PLAN_DESC"),
        cdrFeBenefitPlanRollup1("BENEFIT_PLAN_LV2"),
        cdrFeBenefitPlanRollup1("BENEFIT_PLAN_LV2_DESC"),
        cdrFeBenefitPlanRollup1("BENEFIT_PLAN_LV1"),
        cdrFeBenefitPlanRollup1("BENEFIT_PLAN_LV1_DESC")
      )
      .where((intClaimMember("BENEFIT_PLAN_CODE").isNotNull) && (length(intClaimMember("BENEFIT_PLAN_CODE")) <= 30) && (cdrFeBenefitPlanRollup1("BENEFIT_PLAN_CODE").isNull))
      .groupBy(intClaimMember("GROUPID"), $"BENEFIT_PLAN_CODE"
        , $"DATASRC", $"BENEFIT_PLAN_DESC", cdrFeBenefitPlanRollup1("BENEFIT_PLAN_LV2"),
        cdrFeBenefitPlanRollup1("BENEFIT_PLAN_LV2_DESC"),
        cdrFeBenefitPlanRollup1("BENEFIT_PLAN_LV1"),
        cdrFeBenefitPlanRollup1("BENEFIT_PLAN_LV1_DESC")
      )
      .agg(min($"CLIENT_DS_ID").as("CLIENT_DS_ID"))

    //union the missed records from intclaimmember and the original table
    val rollup1 = cdrFeBenefitPlanRollup.unionByName(intClaimMember1)

    //Applying the additional logic and loading to the backend table.
    val rollup = rollup1.select(
      $"GROUPID"
      , $"CLIENT_DS_ID"
      , $"DATASRC"
      , $"BENEFIT_PLAN_CODE"
      , substring(coalesce($"BENEFIT_PLAN_DESC", concat(lit("UNDEFINED ("), $"BENEFIT_PLAN_CODE", lit(")"))), 1, 150).as("BENEFIT_PLAN_DESC")
      , substring(coalesce($"BENEFIT_PLAN_LV2", concat(lit("3."), $"BENEFIT_PLAN_CODE")), 1, 30).as("BENEFIT_PLAN_LV2")
      , substring(when($"BENEFIT_PLAN_LV2".isNull, coalesce($"BENEFIT_PLAN_DESC", concat(lit("UNDEFINED ("), $"BENEFIT_PLAN_CODE", lit(")"))))
        .otherwise(coalesce($"BENEFIT_PLAN_LV2_DESC", concat(lit("UNDEFINED ("), $"BENEFIT_PLAN_LV2", lit(")")))), 1, 150)
        .as("BENEFIT_PLAN_LV2_DESC")
      , substring(when($"BENEFIT_PLAN_LV1".isNotNull, $"BENEFIT_PLAN_LV1")
        .otherwise(when($"BENEFIT_PLAN_LV2".isNotNull, concat(lit("2."), $"BENEFIT_PLAN_LV2"))
          .otherwise(concat(lit("3."), $"BENEFIT_PLAN_CODE"))), 1, 30).as("BENEFIT_PLAN_LV1")
      , substring(when($"BENEFIT_PLAN_LV1".isNull,
        when($"BENEFIT_PLAN_LV2".isNull, coalesce($"BENEFIT_PLAN_DESC", concat(lit("UNDEFINED ("), $"BENEFIT_PLAN_CODE", lit(")"))))
          .otherwise(coalesce($"BENEFIT_PLAN_LV2_DESC", concat(lit("UNDEFINED ("), $"BENEFIT_PLAN_LV2", lit(")")))))
        .otherwise(coalesce($"BENEFIT_PLAN_LV1_DESC", concat(lit("UNDEFINED ("), $"BENEFIT_PLAN_LV1", lit(")")))), 1, 150).as("BENEFIT_PLAN_LV1_DESC")
      , row_number().over(Window.partitionBy($"BENEFIT_PLAN_CODE")
        .orderBy(
          when($"BENEFIT_PLAN_DESC".isNotNull, lit(0)).otherwise(lit(1)),
          when($"BENEFIT_PLAN_LV2".isNotNull, lit(0)).otherwise(lit(1)),
          when($"BENEFIT_PLAN_LV1".isNotNull, lit(0)).otherwise(lit(1)),
          $"BENEFIT_PLAN_DESC", $"BENEFIT_PLAN_LV2", $"BENEFIT_PLAN_LV1"
        )).as("rn")
    )
      .where((rollup1("BENEFIT_PLAN_CODE").isNotNull) && (length(rollup1("BENEFIT_PLAN_CODE")) <= 30) && ($"rn" === 1))
      .drop($"rn")
    rollup.toDF()

  }
}