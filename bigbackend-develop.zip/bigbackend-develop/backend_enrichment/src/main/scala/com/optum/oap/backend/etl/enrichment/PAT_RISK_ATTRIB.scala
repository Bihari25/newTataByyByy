package com.optum.oap.backend.etl.enrichment

import com.optum.oap.backend.etl.common.MapMasterIds
import com.optum.oap.backend.loader.EnrichmentRunTimeVariables
import com.optum.oap.cdr.models.{map_predicate_values, pat_risk_attrib, patient_mpi, zh_provider_master_xref}
import com.optum.oap.sparkdataloader.{RuntimeVariables, TableInfo, UserDefinedFunctionForDataLoader}
import org.apache.spark.sql.functions._
import org.apache.spark.sql.{DataFrame, SparkSession}
import org.slf4j.LoggerFactory

object PAT_RISK_ATTRIB extends TableInfo[pat_risk_attrib] with INT_CLAIM_CLEANUP {

  val log = LoggerFactory.getLogger(this.getClass)

  override def dependsOn = Set("PATIENT_MPI", "ZH_PROVIDER_MASTER_XREF", "CDR_FE_PAT_RISK_ATTRIB", "MAP_PREDICATE_VALUES")

  override def name = "PAT_RISK_ATTRIB"

  override def saveDataFrameToParquet: Boolean = true

  override def partitions: Int = 32

  override def skipTable: Boolean = false

  override def ignoreExtraColumnsInDataFrame: Boolean = true

  override def regexReplaceColumns: Set[String] = Set("contract_id", "at_risk_status", "risk_type")

  override def createDataFrame(sparkSession: SparkSession,
                               loadedDependencies: Map[String, DataFrame],
                               udfMap: Map[String, UserDefinedFunctionForDataLoader],
                               runtimeVariables: RuntimeVariables): DataFrame = {
    import sparkSession.implicits._

    val pat_risk_attribIn = loadedDependencies("CDR_FE_PAT_RISK_ATTRIB")
    val mapPredicateValues = loadedDependencies("MAP_PREDICATE_VALUES").as[map_predicate_values]
    val groupId = runtimeVariables.asInstanceOf[EnrichmentRunTimeVariables].clientId
    val patRiskAttrib = cleanUp(groupId, mapPredicateValues.toDF(), pat_risk_attribIn)

    val provXref = broadcast(loadedDependencies("ZH_PROVIDER_MASTER_XREF")).as[zh_provider_master_xref]
    val patXref = loadedDependencies("PATIENT_MPI").as[patient_mpi]

    MapMasterIds.mapProviderIds(MapMasterIds.mapPatientIds(patRiskAttrib.toDF, patXref.toDF, false), provXref.toDF(), "providerid", "mstrprovid")
  }
}
