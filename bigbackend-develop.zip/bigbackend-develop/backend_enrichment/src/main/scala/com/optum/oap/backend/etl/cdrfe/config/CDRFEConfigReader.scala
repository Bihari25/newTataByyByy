package com.optum.oap.backend.etl.cdrfe.config

import com.optum.oap.backend.loader.EnrichmentRunTimeVariables

trait CDRFEConfigReader {

  val enrichmentRunTimeVariables: EnrichmentRunTimeVariables

  def getCDRFEConfg: Seq[cdrfe_data_source] = Seq.empty
}

case class cdrfe_data_source(active: Boolean, cds_id: Int, cds_name: String, framework: String)
