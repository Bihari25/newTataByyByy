package com.optum.oap.backend.etl.common

import java.sql.Timestamp
import java.text.SimpleDateFormat

import scala.util.Try


object CommonFunctions {
  // This is a function that doesn't use column as input.
  // This function mimics the safeToDate functionality from CDR FE.
  val safeToDate = {
    (dateString: String, dateFormat: String, dateLength: Integer) => {
      if (dateString == null)
        null
      else {
        try {
          val vDateLength: Integer = if (dateLength == null) dateFormat.toUpperCase().replace("HH24", "HH").length else dateLength

          val dateFormatUpdated = dateFormat.replace("HH24", "HH")

          if (vDateLength == 0) {
            //Adjust the date so that even short dates can also be converted
            val dateFormatList = dateFormatUpdated.split("[./-]")
            val dateStringList = dateString.split("[./-]")

            for (ind <- 0 until (dateFormatList.length)) {

              //DateString is padded with 0's in such a way that it should match with the given dateFormat
              if (dateFormatList(ind).length < dateStringList(ind).length) {
                null
              }
              else if (dateFormatList(ind).length > dateStringList(ind).length) {
                dateStringList(ind).reverse.padTo(dateFormatList(ind).length - dateStringList(ind).length, "0").reverse
              }
            }
            val format = new SimpleDateFormat(dateFormatList.mkString("/"))
            format.setLenient(false)
            Try(new Timestamp(format.parse(dateStringList.mkString("/")).getTime)).toOption
          }
          else {
            val format = new SimpleDateFormat(dateFormatUpdated)
            format.setLenient(false)
            //Either Pad the dateString or take a substring out of it, so that the modifiedDateString's length must be equal to dateLength
            val modifiedDateString =
              vDateLength match {
                case x if (x > dateString.length) => dateString.padTo(vDateLength, "0").mkString("")
                case y if (y < dateString.length) => dateString.substring(0, vDateLength)
                case _ => dateString
              }
            Try(new Timestamp(format.parse(modifiedDateString).getTime)).toOption
          }
        } catch {
          case ex: Exception => null
        } //If invalid dateString is found, return null
      }
    }
  }
}
