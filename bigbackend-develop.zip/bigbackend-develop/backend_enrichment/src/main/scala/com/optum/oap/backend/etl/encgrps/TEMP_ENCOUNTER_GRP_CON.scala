package com.optum.oap.backend.etl.encgrps

import com.optum.oap.backend.cdrTempModel.{temp_encounter_grp_ccs, temp_encounter_grp_con, temp_encounter_prindx, temp_encounter_prinpx}
import com.optum.oap.cdr.models.{diag_ccs_encgrp, diag_icd_encgrp, map_procedure, proc_icd_encgrp, ref_map_ccs_icdx_px}
import com.optum.oap.sparkdataloader.{RuntimeVariables, TableInfo, UserDefinedFunctionForDataLoader}
import org.apache.spark.sql.{DataFrame, SparkSession}
import org.apache.spark.sql.functions.{concat, when, max, lit, regexp_replace, broadcast}

object TEMP_ENCOUNTER_GRP_CON extends TableInfo[temp_encounter_grp_con] {
  override def dependsOn: Set[String] =
    Set("REF_MAP_CCS_ICDX_PX","MAP_PROCEDURE","DIAG_ICD_ENCGRP","TEMP_ENCOUNTER_PRINDX","PROC_ICD_ENCGRP","DIAG_CCS_ENCGRP","TEMP_ENCOUNTER_GRP_CCS", "TEMP_ENCOUNTER_PRINPX")
  override def name: String = "TEMP_ENCOUNTER_GRP_CON"

  override def createDataFrame(sparkSession: SparkSession, loadedDependencies: Map[String, DataFrame], udfMap: Map[String, UserDefinedFunctionForDataLoader], runtimeVariables: RuntimeVariables): DataFrame = {
    import sparkSession.implicits._

    val refMapCcsIcdxPx = broadcast(loadedDependencies("REF_MAP_CCS_ICDX_PX")).as[ref_map_ccs_icdx_px]
    val mapProcedure = broadcast(loadedDependencies("MAP_PROCEDURE")).as[map_procedure]
    val diagIcdEncgrp = loadedDependencies("DIAG_ICD_ENCGRP").as[diag_icd_encgrp]
    val tempEncounterPrindx = loadedDependencies("TEMP_ENCOUNTER_PRINDX").as[temp_encounter_prindx]
    val procIcdEncgrp = loadedDependencies("PROC_ICD_ENCGRP").as[proc_icd_encgrp]
    val diagCcsEncgrp = loadedDependencies("DIAG_CCS_ENCGRP").as[diag_ccs_encgrp]
    val tempEncounterGrpCcs = loadedDependencies("TEMP_ENCOUNTER_GRP_CCS").as[temp_encounter_grp_ccs]
    val tempEncounterPrinpx = loadedDependencies("TEMP_ENCOUNTER_PRINPX").as[temp_encounter_prinpx]

    val df1 = tempEncounterGrpCcs.as("ccs")
      .join(diagCcsEncgrp.as("md"), $"ccs.ccs_cat" === $"md.mappeddiagnosis", "INNER")
      .where($"md.codetype" === "CCS_CAT")
      .groupBy($"groupid", $"grp_mpi", $"encounter_grp_num", concat($"md.codetype", lit("dx")).as("codetype"), $"cui")
      .agg(max($"primarydiagnosis").as("prinflag"))
      .select(
      $"groupid",
      $"grp_mpi",
      $"encounter_grp_num",
      concat($"codetype", lit("dx")).as("codetype"),
      $"cui".as("condcui"),
      $"prinflag"
    )

    val df2 = tempEncounterPrindx.as("dx")
      .join(diagIcdEncgrp.as("md"), $"dx.CODETYPE" === $"md.CODETYPE" && $"dx.mappeddiagnosis" === $"md.mappeddiagnosis", "INNER")
      .where($"md.codetype" === "ICD9" || $"md.codetype" === "ICD10")
      .groupBy($"groupid", $"grp_mpi", $"encounter_grp_num", concat($"md.codetype", lit("dx")).as("codetype"), $"cui")
      .agg(max($"primarydiagnosis").as("prinflag"))
      .select(
        $"groupid",
        $"grp_mpi",
        $"encounter_grp_num",
        concat($"codetype", lit("dx")).as("codetype"),
        $"cui".as("condcui"),
        $"prinflag"
      )

    val df3 = tempEncounterPrinpx.as("px")
      .join(procIcdEncgrp.as("md"), $"px.CODETYPE" === $"md.CODETYPE" && $"px.mappedcode" === $"md.mappedcode")
      .where($"md.codetype" === "ICD9" || $"md.codetype" === "ICD10")
      .groupBy($"groupid", $"grp_mpi", $"encounter_grp_num", concat($"md.codetype", lit("dx")).as("codetype"), $"cui")
      .agg(max(when($"localprincipleindicator" === "Y", 1).otherwise(0)).as("prinflag"))
      .select(
        $"groupid",
        $"grp_mpi",
        $"encounter_grp_num",
        concat($"codetype", lit("dx")).as("codetype"),
        $"cui".as("condcui"),
        $"prinflag"
      )

    val df4 = tempEncounterPrinpx.as("px")
      .join(refMapCcsIcdxPx.as("cd"), regexp_replace($"px.mappedcode", "\\.", "") ===  regexp_replace($"cd.icd_cm_code", "\\.", "") && $"px.icd_ver" === $"cd.icd_version", "INNER")
      .join(mapProcedure.as("md"), $"cd.ccs_category" === $"md.mappedcode", "INNER")
      .where($"md.codetype" === "CCS_CAT")
      .groupBy($"groupid", $"grp_mpi", $"encounter_grp_num", concat($"md.codetype", lit("dx")).as("codetype"), $"cui")
      .agg(max(when($"localprincipleindicator" === "Y", 1).otherwise(0)).as("prinflag"))
      .select(
        $"groupid",
        $"grp_mpi",
        $"encounter_grp_num",
        concat($"codetype", lit("dx")).as("codetype"),
        $"cui".as("condcui"),
        $"prinflag"
      )

    val finalDf = df1
      .union(df2)
      .union(df3)
      .union(df4)
      .groupBy($"ENCOUNTER_GRP_NUM")
      .agg(max(when($"condcui" === "CH001676", 1).otherwise(0)).as("cond1676"),
          max(when($"condcui" === "CH001676" && $"PRINFLAG" === 1, 1).otherwise(0)).as("cond1676p"),
          max(when($"condcui" === "CH001680", 1).otherwise(0)).as("cond1680"),
          max(when($"condcui" === "CH001662", 1).otherwise(0)).as("cond1662"),
          max(when($"condcui" === "CH001662" && $"PRINFLAG" === 1, 1).otherwise(0)).as("cond1662p"),
          max(when($"condcui" === "CH001681", 1).otherwise(0)).as("cond1681"),
          max(when($"condcui" === "CH001682", 1).otherwise(0)).as("cond1682"),
          max(when($"condcui" === "CH001679" && $"PRINFLAG" === 1, 1).otherwise(0)).as("cond1679p"))
      .select(
        $"ENCOUNTER_GRP_NUM",
        $"cond1676",
        $"cond1676p",
        $"cond1680",
        $"cond1662",
        $"cond1662p",
        $"cond1681",
        $"cond1682",
        $"cond1679p"
      )

    finalDf
  }

}