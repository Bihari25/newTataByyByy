package com.optum.oap.backend.etl.patient_matching.quality_gates

import com.optum.oap.backend.cdrTempModel.qgate_patient_id_status
import com.optum.oap.backend.etl.common.CDRConstants
import com.optum.oap.cdr.models.{qgate_new_evidence_patient_id, qgate_patient_id_filter, qgate_patient_id_suspects}
import com.optum.oap.sparkdataloader.{RuntimeVariables, TableInfo, UserDefinedFunctionForDataLoader}
import org.apache.spark.sql.functions.lit
import org.apache.spark.sql.{DataFrame, Dataset, SparkSession}

object QGATE_PATIENT_ID_FILTER extends TableInfo[qgate_patient_id_filter] {
  override def dependsOn = Set("QGATE_PATIENT_ID_SUSPECTS", "QGATE_PATIENT_ID_STATUS", "QGATE_NEW_EVIDENCE_PATIENT_ID")
  override def name = "QGATE_PATIENT_ID_FILTER"

  override def createDataFrame(sparkSession: SparkSession,
                               loadedDependencies: Map[String, DataFrame],
                               udfMap: Map[String, UserDefinedFunctionForDataLoader],
                               runtimeVariables: RuntimeVariables): DataFrame = {
    import sparkSession.implicits._

    val status = loadedDependencies("QGATE_PATIENT_ID_STATUS").drop("row_source","modified_date").as[qgate_patient_id_status]
    val suspects = loadedDependencies("QGATE_PATIENT_ID_SUSPECTS").drop("row_source","modified_date").as[qgate_patient_id_suspects]
    val newEvidence = loadedDependencies("QGATE_NEW_EVIDENCE_PATIENT_ID").drop("row_source","modified_date").as[qgate_new_evidence_patient_id]

    val badPatients = previousBadPatients(sparkSession, status)
    val suspiciousButPreviouslyClearedNoNewEvidencePatients = suspiciousButPreviouslyClearedWithoutNewEvidencePatients(sparkSession, suspects, status, newEvidence, badPatients)

    badPatients.union(suspiciousButPreviouslyClearedNoNewEvidencePatients)
      .select($"groupid", $"client_ds_id", $"patientid", $"status_cd")
  }

  private def previousBadPatients(sparkSession: SparkSession, status: Dataset[qgate_patient_id_status]): DataFrame = {
    import sparkSession.implicits._
    status.as("prev").where(
      $"status_cd".isInCollection(CDRConstants.CLEARED_AND_REFFERED_2_CLIENT_STATUS_IDS)
    )
    .select($"groupid", $"patientid", $"client_ds_id", $"status_cd")
  }

  private def suspiciousButPreviouslyClearedWithoutNewEvidencePatients(sparkSession: SparkSession,
                                                                       suspects: Dataset[qgate_patient_id_suspects],
                                                                       status: Dataset[qgate_patient_id_status],
                                                                       newEvidence: Dataset[qgate_new_evidence_patient_id],
                                                                       previouslyBadPatients: DataFrame): DataFrame = {
    import sparkSession.implicits._
    val suspectIds = suspects.select($"groupid", $"patientid", $"client_ds_id")
    val statusIds = status.select($"groupid", $"patientid", $"client_ds_id").where($"status_cd" === lit("C"))
    val newEvidenceIds = newEvidence.select($"groupid", $"patientid", $"client_ds_id")

    suspectIds
      .except(statusIds)
      .except(newEvidenceIds).as("v")
      .join(previouslyBadPatients.as("f"), Seq("patientid", "client_ds_id", "groupid"), "left")
      .where($"f.groupid".isNull)
      .select($"v.groupid", $"v.patientid", $"v.client_ds_id", lit("S").as("status_cd"))
  }
}
