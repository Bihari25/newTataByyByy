package com.optum.oap.backend.etl.enrichment

import com.optum.oap.backend.cdrTempModel.{ref_cmsnpi_partial}
import com.optum.oap.cdr.models._
import com.optum.oap.sparkdataloader.{RuntimeVariables, TableInfo, UserDefinedFunctionForDataLoader}
import org.apache.spark.sql.expressions.Window
import org.apache.spark.sql.functions._
import org.apache.spark.sql.types.DataTypes
import org.apache.spark.sql.{DataFrame, SparkSession}
import org.slf4j.LoggerFactory
import com.optum.oap.backend.etl.common.Functions.mpvList
import com.optum.oap.backend.loader.EnrichmentRunTimeVariables

object ICPM_PATIENT_ATTRIBUTE extends TableInfo[patient_attribute] {

  private val log = LoggerFactory.getLogger(this.getClass)

  override def dependsOn = Set("INT_CLAIM_MEMBER")

  override def name = "ICPM_PATIENT_ATTRIBUTE"

  override def createDataFrame(sparkSession: SparkSession,
                               loadedDependencies: Map[String, DataFrame],
                               udfMap: Map[String, UserDefinedFunctionForDataLoader],
                               runtimeVariables: RuntimeVariables): DataFrame = {
    import sparkSession.implicits._

    val intClaimMemberIn = loadedDependencies("INT_CLAIM_MEMBER").as[int_claim_member]

    val provDf1 = intClaimMemberIn
      .select(
        $"groupid",
        $"client_ds_id",
        lit("int_claim_member").as("datasrc"),
        $"member_id".as("patientid"),
        $"member_eff_date".as("eff_date"),
        $"member_end_date".as("end_date"),
        $"contract_id",
        lit(null).cast(DataTypes.StringType).as("grp_mpi"),
        lit(null).cast(DataTypes.LongType).as("hgpid"),
        expr("stack(19,ii_cust_attr_1, 'CH004024', ii_cust_attr_2, 'CH004025', ii_cust_attr_3, 'CH004026', ii_cust_attr_4, 'CH004027'," +
          "ii_cust_attr_5, 'CH004028', ii_cust_attr_6, 'CH004029', ii_cust_attr_7, 'CH004030', ii_cust_attr_8, 'CH004031', ii_cust_attr_9, 'CH004032', ii_cust_attr_10," +
          "'CH004033', ii_cust_attr_11, 'CH004034', ii_cust_attr_12, 'CH004035', ii_cust_attr_13, 'CH004036', ii_cust_attr_14, 'CH004037', ii_cust_attr_15, 'CH004038'," +
          " ii_mem_userdef_1, 'CH004044', ii_mem_userdef_2, 'CH004045', ii_mem_userdef_3, 'CH004046', ii_mem_userdef_4, 'CH004047') as (attribute_value,attribute_type_cui)"))
      .where($"attribute_value".isNotNull && $"member_id".isNotNull).distinct()

    val provDf2 = intClaimMemberIn
      .select(
        $"groupid",
        $"client_ds_id",
        lit("int_claim_member").as("datasrc"),
        $"member_id".as("patientid"),
        $"member_eff_date".as("eff_date"),
        $"member_end_date".as("end_date"),
        $"contract_id",
        lit(null).cast(DataTypes.StringType).as("grp_mpi"),
        lit(null).cast(DataTypes.LongType).as("hgpid"),
        expr("stack(5,ii_cust_attr_16, 'CH004039', ii_cust_attr_17, 'CH004040', ii_cust_attr_18, 'CH004041', ii_cust_attr_19, 'CH004042'," +
          "ii_cust_attr_20, 'CH004043') as (attribute_value,attribute_type_cui)")).where($"attribute_value".isNotNull && $"member_id".isNotNull).distinct()


    provDf1.unionByName(provDf2)

  }
}
