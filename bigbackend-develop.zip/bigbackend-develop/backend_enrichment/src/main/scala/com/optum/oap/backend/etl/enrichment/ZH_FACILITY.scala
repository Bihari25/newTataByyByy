package com.optum.oap.backend.etl.enrichment

import com.optum.oap.cdr.models.zh_facility
import com.optum.oap.sparkdataloader.{RuntimeVariables, TableInfo, UserDefinedFunctionForDataLoader}
import org.apache.spark.sql.functions._
import org.apache.spark.sql.{DataFrame, SparkSession}
import org.slf4j.LoggerFactory

object ZH_FACILITY extends TableInfo[zh_facility] {

  private val log = LoggerFactory.getLogger(this.getClass)

  override def dependsOn = Set("CDR_FE_ZH_FACILITY", "ICPM_FACILITY")

  override def name = "ZH_FACILITY"

  override def createDataFrame(sparkSession: SparkSession,
                               loadedDependencies: Map[String, DataFrame],
                               udfMap: Map[String, UserDefinedFunctionForDataLoader],
                               runtimeVariables: RuntimeVariables): DataFrame = {
    import sparkSession.implicits._

    val zhFacilityIn = loadedDependencies("CDR_FE_ZH_FACILITY").drop("row_source","modified_date").as[zh_facility]

    //Load df from ICPM ZH_FACILITY
    val icpmZhFacility = loadedDependencies("ICPM_FACILITY").as[zh_facility]

    //Union Facility dictionary data coming from FE & ICPM
    zhFacilityIn.unionByName(icpmZhFacility)
        .withColumnRenamed("facilityid", "facilityid_old")
        .withColumnRenamed("facilityname", "facilityname_old")
        .select($"*"
          ,trim(regexp_replace($"facilityid_old", "[^A-Z-a-z0-9 .;!()*-_<>&#%$~\"{}\t]", "")).as("facilityid")
          ,trim(regexp_replace($"facilityname_old", "[^A-Z-a-z0-9 .;!()*-_<>&#%$~\"{}\t]", "")).as("facilityname")
        ).drop("facilityid_old", "facilityname_old")
  }

}