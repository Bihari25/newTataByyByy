
package com.optum.oap.backend.etl.encgrps

import com.optum.oap.cdr.models.encounter_encounter_grp
import com.optum.oap.sparkdataloader.QueryAndMetadata

object ENCOUNTER_ENCOUNTER_GRP extends QueryAndMetadata[encounter_encounter_grp] {
  override def name: String = "ENCOUNTER_ENCOUNTER_GRP"

  override def partitions: Int = 128

  override def sparkSql: String =
    """
      |select  distinct eeg.GROUPID,
      |        eeg.ENCOUNTER_GRP_NUM,
      |        eeg.grp_mpi,
      |        eeg.client_ds_id,
      |        eeg.ENCOUNTERID,
      |        eeg.PATIENTTYPE,
      |        trim(eeg.ENCOUNTERIDTYPE) as ENCOUNTERIDTYPE
      |    from TEMP_EEG eeg
    """.stripMargin

  override def dependsOn: Set[String] = Set("TEMP_EEG")
}
