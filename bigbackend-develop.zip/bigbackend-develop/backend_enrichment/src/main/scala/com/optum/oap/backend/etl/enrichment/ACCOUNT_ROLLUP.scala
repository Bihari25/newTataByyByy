package com.optum.oap.backend.etl.enrichment

import com.optum.oap.backend.etl.common.MapMasterIds
import com.optum.oap.backend.loader.EnrichmentRunTimeVariables
import com.optum.oap.cdr.models.{account_rollup, int_claim_member}
import com.optum.oap.sparkdataloader.{RuntimeVariables, TableInfo, UserDefinedFunctionForDataLoader}
import org.apache.spark.sql.expressions.Window
import org.apache.spark.sql.{DataFrame, SparkSession}
import org.slf4j.LoggerFactory
import org.apache.spark.sql.functions.{coalesce, length, regexp_replace, _}
import org.apache.spark.sql.types.DataTypes
import org.apache.spark.sql.types._

object ACCOUNT_ROLLUP extends TableInfo[account_rollup] {

  private val log = LoggerFactory.getLogger(this.getClass)

  override def dependsOn = Set("CDR_FE_ACCOUNT_ROLLUP", "INT_CLAIM_MEMBER")

  override def name = "ACCOUNT_ROLLUP"

  override def createDataFrame(sparkSession: SparkSession,
                               loadedDependencies: Map[String, DataFrame],
                               udfMap: Map[String, UserDefinedFunctionForDataLoader],
                               runtimeVariables: RuntimeVariables): DataFrame = {

    import sparkSession.implicits._

    val cdrAccountRollup = loadedDependencies("CDR_FE_ACCOUNT_ROLLUP").as[account_rollup]

    val intClaimMember = loadedDependencies("INT_CLAIM_MEMBER").as[int_claim_member]

    //Frontend Account Rollup table
    val cdrFeAccountRollup1 = cdrAccountRollup.select(
      $"GROUPID",
      $"CLIENT_DS_ID",
      $"DATASRC",
      $"EMP_ACCT_ID",
      $"ACCOUNT_DESC",
      $"ACCOUNT_LV2",
      $"ACCOUNT_LV2_DESC",
      $"ACCOUNT_LV1",
      $"ACCOUNT_LV1_DESC",
      $"BIZ_SEGMENT",
      $"INDUSTRY"
    )

    //Filtering Frontend Account Rollup table
    val cdrFeAccountRollup = cdrFeAccountRollup1
      .dropDuplicates("EMP_ACCT_ID")
      .select("*")
      .where($"EMP_ACCT_ID" isNotNull)

    //getting the records from intclaimmember whose emp_acct_id is not in the accountrollup
    val intClaimMember2 = intClaimMember.join(cdrFeAccountRollup, regexp_replace(intClaimMember("EMP_ACCT_ID"), "'", "") === cdrFeAccountRollup("EMP_ACCT_ID"), "left")
      .select(intClaimMember("GROUPID"),
        intClaimMember("CLIENT_DS_ID"),
        lit("int_claim_member").cast(StringType).as("DATASRC"),
        regexp_replace(intClaimMember("EMP_ACCT_ID"), "'", "").as("EMP_ACCT_ID"),
        concat(lit("UNDEFINED ("), regexp_replace(intClaimMember("EMP_ACCT_ID"), "'", ""), lit(")")).as("ACCOUNT_DESC"),
        cdrFeAccountRollup("ACCOUNT_LV2"),
        cdrFeAccountRollup("ACCOUNT_LV2_DESC"),
        cdrFeAccountRollup("ACCOUNT_LV1"),
        cdrFeAccountRollup("ACCOUNT_LV1_DESC"),
        cdrFeAccountRollup("BIZ_SEGMENT"),
        cdrFeAccountRollup("INDUSTRY")
      )
      .where((intClaimMember("EMP_ACCT_ID") isNotNull) && (length(regexp_replace(intClaimMember("EMP_ACCT_ID"), "'", "")) <= 30) && (cdrFeAccountRollup("emp_acct_id") isNull))
      .groupBy(intClaimMember("GROUPID"), $"EMP_ACCT_ID"
        , $"DATASRC", $"ACCOUNT_DESC", cdrFeAccountRollup("ACCOUNT_LV2"),
        cdrFeAccountRollup("ACCOUNT_LV2_DESC"),
        cdrFeAccountRollup("ACCOUNT_LV1"),
        cdrFeAccountRollup("ACCOUNT_LV1_DESC"),
        cdrFeAccountRollup("BIZ_SEGMENT"),
        cdrFeAccountRollup("INDUSTRY")
      )
      .agg(min($"CLIENT_DS_ID").as("CLIENT_DS_ID"))

    //union the missed records from intclaimmember and the original table
    val rollup1 = cdrFeAccountRollup1.unionByName(intClaimMember2)

    //Applying the additional logic and loading to the backend table.
    val rollup = rollup1.select(
      $"groupid"
      , $"client_ds_id"
      , $"DATASRC"
      , regexp_replace(rollup1("EMP_ACCT_ID"), "'", "").as("EMP_ACCT_ID")
      , substring(coalesce($"ACCOUNT_DESC", concat(lit("UNDEFINED ("), regexp_replace(rollup1("EMP_ACCT_ID"), "'", ""), lit(")"))), 1, 150).as("ACCOUNT_DESC")
      , substring(coalesce($"ACCOUNT_LV2", concat(lit("3."), regexp_replace(rollup1("EMP_ACCT_ID"), "'", ""))), 1, 30).as("ACCOUNT_LV2")
      , substring(when($"ACCOUNT_LV2".isNull, coalesce($"ACCOUNT_LV2", concat(lit("UNDEFINED ("), regexp_replace(rollup1("EMP_ACCT_ID"), "'", ""), lit(")"))))
        .otherwise(coalesce($"ACCOUNT_LV2_DESC", concat(lit("UNDEFINED ("), $"ACCOUNT_LV2", lit(")")))), 1, 150)
        .as("ACCOUNT_LV2_DESC")
      , substring(when($"ACCOUNT_LV1".isNotNull, $"ACCOUNT_LV1")
        .otherwise(when($"ACCOUNT_LV2".isNotNull, concat(lit("2."), $"ACCOUNT_LV2"))
          .otherwise(concat(lit("3."), regexp_replace(rollup1("EMP_ACCT_ID"), "'", "")))), 1, 30).as("ACCOUNT_LV1")
      , substring(when($"ACCOUNT_LV1".isNull,
        when($"ACCOUNT_LV2".isNull, coalesce($"ACCOUNT_DESC", concat(lit("UNDEFINED ("), regexp_replace(rollup1("EMP_ACCT_ID"), "'", ""), lit(")"))))
          .otherwise(coalesce($"ACCOUNT_LV2_DESC", concat(lit("UNDEFINED ("), $"ACCOUNT_LV2", lit(")")))))
        .otherwise(coalesce($"ACCOUNT_LV1_DESC", concat(lit("UNDEFINED ("), $"ACCOUNT_LV1", lit(")")))), 1, 150).as("ACCOUNT_LV1_DESC")
      , when(length($"BIZ_SEGMENT") > 30, null).otherwise($"BIZ_SEGMENT").as("BIZ_SEGMENT")
      , $"INDUSTRY".cast(IntegerType)
      , row_number().over(Window.partitionBy(regexp_replace(rollup1("EMP_ACCT_ID"), "'", ""))
        .orderBy(
          when($"ACCOUNT_DESC".isNotNull, lit(0)).otherwise(lit(1)),
          when($"ACCOUNT_LV2".isNotNull, lit(0)).otherwise(lit(1)),
          when($"ACCOUNT_LV1".isNotNull, lit(0)).otherwise(lit(1)),
          $"ACCOUNT_DESC",
          $"ACCOUNT_LV2",
          $"ACCOUNT_LV1"
        )).as("rn")
    )
      .where((rollup1("EMP_ACCT_ID") isNotNull) && (length(regexp_replace(rollup1("EMP_ACCT_ID"), "'", "")) <= 30) && ($"rn" === 1))
      .drop($"rn")

    rollup.toDF()
  }
}

