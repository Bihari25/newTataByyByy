package com.optum.oap.backend.etl.enrichment

import com.optum.oap.backend.etl.common.SafeToDateLength.safeToDateLength
import com.optum.oap.cdr.models.{int_claim_labresult, int_claim_member, int_claim_pharm, patient_id}
import com.optum.oap.sparkdataloader.{RuntimeVariables, TableInfo, UserDefinedFunctionForDataLoader}
import org.apache.spark.sql.expressions.Window
import org.apache.spark.sql.functions.{when, _}
import org.apache.spark.sql.types.{LongType, StringType}
import org.apache.spark.sql.{DataFrame, SparkSession}
import org.apache.spark.sql.functions.split
import org.slf4j.LoggerFactory

object ICPM_PATIENTID extends TableInfo[patient_id] {

  val log = LoggerFactory.getLogger(this.getClass)

  override def dependsOn = Set("INT_CLAIM_MEMBER", "INT_CLAIM_PHARM", "INT_CLAIM_MEDICAL", "INT_CLAIM_LABRESULT")

  override def name = "ICPM_PATIENTID"


  override def createDataFrame(sparkSession: SparkSession,
                               loadedDependencies: Map[String, DataFrame],
                               udfMap: Map[String, UserDefinedFunctionForDataLoader],
                               runtimeVariables: RuntimeVariables): DataFrame = {
    import sparkSession.implicits._

    def validateSsnUdf = udf((ssn: String) => validateSSN(ssn))

    def evalMbiHicnUdf = udf((idVal: String) => evalMbiHicn(idVal))

    val intClaimMemberIn = loadedDependencies("INT_CLAIM_MEMBER").as[int_claim_member]
    val intClaimMedicalIn = loadedDependencies("INT_CLAIM_MEDICAL")
    val intClaimPharmIn = loadedDependencies("INT_CLAIM_PHARM").as[int_claim_pharm]
    val intClaimLabResultIn = loadedDependencies("INT_CLAIM_LABRESULT").as[int_claim_labresult]

    val claimPatientid = intClaimMemberIn.select(
      $"groupid"
      , lit("int_claim_member").as("datasrc")
      , $"client_ds_id"
      , lit(null).cast(StringType).as("idtype")
      , lit(null).cast(StringType).as("idvalue")
      , $"member_id".as("patientid")
      , lit(1).as("source")
      , coalesce($"member_eff_date", safeToDateLength($"eligibile_member_month", lit("yyyyMM"), lit(0))).as("lastupdateddate")
      , lit("n").as("incl_val")
    ).unionByName(intClaimMedicalIn.select(
      $"groupid"
      , lit("int_claim_medical").as("datasrc")
      , $"client_ds_id"
      , lit("SSN").as("idtype")
      , regexp_replace($"member_ssn", "-", "").cast(StringType).as("idvalue")
      , $"member_id".as("patientid")
      , lit(2).as("source")
      , coalesce($"member_eff_date", $"service_date").as("lastupdateddate")
      , validateSsnUdf($"member_ssn").as("incl_val"))
    ).unionByName(intClaimPharmIn.select(
      $"groupid"
      , lit("int_claim_pharm").as("datasrc")
      , $"client_ds_id"
      , lit("SSN").as("idtype")
      , regexp_replace($"member_ssn", "-", "").cast(StringType).as("idvalue")
      , $"member_id".as("patientid")
      , lit(3).as("source")
      , coalesce($"member_eff_date", $"service_date").as("lastupdateddate")
      , validateSsnUdf($"member_ssn").as("incl_val"))
    ).unionByName(intClaimLabResultIn.select(
      $"groupid"
      , lit("int_claim_labresult").as("datasrc")
      , $"client_ds_id"
      , lit("SSN").as("idtype")
      , regexp_replace($"member_ssn", "-", "").cast(StringType).as("idvalue")
      , $"member_id".as("patientid")
      , lit(4).as("source")
      , coalesce($"member_eff_date", $"result_date", $"order_date").as("lastupdateddate")
      , validateSsnUdf($"member_ssn").as("incl_val"))
    )

    val intClaimMemberIn2 = intClaimMemberIn.select("*").select($"groupid"
      , $"datasrc"
      , $"client_ds_id"
      , expr("stack(4, member_ssn, 'SSN', alternate_member_id, 'NAT_ID', alternate_member_id_2, 'ALT_ID', hicn, 'HICN') as (idvalue, id_type)")
      , $"member_id"
      , $"member_eff_date"
      , $"eligibile_member_month").where(!($"id_type" === lit("SSN") && length(regexp_replace($"member_ssn", "-", "")) =!= 9))

    val patientId = intClaimMemberIn2.select(
      $"groupid"
      , lit("int_claim_member").as("datasrc")
      , $"client_ds_id"
      , when($"id_type" =!= lit("HICN"), $"id_type").otherwise(when($"id_type" === lit("HICN"), evalMbiHicnUdf($"idvalue"))).as("idtype")
      , when($"id_type" === lit("SSN"), regexp_replace($"idvalue", "-", "")).otherwise($"idvalue").cast(StringType).as("idvalue")
      , $"member_id".as("patientid")
      , lit(1).as("source")
      , coalesce($"member_eff_date", safeToDateLength($"eligibile_member_month", lit("yyyyMM"), lit(0))).as("lastupdateddate"))

    val patientId2 = patientId.unionByName(claimPatientid.select(
      $"groupid"
      , $"datasrc"
      , $"client_ds_id"
      , $"idtype"
      , $"idvalue".cast(StringType).as("idvalue")
      , $"patientid"
      , $"source"
      , $"lastupdateddate"
      , $"incl_val")
      .where("incl_val = 'Y'").drop($"incl_val"))

    val patientId3 = patientId2.unionByName(claimPatientid.select(
      $"groupid"
      , $"datasrc"
      , $"client_ds_id"
      , evalMbiHicnUdf($"patientid").as("idtype")
      , $"patientid".cast(StringType).as("idvalue")
      , $"patientid".as("patientid")
      , $"source"
      , $"lastupdateddate").where($"idtype".isNotNull))

    val patientId4 = patientId3.select($"groupid"
      , $"datasrc"
      , $"client_ds_id"
      , $"patientid"
      , $"idtype"
      , split(col("idvalue"), "\\.").getItem(0).cast(StringType).as("idvalue")
      , lit(null).cast(StringType).as("grp_mpi")
      , lit(null).cast(LongType).as("hgpid")
      , lit(null).cast(StringType).as("id_subtype")
      , row_number().over(Window.partitionBy($"client_ds_id", $"patientid",
        $"idtype").orderBy($"source", $"lastupdateddate".desc_nulls_last, $"idvalue".desc_nulls_last)).as("rn")).where(
      !$"idvalue".isin("000000000", "999999999") && $"rn" === 1 &&
        $"patientid".isNotNull && $"idvalue".isNotNull && $"idtype".isNotNull).drop($"rn")

    patientId4
  }

  def validateSSN(input_ssn: String): String = {
    if (input_ssn == null) {
      "NULL"
    }
    else {
      var v_ret: String = "Y"
      val length_of_ssn_regex = "([0-9]{9})".r
      val std_ssn = input_ssn.replaceAll("([-]){1,11}", "").trim
      try {
        std_ssn match {
          case std_ssn if (std_ssn.isEmpty == true) => "NULL"
          case std_ssn if ((length_of_ssn_regex.findFirstIn(std_ssn).getOrElse("").length) != 9) => "LEN"
          case std_ssn if (std_ssn.substring(0, 1) == "9" || std_ssn.substring(0, 3) == ("000") || std_ssn.substring(0, 3) == ("666") || std_ssn.substring(3, 5) == "00" || std_ssn.substring(5, 9) == "0000") => "DIGIT"
          case std_ssn if ((std_ssn.replace(std_ssn substring(0, 1), "")).isEmpty == true) => "SAME"
          case _ => "Y"
        }
      }
      catch {
        case e: Exception => "Y"
      }
    }
  }

  def evalMbiHicn(idVal: String): String = {
    if (idVal == null) {
      null
    }
    else {
      idVal match {
        case _ if idVal.matches("^[1-9]{1}[ACDEFGHJKMNPQRTUVWXY]{1}[ACDEFGHJKMNPQRTUVWXY0-9]{1}[0-9]{1}[ACDEFGHJKMNPQRTUVWXY]{1}[ACDEFGHJKMNPQRTUVWXY0-9]{1}[0-9]{1}[ACDEFGHJKMNPQRTUVWXY]{1}[ACDEFGHJKMNPQRTUVWXY]{1}[0-9]{1}[0-9]{1}$") => "MBI"
        case _ if idVal.matches("^(00[1-9]|0[1-9][0-9]|[1-7][0-9][0-9]|7[0-7][0-2]|77[0-2])(\\d{6})(A|B([1-9]?|[ADGHJKLNPQRTWY])|C([1-9]|[A-Z])|D([1-9]?|[ACDGHJKLMNPQRSTVWXYZ])|E([1-9]?|[ABCDFGHJKM])|F([1-8])|J([1-4])|K([1-9]|[ABCDEFGHJLM])|T([ABCDEFGHJKLMNPQRSTUVWXYZ2]?)|M|W([1-9]?|[BCFGJRT]))$") => "HICN"
        case _ => null
      }
    }
  }
}

