package com.optum.oap.backend.etl.bpo.bpo_pyr_ii_8_1

import com.optum.oap.backend.cdrTempModel.monthly_payer_servicemed_ii_8_1
import com.optum.oap.backend.etl.common.CDRConstants
import com.optum.oap.cdr.models._
import com.optum.oap.sparkdataloader.{RuntimeVariables, TableInfo, UserDefinedFunctionForDataLoader}
import org.apache.spark.sql.functions._
import org.apache.spark.sql.types.{DataTypes, StringType}
import org.apache.spark.sql.{DataFrame, SparkSession}


object MONTHLY_PAYER_SERVICEMED_II_8_1_EXTRACT extends TableInfo[monthly_payer_servicemed_ii_8_1] {

  override def dependsOn = Set("MAP_PREDICATE_VALUES", "PP_BPO_MEDICAL_CLAIMS", "PP_BPO_MEMBER_DETAIL", "PP_BPO_MEMBER_DETAIL_II")

  override def name = "MONTHLY_PAYER_SERVICEMED_II_8_1_EXTRACT"

  override def createDataFrame(sparkSession: SparkSession,
                               loadedDependencies: Map[String, DataFrame],
                               udfMap: Map[String, UserDefinedFunctionForDataLoader],
                               runtimeVariables: RuntimeVariables): DataFrame = {

    import sparkSession.implicits._

    val mapPredicateValues = broadcast(loadedDependencies("MAP_PREDICATE_VALUES")).as[map_predicate_values]
    val ppBpoMedicalClaims = loadedDependencies("PP_BPO_MEDICAL_CLAIMS").as[pp_bpo_medical_claims]
    val ppBpoMemberDetail = loadedDependencies("PP_BPO_MEMBER_DETAIL").as[pp_bpo_member_detail]
    val ppBpoMemberDetailII = loadedDependencies("PP_BPO_MEMBER_DETAIL_II").as[pp_bpo_member_detail_ii]

    val mpv_df = mapPredicateValues
      .where($"data_src" === "OADW" && $"table_name" === "PP_BPO_MEDICAL_CLAIMS" && $"entity" === "PP_BPO_MEDICAL_CLAIMS" && $"column_name" === "CLM_PASS")
      .select($"groupid").withColumn("mpv_exists", lit("Y")).distinct()

    ppBpoMedicalClaims.as("clm")
      .join(ppBpoMemberDetail.as("m"),
        $"m.memberid" === $"clm.memberid" && $"m.healthplansource" === $"clm.healthplansource" && $"clm.servicedate".between($"m.effectivedate", $"m.enddate"), "left")
      .join(ppBpoMemberDetailII.as("ii"),
        $"ii.memberid" === $"clm.memberid" && $"ii.healthplansource" === $"clm.healthplansource" && $"clm.servicedate".between($"ii.effectivedate", $"ii.enddate") && $"clm.employeraccountid" === $"ii.employeraccountid", "left_outer")
      .join(mpv_df.as("mpv"),
        $"mpv.groupid" === $"clm.groupid", "left")
      .where($"clm.healthplansource" === "PAYER" && ($"mpv.mpv_exists" === "Y" || $"clm.employeraccountid" === $"m.employeraccountid" || $"ii.memberid".isNotNull))

      .select($"clm.memberid".as("member"),
        $"claimheader".as("clm_id_n"),
        $"claimline".as("line_nat"),
        date_format($"servicedate", "yyyy-MM-dd").as("dos"),
        date_format($"fromdate", "yyyy-MM-dd").as("from_dt"),
        when(to_date($"todate", "yyyy-MM-dd").gt(lit("2079-06-06")), null).otherwise(date_format($"todate", "yyyy-MM-dd")).as("to_dt"),
        date_format($"paymentdate", "yyyy-MM-dd").as("pay_dt"),
        when($"icdcodetype" === "10", "0")
          .when($"icdcodetype" === "9", "9")
          .when($"icdcodetype".isNull && $"servicedate".geq(to_date(lit("20151001"), CDRConstants.DATE_FORMAT_4Y2M2D)), "0").otherwise("9").as("icd_version"),
        regexp_replace($"icddiag1", "\\.", "").as("diag1"),
        regexp_replace($"icddiag2", "\\.", "").as("diag2"),
        regexp_replace($"icddiag3", "\\.", "").as("diag3"),
        regexp_replace($"icddiag4", "\\.", "").as("diag4"),
        regexp_replace($"icddiag5", "\\.", "").as("diag5"),
        regexp_replace($"icddiag6", "\\.", "").as("diag6"),
        regexp_replace($"icddiag7", "\\.", "").as("diag7"),
        regexp_replace($"icddiag8", "\\.", "").as("diag8"),
        regexp_replace($"icddiag9", "\\.", "").as("diag9"),
        regexp_replace($"icddiag10", "\\.", "").as("diag10"),
        regexp_replace($"icdproc1", "\\.", "").as("iproc1"),
        regexp_replace($"icdproc2", "\\.", "").as("iproc2"),
        regexp_replace($"icdproc3", "\\.", "").as("iproc3"),
        regexp_replace($"icdproc4", "\\.", "").as("iproc4"),
        regexp_replace($"icdproc5", "\\.", "").as("iproc5"),
        regexp_replace($"icdproc6", "\\.", "").as("iproc6"),
        regexp_replace($"icd_proc_7", "\\.", "").as("iproc7"),
        regexp_replace($"icd_proc_8", "\\.", "").as("iproc8"),
        regexp_replace($"icd_proc_9", "\\.", "").as("iproc9"),
        regexp_replace($"icd_proc_10", "\\.", "").as("iproc10"),
        $"procedurecode".as("proccode"),
        $"revenuecode".as("revenue"),
        $"proceduremodifier".as("mod_n"),
        $"dischargestatus".as("dis_stat"),
        $"placeofservice".as("pos_n"),
        $"type_of_service".as("tos_n"),
        coalesce($"quantity", lit(0)).as("qty"),
        when($"serviceproviderid" === 0, 999).otherwise($"serviceproviderid").as("provider"),
        $"specialty".as("prv_sp_n"),
        coalesce($"cobamount", lit(0)).as("amt_cob"),
        coalesce($"coinsamount", lit(0)).as("amt_coin"),
        coalesce($"copayamount", lit(0)).as("amt_cop"),
        coalesce($"deductamount", lit(0)).as("amt_ded"),
        round(coalesce($"allowedamount", lit(0)), 2).as("amt_eqv"),
        round(coalesce($"paidamount", lit(0)), 2).as("amt_pay"),
        coalesce($"requestedamount", lit(0)).as("amt_req"),
        coalesce($"withamount", lit(0)).as("amt_wth"),
        round(coalesce($"patliabamount", lit(0)), 2).as("amt_liab"),
        coalesce($"capamount", lit(0)).as("amt_cap_pay"),
        $"amt_oth1",
        $"amt_oth2",
        $"amt_oth3",
        $"amt_oth4",
        when($"pseudoflag" === "Y" || $"pseudoflag" === "1" || $"deniedflag" === 'Y' || $"deniedflag" === '1', 1).otherwise(0).as("pseudo"),
        when($"orderingproviderid" === "0", "999").otherwise($"orderingproviderid").as("order_prov"),
        when(length($"typeofbill") === lit(4) && $"typeofbill".startsWith("0"), regexp_replace($"typeofbill", "^0", ""))
          .when(length($"typeofbill") =!= lit(3), null)
          .otherwise($"typeofbill").as("bill_type"),
        substring_index($"claimheader", ".", -1).as("uniq_rec_id"),
        $"clm.network_paid_status",
        $"provider_status",
        $"clm.contract_id".as("contract"),
        $"denied_ind",
        $"spec_rx_ind".as("spec_rx_n"),
        coalesce($"not_covered_amt", lit(0)).as("amt_not_covered"),
        coalesce($"other_carrier_pay_amt", lit(0)).as("amt_other_carrier_pay"),
        coalesce($"admin_fee_amt", lit(0)).as("amt_admin_fee"),
        $"claim_prov_affil_id".as("serv_prov_affil"),
        when($"billingproviderid" === "0", "999").otherwise($"billingproviderid").as("bill_provider"),
        $"drg".as("bill_drg_n"),
        $"drggrouper".as("bill_drg_version"),
        $"drgseverity".as("bill_drg_level"),
        $"drgoutlier".as("bill_drg_outlier"),
        $"proc_code_modifier2".as("mod_n_2"),
        $"proc_code_modifier3".as("mod_n_3"),
        $"proc_code_modifier4".as("mod_n_4"),
        regexp_replace($"icd_diag_11", "\\.", "").as("diag11"),
        regexp_replace($"icd_diag_12", "\\.", "").as("diag12"),
        regexp_replace($"icd_diag_13", "\\.", "").as("diag13"),
        regexp_replace($"icd_diag_14", "\\.", "").as("diag14"),
        regexp_replace($"icd_diag_15", "\\.", "").as("diag15"),
        regexp_replace($"icd_diag_16", "\\.", "").as("diag16"),
        regexp_replace($"icd_diag_17", "\\.", "").as("diag17"),
        regexp_replace($"icd_diag_18", "\\.", "").as("diag18"),
        regexp_replace($"icd_diag_19", "\\.", "").as("diag19"),
        regexp_replace($"icd_diag_20", "\\.", "").as("diag20"),
        regexp_replace($"icd_diag_21", "\\.", "").as("diag21"),
        regexp_replace($"icd_diag_22", "\\.", "").as("diag22"),
        regexp_replace($"icd_diag_23", "\\.", "").as("diag23"),
        regexp_replace($"icd_diag_24", "\\.", "").as("diag24"),
        regexp_replace($"icd_diag_25", "\\.", "").as("diag25"),
        regexp_replace($"icd_proc_11", "\\.", "").as("iproc11"),
        regexp_replace($"icd_proc_12", "\\.", "").as("iproc12"),
        regexp_replace($"icd_proc_13", "\\.", "").as("iproc13"),
        regexp_replace($"icd_proc_14", "\\.", "").as("iproc14"),
        regexp_replace($"icd_proc_15", "\\.", "").as("iproc15"),
        regexp_replace($"icd_proc_16", "\\.", "").as("iproc16"),
        regexp_replace($"icd_proc_17", "\\.", "").as("iproc17"),
        regexp_replace($"icd_proc_18", "\\.", "").as("iproc18"),
        regexp_replace($"icd_proc_19", "\\.", "").as("iproc19"),
        regexp_replace($"icd_proc_20", "\\.", "").as("iproc20"),
        regexp_replace($"icd_proc_21", "\\.", "").as("iproc21"),
        regexp_replace($"icd_proc_22", "\\.", "").as("iproc22"),
        regexp_replace($"icd_proc_23", "\\.", "").as("iproc23"),
        regexp_replace($"icd_proc_24", "\\.", "").as("iproc24"),
        regexp_replace($"icd_proc_25", "\\.", "").as("iproc25"),
        when($"capsvcflag" === "Y" || $"capsvcflag" == "1", 1).otherwise(0).as("cap_flag"),
        $"admitsource".as("admit_source"),
        $"cust_med_attr1".as("cust_med_1"),
        $"cust_med_attr2".as("cust_med_2"),
        $"cust_med_attr3".as("cust_med_3"),
        $"cust_med_attr4".as("cust_med_4"),
        $"cust_med_attr5".as("cust_med_5"),
        $"cust_med_attr6".as("cust_med_6"),
        $"cust_med_attr7".as("cust_med_7"),
        $"cust_med_attr8".as("cust_med_8"),
        $"cust_med_attr9".as("cust_med_9"),
        $"cust_med_attr10".as("cust_med_10"),
        $"cust_med_attr11".as("cust_med_11"),
        $"cust_med_attr12".as("cust_med_12"),
        $"cust_med_attr13".as("cust_med_13"),
        $"cust_med_attr14".as("cust_med_14"),
        $"cust_med_attr15".as("cust_med_15"),
        $"cust_med_attr16".as("cust_med_16"),
        $"cust_med_attr17".as("cust_med_17"),
        $"cust_med_attr18".as("cust_med_18"),
        $"cust_med_attr19".as("cust_med_19"),
        $"cust_med_attr20".as("cust_med_20"),
        $"claimheader".as("cust_med_pk_id"),
        $"clm.refer_prov_id".as("refer_prov"),
        $"clm.poa".as("poa1"),
        $"clm.poa_2".as("poa2"),
        $"clm.poa_3".as("poa3"),
        $"clm.poa_4".as("poa4"),
        $"clm.poa_5".as("poa5"),
        $"clm.poa_6".as("poa6"),
        $"clm.poa_7".as("poa7"),
        $"clm.poa_8".as("poa8"),
        $"clm.poa_9".as("poa9"),
        $"clm.poa_10".as("poa10"),
        $"clm.inp_admit_type".as("inp_admit_type"),
        lit(null).cast(DataTypes.StringType).as("drg_n"),
        lit(null).cast(DataTypes.StringType).as("drg_outlier"),
        lit(null).cast(DataTypes.StringType).as("drg_version"),
        lit(null).cast(DataTypes.StringType).as("drg_level"),
        lit(null).cast(DataTypes.StringType).as("amt_np"),
        lit(1).cast(DataTypes.StringType).as("map_srce_e"),
        lit(1).cast(DataTypes.StringType).as("map_srce_p"),
        lit(1).cast(DataTypes.StringType).as("map_srce_n"),
        lit(null).cast(DataTypes.StringType).as("ndc"),
        lit(null).cast(DataTypes.StringType).as("cvx_code")
      )
  }
}
