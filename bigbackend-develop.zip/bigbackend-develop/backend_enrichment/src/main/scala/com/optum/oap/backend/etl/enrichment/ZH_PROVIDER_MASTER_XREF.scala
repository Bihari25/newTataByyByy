package com.optum.oap.backend.etl.enrichment

import com.optum.oap.backend.cdrTempModel.{provider_xref, ref_cmsnpi_partial}
import com.optum.oap.backend.etl.common.{CDRConstants, CleanName, CleanPunct, PartitionedDataOperations}
import com.optum.oap.backend.loader.EnrichmentRunTimeVariables
import com.optum.oap.cdr.models._
import com.optum.oap.sparkdataloader.{RuntimeVariables, TableInfo, UserDefinedFunctionForDataLoader}
import org.apache.spark.sql.expressions.{UserDefinedFunction, Window}
import org.apache.spark.sql.functions._
import org.apache.spark.sql.types.{DataTypes, IntegerType, LongType}
import org.apache.spark.sql.{DataFrame, SparkSession}
import org.slf4j.LoggerFactory

object ZH_PROVIDER_MASTER_XREF extends TableInfo[zh_provider_master_xref] with PartitionedDataOperations {

  val log = LoggerFactory.getLogger(this.getClass)

  val nullCompareUDF: UserDefinedFunction = udf { (col1: String, col2: String) => nullCompareColumns(col1, col2) }

  def nullCompareColumns(col1: String, col2: String): Int = {
    if (col1 == null && col2 == null) 2 else if (col1 == null || col2 == null) 1 else if (col1.equals(col2)) 3 else 0
  }

  override def dependsOn = Set("TEMP_ZH_PROV_PREMATCH", "ZCM_PROVIDER_MATCH_RULE", "V_PROVIDER_XREF", "REF_CMSNPI", "ECDR_ZH_PROVIDER_MASTER_XREF", "ECDR_ZH_PROVIDER")

  override def name = "ZH_PROVIDER_MASTER_XREF"

  override def createDataFrame(sparkSession: SparkSession,
                               loadedDependencies: Map[String, DataFrame],
                               udfMap: Map[String, UserDefinedFunctionForDataLoader],
                               runtimeVariables: RuntimeVariables): DataFrame = {
    import sparkSession.implicits._

    implicit val session = sparkSession
    val schema = EnrichmentRunTimeVariables(runtimeVariables).cdrSchema

    val suffixPattern = "[\\W]{1}(JR|SR|III|II|IV|2ND|3RD|4TH|5TH|MR|MRS|MS|PHD|TWO|THREE|FOUR|FIVE)($|[\\W]{1})"

    val tempZhproviderIn = loadedDependencies("TEMP_ZH_PROV_PREMATCH").as[zh_provider]
    val hgMap = loadedDependencies("V_PROVIDER_XREF").as[provider_xref].withColumnRenamed("providerid", "localproviderid")
    val hgprovidMap = if(hgMap.isEmpty) loadData(schema, "V_PROVIDER_XREF").as[provider_xref].withColumnRenamed("providerid", "localproviderid") else hgMap
    val cmsNPI = loadedDependencies("REF_CMSNPI").as[ref_cmsnpi_partial]
    val zcmProvMatchRule = broadcast(loadedDependencies("ZCM_PROVIDER_MATCH_RULE")).as[zcm_provider_match_rule]

    val dailyBuild = if(runtimeVariables.asInstanceOf[EnrichmentRunTimeVariables].buildType == CDRConstants.DELTA_BUILD_TYPE) true else false

    val ecdr_zh_provider = if(dailyBuild)
      loadedDependencies("ECDR_ZH_PROVIDER").drop("row_source", "modified_date").as[zh_provider]
    else
      sparkSession.emptyDataset[zh_provider]

    val ecdr_zh_prov_xref = if(dailyBuild)
      loadedDependencies("ECDR_ZH_PROVIDER_MASTER_XREF").as[zh_provider_master_xref]
    else
      sparkSession.emptyDataset[zh_provider_master_xref]

    val zhProvDailyOnly = tempZhproviderIn.as("t")
      .join(ecdr_zh_provider.as("x"), $"t.localproviderid" === $"x.localproviderid" && $"t.client_ds_id" === $"x.client_ds_id", "left_outer")
      .where($"x.localproviderid".isNull)
      .select($"t.*").as[zh_provider]

    val zhproviderIn = if(dailyBuild) {
      zhProvDailyOnly.unionByName(ecdr_zh_provider)
    } else {
      tempZhproviderIn
    }

    val finalCols = Seq("groupid", "client_ds_id", "localproviderid", "hgprovid", "master_hgprovid")
    val ruleColMap = Map("DEFAULT" -> Seq("clean_name"), "CUSTOM1" -> Seq("clean_name", "middle_initial_min", "suffix_min", "mappedcredentialtype_min"))
    val provRule = if (zcmProvMatchRule.count == 1) zcmProvMatchRule.first.match_rule else "DEFAULT"
    val ruleCols = ruleColMap(provRule)
    val npiPartCols = provRule match {
      case "CUSTOM1" => ruleCols :+ "npi"
      case _ => ruleCols
    }
    val ruleColWindow = Window.partitionBy(npiPartCols.head, npiPartCols.tail: _*)
    val selectCols = Seq("rownbr", "npi", "master_hgprovid", "middle_initial", "suffix", "mappedcredentialtype", "npi_rawname_cnt", "clean_name", "cms_clean_name", "rowcnt", "middle_initial_min", "suffix_min", "mappedcredentialtype_min") ++ ruleCols

    //Prep Data
    val zhProvJoin = zhproviderIn.alias("zp")
      .join(hgprovidMap, Seq("groupid", "client_ds_id", "localproviderid"), "inner").select("zp.*", "hgprovid")
      .join(cmsNPI.alias("cms"), Seq("npi"), "left_outer")
      .select($"zp.providername",
        $"zp.groupid",
        $"zp.localproviderid",
        $"zp.client_ds_id",
        $"hgprovid",
        $"first_name",
        $"last_name",
        $"middle_name".as("zp_mid"),
        $"suffix".as("zp_suffix"),
        $"npi",
        $"mappedcredentialtype",
        $"prov_middle_name",
        $"prov_firstname",
        $"prov_credential",
        $"prov_lastname_legalname",
        $"entity_type_code",
        $"prov_name_suffix",
        when(coalesce(length($"npi"), lit(0)) === lit(10), 1).otherwise(0).as("legalNPI"),
        regexp_extract(upper($"providername"), suffixPattern, 1).as("suffix_provname"),
        regexp_extract(upper($"last_name"), suffixPattern, 1).as("suffix_lastname"),
        CleanName.cleanPersonName($"providername", lit(3)).as("clean_name_sub"),
        when(regexp_replace(upper($"providername"), suffixPattern, "").rlike("^[-0-9A-Z ]{2,},"), split(regexp_replace(regexp_replace(upper($"providername".substr(instr($"providername", ",") + 1, length($"providername"))), suffixPattern, ""), "[.,-]", ""), "[ ]{1,}")).as("middle_from_prov"),
        CleanPunct.cleanPunctUDF(coalesce($"credentials", $"prov_credential")).as("credentials"),
        when($"credentials".isNull, 1).otherwise(0).as("no_localcred"),
        CleanName.cleanPersonName(
          when($"entity_type_code" === lit(1), concat($"prov_lastname_legalname", lit(", "), $"prov_firstname"))
          .when($"entity_type_code" === lit(2), coalesce($"prov_oth_org_name", $"prov_org_name_legal_bus_name")).otherwise(""), lit(3)).as("cms_clean_name"),
        when(length(regexp_replace($"zp.middle_name", "[^0-9A-Za-z]", "")) === lit(1) && length($"prov_middle_name") > 1, $"prov_middle_name").otherwise(coalesce($"zp.middle_name", $"prov_middle_name")).as("middle_from_name")
      )

    val zhProvWithElements = zhProvJoin.select(
      $"*",
       when(size($"middle_from_prov") === lit(3), CleanName.cleanPersonName($"middle_from_prov".getItem(2), lit(3)))
         .when(substring(CleanPunct.cleanPunctUDF($"providername"), -2, 1) === lit(" "), substring(CleanPunct.cleanPunctUDF($"providername"), -1, 1))
         .as("last_prov_word"),
       coalesce($"clean_name_sub", $"cms_clean_name").as("clean_name"),
       when(!(coalesce($"suffix_lastname", lit("")) <=> lit("")), $"suffix_lastname").as("suffix_lastname"),
       when(!(coalesce($"suffix_provname", lit("")) <=> lit("")), $"suffix_provname").as("suffix_provname"),
       CleanPunct.cleanPunctUDF(coalesce($"suffix_provname", $"zp_suffix", $"suffix_lastname", $"prov_name_suffix")).as("suffix")
    ).withColumn("middle_name", coalesce($"zp_mid", when(!(coalesce($"last_prov_word", lit("")) <=> lit("")), $"last_prov_word"), $"middle_from_name"))
      .withColumn("middle_initial", substring($"middle_name", 0, 1))


    //Match by NPI
    val npiCol = $"npi"
    val groupedByNPI = zhProvWithElements.where($"legalNPI" === 1)
      .select(
        $"groupid",
        $"client_ds_id",
        $"localproviderid",
        $"npi", $"clean_name",
        $"cms_clean_name",
        $"providername",
        $"last_name",
        $"first_name",
        $"middle_name",
        $"middle_initial",
        $"credentials",
        $"mappedcredentialtype",
        $"no_localcred",
        $"suffix",
        $"hgprovid",
        min($"hgprovid").over(Window.partitionBy(npiCol)).as("master_hgprovid"),
        count($"providername").over(Window.partitionBy(npiCol, regexp_replace($"providername", "[ .,-]", ""))).as("npi_rawname_cnt"),
        count($"hgprovid").over(Window.partitionBy(npiCol, $"clean_name")).as("rowcnt"),
        coalesce($"middle_initial", min("middle_initial").over(Window.partitionBy(npiCol, $"clean_name"))).as("middle_initial_min"),
        coalesce($"suffix", min("suffix").over(Window.partitionBy(npiCol, $"clean_name"))).as("suffix_min"),
        coalesce($"mappedcredentialtype", min("mappedcredentialtype").over(Window.partitionBy(npiCol, $"clean_name"))).as("mappedcredentialtype_min")
      ).withColumn("rownbr", row_number.over(ruleColWindow.orderBy($"npi_rawname_cnt".desc, $"no_localcred", $"npi", $"hgprovid")))

    //Pick the best rows for each set of JOIN cols.
    val bestRankedNames = groupedByNPI.where($"clean_name".isNotNull && $"rownbr" === 1).select(selectCols.head, selectCols.tail: _*)

    //Match Join cols to NPI rows
    val nameToNPIPrep = zhProvWithElements.where($"legalNPI" === 0)
      .select($"groupid",
        $"client_ds_id",
        $"localproviderid",
        $"clean_name",
        $"cms_clean_name",
        $"providername",
        $"last_name",
        $"first_name",
        $"middle_name",
        $"middle_initial",
        $"mappedcredentialtype",
        $"suffix",
        $"hgprovid",
        coalesce($"middle_initial", min("middle_initial").over(Window.partitionBy($"clean_name"))).as("middle_initial_min"),
        coalesce($"suffix", min("suffix").over(Window.partitionBy($"clean_name"))).as("suffix_min"),
        coalesce($"mappedcredentialtype", min("mappedcredentialtype").over(Window.partitionBy($"clean_name"))).as("mappedcredentialtype_min")
      )

    val joinByCleanNameToNPI = nameToNPIPrep.alias("nm")
      .join(bestRankedNames.alias("rn"), $"nm.clean_name" === $"rn.clean_name", "inner")

    val joinByNameToNPI = provRule match {
      case "CUSTOM1" => nameToNPIPrep.alias("nm")
        .join(bestRankedNames.alias("rn"), $"nm.clean_name" === $"rn.cms_clean_name", "inner")
        .join(joinByCleanNameToNPI.alias("bn").select($"hgprovid"), $"nm.hgprovid" === $"bn.hgprovid", "left_outer")
        .where($"bn.hgprovid".isNull).drop($"bn.hgprovid").union(joinByCleanNameToNPI).select(
        $"*",
        nullCompareUDF($"nm.middle_initial", coalesce($"rn.middle_initial", $"rn.middle_initial_min")).as("middle_initial_match"),
        nullCompareUDF($"nm.suffix", $"rn.suffix").as("suffix_match"),
        nullCompareUDF($"nm.mappedcredentialtype", $"rn.mappedcredentialtype").as("mappedcredentialtype_match"),
        when($"nm.clean_name" === $"rn.cms_clean_name", 1).otherwise(2).as("cmsname_match")
      ).where(least($"middle_initial_match",$"suffix_match",$"mappedcredentialtype_match") > 0)
      case _ => joinByCleanNameToNPI.select(
        $"*",
        lit(0).as("middle_initial_match"),
        lit(0).as("suffix_match"),
        lit(0).as("mappedcredentialtype_match"),
        lit(0).as("cmsname_match")
      )
    }


    val joinByNameRanked = joinByNameToNPI.select(
      $"*",
      row_number().over(Window.partitionBy("hgprovid").orderBy($"rownbr", $"middle_initial_match".desc, $"suffix_match".desc, $"mappedcredentialtype_match".desc, $"rn.mappedcredentialtype", $"cmsname_match", $"npi_rawname_cnt".desc, $"npi")).as("bestmatch")
    ).withColumn("master_hgprovid", min($"master_hgprovid").over(Window.partitionBy("npi", "nm.clean_name")))


    //Put those two sets together
    val assignedToNPI = joinByNameRanked.where($"bestmatch" === 1)
      .select(finalCols.head, finalCols.tail: _*).union(groupedByNPI.select(finalCols.head, finalCols.tail: _*))
      .withColumn("master_hgprovid", min($"hgprovid".cast(LongType)).over(Window.partitionBy($"master_hgprovid")))
      .withColumn("match_cnt", count($"hgprovid").over(Window.partitionBy($"master_hgprovid")).cast(IntegerType))

    //Collect Ids not assigned by NPI
    val notByNPI = nameToNPIPrep
      .select($"groupid",
        $"client_ds_id",
        $"localproviderid",
        $"clean_name",
        $"providername",
        $"last_name",
        $"first_name",
        $"middle_name",
        $"middle_initial",
        $"mappedcredentialtype",
        $"suffix",
        $"middle_initial_min",
        $"suffix_min",
        $"mappedcredentialtype_min", $"hgprovid").alias("zp")
      .join(assignedToNPI.alias("s2"), $"zp.groupid" === $"s2.groupid" && $"zp.client_ds_id" === $"s2.client_ds_id" && $"zp.localproviderid" === $"s2.localproviderid", "left_outer")
      .where($"s2.groupid".isNull)
      .select($"zp.*")

    //Group Names that don't match to NPI names.
    val byNamePartition = provRule match {
      case "CUSTOM1" => Window.partitionBy($"clean_name", coalesce($"middle_initial", $"middle_initial_min"), coalesce($"suffix", $"suffix_min"), coalesce($"mappedcredentialtype", $"mappedcredentialtype_min"))
      case _ => Window.partitionBy($"clean_name")
    }
    val assignedByNameOnly = notByNPI.where($"clean_name".isNotNull)
      .select($"groupid",
        $"client_ds_id",
        $"localproviderid",
        $"clean_name",
        $"providername",
        $"last_name",
        $"first_name",
        $"middle_name",
        $"middle_initial",
        $"mappedcredentialtype",
        $"suffix",
        $"middle_initial_min",
        $"suffix_min",
        $"mappedcredentialtype_min",
        $"hgprovid",
       min($"hgprovid").over(byNamePartition).as("master_hgprovid"),
       count($"localproviderid").over(byNamePartition).cast(IntegerType).as("match_cnt")
      )

    val colList = finalCols :+ "match_cnt"
    val assigned = assignedByNameOnly.select(colList.head, colList.tail: _*).union(assignedToNPI)

    //Elements with no NPI and no name, assign each to it's own HGPROVID
    val remainder = notByNPI.where($"clean_name".isNull)
      .select(
        $"groupid",
        $"client_ds_id",
        $"localproviderid",
        $"hgprovid",
        $"hgprovid".cast(DataTypes.StringType).as("master_hgprovid"),
        lit(1).as("match_cnt")
      )

    //Set master using the minimum for the NPI set
    val allAssigned = remainder.union(assigned)

    if(dailyBuild) {
      val dailyProv = allAssigned.as("all").join(zhProvDailyOnly.as("temp"), $"temp.localproviderid" === $"all.localproviderid" && $"temp.client_ds_id" === $"all.client_ds_id", "inner")
        .select($"all.*").as[zh_provider_master_xref]

      ecdr_zh_prov_xref.drop("row_source", "modified_date").unionByName(dailyProv.toDF())

    } else {
      allAssigned
    }

  }


}