package com.optum.oap.backend.etl.enrichment

import com.optum.oap.backend.cdrTempModel.temp_icpm_patient_patientdetail_patientcontact
import com.optum.oap.cdr.models.patientdetail
import com.optum.oap.sparkdataloader.{RuntimeVariables, TableInfo, UserDefinedFunctionForDataLoader}
import org.apache.spark.sql.functions._
import org.apache.spark.sql.types.DataTypes
import org.apache.spark.sql.{DataFrame, SparkSession}
import org.slf4j.LoggerFactory


object ICPM_PATIENT_DETAIL extends TableInfo[patientdetail] {

  private val log = LoggerFactory.getLogger(this.getClass)

  override def dependsOn = Set("ICPM_PATIENT_INTERMEDIATE")

  override def name = "ICPM_PATIENT_DETAIL"

  override def partitions: Int = 32

  override def createDataFrame(sparkSession: SparkSession,
                               loadedDependencies: Map[String, DataFrame],
                               udfMap: Map[String, UserDefinedFunctionForDataLoader],
                               runtimeVariables: RuntimeVariables): DataFrame = {

    import sparkSession.implicits._

    val cdrFePatientIntermediate = loadedDependencies("ICPM_PATIENT_INTERMEDIATE")
      .as[temp_icpm_patient_patientdetail_patientcontact]

    val patDetailTimestamp = when(col("lastupdateddate").isNotNull, col("lastupdateddate")).otherwise(current_timestamp())

    cdrFePatientIntermediate.filter(
      col("firstname_row") === lit(1)
        and col("firstname").isNotNull
        and col("patientid").isNotNull
    ).select(
      col("groupid"),
      col("datasrc"),
      col("patientid"),
      patDetailTimestamp.as("patdetail_timestamp"),
      lit("FIRST_NAME").as("patientdetailtype"),
      upper(col("firstname")).as("localvalue"),
      col("client_ds_id")
    ).unionByName(
      cdrFePatientIntermediate.filter(
        col("lastname_row") === lit(1)
          and col("lastname").isNotNull
          and col("patientid").isNotNull
      ).select(
        col("groupid"),
        col("datasrc"),
        col("patientid"),
        patDetailTimestamp.as("patdetail_timestamp"),
        lit("LAST_NAME").as("patientdetailtype"),
        upper(col("lastname")).as("localvalue"),
        col("client_ds_id")
      )
    ).unionByName(
      cdrFePatientIntermediate.filter(
        col("middle_row") === lit(1)
          and col("middlename").isNotNull
          and col("patientid").isNotNull
      ).select(
        col("groupid"),
        col("datasrc"),
        col("patientid"),
        patDetailTimestamp.as("patdetail_timestamp"),
        lit("MIDDLE_NAME").as("patientdetailtype"),
        upper(col("middlename")).as("localvalue"),
        col("client_ds_id")
      )
    ).unionByName(
      cdrFePatientIntermediate.filter(
        col("gender_row") === lit(1)
          and col("gender").isNotNull
          and col("patientid").isNotNull
      ).select(
        col("groupid"),
        col("datasrc"),
        col("patientid"),
        patDetailTimestamp.as("patdetail_timestamp"),
        lit("GENDER").as("patientdetailtype"),
        col("gender").as("localvalue"),
        col("client_ds_id")
      )
    ).unionByName(
      cdrFePatientIntermediate.filter(
        col("language_row") === lit(1)
          and col("language").isNotNull
          and col("patientid").isNotNull
      ).select(
        col("groupid"),
        col("datasrc"),
        col("patientid"),
        patDetailTimestamp.as("patdetail_timestamp"),
        lit("LANGUAGE").as("patientdetailtype"),
        col("language").as("localvalue"),
        col("client_ds_id")
      )
    ).unionByName(
      cdrFePatientIntermediate.filter(
        col("ethnic_row") === lit(1)
          and col("ethnicity").isNotNull
          and col("patientid").isNotNull
      ).select(
        col("groupid"),
        col("datasrc"),
        col("patientid"),
        patDetailTimestamp.as("patdetail_timestamp"),
        lit("ETHNICITY").as("patientdetailtype"),
        col("ethnicity").as("localvalue"),
        col("client_ds_id")
      )
    ).unionByName(
      cdrFePatientIntermediate.filter(
        col("race_row") === lit(1)
          and col("race").isNotNull
          and col("patientid").isNotNull
      ).select(
        col("groupid"),
        col("datasrc"),
        col("patientid"),
        patDetailTimestamp.as("patdetail_timestamp"),
        lit("RACE").as("patientdetailtype"),
        col("race").as("localvalue"),
        col("client_ds_id")
      )
    ).unionByName(
      cdrFePatientIntermediate.filter(
        col("marital_row") === lit(1)
          and col("marital_status").isNotNull
          and col("patientid").isNotNull
      ).select(
        col("groupid"),
        col("datasrc"),
        col("patientid"),
        patDetailTimestamp.as("patdetail_timestamp"),
        lit("MARITAL").as("patientdetailtype"),
        col("marital_status").as("localvalue"),
        col("client_ds_id")
      )
    ).unionByName(
      cdrFePatientIntermediate.filter(
        col("death_row") === lit(1)
          and col("Deceased").isNotNull
          and col("patientid").isNotNull
      ).select(
        col("groupid"),
        col("datasrc"),
        col("patientid"),
        patDetailTimestamp.as("patdetail_timestamp"),
        lit("DECEASED").as("patientdetailtype"),
        col("Deceased").as("localvalue"),
        col("client_ds_id")
      )
    ).unionByName(
      cdrFePatientIntermediate.filter(
        col("city_row") === lit(1)
          and col("city").isNotNull
          and col("patientid").isNotNull
      ).select(
        col("groupid"),
        col("datasrc"),
        col("patientid"),
        patDetailTimestamp.as("patdetail_timestamp"),
        lit("CITY").as("patientdetailtype"),
        upper(col("city")).as("localvalue"),
        col("client_ds_id")
      )
    ).unionByName(
      cdrFePatientIntermediate.filter(
        col("state_row") === lit(1)
          and col("state").isNotNull
          and col("patientid").isNotNull
      ).select(
        col("groupid"),
        col("datasrc"),
        col("patientid"),
        patDetailTimestamp.as("patdetail_timestamp"),
        lit("STATE").as("patientdetailtype"),
        col("state").as("localvalue"),
        col("client_ds_id")
      )
    ).unionByName(
      cdrFePatientIntermediate.filter(
        col("zipcode_row") === lit(1)
          and col("zipcode").isNotNull
          and col("patientid").isNotNull
      ).select(
        col("groupid"),
        col("datasrc"),
        col("patientid"),
        patDetailTimestamp.as("patdetail_timestamp"),
        lit("ZIPCODE").as("patientdetailtype"),
        col("zipcode").as("localvalue"),
        col("client_ds_id")
      )
    ).select(
      col("groupid"),
      col("datasrc"),
      col("patientid"),
      col(("patdetail_timestamp")),
      col("patientdetailtype"),
      col("localvalue"),
      col("client_ds_id"),
      lit(null).cast(DataTypes.StringType).as("encounterid"),
      lit(null).cast(DataTypes.StringType).as("facilityid"),
      lit(null).cast(DataTypes.StringType).as("grp_mpi"),
      lit(null).cast(DataTypes.StringType).as("patientdetailqual"),
      lit(null).cast(DataTypes.LongType).as("hgpid"),
      lit(null).cast(DataTypes.StringType).as("patientdetailstatus")
    )
  }

}
