package com.optum.oap.backend.etl

import com.optum.oap.backend.util.ImportResources
import com.optum.oap.backend.util.ImportResources.{CDRFETableCrossWalk, InternalDataTypeMapping}
import com.optum.oap.cdr.schema.CDRSchema

import scala.io.Source
import scala.io.Source.fromInputStream
import scala.language.implicitConversions

/**
  * This is a package level object. Anything declared within this object will be visible
  * inside the com.optum.oap.backend.etl package
  */
package object cdrfe {

  /**
    * Map containing key-value pair wherein key is the table in CDRBE and value is the corresponding table in CDRFE
    */
  lazy val CDRFE_TABLE_CROSS_WALK: Map[String, String] = Source
    .fromInputStream(ImportResources.getClass.getClassLoader.getResourceAsStream(CDRFETableCrossWalk))
    .getLines()
    .map(x => {
      val record = x.split("\\|")
      record(1) -> record(0)
    }).toMap

  /**
    * Reads datatype mapping file from CDR Contract and internal_data_type_mapping.txt files and returns all the lines
    */
  lazy val CDRBE_DATATYPE_MAPPING: Seq[String] = {
    val inputStreamFromContract = CDRSchema.getClass.getClassLoader.getResourceAsStream(CDRSchema.CDR_DATA_TYPE_MAPPING_FILE)
    val inputStreamFromInternal = ImportResources.getClass.getClassLoader.getResourceAsStream(InternalDataTypeMapping)
    fromInputStream(inputStreamFromContract).getLines().toList ++ fromInputStream(inputStreamFromInternal).getLines().toList
  }

  case class EmptySchema()
}
