package com.optum.oap.backend.etl.encgrps

import com.optum.oap.backend.cdrTempModel.temp_encounter_grp_pdx
import com.optum.oap.sparkdataloader.QueryAndMetadata

object TEMP_ENCOUNTER_GRP_PDX extends QueryAndMetadata[temp_encounter_grp_pdx] {
  override def name: String = "TEMP_ENCOUNTER_GRP_PDX"

  override def sparkSql: String =
    """
      |select ENCOUNTER_GRP_NUM, max(prindx) as prindx , max(codetype) as codetype from (
      |select dx.groupid, dx.grp_mpi, dx.ENCOUNTER_GRP_NUM, dx.mappeddiagnosis as prindx, dx.encounterid, dx.client_ds_id , CODETYPE, ICD_VER
      |  ,row_number() over (partition by dx.groupid, dx.grp_mpi, dx.ENCOUNTER_GRP_NUM
      |               order by dx.groupid, dx.grp_mpi, dx.ENCOUNTER_GRP_NUM
      |                  , case when encounteridtype = 'MASTER' then 1
      |                         when encounteridtype = 'ENCTR' then 2
      |                         when encounteridtype = 'ADD AS' then 3
      |                         when encounteridtype = 'ADD OT' then 4
      |                         when encounteridtype = 'ADD UN' then 5
      |                         when encounteridtype = 'ADD ER' then 6
      |                         when encounteridtype = 'ADD OB' then 7
      |                         when encounteridtype = 'ADD SD' then 8 else 9 end
      |                  , dx.dx_timestamp desc, dx.encounterid desc
      |                  , dx.mappeddiagnosis desc nulls last) as dxrank
      |from
      |TEMP_ENCOUNTER_PRINDX dx
      |where dx.mappeddiagnosis is not null
      |and primarydiagnosis = 1)
      |where dxrank = 1
      |group by ENCOUNTER_GRP_NUM
    """.stripMargin

  override def dependsOn: Set[String] = Set("TEMP_ENCOUNTER_PRINDX")
}
