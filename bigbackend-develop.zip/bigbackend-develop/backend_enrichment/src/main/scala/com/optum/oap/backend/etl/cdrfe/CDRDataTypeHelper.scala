package com.optum.oap.backend.etl.cdrfe

import org.apache.spark.sql.types.DataType

import scala.language.implicitConversions

object CDRDataTypeHelper {

  /**
    * Implicit method for translating CDRDataType instance to Spark's DataType instance
    * @param cdrDataType
    * @return
    */
  implicit def cdrToSparkDataTypeConverter(cdrDataType: CDRDataType): DataType = {
    cdrDataType.dataType.toLowerCase match {
      case "integer" | "int" => org.apache.spark.sql.types.IntegerType
      case "boolean" | "bool" => org.apache.spark.sql.types.BooleanType
      case "long" | "bigint" => org.apache.spark.sql.types.LongType
      case "varchar" | "char" | "string" => org.apache.spark.sql.types.StringType
      case "sdate" | "date" => org.apache.spark.sql.types.DateType
      case "timestamp" => org.apache.spark.sql.types.TimestampType
      case "double" => org.apache.spark.sql.types.DoubleType
      case "decimal" =>
        org.apache.spark.sql.types.DecimalType(cdrDataType.precision.getOrElse(throw new IllegalArgumentException("Invalid precision value")),
          cdrDataType.scale.getOrElse(throw new IllegalArgumentException("Invalid precision value")))
    }
  }

  case class CDRDataType(dataType: String, precision: Option[Int], scale: Option[Int])
}
