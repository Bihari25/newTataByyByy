package com.optum.oap.backend.etl.bpo

import com.optum.oap.backend.cdrTempModel.temp_pid
import com.optum.oap.cdr.models.{mv_client_data_src, zh_provider, zo_bpo_map_employer}
import com.optum.oap.sparkdataloader.{RuntimeVariables, TableInfo, UserDefinedFunctionForDataLoader}
import org.apache.spark.sql.expressions.Window
import org.apache.spark.sql.{DataFrame, SparkSession}
import org.apache.spark.sql.functions._

object TEMP_PID  extends TableInfo[temp_pid]{
  override def dependsOn: Set[String] = Set("ZH_PROVIDER", "MV_CLIENT_DATA_SRC", "ZO_BPO_MAP_EMPLOYER")

  override def name = "TEMP_PID"

  override def createDataFrame(sparkSession: SparkSession,
                               loadedDependencies: Map[String, DataFrame],
                               udfMap: Map[String, UserDefinedFunctionForDataLoader],
                               runtimeVariables: RuntimeVariables): DataFrame = {
    import sparkSession.implicits._

    val zhProvider = loadedDependencies("ZH_PROVIDER").as[zh_provider]
    val mvClientDataSrc = broadcast(loadedDependencies("MV_CLIENT_DATA_SRC")).as[mv_client_data_src]
    val zoBpoMapEmployer = broadcast(loadedDependencies("ZO_BPO_MAP_EMPLOYER")).as[zo_bpo_map_employer]


    val zhProv = zhProvider.as("zh")
      .where($"master_hgprovid".isNotNull)
      .join(mvClientDataSrc.as("mvcDs"), $"mvcDs.client_id" === $"zh.groupid" && $"mvcDs.client_data_src_id" === $"zh.client_ds_id", "inner")
      .join(zoBpoMapEmployer.as("zbME"), $"zbME.groupid" === $"zh.groupid" && $"zbME.client_ds_id" === $"zh.client_ds_id", "left_outer")
      .select(
        $"zh.master_hgprovid".as("master_hgprovid"),
        $"zh.localproviderid".as("sec_provider_id"),
        row_number().over(Window.partitionBy($"zh.master_hgprovid")
          .orderBy(when($"mvcDs.data_src_id" === lit(3683), lit(1)).otherwise(lit(2))
            ,when($"zbME.client_ds_id".isNotNull, lit(1)).otherwise(lit(2))
            ,$"localproviderid".desc
          )).as("rank")
      ).where($"rank" === 1)

    zhProv.drop($"rank")
  }

}
