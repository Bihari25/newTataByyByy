package com.optum.oap.backend.etl.enrichment

import com.optum.oap.backend.loader.EnrichmentRunTimeVariables
import com.optum.oap.sparkdataloader.{RuntimeVariables, TableInfo, UserDefinedFunctionForDataLoader}
import org.apache.spark.sql.{DataFrame, SparkSession}

/** Case class for copying maps and other tables from cdr_fe to cdr_be
  *
  * ==Overview==
  * In the [[com.optum.oap.backend.loader.loadgroup.EnrichmentLoadGroup]] initial dependencies
  * are dynamically initialized via the [[com.optum.oap.sparkdataloader.LoadFromHive]].
  * Dynamically loaded tables are prefixed with "CDR_FE_". FE_TO_BE etl depends on the prefixed table.
  *
  * @param tableName
  */
case class FE_TO_BE(tableName: String) extends TableInfo[Nil] {
  override def dependsOn: Set[String] = Set(s"CDR_FE_$tableName")

  override def name: String = tableName

  override def ignoreExtraColumnsInDataFrame: Boolean = true

  override def partitions: Int = 1

  override protected def createDataFrame(sparkSession: SparkSession,
                                         loadedDependencies: Map[String, DataFrame],
                                         udfMap: Map[String, UserDefinedFunctionForDataLoader],
                                         runtimeVariables: RuntimeVariables): DataFrame = {

    loadedDependencies(s"CDR_FE_$tableName")
  }
}

case class Nil()
