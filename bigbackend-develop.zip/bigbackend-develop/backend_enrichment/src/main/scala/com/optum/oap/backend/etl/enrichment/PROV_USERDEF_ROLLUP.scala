package com.optum.oap.backend.etl.enrichment

import com.optum.oap.backend.loader.EnrichmentRunTimeVariables
import com.optum.oap.cdr.models.{int_claim_prov, prov_userdef_rollup}
import com.optum.oap.sparkdataloader.{RuntimeVariables, TableInfo, UserDefinedFunctionForDataLoader}
import org.apache.spark.sql.expressions.Window
import org.apache.spark.sql.functions.{coalesce, lit, _}
import org.apache.spark.sql.types._
import org.apache.spark.sql.{DataFrame, SparkSession}
import org.slf4j.LoggerFactory

object PROV_USERDEF_ROLLUP extends TableInfo[prov_userdef_rollup] {

  private val log = LoggerFactory.getLogger(this.getClass)

  override def dependsOn = Set("CDR_FE_PROV_USERDEF_ROLLUP", "INT_CLAIM_PROV")

  override def name = "PROV_USERDEF_ROLLUP"

  override def partitions: Int = 32

  override def createDataFrame(sparkSession: SparkSession, loadedDependencies: Map[String, DataFrame],
                               udfMap: Map[String, UserDefinedFunctionForDataLoader],
                               runtimeVariables: RuntimeVariables): DataFrame = {

    import sparkSession.implicits._

    val groupId = runtimeVariables.asInstanceOf[EnrichmentRunTimeVariables].clientId
    logger.warn(s"Running PROV_USERDEF_ROLLUP for group $groupId")

    val provUserdefRollup = loadedDependencies("CDR_FE_PROV_USERDEF_ROLLUP").as[prov_userdef_rollup]
    val intClaimProv = loadedDependencies("INT_CLAIM_PROV").as[int_claim_prov]

    val attribTypeCui = "CH004049"

    //Origin Front end <PROV_USERDEF_ROLLUP> Table
    val cdrProvUserdefRollup = provUserdefRollup.select(
      $"attribute_type_cui",
      $"client_ds_id",
      $"datasrc",
      $"prov_userdef",
      $"prov_userdef_desc",
      $"prov_userdef_lv1",
      $"prov_userdef_lv1_desc",
      $"prov_userdef_lv2",
      $"prov_userdef_lv2_desc",
      $"groupid")

    //TAKING DISTINCT <prov_userdef> from the <PROV_USERDEF_ROLLUP> TABLE #1
    val distinctProvUserdefRollup = cdrProvUserdefRollup.where(
      $"attribute_type_cui" === lit(attribTypeCui)).dropDuplicates("prov_userdef")

    //SELECTING RECORDS OF <INT_CLAIM_PROV> TABLE WHOSE <ii_prov_userdef_2> are not in <PROV_USERDEF_ROLLUP> TABLE
    val intClaimProv1 = intClaimProv.alias("icp").join(distinctProvUserdefRollup.alias("cdr"),
      $"icp.ii_prov_userdef_2" === $"cdr.prov_userdef", "left")
      .select(
        $"icp.groupid"
        , $"icp.client_ds_id"
        , lit("int_claim_prov").as("datasrc")
        , lit(attribTypeCui).as("attribute_type_cui")
        , $"icp.ii_prov_userdef_2".as("prov_userdef")
        , substring(concat(lit("UNDEFINED ("), $"icp.ii_prov_userdef_2", lit(")")),
          1, 150).cast(StringType).as("prov_userdef_desc")
        , $"cdr.prov_userdef_lv2", $"cdr.prov_userdef_lv2_desc"
        , $"cdr.prov_userdef_lv1", $"cdr.prov_userdef_lv1_desc")
      .where($"icp.ii_prov_userdef_2".isNotNull
        && length($"icp.ii_prov_userdef_2") <= 30
        && $"cdr.prov_userdef".isNull)
      .groupBy($"groupid", $"prov_userdef", $"datasrc", $"prov_userdef_desc", $"attribute_type_cui"
        , $"cdr.prov_userdef_lv2", $"cdr.prov_userdef_lv2_desc"
        , $"cdr.prov_userdef_lv1", $"cdr.prov_userdef_lv1_desc").agg(min($"client_ds_id").as("client_ds_id"))

    //NOW UNION THE MISSING RECORDS FETCHED FROM <INT_CLAIM_PROV> WITH <PROV_USERDEF_ROLLUP> TABLE
    val cdrProvUserdefRollup1 = cdrProvUserdefRollup.unionByName(intClaimProv1)

    //APPLYING ADDITIONAL TRANSFORMATIONS ON THE UNION
    val rollup = cdrProvUserdefRollup1.select(
      $"groupid"
      , $"datasrc"
      , $"client_ds_id"
      , $"attribute_type_cui"
      , $"prov_userdef"
      , substring(coalesce($"prov_userdef_desc", concat(lit("UNDEFINED ("),
        $"prov_userdef", lit(")"))), 1, 150).as("prov_userdef_desc")
      , $"prov_userdef_lv1", $"prov_userdef_lv1_desc"
      , $"prov_userdef_lv2", $"prov_userdef_lv2_desc"
      , row_number().over(Window.partitionBy($"prov_userdef").orderBy(
        $"prov_userdef_desc".desc_nulls_last)).as("rn")).where($"prov_userdef".isNotNull &&
      length($"prov_userdef") <= 30 &&
      $"rn" === lit(1)).drop($"rn")

    rollup.toDF()
  }
}
