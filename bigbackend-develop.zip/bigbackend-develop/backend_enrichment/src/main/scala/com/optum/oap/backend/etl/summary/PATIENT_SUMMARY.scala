package com.optum.oap.backend.etl.summary

import com.optum.oap.backend.etl.common.CDRConstants
import com.optum.oap.cdr.models.patient_summary
import com.optum.oap.sparkdataloader.{RuntimeVariables, TableInfo, UserDefinedFunctionForDataLoader}
import org.apache.spark.sql.expressions.Window
import org.apache.spark.sql.functions._
import org.apache.spark.sql.types.StringType
import org.apache.spark.sql.{DataFrame, SparkSession}
import org.slf4j.LoggerFactory

object PATIENT_SUMMARY extends TableInfo[patient_summary] {
  val log = LoggerFactory.getLogger(this.getClass)
  override def dependsOn =  Set("PATIENT", "PATIENTDETAIL", "PATIENT_ID", "REF_LADMF", "ZCM_DATASRC_PRIORITY", "MAP_GENDER",
    "MAP_RACE", "MAP_ETHNICITY","MAP_DECEASED_INDICATOR" ,"MAP_LANGUAGE" ,"MAP_MARITAL_STATUS")

  override def name = "PATIENT_SUMMARY"

  override def saveDataFrameToParquet: Boolean = true
  override def partitions: Int = 256
  override def skipTable: Boolean = false
  override def ignoreExtraColumnsInDataFrame: Boolean = false

  override def createDataFrame (sparkSession: SparkSession,
                                loadedDependencies: Map[String, DataFrame],
                                udfMap: Map[String, UserDefinedFunctionForDataLoader],
                                runtimeVariables: RuntimeVariables): DataFrame = {
    import sparkSession.implicits._

    val temp_patient = loadedDependencies("PATIENT")
    val temp_patientdetail =loadedDependencies("PATIENTDETAIL")
    val temp_patient_id = loadedDependencies("PATIENT_ID")
    val ref_ladmf = loadedDependencies("REF_LADMF")
    val zcm_datasrc_priority = loadedDependencies("ZCM_DATASRC_PRIORITY")
    val map_gender  = loadedDependencies("MAP_GENDER")
      .withColumnRenamed("GROUPID", "GROUPID_mg")
    val map_race = loadedDependencies("MAP_RACE")
      .withColumnRenamed("GROUPID", "GROUPID_mr")
    val map_ethnicity = loadedDependencies("MAP_ETHNICITY")
      .withColumnRenamed("GROUPID", "GROUPID_me")
    val map_deceased_indicator = loadedDependencies("MAP_DECEASED_INDICATOR")
      .withColumnRenamed("GROUPID", "GROUPID_mdi")
    val map_language = loadedDependencies("MAP_LANGUAGE")
      .withColumnRenamed("GROUPID", "GROUPID_ml")
    val map_marital_status = loadedDependencies("MAP_MARITAL_STATUS")
      .withColumnRenamed("GROUPID", "GROUPID_mms")

    val priority_pat = Window
      .partitionBy($"GROUPID", $"CLIENT_DS_ID", $"PATIENTID")
      .orderBy($"PRIORITY")
    val priority_detail = Window
      .partitionBy($"GROUPID", $"CLIENT_DS_ID", $"PATIENTID")
      .orderBy($"PATDETAIL_TIMESTAMP".desc, $"DATASRC".desc)
    val priority_detail_cui = Window
      .partitionBy($"GROUPID", $"CLIENT_DS_ID", $"PATIENTID")
      .orderBy(when($"CUI".isNotNull, "0").otherwise("1"), $"PATDETAIL_TIMESTAMP".desc, $"DATASRC".desc)

    val priority_detail_race_cui = Window
      .partitionBy($"GROUPID", $"CLIENT_DS_ID", $"PATIENTID")
      .orderBy(when($"CUI".isNotNull, "0").otherwise("1"),
        when($"CUI" === "CH999999", 0).when($"CUI" === "CH999990", 1).when($"CUI" === "CH000056", 2).otherwise(3).desc,
        $"PATDETAIL_TIMESTAMP".desc,
        $"DATASRC".desc,
        when($"CUI" === lit("CH001643"), "0").otherwise("1") // if there is already a multiracial, pick this one first
      )

    val temp_pat = temp_patient
      .join(broadcast(zcm_datasrc_priority), Seq("GROUPID", "CLIENT_DS_ID", "DATASRC"), "left_outer")
      .withColumn("rank", dense_rank.over(priority_pat))
      .withColumn("DISPLAY_ID", lit(null).cast(StringType))

    val pat = temp_pat
      .groupBy("GROUPID", "CLIENT_DS_ID", "PATIENTID", "GRP_MPI", "HGPID", "DISPLAY_ID")
      .agg(
        min(when($"rank" === 1, $"DATEOFBIRTH")).as("DATEOFBIRTH"),
        max(when($"rank" === 1, $"DATEOFDEATH")).as("DATEOFDEATH"),
        max(when($"rank" === 1, $"MEDICALRECORDNUMBER")).as("MEDICALRECORDNUMBER"),
        max($"INACTIVE_FLAG").as("INACTIVE_FLAG")
      )

    val temp_gender = temp_patientdetail
      .filter("patientdetailtype = 'GENDER'")
      .join(broadcast(map_gender), temp_patientdetail("LOCALVALUE") === map_gender("MNEMONIC") && temp_patientdetail("GROUPID") === map_gender("GROUPID_mg"), "left_outer")
      .withColumn("rank", dense_rank.over(priority_detail_cui))
    val gender = temp_gender
      .groupBy("GROUPID", "CLIENT_DS_ID", "PATIENTID")
      .agg(
        max(when($"rank" === 1, $"LOCALVALUE")).as("GENDER"),
        max(when($"rank" === 1, $"CUI")).as("GENDER_CUI")
      )

    val temp_race = temp_patientdetail
         .filter("patientdetailtype = 'RACE'")
         .join(broadcast(map_race), temp_patientdetail("LOCALVALUE") === map_race("MNEMONIC") && temp_patientdetail("GROUPID") === map_race("GROUPID_mr"), "left_outer")
         .withColumn("rank", dense_rank.over(priority_detail_race_cui))

    // just to get distinct count for the top rank rows
    val temp_race_count = temp_race
      .where($"rank" === 1)
      .groupBy("GROUPID", "CLIENT_DS_ID", "PATIENTID")
      .agg(
        countDistinct($"CUI").as("rank_one_distinct_count")
      )

    val race = temp_race.as("tr").where($"rank" === 1)
        .join(temp_race_count.as("trc"),  Seq("GROUPID", "CLIENT_DS_ID", "PATIENTID") )
        .groupBy("tr.GROUPID", "tr.CLIENT_DS_ID", "tr.PATIENTID")
        .agg(
          max(when($"trc.rank_one_distinct_count" === 1 || $"trc.rank_one_distinct_count" === 0, $"LOCALVALUE")
            .otherwise(when($"trc.rank_one_distinct_count" > 1, lit("Multiple races reported")))
           ).as("RACE"),
          max(when($"trc.rank_one_distinct_count" === 1 || $"trc.rank_one_distinct_count" === 0, $"CUI")
            .otherwise(when($"trc.rank_one_distinct_count" > 1, lit("CH001643")))
          ).as("RACE_CUI"),
          max(when($"trc.rank_one_distinct_count" === 1 || $"trc.rank_one_distinct_count" === 0, lit(0))
            .otherwise(when($"trc.rank_one_distinct_count" > 1, lit(1)))
          ).as("MRACE_INFER_IND")
        )

    val temp_ethnicity = temp_patientdetail
      .filter("patientdetailtype = 'ETHNICITY'")
      .join(broadcast(map_ethnicity), temp_patientdetail("LOCALVALUE") === map_ethnicity("MNEMONIC") && temp_patientdetail("GROUPID") === map_ethnicity("GROUPID_me"), "left_outer")
      .withColumn("rank", dense_rank.over(priority_detail_cui))
    val ethnicity = temp_ethnicity
      .groupBy("GROUPID", "CLIENT_DS_ID", "PATIENTID")
      .agg(
        max(when($"rank" === 1, $"LOCALVALUE")).as("ETHNICITY"),
        max(when($"rank" === 1, $"CUI")).as("ETHNICITY_CUI")
      )

    val temp_firstName = temp_patientdetail
      .filter("patientdetailtype = 'FIRST_NAME'")
      .withColumn("rank", dense_rank.over(priority_detail))
    val firstName = temp_firstName
      .groupBy("GROUPID", "CLIENT_DS_ID", "PATIENTID")
      .agg(max(when($"rank" === 1, $"LOCALVALUE")).as("FIRST_NAME"))
      .withColumn("FIRST_NAME_mod", substring(regexp_replace(regexp_replace(upper($"FIRST_NAME"), " (SR|JR)?", ""), "\\p{Space}*\\p{Punct}", ""), 1, 15))

    val temp_lastName = temp_patientdetail
      .filter("patientdetailtype = 'LAST_NAME'")
      .withColumn("rank", dense_rank.over(priority_detail))
    val lastName = temp_lastName
      .groupBy("GROUPID", "CLIENT_DS_ID", "PATIENTID")
      .agg(max(when($"rank" === 1, $"LOCALVALUE")).as("LAST_NAME"))
      .withColumn("LAST_NAME_mod", substring(regexp_replace(regexp_replace(upper($"LAST_NAME"), " (SR|JR)?", ""), "\\p{Space}*\\p{Punct}", ""), 1, 15))

    val temp_middleName = temp_patientdetail
      .filter("patientdetailtype = 'MIDDLE_NAME'")
      .withColumn("rank", dense_rank.over(priority_detail))
    val middleName = temp_middleName
      .groupBy("GROUPID", "CLIENT_DS_ID", "PATIENTID")
      .agg(max(when($"rank" === 1, $"LOCALVALUE")).as("MIDDLE_NAME"))
      .withColumn("MIDDLE_NAME", substring(regexp_replace(regexp_replace(upper($"MIDDLE_NAME"), " (SR|JR)?", ""), "\\p{Space}*\\p{Punct}", ""), 1, 15))

    val temp_religion = temp_patientdetail
      .filter("patientdetailtype = 'RELIGION'")
      .withColumn("rank", dense_rank.over(priority_detail))
    val religion = temp_religion
      .groupBy("GROUPID", "CLIENT_DS_ID", "PATIENTID")
      .agg(max(when($"rank" === 1, $"LOCALVALUE")).as("RELIGION"))

    val temp_zipcode = temp_patientdetail
      .filter("patientdetailtype = 'ZIPCODE'")
      .withColumn("rank", dense_rank.over(priority_detail))
    val zipcode = temp_zipcode
      .groupBy("GROUPID", "CLIENT_DS_ID", "PATIENTID")
      .agg(max(when($"rank" === 1, $"LOCALVALUE")).as("ZIPCODE"))

    val temp_deceased = temp_patientdetail
      .filter("patientdetailtype = 'DECEASED'")
      .join(broadcast(map_deceased_indicator), coalesce(temp_patientdetail("LOCALVALUE"), lit("DEFAULT")) === map_deceased_indicator("MNEMONIC") && temp_patientdetail("GROUPID") === map_deceased_indicator("GROUPID_mdi"), "left_outer")
      .withColumn("rank", dense_rank.over(priority_detail_cui))
    val deceased = temp_deceased
      .groupBy("GROUPID", "CLIENT_DS_ID", "PATIENTID")
      .agg(
        max(when($"rank" === 1, $"LOCALVALUE")).as("DECEASED"),
        max(when($"rank" === 1, $"CUI")).as("DECEASED_CUI")
      )

    val temp_language = temp_patientdetail
      .filter("patientdetailtype = 'LANGUAGE'")
      .join(broadcast(map_language), temp_patientdetail("LOCALVALUE") === map_language("MNEMONIC") && temp_patientdetail("GROUPID") === map_language("GROUPID_ml"), "left_outer")
      .withColumn("rank", dense_rank.over(priority_detail_cui))
    val language = temp_language
      .groupBy("GROUPID", "CLIENT_DS_ID", "PATIENTID")
      .agg(
        max(when($"rank" === 1, $"LOCALVALUE")).as("LANGUAGE"),
        max(when($"rank" === 1, $"CUI")).as("LANGUAGE_CUI")
      )

    val temp_marital = temp_patientdetail
      .filter("patientdetailtype = 'MARITAL'")
      .join(broadcast(map_marital_status), temp_patientdetail("LOCALVALUE") === map_marital_status("LOCAL_CODE") && temp_patientdetail("GROUPID") === map_marital_status("GROUPID_mms"), "left_outer")
      .withColumn("rank", dense_rank.over(priority_detail_cui))
    val marital = temp_marital
      .groupBy("GROUPID", "CLIENT_DS_ID", "PATIENTID")
      .agg(
        max(when($"rank" === 1, $"LOCALVALUE")).as("MARITAL_STATUS"),
        max(when($"rank" === 1, $"CUI")).as("MARITAL_STATUS_CUI")
      )

    val ssn = temp_patient_id
      .filter("idtype = 'SSN'")
      .groupBy("GROUPID", "CLIENT_DS_ID", "PATIENTID")
      .agg(
        min(translate($"IDVALUE", "-", "")).as("SSN"),
        countDistinct(translate($"IDVALUE", "-", "")).as("CNT_SSN")
      )
      .filter("cnt_ssn = 1")
      .drop("cnt_ssn")

    val ssdi_n = ref_ladmf
      .filter("match_name = 'N'")
      .select(
        $"SSN".as("SSN_ssdi_n"),
        $"FIRST_NAME".as("FIRST_NAME_ssdi_n"),
        $"LAST_NAME".as("LAST_NAME_ssdi_n"),
        $"DOB".as("DOB_ssdi_n"),
        $"DATE_OF_DEATH".as("DATEOFDEATH_ssdi_n")
      )

    val ssdi_y = ref_ladmf
      .filter("match_name = 'Y'")
      .select(
        $"SSN".as("SSN_ssdi_y"),
        $"FIRST_NAME".as("FIRST_NAME_ssdi_y"),
        $"LAST_NAME".as("LAST_NAME_ssdi_y"),
        $"DOB".as("DOB_ssdi_y"),
        $"DATE_OF_DEATH".as("DATEOFDEATH_ssdi_y")
      )

    pat
      .join(gender, Seq("GROUPID", "CLIENT_DS_ID", "PATIENTID"), "left_outer")
      .join(race, Seq("GROUPID", "CLIENT_DS_ID", "PATIENTID"), "left_outer")
      .join(ethnicity, Seq("GROUPID", "CLIENT_DS_ID", "PATIENTID"), "left_outer")
      .join(firstName, Seq("GROUPID", "CLIENT_DS_ID", "PATIENTID"), "left_outer")
      .join(lastName, Seq("GROUPID", "CLIENT_DS_ID", "PATIENTID"), "left_outer")
      .join(middleName, Seq("GROUPID", "CLIENT_DS_ID", "PATIENTID"), "left_outer")
      .join(religion, Seq("GROUPID", "CLIENT_DS_ID", "PATIENTID"), "left_outer")
      .join(zipcode, Seq("GROUPID", "CLIENT_DS_ID", "PATIENTID"), "left_outer")
      .join(deceased, Seq("GROUPID", "CLIENT_DS_ID", "PATIENTID"), "left_outer")
      .join(language, Seq("GROUPID", "CLIENT_DS_ID", "PATIENTID"), "left_outer")
      .join(marital, Seq("GROUPID", "CLIENT_DS_ID", "PATIENTID"), "left_outer")
      .join(ssn, Seq("GROUPID", "CLIENT_DS_ID", "PATIENTID"), "left_outer")
      .join(ssdi_n, ssn("SSN") === ssdi_n("SSN_ssdi_n") && date_format(pat("DATEOFBIRTH"), CDRConstants.DATE_FORMAT_4Y2M2D).cast("String") === ssdi_n("DOB_ssdi_n"), "left_outer")
      .join(ssdi_y, ssn("SSN") === ssdi_y("SSN_ssdi_y") && date_format(pat("DATEOFBIRTH"), CDRConstants.DATE_FORMAT_4Y2M2D).cast("String") === ssdi_y("DOB_ssdi_y") && firstName("FIRST_NAME_mod") === ssdi_y("FIRST_NAME_ssdi_y") && lastName("LAST_NAME_mod") === ssdi_y("LAST_NAME_ssdi_y"), "left_outer")
      .select($"GROUPID", $"CLIENT_DS_ID", $"PATIENTID", $"MEDICALRECORDNUMBER", $"DISPLAY_ID", $"GRP_MPI",
        $"HGPID", $"INACTIVE_FLAG", lastName("LAST_NAME"), middleName("MIDDLE_NAME"), $"RELIGION", firstName("FIRST_NAME"),
        year($"DATEOFBIRTH").cast("String").as("YOB"),
        date_format($"DATEOFBIRTH", "yyyyMM").cast("String").as("MOB"),
        date_format($"DATEOFBIRTH", CDRConstants.DATE_FORMAT_4Y2M2D).cast("String").as("DOB"),
        coalesce($"DATEOFDEATH_ssdi_y", $"DATEOFDEATH_ssdi_n", $"DATEOFDEATH").as("DATE_OF_DEATH"),
        when(coalesce($"DATEOFDEATH_ssdi_y", $"DATEOFDEATH_ssdi_n").isNotNull, "Y").otherwise("N").as("SSDI_DOD"),
        when(coalesce($"FIRST_NAME_ssdi_n", $"FIRST_NAME_ssdi_y") === $"FIRST_NAME_mod" && coalesce($"LAST_NAME_ssdi_n", $"LAST_NAME_ssdi_y") === $"LAST_NAME_mod", "Y").otherwise("N").as("SSDI_NAME_MATCH"),
        when(trim($"ZIPCODE").isNull, lit("CH999999"))
          .when($"ZIPCODE" === lit("00000") || !$"ZIPCODE".between("00601", "99950"), lit("CH999990"))
          .when($"ZIPCODE".rlike("\\p{Space}*(([A-Z][0-9]|[a-z][0-9]){3}\\p{Space}*)"), trim($"ZIPCODE"))
          .when(!translate($"ZIPCODE", "O", "0").rlike("\\p{Space}*([0-9]{5}([- ]?[0-9]{4})?)\\p{Space}*"), lit("CH999990"))
          .otherwise(regexp_extract(translate($"ZIPCODE", "O", "0"), "\\p{Space}*([0-9]{5})([- ]?[0-9]{4})?\\p{Space}*", 1))
          .as("MAPPED_ZIPCODE"),
        coalesce($"DECEASED_CUI", lit("CH999999"))
          .as("MAPPED_DEATH_IND"),
        when(coalesce($"GENDER", $"GENDER_CUI").isNull, lit("CH999999"))
          .when($"GENDER".isNotNull && $"GENDER_CUI".isNull, lit("CH999990"))
          .otherwise($"GENDER_CUI")
          .as("MAPPED_GENDER"),
        when(coalesce($"ETHNICITY", $"ETHNICITY_CUI").isNull, lit("CH999999"))
          .when($"ETHNICITY".isNotNull && $"ETHNICITY_CUI".isNull, lit("CH999990"))
          .otherwise($"ETHNICITY_CUI")
          .as("MAPPED_ETHNICITY"),
        when(coalesce($"RACE", $"RACE_CUI").isNull, lit("CH999999"))
          .when($"RACE".isNotNull && $"RACE_CUI".isNull, lit("CH999990"))
          .otherwise($"RACE_CUI")
          .as("MAPPED_RACE"),
        when(coalesce($"LANGUAGE", $"LANGUAGE_CUI").isNull, lit("CH999999"))
          .when($"LANGUAGE".isNotNull && $"LANGUAGE_CUI".isNull, lit("CH999990"))
          .otherwise($"LANGUAGE_CUI")
          .as("MAPPED_LANGUAGE"),
        when(coalesce($"MARITAL_STATUS", $"MARITAL_STATUS_CUI").isNull, lit("CH999999"))
          .when($"MARITAL_STATUS".isNotNull && $"MARITAL_STATUS_CUI".isNull, lit("CH999990"))
          .otherwise($"MARITAL_STATUS_CUI")
          .as("MAPPED_MARITAL_STATUS"),
        $"DATEOFDEATH".as("LOCAL_DOD"),
        $"GENDER".as("LOCAL_GENDER"),
        $"RACE".as("LOCAL_RACE"),
        $"ETHNICITY".as("LOCAL_ETHNICITY"),
        $"ZIPCODE".as("LOCAL_ZIPCODE"),
        $"LANGUAGE".as("LOCAL_LANGUAGE"),
        $"MARITAL_STATUS".as("LOCAL_MARITAL_STATUS"),
        $"DECEASED".as("LOCAL_DEATH_IND"),
        race("MRACE_INFER_IND").as("MRACE_INFER_IND")
      )
  }
}