package com.optum.oap.backend.etl.enrichment

import com.optum.oap.backend.etl.common.Functions.mpvList
import org.apache.spark.sql.functions.{broadcast, column, lit, regexp_replace, trim, when}
import org.apache.spark.sql.{DataFrame, SparkSession}

trait INT_CLAIM_CLEANUP {

  def regexReplaceColumns: Set[String]

  def cleanUp(groupId: String, mapPredicateValues: DataFrame, intClaimDataFrame: DataFrame): DataFrame = {
    import mapPredicateValues.sparkSession.implicits._

    val mpv = mpvList(broadcast(mapPredicateValues),
      groupId,
      null,
      "PAYER_MAPS_INT_TABLES",
      "PAYER_MAPS_INT_TABLES",
      "PAYER_MAPS_INT_TABLES",
      "PAYER_MAPS_INT_TABLES"
    ).mkString(",")

    val remainingColumns = intClaimDataFrame.columns.filter(col => !regexReplaceColumns.contains(col)).map(col => column(col))
    val regexColumns = regexReplaceColumns.map(col => {
      when(lit("'Y'").isin(mpv), trim(regexp_replace($"$col", "[^A-Z-a-z0-9 .;!()*-_<>&#%$~\"{}\t]", "")))
        .otherwise($"$col").as(s"$col")
    })

    val fullList = remainingColumns ++ regexColumns.toSeq

    intClaimDataFrame.select(fullList: _*)
  }

}
