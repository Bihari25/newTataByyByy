package com.optum.oap.backend.etl.enrichment

import com.optum.oap.backend.cdrTempModel.temp_icpm_patient_patientdetail_patientcontact
import com.optum.oap.cdr.models.patientcontact
import com.optum.oap.sparkdataloader.{RuntimeVariables, TableInfo, UserDefinedFunctionForDataLoader}
import org.apache.spark.sql.functions._
import org.apache.spark.sql.types.DataTypes
import org.apache.spark.sql.{DataFrame, SparkSession}
import org.slf4j.LoggerFactory

object ICPM_PATIENT_CONTACT
  extends TableInfo[patientcontact] {

  private val log = LoggerFactory.getLogger(this.getClass)

  override def dependsOn = Set("ICPM_PATIENT_INTERMEDIATE")

  override def name = "ICPM_PATIENT_CONTACT"

  override def partitions: Int = 32

  override def createDataFrame(sparkSession: SparkSession,
                               loadedDependencies: Map[String, DataFrame],
                               udfMap: Map[String, UserDefinedFunctionForDataLoader],
                               runtimeVariables: RuntimeVariables): DataFrame = {

    import sparkSession.implicits._

    val cdrFePatientIntermediate = loadedDependencies("ICPM_PATIENT_INTERMEDIATE")
      .as[temp_icpm_patient_patientdetail_patientcontact]

    cdrFePatientIntermediate.filter(
      col("rank_con") === lit(1)
        and $"patientid".isNotNull
        and coalesce(col("home_phone"), col("personal_email")).isNotNull
    ).select(
      col("groupid"),
      col("client_ds_id"),
      col("datasrc"),
      col("patientid"),
      when(col("lastupdateddate").isNotNull, col("lastupdateddate"))
        .otherwise(current_timestamp()).as("update_dt"),
      col("home_phone"),
      col("personal_email"),

      lit(null).cast(DataTypes.StringType).as("cell_phone"),
      lit(null).cast(DataTypes.StringType).as("work_email"),
      lit(null).cast(DataTypes.StringType).as("grp_mpi"),
      lit(null).cast(DataTypes.StringType).as("work_phone"),
      lit(null).cast(DataTypes.LongType).as("hgpid"),
      lit(null).cast(DataTypes.StringType).as("preferred_comm_channel")

    )


  }

}
