package com.optum.oap.backend.etl.common

import java.util.Calendar

import com.optum.oap.utils.Resource.using
import org.apache.spark.sql.DataFrame
import org.rogach.scallop.{ScallopConf, ScallopOption}
import org.slf4j.LoggerFactory

import scala.io.Source

object EnrichmentUtils {

  class EnrichmentConf(arguments: Seq[String]) extends ScallopConf(arguments) {
    banner(
      """
        |Usage: ./be-summary.sh --cdrSchema <hive_db> --executorThreads <number_of_threads> --clientId <client_id>
        |--environment <environment> -- cdrLevel <cdr_level> --cdrCycle <cdr_cycle> --instance <instance>
        |--targetTables <target_tables> --loadGroups encgrps,summary
        |[--clientBucket <s3 Bucket>]
        |[--fullRun]
        |[--mercuryStage]
      """.stripMargin)

    val clientBucket: ScallopOption[String] = opt[String](required = false, name = "clientBucket", argName = "clientBucket", descr = "for AWS runs, the s3 bucket of the client's data")
    val cdrSchema: ScallopOption[String] = opt[String](required = true, name = "cdrSchema", argName = "cdrSchema", descr = "Source CDR hive schema name for enrichment process")
    val clientId: ScallopOption[String] = opt[String](required = true, name = "clientId", argName = "clientId", descr = "OADW ClientId e.g. H704847")
    val environment: ScallopOption[String] = opt[String](required = true, name = "environment", argName = "environment", descr = "Environment (dev|prd|qa|stg)")
    val cdrCycle: ScallopOption[String] = opt[String](required = true, name = "cdrCycle", argName = "cdrCycle", descr = "CDR cycle : monthly vs delta")
    val cdrLevel: ScallopOption[String] = opt[String](required = true, name = "cdrLevel", argName = "cdrLevel", descr = "CDR level value : ecdr vs cdr_be")
    val instance: ScallopOption[String] = opt[String](required = true, name = "instance", argName = "instance", descr = "instance name e.g. CDR_201811")
    val buildType: ScallopOption[String] = opt[String](required = false, name = "buildType", argName = "buildType", descr = "Type of the build, Monthly vs Delta", default = Some("Monthly"))
    val fullHiveDb: ScallopOption[String] = opt[String](required = false, name = "fullHiveDb", argName = "fullHiveDb", descr = "Ecdr database")
    val release: ScallopOption[String] = opt[String](required = true, name = "release", argName = "release", descr = "release name in YYYYMM format e.g. 201811")
    val targetTables: ScallopOption[String] = opt[String](required = false, name = "targetTables", argName = "targetTables", descr = "Comma separated list of target ETLs to load")
    val executorThreads: ScallopOption[Int] = opt[Int](required = false, name = "executorThreads", argName = "executorThreads", descr = "Number of threads for ETL futures", default = Some(5))
    val loadGroups: ScallopOption[String] = opt[String](required = false, name = "loadGroups", argName = "loadGroups", descr = "Comma delimited list groups to run. Choose from: (cdrfe/ combined / encgrps / summary / enrichment). Default is all", default = Some("all"))
    val getDependencyGraph: ScallopOption[Boolean] = opt[Boolean](required = false, name = "getDependencyGraph", argName = "getDependencyGraph", descr = "Prints dependency graph of the tables being processed without running the loader", default = Some(false))
    val partitionMultiplier: ScallopOption[Double] = opt[Double](required = false, name = "partitionMultiplier", argName = "partitionMultiplier", descr = "Partition multiplier that aids repartitioning of the datasets based on client size", default = Some(1))
    val fullRun: ScallopOption[Boolean] = opt[Boolean](required = false, name = "fullRun", argName = "fullRun", descr = "Removes all prior checkpoints and restarts Run from the beginning", default = Some(false))
    val mercuryStage: ScallopOption[Boolean] = opt[Boolean](required = false, name = "mercuryStage", argName = "mercuryStage", descr = "Import CDRFE data from mercury-stage instead of default mercury location", default = Some(false))
    val dailyEndDate: ScallopOption[String] = opt[String](required = false, name = "endDate", argName = "endDate", descr = "End date for daily builds. Value should be in YYYYMMDD format", default = None)

    verify()

    override def toString: String =
      s"""Enrichment Config:
         |clientBucket: ${cdrSchema.getOrElse("<unspecified>")}
         |cdrSchema: ${cdrSchema.getOrElse("<unspecified>")}
         |clientId: ${clientId.getOrElse("<unspecified>")}
         |env: ${environment.getOrElse("<unspecified>")}
         |cdr_level: ${cdrLevel.getOrElse("<unspecified>")}
         |cdr_cycle: ${cdrCycle.getOrElse("<unspecified>")}
         |instance: ${instance.getOrElse("<unspecified>")}
         |buildType: ${buildType.getOrElse("Monthly")}
         |fullDeltaHiveDb: ${fullHiveDb.getOrElse("<unspecified>")}
         |release: ${release.getOrElse("<unspecified>")}
         |targetTables: ${targetTables.getOrElse("<unspecified>")}
         |executorThreads: ${executorThreads.getOrElse(5)}
         |loadGroups: ${loadGroups.getOrElse("<unspecified>")}
         |getDependencyGraph: ${getDependencyGraph.getOrElse(false)}
         |partitionMultiplier: ${partitionMultiplier.getOrElse(1)}
         |fullRun: ${fullRun.getOrElse(false)}
         |mercuryStage: ${mercuryStage.getOrElse(false)}
         |endDate: ${dailyEndDate.getOrElse("<unspecified>")}
     """.stripMargin
  }


  // returns dataframe by removing row_source and modfied_date columns.
  def removeRowSourceAndModifiedDate(input: DataFrame): DataFrame = {
    val cols = input.columns
    val ingoreColumns = Seq("row_source", "modified_date")
    val colsToSelect = cols.filterNot(ingoreColumns.contains(_))
    input.select(colsToSelect.head, colsToSelect.tail: _*)
  }

  def getPreviousRelease(releaseCycle: String, amount: Int = -1): Option[String] = {
    // if non numeric, it is probably test/stg.
    val isNumericAnd6Digit = releaseCycle.matches("\\d{6}")
    if (!isNumericAnd6Digit) None
    else {
      val formatter = new java.text.SimpleDateFormat("yyyyMM")
      val cal = Calendar.getInstance()
      cal.setTime(formatter.parse(releaseCycle))
      cal.add(Calendar.MONTH, amount)
      Some(formatter.format(cal.getTime))
    }
  }

  private val log = LoggerFactory.getLogger(this.getClass)

  def getCDRProperties(): Map[String, Option[String]] = {

    try {
      using(getClass.getResourceAsStream("/version.properties"))(inputStream => {
        val lines = Source.fromInputStream(inputStream).getLines().toList
        Source.fromInputStream(inputStream).close

        val versionMap = collection.mutable.Map[String, Option[String]]()

        lines.foreach(x => versionMap(x.split("=")(0)) = Some(x.substring(x.lastIndexOf("=") + 1)))

        Map(
          "CDR_VERSION" -> Some(versionMap("version")).getOrElse(None),
          "CDR_CONTRACT_VERSION" -> Some(versionMap("cdr_contract_version")).getOrElse(None)
        )
      })
    } catch {
      case e: Exception => {
        log.error(e.getMessage)
        Map()
      }
    }
  }
}
