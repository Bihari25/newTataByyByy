
package com.optum.oap.backend.etl.encgrps

import com.optum.oap.backend.cdrTempModel.temp_encounter_prinpx
import com.optum.oap.sparkdataloader.QueryAndMetadata


object TEMP_ENCOUNTER_PRINPX extends QueryAndMetadata[temp_encounter_prinpx] {
  override def name: String = "TEMP_ENCOUNTER_PRINPX"

  override def sparkSql: String =
    """
      |select  px.groupid, eeg.grp_mpi, ENCOUNTER_GRP_NUM, px.encounterid, px.client_ds_id, px.datasrc as px_datasrc, mappedcode, proceduredate
      |, max(localprincipleindicator) as localprincipleindicator, encounteridtype
      |, coalesce(codetype,'ICD9') as codetype
      |, case when codetype = 'ICD10' then '0' else '9' end as icd_ver
      |from
      |PROCEDUREDO px
      |inner join ENCOUNTER_ENCOUNTER_GRP eeg on (px.groupid = eeg.groupid and px.encounterid = eeg.encounterid and px.client_ds_id = eeg.client_ds_id)
      |and codetype in ('ICD9', 'ICD10')
      |and mappedcode is not null
      |and length(mappedcode) < 8
      |and hosp_px_flag = 'Y'
      |group by px.groupid, eeg.grp_mpi, ENCOUNTER_GRP_NUM, px.encounterid, px.client_ds_id, px.datasrc, mappedcode, proceduredate, encounteridtype
      |, coalesce(codetype,'ICD9'), case when codetype = 'ICD10' then '0' else '9' end
    """.stripMargin

  override def dependsOn: Set[String] = Set("PROCEDUREDO", "ENCOUNTER_ENCOUNTER_GRP")
}