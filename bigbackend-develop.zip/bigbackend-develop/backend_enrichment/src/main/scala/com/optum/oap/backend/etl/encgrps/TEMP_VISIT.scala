
package com.optum.oap.backend.etl.encgrps

import com.optum.oap.backend.cdrTempModel.temp_visit
import com.optum.oap.sparkdataloader.QueryAndMetadata

object TEMP_VISIT extends QueryAndMetadata[temp_visit] {
  override def name: String = "TEMP_VISIT"

  override def sparkSql: String =
    """
      |select
      |groupid,
      |grp_mpi,
      |TimestampTruncate('DAY', admittime) as admitip,
      |max(dischargetime) as dischip
      |from TEMP_VISIT_ENCTR
      |where patienttype = 'CH000106'
      |group by groupid, grp_mpi
      |, TimestampTruncate('DAY', admittime)
    """.stripMargin

  override def dependsOn: Set[String] = Set("TEMP_VISIT_ENCTR")
}