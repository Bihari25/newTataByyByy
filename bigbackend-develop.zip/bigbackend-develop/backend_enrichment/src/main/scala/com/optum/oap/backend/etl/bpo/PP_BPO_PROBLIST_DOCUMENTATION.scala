package com.optum.oap.backend.etl.bpo

import com.optum.oap.backend.cdrTempModel.{temp_bpo_calculate_params, temp_bpo_patients}
import com.optum.oap.backend.etl.common.{Functions, TimestampTruncate}
import com.optum.oap.cdr.models._
import com.optum.oap.sparkdataloader.{RuntimeVariables, TableInfo, UserDefinedFunctionForDataLoader}
import org.apache.spark.sql.expressions.Window
import org.apache.spark.sql.functions.{row_number, _}
import org.apache.spark.sql.types.{DateType, StringType}
import org.apache.spark.sql.{DataFrame, SparkSession}

object PP_BPO_PROBLIST_DOCUMENTATION extends TableInfo[pp_bpo_problist_documentation] {

  override def dependsOn = Set("TEMP_BPO_CALCULATE_PARAMS", "TEMP_BPO_PATIENTS", "DIAGNOSIS", "MAP_PROB_LIST")

  override def name = "PP_BPO_PROBLIST_DOCUMENTATION"

  override def createDataFrame(sparkSession: SparkSession,
                               loadedDependencies: Map[String, DataFrame],
                               udfMap: Map[String, UserDefinedFunctionForDataLoader],
                               runtimeVariables: RuntimeVariables): DataFrame = {

    import sparkSession.implicits._

    val tempBpoPatients = loadedDependencies("TEMP_BPO_PATIENTS").as[temp_bpo_patients]
    val diag = loadedDependencies("DIAGNOSIS").as[diagnosis]
    val mapProbList = broadcast(loadedDependencies("MAP_PROB_LIST")).as[map_prob_list]
    val tempBpoParams_DS = broadcast(loadedDependencies("TEMP_BPO_CALCULATE_PARAMS")).as[temp_bpo_calculate_params]

    val input = BpoUtil.getBpoInputParameters(sparkSession, tempBpoParams_DS)
    val extractStartDate = to_timestamp(lit(input.engineStartDate))
    val extractEndDate = to_timestamp(lit(input.engineEndDate))

    val pat =
      tempBpoPatients
        .select(
          $"groupid",
          $"grp_mpi",
          $"payer",
          row_number().over(Window.partitionBy($"groupid", $"grp_mpi")
            .orderBy($"payer".desc)).as("rw_id")
        )

    val dgn =
    diag.as("dx")
      .join(mapProbList.as("mpl"), Seq("groupid", "datasrc"), "inner")
      .where($"mpl.is_problemlist" === lit("Y")
        and $"dx.codetype".isin(lit("ICD9"), lit("ICD10"))
        and length($"dx.mappeddiagnosis").between(lit(3), lit(8))
        and TimestampTruncate.truncate(lit("DAY"), $"dx.dx_timestamp").between(extractStartDate, extractEndDate)
      )
      .select(
    $"dx.groupid",
    $"dx.client_ds_id",
    $"dx.grp_mpi",
    $"dx.codetype",
    $"dx.mappeddiagnosis".as("diagnosis_code"),
          TimestampTruncate.truncate(lit("DAY"), $"dx.dx_timestamp").as("problem_start_date"),
          TimestampTruncate.truncate(lit("DAY"), $"dx.resolutiondate").as("problem_resolved_date"),
          when($"dx.codetype" === lit("ICD9"), lit("ICD-9-CM"))
            .when($"dx.codetype" === lit("ICD10"), lit("ICD-10-CM")).as("diagnosis_taxonomy")
      )

    val pd = dgn.as("dgn")
      .join(pat.as("pat"), Seq("groupid", "grp_mpi"), "inner")
      .where($"pat.rw_id" === lit(1))
      .select(
    $"dgn.groupid"
        , $"dgn.client_ds_id"
        , $"dgn.grp_mpi"
        , $"dgn.diagnosis_taxonomy"
        , $"dgn.diagnosis_code"
        , $"dgn.problem_start_date"
        , $"dgn.problem_resolved_date"
        , when($"pat.payer" === lit(1), lit("PAYER")).otherwise("PROVIDER").as("healthplansource")
      ).distinct

    val withRowNumberDf = Functions.appendRowNumberToDataframe(sparkSession, pd, rowNumberName = "rownum")

    withRowNumberDf.select(
      'groupid
      , 'grp_mpi.cast(StringType).as("memberid")
      , concat(lit("PBL"), 'client_ds_id.cast(StringType), lit("."), 'rownum.cast(StringType)).as("problem_list_id")
      , 'diagnosis_taxonomy
      , 'diagnosis_code
      , 'problem_start_date
      , 'problem_resolved_date
      , 'healthplansource
    )
  }
}
