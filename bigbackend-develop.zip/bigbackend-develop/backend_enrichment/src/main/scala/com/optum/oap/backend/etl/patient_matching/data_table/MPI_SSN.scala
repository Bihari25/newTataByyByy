package com.optum.oap.backend.etl.patient_matching.data_table

import com.optum.oap.backend.cdrTempModel.pat_match_prep
import com.optum.oap.backend.etl.common.{CDRConstants, CleanPatientName, EnrichmentUtils, SSNValidation}
import com.optum.oap.backend.loader.EnrichmentRunTimeVariables
import com.optum.oap.cdr.models.{mpi_ssn, patient_id}
import com.optum.oap.sparkdataloader.{RuntimeVariables, TableInfo, UserDefinedFunctionForDataLoader}
import org.apache.spark.sql.expressions.Window
import org.apache.spark.sql.functions._
import org.apache.spark.sql.types.{LongType, StringType}
import org.apache.spark.sql.{DataFrame, SparkSession}

object MPI_SSN extends TableInfo[mpi_ssn]{

  override def dependsOn: Set[String] = Set("PATIENT_ID_PREMATCH", "PAT_MATCH_PREP", "ECDR_MPI_SSN")

  override def name = "MPI_SSN"

  override def createDataFrame(sparkSession: SparkSession,
                               loadedDependencies: Map[String, DataFrame],
                               udfMap: Map[String, UserDefinedFunctionForDataLoader],
                               runtimeVariables: RuntimeVariables): DataFrame = {

    import sparkSession.implicits._
    val dailyBuild = if (runtimeVariables.asInstanceOf[EnrichmentRunTimeVariables].buildType == CDRConstants.DELTA_BUILD_TYPE) true else false

    val tempPatientId = loadedDependencies("PATIENT_ID_PREMATCH").as[patient_id]
    val tempPatMatchPrep = loadedDependencies("PAT_MATCH_PREP").as[pat_match_prep]

    val patientId = tempPatientId.
      where($"idtype" === lit("SSN") && !SSNValidation.cleanAndValidate($"idvalue").isin(SSNValidation.INVALID_OUTCOMES: _*))
      .select(
        $"groupid", $"client_ds_id", $"patientid",
        trim(substring(regexp_replace($"idvalue", "-", ""), 0, 9)).as("idvalue")
      )

    val ps = tempPatMatchPrep
      .select(
        $"groupid",
        $"client_ds_id",
        $"patientid",
        $"hgpid",
        $"dob",
        $"mrn",
        $"fname",
        $"lname",
        $"gender".as("mapped_gender"),
        $"deceased".as("mapped_deceased_ind"),
        $"zipcode",
        $"attr_time",
        when(substring(trim(upper($"fname")), 1, 4).isin("BABY", "TWIN", "FEMA", "MALE")
          && substring(trim(upper($"fname")), -2, 2).isin(" A", " B", " 1", " 2", "-A", "-B", "-1", "-2"), trim(upper($"fname")))
          .otherwise(CleanPatientName.cleanPatientName($"fname", lit(3))).as("adjfirst"),
        CleanPatientName.cleanPatientName($"lname", lit(3)).as("adjlast")
      )

    val idWindow = Window.partitionBy($"idvalue")

    val dataDf = patientId.as("pid")
      .join(ps.as("ps"), $"pid.groupid" === $"ps.groupid" && $"pid.patientid" === $"ps.patientid" && $"pid.client_ds_id" === $"ps.client_ds_id")
      .select(
        $"pid.groupid",
        $"pid.client_ds_id",
        $"pid.patientid",
        $"hgpid",
        $"dob",
        substring($"dob", 1, 4).as("yob"),
        substring($"dob", 5, 2).as("mob"),
        substring($"dob", 7, 2).as("dyob"),
        $"mapped_gender".as("gender"),
        upper($"fname").as("first_name"),
        upper($"lname").as("last_name"),
        upper(substring($"adjfirst", 1, 1)).as("first_init"),
        upper(substring($"adjlast", 1, 1)).as("last_init"),
        when(substring(upper($"adjfirst"), -2, 1) === lit(" "), upper($"adjfirst").substr(lit(1), length($"adjfirst") - lit(2)))
          .otherwise(upper($"adjfirst")).as("first_no_int"),
        $"idvalue".as("ssn"),
        when(substring($"idvalue", 1, 3) === substring($"idvalue", 4, 3)
          && substring($"idvalue", 4, 3) === substring($"idvalue", 7, 3), lit("Triplet"))
          .when(substring($"idvalue", 1, 2) === substring($"idvalue", 3, 2)
            && substring($"idvalue", 1, 2) === substring($"idvalue", 5 , 2) &&
          substring($"idvalue", 1, 2) === substring($"idvalue", 7, 2) && substring($"idvalue", 1, 1) === substring($"idvalue", 9 , 1), lit("Pairs"))
          .when(length(regexp_replace(substring($"idvalue", 1, 3), substring($"idvalue", 1,1), lit("")))=== lit(0) &&
            length(regexp_replace(substring($"idvalue", 4, 2), substring($"idvalue", 4, 1), lit(""))) === lit(0) &&
            length(regexp_replace(substring($"idvalue", 6, 4), substring($"idvalue", 6, 1), lit(""))) === lit(0), lit("Chunks"))
          .when(length(regexp_replace(substring($"idvalue", 1, 8), substring($"idvalue", 1, 1), lit(""))) === lit(0), lit("X8-Y1"))
          .when(length(regexp_replace(substring($"idvalue", 2, 8), substring($"idvalue", 2, 1), lit(""))) === lit(0), lit("X1-Y8"))
          .when(ascii(substring($"idvalue", 1, 1)) + 1 === ascii(substring($"idvalue", 2, 1)) &&
            ascii(substring($"idvalue", 2, 1)) + 1 === ascii(substring($"idvalue", 3, 1)) &&
            ascii(substring($"idvalue", 3, 1)) + 1 === ascii(substring($"idvalue", 4, 1)) &&
            ascii(substring($"idvalue", 4, 1)) + 1 === ascii(substring($"idvalue", 5, 1)) &&
            ascii(substring($"idvalue", 5, 1)) + 1 === ascii(substring($"idvalue", 6, 1)) &&
            ascii(substring($"idvalue", 6, 1)) + 1 === ascii(substring($"idvalue", 7, 1)) &&
            ascii(substring($"idvalue", 7, 1)) + 1 === ascii(substring($"idvalue", 8, 1)) &&
            ascii(substring($"idvalue", 8, 1)) + 1 === ascii(substring($"idvalue", 9, 1)), lit("SEQ"))
          .otherwise(lit("Y")).as("is_valid"),
        size(collect_set($"pid.groupid").over(idWindow)).as("group_cnt"),
        size(collect_set($"ps.hgpid").over(idWindow)).cast(LongType).as("hgpids"),
        size(collect_set(substring($"dob", 1, 4)).over(idWindow)).as("dob_yrs"),
        $"adjfirst".as("adj_firstname"),
        $"adjlast".as("adj_lastname"),
        lit(null).cast(StringType).as("middle_name"),
        lit(null).cast(StringType).as("addr"),
        lit(null).cast(StringType).as("city"),
        lit(null).cast(StringType).as("state"),
        lit(null).cast(StringType).as("zip"),
        lit(null).cast(StringType).as("phone"),
        lit(null).cast(StringType).as("email")
      )

    val ecdrDf = {
      if (dailyBuild) EnrichmentUtils.removeRowSourceAndModifiedDate(loadedDependencies("ECDR_MPI_SSN")).as[mpi_ssn]
      else sparkSession.emptyDataset[mpi_ssn].as[mpi_ssn]
    }.as("e")
      .select($"e.*")

    dataDf.unionByName(ecdrDf).distinct()

  }

}
