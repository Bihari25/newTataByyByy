
package com.optum.oap.backend.etl.encgrps

import com.optum.oap.cdr.models.egm
import com.optum.oap.sparkdataloader.QueryAndMetadata

object EGM extends QueryAndMetadata[egm] {
  override def name: String = "EGM"

  override def partitions: Int = 32

  override def sparkSql: String =
    """
      |SELECT
      |    groupid,
      |    grp_mpi,
      |    encounter_grp_num AS encounter_grp_num_egm,
      |    patienttype AS patienttype_egm,
      |    MIN(arrivaltime) AS arrivaltime_egm,
      |    MAX(dischargetime) AS dischargetime_egm,
      |    MAX(master_facility_name) AS master_facility_name_egm
      |FROM
      |    temp_eeg
      |WHERE
      |    patienttype IN (
      |        'CH000106'
      |    )
      |    AND rtrim(encounteridtype) IN (
      |        'MASTER',
      |        'ENCTR'
      |    )
      |GROUP BY
      |    groupid,
      |    grp_mpi,
      |    encounter_grp_num,
      |    patienttype
    """.stripMargin

  override def dependsOn: Set[String] = Set("TEMP_EEG")

  private def to_timestamp (input_column: String, date_type: String) = {
    "from_unixtime(unix_timestamp(date_format(" + input_column+ ", " + date_type+" ), " + date_type+"),"+ date_type +")"
  }
}