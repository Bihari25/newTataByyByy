/**
  * Creator: bishu
  * Date: 10/12/20
  */

package com.optum.oap.backend.etl.patient_matching

import com.optum.oap.backend.etl.common.CDRConstants
import com.optum.oap.backend.loader.{EnrichmentRunTimeVariables, client_configuration, mpi_rule_config}
import com.optum.oap.cdr.models.{patient, patient_mpi, patient_mpi_all_rules}
import com.optum.oap.sparkdataloader.{RuntimeVariables, TableInfo, UserDefinedFunctionForDataLoader}
import org.apache.spark.sql.expressions.Window
import org.apache.spark.sql.functions.{col, _}
import org.apache.spark.sql.types.LongType
import org.apache.spark.sql.{DataFrame, SparkSession}


class PATIENT_MPI_ALL_RULES(clientConfiguration: client_configuration) extends TableInfo[patient_mpi_all_rules] {

  // Dynamically determine the dependencies
  override def dependsOn: Set[String] = clientConfiguration.pat_match_rules.map(_.etlName).toSet
    .union(Set(
      "QGATE_PATIENT_ID_FILTER",
      "PATIENT_XWALK_MAPPING",
      "ECDR_PATIENT_MPI"
    ))

  override def name = "PATIENT_MPI_ALL_RULES"

  override def createDataFrame(sparkSession: SparkSession,
                               loadedDependencies: Map[String, DataFrame],
                               udfMap: Map[String, UserDefinedFunctionForDataLoader],
                               runtimeVariables: RuntimeVariables): DataFrame = {
    import sparkSession.implicits._

    val dynamicRuleDfs = clientConfiguration
      .pat_match_rules
      .map(getDynamicDataFrame(_, loadedDependencies, sparkSession, runtimeVariables))

    val combinedDf = dynamicRuleDfs.reduceOption(_ union _)

    combinedDf.getOrElse(Seq.empty[patient_mpi_all_rules].toDF)
  }

  private def getDynamicDataFrame(rule: mpi_rule_config,
                                  loadedDependencies: Map[String, DataFrame],
                                  sparkSession: SparkSession,
                                  runtimeVariables: RuntimeVariables): DataFrame = {
    import sparkSession.implicits._

    val dataTableDf: DataFrame = loadedDependencies(rule.etlName)
    val qgate_patient_id_filter_Df: DataFrame = loadedDependencies("QGATE_PATIENT_ID_FILTER")


    val grpid = EnrichmentRunTimeVariables(runtimeVariables).clientId
    val dailyBuild = if (runtimeVariables.asInstanceOf[EnrichmentRunTimeVariables].buildType == CDRConstants.DELTA_BUILD_TYPE) true else false

    val patient_mpi_ecdrdata = {
      if (dailyBuild) loadedDependencies("ECDR_PATIENT_MPI").as[patient_mpi]
      else sparkSession.emptyDataset[patient_mpi].as[patient_mpi]
    }

    val default_groupingname = "DEFAULT_" + grpid + "_GROUPING"
    val fullMode = if (!dailyBuild) true else false

    val hgpid_check_expr = {
      if (fullMode) $"st.hgpids".gt(lit(1))
      else lit(1) === lit(1)
    }

    val hgpidWindow = Window.partitionBy($"grp_mpi")
    val cdr_fe_patmpi = patient_mpi_ecdrdata.as("pm")
      .withColumn("existing_pat_cnt", size(collect_set($"hgpid").over(hgpidWindow)).cast(LongType))

    val ruleWhereCondition = rule.ruleFieldNames
      .map(c => col("st." + c.trim).isNotNull)
      .reduce(_ && _)

    val df1 = {
      if (fullMode) {
        dataTableDf.as("st")
          .join(cdr_fe_patmpi.as("m"), Seq("groupid", "client_ds_id", "patientid"), "left")
          .join(qgate_patient_id_filter_Df.as("pf"), Seq("groupid", "client_ds_id", "patientid"), "left")
          .where($"pf.patientid".isNull)
          .where(hgpid_check_expr)
          .where(ruleWhereCondition)
      } else {
        val deltaDf = deltaFilter(rule, loadedDependencies, sparkSession)
        val deltaWhereCondition = rule.ruleFieldNames
          .map(c => {
            col("st." + c.trim) === col("df.f_" + c.trim)
          })
          .reduce(_ && _)

        dataTableDf.as("st")
          .join(deltaDf.as("df"), deltaWhereCondition)
          .join(cdr_fe_patmpi.as("m"), Seq("groupid", "client_ds_id", "patientid"), "left")
          .join(qgate_patient_id_filter_Df.as("pf"), Seq("groupid", "client_ds_id", "patientid"), "left")
          .where($"pf.patientid".isNull)
          .where(hgpid_check_expr)
          .where(ruleWhereCondition)
      }
    }

    val ruleCols = rule.ruleFieldNames
      .map(col).toSeq

    val partCols = ruleCols ++ Seq($"st.groupid")
    val partitionByColumns = Window.partitionBy(partCols: _*)

    val greatestUniqueCount = {
      if (rule.uniqueFieldNames.nonEmpty) {
        rule.uniqueFieldNames
          .map(uc => size(collect_set(col(uc)).over(partitionByColumns)).cast(LongType))
          .reduce(greatest(_, _)).as("uniq_cnt")
      } else {
        lit(0).as("uniq_cnt")
      }
    }

    val minHgpid = min($"st.hgpid").over(partitionByColumns).as("min_hgpid")
    val matchCnt = size(collect_set($"st.hgpid").over(partitionByColumns)).as("match_cnt")
    val min_existing_grp_mpi = min($"m.grp_mpi").over(partitionByColumns).as("min_existing_grp_mpi")
    val existing_grp_mpi = $"m.grp_mpi".as("existing_grp_mpi")

    val uniqueCols = rule.uniqueFieldNames.map(col)
    val selectColumns = ruleCols ++
      uniqueCols ++
      Seq(greatestUniqueCount, minHgpid, matchCnt, min_existing_grp_mpi, existing_grp_mpi) ++
      Seq($"st.groupid", $"st.client_ds_id", $"st.patientid", $"st.hgpid")

    val df2 = df1.repartition(partCols: _*).select(selectColumns: _*)
    val selectColumn2 = ruleCols ++
      Seq($"groupid", $"client_ds_id", $"patientid", $"hgpid", $"new_grp_mpi", $"match_cnt", $"uniq_cnt")

    val df3 = df2.as("t")
      .withColumn("new_grp_mpi", coalesce($"t.existing_grp_mpi", $"t.min_existing_grp_mpi", $"t.min_hgpid"))
      .where($"t.uniq_cnt".leq(lit(1)))
      .where($"t.match_cnt".gt(lit(1)))
      .select(selectColumn2: _*)

    val resultDf = df3.as("r").select(
      $"r.groupid",
      $"r.client_ds_id",
      $"r.patientid",
      $"r.hgpid",
      $"r.new_grp_mpi".as("grp_mpi"),
      $"r.match_cnt".as("match_cnt"),
      lit(rule.ruleNbr).as("rule_nbr"),
      lit(rule.score).as("score")
    ).distinct()

    resultDf
  }

  // construct filter for daily runs
  private def deltaFilter(rule: mpi_rule_config,
                          loadedDependencies: Map[String, DataFrame],
                          sparkSession: SparkSession
                         ): DataFrame = {
    import sparkSession.implicits._

    val dataTableDf: DataFrame = loadedDependencies(rule.etlName)
    val patientDf = loadedDependencies("PATIENT_XWALK_MAPPING").as[patient]

    val partitionByColumns = Window.partitionBy(
      rule.ruleFieldNames.map(col).toSeq
        ++ Seq($"t.groupid"): _*
    )

    val df1 = dataTableDf.as("t")
      .withColumn("cnt_all_hgpids", size(collect_set($"hgpid").over(partitionByColumns)).cast(LongType))

    val df2 = df1.as("rtf")
      .join(patientDf.as("tp"), Seq("groupid", "client_ds_id", "patientid"))
      .where($"rtf.cnt_all_hgpids".gt(lit(1)))

    val selectColumns = rule.ruleFieldNames
      .map(c => col(c).as("f_" + c.trim)).toSeq

    df2.select(selectColumns: _*).distinct()
  }
}