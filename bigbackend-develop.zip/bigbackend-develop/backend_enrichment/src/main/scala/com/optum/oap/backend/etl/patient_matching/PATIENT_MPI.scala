package com.optum.oap.backend.etl.patient_matching

import com.optum.oap.cdr.models._
import com.optum.oap.sparkdataloader.{RuntimeVariables, TableInfo, UserDefinedFunctionForDataLoader}
import org.apache.spark.sql.types.IntegerType
import org.apache.spark.sql.{DataFrame, SparkSession}
import org.slf4j.LoggerFactory

/**
  * Creator: bishu
  * Date: 10/12/20
  */
object PATIENT_MPI extends TableInfo[patient_mpi] {
  val log = LoggerFactory.getLogger(this.getClass)

  override def dependsOn = Set(
    "QGATE_PERSON_ID_FILTER",
    "PRE_PATIENT_MPI"
  )

  override def createDataFrame(sparkSession: SparkSession,
                               loadedDependencies: Map[String, DataFrame],
                               udfMap: Map[String, UserDefinedFunctionForDataLoader],
                               runtimeVariables: RuntimeVariables): DataFrame = {
    import sparkSession.implicits._

    val qgate_person_id_filter_Df = loadedDependencies("QGATE_PERSON_ID_FILTER").as[qgate_person_id_filter]
    val patient_mpi_Df = loadedDependencies("PRE_PATIENT_MPI").as[patient_mpi]

    // remove suspicious entries
    val resultDf = patient_mpi_Df.as("d1")
      .join(qgate_person_id_filter_Df.as("q1"), $"d1.grp_mpi" === $"q1.personid", "left_anti")
      .select(
        $"d1.groupid",
        $"d1.client_ds_id",
        $"d1.patientid",
        $"d1.hgpid",
        $"d1.grp_mpi",
        $"d1.match_cnt".cast(IntegerType),
        $"d1.rule_nbr".cast(IntegerType),
        $"d1.score".cast(IntegerType)
      )

    resultDf


  }


}
