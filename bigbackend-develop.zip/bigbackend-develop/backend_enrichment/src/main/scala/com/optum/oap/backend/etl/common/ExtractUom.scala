package com.optum.oap.backend.etl.common

import com.optum.oap.sparkdataloader.UserDefinedFunctionForDataLoader
import org.apache.spark.sql.SparkSession
import org.apache.spark.sql.expressions.UserDefinedFunction
import org.apache.spark.sql.functions.udf

object ExtractUom extends UserDefinedFunctionForDataLoader {

  override def name: String = "extract_uom"

  /* Oracle's functions has the ability to return one variable when referenced in a sql query,
     while being able to return multiple variables when referenced inside of another function.
     This is enabled by using the "out" keyword for function parameters.
     extract_uom is one such function.
     It returns the v_uom variable  when referenced inside a sql query (nonnumeric_labs_localresult_25.sql)
     and returns both v_uom and p_raw_uom variables when referenced inside of other functions (extract_fns.extract_value).
     So, to enable this behaviour, two functions, extract_uom and extract_uom_raw are implemented to return
     v_uom and p_raw_uom respectively.
     extract_uom_common abstracts code common to both extract_uom and extract_uom_raw functions.
  */

  val extract_uom_common = (p_txt:String) => {

    val pattern =

      "(iu/l|iu/cc" +
        "|k/ul|kcals/kg|kcal/kg/day" +
        "|m/ul|mg/kg/mmol/l|mmol/l|mos/kg|mosm/l|mosm/kg" +
        "|u/kg/hr|bau|cal/kg|eu/dl|u/l|um3/cell" +
        "|cc/day|cc/kg|cc/hr" +
        "|cell[s]?/mcl|cell[s]?/ul|cfu/ml" +
        "|col/ml" +
        "|g/kg|g/dl/gm/kg|gm/dl" +
        "|iu/ml" +
        "|meq/dl|meq/kg|meq/l" +
        "|ml/kg|ml/hr|ml/min" +
        "|mcg/kg|mcg/kg/hr" +
        "|mil/mcl" +
        "|mg/cc|mg/dl|mg/g|mg/kg/day|mg/ml|mg/l|mg/wk" +
        "|mm/hr" +
        "|ng/ml|ng/dl|nmol/l" +
        "|pg/ml" +
        "|ug/mg|ug/ml|ug/dl|u/dl|uiu/ml|u/ml" +
        "|[x]?[ ]?10[-e*^][36]/ul" +
        "|g/dl" +
        "|#/mcl|#/ul" +
        "|mmol|ml|mg|cm|meg|mcg|iu| g$| g |%|ratio|percent|hpf|/hpf|pg|sec|hr|#)"


    /* Used get method instead of orNull or getOrElse methods, on purpose, to raise exception for null handling */
    val p_raw_uom = pattern.r.findFirstIn(p_txt.trim.toLowerCase().replace(" per ", "/")).get

    val v_uom = p_raw_uom.replace(" ", "")

    (v_uom, p_raw_uom)

  }

  val extract_uom_anon =

    (p_txt: String) => {

      /*
          Functions in Oracle can handle nulls as valid inputs, even if they primarily operate on a different datatype.
          Those types of functions return nulls if they get null inputs.
          But, Scala methods can't handle nulls this way, so to mimic this behaviour, handling NullPointerException
       */

      try {

        val (v_uom, _) = extract_uom_common(p_txt)

        v_uom

      }
      catch {

        case _: Exception => null

      }
    }

  val extract_uom: UserDefinedFunction = udf {

    extract_uom_anon

  }

  override def registerMe(sparkSession: SparkSession): Unit = {
    sparkSession.udf.register(name, extract_uom)
  }
}
