package com.optum.oap.backend.etl.encgrps

import com.optum.oap.cdr.models.encounter_grp_rel
import com.optum.oap.sparkdataloader.{RuntimeVariables, TableInfo, UserDefinedFunctionForDataLoader}
import org.apache.spark.sql.{DataFrame, SparkSession}

object ENCOUNTER_GRP_REL extends TableInfo[encounter_grp_rel] {

  override def name: String = "ENCOUNTER_GRP_REL"

  override def partitions: Int = 64

  override def dependsOn: Set[String] = Set(
    "TEMP_ENCOUNTER_GRP_REL_CH001654",
    "TEMP_ENCOUNTER_GRP_REL_CH001647",
    "TEMP_ENCOUNTER_GRP_REL_CH001648",
    "TEMP_ENCOUNTER_GRP_REL_CH001645",
    "TEMP_ENCOUNTER_GRP_REL_CH001646",
    "TEMP_ENCOUNTER_GRP_REL_CH001655",
    "TEMP_ENCOUNTER_GRP_REL_CH001656",
    "TEMP_ENCOUNTER_GRP_REL_CH002775",
    "TEMP_ENCOUNTER_GRP_REL_CH002776",
    "TEMP_ENCOUNTER_GRP_REL_CH002777",
    "TEMP_ENCOUNTER_GRP_REL_CH002778",
    "TEMP_ENCOUNTER_GRP_REL_CH002779",
    "TEMP_ENCOUNTER_GRP_REL_CH002780",
    "TEMP_ENCOUNTER_GRP_REL_CH002781",
    "TEMP_ENCOUNTER_GRP_REL_CH002782",
    "TEMP_ENCOUNTER_GRP_REL_CH002783",
    "TEMP_ENCOUNTER_GRP_REL_CH002784",
    "TEMP_ENCOUNTER_GRP_REL_CH003537",
    "TEMP_ENCOUNTER_GRP_REL_CH003538",
    "TEMP_ENCOUNTER_GRP_REL_CCS_CH001649",
    "TEMP_ENCOUNTER_GRP_REL_CCS_CH001650",
    "TEMP_ENCOUNTER_GRP_REL_CCS_CH001653",
    "TEMP_ENCOUNTER_GRP_REL_CCS_CH001651",
    "TEMP_ENCOUNTER_GRP_REL_CCS_CH001657",
    "TEMP_ENCOUNTER_GRP_REL_CCS_CH001658",
    "TEMP_ENCOUNTER_GRP_REL_CCS_CH002594",
    "TEMP_ENCOUNTER_GRP_REL_CCS_CH002595",
    "TEMP_ENCOUNTER_GRP_REL_CCS_CH002596",
    "TEMP_ENCOUNTER_GRP_REL_CCS_CH002597",
    "TEMP_ENCOUNTER_GRP_REL_CCS_CH002598",
    "TEMP_ENCOUNTER_GRP_REL_CCS_CH002599"
  )

  override protected def createDataFrame(sparkSession: SparkSession,
                                         loadedDependencies: Map[String, DataFrame],
                                         udfMap: Map[String, UserDefinedFunctionForDataLoader],
                                         runtimeVariables: RuntimeVariables): DataFrame = {
    import sparkSession.implicits._

    val temp_encounter_grp_rel_ch001654 = loadedDependencies("TEMP_ENCOUNTER_GRP_REL_CH001654").as[encounter_grp_rel]
    val temp_encounter_grp_rel_ch001647 = loadedDependencies("TEMP_ENCOUNTER_GRP_REL_CH001647").as[encounter_grp_rel]
    val temp_encounter_grp_rel_ch001648 = loadedDependencies("TEMP_ENCOUNTER_GRP_REL_CH001648").as[encounter_grp_rel]
    val temp_encounter_grp_rel_ch001645 = loadedDependencies("TEMP_ENCOUNTER_GRP_REL_CH001645").as[encounter_grp_rel]
    val temp_encounter_grp_rel_ch001646 = loadedDependencies("TEMP_ENCOUNTER_GRP_REL_CH001646").as[encounter_grp_rel]
    val temp_encounter_grp_rel_ch001655 = loadedDependencies("TEMP_ENCOUNTER_GRP_REL_CH001655").as[encounter_grp_rel]
    val temp_encounter_grp_rel_ch001656 = loadedDependencies("TEMP_ENCOUNTER_GRP_REL_CH001656").as[encounter_grp_rel]
    val temp_encounter_grp_rel_ch002775 = loadedDependencies("TEMP_ENCOUNTER_GRP_REL_CH002775").as[encounter_grp_rel]
    val temp_encounter_grp_rel_ch002776 = loadedDependencies("TEMP_ENCOUNTER_GRP_REL_CH002776").as[encounter_grp_rel]
    val temp_encounter_grp_rel_ch002777 = loadedDependencies("TEMP_ENCOUNTER_GRP_REL_CH002777").as[encounter_grp_rel]
    val temp_encounter_grp_rel_ch002778 = loadedDependencies("TEMP_ENCOUNTER_GRP_REL_CH002778").as[encounter_grp_rel]
    val temp_encounter_grp_rel_ch002779 = loadedDependencies("TEMP_ENCOUNTER_GRP_REL_CH002779").as[encounter_grp_rel]
    val temp_encounter_grp_rel_ch002780 = loadedDependencies("TEMP_ENCOUNTER_GRP_REL_CH002780").as[encounter_grp_rel]
    val temp_encounter_grp_rel_ch002781 = loadedDependencies("TEMP_ENCOUNTER_GRP_REL_CH002781").as[encounter_grp_rel]
    val temp_encounter_grp_rel_ch002782 = loadedDependencies("TEMP_ENCOUNTER_GRP_REL_CH002782").as[encounter_grp_rel]
    val temp_encounter_grp_rel_ch002783 = loadedDependencies("TEMP_ENCOUNTER_GRP_REL_CH002783").as[encounter_grp_rel]
    val temp_encounter_grp_rel_ch002784 = loadedDependencies("TEMP_ENCOUNTER_GRP_REL_CH002784").as[encounter_grp_rel]
    val temp_encounter_grp_rel_ch003537 = loadedDependencies("TEMP_ENCOUNTER_GRP_REL_CH003537").as[encounter_grp_rel]
    val temp_encounter_grp_rel_ch003538 = loadedDependencies("TEMP_ENCOUNTER_GRP_REL_CH003538").as[encounter_grp_rel]
    val temp_encounter_grp_rel_ccs_ch001649 = loadedDependencies("TEMP_ENCOUNTER_GRP_REL_CCS_CH001649").as[encounter_grp_rel]
    val temp_encounter_grp_rel_ccs_ch001650 = loadedDependencies("TEMP_ENCOUNTER_GRP_REL_CCS_CH001650").as[encounter_grp_rel]
    val temp_encounter_grp_rel_ccs_ch001653 = loadedDependencies("TEMP_ENCOUNTER_GRP_REL_CCS_CH001653").as[encounter_grp_rel]
    val temp_encounter_grp_rel_ccs_ch001651 = loadedDependencies("TEMP_ENCOUNTER_GRP_REL_CCS_CH001651").as[encounter_grp_rel]
    val temp_encounter_grp_rel_ccs_ch001657 = loadedDependencies("TEMP_ENCOUNTER_GRP_REL_CCS_CH001657").as[encounter_grp_rel]
    val temp_encounter_grp_rel_ccs_ch001658 = loadedDependencies("TEMP_ENCOUNTER_GRP_REL_CCS_CH001658").as[encounter_grp_rel]
    val temp_encounter_grp_rel_ccs_ch002594 = loadedDependencies("TEMP_ENCOUNTER_GRP_REL_CCS_CH002594").as[encounter_grp_rel]
    val temp_encounter_grp_rel_ccs_ch002595 = loadedDependencies("TEMP_ENCOUNTER_GRP_REL_CCS_CH002595").as[encounter_grp_rel]
    val temp_encounter_grp_rel_ccs_ch002596 = loadedDependencies("TEMP_ENCOUNTER_GRP_REL_CCS_CH002596").as[encounter_grp_rel]
    val temp_encounter_grp_rel_ccs_ch002597 = loadedDependencies("TEMP_ENCOUNTER_GRP_REL_CCS_CH002597").as[encounter_grp_rel]
    val temp_encounter_grp_rel_ccs_ch002598 = loadedDependencies("TEMP_ENCOUNTER_GRP_REL_CCS_CH002598").as[encounter_grp_rel]
    val temp_encounter_grp_rel_ccs_ch002599 = loadedDependencies("TEMP_ENCOUNTER_GRP_REL_CCS_CH002599").as[encounter_grp_rel]

    val result = temp_encounter_grp_rel_ch001654
      .union(temp_encounter_grp_rel_ch001647)
      .union(temp_encounter_grp_rel_ch001648)
      .union(temp_encounter_grp_rel_ch001645)
      .union(temp_encounter_grp_rel_ch001646)
      .union(temp_encounter_grp_rel_ch001655)
      .union(temp_encounter_grp_rel_ch001656)
      .union(temp_encounter_grp_rel_ch002775)
      .union(temp_encounter_grp_rel_ch002776)
      .union(temp_encounter_grp_rel_ch002777)
      .union(temp_encounter_grp_rel_ch002778)
      .union(temp_encounter_grp_rel_ch002779)
      .union(temp_encounter_grp_rel_ch002780)
      .union(temp_encounter_grp_rel_ch002781)
      .union(temp_encounter_grp_rel_ch002782)
      .union(temp_encounter_grp_rel_ch002783)
      .union(temp_encounter_grp_rel_ch002784)
      .union(temp_encounter_grp_rel_ch003537)
      .union(temp_encounter_grp_rel_ch003538)
      .union(temp_encounter_grp_rel_ccs_ch001649)
      .union(temp_encounter_grp_rel_ccs_ch001650)
      .union(temp_encounter_grp_rel_ccs_ch001653)
      .union(temp_encounter_grp_rel_ccs_ch001651)
      .union(temp_encounter_grp_rel_ccs_ch001657)
      .union(temp_encounter_grp_rel_ccs_ch001658)
      .union(temp_encounter_grp_rel_ccs_ch002594)
      .union(temp_encounter_grp_rel_ccs_ch002595)
      .union(temp_encounter_grp_rel_ccs_ch002596)
      .union(temp_encounter_grp_rel_ccs_ch002597)
      .union(temp_encounter_grp_rel_ccs_ch002598)
      .union(temp_encounter_grp_rel_ccs_ch002599)

    result.toDF()
  }
}
