package com.optum.oap.backend.etl.common

import org.apache.spark.sql.DataFrame

object MapMasterIds {


  private val PatientFields = Set("hgpid", "grp_mpi")
  private val ProviderFields = Set("hgprovid", "master_hgprovid")

  def mapPatientIds(sourceDF: DataFrame, patientXREF: DataFrame, filterIds: Boolean): DataFrame = {
    val joinType = if (filterIds) "inner" else "left_outer"
    val cols = getSelectList(sourceDF.columns.toSet, PatientFields)
    sourceDF.alias("d")
      .join(patientXREF.alias("m"), Seq("GROUPID", "CLIENT_DS_ID", "PATIENTID"), joinType)
      .select(cols.head, cols.tail: _*)
  }

  def mapProviderIds(sourceDF: DataFrame, providerXREF: DataFrame, localProviderIdFieldName: String, masterProvIdFieldName: String): DataFrame = {
    val provXref = providerXREF.withColumnRenamed("MASTER_HGPROVID", masterProvIdFieldName)
    val cols = getSelectList(sourceDF.columns.toSet, ProviderFields + masterProvIdFieldName.toLowerCase)
    val mapCols = Seq("GROUPID", "CLIENT_DS_ID", "LOCALPROVIDERID")
    val joinCols = Seq("GROUPID", "CLIENT_DS_ID", localProviderIdFieldName)
    val on = joinCols.zip(mapCols)
      .map { case (x, y) => sourceDF(x) <=> provXref(y) }
      .reduce(_ and _)
    sourceDF.alias("d")
      .join(provXref.alias("m"), on, "left_outer")
      .select(cols.head, cols.tail: _*)
  }

  def getSelectList(sourceCols: Set[String], mapCols: Set[String]): Array[String] = {
    sourceCols.map(s => if (mapCols.contains(s.toLowerCase)) "m." + s else "d." + s).toArray
  }

}
