package com.optum.oap.backend.etl.patient_matching

import com.optum.oap.backend.cdrTempModel.{pat_match_prep, patient_xref}
import com.optum.oap.backend.etl.common.{CDRConstants, PartitionedDataOperations}
import com.optum.oap.backend.loader.EnrichmentRunTimeVariables
import com.optum.oap.cdr.models.{patient, patientdetail}
import com.optum.oap.sparkdataloader.{RuntimeVariables, TableInfo, UserDefinedFunctionForDataLoader}
import org.apache.spark.sql.functions._
import org.apache.spark.sql.types.StringType
import org.apache.spark.sql.{DataFrame, SparkSession}

object PAT_MATCH_PREP extends TableInfo[pat_match_prep] with PartitionedDataOperations {
  override def dependsOn = Set("PATIENT_XWALK_MAPPING", "V_PATIENT_XREF", "CDR_FE_PATIENTDETAIL", "ICPM_PATIENT_DETAIL")
  override def name = "PAT_MATCH_PREP"
  override def saveDataFrameToParquet: Boolean = true
  override def partitions: Int = 32
  override def skipTable: Boolean = false
  override def ignoreExtraColumnsInDataFrame: Boolean = true
  override def createDataFrame(sparkSession: SparkSession,
                               loadedDependencies: Map[String, DataFrame],
                               udfMap: Map[String, UserDefinedFunctionForDataLoader],
                               runtimeVariables: RuntimeVariables): DataFrame = {
    import sparkSession.implicits._

    implicit val session = sparkSession
    val schema = EnrichmentRunTimeVariables(runtimeVariables).cdrSchema
    val patientIn = loadedDependencies("PATIENT_XWALK_MAPPING").drop("row_source","modified_date").as[patient]
    val pXref = loadedDependencies("V_PATIENT_XREF").drop("row_source","modified_date").as[patient_xref]
    val patXref = if(pXref.isEmpty) loadData(schema, "V_PATIENT_XREF").drop("row_source","modified_date").as[patient_xref] else pXref
    val patientDetail = loadedDependencies("CDR_FE_PATIENTDETAIL").drop("row_source","modified_date").as[patientdetail]
    val patientDetailIcpm = loadedDependencies("ICPM_PATIENT_DETAIL").drop("row_source","modified_date").as[patientdetail]

    val patientDetailUnion = patientDetail.unionByName(patientDetailIcpm)

    val tempPatientDetailHash = patientIn.as("pat")
      .join(patXref.as("pr"), Seq("client_ds_id", "patientid"), joinType="inner")
      .join(patientDetailUnion.as("pd"),
        $"pat.client_ds_id" === $"pd.client_ds_id" &&
        $"pat.patientid" === $"pd.patientid" && $"pd.patientdetailtype".isin ("FIRST_NAME","LAST_NAME"),
        "left"
      )
      .where($"pat.patientid".isNotNull)
      .where(translate($"pat.patientid", "0", "") =!= "")
      .select($"pat.groupid", $"pat.datasrc", $"pat.patientid",
        date_format($"pat.dateofbirth", CDRConstants.DATE_FORMAT_4Y2M2D).as("dob"),
        $"pat.medicalrecordnumber".as("mrn"), $"pd.patientdetailtype",
        $"pd.localvalue", $"pd.patdetail_timestamp", $"pat.client_ds_id".as("client_ds_id"),
        $"pr.hgpid"
      ).distinct

    tempPatientDetailHash.as("p")
      .join(tempPatientDetailHash.as("f"), $"p.patientid" === $"f.patientid" && $"p.client_ds_id" === $"f.client_ds_id" && $"f.patientdetailtype" === "FIRST_NAME", "left")
      .join(tempPatientDetailHash.as("l"), $"p.patientid" === $"l.patientid" && $"p.client_ds_id" === $"l.client_ds_id" && $"l.patientdetailtype" === "LAST_NAME", "left")
      .select(
        $"p.groupid", $"p.client_ds_id", $"p.patientid", $"p.hgpid", $"p.dob", $"p.mrn",
        trim($"f.localvalue").as("fname"),
        trim($"l.localvalue").as("lname"),
        lit("CH999999").cast(StringType).as("gender"),
        lit(null).cast(StringType).as("zipcode"),
        lit("CH999999").cast(StringType).as("deceased"),
        coalesce($"f.patdetail_timestamp", $"l.patdetail_timestamp").as("attr_time")
      ).distinct

  }
}
