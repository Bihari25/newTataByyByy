package com.optum.oap.backend.etl.enrichment

import com.optum.oap.backend.etl.common.MapMasterIds
import com.optum.oap.backend.loader.EnrichmentRunTimeVariables
import com.optum.oap.cdr.models.{account_rollup, biz_segment_rollup}
import com.optum.oap.sparkdataloader.{RuntimeVariables, TableInfo, UserDefinedFunctionForDataLoader}
import org.apache.spark.sql.expressions.Window
import org.apache.spark.sql.{DataFrame, SparkSession}
import org.slf4j.LoggerFactory
import org.apache.spark.sql.functions.{coalesce, length, _}
import org.apache.spark.sql.types.DataTypes
import org.apache.spark.sql.types._

object BIZ_SEGMENT_ROLLUP extends TableInfo[biz_segment_rollup] {

  private val log = LoggerFactory.getLogger(this.getClass)

  override def dependsOn = Set("CDR_FE_BIZ_SEGMENT_ROLLUP", "ACCOUNT_ROLLUP")

  override def name = "BIZ_SEGMENT_ROLLUP"

  override def createDataFrame(sparkSession: SparkSession,
                               loadedDependencies: Map[String, DataFrame],
                               udfMap: Map[String, UserDefinedFunctionForDataLoader],
                               runtimeVariables: RuntimeVariables): DataFrame = {

    import sparkSession.implicits._

    val cdrBizSegmentRollup = loadedDependencies("CDR_FE_BIZ_SEGMENT_ROLLUP").as[biz_segment_rollup]


    val cdrAccountRollup = loadedDependencies("ACCOUNT_ROLLUP").as[account_rollup]



    //Frontend BizSegment Rollup table

    val cdrFeBizSegmentRollup = cdrBizSegmentRollup.select(
      $"GROUPID",
      $"CLIENT_DS_ID",
      $"DATASRC",
      $"BIZ_SEGMENT",
      $"BIZ_SEGMENT_DESC",
      $"BIZ_SEGMENT_LV2",
      $"BIZ_SEGMENT_LV2_DESC",
      $"BIZ_SEGMENT_LV1",
      $"BIZ_SEGMENT_LV1_DESC"
    )

    //Filtering Frontend BizSegment Rollup table
    val cdrFeBizSegmentRollup1 = cdrFeBizSegmentRollup
      .dropDuplicates("BIZ_SEGMENT")
      .select("*")


    //getting the records from cdrAccountRollup whose "BIZ_SEGMENT" is not in the BizSegmentrollup
    val cdrAccountRollup1 = cdrAccountRollup.join(cdrFeBizSegmentRollup1, cdrAccountRollup("BIZ_SEGMENT") === cdrFeBizSegmentRollup1("BIZ_SEGMENT"), "left")
      .select(cdrAccountRollup("GROUPID"),
        cdrAccountRollup("CLIENT_DS_ID"),
        lit("account_rollup").cast(StringType).as("DATASRC"),
        cdrAccountRollup("BIZ_SEGMENT"),
        substring(concat(lit("UNDEFINED ("), cdrAccountRollup("BIZ_SEGMENT"), lit(")")), 1, 150).as("BIZ_SEGMENT_DESC"),
        cdrFeBizSegmentRollup1("BIZ_SEGMENT_LV2"),
        cdrFeBizSegmentRollup1("BIZ_SEGMENT_LV2_DESC"),
        cdrFeBizSegmentRollup1("BIZ_SEGMENT_LV1"),
        cdrFeBizSegmentRollup1("BIZ_SEGMENT_LV1_DESC")
      )
      .where((cdrAccountRollup("BIZ_SEGMENT").isNotNull) && (length(cdrAccountRollup("BIZ_SEGMENT")) <= 30) && (cdrFeBizSegmentRollup1("BIZ_SEGMENT").isNull))
      .groupBy(cdrAccountRollup("GROUPID"), $"BIZ_SEGMENT"
        , $"DATASRC", $"BIZ_SEGMENT_DESC", cdrFeBizSegmentRollup1("BIZ_SEGMENT_LV2"),
        cdrFeBizSegmentRollup1("BIZ_SEGMENT_LV2_DESC"),
        cdrFeBizSegmentRollup1("BIZ_SEGMENT_LV1"),
        cdrFeBizSegmentRollup1("BIZ_SEGMENT_LV1_DESC")
      )
      .agg(min($"CLIENT_DS_ID").as("CLIENT_DS_ID"))


    //union the missed records from cdrAccountRollup and the original table

    val rollup1 = cdrFeBizSegmentRollup.unionByName(cdrAccountRollup1)

    //Applying the additional logic and loading to the backend table.
    val rollup = rollup1.select(
      $"GROUPID"
      , $"CLIENT_DS_ID"
      , $"DATASRC"
      , $"BIZ_SEGMENT"
      , substring(coalesce($"BIZ_SEGMENT_DESC", concat(lit("UNDEFINED ("), $"BIZ_SEGMENT", lit(")"))), 1, 150).as("BIZ_SEGMENT_DESC")
      , substring(coalesce($"BIZ_SEGMENT_LV2", concat(lit("3."), $"BIZ_SEGMENT")), 1, 30).as("BIZ_SEGMENT_LV2")
      , substring(when($"BIZ_SEGMENT_LV2".isNull, coalesce($"BIZ_SEGMENT_DESC", concat(lit("UNDEFINED ("), $"BIZ_SEGMENT", lit(")"))))
        .otherwise(coalesce($"BIZ_SEGMENT_LV2_DESC", concat(lit("UNDEFINED ("), $"BIZ_SEGMENT_LV2", lit(")")))), 1, 150)
        .as("BIZ_SEGMENT_LV2_DESC")
      , substring(when($"BIZ_SEGMENT_LV1".isNotNull, $"BIZ_SEGMENT_LV1")
        .otherwise(when($"BIZ_SEGMENT_LV2".isNotNull, concat(lit("2."), $"BIZ_SEGMENT_LV2"))
          .otherwise(concat(lit("3."), $"BIZ_SEGMENT"))), 1, 30).as("BIZ_SEGMENT_LV1")
      , substring(when($"BIZ_SEGMENT_LV1".isNull,
        when($"BIZ_SEGMENT_LV2".isNull, coalesce($"BIZ_SEGMENT_DESC", concat(lit("UNDEFINED ("), $"BIZ_SEGMENT", lit(")"))))
          .otherwise(coalesce($"BIZ_SEGMENT_LV2_DESC", concat(lit("UNDEFINED ("), $"BIZ_SEGMENT_LV2", lit(")")))))
        .otherwise(coalesce($"BIZ_SEGMENT_LV1_DESC", concat(lit("UNDEFINED ("), $"BIZ_SEGMENT_LV1", lit(")")))), 1, 150).as("BIZ_SEGMENT_LV1_DESC")
      , row_number().over(Window.partitionBy($"BIZ_SEGMENT")
        .orderBy(
          when($"BIZ_SEGMENT_DESC".isNotNull, lit(0)).otherwise(lit(1)),
          when($"BIZ_SEGMENT_LV2".isNotNull, lit(0)).otherwise(lit(1)),
          when($"BIZ_SEGMENT_LV1".isNotNull, lit(0)).otherwise(lit(1)),
          $"BIZ_SEGMENT_DESC", $"BIZ_SEGMENT_LV2", $"BIZ_SEGMENT_LV1"
        )).as("rn")
    )
      .where((rollup1("BIZ_SEGMENT").isNotNull) && (length(rollup1("BIZ_SEGMENT")) <= 30) && ($"rn" === 1))
      .drop($"rn")

    rollup.toDF()

  }
}
