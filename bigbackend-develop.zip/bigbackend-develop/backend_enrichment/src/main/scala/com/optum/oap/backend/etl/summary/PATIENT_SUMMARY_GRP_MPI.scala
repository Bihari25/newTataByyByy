package com.optum.oap.backend.etl.summary

import com.optum.oap.backend.etl.common.CDRConstants
import com.optum.oap.cdr.models.{map_domain_cdsid_priority, patient_summary_grp_mpi}
import com.optum.oap.sparkdataloader.{RuntimeVariables, TableInfo, UserDefinedFunctionForDataLoader}
import org.apache.spark.sql.expressions.Window
import org.apache.spark.sql.functions._
import org.apache.spark.sql.types.IntegerType
import org.apache.spark.sql.{DataFrame, SparkSession}
import org.slf4j.LoggerFactory

object PATIENT_SUMMARY_GRP_MPI extends TableInfo[patient_summary_grp_mpi] {
  val log = LoggerFactory.getLogger(this.getClass)
  override def dependsOn =  Set("ZCM_CLIENT_DS_PRIORITY", "PATIENT_SUMMARY", "MV_CLIENT_DATA_SRC",
    "MAP_DECEASED_INDICATOR", "CLIENT_ATTRIBUTE", "MAP_DOMAIN_CDSID_PRIORITY")

  override def name = "PATIENT_SUMMARY_GRP_MPI"

  override def saveDataFrameToParquet: Boolean = true
  override def partitions: Int = 128
  override def skipTable: Boolean = false
  override def ignoreExtraColumnsInDataFrame: Boolean = false


  override def createDataFrame (sparkSession: SparkSession,
                                loadedDependencies: Map[String, DataFrame],
                                udfMap: Map[String, UserDefinedFunctionForDataLoader],
                                runtimeVariables: RuntimeVariables): DataFrame = {
    import sparkSession.implicits._

    val patient_summary = loadedDependencies("PATIENT_SUMMARY")
    val zcm_client_ds_priority = loadedDependencies("ZCM_CLIENT_DS_PRIORITY")
    val mv_client_data_src = loadedDependencies("MV_CLIENT_DATA_SRC")
      .select("CLIENT_DATA_SRC_ID", "DATA_SRC_ID", "DATA_SRC_NAME", "IS_SHARED")
    val mdi = loadedDependencies("MAP_DECEASED_INDICATOR")
      .withColumnRenamed("GROUPID", "GROUPID_mdi")
    val cav = loadedDependencies("CLIENT_ATTRIBUTE")
      .select("CLIENT_ID", "DISPLAYID")
      .withColumnRenamed("CLIENT_ID", "GROUPID")

    val mapDomainCDSIDPriority = broadcast(loadedDependencies("MAP_DOMAIN_CDSID_PRIORITY").as[map_domain_cdsid_priority])

    val patSumCnt = patient_summary
      .filter("grp_mpi is not null")
      .join(broadcast(mdi), patient_summary("GROUPID") === mdi("GROUPID_mdi") && patient_summary("LOCAL_DEATH_IND") === mdi("MNEMONIC"), "left_outer")
      .join(broadcast(zcm_client_ds_priority), Seq("CLIENT_DS_ID"), "left_outer")
      .join(broadcast(mv_client_data_src), patient_summary("CLIENT_DS_ID") === mv_client_data_src("CLIENT_DATA_SRC_ID") && !mv_client_data_src("DATA_SRC_NAME").isin("NLP", "COMMON"), "left_outer")
      .select(
        $"GROUPID", $"GRP_MPI", $"HGPID", $"CLIENT_DS_ID",
        rank.over(Window.partitionBy($"GROUPID", $"GRP_MPI").orderBy($"PRIORITY", when($"IS_SHARED" === "Y", 0).when($"IS_SHARED" === "N", 1).otherwise(2), $"CLIENT_DS_ID")).as("DSRANK"),
        $"MAPPED_GENDER",
        count("HGPID").over(Window.partitionBy($"GROUPID", $"GRP_MPI", $"MAPPED_GENDER")).as("MAPPED_GENDER_PATS"),
        $"MAPPED_RACE",
        count("HGPID").over(Window.partitionBy($"GROUPID", $"GRP_MPI", $"MAPPED_RACE")).as("MAPPED_RACE_PATS"),
        $"MAPPED_ETHNICITY",
        count("HGPID").over(Window.partitionBy($"GROUPID", $"GRP_MPI", $"MAPPED_ETHNICITY")).as("MAPPED_ETHNICITY_PATS"),
        $"MAPPED_LANGUAGE",
        count("HGPID").over(Window.partitionBy($"GROUPID", $"GRP_MPI", $"MAPPED_LANGUAGE")).as("MAPPED_LANGUAGE_PATS"),
        $"MAPPED_MARITAL_STATUS",
        count("HGPID").over(Window.partitionBy($"GROUPID", $"GRP_MPI", $"MAPPED_MARITAL_STATUS")).as("MAPPED_MARITAL_STATUS_PATS"),
        $"MAPPED_ZIPCODE",
        count("HGPID").over(Window.partitionBy($"GROUPID", $"GRP_MPI", $"MAPPED_ZIPCODE")).as("MAPPED_ZIPCODE_PATS"),
        coalesce($"CUI", lit("CH999999")).as("DEATH_IND"),
        count("HGPID").over(Window.partitionBy($"GROUPID", $"GRP_MPI", coalesce($"CUI", lit("CH999999")))).as("DEATH_IND_PATS"),
        $"FIRST_NAME",
        count("HGPID").over(Window.partitionBy($"GROUPID", $"GRP_MPI", upper($"FIRST_NAME"))).as("FIRST_NAME_PATS"),
        size(collect_set($"CLIENT_DS_ID").over(Window.partitionBy($"GROUPID", $"GRP_MPI", $"FIRST_NAME"))).as("FIRST_NAME_SRCS"),
        $"LAST_NAME",
        count("HGPID").over(Window.partitionBy($"GROUPID", $"GRP_MPI", upper($"LAST_NAME"))).as("LAST_NAME_PATS"),
        size(collect_set($"CLIENT_DS_ID").over(Window.partitionBy($"GROUPID", $"GRP_MPI", $"LAST_NAME"))).as("LAST_NAME_SRCS"),
        $"MIDDLE_NAME",
        count("HGPID").over(Window.partitionBy($"GROUPID", $"GRP_MPI", upper($"MIDDLE_NAME"))).as("MIDDLE_NAME_PATS"),
        size(collect_set($"CLIENT_DS_ID").over(Window.partitionBy($"GROUPID", $"GRP_MPI", $"MIDDLE_NAME"))).as("MIDDLE_NAME_SRCS"),
        when(from_unixtime(unix_timestamp($"DOB", CDRConstants.DATE_FORMAT_4Y2M2D)).between(date_add(current_date(), -135 * 365), date_add(current_date(), 3)), $"DOB").otherwise(null).as("DOB"),
        count($"HGPID").over(Window.partitionBy($"GROUPID", $"GRP_MPI", when(from_unixtime(unix_timestamp($"DOB", CDRConstants.DATE_FORMAT_4Y2M2D)).between(date_add(current_date(), -135 * 365), date_add(current_date(), 3)), $"DOB").otherwise(null))).as("DOB_PATS"),
        size(collect_set($"CLIENT_DS_ID").over(Window.partitionBy($"GROUPID", $"GRP_MPI", $"DOB"))).as("DOB_SRCS"),
        $"DATE_OF_DEATH",
        count($"HGPID").over(Window.partitionBy($"GROUPID", $"GRP_MPI", $"DATE_OF_DEATH")).as("DATE_OF_DEATH_PATS"),
        size(collect_set($"CLIENT_DS_ID").over(Window.partitionBy($"GROUPID", $"GRP_MPI", $"DATE_OF_DEATH"))).as("DATE_OF_DEATH_SRCS"),
        $"LOCAL_DOD",
        count($"HGPID").over(Window.partitionBy($"GROUPID", $"GRP_MPI", $"LOCAL_DOD")).as("LOCAL_DOD_PATS"),
        size(collect_set($"CLIENT_DS_ID").over(Window.partitionBy($"GROUPID", $"GRP_MPI", $"LOCAL_DOD"))).as("LOCAL_DOD_SRCS"),
        $"SSDI_DOD",
        $"SSDI_NAME_MATCH",
        $"MEDICALRECORDNUMBER".as("MRN"),
        count($"HGPID").over(Window.partitionBy($"GROUPID", $"GRP_MPI", $"MEDICALRECORDNUMBER")).as("MRN_PATS"),
        size(collect_set($"CLIENT_DS_ID").over(Window.partitionBy($"GROUPID", $"GRP_MPI", $"MEDICALRECORDNUMBER"))).as("MRN_SRCS"),
        $"PATIENTID",
        count($"HGPID").over(Window.partitionBy($"GROUPID", $"GRP_MPI", $"PATIENTID")).as("PATIENTID_PATS"),
        size(collect_set($"CLIENT_DS_ID").over(Window.partitionBy($"GROUPID", $"GRP_MPI", $"PATIENTID"))).as("PATIENTID_SRCS"),
        $"INACTIVE_FLAG",
        when($"INACTIVE_FLAG" === "N" || $"INACTIVE_FLAG".isNull, 1).when($"INACTIVE_FLAG" === "Y", 3).otherwise(2).as("INACTIVE_FLAG_PATS"),
        $"RELIGION",
        count($"HGPID").over(Window.partitionBy($"GROUPID", $"GRP_MPI", $"RELIGION")).as("RELIGION_PATS"),
        when($"DATA_SRC_ID" === "2021" || $"DATA_SRC_ID" === "3803", 99).otherwise(1).as("SFCC_PRIORITY"),
        $"PRIORITY".as("ZCM_PRIORITY")
      )

    val patSumRank = patSumCnt
      .join(mapDomainCDSIDPriority.as("mdcp").where($"domain" === lit("GRP_MPI.DEMO")), Seq("groupid", "client_ds_id"), "left")
      .select(
        $"GROUPID", $"GRP_MPI", $"HGPID", $"CLIENT_DS_ID", $"DSRANK",
        $"MAPPED_GENDER", $"MAPPED_GENDER_PATS",
        $"MAPPED_RACE", $"MAPPED_RACE_PATS",
        $"MAPPED_ETHNICITY", $"MAPPED_ETHNICITY_PATS",
        $"MAPPED_LANGUAGE", $"MAPPED_LANGUAGE_PATS",
        $"MAPPED_MARITAL_STATUS", $"MAPPED_MARITAL_STATUS_PATS",
        $"MAPPED_ZIPCODE", $"MAPPED_ZIPCODE_PATS",
        $"DEATH_IND", $"DEATH_IND_PATS",
        $"FIRST_NAME", $"FIRST_NAME_PATS", $"FIRST_NAME_SRCS",
        $"LAST_NAME", $"LAST_NAME_PATS", $"LAST_NAME_SRCS",
        $"MIDDLE_NAME", $"MIDDLE_NAME_PATS", $"MIDDLE_NAME_SRCS",
        $"DOB", $"DOB_PATS", $"DOB_SRCS",
        $"DATE_OF_DEATH", $"DATE_OF_DEATH_PATS", $"DATE_OF_DEATH_SRCS",
        $"LOCAL_DOD", $"LOCAL_DOD_PATS", $"LOCAL_DOD_SRCS",
        $"SSDI_DOD", $"SSDI_NAME_MATCH",
        $"MRN", $"MRN_PATS", $"MRN_SRCS",
        $"PATIENTID", $"PATIENTID_PATS", $"PATIENTID_SRCS",
        $"INACTIVE_FLAG", $"INACTIVE_FLAG_PATS",
        $"RELIGION", $"RELIGION_PATS",
        rank.over(Window.partitionBy($"GROUPID", $"GRP_MPI")
          .orderBy(when($"MAPPED_GENDER" === "CH999999", 0).when($"MAPPED_GENDER" === "CH999990", 1).otherwise(2).desc,
            $"mdcp.priority".asc_nulls_last
            ,when($"MAPPED_GENDER" === "CH000035", 2).otherwise(1).asc_nulls_last, $"MAPPED_GENDER_PATS".desc))
          .as("MAPPED_GENDER_RANK"),
        rank.over(Window.partitionBy($"GROUPID", $"GRP_MPI")
          .orderBy(when($"MAPPED_RACE" === "CH999999", 0).when($"MAPPED_RACE" === "CH999990", 1).otherwise(2).desc,
            $"mdcp.priority".asc_nulls_last,
            when($"MAPPED_RACE" === "CH000056", 2).otherwise(1).asc_nulls_last,
            $"MAPPED_RACE_PATS".desc,
            when($"MAPPED_RACE" === "CH001643", 1).otherwise(2).asc_nulls_last))
          .as("MAPPED_RACE_RANK"),
        rank.over(Window.partitionBy($"GROUPID", $"GRP_MPI")
          .orderBy(when($"MAPPED_ETHNICITY" === "CH999999", 0).when($"MAPPED_ETHNICITY" === "CH999990", 1).otherwise(2).desc,
            $"mdcp.priority".asc_nulls_last,
            when($"MAPPED_ETHNICITY" === "CH000059", 2).otherwise(1).asc_nulls_last, $"MAPPED_ETHNICITY_PATS".desc))
          .as("MAPPED_ETHNICITY_RANK"),
        rank.over(Window.partitionBy($"GROUPID", $"GRP_MPI")
          .orderBy(when($"MAPPED_ZIPCODE" === "CH999999", 0).when($"MAPPED_ZIPCODE" === "CH999990", 1).otherwise(2).desc, $"MAPPED_ZIPCODE_PATS".desc))
          .as("MAPPED_ZIPCODE_RANK"),
        rank.over(Window.partitionBy($"GROUPID", $"GRP_MPI")
          .orderBy(when($"DEATH_IND" === "CH999999", 0).when($"DEATH_IND" === "CH999990", 1).when($"DEATH_IND" === "CH001139", 3).otherwise(2).desc, $"DEATH_IND_PATS".desc))
          .as("DEATH_IND_RANK"),
        rank.over(Window.partitionBy($"GROUPID", $"GRP_MPI")
          .orderBy(when($"MAPPED_LANGUAGE" === "CH999999", 0).when($"MAPPED_LANGUAGE" === "CH999990", 1).otherwise(2).desc,
            $"mdcp.priority".asc_nulls_last
            ,when($"MAPPED_LANGUAGE" === "CH002186", 2).otherwise(1).asc_nulls_last, $"MAPPED_LANGUAGE_PATS".desc))
          .as("MAPPED_LANGUAGE_RANK"),
        rank.over(Window.partitionBy($"GROUPID", $"GRP_MPI")
          .orderBy(when($"MAPPED_MARITAL_STATUS" === "CH999999", 0).when($"MAPPED_MARITAL_STATUS" === "CH999990", 1).otherwise(2).desc,
            $"mdcp.priority".asc_nulls_last
            ,when($"MAPPED_MARITAL_STATUS" === "CH000017", 2).otherwise(1).asc_nulls_last, $"MAPPED_MARITAL_STATUS_PATS".desc))
          .as("MAPPED_MARITAL_STATUS_RANK"),
        first($"DATE_OF_DEATH")
          .over(Window
            .partitionBy($"GROUPID", $"GRP_MPI")
            .orderBy(
              $"INACTIVE_FLAG_PATS",
              when($"SSDI_DOD" === "Y", 1).when($"SSDI_DOD" === "N", 2).otherwise(3),
              $"ZCM_PRIORITY".asc_nulls_last,
              when($"DATE_OF_DEATH".isNotNull && (year(current_date()) - year($"DATE_OF_DEATH")).between(0, 50), 0).otherwise(1),
              $"DATE_OF_DEATH_PATS".desc,
              $"DATE_OF_DEATH_SRCS".desc,
              $"DSRANK", $"HGPID"
            )
          )
          .as("BEST_DATE_OF_DEATH"),
        first($"LOCAL_DOD", ignoreNulls = true)
          .over(Window
            .partitionBy($"GROUPID", $"GRP_MPI")
            .orderBy(
              $"INACTIVE_FLAG_PATS",
              when($"SSDI_DOD" === "Y", 1).when($"SSDI_DOD" === "N", 2).otherwise(3),
              when($"LOCAL_DOD".isNotNull && (year(current_date()) - year($"LOCAL_DOD")).between(0, 50), 0).otherwise(1),
              $"LOCAL_DOD_PATS".desc,
              $"LOCAL_DOD_SRCS".desc,
              $"DSRANK", $"HGPID"
            )
          )
          .as("BEST_LOCAL_DOD"),
        first($"SSDI_DOD", ignoreNulls = true)
          .over(Window
            .partitionBy($"GROUPID", $"GRP_MPI")
            .orderBy(
              $"INACTIVE_FLAG_PATS",
              when($"SSDI_DOD" === "Y", 1).when($"SSDI_DOD" === "N", 2).otherwise(3)
            )
          )
          .as("BEST_SSDI_DOD"),
        first($"SSDI_NAME_MATCH", ignoreNulls = true)
          .over(Window
            .partitionBy($"GROUPID", $"GRP_MPI")
            .orderBy(
              $"INACTIVE_FLAG_PATS",
              when($"SSDI_NAME_MATCH" === "Y", 1).when($"SSDI_NAME_MATCH" === "N", 2).otherwise(3)
            )
          )
          .as("BEST_SSDI_NAME_MATCH"),
        first($"DOB", ignoreNulls = true)
          .over(Window
            .partitionBy($"GROUPID", $"GRP_MPI")
            .orderBy(
              $"INACTIVE_FLAG_PATS",
              when($"DOB".isNotNull && (year(current_date()) - substring($"DOB", 1, 4).cast("Int")).between(-1, 135), 0).otherwise(1),
              $"DOB_PATS".desc,
              $"DOB_SRCS".desc,
              $"DSRANK", $"HGPID"
            )
          )
          .as("BEST_DOB"),
        first($"FIRST_NAME", ignoreNulls = true)
          .over(Window
            .partitionBy($"GROUPID", $"GRP_MPI")
            .orderBy(
              $"INACTIVE_FLAG_PATS",
              when($"FIRST_NAME".isNotNull, 0).otherwise(1),
              $"SFCC_PRIORITY",
              $"FIRST_NAME_PATS".desc,
              $"FIRST_NAME_SRCS".desc,
              $"DSRANK", $"HGPID"
            )
          )
          .as("BEST_FIRST_NAME"),
        first($"LAST_NAME", ignoreNulls = true)
          .over(Window
            .partitionBy($"GROUPID", $"GRP_MPI")
            .orderBy(
              $"INACTIVE_FLAG_PATS",
              when($"LAST_NAME".isNotNull, 0).otherwise(1),
              $"SFCC_PRIORITY",
              $"LAST_NAME_PATS".desc,
              $"LAST_NAME_SRCS".desc,
              $"DSRANK", $"HGPID"
            )
          )
          .as("BEST_LAST_NAME"),
        first($"MIDDLE_NAME", ignoreNulls = true)
          .over(Window
            .partitionBy($"GROUPID", $"GRP_MPI")
            .orderBy(
              $"INACTIVE_FLAG_PATS",
              when($"MIDDLE_NAME".isNotNull, 0).otherwise(1),
              $"SFCC_PRIORITY",
              $"MIDDLE_NAME_PATS".desc,
              $"MIDDLE_NAME_SRCS".desc,
              $"DSRANK", $"HGPID"
            )
          )
          .as("BEST_MIDDLE_NAME"),
        first($"MRN", ignoreNulls = true)
          .over(Window
            .partitionBy($"GROUPID", $"GRP_MPI")
            .orderBy(
              $"INACTIVE_FLAG_PATS",
              when($"MRN".isNotNull, 0).otherwise(1),
              $"MRN_PATS".desc,
              $"MRN_SRCS".desc,
              $"DSRANK", $"HGPID"
            )
          )
          .as("BEST_MRN"),
        first($"PATIENTID", ignoreNulls = true)
          .over(Window
            .partitionBy($"GROUPID", $"GRP_MPI")
            .orderBy(
              $"INACTIVE_FLAG_PATS",
              $"PATIENTID_PATS".desc,
              $"PATIENTID_SRCS".desc,
              $"DSRANK", $"HGPID"
            )
          )
          .as("BEST_PATIENTID"),
        first($"RELIGION", ignoreNulls = true)
          .over(Window
            .partitionBy($"GROUPID", $"GRP_MPI")
            .orderBy(
              $"mdcp.priority".asc_nulls_last,
              $"INACTIVE_FLAG_PATS",
              when($"RELIGION".isNotNull, 0).otherwise(1),
              $"RELIGION_PATS".desc,
              $"DSRANK", $"HGPID"
            )
          )
          .as("BEST_RELIGION")
      )

    val patSumMax = patSumRank
      .groupBy($"GROUPID", $"GRP_MPI")
      .agg(
        countDistinct($"HGPID").cast(IntegerType).as("PATIENTID_CNT"),
        max($"BEST_PATIENTID").as("PATIENTID"),
        max($"BEST_MRN").as("MEDICALRECORDNUMBER"),
        max($"BEST_DOB").as("DOB"),
        max($"BEST_FIRST_NAME").as("FIRST_NAME"),
        max($"BEST_LAST_NAME").as("LAST_NAME"),
        max($"BEST_MIDDLE_NAME").as("MIDDLE_NAME"),
        max($"BEST_DATE_OF_DEATH").as("DATE_OF_DEATH"),
        max($"BEST_LOCAL_DOD").as("LOCAL_DOD"),
        max($"BEST_SSDI_DOD").as("SSDI_DOD"),
        max($"BEST_SSDI_NAME_MATCH").as("SSDI_NAME_MATCH"),
        max(when($"MAPPED_GENDER_RANK" === 1, $"MAPPED_GENDER")).as("MAPPED_GENDER"),
        countDistinct(when($"MAPPED_GENDER_RANK" === 1, $"MAPPED_GENDER")).as("BEST_MAPPED_GENDER_CNT"),
        max(when($"MAPPED_RACE_RANK" === 1, $"MAPPED_RACE")).as("MAPPED_RACE"),
        countDistinct(when($"MAPPED_RACE_RANK" === 1, $"MAPPED_RACE")).as("BEST_MAPPED_RACE_CNT"),
        max(when($"MAPPED_ETHNICITY_RANK" === 1, $"MAPPED_ETHNICITY")).as("MAPPED_ETHNICITY"),
        countDistinct(when($"MAPPED_ETHNICITY_RANK" === 1, $"MAPPED_ETHNICITY")).as("BEST_MAPPED_ETHNICITY_CNT"),
        max(when($"MAPPED_ZIPCODE_RANK" === 1, $"MAPPED_ZIPCODE")).as("MAPPED_ZIPCODE"),
        countDistinct(when($"MAPPED_ZIPCODE_RANK" === 1, $"MAPPED_ZIPCODE")).as("BEST_MAPPED_ZIPCODE_CNT"),
        max(when($"DEATH_IND_RANK" === 1, $"DEATH_IND")).as("MAPPED_DEATH_IND"),
        max(when($"MAPPED_LANGUAGE_RANK" === 1, $"MAPPED_LANGUAGE")).as("MAPPED_LANGUAGE"),
        countDistinct(when($"MAPPED_LANGUAGE_RANK" === 1, $"MAPPED_LANGUAGE")).as("BEST_MAPPED_LANGUAGE_CNT"),
        max(when($"MAPPED_MARITAL_STATUS_RANK" === 1, $"MAPPED_MARITAL_STATUS")).as("MAPPED_MARITAL_STATUS"),
        countDistinct(when($"MAPPED_MARITAL_STATUS_RANK" === 1, $"MAPPED_MARITAL_STATUS")).as("BEST_MAPPED_MARITAL_STATUS_CNT"),
        max($"BEST_RELIGION").as("RELIGION"),
        min($"INACTIVE_FLAG").as("INACTIVE_FLAG")
      )
      .withColumn("BEST_DEATH_IND_CNT", lit("1"))

    val displayIdReplacerUdf = udf((displayId: String, firstName: String, lastName: String, dob: String,
                                    mrn: String, patientID: String) => {
      displayId.replace("[[FIRST]]", firstName)
        .replace("[[LAST]]", lastName)
        .replace("[[DOB]]", if (dob.length == 8) {dob.substring(4, 6) + "-" + dob.substring(6, 8) + "-" +
          dob.substring( 0, 4)} else dob)
        .replace("[[[MRN]]]", mrn)
        .replace("[[PATIENTID]]", patientID)
    })

    val patSumDisplayID =
      patSumMax
        .join(broadcast(cav), Seq("GROUPID"), "left_outer")
        .withColumn("DISPLAY_ID",
          when($"DISPLAYID" === "PATID", $"PATIENTID")
            .when($"DISPLAYID" === "MRN", $"MEDICALRECORDNUMBER")
            .when($"DISPLAYID" === "NAME_DOB",
              concat(
                coalesce(trim($"LAST_NAME"), lit("")),
                lit(", "),
                coalesce(trim($"FIRST_NAME"), lit("")),
                lit(" - "),
                coalesce(substring($"DOB", 5, 2), lit("")),
                lit("-"),
                coalesce(substring($"DOB", 7, 2), lit("")),
                lit("-"),
                coalesce(substring($"DOB", 1, 4), lit(""))
              )
            )
            .when($"DISPLAYID" === "ID_DOB",
              concat(
                coalesce($"PATIENTID", lit("")),
                lit(" - "),
                coalesce(trim($"LAST_NAME"), lit("")),
                lit(", "),
                coalesce(trim($"FIRST_NAME"), lit("")),
                lit(" - "),
                coalesce(substring($"DOB", 5, 2), lit("")),
                lit("-"),
                coalesce(substring($"DOB", 7, 2), lit("")),
                lit("-"),
                coalesce(substring($"DOB", 1, 4), lit(""))
              )
            )
            .when($"DISPLAYID" === "MRN_NM_DOB",
              concat(
                coalesce($"MEDICALRECORDNUMBER", lit("")),
                lit(" - "),
                coalesce(trim($"LAST_NAME"), lit("")),
                lit(", "),
                coalesce(trim($"FIRST_NAME"), lit("")),
                lit(" - "),
                coalesce(substring($"DOB", 5, 2), lit("")),
                lit("-"),
                coalesce(substring($"DOB", 7, 2), lit("")),
                lit("-"),
                coalesce(substring($"DOB", 1, 4), lit(""))
              )
            )
            .when($"DISPLAYID" === "ID_NM",
              concat(
                coalesce($"PATIENTID", lit("")),
                lit("   "),
                coalesce(trim($"LAST_NAME"), lit("")),
                lit(", "),
                coalesce(trim($"FIRST_NAME"), lit(""))
              )
            )
            .when($"DISPLAYID" === "ID_NM_DOB",
              concat(
                coalesce($"PATIENTID", lit("")),
                lit(" ; "),
                coalesce(trim($"LAST_NAME"), lit("")),
                lit(", "),
                coalesce(trim($"FIRST_NAME"), lit("")),
                lit(" ; "),
                coalesce(substring($"DOB", 5, 2), lit("")),
                lit("-"),
                coalesce(substring($"DOB", 7, 2), lit("")),
                lit("-"),
                coalesce(substring($"DOB", 1, 4), lit(""))
              )
            )
            .when($"DISPLAYID" === "NM_DOB_MRN",
              concat(
                coalesce(trim($"LAST_NAME"), lit("")),
                lit(", "),
                coalesce(trim($"FIRST_NAME"), lit("")),
                lit(" ; "),
                coalesce(substring($"DOB", 5, 2), lit("")),
                lit("-"),
                coalesce(substring($"DOB", 7, 2), lit("")),
                lit("-"),
                coalesce(substring($"DOB", 1, 4), lit("")),
                lit(" ; "),
                coalesce($"MEDICALRECORDNUMBER", lit(""))
              )
            )
            .when($"DISPLAYID".isNotNull,
              displayIdReplacerUdf($"DISPLAYID", coalesce($"FIRST_NAME", lit("")),
                coalesce($"LAST_NAME", lit("")),
                coalesce($"DOB", lit("")),
                coalesce($"MEDICALRECORDNUMBER", lit("")),
                coalesce($"MEDICALRECORDNUMBER", lit("")))

            )
            .otherwise(lit("NOT_SPECIFIED"))
        )

    patSumDisplayID.select(
      $"GROUPID", $"GRP_MPI",
      substring($"DOB", 1, 4).as("YOB"), substring($"DOB", 1, 6).as("MOB"), $"DOB",
      upper($"FIRST_NAME").as("FIRST_NAME"), upper($"LAST_NAME").as("LAST_NAME"), upper($"MIDDLE_NAME").as("MIDDLE_NAME"),
      when($"BEST_MAPPED_GENDER_CNT" > 1, "CH999999").otherwise($"MAPPED_GENDER").as("MAPPED_GENDER"),
      when($"BEST_MAPPED_RACE_CNT" > 1, "CH001643").otherwise($"MAPPED_RACE").as("MAPPED_RACE"),
      when($"BEST_MAPPED_ETHNICITY_CNT" > 1, "CH999999").otherwise($"MAPPED_ETHNICITY").as("MAPPED_ETHNICITY"),
      when($"BEST_MAPPED_ZIPCODE_CNT" > 1, "CH999999").otherwise($"MAPPED_ZIPCODE").as("MAPPED_ZIPCODE"),
      when($"BEST_MAPPED_LANGUAGE_CNT" > 1, "CH999999").otherwise($"MAPPED_LANGUAGE").as("MAPPED_LANGUAGE"),
      when($"BEST_MAPPED_MARITAL_STATUS_CNT" > 1, "CH999999").otherwise($"MAPPED_MARITAL_STATUS").as("MAPPED_MARITAL_STATUS"),
      $"MAPPED_DEATH_IND", $"DATE_OF_DEATH", $"LOCAL_DOD", $"SSDI_DOD", $"SSDI_NAME_MATCH",
      when($"DISPLAY_ID" =!= "", upper($"DISPLAY_ID")).as("DISPLAY_ID"),
      $"PATIENTID_CNT", $"INACTIVE_FLAG", $"RELIGION",
      when($"BEST_MAPPED_RACE_CNT" > 1, lit(1)).otherwise(lit(0)).as("MRACE_INFER_IND")
    )

  }
}