package com.optum.oap.backend.etl.common

import java.util.Date

import com.optum.oap.sparkdataloader.UserDefinedFunctionForDataLoader
import org.apache.spark.sql.SparkSession
import org.joda.time.{DateTime, Days}

object CalendarUDF extends UserDefinedFunctionForDataLoader {

  override def name: String = "calendarUDF"

  override def registerMe(sparkSession: SparkSession): Unit = {
    sparkSession.udf.register(name, calendarUDF _)
  }

  def calendarUDF(start: Date, stop: Date): Seq[DateInfo] = {
    val startDateTime = new DateTime(start)
    val stopDateTime = new DateTime(stop)

    val numberOfDays = Days.daysBetween(startDateTime, stopDateTime).getDays
    val seq = for (f <- 0 to numberOfDays) yield {
      val dt = startDateTime.plusDays(f)

      DateInfo(f + 1, dt.toString("yyyy-MM-dd"), dt.dayOfMonth().get(), dt.dayOfWeek().getAsText, dt.dayOfWeek().getAsShortText, dt.dayOfYear().get(),
        dt.getWeekOfWeekyear, (dt.getMonthOfYear / 3) + 1, dt.toString("MM"), dt.monthOfYear().getAsShortText, dt.monthOfYear().getAsText, dt.year().get(), dt.year().get().toString.concat(dt.toString("MM")))
    }
    seq
  }
}

case class DateInfo(Serial_Num: Int, CAL_DT: String, DT_DAYOFMONTH: Int, DT_DAY_NAME: String, DT_DAYOFWEEK: String, DT_DAYOFYEAR: Int,
                    DT_WEEKOFYEAR: Int, DT_QUARTER: Int, DT_MONTH_MM: String, DT_MONTH_NAME_ABBREV: String, DT_MONTH_NAME: String, DT_YEAR: Int, DT_yr_month: String)