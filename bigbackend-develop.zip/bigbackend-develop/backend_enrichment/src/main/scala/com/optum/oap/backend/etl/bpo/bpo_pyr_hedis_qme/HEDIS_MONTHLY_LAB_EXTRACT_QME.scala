package com.optum.oap.backend.etl.bpo.bpo_pyr_hedis_qme

import com.optum.oap.backend.cdrTempModel.hedis_monthly_lab_extract_qme
import com.optum.oap.cdr.models.{pp_bpo_labresult_claims, pp_bpo_member_detail}
import com.optum.oap.sparkdataloader.{RuntimeVariables, TableInfo, UserDefinedFunctionForDataLoader}
import org.apache.spark.sql.functions._
import org.apache.spark.sql.types.{IntegerType, StringType}
import org.apache.spark.sql.{DataFrame, SparkSession}

object HEDIS_MONTHLY_LAB_EXTRACT_QME extends TableInfo[hedis_monthly_lab_extract_qme] {

  override def dependsOn: Set[String] = Set("PP_BPO_MEMBER_DETAIL","PP_BPO_LABRESULT_CLAIMS")

  override def name = "HEDIS_MONTHLY_LAB_EXTRACT_QME"

  override def createDataFrame(sparkSession: SparkSession,
                               loadedDependencies: Map[String, DataFrame],
                               udfMap: Map[String, UserDefinedFunctionForDataLoader],
                               runtimeVariables: RuntimeVariables): DataFrame = {

      import sparkSession.implicits._


      val hedis_patients=loadedDependencies("PP_BPO_MEMBER_DETAIL").as[pp_bpo_member_detail]
      val pp_bpo_labresult_claims= loadedDependencies("PP_BPO_LABRESULT_CLAIMS").as[pp_bpo_labresult_claims]

    val hedis_patients_final= hedis_patients.where($"lineofbusinessid".isNotNull && $"healthplansource" === lit("PAYER")).select($"memberid").distinct

    pp_bpo_labresult_claims.alias("lc").join(hedis_patients_final.alias("hp"), $"lc.MEMBERID" === $"hp.MEMBERID", "inner").where($"lc.healthplansource" === lit("PAYER")).select(
      $"lc.MEMBERID".as("MemberID"),
      $"CLAIMHEADER".as("ClaimHeaderID"),
      date_format($"SERVICEDATE", "yyyy-MM-dd").cast(StringType).as("ServiceDate"),
      $"LOINC".as("LOINC"),
      $"TESTRESULTNUMBER".cast(StringType).as("TestResultNumber"),
      $"TESTRESULTUNITS".as("TestResultUnits"),
      when($"TESTRESULTTEXT".isin("Positive","Y"), "Positive").otherwise(when($"TESTRESULTTEXT".isin("Negative","N"), "Negative").otherwise(lit(null)).cast(StringType)).as("TestResultText"),
      lit("SS").as("MapSource"),
      $"HEALTHPLANSOURCE".as("HealthPlanSource"),
      $"CPT_CODE".as("CPTCode"),
      lit(null).cast(StringType).as("ProviderID"),
      lit(null).cast(StringType).as("OrderingProviderID"),
      lit(null).cast(StringType).as("GroupCode")
    )
  }

}
