package com.optum.oap.backend.etl.patient_matching.quality_gates

import com.optum.oap.backend.cdrTempModel.pat_match_prep
import com.optum.oap.backend.etl.common.{CDRConstants, EnrichmentUtils}
import com.optum.oap.backend.loader.EnrichmentRunTimeVariables
import com.optum.oap.cdr.models._
import com.optum.oap.sparkdataloader.{RuntimeVariables, TableInfo, UserDefinedFunctionForDataLoader}
import org.apache.spark.sql.functions._
import org.apache.spark.sql.{DataFrame, Dataset, Row, SparkSession}

object QGATE_PATIENT_ID_SUSPECTS extends TableInfo[qgate_patient_id_suspects] {
  override def dependsOn = Set("PAT_MATCH_PREP", "MAP_PREDICATE_VALUES", "CDR_FE_PATIENTADDR", "ECDR_PATIENTADDR"
    , "PATIENTDETAIL_PREMATCH", "ECDR_PATIENTDETAIL_PREMATCH", "MAP_GENDER", "ICPM_PATIENTADDR")

  override def name = "QGATE_PATIENT_ID_SUSPECTS"

  override def createDataFrame(sparkSession: SparkSession,
                               loadedDependencies: Map[String, DataFrame],
                               udfMap: Map[String, UserDefinedFunctionForDataLoader],
                               runtimeVariables: RuntimeVariables): DataFrame = {
    import sparkSession.implicits._

    val dailyBuild = if (runtimeVariables.asInstanceOf[EnrichmentRunTimeVariables].buildType == CDRConstants.DELTA_BUILD_TYPE) true else false

    val patMatchPrep = loadedDependencies("PAT_MATCH_PREP").as[pat_match_prep]
    val mapPredicateValues = broadcast(loadedDependencies("MAP_PREDICATE_VALUES").as[map_predicate_values])

    val mapGender = broadcast(loadedDependencies("MAP_GENDER").as[map_gender])

    val patientAddr1 = {
      if (dailyBuild) {
        loadedDependencies("CDR_FE_PATIENTADDR").drop("row_source","modified_date").as[patientaddr]
          .unionByName(loadedDependencies("ECDR_PATIENTADDR").drop("row_source","modified_date").as[patientaddr])
          .distinct()
      } else {
        loadedDependencies("CDR_FE_PATIENTADDR").drop("row_source","modified_date").as[patientaddr]
      }
    }

    val icpm_patientAddr = loadedDependencies("ICPM_PATIENTADDR").drop("row_source","modified_date").as[patientaddr]
    val patientAddr = patientAddr1.unionByName(icpm_patientAddr)

    val patientDetailGender = {
      val whereCondition = $"patientdetailtype" === lit("GENDER")
      if (dailyBuild) {
        val patientDetailPrematchDf = loadedDependencies("PATIENTDETAIL_PREMATCH").drop("row_source","modified_date").as[patientdetail]
        val ecdrPatientDetailPrematchDf = EnrichmentUtils.removeRowSourceAndModifiedDate(loadedDependencies("ECDR_PATIENTDETAIL_PREMATCH")).drop("row_source","modified_date").as[patientdetail]
        patientDetailPrematchDf.where(whereCondition).unionByName(ecdrPatientDetailPrematchDf.where(whereCondition).as[patientdetail]).distinct()
      } else {
        loadedDependencies("PATIENTDETAIL_PREMATCH").drop("row_source","modified_date").where(whereCondition).as[patientdetail]
      }
    }

    val temp = patMatchPrep.as("pts")
      .join(patientAddr.as("pad"), Seq("patientid", "client_ds_id"), "left")
      .join(patientDetailGender.as("pdet"), Seq("patientid", "client_ds_id"), "left")
      .join(mapGender.as("mg"), $"pdet.localvalue" === $"mg.mnemonic", "left")
      .groupBy($"pts.patientid", $"pts.client_ds_id", $"pts.groupid")
      .agg(
        when(countDistinct(regexp_replace(lower($"pts.lname"), "[^a-z]", "")) > 1 &&
          countDistinct($"pts.dob") > 1, lit(1)
        ).otherwise(null).as("gate1"),
        when(countDistinct(lower($"pts.fname")) > 1 &&
          countDistinct(when($"mg.cui".isInCollection(CDRConstants.MALE_AND_FEMALE_CUIS), $"mg.cui").otherwise(null)) > 1 &&
          countDistinct(lower($"address_line1")) > 1 &&
          countDistinct($"pts.dob") > 1, lit(1)
        ).otherwise(null).as("gate2"),
        when(
          sum(
            when(upper(substring($"lname", 0, 2)).isin("XX", "ZZ"), 1).otherwise(0)
          ) === count("*"), lit(1)
        ).otherwise(0).as("gate3")
      )

    temp
      .where($"gate1" === lit(1) || $"gate2" === lit(1) || $"gate3" === lit(1))
      .flatMap(gates1and2and3)
      .union(gate4(sparkSession, patMatchPrep, mapPredicateValues))
      .toDF
  }

  private def gates1and2and3(row: Row): Seq[qgate_patient_id_suspects] = {
    val groupId = row.getAs[String]("groupid")
    val clientDsId = row.getAs[Integer]("client_ds_id")
    val patientId = row.getAs[String]("patientid")
    val gate1: Option[qgate_patient_id_suspects] = if (row.getAs[Integer]("gate1") == 1)
      Some(qgate_patient_id_suspects(clientDsId, 1, groupId, patientId)) else None
    val gate2: Option[qgate_patient_id_suspects] = if (row.getAs[Integer]("gate2") == 1)
      Some(qgate_patient_id_suspects(clientDsId, 2, groupId, patientId)) else None
    val gate3: Option[qgate_patient_id_suspects] = if (row.getAs[Integer]("gate3") == 1)
      Some(qgate_patient_id_suspects(clientDsId, 3, groupId, patientId)) else None

    Seq(gate1, gate2, gate3).flatten
  }

  private def gate4(sparkSession: SparkSession, tempPatMatchPrep: Dataset[pat_match_prep], mapPredicateValues: Dataset[map_predicate_values]): Dataset[qgate_patient_id_suspects] = {
    import sparkSession.implicits._

    val cdsIdList: Seq[Integer] = mapPredicateValues.where(
      $"data_src" === lit("CDR") &&
        $"entity" === lit("QGATE_PATIENT") &&
        $"table_name" === lit("APPLY_GATE_4") &&
        upper($"column_value") === lit("Y")
    ).select($"client_ds_id").collect.toSeq.map(_.getAs[Integer](0))

    tempPatMatchPrep.as("pts")
      .where($"pts.client_ds_id".isin(cdsIdList: _*))
      .groupBy($"pts.patientid", $"pts.client_ds_id", $"pts.groupid")
      .agg(
        when(countDistinct(lower(substring($"pts.fname", 0, 3))) > 1 &&
          countDistinct(lower(substring($"pts.lname", 0, 3))) > 1, 4
        ).otherwise(null).as("gate_id")
      )
      .where($"gate_id" === lit(4))
      .select($"client_ds_id", $"gate_id", $"groupid", $"patientid").as[qgate_patient_id_suspects]
  }
}
