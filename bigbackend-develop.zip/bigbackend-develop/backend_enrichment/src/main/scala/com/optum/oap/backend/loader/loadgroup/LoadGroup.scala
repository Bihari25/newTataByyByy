package com.optum.oap.backend.loader.loadgroup

import com.optum.oap.backend.loader.EnrichmentLoader.{logger, recoverPartitions}
import com.optum.oap.backend.loader.{CDRBELoaderPerformanceAnalysis, EnrichmentQueryRegistry, EnrichmentRunTimeVariables}
import com.optum.oap.sparkdataloader.TableInfo
import org.apache.spark.sql.SparkSession
import org.slf4j.LoggerFactory

trait LoadGroup extends CDRBELoaderPerformanceAnalysis {
  private val logger = LoggerFactory.getLogger(this.getClass)

  def loadGroup: String
  def initialDependencies(runTimeVariables: EnrichmentRunTimeVariables, sparkSession: SparkSession) : Seq[TableInfo[_ <: Product with Serializable]]
  def queryRegistry(runTimeVariables: EnrichmentRunTimeVariables, sparkSession: SparkSession): Seq[TableInfo[_ <: Product with Serializable]] = {
    EnrichmentQueryRegistry.metricsQueryRegistry
  }

  final def refreshXRefTables(enrichmentRunTimeVariables: EnrichmentRunTimeVariables, sparkSession: SparkSession) = {
    implicit val session = sparkSession
    //Added this if to make QueryIntegrationTest happy.
    if(!enrichmentRunTimeVariables.cdrSchema.equals("test")) {
      logger.warn("Refreshing XREF tables")
      val xRefTables = Seq("PROVIDER_XREF", "PATIENT_XREF", "FACILITY_XREF")
      xRefTables.foreach( table => {
        recoverPartitions(enrichmentRunTimeVariables.cdrSchema, table)
      })
    }
  }
}
