package com.optum.oap.backend.etl.enrichment

import com.optum.oap.backend.etl.common.MapMasterIds
import com.optum.oap.cdr.models.{appointment, patient_mpi, zh_provider_master_xref}
import com.optum.oap.sparkdataloader.{RuntimeVariables, TableInfo, UserDefinedFunctionForDataLoader}
import org.apache.spark.sql.functions.broadcast
import org.apache.spark.sql.{DataFrame, SparkSession}
import org.slf4j.LoggerFactory

object APPOINTMENT extends TableInfo[appointment] {

  val log = LoggerFactory.getLogger(this.getClass)

  override def dependsOn = Set("PATIENT_MPI", "ZH_PROVIDER_MASTER_XREF", "CDR_FE_APPOINTMENT")

  override def name = "APPOINTMENT"

  override def saveDataFrameToParquet: Boolean = true

  override def partitions: Int = 32

  override def skipTable: Boolean = false

  override def ignoreExtraColumnsInDataFrame: Boolean = true

  override def createDataFrame(sparkSession: SparkSession,
                               loadedDependencies: Map[String, DataFrame],
                               udfMap: Map[String, UserDefinedFunctionForDataLoader],
                               runtimeVariables: RuntimeVariables): DataFrame = {
    import sparkSession.implicits._

    val appointmentIn = loadedDependencies("CDR_FE_APPOINTMENT").as[appointment]
    val provXref = broadcast(loadedDependencies("ZH_PROVIDER_MASTER_XREF")).as[zh_provider_master_xref]
    val patXref = loadedDependencies("PATIENT_MPI").as[patient_mpi]

    MapMasterIds.mapProviderIds(MapMasterIds.mapPatientIds(appointmentIn.toDF, patXref.toDF, false), provXref.toDF(), "providerid", "mstrprovid")
  }
}
