package com.optum.oap.backend.etl.enrichment

import com.optum.oap.backend.etl.common.MapMasterIds
import com.optum.oap.cdr.models.{zh_prov_attribute, zh_provider_master_xref}
import com.optum.oap.sparkdataloader.{RuntimeVariables, TableInfo, UserDefinedFunctionForDataLoader}
import org.apache.spark.sql.functions.broadcast
import org.apache.spark.sql.{DataFrame, SparkSession}
import org.slf4j.LoggerFactory

object ZH_PROV_ATTRIBUTE extends TableInfo[zh_prov_attribute] {

  val log = LoggerFactory.getLogger(this.getClass)

  override def dependsOn = Set("ZH_PROVIDER_MASTER_XREF", "CDR_FE_ZH_PROV_ATTRIBUTE", "ICPM_PROVIDER_ATTRIBUTES")

  override def name = "ZH_PROV_ATTRIBUTE"

  override def saveDataFrameToParquet: Boolean = true

  override def partitions: Int = 32

  override def skipTable: Boolean = false

  override def ignoreExtraColumnsInDataFrame: Boolean = true

  override def createDataFrame(sparkSession: SparkSession,
                               loadedDependencies: Map[String, DataFrame],
                               udfMap: Map[String, UserDefinedFunctionForDataLoader],
                               runtimeVariables: RuntimeVariables): DataFrame = {
    import sparkSession.implicits._

    val zh_prov_attributeIn1 = loadedDependencies("CDR_FE_ZH_PROV_ATTRIBUTE").drop("row_source","modified_date").as[zh_prov_attribute]
    val icpmZhProvAttribute = loadedDependencies("ICPM_PROVIDER_ATTRIBUTES").as[zh_prov_attribute]
    val zh_prov_attributeIn = zh_prov_attributeIn1.unionByName(icpmZhProvAttribute)
    val provXref = broadcast(loadedDependencies("ZH_PROVIDER_MASTER_XREF")).as[zh_provider_master_xref]

    MapMasterIds.mapProviderIds(zh_prov_attributeIn.toDF, provXref.toDF, "localproviderid", "master_hgprovid")
  }

}
