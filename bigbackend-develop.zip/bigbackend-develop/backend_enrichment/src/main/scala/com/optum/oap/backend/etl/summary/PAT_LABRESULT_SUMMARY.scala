package com.optum.oap.backend.etl.summary

import com.optum.oap.backend.etl.common.CDRConstants
import com.optum.oap.cdr.models.{labresult, pat_labresult_summary}
import com.optum.oap.sparkdataloader.{RuntimeVariables, TableInfo, UserDefinedFunctionForDataLoader}
import org.apache.spark.sql.functions._
import org.apache.spark.sql.types.{DoubleType, IntegerType, StringType}
import org.apache.spark.sql.{DataFrame, SparkSession}
import org.slf4j.LoggerFactory

object PAT_LABRESULT_SUMMARY extends TableInfo[pat_labresult_summary] {

  val log = LoggerFactory.getLogger( this.getClass )

  override def dependsOn = Set( "LABRESULT" )

  override def name = "PAT_LABRESULT_SUMMARY"

  override def saveDataFrameToParquet: Boolean = true

  override def partitions: Int = 256

  override def skipTable: Boolean = false

  override def ignoreExtraColumnsInDataFrame: Boolean = false

  override def createDataFrame( sparkSession: SparkSession,
                                loadedDependencies: Map[String, DataFrame],
                                udfMap: Map[String, UserDefinedFunctionForDataLoader],
                                runtimeVariables: RuntimeVariables ): DataFrame = {

    import sparkSession.implicits._

    val labresult = loadedDependencies( "LABRESULT" ).as[labresult]

    val summary = labresult
      .filter( 'datecollected.isNotNull && 'grp_mpi.isNotNull )
      .select(
        'groupid,
        'grp_mpi,
        coalesce( 'mappedcode, lit( "CH999990" ) ).alias( "labcui" ),
        date_format( 'datecollected, "yyyy" ).alias( "dt_yr" ),
        quarter( 'datecollected ).cast( StringType ).alias( "dt_qtr" ),
        date_format( 'datecollected, "MM" ).alias( "dt_month" ),
        date_format( 'datecollected, CDRConstants.DATE_FORMAT_4Y2M2D ).alias( "dt_yyyymmdd" ),
        'normalizedvalue.cast( DoubleType ).alias( "normalizedvalue" )
      )
      .groupBy( "groupid", "grp_mpi", "labcui", "dt_yr", "dt_qtr", "dt_month" )
      .agg(
        min( 'normalizedvalue ).alias( "min_val" ),
        max( 'normalizedvalue ).alias( "max_val" ),
        countDistinct( 'dt_yyyymmdd ).cast( IntegerType ).alias( "cnt" )
      )

    summary.select( "groupid", "grp_mpi", "labcui", "dt_yr", "dt_qtr", "dt_month", "min_val", "max_val", "cnt" )
  }

}
