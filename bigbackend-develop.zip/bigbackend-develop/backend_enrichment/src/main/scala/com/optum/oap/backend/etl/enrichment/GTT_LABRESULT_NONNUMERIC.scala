package com.optum.oap.backend.etl.enrichment

import com.optum.oap.backend.cdrTempModel.gtt_labresult_nonnumeric
import com.optum.oap.cdr.models.labresult
import com.optum.oap.sparkdataloader.{RuntimeVariables, TableInfo, UserDefinedFunctionForDataLoader}
import org.apache.spark.sql.{DataFrame, SparkSession}
import org.slf4j.LoggerFactory
import org.apache.spark.sql.functions._
import org.apache.spark.sql.types.DataTypes

object GTT_LABRESULT_NONNUMERIC extends TableInfo[gtt_labresult_nonnumeric] {

  private val log = LoggerFactory.getLogger(this.getClass)

  override def dependsOn = Set("ICPM_LABRESULT_CACHE")

  override def name = "GTT_LABRESULT_NONNUMERIC"

  override def partitions: Int = 32

  override def createDataFrame(sparkSession: SparkSession,
                               loadedDependencies: Map[String, DataFrame],
                               udfMap: Map[String, UserDefinedFunctionForDataLoader],
                               runtimeVariables: RuntimeVariables): DataFrame = {

    import sparkSession.implicits._

    val icpmLabresultCache = loadedDependencies("ICPM_LABRESULT_CACHE").as[labresult]

    icpmLabresultCache.filter($"localresult_numeric".isNull).select(
       $"groupid"
      , $"datasrc"
      , $"patientid"
      , $"labresultid"
      , $"localresult"
      , $"localcode"
      , $"localname"
      , $"normalrange"
      , $"localunits"
      , $"localtestname"
      , $"datecollected"
      , $"labordereddate".cast(DataTypes.DateType).as("labordereddate")
      , $"dateavailable"
      , $"labresult_date"
      , expr(
        """
          |nullif(SUBSTR(localresult,1,CASE WHEN INSTR(substr(localresult, 25),' ') = 0 THEN LENGTH(localresult)
          |ELSE INSTR(substr(localresult, 25),' ')+24
          |END), '')
        """.stripMargin).as("localresult_25")
      , $"client_ds_id"
      , $"localspecimentype"
      , $"local_loinc_code"
      , $"encounterid"
      , $"resulttype"
      , $"localresult_numeric".cast(DataTypes.createDecimalType(38,18)).as("localresult_numeric")
      , $"localresult_inferred".cast(DataTypes.createDecimalType(38,18)).as("localresult_inferred")
      , $"normalizedvalue".cast(DataTypes.createDecimalType(38,18)).as("normalizedvalue")
      , $"hgpid".cast(DataTypes.StringType).as("hgpid")
      , lit(null).cast(DataTypes.StringType).as("facilityid")
      , lit(null).cast(DataTypes.StringType).as("grp_mpi")
      , lit(null).cast(DataTypes.StringType).as("laborderid")
      , lit(null).cast(DataTypes.StringType).as("locallisresource")
      , lit(null).cast(DataTypes.StringType).as("localunits_inferred")
      , lit(null).cast(DataTypes.StringType).as("mappedcode")
      , lit(null).cast(DataTypes.StringType).as("mappedloinc")
      , lit(null).cast(DataTypes.StringType).as("mappedname")
      , lit(null).cast(DataTypes.StringType).as("mappedunits")
      , lit(null).cast(DataTypes.StringType).as("relativeindicator")
      , lit(null).cast(DataTypes.StringType).as("resultstatus")
      , lit(null).cast(DataTypes.StringType).as("statuscode")
    )

  }

}
