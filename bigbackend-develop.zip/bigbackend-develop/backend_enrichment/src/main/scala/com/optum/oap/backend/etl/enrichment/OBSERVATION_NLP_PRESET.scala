package com.optum.oap.backend.etl.enrichment

import com.optum.oap.backend.etl.common.{Functions, MapMasterIds, Observations}
import com.optum.oap.backend.loader.EnrichmentRunTimeVariables
import com.optum.oap.backend.cdrTempModel.{observation_nlp_preset, concept_event_2, concept_event_result_parent_2}
import com.optum.oap.sparkdataloader.{RuntimeVariables, TableInfo, UserDefinedFunctionForDataLoader}
import org.apache.spark.sql.functions._
import org.apache.spark.sql.types.IntegerType
import org.apache.spark.sql.{DataFrame, Dataset, SparkSession}

object OBSERVATION_NLP_PRESET extends TableInfo[observation_nlp_preset] {
  override def dependsOn = Set("CONCEPT_EVENT_RESULT_PARENT_2", "CONCEPT_EVENT_2")

  override def name = "OBSERVATION_NLP_PRESET"

  override def partitions: Int = 128

  override def ignoreExtraColumnsInDataFrame: Boolean = true

  override def createDataFrame(sparkSession: SparkSession,
                               loadedDependencies: Map[String, DataFrame],
                               udfMap: Map[String, UserDefinedFunctionForDataLoader],
                               runtimeVariables: RuntimeVariables): DataFrame = {
    import sparkSession.implicits._

    val partitionMultiplier = EnrichmentRunTimeVariables(runtimeVariables).partitionMultiplier

    val grpid = EnrichmentRunTimeVariables(runtimeVariables).clientId
    // handle groups with existing NLP data that has null cdsid (from SOA files).  TODO re-evaluate if this is still required with SOA team
    val cdsid_df = broadcast(Seq(grpid match {
      case "H406239" => "721"
      case "H770635" => "45"
      case "H973241" => "1201"
      case _ => null
    }).toDF("default_cdsid"))

    val lConceptAll = loadedDependencies("CONCEPT_EVENT_2")
      .where($"project".isin("lvef", "fev1_fvc"))
      .as[concept_event_2]
    
    // get max version per project
    val lConceptMaxVersion = broadcast(lConceptAll
      .groupBy("project")
      .agg(max("project_version").as("project_version")))
    // keep only records for max version
    val lConcept = lConceptAll.as("all")
      .join(lConceptMaxVersion.as("max"), $"all.project" === $"max.project"  && $"all.project_version" === $"max.project_version", "inner")
      .select($"all.*")
      .as[concept_event_2]

    val lConceptParentAll = loadedDependencies("CONCEPT_EVENT_RESULT_PARENT_2")
      .where($"project".isin("lvef", "fev1_fvc"))
      .as[concept_event_result_parent_2]
        
    // keep only records for max version
    val lConceptParentLatest = lConceptParentAll.as("all")
      .join(lConceptMaxVersion.as("max"), $"all.project" === $"max.project"  && $"all.project_version" === $"max.project_version", "inner")
      .select($"all.*")
      .as[concept_event_result_parent_2]

    val lConceptParent = lConceptParentLatest.where($"concept_nm".isin("observable", "result_min", "result_max", "modifier", "date", "result_num", "units")  )

    val pSet = lConceptParent.where($"par_concept_event_result_key".isNull && $"concept_nm" === "observable")
      .groupBy($"docid", $"concept_event_result_key")
      .agg(max($"concept_normalized_val").as("observable"))

    val cSet = getChildSet(sparkSession, lConceptParent.where($"par_concept_event_result_key".isNotNull && $"concept_nm".isin("result_min", "result_max", "modifier", "date", "result_num", "units")).as[concept_event_result_parent_2])

    val finalSet = cSet.as("c")
      .join(pSet.as("p"), $"p.concept_event_result_key" === $"c.par_concept_event_result_key", "inner") // get observable column
      .join(lConcept.as("vw"), $"vw.docid" === $"p.docid", "inner")
      .crossJoin(cdsid_df.as("cd"))
      .select(
        $"vw.groupid",
        coalesce($"vw.client_ds_id", $"cd.default_cdsid").cast(IntegerType).as("client_ds_id"),
        $"vw.patientid",
        when($"vw.encounterid".contains("?"), lit(null)).otherwise($"vw.encounterid").as("encounterid"),
        $"vw.encounterdate",
        when($"c.units".isNotNull, concat($"p.observable", lit("_"), $"c.units")).otherwise($"p.observable").as("localcode"),
        $"c.result_min",
        $"c.result_max",
        $"c.result_num",
        $"c.modifier",
        $"c.result_date",
        $"c.units",
        $"c.concept_dt_guess",
        $"c.concept_dt_type",
        lit("nlp").as("datasrc")
      ).distinct()

    finalSet.filter($"client_ds_id".isNotNull)
  }

  private def getChildSet(sparkSession: SparkSession,
                          lChild: Dataset[concept_event_result_parent_2]): DataFrame = {
    import sparkSession.implicits._

    val childSetPre = lChild
      .groupBy($"par_concept_event_result_key", $"concept_event_result_frameid")
      .pivot($"concept_nm", Seq("result_min", "result_max", "modifier", "date", "result_num", "units"))
      .agg(max($"concept_normalized_val"))

    val childSet = childSetPre.as("c1")
      .join(lChild.as("c2"), $"c1.concept_event_result_frameid" === $"c2.concept_event_result_frameid" && $"c2.concept_nm" === "date", "left_outer")
      .select(
        $"c1.par_concept_event_result_key",
        $"c1.concept_event_result_frameid",
        $"c1.result_min",
        $"c1.result_max",
        $"c1.result_num",
        $"c1.modifier",
        $"c1.date".as("result_date"),
        $"c1.units",
        $"c2.concept_dt_guess",
        $"c2.concept_dt_type"
      )

    childSet
  }
}
