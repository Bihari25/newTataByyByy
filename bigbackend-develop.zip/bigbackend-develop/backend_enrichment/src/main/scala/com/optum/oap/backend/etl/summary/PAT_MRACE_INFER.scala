package com.optum.oap.backend.etl.summary

import com.optum.oap.backend.etl.common.CDRConstants
import com.optum.oap.cdr.models._
import com.optum.oap.sparkdataloader.{RuntimeVariables, TableInfo, UserDefinedFunctionForDataLoader}
import org.apache.spark.sql.expressions.Window
import org.apache.spark.sql.functions._
import org.apache.spark.sql.types.StringType
import org.apache.spark.sql.{DataFrame, SparkSession}
import org.slf4j.LoggerFactory

object PAT_MRACE_INFER extends TableInfo[pat_mrace_infer] {
  val log = LoggerFactory.getLogger(this.getClass)
  override def dependsOn =  Set("PATIENT_SUMMARY", "PATIENTDETAIL", "MAP_RACE", "PATIENT_SUMMARY_GRP_MPI")
  override def name = "PAT_MRACE_INFER"

  override def saveDataFrameToParquet: Boolean = true
  override def partitions: Int = 256
  override def skipTable: Boolean = false
  override def ignoreExtraColumnsInDataFrame: Boolean = false

  override def createDataFrame (sparkSession: SparkSession,
                                loadedDependencies: Map[String, DataFrame],
                                udfMap: Map[String, UserDefinedFunctionForDataLoader],
                                runtimeVariables: RuntimeVariables): DataFrame = {
    import sparkSession.implicits._

    val patientSummary = loadedDependencies("PATIENT_SUMMARY").as[patient_summary]

    val temp_patientdetail =loadedDependencies("PATIENTDETAIL").where($"patientdetailtype" === lit("RACE")).as[patientdetail]
    val map_race = loadedDependencies("MAP_RACE").as[map_race]

    val temp_race = temp_patientdetail
      .join(broadcast(map_race), temp_patientdetail("LOCALVALUE") === map_race("MNEMONIC") && temp_patientdetail("GROUPID") === map_race("GROUPID"), "left_outer")
      .filter($"cui" =!= lit("CH000056"))          //exclude Unknown

    val df1 = patientSummary
      .where($"MRACE_INFER_IND" === lit(1)).as("ps")
      .join(temp_race.as("tr"), Seq("GROUPID", "CLIENT_DS_ID", "PATIENTID") )
      .select($"ps.GROUPID", $"ps.GRP_MPI", $"ps.CLIENT_DS_ID", $"tr.CUI".as("mapped_race"))
      .distinct()

    val patientSummaryGrpMpi = loadedDependencies("PATIENT_SUMMARY_GRP_MPI").where($"MRACE_INFER_IND" === lit(1)).as[patient_summary_grp_mpi]

    val df2 = patientSummaryGrpMpi.as("pm")
      .join(patientSummary.as("ps"), Seq("GROUPID", "GRP_MPI"))
      .select($"pm.GROUPID", $"pm.GRP_MPI", $"ps.CLIENT_DS_ID", $"pm.MAPPED_RACE")
      .distinct()

    df1.union(df2)

  }
}