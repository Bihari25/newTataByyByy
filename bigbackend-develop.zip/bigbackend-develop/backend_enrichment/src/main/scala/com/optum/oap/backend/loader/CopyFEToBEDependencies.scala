package com.optum.oap.backend.loader

import com.optum.oap.backend.cdrTempModel._
import com.optum.oap.cdr.models._
import com.optum.oap.sparkdataloader.LoadFromHive

object copyCommonDependecies {
  def copyCommonTables(cdrDB: String, saveToDB: Boolean) = {
    Seq(
      LoadFromHive[care_management_pathway](tableName = "CARE_MANAGEMENT_PATHWAY", referenceName = None, hiveDatabase = cdrDB, saveDataFrameToParquet = saveToDB),
      LoadFromHive[care_management_program](tableName = "CARE_MANAGEMENT_PROGRAM", referenceName = None, hiveDatabase = cdrDB, saveDataFrameToParquet = saveToDB),
      LoadFromHive[cc_user](tableName = "CC_USER", referenceName = None, hiveDatabase = cdrDB, saveDataFrameToParquet = saveToDB),
      LoadFromHive[claim_attribute](tableName = "CLAIM_ATTRIBUTE", referenceName = None, hiveDatabase = cdrDB, saveDataFrameToParquet = saveToDB),
      LoadFromHive[contract_cdsid_xwalk](tableName = "CONTRACT_CDSID_XWALK", referenceName = None, hiveDatabase = cdrDB, saveDataFrameToParquet = saveToDB),
      LoadFromHive[general_domain_map_src](tableName = "GENERAL_DOMAIN_MAP_SRC", referenceName = None, hiveDatabase = cdrDB, saveDataFrameToParquet = saveToDB),
      LoadFromHive[int_claim_labresult](tableName = "INT_CLAIM_LABRESULT", referenceName = None, hiveDatabase = cdrDB, saveDataFrameToParquet = saveToDB),
      LoadFromHive[master_hgprovid_diff](tableName = "MASTER_HGPROVID_DIFF", referenceName = None, hiveDatabase = cdrDB, saveDataFrameToParquet = saveToDB),
      LoadFromHive[medication_map_src](tableName = "MEDICATION_MAP_SRC", referenceName = None, hiveDatabase = cdrDB, saveDataFrameToParquet = saveToDB),
      LoadFromHive[mv_hts_domain_concept](tableName = "MV_HTS_DOMAIN_CONCEPT", referenceName = None, hiveDatabase = cdrDB, saveDataFrameToParquet = saveToDB),
      LoadFromHive[pat_id_xwalk](tableName = "PAT_ID_XWALK", referenceName = None, hiveDatabase = cdrDB, saveDataFrameToParquet = saveToDB),
      LoadFromHive[provider_classification](tableName = "PROVIDER_CLASSIFICATION", referenceName = None, hiveDatabase = cdrDB, saveDataFrameToParquet = saveToDB),
      LoadFromHive[qgate_new_evidence_patient_id](tableName = "QGATE_NEW_EVIDENCE_PATIENT_ID", referenceName = None, hiveDatabase = cdrDB, saveDataFrameToParquet = saveToDB),
      LoadFromHive[qgate_new_evidence_person_id](tableName = "QGATE_NEW_EVIDENCE_PERSON_ID", referenceName = None, hiveDatabase = cdrDB, saveDataFrameToParquet = saveToDB),
      LoadFromHive[ref_imap_em_proc](tableName = "REF_IMAP_EM_PROC", referenceName = None, hiveDatabase = cdrDB, saveDataFrameToParquet = saveToDB),
      LoadFromHive[schema_init](tableName = "SCHEMA_INIT", referenceName = None, hiveDatabase = cdrDB, saveDataFrameToParquet = saveToDB),
      LoadFromHive[zh_appt_location](tableName = "ZH_APPT_LOCATION", referenceName = None, hiveDatabase = cdrDB, saveDataFrameToParquet = saveToDB),
      LoadFromHive[zh_facility_rollup](tableName = "ZH_FACILITY_ROLLUP", referenceName = None, hiveDatabase = cdrDB, saveDataFrameToParquet = saveToDB),
      LoadFromHive[zh_service_line](tableName = "ZH_SERVICE_LINE", referenceName = None, hiveDatabase = cdrDB, saveDataFrameToParquet = saveToDB),
      LoadFromHive[zh_v_provider](tableName = "ZH_V_PROVIDER", referenceName = None, hiveDatabase = cdrDB, saveDataFrameToParquet = saveToDB),
      LoadFromHive[org_rollup](tableName = "ORG_ROLLUP", referenceName = None, hiveDatabase = cdrDB, saveDataFrameToParquet = saveToDB),
      LoadFromHive[zh_cc_care_plan_subtype](tableName = "ZH_CC_CARE_PLAN_SUBTYPE", referenceName = None, hiveDatabase = cdrDB, saveDataFrameToParquet = saveToDB),
      LoadFromHive[zh_cc_care_plan_type](tableName = "ZH_CC_CARE_PLAN_TYPE", referenceName = None, hiveDatabase = cdrDB, saveDataFrameToParquet = saveToDB),
      LoadFromHive[zh_cc_case_status](tableName = "ZH_CC_CASE_STATUS", referenceName = None, hiveDatabase = cdrDB, saveDataFrameToParquet = saveToDB)
    )
  }
}

/**
  * ToDo - Remove this. Moved this functionality to the FE enrichment step.
  */
object CopyFEToBEDependencies {
  def copyAllFromFeToBe(cdrDB: String) = {
      copyCommonDependecies.copyCommonTables(cdrDB, true)
  }
}
