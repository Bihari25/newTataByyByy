package com.optum.oap.backend.etl.cdrfe

import com.optum.oap.sparkdataloader.TableInfo
import org.apache.spark.sql.functions.lit
import org.apache.spark.sql.{Column, DataFrame}
import org.apache.spark.sql.types.DataType

import scala.language.implicitConversions
import scala.util.Try

trait CDRBESchemaHelper { self: TableInfo[_ <: Product] =>

  import CDRDataTypeHelper._

  val columnsToIgnore = Seq("row_source", "modified_date")

  /**
    * Parse the CDR-Contract datatype mapping file and convert it to an instance of CDRSparkDataType
    * @param tableName CDRBE table name
    * @return
    */
  def schemaForTable(tableName: String): Seq[CDRSparkDataType] = {
    CDRBE_DATATYPE_MAPPING
      .filter(x => x.split("\\|")(0).equalsIgnoreCase(tableName))
      .map(record => {
        val data = record.split("\\|")
        val tableName = data(0)
        val columnName = data(1)
        val dataType = data(2)
        val precision = Try(data(3).toInt).toOption
        val scale = Try(data(4).toInt).toOption
        CDRSparkDataType(tableName, columnName, CDRDataType(dataType, precision, scale))
      })
  }

  /**
    * Applies CDRBE datatype's to the CDRFE dataframe. The number of columns in CDRFE dataframe
    * should be same as the number of columns in CDRBE datatype mapping file.
    * @param dataFrame Dataframe containing CDRFE data
    * @param dataType Datatype derived from the CDR-Contract datatype mapping file
    * @return
    */
  def castToCDRBESchema(dataFrame: DataFrame, dataType: Seq[CDRSparkDataType]): DataFrame = {
    val cdrfeColumns = dataFrame.schema.map(_.name.toLowerCase).toSet
    val datatypeMap = dataType.map(x => x.fieldName.toLowerCase -> x.sparkDataType).toMap
    val (existingColumns, missingColumns) = datatypeMap.keys.partition(x => cdrfeColumns.contains(x.toLowerCase))
    // This is for debugging purpose. Ideally the columns should match between CDRFE and CDRBE
    missingColumns.foreach(x => logger.warn(s"${x} doesn't exist in the CDRFE Schema for table ${dataType.head.tableName}"))

    val columns = datatypeMap.keys.toSeq.sorted.map(field => {
      field.toLowerCase match {
        case x if cdrfeColumns.contains(x) => dataFrame.col(x).cast(datatypeMap(x))
        case _ => lit(null).as(field).cast(datatypeMap(field))
      }
    })
    dataFrame.select(columns: _*)
  }
}

case class CDRSparkDataType(tableName: String, fieldName: String, sparkDataType: DataType)


