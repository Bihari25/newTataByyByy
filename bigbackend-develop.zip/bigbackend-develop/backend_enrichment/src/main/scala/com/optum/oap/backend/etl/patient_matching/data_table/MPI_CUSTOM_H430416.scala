package com.optum.oap.backend.etl.patient_matching.data_table

import com.optum.oap.backend.cdrTempModel.pat_match_prep
import com.optum.oap.backend.etl.common.{CDRConstants, CleanPatientName, EnrichmentUtils, SSNValidation}
import com.optum.oap.backend.etl.patient_matching.PATIENT_MPI_UTILS
import com.optum.oap.backend.loader.EnrichmentRunTimeVariables
import com.optum.oap.cdr.models.{map_gender, mpi_custom, patient_id, patientdetail}
import com.optum.oap.sparkdataloader.{RuntimeVariables, TableInfo, UserDefinedFunctionForDataLoader}
import org.apache.spark.sql.expressions.Window
import org.apache.spark.sql.functions._
import org.apache.spark.sql.types.LongType
import org.apache.spark.sql.{DataFrame, SparkSession}

object MPI_CUSTOM_H430416 extends TableInfo[mpi_custom] {

  override def dependsOn = Set("PAT_MATCH_PREP", "PATIENTDETAIL_PREMATCH", "MAP_GENDER", "PATIENT_ID_PREMATCH", "ECDR_MPI_CUSTOM_H430416")

  override def name = "MPI_CUSTOM_H430416"

  override def createDataFrame(sparkSession: SparkSession,
                               loadedDependencies: Map[String, DataFrame],
                               udfMap: Map[String, UserDefinedFunctionForDataLoader],
                               runtimeVariables: RuntimeVariables): DataFrame = {
    import sparkSession.implicits._

    val dailyBuild = if (runtimeVariables.asInstanceOf[EnrichmentRunTimeVariables].buildType == CDRConstants.DELTA_BUILD_TYPE) true else false

    val tempPatMatchPrep = loadedDependencies("PAT_MATCH_PREP").as[pat_match_prep]
    val patientId = loadedDependencies("PATIENT_ID_PREMATCH").as[patient_id]
    val mapGender = broadcast(loadedDependencies("MAP_GENDER").as[map_gender])
    val patientDetail = loadedDependencies("PATIENTDETAIL_PREMATCH").as[patientdetail]

    val ps = tempPatMatchPrep
      .where($"dob".isNotNull)
      .select(
        $"groupid", $"client_ds_id", $"patientid", $"hgpid", $"dob",
        upper($"fname").as("first_name"),
        upper($"lname").as("last_name"),
        CleanPatientName.cleanPatientName($"fname", lit(3)).as("fname"),
        CleanPatientName.cleanPatientName($"lname", lit(3)).as("lname")
      ).distinct

    /**
      * select distinct groupid,client_ds_id,patientid
      * ,trim(substr(replace(idvalue,'-'),1,9)) as ssn
      * from temp_patient_id partition (P_GRPID) tpi
      * where trim(substr(replace(idvalue,'-'),1,9)) not in (select ssn from cdr_common.bad_ssn)
      * and idtype = 'SSN' and validate_ssn(idvalue) = 'Y'
      */
    val pid = patientId.as("tpi")
      .where(!trim(substring(regexp_replace($"idvalue", "-", ""), 0, 9)).isin(PATIENT_MPI_UTILS.getBadSSNs: _*) &&
        $"idtype" === lit("SSN") && !SSNValidation.cleanAndValidate($"idvalue").isin(SSNValidation.INVALID_OUTCOMES: _*)
      )
      .select(
        $"groupid", $"client_ds_id", $"patientid",
        trim(substring(regexp_replace($"idvalue", "-", ""), 0, 9)).as("ssn")
      ).distinct

    /**
      * select distinct groupid,client_ds_id,patientid
      * ,trim(substr(replace(idvalue,'-'),1,9)) as mrn
      * from temp_patient_id partition (P_GRPID) tpi
      * where idtype = 'MRN'
      */
    val mrn = patientId.as("tpi")
      .where($"idtype" === lit("MRN"))
      .select(
        $"groupid", $"client_ds_id", $"patientid",
        substring(regexp_replace($"idvalue", "-", ""), 0, 9).as("mrn")
      ).distinct

    val dobWindow = Window.partitionBy($"dob")


    val dataDf = ps.as("ps")
      .join(pid.as("pid"), Seq("groupid", "client_ds_id", "patientid"), "left")
      .join(mrn.as("mrn"), Seq("groupid", "client_ds_id", "patientid"), "left")
      .join(patientDetail.as("pd").where($"pd.patientdetailtype" === lit("GENDER")),
        Seq("groupid", "client_ds_id", "patientid"), "left")
      .join(mapGender.as("mg").where($"mg.cui".isInCollection(CDRConstants.MALE_AND_FEMALE_CUIS)), $"pd.localvalue" === $"mg.mnemonic", "left")
      .join(patientDetail.as("pz").where($"pz.patientdetailtype" === lit("ZIPCODE")),
        Seq("groupid", "client_ds_id", "patientid"), "left")
      .select(
        $"ps.groupid",
        $"ps.client_ds_id",
        $"ps.patientid",
        $"ps.hgpid",
        $"ps.dob".as("key_attr"),
        $"ps.fname".as("attr_2"),
        $"ps.lname".as("attr_3"),
        when(length(regexp_replace($"ps.fname", " ", "")) < 7, regexp_replace($"ps.fname", " ", ""))
          .otherwise(substring(regexp_replace($"ps.fname", " ", ""), -7, 7)).as("attr_4"),
        when(length(regexp_replace($"ps.lname", " ", "")) < 7, regexp_replace($"ps.lname", " ", ""))
          .otherwise(substring(regexp_replace($"ps.lname", " ", ""), -7, 7)).as("attr_5"),
        substring($"ps.fname", 1, 5).as("attr_6"),
        $"mrn".as("attr_7"),
        $"mg.cui".as("attr_8"),
        $"ssn".as("attr_9"),
        substring($"pz.localvalue", 1, 5).as("attr_10"),
        substring($"ps.lname", 1, 1).as("attr_11"),
        substring($"ps.lname", 1, 3).as("attr_12"),
        size(collect_set("ps.groupid").over(dobWindow)).as("group_cnt"),
        size(collect_set("ps.hgpid").over(dobWindow)).cast(LongType).as("hgpids")
      )

    val ecdrDf = {
      if (dailyBuild) EnrichmentUtils.removeRowSourceAndModifiedDate(loadedDependencies("ECDR_MPI_CUSTOM_H430416")).as[mpi_custom]
      else sparkSession.emptyDataset[mpi_custom].as[mpi_custom]
    }.as("e")
      .select($"e.*")

    dataDf.unionByName(ecdrDf).distinct()
  }
}
