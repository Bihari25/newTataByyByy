package com.optum.oap.backend.loader.loadgroup
import com.optum.oap.backend.loader.{CopyFEToBEDependencies, EnrichmentRunTimeVariables}
import com.optum.oap.sparkdataloader.TableInfo
import org.apache.spark.sql.SparkSession

trait CopyLoadGroup extends LoadGroup {

  override def loadGroup: String = "copy"

  override def initialDependencies(runTimeVariables: EnrichmentRunTimeVariables, sparkSession: SparkSession): Seq[TableInfo[_ <: Product with Serializable]] = {
    CopyFEToBEDependencies.copyAllFromFeToBe(runTimeVariables.cdrSchema)
  }

  override def queryRegistry(runTimeVariables: EnrichmentRunTimeVariables, sparkSession: SparkSession): Seq[TableInfo[_ <: Product with Serializable]] = {
    Seq.empty
  }
}
