package com.optum.oap.backend.etl.encgrps
import com.optum.oap.backend.cdrTempModel.{temp_eg_ins_null, temp_enc_ins_1, temp_ins_join_eeg}
import com.optum.oap.sparkdataloader.{RuntimeVariables, TableInfo, UserDefinedFunctionForDataLoader}
import org.apache.spark.sql.{DataFrame, SparkSession}
import org.apache.spark.sql.functions.{coalesce, _}

object TEMP_ENC_INS_1 extends TableInfo[temp_enc_ins_1] {
  override def dependsOn: Set[String] = Set("TEMP_EG_INS_NULL","TEMP_INS_JOIN_EEG")
  override def name = "TEMP_ENC_INS_1"

  override def createDataFrame(sparkSession: SparkSession, loadedDependencies: Map[String, DataFrame], udfMap: Map[String, UserDefinedFunctionForDataLoader], runtimeVariables: RuntimeVariables): DataFrame = {
    import sparkSession.implicits._

    val tempEGInsNull = loadedDependencies("TEMP_EG_INS_NULL").as[temp_eg_ins_null]
    val tempInsJoinEEG = loadedDependencies("TEMP_INS_JOIN_EEG").as[temp_ins_join_eeg]

    tempEGInsNull.where($"grp_mpi".isNotNull).as("px")
      .join(tempInsJoinEEG.as("eeg"), $"px.grp_mpi" === $"eeg.grp_mpi" && $"px.client_ds_id" === $"eeg.client_ds_id" && (to_date($"ins_timestamp").between(to_date($"ARRIVALTIME"), to_date($"DISCHARGETIME")) || to_date($"dischargetime").between($"enrollstartdt", coalesce(to_date($"enrollenddt"), to_date(current_timestamp())))), "INNER")
      .select(
        $"px.groupid",
        $"px.grp_mpi",
        $"ENCOUNTER_GRP_NUM",
        $"px.finclass",
        $"plancode",
        $"planname",
        $"payorcode",
        $"payorname",
        $"px.mfc_cui",
        $"MAPPEDPLANFINCODE",
        $"insuranceorder",
        $"encounteridtype",
        $"px.ins_timestamp",
        $"px.datasrc".as("datasrc"),
        $"px.sourceid",
        $"px.encounterid".as("encounterid"),
        $"px.client_ds_id"
      )
  }
}