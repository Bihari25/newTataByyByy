package com.optum.oap.backend.etl.enrichment

import com.optum.oap.backend.cdrTempModel.{temp_med_claim, ref_cmsnpi_partial}
import com.optum.oap.backend.etl.common.IsSafeToNumber
import com.optum.oap.cdr.models.{map_specialty_ii, ref_billtype_pos_xref, ref_ub04_rev_codes}
import com.optum.oap.sparkdataloader.{RuntimeVariables, TableInfo, UserDefinedFunctionForDataLoader}
import org.apache.spark.sql.expressions.Window
import org.apache.spark.sql.{DataFrame, SparkSession}
import org.slf4j.LoggerFactory
import org.apache.spark.sql.functions._
import org.apache.spark.sql.types.DataTypes

object ICPM_TEMP_MED_CLAIM extends TableInfo[temp_med_claim] {

  private val log = LoggerFactory.getLogger(this.getClass)

  override def dependsOn = Set("INT_CLAIM_MEDICAL", "REF_BILLTYPE_POS_XREF", "REF_UB04_REV_CODES", "REF_CMSNPI", "MAP_SPECIALTY_II")

  override def name = "ICPM_TEMP_MED_CLAIM"

  override def ignoreExtraColumnsInDataFrame: Boolean = true

  override def partitions: Int = 32

  override def createDataFrame(sparkSession: SparkSession,
                               loadedDependencies: Map[String, DataFrame],
                               udfMap: Map[String, UserDefinedFunctionForDataLoader],
                               runtimeVariables: RuntimeVariables): DataFrame = {

    import sparkSession.implicits._

    val intClaimMedAdj = loadedDependencies("INT_CLAIM_MEDICAL")
    val refBilltypePosXref = broadcast(loadedDependencies("REF_BILLTYPE_POS_XREF")).as[ref_billtype_pos_xref]
    val refUb04RevCodes = broadcast(loadedDependencies("REF_UB04_REV_CODES")).as[ref_ub04_rev_codes]
    val refCmsnpi = loadedDependencies("REF_CMSNPI").as[ref_cmsnpi_partial]
    val mapSpecialtyIi = broadcast(loadedDependencies("MAP_SPECIALTY_II")).as[map_specialty_ii]

    val step1 = intClaimMedAdj.filter($"member_id".isNotNull
      && coalesce($"claim_adj_type", lit("K")) === "K").select(
      $"*"
      , concat_ws("", $"client_ds_id", $"contract_id", $"encounterid", $"claim_header_id").as(
        "pre_encounterid"
      )
      , when(IsSafeToNumber.isSafeToNumber($"place_of_service"), $"place_of_service").otherwise(null).as("place_of_service_num")
    )

    val step2a = step1.as("s1").join(
      refBilltypePosXref.as("ref")
      , substring($"s1.type_of_bill_code", 1, 2) === $"ref.bill_type"
      , "left").select(
      $"*"
      , $"ref.imputed_pos"
      , when(
        length($"place_of_service_num") === 1,
        lpad($"place_of_service_num", 2, "0")
      ).when(
        length($"place_of_service_num") === 2,
        $"place_of_service_num"
      ).otherwise(null).as("pos_clean")
    )

    val step2b = step2a.select(
      $"*"
      , when(coalesce($"pos_clean", $"imputed_pos").isNotNull, concat_ws("",
        lit("POS."), coalesce($"pos_clean", $"imputed_pos")
      )).otherwise(null).as("localpatienttype")
    )

    val step3 = step2b.select(
      $"*"
      , expr("nullif(concat_ws('', pre_encounterid, localpatienttype), '')").as("sec_encounterid")
    )

    val step4a = step3
      .withColumnRenamed("admit_date", "admit_date_old")
      .withColumnRenamed("service_date", "service_date_old")
      .withColumnRenamed("service_from_date", "service_from_date_old")
      .withColumnRenamed("service_to_date", "service_to_date_old")
      .withColumnRenamed("discharge_date", "discharge_date_old")
      .select(
      $"*"
      , when(year($"admit_date_old") between(1901, 2078)
        , $"admit_date_old").otherwise(null).as("admit_date")
      , when(year($"service_date_old") between(1901, 2078)
        , $"service_date_old").otherwise(null).as("service_date")
      , when(year($"service_from_date_old") between(1901, 2078)
        , $"service_from_date_old").otherwise(null).as("service_from_date")
      , when(year($"service_to_date_old") between(1901, 2078)
        , $"service_to_date_old").otherwise(null).as("service_to_date")
      , when(year($"discharge_date_old") between(1901, 2078)
        , $"discharge_date_old").otherwise(null).as("discharge_date")
    )

    val windowFn = Window.partitionBy($"sec_encounterid", $"groupid")

    val step4b = step4a.filter(coalesce($"admit_date", $"service_date", $"service_from_date", $"service_to_date", $"discharge_date").isNotNull).select(
      $"*"
      , min(to_date($"admit_date")).over(windowFn).as("min_admit_dt")
      , min(to_date($"service_date")).over(windowFn).as("min_dos")
      , min(to_date($"service_from_date")).over(windowFn).as("min_dos_from")
      , max(to_date($"discharge_date")).over(windowFn).as("max_disch")
      , max(to_date($"service_date")).over(windowFn).as("max_dos")
      , max(to_date($"service_to_date")).over(windowFn).as("max_dos_to")
    ).select(
      $"*"
      , least($"min_admit_dt", $"min_dos", $"min_dos_from").as("dos_least")
      , greatest($"max_disch", $"max_dos", $"max_dos_to").as("dos_great")
    )

    val step4c = step4b.select(
      $"*"
      , when(datediff($"dos_great", $"dos_least") > 0, 1).otherwise(0).as("admit_marker")
      , $"dos_least".cast(DataTypes.TimestampType).as("arrivaltime")
    )

    val step4d = step4c.select(
      $"*"
      , when($"min_admit_dt".isNotNull, $"min_admit_dt")
        .when($"admit_marker" === 0, null)
        .when($"admit_marker" === 1, least($"min_dos", $"min_dos_from")).cast(DataTypes.TimestampType).as("admittime")
      , when($"max_disch".isNotNull, $"max_disch")
        .when($"admit_marker" === 0, null)
        .when($"admit_marker" === 1, greatest($"max_dos", $"max_dos_to")).cast(DataTypes.TimestampType).as("dischargetime")
    )

    val step4 = step4d.select($"*"
      , when(IsSafeToNumber.isSafeToNumber($"diag_rel_grp_code"), $"diag_rel_grp_code").otherwise(null).as("diag_rel_grp_code_num")
      , when(IsSafeToNumber.isSafeToNumber($"diag_rel_grp_severity"), $"diag_rel_grp_severity").otherwise(null).as("diag_rel_grp_severity_num")
      , when(IsSafeToNumber.isSafeToNumber($"diag_rel_grp_rom"), $"diag_rel_grp_rom").otherwise(null).as("diag_rel_grp_rom_num")
      , when(IsSafeToNumber.isSafeToNumber($"diag_rel_grp_outlier"), $"diag_rel_grp_outlier").otherwise(null).as("diag_rel_grp_outlier_num")
    )

    ///////// New encounterid spec including datasrc /////

    val step5aBuildRevCode = step4
      .select(
      $"*"
      , when(length($"revenue_code") > 4, lit(null))
        .otherwise(lpad($"revenue_code", 4, "0")).as("rev_clean")
    )

    val step5b = step5aBuildRevCode.as("med")
      .join(refUb04RevCodes.as("ref04"), $"med.rev_clean" === $"ref04.rev_code", "left")
      .join(refCmsnpi.as("refCms"), $"med.servicing_prov_npi" === $"refCms.npi" && $"refCms.entity_type_code" === 2, "left")
      .join(mapSpecialtyIi.as("ii"), $"med.groupid" === $"ii.groupid" && $"med.servicing_prov_spclty_cd" === "ii.local_code" && when(IsSafeToNumber.isSafeToNumber($"ii.ii_code"), "ii.ii_code").otherwise(lit(null)) < 200, "left")
      .select(
        when($"ref04.rev_code".isNotNull, lit(1)).otherwise(lit(0)).as("valid_rev")
      /*  , when(
          first($"refCms.npi", true).over(
            Window.partitionBy($"encounterid").orderBy(
              $"refCms.npi".desc_nulls_last, $"refCms.entity_type_code".desc_nulls_last)
          ).isNotNull,
          lit(1)).otherwise(lit(0)).as("serv_facility") */
        , when($"refCms.npi".isNotNull, lit(1)).otherwise(lit(0)).as("serv_facility")
        , when($"ii.ii_code".isNotNull, lit(1)).otherwise(lit(0)).as("fac_spec")
        , when($"med.claim_type" === "I", lit(1)).otherwise(lit(0)).as("claim_i")
        , $"med.*"
      )

    val step5cDatasrc = step5b.withColumnRenamed("datasrc", "datasrc_old")
      .select(
        $"*"
        ,lit(null).cast(DataTypes.StringType).as("datasrc_med")
        , when($"valid_rev" + $"serv_facility" + $"fac_spec" + $"claim_i" > 0, "int_claim_medical_i")
          .otherwise("int_claim_medical_p").as("datasrc")
      )

    val step6 = step5cDatasrc
      .withColumnRenamed("encounterid", "encounterid_old")
      .select(
        concat_ws("_", $"client_ds_id", $"member_id", $"servicing_prov_id", $"arrivaltime", $"dischargetime", $"localpatienttype", $"contract_id", when($"datasrc" === "int_claim_medical_i", lit("I")).otherwise(lit("P"))).as("encounterid")
        , when($"diag_rel_grp_code_num".isNull || $"diag_rel_grp_code_num" > 999, lit(null)).otherwise(lpad($"diag_rel_grp_code_num", 3, "0")).as("drg_clean")
        , $"*"
    )

    val step7a = step6
      .select($"*"
        , when($"diag_rel_grp_severity_num".isin(1, 2, 3, 4) && $"drg_clean".isNotNull, $"diag_rel_grp_severity_num")
          .otherwise(lit(null)).as("soi_clean")
        , when($"diag_rel_grp_rom_num".isin(1, 2, 3, 4) && $"drg_clean".isNotNull, $"diag_rel_grp_rom_num")
          .otherwise(lit(null)).as("rom_clean")
        , when($"diag_rel_grp_outlier_num".isin(0, 1, 2, 6, 7, 8, 9) && $"drg_clean".isNotNull, $"diag_rel_grp_outlier_num")
          .otherwise(lit(null)).as("outlier_clean")
      )

    val step7b = step7a
      .select($"*"
        , first("drg_clean", true).over(Window.partitionBy($"encounterid", $"diag_rel_grp_grouper").orderBy(when($"drg_clean".isNotNull, $"service_date").otherwise(null).desc_nulls_last, $"drg_clean".desc_nulls_last)).as("drg_clean_max")
        , first("soi_clean", true).over(Window.partitionBy($"encounterid", $"diag_rel_grp_grouper").orderBy(when($"soi_clean".isNotNull, $"service_date").otherwise(null).desc_nulls_last, $"soi_clean".desc_nulls_last)).as("soi_clean_max")
        , first("rom_clean", true).over(Window.partitionBy($"encounterid", $"diag_rel_grp_grouper").orderBy(when($"rom_clean".isNotNull, $"service_date").otherwise(null).desc_nulls_last, $"rom_clean".desc_nulls_last)).as("rom_clean_max")
        , first("outlier_clean", true).over(Window.partitionBy($"encounterid", $"diag_rel_grp_grouper").orderBy(when($"outlier_clean".isNotNull, $"service_date").otherwise(null).desc_nulls_last, $"outlier_clean".desc_nulls_last)).as("outlier_clean_max")
      )

    val step7Pivot = step7b.groupBy("encounterid").pivot($"diag_rel_grp_grouper", Seq("MSDRG", "APRDRG"))
      .agg(max("drg_clean_max").as("drg_clean_max"), max("soi_clean_max").as("soi_clean_max")
        , max("rom_clean_max").as("rom_clean_max"), max("outlier_clean_max").as("outlier_clean_max"))

    val step7DedupDRG = step7b
      .as("s6_6").join(step7Pivot.as("s6_pv"), $"s6_6.encounterid" === $"s6_pv.encounterid", "left")
      .withColumnRenamed("revenue_code", "revenue_code_old")
      .select(
        when(IsSafeToNumber.isSafeToNumber($"revenue_code_old"), $"revenue_code_old").otherwise(null).as("revenue_code")
        , when($"s6_pv.msdrg_drg_clean_max".isNotNull, "MSDRG").as("localdrgtype")
        , when($"s6_pv.msdrg_drg_clean_max".isNotNull, $"s6_pv.msdrg_drg_clean_max").as("localdrg")
        , when($"s6_pv.aprdrg_drg_clean_max".isNotNull, $"s6_pv.aprdrg_drg_clean_max").as("aprdrg_cd")
        , when($"s6_pv.aprdrg_drg_clean_max".isNotNull, $"s6_pv.aprdrg_soi_clean_max").as("aprdrg_soi")
        , when($"s6_pv.aprdrg_drg_clean_max".isNotNull, $"s6_pv.aprdrg_rom_clean_max").as("aprdrg_rom")
        , coalesce($"s6_pv.msdrg_outlier_clean_max", $"s6_pv.aprdrg_outlier_clean_max").as("localdrgoutlier")
        , $"s6_6.*"
      )

    step7DedupDRG.drop("row_source", "modified_date", "admit_prov_spclty_desc", "outlier_clean_max", "place_of_service_num", "drg_clean_max", "service_from_date_old", "discharge_date_old", "fac_spec",
      "diag_rel_grp_severity_num", "pre_encounterid", "dos_least", "soi_clean", "diag_rel_grp_outlier_num", "serv_facility", "claim_i",
      "admit_date_old", "encounterid_old", "bill_type", "specialty_classification", "specialty", "sec_encounterid", "rom_clean", "diag_rel_grp_rom_num",
      "rom_clean_max", "specialty_specialization", "bpo_spec_name", "min_admit_dt", "diag_rel_grp_code_num", "drg_clean", "max_dos", "valid_rev",
      "service_to_date_old", "min_dos_from", "fac_type_desc", "bpo_spec", "outlier_clean", "admit_marker", "dos_great", "min_dos", "pos_clean",
      "rev_clean", "soi_clean_max", "bill_clsfctn_desc", "max_disch", "specialty_type", "max_dos_to", "datasrc_old", "bill_clsfctn_cd",
      "service_date_old", "imputed_pos", "fac_type_cd", "claim_line_id")
      .distinct()
  }
}