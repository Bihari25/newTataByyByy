package com.optum.oap.backend.etl.patient_matching.data_table

import com.optum.oap.backend.cdrTempModel.patient_xref
import com.optum.oap.backend.etl.common.{CDRConstants, EnrichmentUtils, PartitionedDataOperations}
import com.optum.oap.backend.loader.EnrichmentRunTimeVariables
import com.optum.oap.cdr.models.{mpi_empi, patient_id}
import com.optum.oap.sparkdataloader.{RuntimeVariables, TableInfo, UserDefinedFunctionForDataLoader}
import org.apache.spark.sql.expressions.Window
import org.apache.spark.sql.functions._
import org.apache.spark.sql.types.LongType
import org.apache.spark.sql.{DataFrame, SparkSession}

object MPI_EMPI extends TableInfo[mpi_empi] with PartitionedDataOperations {

  val partitionKey: String = "idvalue"

  override def dependsOn = Set("PATIENT_ID_PREMATCH", "V_PATIENT_XREF", "ECDR_MPI_EMPI")

  override def name = "MPI_EMPI"

  override def saveDataFrameToParquet: Boolean = true

  override def createDataFrame(sparkSession: SparkSession,
                               loadedDependencies: Map[String, DataFrame],
                               udfMap: Map[String, UserDefinedFunctionForDataLoader],
                               runtimeVariables: RuntimeVariables): DataFrame = {
    import sparkSession.implicits._
    implicit val session = sparkSession
    val schema = EnrichmentRunTimeVariables(runtimeVariables).cdrSchema

    val dailyBuild = if (runtimeVariables.asInstanceOf[EnrichmentRunTimeVariables].buildType == CDRConstants.DELTA_BUILD_TYPE) true else false

    val patientId = loadedDependencies("PATIENT_ID_PREMATCH").as[patient_id]
      .where($"idvalue".isNotNull && $"idtype" === lit("EMPI") && $"datasrc" =!= lit("CDR"))
    val pXref = loadedDependencies("V_PATIENT_XREF").as[patient_xref]
    val patientXref = if(pXref.isEmpty) loadData(schema, "V_PATIENT_XREF").as[patient_xref] else pXref
    val window = Window.partitionBy(ltrim($"a.idvalue", "0"))

    val dataDf = patientId.as("a")
      .join(patientXref.as("b"), Seq("client_ds_id", "patientid"))
      .groupBy($"a.groupid", $"a.client_ds_id", $"a.patientid", $"b.hgpid", $"a.idvalue".as("untrimmed_idvalue"), $"a.idtype")
      .agg(
        lit(1).as("group_cnt"),
        trim($"a.idvalue").as("idvalue"),
        size(collect_set("b.hgpid").over(window)).cast(LongType).as("hgpids")
      ).drop("untrimmed_idvalue").distinct

    val ecdrDf = {
      if (dailyBuild) EnrichmentUtils.removeRowSourceAndModifiedDate(loadedDependencies("ECDR_MPI_EMPI")).as[mpi_empi]
      else sparkSession.emptyDataset[mpi_empi].as[mpi_empi]
    }.as("e")
      .select($"e.*")

    dataDf.unionByName(ecdrDf).distinct()
  }
}
