package com.optum.oap.backend.loader

import com.amazonaws.services.s3.model.GetObjectRequest
import com.optum.oap.awsutils.AWSClientConfig
import com.optum.oap.backend.etl.common.CDRConstants
import org.slf4j.LoggerFactory

object S3BpoConfigReader {
  def apply(): BpoConfigReader = new S3ConfigReader()

  class S3ConfigReader extends BpoConfigReader {
    private val logger = LoggerFactory.getLogger(this.getClass)

    override def constructLines(clientId: String, release: String, cdrCycle: String, isOverride: Boolean): Set[String] = {

      val override_configkey = "CDRBE/BPO/override_cdr_be_bpo_extract_config.csv"
      val release_configkey = s"CDRBE/BPO/$release/cdr_be_bpo_extract_config.csv"
      val configkey = if (isOverride) override_configkey else release_configkey
      logger.warn(s"using key$configkey")
      val awsS3Client = AWSClientConfig.default.createS3Client()
      val obj = awsS3Client.getObject(new GetObjectRequest(CDRConstants.OAPCONFIG_BUCKET_NAME, configkey))
      try {
        val iStream = scala.io.Source.fromInputStream(obj.getObjectContent)
        iStream.getLines()
          .filter(line => line.startsWith(clientId) && ((isOverride && line.endsWith(cdrCycle)) || !isOverride)).toSet
      } finally {
        if (obj != null) obj.close()
      }
    }
  }

}



