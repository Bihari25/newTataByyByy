package com.optum.oap.backend.etl.bpo

import com.optum.oap.backend.cdrTempModel.temp_zip
import com.optum.oap.cdr.models.ref_commercial_zipcodes
import com.optum.oap.sparkdataloader.{RuntimeVariables, TableInfo, UserDefinedFunctionForDataLoader}
import org.apache.spark.sql.{DataFrame, SparkSession}
import org.apache.spark.sql.functions._

object TEMP_ZIP  extends TableInfo[temp_zip] {
  override def dependsOn: Set[String] = Set("REF_COMMERCIAL_ZIPCODES")

  override def name = "TEMP_ZIP"

  override def createDataFrame(sparkSession: SparkSession,
                               loadedDependencies: Map[String, DataFrame],
                               udfMap: Map[String, UserDefinedFunctionForDataLoader],
                               runtimeVariables: RuntimeVariables): DataFrame = {
    import sparkSession.implicits._

    val refCommercialZipCodes = loadedDependencies("REF_COMMERCIAL_ZIPCODES").as[ref_commercial_zipcodes]

    refCommercialZipCodes
      .groupBy($"zipcode")
      .agg(max($"latitude").as("latitude")
      ,max($"longitude").as("longitude"))

  }
}