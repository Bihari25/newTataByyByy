package com.optum.oap.backend.etl.encgrps

import com.optum.oap.backend.cdrTempModel.temp_eeg_p1
import com.optum.oap.sparkdataloader.QueryAndMetadata

object TEMP_EEG_P1 extends QueryAndMetadata[temp_eeg_p1] {

  override def name: String = "TEMP_EEG_P1"

  override def sparkSql: String =
    """
      |SELECT
      |    a.*,
      |    ROW_NUMBER() OVER(
      |        PARTITION BY groupid,grp_mpi,patienttype
      |        ORDER BY
      |            groupid,grp_mpi,patienttype,excl,to_date(arrivaltime),to_date(dischargetime) desc,master_facility_name
      |NULLS LAST,
      |                CASE
      |                    WHEN arrivaltime <> TimestampTruncate('DAY', arrivaltime) THEN 1 ELSE 2
      |                END,arrivaltime,dischargetime DESC,prindx NULLS LAST,client_ds_id,encounterid
      |    ) AS enc_order
      |FROM
      |    (
      |        SELECT /*+  BROADCASTJOIN(f) */
      |               /*+ BROADCASTJOIN(d) */
      |            ce.groupid,
      |            ce.grp_mpi,
      |            coalesce(ce.master_facility_name,f.master_facility_name) AS master_facility_name,
      |            ce.patienttype,
      |            TimestampTruncate('HOUR', arrivaltime) AS arrivaltime,
      |            TimestampTruncate('HOUR', dischargetime) AS dischargetime,
      |            ce.arrivaltime AS old_arrivaltime,
      |            ce.dischargetime AS old_dischargetime,
      |            ce.disposition,
      |            ce.client_ds_id,
      |            ce.encounterid,
      |            ce.alt_encounterid,
      |            ce.datasrc,
      |            CASE
      |                    WHEN ce.groupid IN ('H064317','H101623')
      |                         AND ce.patienttype = 'CH000106'
      |                         AND ce.arrivaltime = ce.dischargetime THEN 'Y'
      |                    WHEN ce.excl_fac = 'Y'   THEN 'Y'
      |                    WHEN ce.altid_excl = 'Y' THEN 'Y'
      |                    ELSE ce.excl
      |                END
      |            AS excl,
      |            datediff(ce.dischargetime,ce.arrivaltime) + 1 AS los,
      |            ce.facilityid,
      |            coalesce(pdx.prindx,d.prindx) AS prindx,
      |            coalesce(pdx.prindx_codetype,d.prindx_codetype) AS prindx_codetype,
      |            pdx.hosp_dx_flag,
      |            prov.prov_id  --select *
      |        FROM
      |            temp_visit_enctr ce
      |            LEFT OUTER JOIN temp_eeg_pdx pdx ON ( ce.groupid = pdx.groupid
      |                                                  AND ce.client_ds_id = pdx.client_ds_id
      |                                                  AND ce.encounterid = pdx.encounterid
      |                                                  AND ce.grp_mpi = pdx.grp_mpi )
      |            LEFT OUTER JOIN temp_eeg_prov prov ON ( ce.groupid = prov.groupid
      |                                                    AND ce.client_ds_id = prov.client_ds_id
      |                                                    AND ce.encounterid = prov.encounterid
      |                                                    AND ce.grp_mpi = prov.grp_mpi )
      |            LEFT OUTER JOIN temp_eeg_p1f f ON ( ce.groupid = f.groupid
      |                                                AND ce.client_ds_id = f.client_ds_id
      |                                                AND ce.encounterid = f.encounterid
      |                                                AND ce.grp_mpi = f.grp_mpi )
      |            LEFT OUTER JOIN temp_eeg_p1d d ON ( ce.groupid = d.groupid
      |                                                AND ce.client_ds_id = d.client_ds_id
      |                                                AND ce.encounterid = d.encounterid
      |                                                AND ce.grp_mpi = d.grp_mpi )
      |        WHERE
      |            ce.patienttype IN (
      |                'CH000106',
      |                'CH000107',
      |                'CH000109',
      |                'CH000113',
      |                'CH000795',
      |                'CH003031',
      |                'CH003032'
      |            )
      |            AND datediff(to_date(ce.dischargetime),to_date(ce.arrivaltime) ) >= 0
      |            AND ce.excl_fac = 'N'
      |            AND ce.altid_excl = 'N'
      |    ) a
    """.stripMargin

  override def dependsOn: Set[String] = Set("TEMP_VISIT_ENCTR","TEMP_EEG_P1F","TEMP_EEG_P1D","TEMP_EEG_PDX","TEMP_EEG_PROV")
}
