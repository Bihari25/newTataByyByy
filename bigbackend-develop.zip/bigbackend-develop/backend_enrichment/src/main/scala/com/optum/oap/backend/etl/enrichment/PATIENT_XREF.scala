package com.optum.oap.backend.etl.enrichment

import com.optum.oap.backend.cdrTempModel.patient_xref
import com.optum.oap.backend.etl.common.XrefUtil
import com.optum.oap.backend.etl.enrichment.FACILITY_XREF.{logger, name}
import com.optum.oap.backend.loader.EnrichmentRunTimeVariables
import com.optum.oap.cdr.models.patient
import com.optum.oap.sparkdataloader.{RuntimeVariables, TableInfo, UserDefinedFunctionForDataLoader}
import org.apache.spark.sql.functions._
import org.apache.spark.sql.types.IntegerType
import org.apache.spark.sql.{DataFrame, SparkSession}
import org.slf4j.LoggerFactory

object PATIENT_XREF extends TableInfo[patient_xref] {

  val log = LoggerFactory.getLogger(this.getClass)

  override def dependsOn = Set("PATIENT_XWALK_MAPPING", "COMMON_PATIENT_XREF", "CDR_FE_PATIENT_XREF")

  override def name = "PATIENT_XREF"

  override def createDataFrame(sparkSession: SparkSession,
                               loadedDependencies: Map[String, DataFrame],
                               udfMap: Map[String, UserDefinedFunctionForDataLoader],
                               runtimeVariables: RuntimeVariables): DataFrame = {
    import sparkSession.implicits._
    implicit val session = sparkSession

    val patientIn = loadedDependencies("PATIENT_XWALK_MAPPING").as[patient]
    val commonPatientXref = loadedDependencies("COMMON_PATIENT_XREF").as[patient_xref]

    val enrichmentRunTimeVariables = EnrichmentRunTimeVariables(runtimeVariables)

    if (!enrichmentRunTimeVariables.cdrSchema.equals("test")) {
      logger.warn(s"Refreshing $name table")
      sparkSession.catalog.recoverPartitions(s"${enrichmentRunTimeVariables.cdrSchema}.$name")
    }

    val numOfPartitions = Math.ceil(partitions * enrichmentRunTimeVariables.partitionMultiplier).toInt

    val xrefUtil = new XrefUtil()

    /*
      This is only executed once, when we first import the PATIENT_XREF to the common location
   */
    val loadedDf = if (commonPatientXref.isEmpty) {
      val patientXref = loadedDependencies("CDR_FE_PATIENT_XREF").as[patient_xref]
      val df = patientXref.select($"groupid", $"patientid", $"hgpid", $"client_ds_id",
        date_format(current_date(), "yyyyMMdd").cast(IntegerType).as("partition_date"),
        $"hgpid".as("hgpid_without_groupid"))

      xrefUtil.writeInitialXrefData(df, runtimeVariables, "PATIENT_XREF")
    } else {
      log.warn(s"PATIENT_XREF Table is NOT empty at common location")
      if (enrichmentRunTimeVariables.cdrSchema.equals("test")) {
        commonPatientXref
      } else {
        sparkSession.read.parquet(s"${enrichmentRunTimeVariables.commonPath}/$name")
      }
    }


    val newDf = getNewPatientRecords(sparkSession, loadedDf.toDF(), patientIn.toDF())

    val count = newDf.count()

    val returnDf = if (count > 0) {
      logger.warn(s"INSIDE PATIENT_XREF diffDf count  ${count}. NumPartitions $numOfPartitions")
      xrefUtil.writeNewXrefRecords(loadedDf.toDF(), newDf, $"hgpid_without_groupid", "hgpid", runtimeVariables, "PATIENT_XREF", numOfPartitions)
    } else {
      log.warn(s" There are no new PATIENT_XREF Records so skipping writing to PATIENT_XREF")
      sparkSession.emptyDataset[patient_xref].toDF()
    }

    returnDf
  }

  /**
    *
    * @param sparkSession session
    * @param loadedDf     patient_xref dataframe
    * @param patientIn    patient dataframe
    * @return returns the records that are in patient but not in patient_xref when joined on to patientid and client_ds_id
    */
  def getNewPatientRecords(sparkSession: SparkSession, loadedDf: DataFrame, patientIn: DataFrame): DataFrame = {
    import sparkSession.implicits._

    patientIn.as("pat")
      .join(loadedDf.as("ref"), $"pat.groupid" === $"ref.groupid" && $"pat.patientid" === $"ref.patientid" && $"pat.client_ds_id" === $"ref.client_ds_id", "left_outer")
      .where($"ref.patientid".isNull)
      .select($"pat.groupid",
        $"pat.patientid".as("patientid"),
        $"pat.client_ds_id").distinct().withColumn("partition_date", date_format(current_date(), "yyyyMMdd").cast(IntegerType))

  }

}
