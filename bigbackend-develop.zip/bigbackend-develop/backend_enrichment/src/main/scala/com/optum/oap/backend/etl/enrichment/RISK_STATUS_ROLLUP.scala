package com.optum.oap.backend.etl.enrichment

import com.optum.oap.backend.loader.EnrichmentRunTimeVariables
import com.optum.oap.cdr.models.{map_risk_status, pat_risk_attrib, risk_status_rollup}
import com.optum.oap.sparkdataloader.{RuntimeVariables, TableInfo, UserDefinedFunctionForDataLoader}
import org.apache.spark.sql.expressions.Window
import org.apache.spark.sql.functions.{coalesce, lit, _}
import org.apache.spark.sql.types._
import org.apache.spark.sql.{DataFrame, SparkSession}
import org.slf4j.LoggerFactory

object RISK_STATUS_ROLLUP extends TableInfo[risk_status_rollup] {

  private val log = LoggerFactory.getLogger(this.getClass)

  override def dependsOn = Set("CDR_FE_RISK_STATUS_ROLLUP", "PAT_RISK_ATTRIB", "MAP_RISK_STATUS")

  override def name = "RISK_STATUS_ROLLUP"

  override def partitions: Int = 32

  override def createDataFrame(sparkSession: SparkSession,
                               loadedDependencies: Map[String, DataFrame],
                               udfMap: Map[String, UserDefinedFunctionForDataLoader],
                               runtimeVariables: RuntimeVariables): DataFrame = {

    import sparkSession.implicits._

    val riskStatusRollup = loadedDependencies("CDR_FE_RISK_STATUS_ROLLUP").as[risk_status_rollup]
    val patRiskAttrib = loadedDependencies("PAT_RISK_ATTRIB").as[pat_risk_attrib]
    val mapRiskStatus = broadcast(loadedDependencies("MAP_RISK_STATUS")).as[map_risk_status]

    val groupId = runtimeVariables.asInstanceOf[EnrichmentRunTimeVariables].clientId
    logger.warn(s"Running RISK_STATUS_ROLLUP for group $groupId")


    //Origin Front end <RISK_STATUS_ROLLUP> Table
    val cdrRiskStatusRollup = riskStatusRollup.select(
      $"client_ds_id",
      $"datasrc",
      $"at_risk_status",
      $"at_risk_rollup",
      $"at_risk_status_desc",
      $"at_risk_status_lv1",
      $"at_risk_status_lv1_desc",
      $"at_risk_status_lv2",
      $"at_risk_status_lv2_desc",
      $"groupid")

    //TAKING DISTINCT <at_risk_status> from the <RISK_STATUS_ROLLUP> TABLE #1
    val distinctRiskStatusRollup = cdrRiskStatusRollup.dropDuplicates("at_risk_status")

    //SELECTING RECORDS OF <PAT_RISK_ATTRIB> TABLE WHOSE <at_risk_status> are not in <RISK_STATUS_ROLLUP> TABLE
    val patRiskAttrib1 = patRiskAttrib.alias("pra").join(distinctRiskStatusRollup.alias("cdr"),
      $"pra.at_risk_status" === $"cdr.at_risk_status", "left")
      .select(
        $"pra.groupid"
        , $"pra.client_ds_id"
        , $"pra.at_risk_status"
        , lit("pat_risk_attrib").cast(StringType).as("datasrc")
        , substring(concat(lit("UNDEFINED ("), $"pra.at_risk_status",
          lit(")")), 1, 150).cast(StringType).as("at_risk_status_desc")
        , $"cdr.at_risk_status_lv2", $"cdr.at_risk_status_lv2_desc"
        , $"cdr.at_risk_status_lv1", $"cdr.at_risk_status_lv1_desc", $"at_risk_rollup")
      .where($"pra.at_risk_status".isNotNull
        && length($"pra.at_risk_status") <= 30
        && $"cdr.at_risk_status".isNull)
      .groupBy($"groupid", $"pra.at_risk_status", $"datasrc"
        , $"at_risk_status_desc", $"at_risk_rollup"
        , $"cdr.at_risk_status_lv2", $"cdr.at_risk_status_lv2_desc"
        , $"cdr.at_risk_status_lv1", $"cdr.at_risk_status_lv1_desc")
      .agg(min($"client_ds_id").as("client_ds_id"))

    //NOW UNION THE MISSING RECORDS FETCHED FROM <PAT_RISK_ATTRIB> WITH <RISK_STATUS_ROLLUP> TABLE
    val cdrRiskStatusRollup1 = cdrRiskStatusRollup.unionByName(patRiskAttrib1)


    //APPLYING ADDITIONAL TRANSFORMATIONS ON THE UNION
    val rollup = cdrRiskStatusRollup1.alias("cdr").join(mapRiskStatus.alias("mpi"),
      $"cdr.at_risk_status" === $"mpi.localcode" && $"mpi.groupid" === lit(groupId), "left").
      select(
        $"cdr.groupid".as("groupid")
        , $"cdr.datasrc".as("datasrc")
        , $"cdr.client_ds_id".as("client_ds_id")
        , $"cdr.at_risk_status".as("at_risk_status")
        , substring(coalesce($"cdr.at_risk_status_desc", concat(lit("UNDEFINED ("),
          $"cdr.at_risk_status", lit(")"))), 1, 150).as("at_risk_status_desc")
        , substring(coalesce($"cdr.at_risk_status_lv2", concat(lit("3."), $"cdr.at_risk_status")),
          1, 30).as("at_risk_status_lv2")
        , substring(when($"cdr.at_risk_status_lv2".isNull,
          coalesce($"cdr.at_risk_status_desc",
            concat(lit("UNDEFINED ("), $"cdr.at_risk_status", lit(")"))))
          .otherwise(coalesce($"cdr.at_risk_status_lv2_desc",
            concat(lit("UNDEFINED ("), $"cdr.at_risk_status_lv2", lit(")")))),
          1, 150).as("at_risk_status_lv2_desc")
        , substring(coalesce($"cdr.at_risk_status_lv1", when($"cdr.at_risk_status_lv2".isNotNull,
          concat(lit("2."), $"cdr.at_risk_status_lv2")).otherwise($"cdr.at_risk_status_lv2"),
          concat(lit("3."), $"cdr.at_risk_status")), 1, 30).as("at_risk_status_lv1")
        , substring(when($"cdr.at_risk_status_lv1".isNull, when($"cdr.at_risk_status_lv2".isNull,
          coalesce($"cdr.at_risk_status_desc", concat(lit("UNDEFINED ("), $"cdr.at_risk_status", lit(")"))))
          .otherwise(coalesce($"cdr.at_risk_status_lv2_desc",
            concat(lit("UNDEFINED ("), $"cdr.at_risk_status_lv2", lit(")")))))
          .otherwise(coalesce($"cdr.at_risk_status_lv1_desc",
            concat(lit("UNDEFINED ("), $"cdr.at_risk_status_lv1", lit(")")))),
          1, 150).as("at_risk_status_lv1_desc")
        , when($"cdr.at_risk_rollup" === lit("0"), lit("N")).otherwise(
          when($"cdr.at_risk_rollup" === lit("1"), lit("Y")).otherwise(
            when($"cdr.at_risk_rollup".isNotNull, $"cdr.at_risk_rollup").otherwise(
              lit("X")))).as("at_risk_rollup")
        , row_number().over(Window.partitionBy($"cdr.at_risk_status")
          .orderBy(
            when($"cdr.at_risk_status_desc".isNotNull, lit(0)).otherwise(lit(1)),
            when($"cdr.at_risk_status_lv2".isNotNull, lit(0)).otherwise(lit(1)),
            when($"cdr.at_risk_status_lv1".isNotNull, lit(0)).otherwise(lit(1)),
            $"cdr.at_risk_status_desc", $"cdr.at_risk_status_lv2", $"cdr.at_risk_status_lv1")).as("rn"))
      .where($"cdr.at_risk_status".isNotNull &&
        length($"cdr.at_risk_status") <= 30 &&
        $"rn" === lit(1)).drop($"rn")

    val rollup1 = rollup.alias("cdr").join(mapRiskStatus.alias("mpi"),
      $"cdr.at_risk_status" === $"mpi.localcode" && $"mpi.groupid" === lit(groupId), "left").
      select(
        $"cdr.client_ds_id",
        $"cdr.datasrc",
        $"cdr.at_risk_status_desc",
        $"cdr.at_risk_status_lv1",
        $"cdr.at_risk_status_lv1_desc",
        $"cdr.at_risk_status_lv2",
        $"cdr.at_risk_status_lv2_desc",
        $"cdr.at_risk_status",
        $"cdr.groupid",
        when(!($"cdr.at_risk_rollup".isin("Y", "N", "U")), $"mpi.mappedvalue").otherwise(
          when($"cdr.at_risk_rollup" === lit("0"), lit("N")).otherwise(
            when($"cdr.at_risk_rollup" === lit("1"), lit("Y")).otherwise(
              $"cdr.at_risk_rollup"))).as("at_risk_rollup"))

    rollup1.toDF()

  }
}
