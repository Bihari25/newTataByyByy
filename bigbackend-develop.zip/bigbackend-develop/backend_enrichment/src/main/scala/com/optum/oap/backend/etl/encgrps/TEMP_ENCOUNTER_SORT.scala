
package com.optum.oap.backend.etl.encgrps

import com.optum.oap.backend.cdrTempModel.temp_encounter_sort
import com.optum.oap.backend.etl.common.TimestampTruncate
import com.optum.oap.sparkdataloader.{RuntimeVariables, TableInfo, UserDefinedFunctionForDataLoader}
import org.apache.spark.sql.expressions.Window
import org.apache.spark.sql.functions._
import org.apache.spark.sql.{DataFrame, SparkSession}


object TEMP_ENCOUNTER_SORT extends TableInfo[temp_encounter_sort] {
  override def name: String = "TEMP_ENCOUNTER_SORT"

  override def partitions: Int = 256

  override def dependsOn: Set[String] = Set("ENCOUNTER_ENCOUNTER_GRP", "TEMP_VISIT_ENCTR", "REF_VW_REF_DRG_REFERENCE", "MAP_DISCHARGE_DISPOSITION",
    "MAP_ADMIT_SOURCE", "ZH_FACILITY_ROLLUP", "ZCM_CLIENT_DS_PRIORITY", "MV_CLIENT_DATA_SRC", "MAP_DOMAIN_CDSID_PRIORITY")

  override protected def createDataFrame(sparkSession: SparkSession, loadedDependencies: Map[String, DataFrame],
                                         udfMap: Map[String, UserDefinedFunctionForDataLoader],
                                         runtimeVariables: RuntimeVariables): DataFrame = {

    import sparkSession.implicits._

    val encEncGrp = loadedDependencies("ENCOUNTER_ENCOUNTER_GRP")
    val tempVisitEncounter = loadedDependencies("TEMP_VISIT_ENCTR")
    val mapDischargeDisposition = broadcast(loadedDependencies("MAP_DISCHARGE_DISPOSITION"))
    val refDrg = broadcast(loadedDependencies("REF_VW_REF_DRG_REFERENCE"))
    val mapAdmitSource = broadcast(loadedDependencies("MAP_ADMIT_SOURCE"))
    val zhFacilityRollup = broadcast(loadedDependencies("ZH_FACILITY_ROLLUP"))
    val zcmClientDsPriority = broadcast(loadedDependencies("ZCM_CLIENT_DS_PRIORITY"))
    val mvClientDataSrc = broadcast(loadedDependencies("MV_CLIENT_DATA_SRC").filter(!$"data_src_name".isin("NLP", "COMMON")))
    val mapDomainCdsidPriority = broadcast(loadedDependencies("MAP_DOMAIN_CDSID_PRIORITY"))


    val tempEncSort = encEncGrp.as("eeg")
      .join(tempVisitEncounter.as("ve"), $"ve.groupid" === $"eeg.groupid" and $"ve.encounterid" === $"eeg.encounterid"
        and $"ve.client_ds_id" === $"eeg.client_ds_id", "inner")
      .join(refDrg.as("drg"), $"ve.drg" === $"drg.drg" and $"ve.drgtypecui" === $"drg.drg_type_cui", "left_outer")
      .join(mapDischargeDisposition.as("dd"), $"ve.groupid" === $"dd.groupid" and $"ve.localdischargedisposition" === $"dd.mnemonic", "left_outer")
      .join(mapAdmitSource.as("mas"), $"ve.groupid" === $"mas.groupid" and $"ve.localadmitsource" === $"mas.localcode", "left_outer")
      .join(zhFacilityRollup.as("zfr"), $"ve.groupid" === $"zfr.groupid" and $"ve.facilityid" === $"zfr.facility_id" and $"ve.client_ds_id" === $"zfr.client_ds_id", "left_outer")
      .join(zcmClientDsPriority.as("cdp"), $"ve.client_ds_id" === $"cdp.client_ds_id", "left_outer")
      .join(mvClientDataSrc.as("cds"), $"ve.client_ds_id" === $"cds.client_data_src_id", "left_outer")
      .join(mapDomainCdsidPriority.as("admsort"), $"ve.client_ds_id" === $"admsort.client_ds_id"
        and $"admsort.domain" === "EG.ADMSRC" and ($"ve.datasrc" === $"admsort.datasrc" or $"admsort.datasrc" === "ALL"), "left_outer")

    val partBy = Window.partitionBy($"eeg.encounter_grp_num")

    tempEncSort.repartition($"eeg.encounter_grp_num").select($"eeg.encounter_grp_num",
      $"eeg.encounterid",
      $"eeg.client_ds_id",
      row_number().over(partBy
        .orderBy(when($"drg.drg".isNotNull, lit(1)).when($"ve.drg".isNotNull, lit(3)).otherwise(lit(2)),
          $"ve.dischargetime".desc,
          when($"eeg.encounteridtype" === "MASTER", lit(1)).when($"eeg.encounteridtype" === "ENCTR", lit(2)).otherwise(lit(3)),
          $"ve.encounterid".desc
        )).as("drgrank"),
      row_number().over(partBy
        .orderBy(
          when($"ve.aprdrg_cd".isNotNull, lit(1)).otherwise(lit(2)),
          when($"ve.datasrc".like("837%"), lit(1)).otherwise(lit(2)),
          $"ve.dischargetime".desc,
          when($"eeg.encounteridtype" === "MASTER", lit(1)).when($"eeg.encounteridtype" === "ENCTR", lit(2)).otherwise(lit(3)),
          $"ve.encounterid".desc
        )).as("aprdrgrank"),
      row_number().over(partBy
        .orderBy(
          when($"dd.cui".isNotNull, lit(1)).otherwise(lit(2)),
          when($"eeg.encounteridtype".isin("MASTER", "ENCTR") and $"ve.excl" === "N", lit(1)).otherwise(lit(2)),
          $"ve.dischargetime".desc,
          when($"eeg.encounteridtype" === "MASTER", lit(1)).when($"eeg.encounteridtype" === "ENCTR", lit(2)).otherwise(lit(3)),
          $"ve.encounterid".desc
        )).as("disprank"),
      row_number().over(partBy.orderBy(
        when($"mas.cui".isNotNull, lit(1)).otherwise(lit(2)),
        coalesce($"admsort.priority", lit(99)),
        when($"eeg.encounteridtype".isin("MASTER", "ENCTR", "ADD ER", "ADD SD", "ADD OB"), lit(1)).otherwise(lit(2)),
        when(TimestampTruncate.truncate(lit("DAY"), $"ve.arrivaltime") === $"ve.arrivaltime", lit(2)).otherwise(lit(1)),
        $"ve.arrivaltime",
        when($"eeg.encounteridtype" === "MASTER", lit(1)).when($"eeg.encounteridtype" === "ENCTR", lit(2)).otherwise(lit(3)),
        $"ve.encounterid"
      )).as("admsrcrank"),
      row_number().over(partBy.orderBy(
        when($"eeg.encounteridtype".isin("MASTER", "ENCTR", "ADD ER", "ADD SD", "ADD OB") and $"ve.excl" === "N", lit(1)).otherwise(lit(2)),
        to_date($"ve.arrivaltime"),
        when(TimestampTruncate.truncate(lit("DAY"), $"ve.arrivaltime") === $"ve.arrivaltime", lit(2)).otherwise(lit(1)),
        $"ve.arrivaltime",
        $"ve.encounterid"
      )).as("arrivalrank"),
      row_number().over(partBy.orderBy(
        when($"eeg.encounteridtype".isin("MASTER", "ENCTR") and $"ve.excl" === "N", lit(1)).otherwise(lit(2)),
        when($"ve.orig_admittime".isNotNull and $"ve.orig_dischargetime".isNotNull and $"ve.orig_dischargetime" > $"ve.orig_admittime"
          and $"ve.orig_dischargetime" =!= TimestampTruncate.truncate(lit("DAY"), $"ve.orig_dischargetime"), lit(1))
          .otherwise(lit(2)),
        coalesce(to_date($"ve.admittime"), to_date($"ve.arrivaltime")),
        when(TimestampTruncate.truncate(lit("DAY"), $"ve.admittime") === $"ve.admittime", lit(2)).otherwise(lit(1)),
        when($"eeg.encounteridtype" === "MASTER", lit(1)).otherwise(lit(2)),
        coalesce($"ve.admittime", $"ve.arrivaltime"),
        $"ve.encounterid".desc
      )).as("admitrank"),
      row_number().over(partBy.orderBy(
        when($"zfr.master_facility_name".isNotNull and $"ve.patienttype".isin("CH000106","CH000107","CH000109","CH000113","CH000795","CH003031","CH003032")
          and $"eeg.encounteridtype".isin("MASTER", "ENCTR"), lit(1))
          .when($"zfr.siteofcare_name".isNotNull and !$"ve.patienttype".isin("CH000106","CH000107","CH000109","CH000113","CH000795","CH003031","CH003032")
            and $"eeg.encounteridtype".isin("MASTER", "ENCTR"), lit(2))
          .when($"ve.facilityid".isNotNull and !$"ve.patienttype".isin("CH000106","CH000107","CH000109","CH000113","CH000795","CH003031","CH003032")
            and $"eeg.encounteridtype".isin("MASTER", "ENCTR"), lit(3)).otherwise(lit(4)),
        when($"eeg.encounteridtype" === "MASTER", lit(1)).when($"eeg.encounteridtype" === "ENCTR", lit(2)).otherwise(lit(3)),
        $"ve.dischargetime".desc, $"ve.encounterid".desc
      )).as("facrank"),
      row_number().over(partBy.orderBy(
        when($"eeg.encounteridtype".isin("MASTER", "ENCTR") and $"ve.excl" === "N", lit(1)).otherwise(lit(2)),
        $"cdp.priority",
        when($"cds.is_shared" === "Y", lit(0)).when($"cds.is_shared" === "N", lit(1)).otherwise(lit(2)),
        $"ve.client_ds_id", $"ve.dischargetime".desc, $"eeg.encounteridtype".desc, $"ve.encounterid".desc
      )).as("displayrank")
    )

  }

}
