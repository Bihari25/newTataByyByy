package com.optum.oap.backend.etl.bpo

import com.optum.oap.backend.cdrTempModel._
import com.optum.oap.backend.etl.common.Functions.collectListFromType
import com.optum.oap.backend.loader.EnrichmentRunTimeVariables
import com.optum.oap.cdr.models._
import com.optum.oap.sparkdataloader.{RuntimeVariables, TableInfo, UserDefinedFunctionForDataLoader}
import org.apache.spark.sql.expressions.Window
import org.apache.spark.sql.functions._
import org.apache.spark.sql.types._
import org.apache.spark.sql.{DataFrame, SparkSession}

object TEMP_BPO_PROV_CLIENT_REL_SPANS extends TableInfo[temp_bpo_prov_client_rel_spans] {

  override def name = "TEMP_BPO_PROV_CLIENT_REL_SPANS"

  override def dependsOn: Set[String] = Set("PP_BPO_MEMBER_DETAIL", "TEMP_BPO_PROVIDER_DETAIL", "PROV_CLIENT_REL", "PROV_STATUS_ROLLUP")

  override def createDataFrame(sparkSession: SparkSession, loadedDependencies: Map[String, DataFrame], udfMap: Map[String, UserDefinedFunctionForDataLoader], runtimeVariables: RuntimeVariables): DataFrame = {

    import sparkSession.implicits._

    val ppBpoMemeberDetail = loadedDependencies("PP_BPO_MEMBER_DETAIL").as[pp_bpo_member_detail]
    val tempBpoProviderDetail = loadedDependencies("TEMP_BPO_PROVIDER_DETAIL").as[temp_bpo_provider_detail]
    val tempProvClientRel = loadedDependencies("PROV_CLIENT_REL").as[prov_client_rel]
    val provStatusRollUp = loadedDependencies("PROV_STATUS_ROLLUP").as[prov_status_rollup]
    val grpid = EnrichmentRunTimeVariables(runtimeVariables).clientId

    val dflt_dates = ppBpoMemeberDetail.
      where($"healthplansource" === lit("PAYER")).
      select(to_timestamp(trunc(min($"effectivedate"), "MONTH")).as("eff_date"),
        to_timestamp(last_day(max($"enddate"))).as("end_date"))

    val spanWindow = Window.partitionBy($"pa.mstrprovid")

    val intermediateDf = tempProvClientRel.as("pa")
      .crossJoin(dflt_dates.as("dd"))
      .where($"pa.startdate" <= coalesce($"pa.enddate", $"dd.end_date"))
      .join(tempBpoProviderDetail.as("tmp"), $"tmp.providerid".cast(LongType) === $"pa.mstrprovid".cast(LongType), "inner")
      .select(
        $"pa.mstrprovid".as("master_hgprovid"),
        $"dd.eff_date".as("init_date"),
        $"pa.startdate".as("eff_date"),
        coalesce($"pa.enddate", $"dd.end_date").as("end_date"),
        max(coalesce($"pa.enddate", $"dd.end_date")).over(spanWindow).as("max_end_date")
      )

    val dataList = List("init_date", "eff_date", "end_date")

    val allDates = intermediateDf
      .select($"master_hgprovid",
        expr("stack(4,'init_date', init_date, 'eff_date', eff_date, 'end_date', end_date, 'next_start_date', end_date) as (date_type, date_value) "))
      .where($"date_type".isin(dataList: _*) || ($"date_type" === lit("next_start_date") && month(to_date($"date_value")) < month(to_date($"max_end_date"))))
      .select(
        $"master_hgprovid",
        when($"date_type" === lit("next_start_date"), date_add(last_day($"date_value"), 1))
          .otherwise(trunc($"date_value", "MONTH")).as("date_value")
      )
      .distinct()

    val spanWindowDate = Window.partitionBy($"al.master_hgprovid").orderBy($"al.date_value")

    val allSpans = allDates.as("al")
      .select($"al.master_hgprovid",
        $"al.date_value".as("start_date"),
        coalesce(add_months(last_day(lead($"al.date_value", 1).over(spanWindowDate)), -1), last_day($"al.date_value")).as("end_date"))

    val intermediateRsltSet1 = allSpans.as("sp")
        .crossJoin(dflt_dates.as("dd"))
        .join(tempProvClientRel.as("pa"), $"pa.mstrprovid" === $"sp.master_hgprovid" && $"pa.startdate" <= coalesce($"pa.enddate", current_date()) && $"pa.startdate".between($"sp.start_date", $"sp.end_date"), "left")
        .join(provStatusRollUp.as("psr"), $"psr.prov_status_id" === $"pa.prov_status_id", "left")
        .select(
          $"sp.master_hgprovid",
          $"sp.start_date",
          $"sp.end_date",
          $"pa.prov_status_id".as("provider_status"),
          $"prov_status_rollup",
          $"pa.enddate",
          $"pa.startdate",
          $"pa.mstrprovid".as("pa_mstrprovid"),
          $"primary_span"
        )

    val intermediateRsltSet2 = allSpans.as("sp")
        .crossJoin(dflt_dates.as("dd"))
        .join(tempProvClientRel.as("pa"), $"pa.mstrprovid" === $"sp.master_hgprovid" && $"pa.startdate" <= coalesce($"pa.enddate", current_date()) && coalesce($"pa.enddate", $"dd.end_date").between($"sp.start_date", $"sp.end_date"), "left")
        .join(provStatusRollUp.as("psr"), $"psr.prov_status_id" === $"pa.prov_status_id", "left")
        .select(
          $"sp.master_hgprovid",
          $"sp.start_date",
          $"sp.end_date",
          $"pa.prov_status_id".as("provider_status"),
          $"prov_status_rollup",
          $"pa.enddate",
          $"pa.startdate",
          $"pa.mstrprovid".as("pa_mstrprovid"),
          $"primary_span"
        )

    val intermediateRsltSet3 = allSpans.as("sp")
        .crossJoin(dflt_dates.as("dd"))
        .join(tempProvClientRel.as("pa"), $"pa.mstrprovid" === $"sp.master_hgprovid" && $"pa.startdate" <= coalesce($"pa.enddate", current_date()) && $"sp.start_date" > $"pa.startdate" && $"sp.end_date" <= coalesce($"pa.enddate", $"dd.end_date"), "left")
        .join(provStatusRollUp.as("psr"), $"psr.prov_status_id" === $"pa.prov_status_id", "left")
        .select(
        $"sp.master_hgprovid",
          $"sp.start_date",
          $"sp.end_date",
          $"pa.prov_status_id".as("provider_status"),
          $"prov_status_rollup",
          $"pa.enddate",
          $"pa.startdate",
          $"pa.mstrprovid".as("pa_mstrprovid"),
          $"primary_span"
      )

    val resultSetWindow = Window.partitionBy($"master_hgprovid", $"start_date", $"end_date")
      .orderBy($"pa_mstrprovid".desc_nulls_last,
        $"prov_status_rollup".desc_nulls_last,
        $"enddate".desc_nulls_first,
        $"startdate".desc_nulls_last,
        when(upper($"primary_span") === lit("Y"), lit(1)).
          when(upper($"primary_span") === lit("N"), lit(3)).
          otherwise(lit(2))
        ,
        $"provider_status".desc_nulls_last
      )

    val rsltSet = intermediateRsltSet1
      .union(intermediateRsltSet2)
      .union(intermediateRsltSet3)
      .withColumn("rw_id", row_number.over(resultSetWindow))
      .where($"rw_id" === lit(1))
      .select(
        lit(grpid).as("groupid"),
        $"master_hgprovid",
        $"start_date",
        $"end_date",
        $"provider_status"
      )

    val windowedResult = rsltSet
      .groupBy($"master_hgprovid")
      .agg(
        collectListFromType[temp_bpo_prov_client_rel_spans](sparkSession).as("resultList")
      )
      .as[resultPerProvid]
      .flatMap(rsltDoc => {
        val sortedByStartDate = rsltDoc.resultList.sortWith {
          case (left, right) =>
            if(left.start_date == null) {
              false
            } else if(right.start_date == null) {
              true
            } else {
              left.start_date.before(right.start_date)
            }
        }
        windowMatchForResultSet(sortedByStartDate)
      }).orderBy($"groupid", $"master_hgprovid", $"start_date", $"end_date")

    val result = windowedResult.select(
      $"groupid",
      $"master_hgprovid",
      $"start_date",
      $"end_date",
      $"provider_status"
    ).as[temp_bpo_prov_client_rel_spans].toDF()

    result
  }

  def windowMatchForResultSet(sortedByMemberStart: Seq[temp_bpo_prov_client_rel_spans]): Seq[temp_bpo_prov_client_rel_spans] = {
    val windowed = sortedByMemberStart.foldLeft((Option.empty[temp_bpo_prov_client_rel_spans], Seq.empty[temp_bpo_prov_client_rel_spans])) {
      case ((prevOption, finished), current) =>

        if (prevOption.isEmpty) {
          // first record, just use everything in current
          (Some(current), finished)

        } else {
          // there is an existing window, determine if current belongs in it
          val prev = prevOption.get

          if ((current.provider_status != null && prev.provider_status != null) && (current.provider_status == prev.provider_status)) { // if null, treat as different window)
            // still in the window, put the current end_date into the previous. do not alter finished as this window is not finished
            (Some(prev.copy(end_date = current.end_date)), finished)
          } else {
            // not in the same window, use the new current as the start of the window and put prev into finished
            (Some(current), finished :+ prev)
          }
        }
    }

    val result = windowed._1 match {
      case Some(lastWindow) => windowed._2 :+ lastWindow
      case None => windowed._2
    }
    result
  }
}

case class resultPerProvid(master_hgprovid: String, resultList: Seq[temp_bpo_prov_client_rel_spans])

