package com.optum.oap.backend.etl.patient_matching.quality_gates

import com.optum.oap.backend.cdrTempModel.{qgate_person_id_status, pat_match_prep}
import com.optum.oap.backend.etl.common.CDRConstants
import com.optum.oap.cdr.models._
import com.optum.oap.sparkdataloader.{RuntimeVariables, TableInfo, UserDefinedFunctionForDataLoader}
import org.apache.spark.sql.functions.broadcast
import org.apache.spark.sql.{DataFrame, SparkSession}

object QGATE_PERSON_ID_EVIDENCE extends TableInfo[qgate_person_id_evidence]{

  override def dependsOn: Set[String] = Set("PAT_MATCH_PREP", "CDR_FE_PATIENTADDR", "PATIENTDETAIL_PREMATCH","MAP_GENDER", "PRE_PATIENT_MPI", "QGATE_PERSON_ID_SUSPECTS","QGATE_PERSON_ID_STATUS", "ICPM_PATIENTADDR")
  override def name = "QGATE_PERSON_ID_EVIDENCE"

  override def createDataFrame(sparkSession: SparkSession,
                               loadedDependencies: Map[String, DataFrame],
                               udfMap: Map[String, UserDefinedFunctionForDataLoader],
                               runtimeVariables: RuntimeVariables): DataFrame = {
    import sparkSession.implicits._

    val patMatchPrep = loadedDependencies("PAT_MATCH_PREP").as[pat_match_prep]
    val patientAddr1 = loadedDependencies("CDR_FE_PATIENTADDR").drop("row_source","modified_date").as[patientaddr]
    val icpmPatientAddr = loadedDependencies("ICPM_PATIENTADDR").drop("row_source","modified_date").as[patientaddr]
    val patientAddr = patientAddr1.unionByName(icpmPatientAddr)
    val patientDetail = loadedDependencies("PATIENTDETAIL_PREMATCH").as[patientdetail]
    val mapGender = broadcast(loadedDependencies("MAP_GENDER").as[map_gender])
    val patientMpi = loadedDependencies("PRE_PATIENT_MPI").as[patient_mpi]
    val personSuspects = loadedDependencies("QGATE_PERSON_ID_SUSPECTS").as[qgate_person_id_suspects]
    val personStatus = loadedDependencies("QGATE_PERSON_ID_STATUS")
      .where($"status_cd".isInCollection(CDRConstants.CLEARED_AND_REFFERED_2_CLIENT_STATUS_IDS)).as[qgate_person_id_status]

    val ids2chk = personSuspects.as("s")
      .join(personStatus.as("prev"), Seq("groupid", "personid"), "left_outer")
      .select($"groupid", $"personid")

    patMatchPrep.as("pts")
      .join(patientMpi.as("mpi"), $"mpi.groupid" === $"pts.groupid" && $"pts.patientid" === $"mpi.patientid" && $"pts.client_ds_id" === $"mpi.client_ds_id", "inner")
      .join(ids2chk.as("bad"), $"mpi.groupid" === $"bad.groupid" && $"mpi.grp_mpi" === $"bad.personid", "inner")
      .join(patientAddr.as("pad"), Seq("groupid", "patientid", "client_ds_id"), "left")
      .join(patientDetail.as("pdet"), Seq("groupid", "patientid", "client_ds_id"), "left")
      .join(mapGender.as("mg"), $"pdet.localvalue" === $"mg.mnemonic", "left")
      .select(
        $"pts.groupid",
        $"pts.client_ds_id",
        $"bad.personid",
        $"pts.patientid",
        $"pts.dob",
        $"pts.fname".as("first_name"),
        $"pts.lname".as("last_name"),
        $"mg.cui".as("gender"),
        $"pad.address_line1".as("street_addr"),
        $"pad.city".as("city"),
        $"pad.state".as("state"),
        $"pad.zipcode".as("zipcode")
      )
  }

}
