package com.optum.oap.backend.etl.enrichment

import com.optum.oap.backend.etl.common.{MapMasterIds, MapMedication}
import com.optum.oap.backend.loader.EnrichmentRunTimeVariables
import com.optum.oap.cdr.models.{patient_mpi, rxadmin, zh_med_map_dcc, zh_provider_master_xref}
import com.optum.oap.sparkdataloader.{RuntimeVariables, TableInfo, UserDefinedFunctionForDataLoader}
import org.apache.spark.sql.{DataFrame, SparkSession}
import org.apache.spark.sql.functions.{broadcast, trim}
import org.slf4j.LoggerFactory

object RXADMIN extends TableInfo[rxadmin] {

  val log = LoggerFactory.getLogger(this.getClass)

  override def dependsOn = Set("PATIENT_MPI", "ZH_PROVIDER_MASTER_XREF", "CDR_FE_RXADMIN", "ZH_MED_MAP_DCC")

  override def name = "RXADMIN"

  override def saveDataFrameToParquet: Boolean = true

  override def partitions: Int = 32

  override def skipTable: Boolean = false

  override def ignoreExtraColumnsInDataFrame: Boolean = true

  override def createDataFrame(sparkSession: SparkSession,
                               loadedDependencies: Map[String, DataFrame],
                               udfMap: Map[String, UserDefinedFunctionForDataLoader],
                               runtimeVariables: RuntimeVariables): DataFrame = {
    import sparkSession.implicits._


    val rxadmin = loadedDependencies("CDR_FE_RXADMIN").as[rxadmin]
    val rxadminIn = rxadmin.select(rxadmin.columns.map {
      colName => {
        colName.toLowerCase match {
          case "localform" | "localroute" | "localstrengthunit"  => trim(rxadmin.col(colName)).as(colName)
          case _ => rxadmin.col(colName)
        }
      }
    }:_*)

    val provXref = broadcast(loadedDependencies("ZH_PROVIDER_MASTER_XREF")).as[zh_provider_master_xref]
    val patXref = loadedDependencies("PATIENT_MPI").as[patient_mpi]
    val mapDccDf = broadcast(loadedDependencies("ZH_MED_MAP_DCC")).as[zh_med_map_dcc]

    val mappedProviderIdDf = MapMasterIds.mapProviderIds(MapMasterIds.mapPatientIds(rxadminIn.toDF, patXref.toDF, false), provXref.toDF(), "localproviderid", "mstrprovid")

    val partitionMultiplier = EnrichmentRunTimeVariables(runtimeVariables).partitionMultiplier
    val repNum = Math.ceil(partitions * partitionMultiplier).toInt
    val repartitionedRxadmin = mappedProviderIdDf.repartition(repNum, $"groupid", $"datasrc", $"client_ds_id", $"localmedcode")
    MapMedication.applyMedMap(repartitionedRxadmin, false, mapDccDf.toDF(), null, "localmedcode", dccFlag = true)

  }
}
