package com.optum.oap.backend.etl.enrichment

import com.optum.oap.backend.cdrTempModel.{ref_cmsnpi_partial}
import com.optum.oap.cdr.models.{int_claim_prov, zh_facility}
import com.optum.oap.sparkdataloader.{RuntimeVariables, TableInfo, UserDefinedFunctionForDataLoader}
import org.apache.spark.sql.expressions.Window
import org.apache.spark.sql.{DataFrame, SparkSession}
import org.apache.spark.sql.functions._
import org.apache.spark.sql.types.DataTypes
import org.slf4j.LoggerFactory

object ICPM_FACILITY extends TableInfo[zh_facility] {

  private val log = LoggerFactory.getLogger(this.getClass)

  override def dependsOn = Set("INT_CLAIM_PROV", "REF_CMSNPI", "INT_CLAIM_MEDICAL")

  override def name = "ICPM_FACILITY"

  override def partitions: Int = 32

  override def createDataFrame(sparkSession: SparkSession,
                               loadedDependencies: Map[String, DataFrame],
                               udfMap: Map[String, UserDefinedFunctionForDataLoader],
                               runtimeVariables: RuntimeVariables): DataFrame = {

    import sparkSession.implicits._

    val cdrFeIntClaimProv = loadedDependencies("INT_CLAIM_PROV").as[int_claim_prov]

    val cdrFeIntClaimMedical = loadedDependencies("INT_CLAIM_MEDICAL")

    val refCmsNpi = loadedDependencies("REF_CMSNPI").as[ref_cmsnpi_partial]

    val intClaimProvDf = cdrFeIntClaimProv.as("prov")
      .join(refCmsNpi.as("cms"), $"prov.prov_npi" === $"cms.npi", "left")
      .select(
        $"groupid"
        , $"client_ds_id"
        , lit("int_claim_prov").as("datasrc")
        , $"prov.prov_id".as("facilityid")
        , coalesce(
          $"prov_name"
          , trim(
            expr("nullif(concat_ws(' ' , trim(prov_lname), trim(prov_fname)),'')")
          )
          , $"prov_org_name_legal_bus_name"
        ).as("facilityname")
        , coalesce(
          $"prov.prov_zip_code"
          , $"cms.prov_bus_mail_addr_postalcode"
        ).as("facilitypostalcd")
        , $"prov.prov_npi".as("npi")
        , $"prov.prov_spclty_cd".as("specialty")
        , $"update_dt".as("updatedate")
        , lit("1").as("source")
      )

    val intClaimMedicalDf = cdrFeIntClaimMedical.select(
      $"groupid"
      , lit("int_claim_medical").as("datasrc")
      , $"client_ds_id"
      , $"facility_name"
      , $"servicing_prov_name"
      , $"servicing_prov_fname"
      , $"servicing_prov_lname"
      , $"servicing_prov_npi".as("prov_npi")
      , $"servicing_prov_spclty_cd".as("specialty")
      , $"service_date".as("updatedate")
      , expr(
        "stack(2, facility_code, 'FACILITY_CODE', servicing_prov_id, 'SERVICING_PROV_ID') " +
          "as (facility_cd, fac_source)")
    ).as("x")
      .join(refCmsNpi.as("cms"), $"x.prov_npi" === $"cms.npi", "left")
      .select(
        $"groupid"
        , $"client_ds_id"
        , $"datasrc"
        , $"x.facility_cd".as("facilityid")
        , when($"fac_source" === "FACILITY_CODE", $"facility_name")
          .otherwise(
            coalesce($"servicing_prov_name"
              , trim(
                expr("nullif(concat_ws(' ', trim(servicing_prov_lname), trim(servicing_prov_fname)),'')")
              )
              , $"prov_org_name_legal_bus_name")
          ).as("facilityname")
        , when($"fac_source" === "FACILITY_CODE", lit(null))
          .otherwise(
            $"prov_bus_mail_addr_postalcode"
          ).as("facilitypostalcd")
        , when($"fac_source" === "FACILITY_CODE", lit(null))
          .otherwise(
            $"prov_npi"
          ).as("npi")
        , when($"fac_source" === "FACILITY_CODE", lit(null))
          .otherwise(
            $"x.specialty"
          ).as("specialty")
        , $"updatedate"
        , lit("2").as("source")
      )

    intClaimProvDf.unionByName(intClaimMedicalDf)
      .withColumn("rank_fac"
        , row_number().over(Window.partitionBy($"client_ds_id", $"facilityid")
          //Comparing to Oracle script, facilitypostalcd and npi are added in addition to other orderBy columns to avoid non-deterministic issue.
          .orderBy($"source", $"updatedate".desc_nulls_last, length($"facilityname").desc_nulls_last, $"facilitypostalcd".asc_nulls_last, $"npi".asc_nulls_last)))
      .filter($"rank_fac" === 1 && $"facilityid".isNotNull)
      .select($"groupid"
        , $"client_ds_id"
        , $"facilityid"
        , $"facilityname"
        , substring($"facilitypostalcd", 1, 10).as("facilitypostalcd")
        , $"npi"
        , $"specialty"
        , lit(null).cast(DataTypes.DoubleType).as("charge_cost_ratio")
        , lit(null).cast(DataTypes.StringType).as("localfacilitytype")
        , lit(null).cast(DataTypes.StringType).as("address1")
        , lit(null).cast(DataTypes.StringType).as("address2")
        , lit(null).cast(DataTypes.StringType).as("city")
        , lit(null).cast(DataTypes.StringType).as("state")
      )
  }
}
