package com.optum.oap.backend.etl.patient_matching.data_table

import com.optum.oap.backend.cdrTempModel.pat_match_prep
import com.optum.oap.backend.etl.common.{CDRConstants, CleanPatientName, EnrichmentUtils}
import com.optum.oap.backend.loader.EnrichmentRunTimeVariables
import com.optum.oap.cdr.models.mpi_dob
import com.optum.oap.sparkdataloader.{RuntimeVariables, TableInfo, UserDefinedFunctionForDataLoader}
import org.apache.spark.sql.expressions.Window
import org.apache.spark.sql.functions._
import org.apache.spark.sql.types.{LongType, StringType}
import org.apache.spark.sql.{DataFrame, SparkSession}

/**
  * This is the generic MPI_DOB ETL
  */
object MPI_DOB extends TableInfo[mpi_dob] {

  override def dependsOn = Set("PAT_MATCH_PREP", "ECDR_MPI_DOB")

  override def name = "MPI_DOB"

  val partitionKey: String = "dob"

  override def saveDataFrameToParquet: Boolean = true

  override def createDataFrame(sparkSession: SparkSession,
                               loadedDependencies: Map[String, DataFrame],
                               udfMap: Map[String, UserDefinedFunctionForDataLoader],
                               runtimeVariables: RuntimeVariables): DataFrame = {
    import sparkSession.implicits._

    val dailyBuild = if (runtimeVariables.asInstanceOf[EnrichmentRunTimeVariables].buildType == CDRConstants.DELTA_BUILD_TYPE) true else false

    val tempPatMatchPrep = loadedDependencies("PAT_MATCH_PREP").as[pat_match_prep]

    val subSelect = tempPatMatchPrep
      .where($"dob".isNotNull)
      .select(
        $"groupid", $"client_ds_id", $"patientid", $"hgpid", $"dob", $"gender",
        upper($"fname").as("first_name"), upper($"lname").as("last_name"),
        when(substring(trim(upper($"fname")), 1, 4).isin("BABY", "TWIN", "FEMA", "MALE")
          && substring(trim(upper($"fname")), -2, 2).isin(" A", " B", " 1", " 2", "-A", "-B", "-1", "-2"), trim(upper($"fname")))
          .otherwise(CleanPatientName.cleanPatientName($"fname", lit(3))).as("adjfirst"),
        CleanPatientName.cleanPatientName($"lname", lit(3)).as("adjlast")
      ).distinct

    val dataDf = subSelect.select($"groupid", $"client_ds_id", $"patientid", $"hgpid",
      $"dob", $"gender", $"first_name", $"last_name",
      upper(substring($"adjfirst", 0, 1)).as("first_init"),
      upper(substring($"adjlast", 0, 1)).as("last_init"),
      when(substring($"adjfirst", -2, 1) === lit(" "), // case when substr(upper(adjfirst),-2,1) = ' '
        upper($"adjfirst").substr(lit(0), length($"adjfirst") - lit(2)) // then substr(upper(adjfirst),1,length(upper(adjfirst)) - 2)
      ).otherwise(upper($"adjfirst")).as("first_no_int"), // else upper(adjfirst) end as first_no_int
      upper(regexp_extract($"adjfirst", "(^[^ ,]{1,})", 1)).as("first_word"),
      size(collect_set("groupid").over(Window.partitionBy($"dob"))).as("group_cnt"),
      size(collect_set("hgpid").over(Window.partitionBy($"dob"))).cast(LongType).as("hgpids"),
      $"adjfirst".as("adj_firstname"),
      $"adjlast".as("adj_lastname"),
      lit(null).cast(StringType).as("middle_name"),
      lit(null).cast(StringType).as("addr"),
      lit(null).cast(StringType).as("city"),
      lit(null).cast(StringType).as("state"),
      lit(null).cast(StringType).as("zip"),
      lit(null).cast(StringType).as("phone"),
      lit(null).cast(StringType).as("email")
    )

    val ecdrDf = {
      if (dailyBuild) EnrichmentUtils.removeRowSourceAndModifiedDate(loadedDependencies("ECDR_MPI_DOB")).as[mpi_dob]
      else sparkSession.emptyDataset[mpi_dob].as[mpi_dob]
    }.as("e")
      .select($"e.*")

    dataDf.unionByName(ecdrDf).distinct()

  }
}
