package com.optum.oap.backend.etl.common

import com.optum.oap.sparkdataloader.UserDefinedFunctionForDataLoader
import org.apache.spark.sql.SparkSession
import org.apache.spark.sql.expressions.UserDefinedFunction
import org.apache.spark.sql.functions.udf


object SafeToDateLength extends UserDefinedFunctionForDataLoader {

  val safeToDateLength: UserDefinedFunction = udf {
    (dateString: String, dateFormat: String, dateLength: Integer) => {
      CommonFunctions.safeToDate(dateString, dateFormat, dateLength)
    }
  }

  override def name: String = "safe_to_date_length"

  override def registerMe(sparkSession: SparkSession): Unit = {
    sparkSession.udf.register(name, safeToDateLength)
  }
}
