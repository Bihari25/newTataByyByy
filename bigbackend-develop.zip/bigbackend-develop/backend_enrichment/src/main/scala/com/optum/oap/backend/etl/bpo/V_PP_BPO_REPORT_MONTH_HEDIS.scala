package com.optum.oap.backend.etl.bpo

import com.optum.oap.backend.etl.common.CDRConstants
import com.optum.oap.cdr.models._
import com.optum.oap.sparkdataloader.{RuntimeVariables, TableInfo, UserDefinedFunctionForDataLoader}
import org.apache.spark.sql.functions._
import org.apache.spark.sql.{DataFrame, SparkSession}

object V_PP_BPO_REPORT_MONTH_HEDIS extends TableInfo[v_pp_bpo_report_month_hedis] {

  override def dependsOn = Set("PP_BPO_MEMBER_DETAIL")

  override def name = "V_PP_BPO_REPORT_MONTH_HEDIS"

  override def createDataFrame(sparkSession: SparkSession,
                               loadedDependencies: Map[String, DataFrame],
                               udfMap: Map[String, UserDefinedFunctionForDataLoader],
                               runtimeVariables: RuntimeVariables): DataFrame = {

    import sparkSession.implicits._

    val ppBpoMemberDetail = loadedDependencies("PP_BPO_MEMBER_DETAIL").as[pp_bpo_member_detail]

    ppBpoMemberDetail.where($"healthplansource" === lit("PAYER")).groupBy($"groupid")
      .agg(
        max(to_timestamp(concat(year($"enddate"), lit("1231")), CDRConstants.DATE_FORMAT_4Y2M2D)).alias("yr0_date"),
        max(to_timestamp(concat(year($"enddate") - 1, lit("1231")), CDRConstants.DATE_FORMAT_4Y2M2D)).alias("yr1_date"),
        max(to_timestamp(concat(year($"enddate") - 2, lit("1231")), CDRConstants.DATE_FORMAT_4Y2M2D)).alias("yr2_date"),
        max(to_timestamp(concat(year($"enddate") - 3, lit("1231")), CDRConstants.DATE_FORMAT_4Y2M2D)).alias("yr3_date"),
        min($"effectivedate").alias("min_eff_date")
      )
      .select(
        $"*"
      )

  }
}
