package com.optum.oap.backend.etl.common

import com.optum.oap.sparkdataloader.UserDefinedFunctionForDataLoader
import org.apache.spark.sql.SparkSession
import org.apache.spark.sql.expressions.UserDefinedFunction
import org.apache.spark.sql.functions.udf

/**
  *
  * Copyright 2019 Optum Analytics
  *
  * Date: 9/18/2019
  *
  * Creator: rrogers2
  */
object CleanName extends UserDefinedFunctionForDataLoader with cleanNameTrait {

  /**
   * Remove suffix, prefix, titles, middle initials, punctuation from patient and provider names
   */

  val occupations = "STUDENT |THERAPY |THERAPIST |THERAPIES |THERAPEUTIC |PHYSICIAN |INSTRUCTOR |HISTORY |HISTORICAL |RESIDENT "
  val suffixes = "JR$|SR$|IIII$|III$|II$| IV$| MD$| MR$| DR$| MS$| MRS$| DDS$|^DR |^DDS |^MRS |^MR |^MS |^JR |^SR |^III |^MD | JR | SR | II | III | DDS |111$|11$|2ND$|3RD$|[(][A-Z].*[)]| M D "
  override val matchPatterns = occupations + "|" + suffixes + "| D O | MD | PA$| PHD$|^DO | DO | DO$| NP$| NP |^NOS | NOS | NOS$"
  val cleanPersonName: UserDefinedFunction = udf (cleanName _)

  override def registerMe(sparkSession: SparkSession): Unit = {
    sparkSession.udf.register(name, cleanPersonName)
  }

  override def name: String = "cleanName"
}