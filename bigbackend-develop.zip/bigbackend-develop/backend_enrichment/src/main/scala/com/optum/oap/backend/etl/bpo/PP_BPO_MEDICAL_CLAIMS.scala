package com.optum.oap.backend.etl.bpo

import com.optum.oap.backend.cdrTempModel._
import com.optum.oap.backend.etl.bpo.BpoUtil.getBpoInputParameters
import com.optum.oap.cdr.models._
import com.optum.oap.sparkdataloader.{RuntimeVariables, TableInfo, UserDefinedFunctionForDataLoader}
import org.apache.spark.sql.functions.{lit, when, _}
import org.apache.spark.sql.types._
import org.apache.spark.sql.{DataFrame, Row, SparkSession}

/**
  *
  * Copyright 2019 Optum Analytics
  *
  * Date: 5/31/19
  *
  * Creator: bpokharel(bishu)
  */
object PP_BPO_MEDICAL_CLAIMS extends TableInfo[pp_bpo_medical_claims] {

  override def dependsOn = Set(
    "TEMP_BPO_CLAIM",
    "TEMP_BPO_DIAGNOSIS",
    "TEMP_BPO_PROCEDURE",
    "ZO_PLACE_OF_SERVICE",
    "ZO_DISCHARGE_DISPOSITION",
    "ZO_BPO_MAP_EMPLOYER",
    "TEMP_PP_BPO_PROVIDER_DETAIL",
    "ZO_ADMIT_SOURCE",
    "TEMP_BPO_CALCULATE_PARAMS",
    "PROCEDUREDO",
    "TEMP_BPO_PATIENTS",
    "CLINICALENCOUNTER",
    "MAP_PATIENT_TYPE",
    "REF_CUSTOM_PROC_MAPPED_VALUES"
  )

  override def name = "PP_BPO_MEDICAL_CLAIMS"

  override def partitions: Int = 512

  override def createDataFrame(sparkSession: SparkSession,
                               loadedDependencies: Map[String, DataFrame],
                               udfMap: Map[String, UserDefinedFunctionForDataLoader],
                               runtimeVariables: RuntimeVariables): DataFrame = {
    import sparkSession.implicits._

    val temp_bpo_claim_DS = loadedDependencies("TEMP_BPO_CLAIM").as[temp_bpo_claim]
    val temp_bpo_diagnosis_DS = loadedDependencies("TEMP_BPO_DIAGNOSIS").as[temp_bpo_diagnosis]
    val temp_bpo_procedure_DS = loadedDependencies("TEMP_BPO_PROCEDURE").as[temp_bpo_procedure]
    val zo_place_of_service_DS = broadcast(loadedDependencies("ZO_PLACE_OF_SERVICE")).as[zo_place_of_service]
    val zo_discharge_disposition_DS = broadcast(loadedDependencies("ZO_DISCHARGE_DISPOSITION")).as[zo_discharge_disposition]
    val zo_bpo_map_employer_DS = broadcast(loadedDependencies("ZO_BPO_MAP_EMPLOYER")).as[zo_bpo_map_employer]
    val pp_bpo_provider_detail_DS = broadcast(loadedDependencies("TEMP_PP_BPO_PROVIDER_DETAIL")).as[pp_bpo_provider_detail]
    val zo_admit_source_DS = broadcast(loadedDependencies("ZO_ADMIT_SOURCE")).as[zo_admit_source]

    val joinedDf1 = temp_bpo_claim_DS.as("clm")
      .join(temp_bpo_diagnosis_DS.as("dx"),
        ($"clm.groupid" === $"dx.groupid")
          && ($"clm.encounterid" === $"dx.encounterid")
          && ($"clm.client_ds_id" === $"dx.client_ds_id")
          && ($"clm.grp_mpi" === $"dx.grp_mpi")
          && ($"dx.record_preference" === lit(1))
          && ($"dx.sourceid" === $"clm.sourceid"),
        "left_outer"
      )
      .join(zo_admit_source_DS.as("zo"),
        $"clm.admitsourcecui" === $"zo.cui", "left_outer")
      .join(temp_bpo_procedure_DS.as("px"),
        ($"clm.groupid" === $"px.groupid")
          && ($"clm.encounterid" === $"px.encounterid")
          && ($"clm.client_ds_id" === $"px.client_ds_id")
          && ($"clm.grp_mpi" === $"px.grp_mpi")
          && ($"clm.servicedate" === $"px.servicedate")
          && ($"dx.codetype" === $"px.codetype")
          && ($"px.sourceid" === $"clm.sourceid"),
        "left_outer"
      )
      .join(zo_place_of_service_DS.as("pos"),
        $"pos.hts_cui" === $"clm.patienttype",
        "left_outer"
      )
      .join(zo_discharge_disposition_DS.as("dis"),
        $"dis.hts_cui" === $"clm.disposition",
        "left_outer"
      )
      .join(zo_bpo_map_employer_DS.as("zo_map"),
        $"zo_map.client_ds_id" === $"clm.client_ds_id",
        "left_outer"
      ).select(
      $"clm.groupid",
      $"clm.grp_mpi".cast(StringType).as("memberid"),
      to_timestamp($"clm.paymentdate").as("paymentdate"),
      to_timestamp($"clm.servicedate").as("servicedate"),
      to_timestamp(
        coalesce($"clm.admittime", when($"clm.encounterid".isNull, $"clm.servicedate").otherwise($"clm.min_svc_date"))
      ).as("fromdate"),
      to_timestamp(
        coalesce($"clm.todate", when($"clm.encounterid".isNull, $"clm.servicedate").otherwise($"clm.max_svc_date"))
      ).as("todate"),
      coalesce($"claim_mstrprovid", lit("0")).cast(StringType).as("serviceproviderid"),
      when(length($"clm.pos").leq(lit(3)) && $"clm.pos".isNotNull, $"clm.pos")
        .when($"pos.ii_code".isNotNull, $"pos.ii_code")
        .otherwise(lit("99"))
        .as("placeofservice"),
      $"clm.revenuecode",
      $"clm.procedurecode",
      $"clm.proceduremodifier",
      $"clm.proc_code_modifier2",
      $"clm.proc_code_modifier3",
      $"clm.proc_code_modifier4",
      when($"clm.revenuecode".isNull && $"clm.procedurecode".isNull && $"clm.patienttype".isin(lit("CH000106"), lit("CH000107"), lit("CH000109"), lit("CH000113")), lit("2"))
        .when($"clm.revenuecode".isNull && $"clm.procedurecode".isNull && $"clm.patienttype".isin(lit("CH000110")), lit("1"))
        .when($"clm.revenuecode".isNull && $"clm.procedurecode".isNull, lit("0"))
        .otherwise(lit(null).cast(StringType))
        .as("tos"),
      when(coalesce($"px.codetype", $"dx.codetype") === lit("ICD10"), lit("10"))
        .when(coalesce($"px.codetype", $"dx.codetype") === lit("ICD9"), lit("9"))
        .otherwise(lit(null).cast(StringType))
        .as("icdcodetype"),
      $"icdproc1",
      $"icdproc2",
      $"icdproc3",
      $"icdproc4",
      $"icdproc5",
      $"icdproc6",
      $"icd_proc_7",
      $"icd_proc_8",
      $"icd_proc_9",
      $"icd_proc_10",
      $"icd_proc_11",
      $"icd_proc_12",
      $"icd_proc_13",
      $"icd_proc_14",
      $"icd_proc_15",
      $"icd_proc_16",
      $"icd_proc_17",
      $"icd_proc_18",
      $"icd_proc_19",
      $"icd_proc_20",
      $"icd_proc_21",
      $"icd_proc_22",
      $"icd_proc_23",
      $"icd_proc_24",
      $"icd_proc_25",
      when(length($"icddiag1").leq(lit(8)), $"icddiag1").otherwise(lit(null).cast(StringType)).as("icddiag1"),
      when(length($"icddiag2").leq(lit(8)), $"icddiag2").otherwise(lit(null).cast(StringType)).as("icddiag2"),
      when(length($"icddiag3").leq(lit(8)), $"icddiag3").otherwise(lit(null).cast(StringType)).as("icddiag3"),
      when(length($"icddiag4").leq(lit(8)), $"icddiag4").otherwise(lit(null).cast(StringType)).as("icddiag4"),
      when(length($"icddiag5").leq(lit(8)), $"icddiag5").otherwise(lit(null).cast(StringType)).as("icddiag5"),
      when(length($"icddiag6").leq(lit(8)), $"icddiag6").otherwise(lit(null).cast(StringType)).as("icddiag6"),
      when(length($"icddiag7").leq(lit(8)), $"icddiag7").otherwise(lit(null).cast(StringType)).as("icddiag7"),
      when(length($"icddiag8").leq(lit(8)), $"icddiag8").otherwise(lit(null).cast(StringType)).as("icddiag8"),
      when(length($"icddiag9").leq(lit(8)), $"icddiag9").otherwise(lit(null).cast(StringType)).as("icddiag9"),
      when(length($"icddiag10").leq(lit(8)), $"icddiag10").otherwise(lit(null).cast(StringType)).as("icddiag10"),
      when(length($"icd_diag_11").leq(lit(8)), $"icd_diag_11").otherwise(lit(null).cast(StringType)).as("icd_diag_11"),
      when(length($"icd_diag_12").leq(lit(8)), $"icd_diag_12").otherwise(lit(null).cast(StringType)).as("icd_diag_12"),
      when(length($"icd_diag_13").leq(lit(8)), $"icd_diag_13").otherwise(lit(null).cast(StringType)).as("icd_diag_13"),
      when(length($"icd_diag_14").leq(lit(8)), $"icd_diag_14").otherwise(lit(null).cast(StringType)).as("icd_diag_14"),
      when(length($"icd_diag_15").leq(lit(8)), $"icd_diag_15").otherwise(lit(null).cast(StringType)).as("icd_diag_15"),
      when(length($"icd_diag_16").leq(lit(8)), $"icd_diag_16").otherwise(lit(null).cast(StringType)).as("icd_diag_16"),
      when(length($"icd_diag_17").leq(lit(8)), $"icd_diag_17").otherwise(lit(null).cast(StringType)).as("icd_diag_17"),
      when(length($"icd_diag_18").leq(lit(8)), $"icd_diag_18").otherwise(lit(null).cast(StringType)).as("icd_diag_18"),
      when(length($"icd_diag_19").leq(lit(8)), $"icd_diag_19").otherwise(lit(null).cast(StringType)).as("icd_diag_19"),
      when(length($"icd_diag_20").leq(lit(8)), $"icd_diag_20").otherwise(lit(null).cast(StringType)).as("icd_diag_20"),
      when(length($"icd_diag_21").leq(lit(8)), $"icd_diag_21").otherwise(lit(null).cast(StringType)).as("icd_diag_21"),
      when(length($"icd_diag_22").leq(lit(8)), $"icd_diag_22").otherwise(lit(null).cast(StringType)).as("icd_diag_22"),
      when(length($"icd_diag_23").leq(lit(8)), $"icd_diag_23").otherwise(lit(null).cast(StringType)).as("icd_diag_23"),
      when(length($"icd_diag_24").leq(lit(8)), $"icd_diag_24").otherwise(lit(null).cast(StringType)).as("icd_diag_24"),
      when(length($"icd_diag_25").leq(lit(8)), $"icd_diag_25").otherwise(lit(null).cast(StringType)).as("icd_diag_25"),
      coalesce($"icddiag1poa", lit("U")).as("poa"),
      coalesce($"icddiag2poa", lit("U")).as("poa_2"),
      coalesce($"icddiag3poa", lit("U")).as("poa_3"),
      coalesce($"icddiag4poa", lit("U")).as("poa_4"),
      coalesce($"icddiag5poa", lit("U")).as("poa_5"),
      coalesce($"icddiag6poa", lit("U")).as("poa_6"),
      coalesce($"icddiag7poa", lit("U")).as("poa_7"),
      coalesce($"icddiag8poa", lit("U")).as("poa_8"),
      coalesce($"icddiag9poa", lit("U")).as("poa_9"),
      coalesce($"icddiag10poa", lit("U")).as("poa_10"),
      coalesce($"icddiag11poa", lit("U")).as("poa_11"),
      coalesce($"icddiag12poa", lit("U")).as("poa_12"),
      coalesce($"icddiag13poa", lit("U")).as("poa_13"),
      $"dis.ii_code".as("dischargestatus"),
      $"clm.quantity".cast(IntegerType),
      $"clm.allowedamount",
      $"clm.requestedamount",
      $"clm.paidamount",
      when($"zo_map.client_ds_id".isNull, lit("PROVIDER")).otherwise(lit("PAYER")).as("healthplansource"),
      lit("MED").as("coverageclasscode"),
      $"clm.patienttype",
      $"clm.client_ds_id",
      $"clm.par_flag",
      $"zo_map.employeraccountid",
      coalesce($"clm.contract_id", $"zo_map.employeraccountid").as("contract_id"),
      $"clm.network_paid_status",
      $"clm.ffsamount",
      $"clm.copayamount",
      $"clm.coinsamount",
      $"clm.deductamount",
      $"clm.patliabamount",
      $"clm.cobamount",
      $"clm.withamount",
      $"clm.capamount",
      $"clm.capsvcflag",
      $"clm.deniedflag",
      $"clm.pseudoflag",
      $"clm.claimid",
      $"clm.prov_svc_ii_spec",
      $"clm.type_of_service",
      $"clm.amt_oth1",
      $"clm.amt_oth2",
      $"clm.amt_oth3",
      $"clm.amt_oth4",
      $"clm.billingproviderid",
      $"clm.orderingproviderid",
      $"clm.typeofbill",
      $"clm.spec_rx_ind",
      $"clm.not_covered_amt",
      $"clm.other_carrier_pay_amt",
      $"clm.admin_fee_amt",
      $"clm.denied_ind",
      coalesce($"clm.claim_prov_affil_id", $"clm.provaffiliationid").as("claim_prov_affil_id"),
      when($"clm.localdrggrouper" === "CH001334" && $"clm.localdrg".isNotNull && length($"clm.localdrg") <= 3, $"clm.localdrg")
        .when($"clm.aprdrg_cd".isNotNull && $"clm.aprdrg_cd" <= 3, $"clm.aprdrg_cd")
        .otherwise(lit(null).cast(StringType)).as("drg"),
      when($"clm.localdrggrouper" === "CH001334" && $"clm.localdrg".isNotNull && length($"clm.localdrg") <= 3, "MS")
        .when($"clm.aprdrg_cd".isNotNull && $"clm.aprdrg_cd" <= 3, "APR")
        .otherwise(lit(null).cast(StringType)).as("drggrouper"),
      when($"clm.localdrggrouper" === "CH001334" && $"clm.localdrg".isNotNull && length($"clm.localdrg") <= 3, null)
        .when($"clm.aprdrg_cd".isNotNull && $"clm.aprdrg_cd" <= 3 && $"clm.aprdrg_soi".isin("1", "2", "3", "4"), $"clm.aprdrg_soi")
        .otherwise(lit(null).cast(StringType)).as("drgseverity"),
      when($"clm.localdrgoutlier".isin("0", "1", "2", "3", "4", "5", "6", "7", "8"), $"clm.localdrgoutlier")
        .otherwise(null).as("drgoutlier"),
      when(length($"zo.as_code") === 1, $"zo.as_code").as("admitsource"),
      coalesce($"clm.claim_prov_status_id", $"clm.provider_status").as("provider_status"),
      $"clm.cust_attr_1",
      $"clm.cust_attr_2",
      $"clm.cust_attr_3",
      $"clm.cust_attr_4",
      $"clm.cust_attr_5",
      $"clm.cust_attr_6",
      $"clm.cust_attr_7",
      $"clm.cust_attr_8",
      $"clm.cust_attr_9",
      $"clm.cust_attr_10",
      $"clm.cust_attr_11",
      $"clm.cust_attr_12",
      $"clm.cust_attr_13",
      $"clm.cust_attr_14",
      $"clm.cust_attr_15",
      $"clm.cust_attr_16",
      $"clm.cust_attr_17",
      $"clm.cust_attr_18",
      $"clm.cust_attr_19",
      $"clm.cust_attr_20",
      $"refer_prov_id",
      $"inp_admit_type"
    )

    val netwrk = pp_bpo_provider_detail_DS.select(
      $"providerid",
      lit("Y").as("flag"),
      $"providername",
      $"healthplansource",
      $"specialty",
      $"providertype"
    ).distinct()

    val joinedDf2 = joinedDf1.as("clm1")
      .join(netwrk.as("netwrk"),
        $"clm1.serviceproviderid" === $"netwrk.providerid", "left_outer")
      .select(
        $"clm1.groupid",
        $"memberid",
        $"paymentdate",
        $"servicedate",
        $"fromdate",
        $"todate",
        $"clm1.serviceproviderid",
        coalesce($"clm1.prov_svc_ii_spec", when($"clm1.revenuecode".isNotNull && coalesce($"netwrk.specialty", lit("999")).between(lit("100"), lit("199")), coalesce($"netwrk.specialty", lit("999")))
          .when($"clm1.revenuecode".isNotNull && coalesce($"netwrk.specialty", lit("999")).isin(lit("700"), lit("710"), lit("711"), lit("712")), coalesce($"netwrk.specialty", lit("999")))
          .when($"clm1.revenuecode".isNotNull, lit("100"))
          .otherwise(coalesce($"netwrk.specialty", lit("999")))).as("specialty"),
        coalesce($"clm1.prov_svc_ii_spec", when($"clm1.revenuecode".isNotNull && coalesce($"netwrk.specialty", lit("999")).between(lit("100"), lit("199")), coalesce($"netwrk.specialty", lit("999")))
          .when($"clm1.revenuecode".isNotNull && coalesce($"netwrk.specialty", lit("999")).isin(lit("700"), lit("710"), lit("711"), lit("712")), coalesce($"netwrk.specialty", lit("999")))
          .when($"clm1.revenuecode".isNotNull, lit("100"))
          .otherwise(coalesce($"netwrk.specialty", lit("999")))).as("providertype"),
        $"placeofservice",
        $"revenuecode",
        $"procedurecode",
        $"proceduremodifier",
        $"proc_code_modifier2",
        $"proc_code_modifier3",
        $"proc_code_modifier4",
        $"tos",
        $"icdcodetype",
        $"icdproc1",
        $"icdproc2",
        $"icdproc3",
        $"icdproc4",
        $"icdproc5",
        $"icdproc6",
        $"icd_proc_7",
        $"icd_proc_8",
        $"icd_proc_9",
        $"icd_proc_10",
        $"icd_proc_11",
        $"icd_proc_12",
        $"icd_proc_13",
        $"icd_proc_14",
        $"icd_proc_15",
        $"icd_proc_16",
        $"icd_proc_17",
        $"icd_proc_18",
        $"icd_proc_19",
        $"icd_proc_20",
        $"icd_proc_21",
        $"icd_proc_22",
        $"icd_proc_23",
        $"icd_proc_24",
        $"icd_proc_25",
        $"icddiag1",
        $"icddiag2",
        $"icddiag3",
        $"icddiag4",
        $"icddiag5",
        $"icddiag6",
        $"icddiag7",
        $"icddiag8",
        $"icddiag9",
        $"icddiag10",
        $"icd_diag_11",
        $"icd_diag_12",
        $"icd_diag_13",
        $"icd_diag_14",
        $"icd_diag_15",
        $"icd_diag_16",
        $"icd_diag_17",
        $"icd_diag_18",
        $"icd_diag_19",
        $"icd_diag_20",
        $"icd_diag_21",
        $"icd_diag_22",
        $"icd_diag_23",
        $"icd_diag_24",
        $"icd_diag_25",
        $"drg",
        $"drggrouper",
        $"poa",
        $"poa_2",
        $"poa_3",
        $"poa_4",
        $"poa_5",
        $"poa_6",
        $"poa_7",
        $"poa_8",
        $"poa_9",
        $"poa_10",
        $"poa_11",
        $"poa_12",
        $"poa_13",
        $"dischargestatus",
        $"quantity",
        $"allowedamount",
        $"requestedamount",
        $"paidamount",
        $"clm1.coverageclasscode",
        $"clm1.healthplansource",
        lit("1").as("claimline"),
        when($"clm1.par_flag" === lit("Y"), lit("Y")).otherwise(lit("N")).as("networkstatus"),
        when($"clm1.healthplansource" === lit("PAYER"), lit("AD")).otherwise(lit("SS")).as("mapsource"),
        $"clm1.employeraccountid",
        $"clm1.contract_id",
        $"clm1.provider_status",
        $"clm1.network_paid_status",
        $"clm1.ffsamount",
        $"clm1.copayamount",
        $"clm1.coinsamount",
        $"clm1.deductamount",
        $"clm1.patliabamount",
        $"clm1.cobamount",
        $"clm1.withamount",
        $"clm1.capamount",
        $"clm1.capsvcflag",
        $"clm1.deniedflag",
        $"clm1.pseudoflag",
        $"clm1.client_ds_id",
        $"serviceproviderid".as("provider_key"),
        $"clm1.claimid",
        $"clm1.type_of_service",
        $"clm1.amt_oth1",
        $"clm1.amt_oth2",
        $"clm1.amt_oth3",
        $"clm1.amt_oth4",
        $"clm1.billingproviderid",
        $"clm1.orderingproviderid",
        $"clm1.typeofbill",
        $"clm1.spec_rx_ind",
        $"clm1.not_covered_amt",
        $"clm1.other_carrier_pay_amt",
        $"clm1.admin_fee_amt",
        $"clm1.denied_ind",
        $"clm1.claim_prov_affil_id",
        $"clm1.drgoutlier",
        $"clm1.drgseverity",
        $"clm1.admitsource",
        $"clm1.cust_attr_1".as("cust_med_attr1"),
        $"clm1.cust_attr_2".as("cust_med_attr2"),
        $"clm1.cust_attr_3".as("cust_med_attr3"),
        $"clm1.cust_attr_4".as("cust_med_attr4"),
        $"clm1.cust_attr_5".as("cust_med_attr5"),
        $"clm1.cust_attr_6".as("cust_med_attr6"),
        $"clm1.cust_attr_7".as("cust_med_attr7"),
        $"clm1.cust_attr_8".as("cust_med_attr8"),
        $"clm1.cust_attr_9".as("cust_med_attr9"),
        $"clm1.cust_attr_10".as("cust_med_attr10"),
        $"clm1.cust_attr_11".as("cust_med_attr11"),
        $"clm1.cust_attr_12".as("cust_med_attr12"),
        $"clm1.cust_attr_13".as("cust_med_attr13"),
        $"clm1.cust_attr_14".as("cust_med_attr14"),
        $"clm1.cust_attr_15".as("cust_med_attr15"),
        $"clm1.cust_attr_16".as("cust_med_attr16"),
        $"clm1.cust_attr_17".as("cust_med_attr17"),
        $"clm1.cust_attr_18".as("cust_med_attr18"),
        $"clm1.cust_attr_19".as("cust_med_attr19"),
        $"clm1.cust_attr_20".as("cust_med_attr20"),
        lit(null).cast(StringType).alias("attend_prov_id"),
        lit(null).cast(StringType).alias("claimsource"),
        lit(null).cast(IntegerType).alias("covered_days"),
        lit(null).cast(StringType).alias("cpt2_code"),
        lit(null).cast(StringType).alias("deniedreason"),
        lit(null).cast(StringType).alias("hcpcs_code"),
        $"refer_prov_id",
        $"inp_admit_type"
      )

    // convert to RDD , append rownumber column and change it back to dataframe
    val newSchema = StructType(joinedDf2.schema.fields ++ Array(StructField("rownumber", LongType, nullable = false)))
    val rddWithId = joinedDf2.rdd.zipWithIndex
    val withRowNumberDf = sparkSession.createDataFrame(rddWithId.map { case (row, index) => Row.fromSeq(row.toSeq ++ Array(index + 1)) }, newSchema)

    val joinedDf3 = withRowNumberDf
      .withColumn("claimheader", concat(lit("MED"), $"client_ds_id", lit("."), $"rownumber"))
      .drop("rownumber", "client_ds_id")


    // EBM Improvements - Custom Codes
    val proceduredo_DS = loadedDependencies("PROCEDUREDO").as[proceduredo]
    val temp_bpo_patients_DS = loadedDependencies("TEMP_BPO_PATIENTS").as[temp_bpo_patients]
    val clinicalencounter_DS = loadedDependencies("CLINICALENCOUNTER").as[clinicalencounter]
    val map_patient_type_DS = broadcast(loadedDependencies("MAP_PATIENT_TYPE")).as[map_patient_type]
    val ref_custom_proc_mapped_values_DS = broadcast(loadedDependencies("REF_CUSTOM_PROC_MAPPED_VALUES")).as[ref_custom_proc_mapped_values]

    val temp_bpo_calculate_params_DS = broadcast(loadedDependencies("TEMP_BPO_CALCULATE_PARAMS")).as[temp_bpo_calculate_params]
    val bpoInputParameters = getBpoInputParameters(sparkSession, temp_bpo_calculate_params_DS)
    val extractStartDate = bpoInputParameters.engineStartDate
    val extractEndDate = bpoInputParameters.engineEndDate

    val patDf = temp_bpo_patients_DS
      .select(
        $"groupid",
        $"grp_mpi"
      ).distinct()

    val joinedDf_CUS = proceduredo_DS.as("a")
      .where(to_date($"a.proceduredate").between(lit(extractStartDate), lit(extractEndDate))
        && ($"a.grp_mpi".isNotNull)
      )
      .join(patDf.as("pat"),
        ($"a.groupid" === $"pat.groupid")
          && ($"a.grp_mpi" === $"pat.grp_mpi")
      )
      .join(ref_custom_proc_mapped_values_DS.as("ref"),
        ($"a.mappedcode" === $"ref.mappedvalue")
          && ($"a.codetype" === "CUSTOM")
          && ($"ref.preferred_proc_cd".isNotNull)
      )
      .join(pp_bpo_provider_detail_DS.as("p"),
        ($"a.performing_mstrprovid".cast(StringType) === $"p.providerid")
        , "left_outer"
      )
      .join(clinicalencounter_DS.as("ce"),
        ($"a.groupid" === $"ce.groupid")
          && ($"a.encounterid" === $"ce.encounterid")
          && ($"a.client_ds_id" === $"ce.client_ds_id")
          && ($"a.grp_mpi" === $"ce.grp_mpi"), "left_outer"
      )
      .join(map_patient_type_DS.as("mp"),
        ($"ce.groupid" === $"mp.groupid")
          && ($"ce.localpatienttype" === $"mp.local_code"), "left_outer"
      )
      .join(zo_place_of_service_DS.as("pos"),
        $"mp.cui" === $"pos.hts_cui", "left_outer"
      )
      .select(
        $"a.groupid",
        $"a.grp_mpi".as("memberid"),
        to_date($"a.proceduredate").as("paymentdate"),
        to_date($"a.proceduredate").as("servicedate"),
        to_date($"a.proceduredate").as("fromdate"),
        to_date($"a.proceduredate").as("todate"),
        coalesce($"a.performing_mstrprovid", lit("0")).cast(StringType).as("serviceproviderid"),
        coalesce($"ref.preferred_proc_spec", $"p.specialty", lit("999")).as("specialty"),
        coalesce($"ref.preferred_proc_spec", $"p.specialty", lit("999")).as("providertype"),
        coalesce($"ref.preferred_proc_pos", $"pos.ii_code", lit("99")).as("placeofservice"),
        when($"ref.preferred_proc_codetype" === lit("REV"), $"ref.preferred_proc_cd").otherwise(null).as("revenuecode"),
        when($"ref.preferred_proc_codetype".isin("CPT4", "HCPCS"), $"ref.preferred_proc_cd").otherwise(null).as("procedurecode"),
        lit(null).cast(StringType).as("proceduremodifier"),
        lit(null).cast(StringType).as("proc_code_modifier2"),
        lit(null).cast(StringType).as("proc_code_modifier3"),
        lit(null).cast(StringType).as("proc_code_modifier4"),
        lit(null).cast(StringType).as("tos"),
        lit("10").as("icdcodetype"),
        when($"ref.preferred_proc_codetype" === lit("ICD10"), $"ref.preferred_proc_cd").otherwise(null).as("icdproc1"),
        lit(null).cast(StringType).as("icdproc2"),
        lit(null).cast(StringType).as("icdproc3"),
        lit(null).cast(StringType).as("icdproc4"),
        lit(null).cast(StringType).as("icdproc5"),
        lit(null).cast(StringType).as("icdproc6"),
        lit(null).cast(StringType).as("icd_proc_7"),
        lit(null).cast(StringType).as("icd_proc_8"),
        lit(null).cast(StringType).as("icd_proc_9"),
        lit(null).cast(StringType).as("icd_proc_10"),
        lit(null).cast(StringType).as("icd_proc_11"),
        lit(null).cast(StringType).as("icd_proc_12"),
        lit(null).cast(StringType).as("icd_proc_13"),
        lit(null).cast(StringType).as("icd_proc_14"),
        lit(null).cast(StringType).as("icd_proc_15"),
        lit(null).cast(StringType).as("icd_proc_16"),
        lit(null).cast(StringType).as("icd_proc_17"),
        lit(null).cast(StringType).as("icd_proc_18"),
        lit(null).cast(StringType).as("icd_proc_19"),
        lit(null).cast(StringType).as("icd_proc_20"),
        lit(null).cast(StringType).as("icd_proc_21"),
        lit(null).cast(StringType).as("icd_proc_22"),
        lit(null).cast(StringType).as("icd_proc_23"),
        lit(null).cast(StringType).as("icd_proc_24"),
        lit(null).cast(StringType).as("icd_proc_25"),
        lit(null).cast(StringType).as("icddiag1"),
        lit(null).cast(StringType).as("icddiag2"),
        lit(null).cast(StringType).as("icddiag3"),
        lit(null).cast(StringType).as("icddiag4"),
        lit(null).cast(StringType).as("icddiag5"),
        lit(null).cast(StringType).as("icddiag6"),
        lit(null).cast(StringType).as("icddiag7"),
        lit(null).cast(StringType).as("icddiag8"),
        lit(null).cast(StringType).as("icddiag9"),
        lit(null).cast(StringType).as("icddiag10"),
        lit(null).cast(StringType).as("icd_diag_11"),
        lit(null).cast(StringType).as("icd_diag_12"),
        lit(null).cast(StringType).as("icd_diag_13"),
        lit(null).cast(StringType).as("icd_diag_14"),
        lit(null).cast(StringType).as("icd_diag_15"),
        lit(null).cast(StringType).as("icd_diag_16"),
        lit(null).cast(StringType).as("icd_diag_17"),
        lit(null).cast(StringType).as("icd_diag_18"),
        lit(null).cast(StringType).as("icd_diag_19"),
        lit(null).cast(StringType).as("icd_diag_20"),
        lit(null).cast(StringType).as("icd_diag_21"),
        lit(null).cast(StringType).as("icd_diag_22"),
        lit(null).cast(StringType).as("icd_diag_23"),
        lit(null).cast(StringType).as("icd_diag_24"),
        lit(null).cast(StringType).as("icd_diag_25"),
        lit(null).cast(StringType).as("drg"),
        lit(null).cast(StringType).as("drggrouper"),
        lit("U").as("poa"),
        lit("U").as("poa_2"),
        lit("U").as("poa_3"),
        lit("U").as("poa_4"),
        lit("U").as("poa_5"),
        lit("U").as("poa_6"),
        lit("U").as("poa_7"),
        lit("U").as("poa_8"),
        lit("U").as("poa_9"),
        lit("U").as("poa_10"),
        lit("U").as("poa_11"),
        lit("U").as("poa_12"),
        lit("U").as("poa_13"),
        lit(null).cast(StringType).as("dischargestatus"),
        lit(1).as("quantity"),
        lit(null).as("allowedamount"),
        lit(null).as("requestedamount"),
        lit(null).as("paidamount"),
        lit("MED").as("coverageclasscode"),
        lit("PROVIDER").as("healthplansource"),
        lit("1").as("claimline"),
        lit("Y").as("networkstatus"),
        lit("SS").as("mapsource"),
        lit(null).cast(StringType).as("employeraccountid"),
        lit(null).cast(StringType).as("contract_id"),
        lit(null).cast(StringType).as("provider_status"),
        lit(null).cast(StringType).as("network_paid_status"),
        lit(null).as("ffsamount"),
        lit(null).as("copayamount"),
        lit(null).as("coinsamount"),
        lit(null).as("deductamount"),
        lit(null).as("patliabamount"),
        lit(null).as("cobamount"),
        lit(null).as("withamount"),
        lit(null).as("capamount"),
        lit(null).cast(StringType).as("capsvcflag"),
        lit("N").as("deniedflag"),
        lit("N").as("pseudoflag"),
        $"a.client_ds_id",
        coalesce($"a.performing_mstrprovid", lit("0")).cast(StringType).as("provider_key"),
        lit(null).cast(StringType).as("claimid"),
        lit(null).cast(StringType).as("type_of_service"),
        lit(null).as("amt_oth1"),
        lit(null).as("amt_oth2"),
        lit(null).as("amt_oth3"),
        lit(null).as("amt_oth4"),
        lit(null).cast(StringType).as("billingproviderid"),
        lit(null).cast(StringType).as("orderingproviderid"),
        lit(null).cast(StringType).as("typeofbill"),
        lit(null).cast(StringType).as("spec_rx_ind"),
        lit(null).as("not_covered_amt"),
        lit(null).as("other_carrier_pay_amt"),
        lit(null).as("admin_fee_amt"),
        lit("N").as("denied_ind"),
        lit(null).cast(StringType).as("claim_prov_affil_id"),
        lit(null).cast(StringType).as("drgoutlier"),
        lit(null).cast(StringType).as("drgseverity"),
        lit(null).cast(StringType).as("admitsource"),
        lit(null).cast(StringType).as("cust_med_attr1"),
        lit(null).cast(StringType).as("cust_med_attr2"),
        lit(null).cast(StringType).as("cust_med_attr3"),
        lit(null).cast(StringType).as("cust_med_attr4"),
        lit(null).cast(StringType).as("cust_med_attr5"),
        lit(null).cast(StringType).as("cust_med_attr6"),
        lit(null).cast(StringType).as("cust_med_attr7"),
        lit(null).cast(StringType).as("cust_med_attr8"),
        lit(null).cast(StringType).as("cust_med_attr9"),
        lit(null).cast(StringType).as("cust_med_attr10"),
        lit(null).cast(StringType).as("cust_med_attr11"),
        lit(null).cast(StringType).as("cust_med_attr12"),
        lit(null).cast(StringType).as("cust_med_attr13"),
        lit(null).cast(StringType).as("cust_med_attr14"),
        lit(null).cast(StringType).as("cust_med_attr15"),
        lit(null).as("cust_med_attr16"),
        lit(null).as("cust_med_attr17"),
        lit(null).as("cust_med_attr18"),
        lit(null).as("cust_med_attr19"),
        lit(null).as("cust_med_attr20"),
        lit(null).cast(StringType).as("refer_prov_id"),
        lit(null).cast(StringType).as("inp_admit_type"),
        lit(null).cast(StringType).as("attend_prov_id"),
        lit(null).cast(StringType).as("claimsource"),
        lit(null).cast(IntegerType).as("covered_days"),
        lit(null).cast(StringType).as("cpt2_code"),
        lit(null).cast(StringType).as("deniedreason"),
        lit(null).cast(StringType).as("hcpcs_code")
    ).distinct()

    // convert to RDD , append rownumber column and change it back to dataframe
    val newSchema_CUS = StructType(joinedDf_CUS.schema.fields ++ Array(StructField("rownumber", LongType, nullable = false)))
    val rddWithId_CUS = joinedDf_CUS.rdd.zipWithIndex
    val withRowNumberDf_CUS = sparkSession.createDataFrame(rddWithId_CUS.map { case (row, index) => Row.fromSeq(row.toSeq ++ Array(index + 1)) }, newSchema_CUS)

    val joinedDf3_CUS = withRowNumberDf_CUS
      .withColumn("claimheader", concat(lit("CUS"), $"client_ds_id", lit("."), $"rownumber"))
      .drop("rownumber", "client_ds_id")

    joinedDf3.unionByName(joinedDf3_CUS)

  }
}