
package com.optum.oap.backend.etl.encgrps

import com.optum.oap.backend.cdrTempModel.temp_encounter_prindx
import com.optum.oap.cdr.models.{map_diagnosis, mapdiag_icd}
import com.optum.oap.sparkdataloader.{RuntimeVariables, TableInfo, UserDefinedFunctionForDataLoader}
import org.apache.spark.sql.types.IntegerType
import org.apache.spark.sql.{DataFrame, SparkSession}

object MAPDIAG_ICD extends TableInfo[mapdiag_icd] {

  override def dependsOn: Set[String] = Set("TEMP_ENCOUNTER_PRINDX", "MAP_DIAGNOSIS")

  override def partitions: Int = 32

  override protected def createDataFrame(sparkSession: SparkSession,
                                         loadedDependencies: Map[String, DataFrame],
                                         udfMap: Map[String, UserDefinedFunctionForDataLoader],
                                         runtimeVariables: RuntimeVariables): DataFrame = {

    import sparkSession.implicits._
    import org.apache.spark.sql.functions._

    val tempEncounterPrinDX = loadedDependencies("TEMP_ENCOUNTER_PRINDX").as[temp_encounter_prindx]
    val mapDiagICD = loadedDependencies("MAP_DIAGNOSIS").as[map_diagnosis]

    val groupedEncounterPrinDX = tempEncounterPrinDX
      .groupBy($"codetype", $"mappeddiagnosis")
      .agg(count($"*").cast(IntegerType).as("cnt"))

    val result = groupedEncounterPrinDX.as("dx").join(
      broadcast(mapDiagICD).as("md"), $"dx.codetype" === $"md.codetype" && $"dx.mappeddiagnosis" === $"md.mappedcode"
    ).select($"dx.codetype", $"dx.mappeddiagnosis", $"md.cui", $"md.is_ambulatory", $"dx.cnt")

    result
  }
}
