package com.optum.oap.backend.etl.enrichment


import com.optum.oap.backend.cdrTempModel.{temp_icpm_patient_patientdetail_patientcontact}
import com.optum.oap.backend.etl.common.SafeToDateLength.safeToDateLength
import com.optum.oap.cdr.models.{int_claim_labresult, int_claim_member, int_claim_pharm}
import com.optum.oap.sparkdataloader.{RuntimeVariables, TableInfo, UserDefinedFunctionForDataLoader}
import org.apache.spark.sql.types.{StringType, TimestampType}
import org.apache.spark.sql.expressions.Window
import org.apache.spark.sql.functions._
import org.apache.spark.sql.{DataFrame, SparkSession}
import org.slf4j.LoggerFactory

object ICPM_PATIENT_INTERMEDIATE
  extends TableInfo[temp_icpm_patient_patientdetail_patientcontact] {

  private val log = LoggerFactory.getLogger(this.getClass)

  override def dependsOn = Set("INT_CLAIM_MEMBER", "INT_CLAIM_MEDICAL", "INT_CLAIM_PHARM", "INT_CLAIM_LABRESULT")

  override def name = "ICPM_PATIENT_INTERMEDIATE"

  override def partitions: Int = 32

  override def createDataFrame(sparkSession: SparkSession,
                               loadedDependencies: Map[String, DataFrame],
                               udfMap: Map[String, UserDefinedFunctionForDataLoader],
                               runtimeVariables: RuntimeVariables): DataFrame = {

    import sparkSession.implicits._

    val cdrFeIntClaimMember = loadedDependencies("INT_CLAIM_MEMBER").as[int_claim_member]

    val cdrFeIntClaimMedical = loadedDependencies("INT_CLAIM_MEDICAL")

    val cdrFeIntClaimPharm = loadedDependencies("INT_CLAIM_PHARM").as[int_claim_pharm]

    val cdrFeIntClaimLabresult = loadedDependencies("INT_CLAIM_LABRESULT").as[int_claim_labresult]


    val recordsFromIntClaimMember = cdrFeIntClaimMember
      .select(
        $"groupid"
        ,lit("int_claim_member").as("datasrc")
        ,$"client_ds_id"
        ,$"alternate_member_id".as("medicalrecordnumber")
        ,$"member_id".as("patientid")
        ,$"member_dob".as("dateofbirth")
        ,$"member_dod".as("dateofdeath")
        ,when(upper($"member_death_ind") === "Y ", "Y" )
          .when($"member_dod".isNotNull, "Y")
          .otherwise($"member_death_ind").as("deceased")
        ,$"member_ethnicity".as("ethnicity")
        ,$"member_language".as("language")
        ,$"member_marital_status".as("marital_status")
        ,$"member_race".as("race")
        ,$"member_fname".as("firstname")
        ,$"member_gender_code".as("gender")
        ,$"member_lname".as("lastname")
        ,$"member_mname".as("middlename")
        ,$"member_phone".as("home_phone")
        ,$"member_email".as("personal_email")
        ,$"member_state_code".as("state")
        , when(regexp_replace($"member_zip_code","-","").like("%0000"),
          regexp_replace($"member_zip_code","-","" ).substr(1,5)
        ).otherwise(regexp_replace($"member_zip_code","-","" ))
          .as("zipcode")
        ,$"member_city".as("city")
        , lit(null).cast(TimestampType).as("member_eff_date")
        ,$"member_end_date"
        , coalesce($"member_eff_date",
          safeToDateLength($"eligibile_member_month", lit("yyyyMM"),lit(0))
        ).as("lastupdateddate"),
        lit(1).as("source")
      )

    val recordsFromIntClaimMedical = cdrFeIntClaimMedical
      .select(
        $"groupid"
        ,lit("int_claim_medical").as("datasrc")
        ,$"client_ds_id"
        ,lit(null).cast(StringType).as("medicalrecordnumber")
        ,$"member_id".as("patientid")
        ,$"member_dob".as("dateofbirth")
        ,lit(null).cast(TimestampType).as("dateofdeath")
        ,lit(null).cast(StringType).as("deceased")
        ,lit(null).cast(StringType) .as("ethnicity")
        ,lit(null).cast(StringType).as("language")
        ,lit(null).cast(StringType).as("marital_status")
        ,lit(null).cast(StringType).as("race")
        ,$"member_fname".as("firstname")
        ,$"member_gender_code".as("gender")
        ,$"member_lname".as("lastname")
        ,$"member_mname".as("middlename")
        ,lit(null).cast(StringType).as("home_phone")
        ,lit(null).cast(StringType).as("personal_email")
        ,lit(null).cast(StringType).as("state")
        ,lit(null).cast(StringType).as("zipcode")
        ,lit(null).cast(StringType).as("city")
        ,lit(null).cast(TimestampType).as("member_eff_date")
        ,lit(null).cast(TimestampType).as("member_end_date")
        ,coalesce($"member_eff_date", $"service_Date").as("lastupdateddate")
        ,lit(2).as("source")
      )

    val recordsFromIntClaimPharm = cdrFeIntClaimPharm
      .select(
        $"groupid"
        ,lit("int_claim_pharm").as("datasrc")
        ,$"client_ds_id"
        ,lit(null).cast(StringType).as("medicalrecordnumber")
        ,$"member_id".as("patientid")
        ,$"member_dob".as("dateofbirth")
        ,lit(null).cast(TimestampType).as("dateofdeath")
        ,lit(null).cast(StringType).as("deceased")
        ,lit(null).cast(StringType).as("ethnicity")
        ,lit(null).cast(StringType).as("language")
        ,lit(null).cast(StringType).as("marital_status")
        ,lit(null).cast(StringType).as("race")
        ,$"member_fname".as("firstname")
        ,$"member_gender_code".as("gender")
        ,$"member_lname".as("lastname")
        ,$"member_mname".as("middlename")
        ,lit(null).cast(StringType).as("home_phone")
        ,lit(null).cast(StringType).as("personal_email")
        ,lit(null).cast(StringType).as("state")
        ,lit(null).cast(StringType).as("zipcode")
        ,lit(null).cast(StringType).as("city")
        ,lit(null).cast(TimestampType).as("member_eff_date")
        ,lit(null).cast(TimestampType).as("member_end_date")
        ,coalesce($"member_eff_date", $"service_Date").as("lastupdateddate"),
        lit(3).as("source")
      )

    val recordsFromIntClaimLabresult = cdrFeIntClaimLabresult
      .select(
        $"groupid"
        ,lit("int_claim_labresult").as("datasrc")
        ,$"client_ds_id"
        ,lit(null).cast(StringType).as("medicalrecordnumber")
        ,$"member_id".as("patientid")
        ,$"member_dob".as("dateofbirth")
        ,lit(null).cast(TimestampType).as("dateofdeath")
        ,lit(null).cast(StringType).as("deceased")
        ,lit(null).cast(StringType).as("ethnicity")
        ,lit(null).cast(StringType).as("language")
        ,lit(null).cast(StringType).as("marital_status")
        ,lit(null).cast(StringType).as("race")
        ,$"member_fname".as("firstname")
        ,$"member_gender_code".as("gender")
        ,$"member_lname".as("lastname")
        ,$"member_mname".as("middlename")
        ,lit(null).cast(StringType).as("home_phone")
        ,lit(null).cast(StringType).as("personal_email")
        ,lit(null).cast(StringType).as("state")
        ,lit(null).cast(StringType).as("zipcode")
        ,lit(null).cast(StringType).as("city")
        ,lit(null).cast(TimestampType).as("member_eff_date")
        ,lit(null).cast(TimestampType).as("member_end_date")
        ,coalesce($"member_eff_date", $"result_date", $"order_date").as("lastupdateddate")
        ,lit(4).as("source")
      )

    recordsFromIntClaimMember.unionByName(recordsFromIntClaimMedical)
      .unionByName(recordsFromIntClaimPharm)
      .unionByName(recordsFromIntClaimLabresult)
      .withColumn("dob", first($"dateofbirth", true)
        .over(Window.partitionBy($"client_ds_id", $"patientid")
          .orderBy($"source".asc_nulls_last
            ,when($"dateofbirth".isNotNull, 1).otherwise(0)
            ,$"lastupdateddate".desc_nulls_last, $"dateofbirth"))
      )
      .withColumn("dod", last(when($"source" === lit(1), $"dateofdeath"), true)
        .over(Window.partitionBy($"client_ds_id", $"patientid")
          .orderBy($"lastupdateddate".desc_nulls_last, $"member_end_date".desc_nulls_first, $"dateofdeath".desc_nulls_last))
      )
      .withColumn("rank_pat", row_number()
        .over(Window.partitionBy($"client_ds_id", $"patientid")
          .orderBy($"source".asc_nulls_last, $"lastupdateddate".desc_nulls_last))
      )
      .withColumn("firstname_row", row_number()
        .over(Window.partitionBy($"client_ds_id", $"patientid", upper($"firstname"))
          .orderBy($"source".asc_nulls_last, $"lastupdateddate".desc_nulls_last, $"firstname".desc_nulls_last))
      )
      .withColumn("lastname_row", row_number()
        .over(Window.partitionBy($"client_ds_id", $"patientid", upper($"lastname"))
          .orderBy($"source".asc_nulls_last, $"lastupdateddate".desc_nulls_last, $"lastname".desc_nulls_last))
      )
      .withColumn("middle_row", row_number()
        .over(Window.partitionBy($"client_ds_id", $"patientid", upper($"middlename"))
          .orderBy($"source".asc_nulls_last, $"lastupdateddate".desc_nulls_last, $"middlename".desc_nulls_last))
      )
      .withColumn("gender_row", row_number()
        .over(Window.partitionBy($"client_ds_id", $"patientid", upper($"gender"))
          .orderBy($"source".asc_nulls_last, $"lastupdateddate".desc_nulls_last, $"gender".desc_nulls_last))
      )
      .withColumn("language_row", row_number()
        .over(Window.partitionBy($"client_ds_id", $"patientid", upper($"language"))
          .orderBy($"source".asc_nulls_last, $"lastupdateddate".desc_nulls_last, $"language".desc_nulls_last))
      )
      .withColumn("ethnic_row", row_number()
        .over(Window.partitionBy($"client_ds_id", $"patientid", upper($"ethnicity"))
          .orderBy($"source".asc_nulls_last, $"lastupdateddate".desc_nulls_last, $"ethnicity".desc_nulls_last))
      )
      .withColumn("race_row", row_number()
        .over(Window.partitionBy($"client_ds_id", $"patientid", upper($"race"))
          .orderBy($"source".asc_nulls_last, $"lastupdateddate".desc_nulls_last, $"race".desc_nulls_last))
      )
      .withColumn("marital_row", row_number()
        .over(Window.partitionBy($"client_ds_id", $"patientid", upper($"marital_status"))
          .orderBy($"source".asc_nulls_last, $"lastupdateddate".desc_nulls_last, $"marital_status".desc_nulls_last))
      )
      .withColumn("death_row", row_number()
        .over(Window.partitionBy($"client_ds_id", $"patientid", upper($"deceased"))
          .orderBy($"lastupdateddate".desc_nulls_last, $"member_end_date".desc_nulls_first, $"dateofdeath".desc_nulls_last))
      )
      .withColumn("city_row", row_number()
        .over(Window.partitionBy($"client_ds_id", $"patientid", upper($"city"))
          .orderBy($"source".asc_nulls_last, $"lastupdateddate".desc_nulls_last, $"city".desc_nulls_last))
      )
      .withColumn("state_row", row_number()
        .over(Window.partitionBy($"client_ds_id", $"patientid", upper($"state"))
          .orderBy($"source".asc_nulls_last, $"lastupdateddate".desc_nulls_last, $"state".desc_nulls_last))
      )
      .withColumn("zipcode_row", row_number()
        .over(Window.partitionBy($"client_ds_id", $"patientid", $"zipcode")
          .orderBy($"source".asc_nulls_last, $"lastupdateddate".desc_nulls_last, $"zipcode".desc_nulls_last))
      )
      .withColumn("rank_con", row_number()
        .over(Window.partitionBy($"client_ds_id", $"patientid", $"home_phone", $"personal_email")
          .orderBy($"source".asc_nulls_last, $"lastupdateddate".desc_nulls_last, $"home_phone".desc_nulls_last, $"personal_email".desc_nulls_last))
      )
  }

}
