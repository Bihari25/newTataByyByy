
package com.optum.oap.backend.etl.encgrps

import com.optum.oap.backend.etl.common.{TimestampAddDays, TimestampTruncate}
import com.optum.oap.cdr.models.encounter_grp
import com.optum.oap.sparkdataloader.{QueryAndMetadata, RuntimeVariables, TableInfo, UserDefinedFunctionForDataLoader}
import org.apache.spark.sql.{DataFrame, SparkSession}
import org.apache.spark.sql.functions._
import org.apache.spark.sql.types.{DoubleType, IntegerType, LongType, StringType}

object ENCOUNTER_GRP extends TableInfo[encounter_grp] {
  override def name: String = "ENCOUNTER_GRP"

  override def partitions: Int = 1024

  override def dependsOn: Set[String] = Set("ENCOUNTER_ENCOUNTER_GRP", "TEMP_VISIT_ENCTR", "TEMP_ENCOUNTER_SORT", "TEMP_ENCOUNTER_GRP_PDX", "TEMP_ENCOUNTER_GRP_PPX", "TEMP_ENCOUNTER_GRP_LOC",
    "TEMP_ENCOUNTER_GRP_CHG", "TEMP_ENC_GRP_PYR", "TEMP_ENCOUNTER_ZIP", "TEMP_VISIT", "TEMP_ENCOUNTER_GRP_CCS", "TEMP_ENCOUNTER_PRINPX", "REF_MAP_CCS_ICDX_PX", "TEMP_ENCOUNTER_GRP_CON",
    "MAP_ADMIT_SOURCE", "MAP_DISCHARGE_DISPOSITION", "TEMP_ENCOUNTER_GRP_PRV", "REF_VW_REF_DRG_REFERENCE", "ZH_FACILITY_ROLLUP", "TEMP_CMSINCLUDE", "TEMP_ENC_GRP_EPRV")

  override protected def createDataFrame(sparkSession: SparkSession, loadedDependencies: Map[String, DataFrame],
                                         udfMap: Map[String, UserDefinedFunctionForDataLoader], runtimeVariables: RuntimeVariables): DataFrame = {

    import sparkSession.implicits._

    val encounterEncounterGrp = loadedDependencies("ENCOUNTER_ENCOUNTER_GRP").repartition($"ENCOUNTER_GRP_NUM")
    val tempVisitEnctr = loadedDependencies("TEMP_VISIT_ENCTR")
    val tempEncounterSort = loadedDependencies("TEMP_ENCOUNTER_SORT")
    val tempEncounterGrpPdx = loadedDependencies("TEMP_ENCOUNTER_GRP_PDX")
    val tempEncounterGrpPpx = broadcast(loadedDependencies("TEMP_ENCOUNTER_GRP_PPX"))
    val tempEncounterGrpLoc = loadedDependencies("TEMP_ENCOUNTER_GRP_LOC")
    val tempEncounterGrpChg = loadedDependencies("TEMP_ENCOUNTER_GRP_CHG")
    val tempEncGrpPry = loadedDependencies("TEMP_ENC_GRP_PYR")
    val tempEncounterZip = loadedDependencies("TEMP_ENCOUNTER_ZIP")
    val tempVisit = loadedDependencies("TEMP_VISIT")
    val tempEncounterGrpCcs = loadedDependencies("TEMP_ENCOUNTER_GRP_CCS")
    val tempEncounterPrinPx = loadedDependencies("TEMP_ENCOUNTER_PRINPX")
    val refMapCCsICDXPx = broadcast(loadedDependencies("REF_MAP_CCS_ICDX_PX"))
    val tempEncounterGrpCon = loadedDependencies("TEMP_ENCOUNTER_GRP_CON")
    val mapAdmitSource = broadcast(loadedDependencies("MAP_ADMIT_SOURCE"))
    val mapDischargeDisposition = broadcast(loadedDependencies("MAP_DISCHARGE_DISPOSITION"))
    val tempEncounterGrpPrv = loadedDependencies("TEMP_ENCOUNTER_GRP_PRV")
    val refVwRefDrgReference = broadcast(loadedDependencies("REF_VW_REF_DRG_REFERENCE"))
    val zhFacilityRollup = broadcast(loadedDependencies("ZH_FACILITY_ROLLUP"))
    val tempCMSInclude = broadcast(loadedDependencies("TEMP_CMSINCLUDE"))
    val tempEncGrpEprv = loadedDependencies("TEMP_ENC_GRP_EPRV")

    val groupedGrpCcs = tempEncounterGrpCcs
      .withColumn("ccs_cat", trim($"ccs_cat")) // only trim once per row
      .groupBy($"ENCOUNTER_GRP_NUM")
      .agg(
        max(when($"ccs_cat" === "254", 1).otherwise(0)).as("ccs254"),
        max(when($"ccs_cat" === "254" and $"primarydiagnosis" === 1, 1).otherwise(0)).as("ccs254p"),
        max(when($"ccs_cat" === "43", 1).otherwise(0)).as("ccs43"),
        max(when($"ccs_cat".isin("14","16","17","19","22","24","26","27","31","41","42"), 1).otherwise(0)).as("ccsmort"),
        max(when($"ccs_cat".isin("14","16","17","19","22","24","26","27","31","41","42") and $"primarydiagnosis" === 1, 1).otherwise(0)).as("ccsmortp"),
        max(when($"ccs_cat".isin("45","194","196","254") and $"primarydiagnosis" === 1, 1).otherwise(0)).as("ccs_apdx")
      )

    val groupedPrinPx = tempEncounterPrinPx
      .withColumn("mappedcode", trim($"mappedcode"))
      .as("px")
      .join(
        refMapCCsICDXPx
          .select(
            trim($"ccs_category").as("ccs_category"),
            trim($"icd_cm_code").as("icd_cm_code"),
            $"icd_version"
          )
          .as("cd"),
        $"px.mappedcode" === $"cd.icd_cm_code" and $"px.icd_ver" === $"cd.icd_version"
      )
      .groupBy($"ENCOUNTER_GRP_NUM")
      .agg(
        max(when($"ccs_category".isin("64", "105", "134", "135", "176"), 1).otherwise(0)).as("ccs_appx")
      )

    encounterEncounterGrp.as("eeg")
      .join(tempVisitEnctr.as("ce"), $"ce.groupid" === $"eeg.groupid" and $"ce.encounterid" === $"eeg.encounterid" and $"ce.client_ds_id" === $"eeg.client_ds_id")
      .join(tempEncounterSort.as("es"), $"eeg.ENCOUNTER_GRP_NUM" === $"es.ENCOUNTER_GRP_NUM" and $"ce.encounterid" === $"es.encounterid" and $"ce.client_ds_id" === $"es.client_ds_id")
      .join(tempEncounterGrpPdx.as("prdx"), $"eeg.ENCOUNTER_GRP_NUM" === $"prdx.ENCOUNTER_GRP_NUM", "left_outer")
      .join(tempEncounterGrpPpx.as("prpx"), $"eeg.ENCOUNTER_GRP_NUM" === $"prpx.ENCOUNTER_GRP_NUM", "left_outer")
      .join(tempEncounterGrpLoc.as("loc"), $"eeg.ENCOUNTER_GRP_NUM" === $"loc.ENCOUNTER_GRP_NUM", "left_outer")
      .join(tempEncounterGrpChg.as("chg"), $"eeg.ENCOUNTER_GRP_NUM" === $"chg.ENCOUNTER_GRP_NUM", "left_outer")
      .join(tempEncGrpPry.as("pyr"), $"eeg.ENCOUNTER_GRP_NUM" === $"pyr.ENCOUNTER_GRP_NUM", "left_outer")
      .join(tempEncounterZip.as("zip"), $"eeg.ENCOUNTER_GRP_NUM" === $"zip.ENCOUNTER_GRP_NUM", "left_outer")
      .join(tempVisit.as("cip"), $"eeg.grp_mpi" === $"cip.grp_mpi" and TimestampTruncate.truncate(lit("DAY"), $"ce.dischargetime").between(TimestampAddDays.timestampAddDays($"cip.admitip", lit(-1)), $"cip.dischip"), "left_outer") // TODO: between is BAD
      .join(groupedGrpCcs.as("ccs"), $"eeg.ENCOUNTER_GRP_NUM" === $"ccs.ENCOUNTER_GRP_NUM", "left_outer")
      .join(groupedPrinPx.as("pxccs"), $"eeg.ENCOUNTER_GRP_NUM" === $"pxccs.ENCOUNTER_GRP_NUM", "left_outer")
      .join(tempEncounterGrpCon.as("cond"), $"eeg.ENCOUNTER_GRP_NUM" === $"cond.ENCOUNTER_GRP_NUM", "left_outer")
      .join(mapAdmitSource.as("mas"), $"ce.groupid" === $"mas.groupid" and $"ce.localadmitsource" === $"mas.localcode", "left_outer")
      .join(mapDischargeDisposition.as("mdd"), $"ce.groupid" === $"mdd.groupid" and $"ce.localdischargedisposition" === $"mdd.mnemonic", "left_outer")
      .join(tempEncounterGrpPrv.as("prov"), $"eeg.ENCOUNTER_GRP_NUM" === $"prov.ENCOUNTER_GRP_NUM", "left_outer")
      .join(refVwRefDrgReference.as("drg"), $"ce.drg" === $"drg.drg" and $"ce.drgtypecui" === $"drg.drg_type_cui", "left_outer")
      .join(zhFacilityRollup.as("zfr"), $"ce.groupid" === $"zfr.groupid" and $"ce.facilityid" === $"zfr.facility_id" and $"ce.client_ds_id" === $"zfr.client_ds_id", "left_outer")
      .join(tempCMSInclude.as("cmsi2"), $"eeg.groupid" === $"cmsi2.groupid" and $"eeg.grp_mpi" === $"cmsi2.grp_mpi" and $"eeg.encounter_grp_num" === $"cmsi2.encounter_grp_num", "left_outer")
      .join(tempCMSInclude.as("cmsi"),
        $"eeg.groupid" === $"cmsi.groupid" and $"eeg.grp_mpi" === $"cmsi.grp_mpi" and $"cmsi.arrivaltime" > $"cmsi2.arrivaltime" and to_date($"cmsi.arrivaltime").between(to_date($"cmsi2.dischargetime"), date_add(to_date($"cmsi2.dischargetime"), 1)) // TODO: between is bad
        , "left_outer")
      .join(tempCMSInclude.as("cmsi3"),
        $"eeg.groupid" === $"cmsi3.groupid" and $"eeg.grp_mpi" === $"cmsi3.grp_mpi" and $"cmsi3.arrivaltime" < $"cmsi2.arrivaltime" and to_date($"cmsi3.dischargetime").between(date_sub(to_date($"cmsi2.arrivaltime"), 1), to_date($"cmsi2.arrivaltime")) // TODO: between is bad
        , "left_outer")
      .join(tempEncGrpEprv.as("egp"), $"eeg.groupid" === $"egp.groupid" and $"eeg.ENCOUNTER_GRP_NUM" === $"egp.ENCOUNTER_GRP_NUM", "left_outer")
      .groupBy($"eeg.groupid", $"eeg.ENCOUNTER_GRP_NUM", $"eeg.grp_mpi")
      .agg(
        max(
          when(
            $"facrank" === 1 and $"encounteridtype".isin("MASTER", "ENCTR") and
              (
                ($"zfr.master_facility_id".isNotNull and $"ce.patienttype".isin("CH000106","CH000107","CH000109","CH000113","CH000795","CH003031","CH003032")) or
                ($"ce.FACILITYID".isNotNull and not($"ce.patienttype".isin("CH000106","CH000107","CH000109","CH000113","CH000795","CH003031","CH003032")))
              ), $"ce.facilityid"
          ).otherwise(null)
        ).as("facilityid"),
        max(
          when(
            $"facrank" === 1 and $"encounteridtype".isin("MASTER", "ENCTR") and
              (
                ($"zfr.master_facility_id".isNotNull and $"ce.patienttype".isin("CH000106","CH000107","CH000109","CH000113","CH000795","CH003031","CH003032")) or
                  ($"ce.FACILITYID".isNotNull and not($"ce.patienttype".isin("CH000106","CH000107","CH000109","CH000113","CH000795","CH003031","CH003032")))
                ), $"ce.client_ds_id"
          ).otherwise(null)
        ).as("facility_ds_id"),
        max(coalesce($"prov.ADMITTINGPHYSICIAN",lit("CH999999"))).as("ADMITTINGPHYSICIAN"),
        max($"prov.ADMITTINGPHYS_ds_id").cast(LongType).as("ADMITTINGPHYS_ds_id"),
        max($"prov.ADMITTINGPHYS_mstr_id").cast(LongType).as("ADMITTINGPHYS_mstr_id"),
        max(coalesce($"prov.LASTATT",lit("CH999999"))).as("LASTATTPHYSICIAN"),
        max($"prov.LASTATTphys_ds_id").cast(LongType).as("LASTATTPHYS_ds_id"),
        max($"prov.LASTATTphys_mstr_id").cast(LongType).as("LASTATTPHYS_mstr_id"),
        max(when($"admitrank" === 1, coalesce($"ce.ADMITTIME",$"ce.arrivaltime")).otherwise(null)).as("ADMITTIME"),
        min(when($"arrivalrank" === 1, $"ce.ARRIVALTIME").otherwise(null)).as("ARRIVALTIME"),
        max(
          when(
            $"ENCOUNTERIDTYPE" === "MASTER" or ($"ENCOUNTERIDTYPE" === "ENCTR" and $"EXCL" === "N"), $"ce.dischargetime"
          ).otherwise(null)
        ).as("DISCHARGETIME"),
        max(when($"ENCOUNTERIDTYPE" === "MASTER", $"eeg.PATIENTTYPE").otherwise(null)).as("ENCOUNTER_GRP_TYPE"),
        max(when($"disprank" === 1, $"ce.LOCALDISCHARGEDISPOSITION").otherwise(null)).as("LOCALDISCHARGEDISPOSITION"),
        max(when($"admsrcrank" === 1, $"ce.LOCALADMITSOURCE").otherwise(null)).as("LOCALADMITSOURCE"),
        max($"loc.lastloc").as("LASTLOCATION"),
        max(when($"drgrank" === 1 and $"drg.drg".isNotNull, $"ce.DRG").otherwise(null)).as("DRG"),
        max(when($"drgrank" === 1 and $"drg.drg".isNotNull, $"ce.DRGTYPECUI").otherwise(null)).as("DRGTYPECUI"),
        max($"prdx.prindx").as("prindx"),
        max($"prpx.prinpx").as("prinpx"),
        round(max($"totchg"), 2).as("CHARGE"),
        max(when($"ENCOUNTERIDTYPE".isin("MASTER","ENCTR") and $"ce.wasplannedflg".isNotNull and $"ce.wasplannedflg".isin("Y","Yes","YES", "1", "Newborn","Elective","E"), "Y").otherwise("N")).as("CLIENTPLANNED"),
        max(
          when(
            coalesce($"pxccs.ccs_appx", lit(0)) === 1 or
            coalesce($"ccs.ccs_apdx", lit(0)) === 1 or
            coalesce($"ccs.ccs254", lit(0)) === 1 or
            (coalesce($"cond.cond1681", lit(0)) === 1 and coalesce($"cond.cond1662p", lit(0)) === 0) or
            $"cmsi3.disposition" === "CH000078" or
            ($"cmsi3.disposition" === "CH000081" and ($"cmsi2.prindx" like "F%" or $"cmsi2.prindx".substr(1, 2).isin("29","30","31"))),
            "Y"
          ).otherwise("N")
        ).as("CMSPLANNED"),
        min(
          when(
            not($"ENCOUNTERIDTYPE".isin("ADD ER", "ADD OB", "ADD SD")) and
            $"disprank" === 1 and $"mdd.cui".isin(
              "CH000061","CH000077","CH000078","CH000079","CH000081","CH000082", // disch to hosp
              "CH000070",  // cont as patient
              "CH000069","CH000071","CH000072","CH000073"
            ),
            "N"
          ).otherwise("Y")
        ).as("BASEINCLUDE"),
        min(
          when(
            (not($"ENCOUNTERIDTYPE".isin("ADD ER", "ADD OB", "ADD SD")) and $"disprank" === 1 and $"mdd.cui".isin("CH000061","CH000082","CH000071","CH000072","CH000073","CH000069","CH000066")) or
            coalesce($"cond.cond1679p", lit(0)) === 1 or
            coalesce($"ccs.ccs254", lit(0)) === 1 or
            (coalesce($"cond.cond1682", lit(0)) === 0 and coalesce($"cond.cond1676p", lit(0)) === 1) or
            (datediff(to_date($"cmsi.arrivaltime"), to_date($"cmsi2.dischargetime")) <= 1 and coalesce($"cmsi.master_facility_id", $"cmsi2.master_facility_id") =!= coalesce($"cmsi2.master_facility_id", $"cmsi.master_facility_id")) or
            (to_date($"cmsi.arrivaltime") === to_date($"cmsi2.dischargetime") and coalesce($"cmsi.master_facility_id", $"cmsi2.master_facility_id", lit("SAME")) === coalesce($"cmsi2.master_facility_id", $"cmsi.master_facility_id", lit("SAME")) and $"cmsi.prindx" === $"cmsi2.prindx") or
            datediff(to_date($"cmsi2.dischargetime"), to_date($"cmsi2.arrivaltime")) > 365,
            "N"
          ).otherwise("Y")
        ).as("CMSINCLUDE"),
        max(
          when(
            not($"ENCOUNTERIDTYPE".isin("ADD ER", "ADD OB", "ADD SD")) and $"disprank" === 1 and
            $"mdd.cui".isin(
              "CH000061", "CH000082", // disch to hosp, CMS discharge disp = 02, 66
              "CH000070", // cont as patient, CMS discharge disp = 30
              "CH000069", // expired, CMS discharge disp = 20
              "CH000066" // left ama, CMS discharge disp = 07
            ),
            1
          ).otherwise(0)
        ).cast(StringType).as("CMS_DDISP"),
        max(when(coalesce($"ccs.ccs254p", lit(0)) === 1, "Y").otherwise("N")).as("CMS_REHABP"),  // REHAB
        max(when(coalesce($"ccs.ccs254", lit(0)) === 1, "Y").otherwise("N")).as("CMS_REHAB"), // REHAB
        max(when(coalesce($"cond.cond1679P", lit(0)) === 1, 1).otherwise(0)).cast(StringType).as("CMS_PSYCH"),
        max(when(coalesce($"cond.cond1682", lit(0)) === 0 and coalesce($"cond.cond1676P", lit(0)) === 1, 1).otherwise(0)).cast(StringType).as("cms_non_surgcancer"),
        max(
          when(
            $"ENCOUNTERIDTYPE" === "MASTER" and $"ce.patienttype" =!= "CH000106" and $"cip.grp_mpi".isNotNull and
              (
                TimestampTruncate.truncate(lit("DAY"), $"ce.dischargetime") === $"admitip" or
                (
                  TimestampTruncate.truncate(lit("DAY"), $"ce.dischargetime") === TimestampAddDays.timestampAddDays($"admitip", lit(-1)) and
                  $"ce.arrivaltime" === $"ce.dischargetime" and $"ce.arrivaltime" =!= TimestampTruncate.truncate(lit("DAY"), $"ce.arrivaltime")
                )
              ),
            "Y"
          ).otherwise("N")
        ).as("CONVERT_IP"),
        max(when($"ce.patienttype" === "CH000109" or $"mas.cui" === "CH000614" or $"loc.HAS_ED_ECA" === 1, "Y").otherwise("N")).as("ADMITTED_ER"),
        min(coalesce($"loc.service", lit("CH999999"))).as("ENCOUNTERSERVICE"),
        min(coalesce($"pyr.finclass", lit("CH999999"))).as("finclass"),
        max(when($"aprdrgrank" === 1, $"ce.aprdrg_cd".substr(1, 6)).otherwise(null)).as("aprDRG"),
        max(when($"aprdrgrank" === 1, $"ce.aprdrg_soi").otherwise(null)).as("APRDRG_SEV"),
        max(when($"aprdrgrank" === 1, $"ce.aprdrg_rom").otherwise(null)).as("APRDRG_RISK"),
        max(
          when(trim($"zip.zipcode".substr(1, 5)).isNull, "CH999999")
          .when($"zip.zipcode".substr(1, 5) === "00000", "CH999990")
          .when(not($"zip.zipcode".substr(1, 5).between("00601", "99950")), "CH999990")
          .when(translate($"zip.zipcode".substr(1, 5), "O", "0").rlike("\\p{Space}*([0-9]{5}([- ]?[0-9]{4})?)\\p{Space}*"), trim(upper($"zip.zipcode".substr(1, 5))))
          .when(not(translate($"zip.zipcode".substr(1, 5), "O", "0").rlike("\\p{Space}*([0-9]{5}([- ]?[0-9]{4})?)\\p{Space}*")), "CH999990")
          .otherwise(regexp_replace(translate($"zip.zipcode".substr(1, 5), "O", "0"), "\\p{Space}*([0-9]{5})[- ]?[0-9]{4}\\p{Space}*", "\1"))
        ).as("MAPPEDZIPCODE"),
        max($"loc.servicecode").as("servicecode"),
        max($"plancode").as("insuranceplan"),
        max(coalesce($"LASTATTTEAM", lit("CH999999"))).as("LASTATTTEAM"),
        max($"lastattteam_ds_id").as("lastattteam_ds_id"),
        max($"LASTATTTEAM_MSTR_ID").cast(IntegerType).as("LASTATTTEAM_MSTR_ID"),
        max(when($"displayrank" === 1, coalesce($"ce.alt_encounterid", $"eeg.encounterid")).otherwise(null)).as("display_encounterid"),
        max(when($"displayrank" === 1, $"eeg.client_ds_id").otherwise(null)).as("display_ds_id"),
        max($"ce.elos").as("elos"),
        max(when($"drgrank" === 1 and $"drg.mdc".isNotNull, $"drg.mdc").otherwise(null)).as("mdc"),
        max($"prdx.codetype").as("PRINDX_CODETYPE"),
        max($"prpx.codetype").as("PRINPX_CODETYPE"),
        max($"event_prov_id").cast(StringType).as("event_prov_id")
      ).withColumn("cost", lit(null).cast(DoubleType)).withColumn("cost_charge_ratio", lit(null).cast(DoubleType)).withColumn("display_id_type", lit(null).cast(StringType))
  }
}
