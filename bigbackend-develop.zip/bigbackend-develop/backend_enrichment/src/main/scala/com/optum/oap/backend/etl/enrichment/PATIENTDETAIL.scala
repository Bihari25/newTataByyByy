package com.optum.oap.backend.etl.enrichment

import com.optum.oap.backend.etl.common.MapMasterIds
import com.optum.oap.cdr.models.{patient_mpi, patientdetail}
import com.optum.oap.sparkdataloader.{RuntimeVariables, TableInfo, UserDefinedFunctionForDataLoader}
import org.apache.spark.sql.{DataFrame, SparkSession}

object PATIENTDETAIL extends TableInfo[patientdetail] {

  override def dependsOn = Set("PATIENTDETAIL_PREMATCH", "PATIENT_MPI")

  override def name = "PATIENTDETAIL"

  override def createDataFrame(sparkSession: SparkSession,
                               loadedDependencies: Map[String, DataFrame],
                               udfMap: Map[String, UserDefinedFunctionForDataLoader],
                               runtimeVariables: RuntimeVariables): DataFrame = {
    import sparkSession.implicits._

    val patientDetailPrematchDf = loadedDependencies("PATIENTDETAIL_PREMATCH")
    val patXref = loadedDependencies("PATIENT_MPI").as[patient_mpi]

    MapMasterIds.mapPatientIds(patientDetailPrematchDf, patXref.toDF, false)

  }
}
