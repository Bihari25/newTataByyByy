package com.optum.oap.backend.etl.bpo.bpo_pyr_sre

import com.optum.oap.backend.cdrTempModel.monthly_payer_phc_sre
import com.optum.oap.cdr.models.{pp_bpo_member_detail, pp_bpo_pharmacy_clinical}
import com.optum.oap.sparkdataloader.{RuntimeVariables, TableInfo, UserDefinedFunctionForDataLoader}
import org.apache.spark.sql.functions.{date_format, lit}
import org.apache.spark.sql.types.StringType
import org.apache.spark.sql.{DataFrame, SparkSession}

object MONTHLY_PAYER_PHC_SRE_EXTRACT extends TableInfo[monthly_payer_phc_sre] {

  override def dependsOn = Set("PP_BPO_PHARMACY_CLINICAL", "PP_BPO_MEMBER_DETAIL")

  override def name = "MONTHLY_PAYER_PHC_SRE_EXTRACT"

  override def createDataFrame(sparkSession: SparkSession,
                               loadedDependencies: Map[String, DataFrame],
                               udfMap: Map[String, UserDefinedFunctionForDataLoader],
                               runtimeVariables: RuntimeVariables): DataFrame = {

    import sparkSession.implicits._

    val ppBpoMemberDetail = loadedDependencies("PP_BPO_MEMBER_DETAIL").where($"healthplansource" === "PAYER").as[pp_bpo_member_detail]
    val ppBpoPharmacyClinical = loadedDependencies("PP_BPO_PHARMACY_CLINICAL").where($"healthplansource" === "PAYER").as[pp_bpo_pharmacy_clinical]

    val result_df = ppBpoPharmacyClinical.as("phc")
      .join(ppBpoMemberDetail.as("elig"), Seq("groupid", "memberid", "healthplansource"), "inner")
      .where($"phc.administration_date".between($"elig.effectivedate", $"elig.enddate"))
      .select(
          $"phc.memberid".as("memberid"),
          $"phc.pharmacy_clinical_id".as("pharmacy_clinical_id"),
          $"phc.code_taxonomy".as("code_taxonomy"),
          $"phc.code".as("code"),
          date_format($"phc.administration_date", "yyyy-MM-dd").as("administration_date"),
          lit(null).cast(StringType).as("healthplansource"),
          lit("*").as("mapsource")
      )

    result_df.as[monthly_payer_phc_sre].toDF()
  }

}
