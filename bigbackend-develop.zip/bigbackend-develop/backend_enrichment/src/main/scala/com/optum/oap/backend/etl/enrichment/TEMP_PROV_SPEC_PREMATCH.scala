package com.optum.oap.backend.etl.enrichment

import com.optum.oap.backend.loader.EnrichmentRunTimeVariables
import com.optum.oap.cdr.models.{prov_spec, ref_primaryspecialty, zh_provider}
import com.optum.oap.sparkdataloader.{RuntimeVariables, TableInfo, UserDefinedFunctionForDataLoader}
import org.apache.spark.sql.expressions.Window
import org.apache.spark.sql.functions._
import org.apache.spark.sql.{DataFrame, SparkSession}

object TEMP_PROV_SPEC_PREMATCH extends TableInfo[prov_spec] {

  override def dependsOn = Set("CDR_FE_PROV_SPEC", "REF_PRIMARYSPECIALTY", "CDR_FE_ZH_PROVIDER",
    "ICPM_ZH_PROVIDER", "ICPM_PROV_SPEC")

  override def name = "TEMP_PROV_SPEC_PREMATCH"

  override def ignoreExtraColumnsInDataFrame: Boolean = true

  override def createDataFrame(sparkSession: SparkSession,
                               loadedDependencies: Map[String, DataFrame],
                               udfMap: Map[String, UserDefinedFunctionForDataLoader],
                               runtimeVariables: RuntimeVariables): DataFrame = {
    import sparkSession.implicits._

    val grpid = EnrichmentRunTimeVariables(runtimeVariables).clientId

    val zhprovIn = loadedDependencies("CDR_FE_ZH_PROVIDER").withColumn("rn", row_number().over(Window.partitionBy($"groupid", $"client_ds_id", $"localproviderid")
      .orderBy(when($"npi".isNotNull && length($"npi") === 10, 1).otherwise(0).desc_nulls_last
        , length($"providername").desc_nulls_last
        , when($"credentials".isNotNull, 1).otherwise(0).desc
        , $"npi".asc_nulls_last
        , $"providername".asc))).filter($"rn" === 1).drop("row_source","modified_date", "rn").as[zh_provider]

    val provspecIn = loadedDependencies("CDR_FE_PROV_SPEC").drop("row_source","modified_date").as[prov_spec]
    val refPrimSpec = loadedDependencies("REF_PRIMARYSPECIALTY").as[ref_primaryspecialty]
    //Load df from ICPM zh_provider and prov_spec
    val icpmProvider = loadedDependencies("ICPM_ZH_PROVIDER").as[zh_provider]
    val icpmProvSpec = loadedDependencies("ICPM_PROV_SPEC").as[prov_spec]

    //Union Provider & Provider specialty data coming from FE & ICPM
    val unionProvider = zhprovIn.unionByName(icpmProvider)

    // For H053731, remove data from all client_ds_ids except for 10192
   val unionProvSpec =
     if (grpid.trim.equalsIgnoreCase("H053731"))
      provspecIn.unionByName(icpmProvSpec).filter($"client_ds_id" === 10192)
    else
      provspecIn.unionByName(icpmProvSpec)

    val addedSpecs = unionProvider.as("zh")
      .join(refPrimSpec.as("ref"), $"zh.npi" === $"ref.npi", "inner")
      .join(unionProvSpec.filter($"localcodesource" === "npi").as("zhps"), $"zh.client_ds_id" === $"zhps.client_ds_id" &&
        $"zh.localproviderid" === $"zhps.localproviderid" &&
        $"ref.primarycode" === $"zhps.localspecialtycode", "left_outer")
      .where($"zhps.localproviderid".isNull && $"primarycode".isNotNull)
      .select($"zh.groupid",
        $"zh.client_ds_id",
        $"zh.master_hgprovid".as("mstrprovid"),
        $"zh.localproviderid",
        $"ref.primarycode".as("localspecialtycode"),
        lit("npi").as("localcodesource"),
        lit(1).as("local_code_order")
      )

    val cols = addedSpecs.columns.map(c => $"$c")
    addedSpecs.union(unionProvSpec.toDF().select(cols: _*))

  }

}