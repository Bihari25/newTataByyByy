package com.optum.oap.backend.etl.encgrps

import com.optum.oap.backend.cdrTempModel.temp_encounter_grp_rel_base
import com.optum.oap.cdr.models.encounter_grp_rel
import com.optum.oap.sparkdataloader.{RuntimeVariables, TableInfo, UserDefinedFunctionForDataLoader}
import org.apache.spark.sql.expressions.Window
import org.apache.spark.sql.{DataFrame, SparkSession}

// Maps to TEMP_ENCOUNTER_GRP_REL2
object TEMP_ENCOUNTER_GRP_REL_CH001654 extends TableInfo[encounter_grp_rel] {

  override def name: String = "TEMP_ENCOUNTER_GRP_REL_CH001654"

  override def dependsOn: Set[String] = Set("ENCOUNTER_GRP_REL_BASE")

  override protected def createDataFrame(sparkSession: SparkSession,
                                         loadedDependencies: Map[String, DataFrame],
                                         udfMap: Map[String, UserDefinedFunctionForDataLoader],
                                         runtimeVariables: RuntimeVariables): DataFrame = {
    import org.apache.spark.sql.functions._
    import sparkSession.implicits._

    val tempEncounterGrpBaseRel = loadedDependencies("ENCOUNTER_GRP_REL_BASE").as[temp_encounter_grp_rel_base]

    /*
    select GROUPID,ENCOUNTER_GRP_NUM,ENCOUNTER_GRP_REL_TYPE,REL_ENCOUNTER_GRP_NUM
from
(select idx.groupid, idx.ENCOUNTER_GRP_NUM, 'CH001654' as ENCOUNTER_GRP_REL_TYPE  --IP to IP cms any dx
  , readm.ENCOUNTER_GRP_NUM as REL_ENCOUNTER_GRP_NUM
  , row_number() over (partition by idx.ENCOUNTER_GRP_NUM
                 order by idx.ENCOUNTER_GRP_NUM,datediff(date_trunc('dd', readm.admittime), date_trunc('dd', idx.dischargetime)), readm.ENCOUNTER_GRP_NUM) as rrank
from ENCOUNTER_GRP idx
inner join  ENCOUNTER_GRP readm on (idx.grp_mpi = readm.grp_mpi)
where idx.encounter_grp_type = 'CH000106'
and readm.encounter_grp_type = 'CH000106'
and date_trunc('dd', readm.admittime) > date_trunc('dd', idx.dischargetime)
and idx.cmsinclude = 'Y'
and readm.cmsplanned = 'N'
)
where rrank = 1
     */
    val result = tempEncounterGrpBaseRel.as("rel")
      .where(
        $"rel.idxEncounterGrpType" === lit("CH000106") &&
          $"rel.readmEncounterGrpType" === lit("CH000106") &&
          $"rel.idxCMSInclude" === lit("Y") &&
          $"rel.readmCMSPlanned" === lit("N"))
      .select(
        $"rel.idxGroupId".as("GROUPID"),
        $"rel.idxEncounterGrpNum".as("ENCOUNTER_GRP_NUM"),
        lit("CH001654").as("ENCOUNTER_GRP_REL_TYPE"),
        $"rel.readmEncounterGrpNum".as("REL_ENCOUNTER_GRP_NUM"),
        row_number().over(Window.partitionBy($"rel.idxEncounterGrpNum")
          .orderBy($"rel.idxEncounterGrpNum", datediff(to_date($"rel.readmAdmitTime"), to_date($"rel.idxDischargeTime")), $"rel.readmEncounterGrpNum")).as("rrank")
      )
      .where($"rrank" === lit(1))
      .select(
        $"GROUPID",
        $"ENCOUNTER_GRP_NUM",
        $"ENCOUNTER_GRP_REL_TYPE",
        $"REL_ENCOUNTER_GRP_NUM"
      ).as[encounter_grp_rel]

    result.toDF()
  }
}

// Maps to TEMP_ENCOUNTER_GRP_REL5
object TEMP_ENCOUNTER_GRP_REL_CH001647 extends TableInfo[encounter_grp_rel] {

  override def name: String = "TEMP_ENCOUNTER_GRP_REL_CH001647"

  override def dependsOn: Set[String] = Set("ENCOUNTER_GRP_REL_BASE")

  override protected def createDataFrame(sparkSession: SparkSession,
                                         loadedDependencies: Map[String, DataFrame],
                                         udfMap: Map[String, UserDefinedFunctionForDataLoader],
                                         runtimeVariables: RuntimeVariables): DataFrame = {
    import org.apache.spark.sql.functions._
    import sparkSession.implicits._

    val tempEncounterGrpBaseRel = loadedDependencies("ENCOUNTER_GRP_REL_BASE").as[temp_encounter_grp_rel_base]

    /*
    select  GROUPID,ENCOUNTER_GRP_NUM,ENCOUNTER_GRP_REL_TYPE,REL_ENCOUNTER_GRP_NUM
from
(select  idx.groupid, idx.ENCOUNTER_GRP_NUM, 'CH001647' as ENCOUNTER_GRP_REL_TYPE  --IP to ED base any dx
  , readm.ENCOUNTER_GRP_NUM as REL_ENCOUNTER_GRP_NUM
  , row_number() over (partition by idx.ENCOUNTER_GRP_NUM
                 order by idx.ENCOUNTER_GRP_NUM,datediff(date_trunc('dd', readm.admittime), date_trunc('dd', idx.dischargetime)), readm.ENCOUNTER_GRP_NUM) as rrank
from ENCOUNTER_GRP idx
inner join ENCOUNTER_GRP readm on (idx.grp_mpi = readm.grp_mpi)
where idx.encounter_grp_type = 'CH000106'
and readm.encounter_grp_type = 'CH000109'
and date_trunc('dd', readm.admittime) > date_trunc('dd', idx.dischargetime)
and idx.baseinclude = 'Y'
)
where rrank = 1
     */
    val result = tempEncounterGrpBaseRel.as("rel")
      .where(
        $"rel.idxEncounterGrpType" === lit("CH000106") &&
          $"rel.readmEncounterGrpType" === lit("CH000109") &&
          $"rel.idxBaseInclude" === lit("Y"))
      .select(
        $"rel.idxGroupId".as("GROUPID"),
        $"rel.idxEncounterGrpNum".as("ENCOUNTER_GRP_NUM"),
        lit("CH001647").as("ENCOUNTER_GRP_REL_TYPE"),
        $"rel.readmEncounterGrpNum".as("REL_ENCOUNTER_GRP_NUM"),
        row_number().over(Window.partitionBy($"rel.idxEncounterGrpNum")
          .orderBy($"rel.idxEncounterGrpNum", datediff(to_date($"rel.readmAdmitTime"), to_date($"rel.idxDischargeTime")), $"rel.readmEncounterGrpNum")).as("rrank")
      )
      .where($"rrank" === lit(1))
      .select(
        $"GROUPID",
        $"ENCOUNTER_GRP_NUM",
        $"ENCOUNTER_GRP_REL_TYPE",
        $"REL_ENCOUNTER_GRP_NUM"
      ).as[encounter_grp_rel]

    result.toDF()
  }
}

// Maps to TEMP_ENCOUNTER_GRP_REL6
object TEMP_ENCOUNTER_GRP_REL_CH001648 extends TableInfo[encounter_grp_rel] {

  override def name: String = "TEMP_ENCOUNTER_GRP_REL_CH001648"

  override def dependsOn: Set[String] = Set("ENCOUNTER_GRP_REL_BASE")

  override protected def createDataFrame(sparkSession: SparkSession,
                                         loadedDependencies: Map[String, DataFrame],
                                         udfMap: Map[String, UserDefinedFunctionForDataLoader],
                                         runtimeVariables: RuntimeVariables): DataFrame = {
    import org.apache.spark.sql.functions._
    import sparkSession.implicits._

    val tempEncounterGrpBaseRel = loadedDependencies("ENCOUNTER_GRP_REL_BASE").as[temp_encounter_grp_rel_base]

    /*
    select GROUPID,ENCOUNTER_GRP_NUM,ENCOUNTER_GRP_REL_TYPE,REL_ENCOUNTER_GRP_NUM
from
(select idx.groupid, idx.ENCOUNTER_GRP_NUM, 'CH001648' as ENCOUNTER_GRP_REL_TYPE  --IP to ED base same prindx3
  , readm.ENCOUNTER_GRP_NUM as REL_ENCOUNTER_GRP_NUM
  , row_number() over (partition by idx.ENCOUNTER_GRP_NUM
                 order by idx.ENCOUNTER_GRP_NUM,datediff(date_trunc('dd', readm.admittime), date_trunc('dd', idx.dischargetime)), readm.ENCOUNTER_GRP_NUM) as rrank
from ENCOUNTER_GRP idx
inner join ENCOUNTER_GRP readm on (idx.grp_mpi = readm.grp_mpi)
where idx.encounter_grp_type = 'CH000106'
and readm.encounter_grp_type = 'CH000109'
and date_trunc('dd', readm.admittime) > date_trunc('dd', idx.dischargetime)
and idx.prindx is not null
and substr(idx.prindx,1,3) =  substr(readm.prindx,1,3)
and idx.baseinclude = 'Y'
)
where rrank = 1
     */
    val result = tempEncounterGrpBaseRel.as("rel")
      .where(
        $"rel.idxEncounterGrpType" === lit("CH000106") &&
          $"rel.readmEncounterGrpType" === lit("CH000109") &&
          $"rel.idxPrinDx".isNotNull &&
          substring($"rel.idxPrinDx", 1, 3) === substring($"rel.readmPrinDx", 1, 3) &&
          $"rel.idxBaseInclude" === lit("Y"))
      .select(
        $"rel.idxGroupId".as("GROUPID"),
        $"rel.idxEncounterGrpNum".as("ENCOUNTER_GRP_NUM"),
        lit("CH001648").as("ENCOUNTER_GRP_REL_TYPE"),
        $"rel.readmEncounterGrpNum".as("REL_ENCOUNTER_GRP_NUM"),
        row_number().over(Window.partitionBy($"rel.idxEncounterGrpNum")
          .orderBy($"rel.idxEncounterGrpNum", datediff(to_date($"rel.readmAdmitTime"), to_date($"rel.idxDischargeTime")), $"rel.readmEncounterGrpNum")).as("rrank")
      )
      .where($"rrank" === lit(1))
      .select(
        $"GROUPID",
        $"ENCOUNTER_GRP_NUM",
        $"ENCOUNTER_GRP_REL_TYPE",
        $"REL_ENCOUNTER_GRP_NUM"
      ).as[encounter_grp_rel]

    result.toDF()
  }
}

// Maps to TEMP_ENCOUNTER_GRP_REL7
object TEMP_ENCOUNTER_GRP_REL_CH001645 extends TableInfo[encounter_grp_rel] {

  override def name: String = "TEMP_ENCOUNTER_GRP_REL_CH001645"

  override def dependsOn: Set[String] = Set("ENCOUNTER_GRP_REL_BASE")

  override protected def createDataFrame(sparkSession: SparkSession,
                                         loadedDependencies: Map[String, DataFrame],
                                         udfMap: Map[String, UserDefinedFunctionForDataLoader],
                                         runtimeVariables: RuntimeVariables): DataFrame = {
    import org.apache.spark.sql.functions._
    import sparkSession.implicits._

    val tempEncounterGrpBaseRel = loadedDependencies("ENCOUNTER_GRP_REL_BASE").as[temp_encounter_grp_rel_base]

    /*
    select GROUPID,ENCOUNTER_GRP_NUM,ENCOUNTER_GRP_REL_TYPE,REL_ENCOUNTER_GRP_NUM
from
(select idx.groupid, idx.ENCOUNTER_GRP_NUM, 'CH001645' as ENCOUNTER_GRP_REL_TYPE  --ED to ED base any dx
  , readm.ENCOUNTER_GRP_NUM as REL_ENCOUNTER_GRP_NUM
  , row_number() over (partition by idx.ENCOUNTER_GRP_NUM
                 order by idx.ENCOUNTER_GRP_NUM,datediff(date_trunc('dd', readm.admittime), date_trunc('dd', idx.dischargetime)), readm.ENCOUNTER_GRP_NUM) as rrank
from ENCOUNTER_GRP idx
inner join ENCOUNTER_GRP readm on (idx.grp_mpi = readm.grp_mpi)
where idx.encounter_grp_type = 'CH000109'
and readm.encounter_grp_type = 'CH000109'
and date_trunc('dd', readm.admittime) > date_trunc('dd', idx.dischargetime)
and idx.baseinclude = 'Y'
)
where rrank = 1
     */
    val result = tempEncounterGrpBaseRel.as("rel")
      .where(
        $"rel.idxEncounterGrpType" === lit("CH000109") &&
          $"rel.readmEncounterGrpType" === lit("CH000109") &&
          $"rel.idxBaseInclude" === lit("Y"))
      .select(
        $"rel.idxGroupId".as("GROUPID"),
        $"rel.idxEncounterGrpNum".as("ENCOUNTER_GRP_NUM"),
        lit("CH001645").as("ENCOUNTER_GRP_REL_TYPE"),
        $"rel.readmEncounterGrpNum".as("REL_ENCOUNTER_GRP_NUM"),
        row_number().over(Window.partitionBy($"rel.idxEncounterGrpNum")
          .orderBy($"rel.idxEncounterGrpNum", datediff(to_date($"rel.readmAdmitTime"), to_date($"rel.idxDischargeTime")), $"rel.readmEncounterGrpNum")).as("rrank")
      )
      .where($"rrank" === lit(1))
      .select(
        $"GROUPID",
        $"ENCOUNTER_GRP_NUM",
        $"ENCOUNTER_GRP_REL_TYPE",
        $"REL_ENCOUNTER_GRP_NUM"
      ).as[encounter_grp_rel]

    result.toDF()
  }
}

// Maps to TEMP_ENCOUNTER_GRP_REL8
object TEMP_ENCOUNTER_GRP_REL_CH001646 extends TableInfo[encounter_grp_rel] {

  override def name: String = "TEMP_ENCOUNTER_GRP_REL_CH001646"

  override def dependsOn: Set[String] = Set("ENCOUNTER_GRP_REL_BASE")

  override protected def createDataFrame(sparkSession: SparkSession,
                                         loadedDependencies: Map[String, DataFrame],
                                         udfMap: Map[String, UserDefinedFunctionForDataLoader],
                                         runtimeVariables: RuntimeVariables): DataFrame = {
    import org.apache.spark.sql.functions._
    import sparkSession.implicits._

    val tempEncounterGrpBaseRel = loadedDependencies("ENCOUNTER_GRP_REL_BASE").as[temp_encounter_grp_rel_base]

    /*
    select GROUPID,ENCOUNTER_GRP_NUM,ENCOUNTER_GRP_REL_TYPE,REL_ENCOUNTER_GRP_NUM
from
(select idx.groupid, idx.ENCOUNTER_GRP_NUM, 'CH001646' as ENCOUNTER_GRP_REL_TYPE  --ED to ED base same prindx3
  , readm.ENCOUNTER_GRP_NUM as REL_ENCOUNTER_GRP_NUM
  , row_number() over (partition by idx.ENCOUNTER_GRP_NUM
                 order by idx.ENCOUNTER_GRP_NUM,datediff(date_trunc('dd', readm.admittime), date_trunc('dd', idx.dischargetime)), readm.ENCOUNTER_GRP_NUM) as rrank
from ENCOUNTER_GRP idx
inner join ENCOUNTER_GRP readm on (idx.grp_mpi = readm.grp_mpi)
where idx.encounter_grp_type = 'CH000109'
and readm.encounter_grp_type = 'CH000109'
and date_trunc('dd', readm.admittime) > date_trunc('dd', idx.dischargetime)
and idx.prindx is not null
and substr(idx.prindx,1,3) =  substr(readm.prindx,1,3)
and idx.baseinclude = 'Y'
)
where rrank = 1
     */
    val result = tempEncounterGrpBaseRel.as("rel")
      .where(
        $"rel.idxEncounterGrpType" === lit("CH000109") &&
          $"rel.readmEncounterGrpType" === lit("CH000109") &&
          $"rel.idxPrinDx".isNotNull &&
          substring($"rel.idxPrinDx", 1, 3) === substring($"rel.readmPrinDx", 1, 3) &&
          $"rel.idxBaseInclude" === lit("Y"))
      .select(
        $"rel.idxGroupId".as("GROUPID"),
        $"rel.idxEncounterGrpNum".as("ENCOUNTER_GRP_NUM"),
        lit("CH001646").as("ENCOUNTER_GRP_REL_TYPE"),
        $"rel.readmEncounterGrpNum".as("REL_ENCOUNTER_GRP_NUM"),
        row_number().over(Window.partitionBy($"rel.idxEncounterGrpNum")
          .orderBy($"rel.idxEncounterGrpNum", datediff(to_date($"rel.readmAdmitTime"), to_date($"rel.idxDischargeTime")), $"rel.readmEncounterGrpNum")).as("rrank")
      )
      .where($"rrank" === lit(1))
      .select(
        $"GROUPID",
        $"ENCOUNTER_GRP_NUM",
        $"ENCOUNTER_GRP_REL_TYPE",
        $"REL_ENCOUNTER_GRP_NUM"
      ).as[encounter_grp_rel]

    result.toDF()
  }
}

// Maps to TEMP_ENCOUNTER_GRP_REL11
object TEMP_ENCOUNTER_GRP_REL_CH001655 extends TableInfo[encounter_grp_rel] {

  override def name: String = "TEMP_ENCOUNTER_GRP_REL_CH001655"

  override def dependsOn: Set[String] = Set("ENCOUNTER_GRP_REL_BASE")

  override protected def createDataFrame(sparkSession: SparkSession,
                                         loadedDependencies: Map[String, DataFrame],
                                         udfMap: Map[String, UserDefinedFunctionForDataLoader],
                                         runtimeVariables: RuntimeVariables): DataFrame = {
    import org.apache.spark.sql.functions._
    import sparkSession.implicits._

    val tempEncounterGrpBaseRel = loadedDependencies("ENCOUNTER_GRP_REL_BASE").as[temp_encounter_grp_rel_base]

    /*
    select GROUPID,ENCOUNTER_GRP_NUM,ENCOUNTER_GRP_REL_TYPE,REL_ENCOUNTER_GRP_NUM
from
(select idx.groupid, idx.ENCOUNTER_GRP_NUM, 'CH001655' as ENCOUNTER_GRP_REL_TYPE  --SDS to ED base any dx
  , readm.ENCOUNTER_GRP_NUM as REL_ENCOUNTER_GRP_NUM
  , row_number() over (partition by idx.ENCOUNTER_GRP_NUM
                 order by idx.ENCOUNTER_GRP_NUM,datediff(date_trunc('dd', readm.admittime), date_trunc('dd', idx.dischargetime)), readm.ENCOUNTER_GRP_NUM) as rrank
from ENCOUNTER_GRP idx
inner join ENCOUNTER_GRP readm on (idx.grp_mpi = readm.grp_mpi)
where idx.encounter_grp_type = 'CH000113'
and readm.encounter_grp_type = 'CH000109'
and date_trunc('dd', readm.admittime) > date_trunc('dd', idx.dischargetime)
and idx.baseinclude = 'Y'
)
where rrank = 1
     */
    val result = tempEncounterGrpBaseRel.as("rel")
      .where(
        $"rel.idxEncounterGrpType" === lit("CH000113") &&
          $"rel.readmEncounterGrpType" === lit("CH000109") &&
          $"rel.idxBaseInclude" === lit("Y"))
      .select(
        $"rel.idxGroupId".as("GROUPID"),
        $"rel.idxEncounterGrpNum".as("ENCOUNTER_GRP_NUM"),
        lit("CH001655").as("ENCOUNTER_GRP_REL_TYPE"),
        $"rel.readmEncounterGrpNum".as("REL_ENCOUNTER_GRP_NUM"),
        row_number().over(Window.partitionBy($"rel.idxEncounterGrpNum")
          .orderBy($"rel.idxEncounterGrpNum", datediff(to_date($"rel.readmAdmitTime"), to_date($"rel.idxDischargeTime")), $"rel.readmEncounterGrpNum")).as("rrank")
      )
      .where($"rrank" === lit(1))
      .select(
        $"GROUPID",
        $"ENCOUNTER_GRP_NUM",
        $"ENCOUNTER_GRP_REL_TYPE",
        $"REL_ENCOUNTER_GRP_NUM"
      ).as[encounter_grp_rel]

    result.toDF()
  }
}

// Maps to TEMP_ENCOUNTER_GRP_REL12
object TEMP_ENCOUNTER_GRP_REL_CH001656 extends TableInfo[encounter_grp_rel] {

  override def name: String = "TEMP_ENCOUNTER_GRP_REL_CH001656"

  override def dependsOn: Set[String] = Set("ENCOUNTER_GRP_REL_BASE")

  override protected def createDataFrame(sparkSession: SparkSession,
                                         loadedDependencies: Map[String, DataFrame],
                                         udfMap: Map[String, UserDefinedFunctionForDataLoader],
                                         runtimeVariables: RuntimeVariables): DataFrame = {
    import org.apache.spark.sql.functions._
    import sparkSession.implicits._

    val tempEncounterGrpBaseRel = loadedDependencies("ENCOUNTER_GRP_REL_BASE").as[temp_encounter_grp_rel_base]

    /*
    select GROUPID,ENCOUNTER_GRP_NUM,ENCOUNTER_GRP_REL_TYPE,REL_ENCOUNTER_GRP_NUM
from
(select idx.groupid, idx.ENCOUNTER_GRP_NUM, 'CH001656' as ENCOUNTER_GRP_REL_TYPE  --SDS to ED base same prindx3
  , readm.ENCOUNTER_GRP_NUM as REL_ENCOUNTER_GRP_NUM
  , row_number() over (partition by idx.ENCOUNTER_GRP_NUM
                 order by idx.ENCOUNTER_GRP_NUM,datediff(date_trunc('dd', readm.admittime), date_trunc('dd', idx.dischargetime)), readm.ENCOUNTER_GRP_NUM) as rrank
from ENCOUNTER_GRP idx
inner join ENCOUNTER_GRP readm on (idx.grp_mpi = readm.grp_mpi)
where idx.encounter_grp_type = 'CH000113'
and readm.encounter_grp_type = 'CH000109'
and date_trunc('dd', readm.admittime) > date_trunc('dd', idx.dischargetime)
and idx.prindx is not null
and substr(idx.prindx,1,3) =  substr(readm.prindx,1,3)
and idx.baseinclude = 'Y'
)
where rrank = 1
     */
    val result = tempEncounterGrpBaseRel.as("rel")
      .where(
        $"rel.idxEncounterGrpType" === lit("CH000113") &&
          $"rel.readmEncounterGrpType" === lit("CH000109") &&
          $"rel.idxPrinDx".isNotNull && substring($"rel.idxPrinDx", 1, 3) === substring($"rel.readmPrinDx", 1, 3) &&
          $"rel.idxBaseInclude" === lit("Y"))
      .select(
        $"rel.idxGroupId".as("GROUPID"),
        $"rel.idxEncounterGrpNum".as("ENCOUNTER_GRP_NUM"),
        lit("CH001656").as("ENCOUNTER_GRP_REL_TYPE"),
        $"rel.readmEncounterGrpNum".as("REL_ENCOUNTER_GRP_NUM"),
        row_number().over(Window.partitionBy($"rel.idxEncounterGrpNum")
          .orderBy($"rel.idxEncounterGrpNum", datediff(to_date($"rel.readmAdmitTime"), to_date($"rel.idxDischargeTime")), $"rel.readmEncounterGrpNum")).as("rrank")
      )
      .where($"rrank" === lit(1))
      .select(
        $"GROUPID",
        $"ENCOUNTER_GRP_NUM",
        $"ENCOUNTER_GRP_REL_TYPE",
        $"REL_ENCOUNTER_GRP_NUM"
      ).as[encounter_grp_rel]

    result.toDF()
  }
}

// Maps to TEMP_ENCOUNTER_GRP_REL19
object TEMP_ENCOUNTER_GRP_REL_CH002775 extends TableInfo[encounter_grp_rel] {

  override def name: String = "TEMP_ENCOUNTER_GRP_REL_CH002775"

  override def dependsOn: Set[String] = Set("ENCOUNTER_GRP_REL_BASE")

  override protected def createDataFrame(sparkSession: SparkSession,
                                         loadedDependencies: Map[String, DataFrame],
                                         udfMap: Map[String, UserDefinedFunctionForDataLoader],
                                         runtimeVariables: RuntimeVariables): DataFrame = {
    import org.apache.spark.sql.functions._
    import sparkSession.implicits._

    val tempEncounterGrpBaseRel = loadedDependencies("ENCOUNTER_GRP_REL_BASE").as[temp_encounter_grp_rel_base]

    /*
    select GROUPID,ENCOUNTER_GRP_NUM,ENCOUNTER_GRP_REL_TYPE,REL_ENCOUNTER_GRP_NUM
from
(select idx.groupid, idx.ENCOUNTER_GRP_NUM, 'CH002775' as ENCOUNTER_GRP_REL_TYPE  --OBS visit will be readmitted to another OBS visit
  , readm.ENCOUNTER_GRP_NUM as REL_ENCOUNTER_GRP_NUM
  , row_number() over (partition by idx.ENCOUNTER_GRP_NUM
                 order by idx.ENCOUNTER_GRP_NUM,datediff(date_trunc('dd', readm.admittime), date_trunc('dd', idx.dischargetime)), readm.ENCOUNTER_GRP_NUM) as rrank
from ENCOUNTER_GRP idx
inner join ENCOUNTER_GRP readm on (idx.grp_mpi = readm.grp_mpi)
where idx.encounter_grp_type = 'CH000107'
and readm.encounter_grp_type = 'CH000107'
and date_trunc('dd', readm.admittime) > date_trunc('dd', idx.dischargetime)
and idx.baseinclude = 'Y'
)
where rrank = 1
     */
    val result = tempEncounterGrpBaseRel.as("rel")
      .where(
        $"rel.idxEncounterGrpType" === lit("CH000107") &&
          $"rel.readmEncounterGrpType" === lit("CH000107") &&
          $"rel.idxBaseInclude" === lit("Y"))
      .select(
        $"rel.idxGroupId".as("GROUPID"),
        $"rel.idxEncounterGrpNum".as("ENCOUNTER_GRP_NUM"),
        lit("CH002775").as("ENCOUNTER_GRP_REL_TYPE"),
        $"rel.readmEncounterGrpNum".as("REL_ENCOUNTER_GRP_NUM"),
        row_number().over(Window.partitionBy($"rel.idxEncounterGrpNum")
          .orderBy($"rel.idxEncounterGrpNum", datediff(to_date($"rel.readmAdmitTime"), to_date($"rel.idxDischargeTime")), $"rel.readmEncounterGrpNum")).as("rrank")
      )
      .where($"rrank" === lit(1))
      .select(
        $"GROUPID",
        $"ENCOUNTER_GRP_NUM",
        $"ENCOUNTER_GRP_REL_TYPE",
        $"REL_ENCOUNTER_GRP_NUM"
      ).as[encounter_grp_rel]

    result.toDF()
  }
}

// Maps to TEMP_ENCOUNTER_GRP_REL20
object TEMP_ENCOUNTER_GRP_REL_CH002776 extends TableInfo[encounter_grp_rel] {

  override def name: String = "TEMP_ENCOUNTER_GRP_REL_CH002776"

  override def dependsOn: Set[String] = Set("ENCOUNTER_GRP_REL_BASE")

  override protected def createDataFrame(sparkSession: SparkSession,
                                         loadedDependencies: Map[String, DataFrame],
                                         udfMap: Map[String, UserDefinedFunctionForDataLoader],
                                         runtimeVariables: RuntimeVariables): DataFrame = {
    import org.apache.spark.sql.functions._
    import sparkSession.implicits._

    val tempEncounterGrpBaseRel = loadedDependencies("ENCOUNTER_GRP_REL_BASE").as[temp_encounter_grp_rel_base]

    /*
    select GROUPID,ENCOUNTER_GRP_NUM,ENCOUNTER_GRP_REL_TYPE,REL_ENCOUNTER_GRP_NUM
from
(select idx.groupid, idx.ENCOUNTER_GRP_NUM, 'CH002776' as ENCOUNTER_GRP_REL_TYPE  --OBS visit will be readmitted to another OBS visit with same 3-digit principal dx
  , readm.ENCOUNTER_GRP_NUM as REL_ENCOUNTER_GRP_NUM
  , row_number() over (partition by idx.ENCOUNTER_GRP_NUM
                 order by idx.ENCOUNTER_GRP_NUM,datediff(date_trunc('dd', readm.admittime), date_trunc('dd', idx.dischargetime)), readm.ENCOUNTER_GRP_NUM) as rrank
from ENCOUNTER_GRP idx
inner join ENCOUNTER_GRP readm on (idx.grp_mpi = readm.grp_mpi)
where idx.encounter_grp_type = 'CH000107'
and readm.encounter_grp_type = 'CH000107'
and date_trunc('dd', readm.admittime) > date_trunc('dd', idx.dischargetime)
and idx.prindx is not null
and substr(idx.prindx,1,3) =  substr(readm.prindx,1,3)
and idx.baseinclude = 'Y'
)
where rrank = 1
     */
    val result = tempEncounterGrpBaseRel.as("rel")
      .where(
        $"rel.idxEncounterGrpType" === lit("CH000107") &&
          $"rel.readmEncounterGrpType" === lit("CH000107") &&
          $"rel.idxPrinDx".isNotNull && substring($"rel.idxPrinDx", 1, 3) === substring($"rel.readmPrinDx", 1, 3) &&
          $"rel.idxBaseInclude" === lit("Y"))
      .select(
        $"rel.idxGroupId".as("GROUPID"),
        $"rel.idxEncounterGrpNum".as("ENCOUNTER_GRP_NUM"),
        lit("CH002776").as("ENCOUNTER_GRP_REL_TYPE"),
        $"rel.readmEncounterGrpNum".as("REL_ENCOUNTER_GRP_NUM"),
        row_number().over(Window.partitionBy($"rel.idxEncounterGrpNum")
          .orderBy($"rel.idxEncounterGrpNum", datediff(to_date($"rel.readmAdmitTime"), to_date($"rel.idxDischargeTime")), $"rel.readmEncounterGrpNum")).as("rrank")
      )
      .where($"rrank" === lit(1))
      .select(
        $"GROUPID",
        $"ENCOUNTER_GRP_NUM",
        $"ENCOUNTER_GRP_REL_TYPE",
        $"REL_ENCOUNTER_GRP_NUM"
      ).as[encounter_grp_rel]

    result.toDF()
  }
}

// Maps to TEMP_ENCOUNTER_GRP_REL21
object TEMP_ENCOUNTER_GRP_REL_CH002777 extends TableInfo[encounter_grp_rel] {

  override def name: String = "TEMP_ENCOUNTER_GRP_REL_CH002777"

  override def dependsOn: Set[String] = Set("ENCOUNTER_GRP_REL_BASE")

  override protected def createDataFrame(sparkSession: SparkSession,
                                         loadedDependencies: Map[String, DataFrame],
                                         udfMap: Map[String, UserDefinedFunctionForDataLoader],
                                         runtimeVariables: RuntimeVariables): DataFrame = {
    import org.apache.spark.sql.functions._
    import sparkSession.implicits._

    val tempEncounterGrpBaseRel = loadedDependencies("ENCOUNTER_GRP_REL_BASE").as[temp_encounter_grp_rel_base]

    /*
    select GROUPID,ENCOUNTER_GRP_NUM,ENCOUNTER_GRP_REL_TYPE,REL_ENCOUNTER_GRP_NUM
from
(select idx.groupid, idx.ENCOUNTER_GRP_NUM, 'CH002777' as ENCOUNTER_GRP_REL_TYPE  --OBS visit will be readmitted to an IP visit
  , readm.ENCOUNTER_GRP_NUM as REL_ENCOUNTER_GRP_NUM
  , row_number() over (partition by idx.ENCOUNTER_GRP_NUM
                 order by idx.ENCOUNTER_GRP_NUM,datediff(date_trunc('dd', readm.admittime), date_trunc('dd', idx.dischargetime)), readm.ENCOUNTER_GRP_NUM) as rrank
from ENCOUNTER_GRP idx
inner join ENCOUNTER_GRP readm on (idx.grp_mpi = readm.grp_mpi)
where idx.encounter_grp_type = 'CH000107'
and readm.encounter_grp_type = 'CH000106'
and date_trunc('dd', readm.admittime) > date_trunc('dd', idx.dischargetime)
and idx.baseinclude = 'Y'
)
where rrank = 1
     */
    val result = tempEncounterGrpBaseRel.as("rel")
      .where(
        $"rel.idxEncounterGrpType" === lit("CH000107") &&
          $"rel.readmEncounterGrpType" === lit("CH000106") &&
          $"rel.idxBaseInclude" === lit("Y"))
      .select(
        $"rel.idxGroupId".as("GROUPID"),
        $"rel.idxEncounterGrpNum".as("ENCOUNTER_GRP_NUM"),
        lit("CH002777").as("ENCOUNTER_GRP_REL_TYPE"),
        $"rel.readmEncounterGrpNum".as("REL_ENCOUNTER_GRP_NUM"),
        row_number().over(Window.partitionBy($"rel.idxEncounterGrpNum")
          .orderBy($"rel.idxEncounterGrpNum", datediff(to_date($"rel.readmAdmitTime"), to_date($"rel.idxDischargeTime")), $"rel.readmEncounterGrpNum")).as("rrank")
      )
      .where($"rrank" === lit(1))
      .select(
        $"GROUPID",
        $"ENCOUNTER_GRP_NUM",
        $"ENCOUNTER_GRP_REL_TYPE",
        $"REL_ENCOUNTER_GRP_NUM"
      ).as[encounter_grp_rel]

    result.toDF()
  }
}

// Maps to TEMP_ENCOUNTER_GRP_REL22
object TEMP_ENCOUNTER_GRP_REL_CH002778 extends TableInfo[encounter_grp_rel] {

  override def name: String = "TEMP_ENCOUNTER_GRP_REL_CH002778"

  override def dependsOn: Set[String] = Set("ENCOUNTER_GRP_REL_BASE")

  override protected def createDataFrame(sparkSession: SparkSession,
                                         loadedDependencies: Map[String, DataFrame],
                                         udfMap: Map[String, UserDefinedFunctionForDataLoader],
                                         runtimeVariables: RuntimeVariables): DataFrame = {
    import org.apache.spark.sql.functions._
    import sparkSession.implicits._

    val tempEncounterGrpBaseRel = loadedDependencies("ENCOUNTER_GRP_REL_BASE").as[temp_encounter_grp_rel_base]

    /*
    select GROUPID,ENCOUNTER_GRP_NUM,ENCOUNTER_GRP_REL_TYPE,REL_ENCOUNTER_GRP_NUM
from
(select idx.groupid, idx.ENCOUNTER_GRP_NUM, 'CH002778' as ENCOUNTER_GRP_REL_TYPE  ---OBS visit will be readmitted to an IP visit with same 3-digit principal dx
  , readm.ENCOUNTER_GRP_NUM as REL_ENCOUNTER_GRP_NUM
  , row_number() over (partition by idx.ENCOUNTER_GRP_NUM
                 order by idx.ENCOUNTER_GRP_NUM,datediff(date_trunc('dd', readm.admittime), date_trunc('dd', idx.dischargetime)), readm.ENCOUNTER_GRP_NUM) as rrank
from ENCOUNTER_GRP idx
inner join ENCOUNTER_GRP readm on (idx.grp_mpi = readm.grp_mpi)
where idx.encounter_grp_type = 'CH000107'
and readm.encounter_grp_type = 'CH000106'
and date_trunc('dd', readm.admittime) > date_trunc('dd', idx.dischargetime)
and idx.prindx is not null
and substr(idx.prindx,1,3) =  substr(readm.prindx,1,3)
and idx.baseinclude = 'Y'
)
where rrank = 1
     */
    val result = tempEncounterGrpBaseRel.as("rel")
      .where(
        $"rel.idxEncounterGrpType" === lit("CH000107") &&
          $"rel.readmEncounterGrpType" === lit("CH000106") &&
          $"rel.idxPrinDx".isNotNull && substring($"rel.idxPrinDx", 1, 3) === substring($"rel.readmPrinDx", 1, 3) &&
          $"rel.idxBaseInclude" === lit("Y"))
      .select(
        $"rel.idxGroupId".as("GROUPID"),
        $"rel.idxEncounterGrpNum".as("ENCOUNTER_GRP_NUM"),
        lit("CH002778").as("ENCOUNTER_GRP_REL_TYPE"),
        $"rel.readmEncounterGrpNum".as("REL_ENCOUNTER_GRP_NUM"),
        row_number().over(Window.partitionBy($"rel.idxEncounterGrpNum")
          .orderBy($"rel.idxEncounterGrpNum", datediff(to_date($"rel.readmAdmitTime"), to_date($"rel.idxDischargeTime")), $"rel.readmEncounterGrpNum")).as("rrank")
      )
      .where($"rrank" === lit(1))
      .select(
        $"GROUPID",
        $"ENCOUNTER_GRP_NUM",
        $"ENCOUNTER_GRP_REL_TYPE",
        $"REL_ENCOUNTER_GRP_NUM"
      ).as[encounter_grp_rel]

    result.toDF()
  }
}

// Maps to TEMP_ENCOUNTER_GRP_REL23
object TEMP_ENCOUNTER_GRP_REL_CH002779 extends TableInfo[encounter_grp_rel] {

  override def name: String = "TEMP_ENCOUNTER_GRP_REL_CH002779"

  override def dependsOn: Set[String] = Set("ENCOUNTER_GRP_REL_BASE")

  override protected def createDataFrame(sparkSession: SparkSession,
                                         loadedDependencies: Map[String, DataFrame],
                                         udfMap: Map[String, UserDefinedFunctionForDataLoader],
                                         runtimeVariables: RuntimeVariables): DataFrame = {
    import org.apache.spark.sql.functions._
    import sparkSession.implicits._

    val tempEncounterGrpBaseRel = loadedDependencies("ENCOUNTER_GRP_REL_BASE").as[temp_encounter_grp_rel_base]

    /*
    select GROUPID,ENCOUNTER_GRP_NUM,ENCOUNTER_GRP_REL_TYPE,REL_ENCOUNTER_GRP_NUM
from
(select idx.groupid, idx.ENCOUNTER_GRP_NUM, 'CH002779' as ENCOUNTER_GRP_REL_TYPE  --OBS visit will be readmitted to an ED visit
  , readm.ENCOUNTER_GRP_NUM as REL_ENCOUNTER_GRP_NUM
  , row_number() over (partition by idx.ENCOUNTER_GRP_NUM
                 order by idx.ENCOUNTER_GRP_NUM,datediff(date_trunc('dd', readm.admittime), date_trunc('dd', idx.dischargetime)), readm.ENCOUNTER_GRP_NUM) as rrank
from  ENCOUNTER_GRP idx
inner join  ENCOUNTER_GRP readm on (idx.grp_mpi = readm.grp_mpi)
where idx.encounter_grp_type = 'CH000107'
and readm.encounter_grp_type = 'CH000109'
and date_trunc('dd', readm.admittime) > date_trunc('dd', idx.dischargetime)
and idx.baseinclude = 'Y'
)
where rrank = 1
     */
    val result = tempEncounterGrpBaseRel.as("rel")
      .where(
        $"rel.idxEncounterGrpType" === lit("CH000107") &&
          $"rel.readmEncounterGrpType" === lit("CH000109") &&
          $"rel.idxBaseInclude" === lit("Y"))
      .select(
        $"rel.idxGroupId".as("GROUPID"),
        $"rel.idxEncounterGrpNum".as("ENCOUNTER_GRP_NUM"),
        lit("CH002779").as("ENCOUNTER_GRP_REL_TYPE"),
        $"rel.readmEncounterGrpNum".as("REL_ENCOUNTER_GRP_NUM"),
        row_number().over(Window.partitionBy($"rel.idxEncounterGrpNum")
          .orderBy($"rel.idxEncounterGrpNum", datediff(to_date($"rel.readmAdmitTime"), to_date($"rel.idxDischargeTime")), $"rel.readmEncounterGrpNum")).as("rrank")
      )
      .where($"rrank" === lit(1))
      .select(
        $"GROUPID",
        $"ENCOUNTER_GRP_NUM",
        $"ENCOUNTER_GRP_REL_TYPE",
        $"REL_ENCOUNTER_GRP_NUM"
      ).as[encounter_grp_rel]

    result.toDF()
  }
}

// Maps to TEMP_ENCOUNTER_GRP_REL24
object TEMP_ENCOUNTER_GRP_REL_CH002780 extends TableInfo[encounter_grp_rel] {

  override def name: String = "TEMP_ENCOUNTER_GRP_REL_CH002780"

  override def dependsOn: Set[String] = Set("ENCOUNTER_GRP_REL_BASE")

  override protected def createDataFrame(sparkSession: SparkSession,
                                         loadedDependencies: Map[String, DataFrame],
                                         udfMap: Map[String, UserDefinedFunctionForDataLoader],
                                         runtimeVariables: RuntimeVariables): DataFrame = {
    import org.apache.spark.sql.functions._
    import sparkSession.implicits._

    val tempEncounterGrpBaseRel = loadedDependencies("ENCOUNTER_GRP_REL_BASE").as[temp_encounter_grp_rel_base]

    /*
    select GROUPID,ENCOUNTER_GRP_NUM,ENCOUNTER_GRP_REL_TYPE,REL_ENCOUNTER_GRP_NUM
from
(select idx.groupid, idx.ENCOUNTER_GRP_NUM, 'CH002780' as ENCOUNTER_GRP_REL_TYPE  --OBS visit will be readmitted to an ED visit with same 3-digit principal dx
  , readm.ENCOUNTER_GRP_NUM as REL_ENCOUNTER_GRP_NUM
  , row_number() over (partition by idx.ENCOUNTER_GRP_NUM
                 order by idx.ENCOUNTER_GRP_NUM,datediff(date_trunc('dd', readm.admittime), date_trunc('dd', idx.dischargetime)), readm.ENCOUNTER_GRP_NUM) as rrank
from ENCOUNTER_GRP idx
inner join ENCOUNTER_GRP readm on (idx.grp_mpi = readm.grp_mpi)
where idx.encounter_grp_type = 'CH000107'
and readm.encounter_grp_type = 'CH000109'
and date_trunc('dd', readm.admittime) > date_trunc('dd', idx.dischargetime)
and idx.prindx is not null
and substr(idx.prindx,1,3) =  substr(readm.prindx,1,3)
and idx.baseinclude = 'Y'
)
where rrank = 1
     */
    val result = tempEncounterGrpBaseRel.as("rel")
      .where(
        $"rel.idxEncounterGrpType" === lit("CH000107") &&
          $"rel.readmEncounterGrpType" === lit("CH000109") &&
          $"rel.idxPrinDx".isNotNull && substring($"rel.idxPrinDx", 1, 3) === substring($"rel.readmPrinDx", 1, 3) &&
          $"rel.idxBaseInclude" === lit("Y"))
      .select(
        $"rel.idxGroupId".as("GROUPID"),
        $"rel.idxEncounterGrpNum".as("ENCOUNTER_GRP_NUM"),
        lit("CH002780").as("ENCOUNTER_GRP_REL_TYPE"),
        $"rel.readmEncounterGrpNum".as("REL_ENCOUNTER_GRP_NUM"),
        row_number().over(Window.partitionBy($"rel.idxEncounterGrpNum")
          .orderBy($"rel.idxEncounterGrpNum", datediff(to_date($"rel.readmAdmitTime"), to_date($"rel.idxDischargeTime")), $"rel.readmEncounterGrpNum")).as("rrank")
      )
      .where($"rrank" === lit(1))
      .select(
        $"GROUPID",
        $"ENCOUNTER_GRP_NUM",
        $"ENCOUNTER_GRP_REL_TYPE",
        $"REL_ENCOUNTER_GRP_NUM"
      ).as[encounter_grp_rel]

    result.toDF()
  }
}

// Maps to TEMP_ENCOUNTER_GRP_REL25
object TEMP_ENCOUNTER_GRP_REL_CH002781 extends TableInfo[encounter_grp_rel] {

  override def name: String = "TEMP_ENCOUNTER_GRP_REL_CH002781"

  override def dependsOn: Set[String] = Set("ENCOUNTER_GRP_REL_BASE")

  override protected def createDataFrame(sparkSession: SparkSession,
                                         loadedDependencies: Map[String, DataFrame],
                                         udfMap: Map[String, UserDefinedFunctionForDataLoader],
                                         runtimeVariables: RuntimeVariables): DataFrame = {
    import org.apache.spark.sql.functions._
    import sparkSession.implicits._

    val tempEncounterGrpBaseRel = loadedDependencies("ENCOUNTER_GRP_REL_BASE").as[temp_encounter_grp_rel_base]

    /*
    select GROUPID,ENCOUNTER_GRP_NUM,ENCOUNTER_GRP_REL_TYPE,REL_ENCOUNTER_GRP_NUM
from
(select idx.groupid, idx.ENCOUNTER_GRP_NUM, 'CH002781' as ENCOUNTER_GRP_REL_TYPE  --IP visit will be readmitted to an OBS visit
  , readm.ENCOUNTER_GRP_NUM as REL_ENCOUNTER_GRP_NUM
  , row_number() over (partition by idx.ENCOUNTER_GRP_NUM
                 order by idx.ENCOUNTER_GRP_NUM,datediff(date_trunc('dd', readm.admittime), date_trunc('dd', idx.dischargetime)), readm.ENCOUNTER_GRP_NUM) as rrank
from ENCOUNTER_GRP idx
inner join ENCOUNTER_GRP readm on (idx.grp_mpi = readm.grp_mpi)
where idx.encounter_grp_type = 'CH000106'
and readm.encounter_grp_type = 'CH000107'
and date_trunc('dd', readm.admittime) > date_trunc('dd', idx.dischargetime)
and idx.baseinclude = 'Y'
)
where rrank = 1
     */
    val result = tempEncounterGrpBaseRel.as("rel")
      .where(
        $"rel.idxEncounterGrpType" === lit("CH000106") &&
          $"rel.readmEncounterGrpType" === lit("CH000107") &&
          $"rel.idxBaseInclude" === lit("Y"))
      .select(
        $"rel.idxGroupId".as("GROUPID"),
        $"rel.idxEncounterGrpNum".as("ENCOUNTER_GRP_NUM"),
        lit("CH002781").as("ENCOUNTER_GRP_REL_TYPE"),
        $"rel.readmEncounterGrpNum".as("REL_ENCOUNTER_GRP_NUM"),
        row_number().over(Window.partitionBy($"rel.idxEncounterGrpNum")
          .orderBy($"rel.idxEncounterGrpNum", datediff(to_date($"rel.readmAdmitTime"), to_date($"rel.idxDischargeTime")), $"rel.readmEncounterGrpNum")).as("rrank")
      )
      .where($"rrank" === lit(1))
      .select(
        $"GROUPID",
        $"ENCOUNTER_GRP_NUM",
        $"ENCOUNTER_GRP_REL_TYPE",
        $"REL_ENCOUNTER_GRP_NUM"
      ).as[encounter_grp_rel]

    result.toDF()
  }
}

// Maps to TEMP_ENCOUNTER_GRP_REL26
object TEMP_ENCOUNTER_GRP_REL_CH002782 extends TableInfo[encounter_grp_rel] {

  override def name: String = "TEMP_ENCOUNTER_GRP_REL_CH002782"

  override def dependsOn: Set[String] = Set("ENCOUNTER_GRP_REL_BASE")

  override protected def createDataFrame(sparkSession: SparkSession,
                                         loadedDependencies: Map[String, DataFrame],
                                         udfMap: Map[String, UserDefinedFunctionForDataLoader],
                                         runtimeVariables: RuntimeVariables): DataFrame = {
    import org.apache.spark.sql.functions._
    import sparkSession.implicits._

    val tempEncounterGrpBaseRel = loadedDependencies("ENCOUNTER_GRP_REL_BASE").as[temp_encounter_grp_rel_base]

    /*
    select GROUPID,ENCOUNTER_GRP_NUM,ENCOUNTER_GRP_REL_TYPE,REL_ENCOUNTER_GRP_NUM
from
(select idx.groupid, idx.ENCOUNTER_GRP_NUM, 'CH002782' as ENCOUNTER_GRP_REL_TYPE  --IP visit will be readmitted to an OBS visit with same 3-digit principal dx
  , readm.ENCOUNTER_GRP_NUM as REL_ENCOUNTER_GRP_NUM
  , row_number() over (partition by idx.ENCOUNTER_GRP_NUM
                 order by idx.ENCOUNTER_GRP_NUM,datediff(date_trunc('dd', readm.admittime), date_trunc('dd', idx.dischargetime)), readm.ENCOUNTER_GRP_NUM) as rrank
from  ENCOUNTER_GRP idx
inner join  ENCOUNTER_GRP readm on (idx.grp_mpi = readm.grp_mpi)
where idx.encounter_grp_type = 'CH000106'
and readm.encounter_grp_type = 'CH000107'
and date_trunc('dd', readm.admittime) > date_trunc('dd', idx.dischargetime)
and idx.prindx is not null
and substr(idx.prindx,1,3) =  substr(readm.prindx,1,3)
and idx.baseinclude = 'Y'
)
where rrank = 1
     */
    val result = tempEncounterGrpBaseRel.as("rel")
      .where(
        $"rel.idxEncounterGrpType" === lit("CH000106") &&
          $"rel.readmEncounterGrpType" === lit("CH000107") &&
          $"rel.idxPrinDx".isNotNull && substring($"rel.idxPrinDx", 1, 3) === substring($"rel.readmPrinDx", 1, 3) &&
          $"rel.idxBaseInclude" === lit("Y"))
      .select(
        $"rel.idxGroupId".as("GROUPID"),
        $"rel.idxEncounterGrpNum".as("ENCOUNTER_GRP_NUM"),
        lit("CH002782").as("ENCOUNTER_GRP_REL_TYPE"),
        $"rel.readmEncounterGrpNum".as("REL_ENCOUNTER_GRP_NUM"),
        row_number().over(Window.partitionBy($"rel.idxEncounterGrpNum")
          .orderBy($"rel.idxEncounterGrpNum", datediff(to_date($"rel.readmAdmitTime"), to_date($"rel.idxDischargeTime")), $"rel.readmEncounterGrpNum")).as("rrank")
      )
      .where($"rrank" === lit(1))
      .select(
        $"GROUPID",
        $"ENCOUNTER_GRP_NUM",
        $"ENCOUNTER_GRP_REL_TYPE",
        $"REL_ENCOUNTER_GRP_NUM"
      ).as[encounter_grp_rel]

    result.toDF()
  }
}

// Maps to TEMP_ENCOUNTER_GRP_REL27
object TEMP_ENCOUNTER_GRP_REL_CH002783 extends TableInfo[encounter_grp_rel] {

  override def name: String = "TEMP_ENCOUNTER_GRP_REL_CH002783"

  override def dependsOn: Set[String] = Set("ENCOUNTER_GRP_REL_BASE")

  override protected def createDataFrame(sparkSession: SparkSession,
                                         loadedDependencies: Map[String, DataFrame],
                                         udfMap: Map[String, UserDefinedFunctionForDataLoader],
                                         runtimeVariables: RuntimeVariables): DataFrame = {
    import org.apache.spark.sql.functions._
    import sparkSession.implicits._

    val tempEncounterGrpBaseRel = loadedDependencies("ENCOUNTER_GRP_REL_BASE").as[temp_encounter_grp_rel_base]

    /*
    select GROUPID,ENCOUNTER_GRP_NUM,ENCOUNTER_GRP_REL_TYPE,REL_ENCOUNTER_GRP_NUM
from
(select idx.groupid, idx.ENCOUNTER_GRP_NUM, 'CH002783' as ENCOUNTER_GRP_REL_TYPE  --ED visit will be readmitted to an OBS visit
  , readm.ENCOUNTER_GRP_NUM as REL_ENCOUNTER_GRP_NUM
  , row_number() over (partition by idx.ENCOUNTER_GRP_NUM
                 order by idx.ENCOUNTER_GRP_NUM,datediff(date_trunc('dd', readm.admittime), date_trunc('dd', idx.dischargetime)), readm.ENCOUNTER_GRP_NUM) as rrank
from ENCOUNTER_GRP idx
inner join ENCOUNTER_GRP readm on (idx.grp_mpi = readm.grp_mpi)
where idx.encounter_grp_type = 'CH000109'
and readm.encounter_grp_type = 'CH000107'
and date_trunc('dd', readm.admittime) > date_trunc('dd', idx.dischargetime)
and idx.baseinclude = 'Y'
)
where rrank = 1
     */
    val result = tempEncounterGrpBaseRel.as("rel")
      .where(
        $"rel.idxEncounterGrpType" === lit("CH000109") &&
          $"rel.readmEncounterGrpType" === lit("CH000107") &&
          $"rel.idxBaseInclude" === lit("Y"))
      .select(
        $"rel.idxGroupId".as("GROUPID"),
        $"rel.idxEncounterGrpNum".as("ENCOUNTER_GRP_NUM"),
        lit("CH002783").as("ENCOUNTER_GRP_REL_TYPE"),
        $"rel.readmEncounterGrpNum".as("REL_ENCOUNTER_GRP_NUM"),
        row_number().over(Window.partitionBy($"rel.idxEncounterGrpNum")
          .orderBy($"rel.idxEncounterGrpNum", datediff(to_date($"rel.readmAdmitTime"), to_date($"rel.idxDischargeTime")), $"rel.readmEncounterGrpNum")).as("rrank")
      )
      .where($"rrank" === lit(1))
      .select(
        $"GROUPID",
        $"ENCOUNTER_GRP_NUM",
        $"ENCOUNTER_GRP_REL_TYPE",
        $"REL_ENCOUNTER_GRP_NUM"
      ).as[encounter_grp_rel]

    result.toDF()
  }
}

// Maps to TEMP_ENCOUNTER_GRP_REL29
object TEMP_ENCOUNTER_GRP_REL_CH002784 extends TableInfo[encounter_grp_rel] {

  override def name: String = "TEMP_ENCOUNTER_GRP_REL_CH002784"

  override def dependsOn: Set[String] = Set("ENCOUNTER_GRP_REL_BASE")

  override protected def createDataFrame(sparkSession: SparkSession,
                                         loadedDependencies: Map[String, DataFrame],
                                         udfMap: Map[String, UserDefinedFunctionForDataLoader],
                                         runtimeVariables: RuntimeVariables): DataFrame = {
    import org.apache.spark.sql.functions._
    import sparkSession.implicits._

    val tempEncounterGrpBaseRel = loadedDependencies("ENCOUNTER_GRP_REL_BASE").as[temp_encounter_grp_rel_base]

    /*
    select GROUPID,ENCOUNTER_GRP_NUM,ENCOUNTER_GRP_REL_TYPE,REL_ENCOUNTER_GRP_NUM
from
(select idx.groupid, idx.ENCOUNTER_GRP_NUM, 'CH002784' as ENCOUNTER_GRP_REL_TYPE  --ED visit will be readmitted to an OBS visit with same 3-digit principal dx
  , readm.ENCOUNTER_GRP_NUM as REL_ENCOUNTER_GRP_NUM
  , row_number() over (partition by idx.ENCOUNTER_GRP_NUM
                 order by idx.ENCOUNTER_GRP_NUM,datediff(date_trunc('dd', readm.admittime), date_trunc('dd', idx.dischargetime)), readm.ENCOUNTER_GRP_NUM) as rrank
from ENCOUNTER_GRP idx
inner join ENCOUNTER_GRP readm on (idx.grp_mpi = readm.grp_mpi)
where idx.encounter_grp_type = 'CH000109'
and readm.encounter_grp_type = 'CH000107'
and date_trunc('dd', readm.admittime) > date_trunc('dd', idx.dischargetime)
and idx.prindx is not null
and substr(idx.prindx,1,3) =  substr(readm.prindx,1,3)
and idx.baseinclude = 'Y'
)
where rrank = 1
     */
    val result = tempEncounterGrpBaseRel.as("rel")
      .where(
        $"rel.idxEncounterGrpType" === lit("CH000109") &&
          $"rel.readmEncounterGrpType" === lit("CH000107") &&
          $"rel.idxPrinDx".isNotNull && substring($"rel.idxPrinDx", 1, 3) === substring($"rel.readmPrinDx", 1, 3) &&
          $"rel.idxBaseInclude" === lit("Y"))
      .select(
        $"rel.idxGroupId".as("GROUPID"),
        $"rel.idxEncounterGrpNum".as("ENCOUNTER_GRP_NUM"),
        lit("CH002784").as("ENCOUNTER_GRP_REL_TYPE"),
        $"rel.readmEncounterGrpNum".as("REL_ENCOUNTER_GRP_NUM"),
        row_number().over(Window.partitionBy($"rel.idxEncounterGrpNum")
          .orderBy($"rel.idxEncounterGrpNum", datediff(to_date($"rel.readmAdmitTime"), to_date($"rel.idxDischargeTime")), $"rel.readmEncounterGrpNum")).as("rrank")
      )
      .where($"rrank" === lit(1))
      .select(
        $"GROUPID",
        $"ENCOUNTER_GRP_NUM",
        $"ENCOUNTER_GRP_REL_TYPE",
        $"REL_ENCOUNTER_GRP_NUM"
      ).as[encounter_grp_rel]

    result.toDF()
  }
}

// Maps to TEMP_ENCOUNTER_GRP_REL30
object TEMP_ENCOUNTER_GRP_REL_CH003537 extends TableInfo[encounter_grp_rel] {

  override def name: String = "TEMP_ENCOUNTER_GRP_REL_CH003537"

  override def dependsOn: Set[String] = Set("ENCOUNTER_GRP_REL_BASE")

  override protected def createDataFrame(sparkSession: SparkSession,
                                         loadedDependencies: Map[String, DataFrame],
                                         udfMap: Map[String, UserDefinedFunctionForDataLoader],
                                         runtimeVariables: RuntimeVariables): DataFrame = {
    import org.apache.spark.sql.functions._
    import sparkSession.implicits._

    val tempEncounterGrpBaseRel = loadedDependencies("ENCOUNTER_GRP_REL_BASE").as[temp_encounter_grp_rel_base]

    /*
    select GROUPID,ENCOUNTER_GRP_NUM,ENCOUNTER_GRP_REL_TYPE,REL_ENCOUNTER_GRP_NUM
from
(select idx.groupid, idx.ENCOUNTER_GRP_NUM, 'CH003537' as ENCOUNTER_GRP_REL_TYPE --IP to ED cms any dx
, readm.ENCOUNTER_GRP_NUM as REL_ENCOUNTER_GRP_NUM
, row_number() over (partition by idx.ENCOUNTER_GRP_NUM
order by idx.ENCOUNTER_GRP_NUM,datediff(date_trunc('dd', readm.admittime), date_trunc('dd', idx.dischargetime)), readm.ENCOUNTER_GRP_NUM) as rrank
from coalesce(ENCOUNTER_GRP idx
inner join ENCOUNTER_GRP readm on (idx.grp_mpi = readm.grp_mpi)
where idx.encounter_grp_type = 'CH000106'
and readm.encounter_grp_type = 'CH000109'
and date_trunc('dd', readm.admittime) > date_trunc('dd', idx.dischargetime)
and idx.cmsinclude = 'Y'
)
where rrank = 1
     */
    val result = tempEncounterGrpBaseRel.as("rel")
      .where(
        $"rel.idxEncounterGrpType" === lit("CH000106") &&
          $"rel.readmEncounterGrpType" === lit("CH000109") &&
          $"rel.idxCMSInclude" === lit("Y"))
      .select(
        $"rel.idxGroupId".as("GROUPID"),
        $"rel.idxEncounterGrpNum".as("ENCOUNTER_GRP_NUM"),
        lit("CH003537").as("ENCOUNTER_GRP_REL_TYPE"),
        $"rel.readmEncounterGrpNum".as("REL_ENCOUNTER_GRP_NUM"),
        row_number().over(Window.partitionBy($"rel.idxEncounterGrpNum")
          .orderBy($"rel.idxEncounterGrpNum", datediff(to_date($"rel.readmAdmitTime"), to_date($"rel.idxDischargeTime")), $"rel.readmEncounterGrpNum")).as("rrank")
      )
      .where($"rrank" === lit(1))
      .select(
        $"GROUPID",
        $"ENCOUNTER_GRP_NUM",
        $"ENCOUNTER_GRP_REL_TYPE",
        $"REL_ENCOUNTER_GRP_NUM"
      ).as[encounter_grp_rel]

    result.toDF()
  }
}

// Maps to TEMP_ENCOUNTER_GRP_REL31
object TEMP_ENCOUNTER_GRP_REL_CH003538 extends TableInfo[encounter_grp_rel] {

  override def name: String = "TEMP_ENCOUNTER_GRP_REL_CH003538"

  override def dependsOn: Set[String] = Set("ENCOUNTER_GRP_REL_BASE")

  override protected def createDataFrame(sparkSession: SparkSession,
                                         loadedDependencies: Map[String, DataFrame],
                                         udfMap: Map[String, UserDefinedFunctionForDataLoader],
                                         runtimeVariables: RuntimeVariables): DataFrame = {
    import org.apache.spark.sql.functions._
    import sparkSession.implicits._

    val tempEncounterGrpBaseRel = loadedDependencies("ENCOUNTER_GRP_REL_BASE").as[temp_encounter_grp_rel_base]

    /*
 select GROUPID,ENCOUNTER_GRP_NUM,ENCOUNTER_GRP_REL_TYPE,REL_ENCOUNTER_GRP_NUM
from
(select idx.groupid, idx.ENCOUNTER_GRP_NUM, 'CH003538' as ENCOUNTER_GRP_REL_TYPE --IP to ED cms any dx
, readm.ENCOUNTER_GRP_NUM as REL_ENCOUNTER_GRP_NUM
, row_number() over (partition by idx.ENCOUNTER_GRP_NUM
order by idx.ENCOUNTER_GRP_NUM,datediff(date_trunc('dd', readm.admittime), date_trunc('dd', idx.dischargetime)), readm.ENCOUNTER_GRP_NUM) as rrank
from ENCOUNTER_GRP idx
inner join ENCOUNTER_GRP readm on (idx.grp_mpi = readm.grp_mpi)
where idx.encounter_grp_type = 'CH000106'
and readm.encounter_grp_type = 'CH000107'
and date_trunc('dd', readm.admittime) > date_trunc('dd', idx.dischargetime)
and idx.cmsinclude = 'Y'
)
where rrank = 1
     */
    val result = tempEncounterGrpBaseRel.as("rel")
      .where(
        $"rel.idxEncounterGrpType" === lit("CH000106") &&
          $"rel.readmEncounterGrpType" === lit("CH000107") &&
          $"rel.idxCMSInclude" === lit("Y"))
      .select(
        $"rel.idxGroupId".as("GROUPID"),
        $"rel.idxEncounterGrpNum".as("ENCOUNTER_GRP_NUM"),
        lit("CH003538").as("ENCOUNTER_GRP_REL_TYPE"),
        $"rel.readmEncounterGrpNum".as("REL_ENCOUNTER_GRP_NUM"),
        row_number().over(Window.partitionBy($"rel.idxEncounterGrpNum")
          .orderBy($"rel.idxEncounterGrpNum", datediff(to_date($"rel.readmAdmitTime"), to_date($"rel.idxDischargeTime")), $"rel.readmEncounterGrpNum")).as("rrank")
      )
      .where($"rrank" === lit(1))
      .select(
        $"GROUPID",
        $"ENCOUNTER_GRP_NUM",
        $"ENCOUNTER_GRP_REL_TYPE",
        $"REL_ENCOUNTER_GRP_NUM"
      ).as[encounter_grp_rel]

    result.toDF()
  }
}