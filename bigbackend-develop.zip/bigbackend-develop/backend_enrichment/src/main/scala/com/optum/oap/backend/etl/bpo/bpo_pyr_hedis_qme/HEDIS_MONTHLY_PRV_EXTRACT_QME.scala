package com.optum.oap.backend.etl.bpo.bpo_pyr_hedis_qme

import com.optum.oap.backend.cdrTempModel.{hedis_monthly_prv_extract_qme, hedis_qme_specialty}
import com.optum.oap.backend.etl.patient_matching.PATIENT_MPI_UTILS.BAD_SSN_RESOURCENAME
import com.optum.oap.cdr.models.pp_bpo_provider_detail
import com.optum.oap.sparkdataloader.{RuntimeVariables, TableInfo, UserDefinedFunctionForDataLoader}
import org.apache.spark.sql.functions._
import org.apache.spark.sql.types.StringType
import org.apache.spark.sql.{DataFrame, SparkSession}

import scala.util.Try

object HEDIS_MONTHLY_PRV_EXTRACT_QME extends TableInfo[hedis_monthly_prv_extract_qme] {

  override def dependsOn: Set[String] = Set("PP_BPO_PROVIDER_DETAIL")

  override def name = "HEDIS_MONTHLY_PRV_EXTRACT_QME"

  override def createDataFrame(sparkSession: SparkSession,
                               loadedDependencies: Map[String, DataFrame],
                               udfMap: Map[String, UserDefinedFunctionForDataLoader],
                               runtimeVariables: RuntimeVariables): DataFrame = {

      import sparkSession.implicits._

    val hedisQmeSpecialty = "hedis_qme_specialty.txt"

    val pp_bpo_provider_detail = loadedDependencies("PP_BPO_PROVIDER_DETAIL").as[pp_bpo_provider_detail]

    val hedisQmeSpecialtyDf: DataFrame = {
      val resPath = this.getClass.getClassLoader.getResourceAsStream(hedisQmeSpecialty)
      val res = scala.io.Source.fromInputStream(resPath).getLines
        .map(row => row.split('|'))
        .drop(1)
        .map(row => hedis_qme_specialty(row(0), row(1), Try(row(2)).getOrElse(null), Try(row(3)).getOrElse(null)))
      res.toSeq.toDF()
    }
     pp_bpo_provider_detail.as("prov_detail")
       .join(hedisQmeSpecialtyDf.as("spec"), Seq("specialty"), "left")
       .select(
          $"PROVIDERID".as("ProviderID"),
          $"NPI".as("NationalProviderIdentifier"),
          $"DEA".as("DEANumber"),
          $"PROVIDERNAME".as("Name"),
          $"PROVIDERFIRSTNAME".as("FirstName"),
          $"PROVIDERLASTNAME".as("LastName"),
          $"SPECIALTY".as("SpecialtyCode"),
          $"SECONDARYSPECIALTY".as("SecondarySpecialtyCode"),
          $"PCPFLAG".as("IsPCP"),
          $"HEALTHPLANSOURCE".as("HealthPlanSource"),
          lit(null).cast(StringType).as("MapSourceCode"),
          coalesce($"prov_detail.THIRD_SPECIALTY", $"spec.THIRD_SPECIALTY").as("ThirdSpecialtyCode"),
          coalesce($"prov_detail.FOURTH_SPECIALTY", $"spec.FOURTH_SPECIALTY").as("FourthSpecialtyCode"),
          coalesce($"prov_detail.FIFTH_SPECIALTY", $"spec.FIFTH_SPECIALTY").as("FifthSpecialtyCode"),
          $"PROV_TIN".as("TIN"),
          lit(null).cast(StringType).as("CMSHospitalID"),
          lit(null).cast(StringType).as("ProviderTypeCode"),
          lit(null).cast(StringType).as("IsChartChase")
     )
  }

}
