package com.optum.oap.backend.etl.enrichment

import com.optum.oap.backend.etl.common.MapMasterIds
import com.optum.oap.backend.loader.EnrichmentRunTimeVariables
import com.optum.oap.cdr.models.{int_claim_member, map_predicate_values, patient, patient_attribute, patient_mpi}
import com.optum.oap.sparkdataloader.{RuntimeVariables, TableInfo, UserDefinedFunctionForDataLoader}
import org.apache.spark.sql.{DataFrame, SparkSession}
import org.slf4j.LoggerFactory
import org.apache.spark.sql.functions._

object PATIENT_ATTRIBUTE extends TableInfo[patient_attribute] {

  val log = LoggerFactory.getLogger(this.getClass)

  override def dependsOn = Set("CDR_FE_PATIENT_ATTRIBUTE", "ICPM_PATIENT_ATTRIBUTE", "PATIENT_MPI", "INT_CLAIM_MEMBER", "MAP_PREDICATE_VALUES", "PATIENT")

  private val noAliasCols = List("datasrc", "contract_id")

  override def name = "PATIENT_ATTRIBUTE"

  override def saveDataFrameToParquet: Boolean = true

  override def partitions: Int = 32

  override def skipTable: Boolean = false

  override def ignoreExtraColumnsInDataFrame: Boolean = true

  override def createDataFrame(sparkSession: SparkSession,
                               loadedDependencies: Map[String, DataFrame],
                               udfMap: Map[String, UserDefinedFunctionForDataLoader],
                               runtimeVariables: RuntimeVariables): DataFrame = {
    import sparkSession.implicits._

    val patient_attributeIn1 = loadedDependencies("CDR_FE_PATIENT_ATTRIBUTE").drop("row_source","modified_date").as[patient_attribute]
    val patient_attributeIcpm = loadedDependencies("ICPM_PATIENT_ATTRIBUTE").as[patient_attribute]
    val patient_attributeDf = patient_attributeIn1.unionByName(patient_attributeIcpm)
    val patXref = loadedDependencies("PATIENT_MPI").as[patient_mpi]
    val intClaimMember = loadedDependencies("INT_CLAIM_MEMBER").as[int_claim_member]
    val mapPredicateValues = broadcast(loadedDependencies("MAP_PREDICATE_VALUES")).as[map_predicate_values]
    val patient = loadedDependencies("PATIENT").as[patient]

    val grpId = runtimeVariables.asInstanceOf[EnrichmentRunTimeVariables].clientId

    val patient_attributeIn = patient_attributeDf
      .select(
        $"attribute_type_cui", $"attribute_value", $"client_ds_id", $"contract_id",
        $"datasrc", $"eff_date", $"end_date", $"groupid", $"grp_mpi", $"hgpid", $"patientid"
      )

    val copyCustAttrGrps = Set("H623622", "H218562")

    val patientAttributeWithCustAttr = if (copyCustAttrGrps.contains(grpId)) {
      val currentRecs = patient_attributeIn.
        where($"attribute_type_cui".isin(List("CH004024", "CH004025", "CH004026", "CH004027", "CH004028", "CH004029"):_*))

      val additionalRecords = currentRecs
        .withColumn("attribute_type_cui", when($"attribute_type_cui" === lit("CH004024"), lit("CH002785"))
          .when($"attribute_type_cui" === lit("CH004025"), lit("CH002786"))
          .when($"attribute_type_cui" === lit("CH004026"), lit("CH002787"))
          .when($"attribute_type_cui" === lit("CH004027"), lit("CH002788"))
          .when($"attribute_type_cui" === lit("CH004028"), lit("CH002949"))
          .when($"attribute_type_cui" === lit("CH004029"), lit("CH002950"))
          .otherwise($"attribute_type_cui"))

      patient_attributeIn.unionByName(additionalRecords)
    } else {
      patient_attributeIn
    }

    val aggExprs = patient.columns.diff(List("groupid", "client_ds_id", "patientid")).map(x => min(x).alias(x))
    val patientClause = patient
      .groupBy($"groupid", $"client_ds_id", $"patientid")
      .agg(aggExprs.head, aggExprs.tail: _*)

    val mappedPatientAttribute = MapMasterIds.mapPatientIds(patientAttributeWithCustAttr.toDF, patXref.toDF, false)

    val cols = getSelectList(mappedPatientAttribute.columns.toSet, patientClause.columns.toList, noAliasCols)

    val maxEnddates = intClaimMember
      .groupBy($"client_ds_id")
      .agg(max($"member_end_date").as("member_end_date"))
      .select($"client_ds_id", $"member_end_date")

    val resultDf = patientClause.as("pc")
      .join(mapPredicateValues.as("mpv"),
        $"pc.client_ds_id" === $"mpv.client_ds_id" && $"pc.groupid" === $"mpv.groupid" && $"data_src" === lit
        ("CDR_CDSID") && $"entity" === lit("PATIENT_ATTRIBUTE") && $"table_name" === lit("PATIENT"), "inner")
      .join(intClaimMember.as("cm"),
        $"pc.patientid" === $"cm.member_id" && $"pc.client_ds_id" === $"cm.client_ds_id" && $"mpv.column_name".isin(
          lit("CH003512"), lit("CH003999")), "left_outer")
      .join(maxEnddates.as("ed"),
        $"pc.client_ds_id" === $"ed.client_ds_id", "left_outer")
      .drop("datasrc", "contract_id")
      .withColumn("attribute_type_cui", $"mpv.column_name")
      .withColumn("attribute_value", $"mpv.column_value")
      .withColumn("datasrc", lit("CDR_CDSID"))
      .withColumn("contract_id", lit(null))
      .withColumn("end_date", when($"cm.member_end_date" === $"ed.member_end_date", lit(null))
        .otherwise($"cm.member_end_date"))
      .withColumn("eff_date", $"cm.member_eff_date")
      .select(cols.head, cols.tail: _*)

    mappedPatientAttribute.unionByName(resultDf).distinct

  }

  def getSelectList(sourceCols: Set[String], aliasCols: List[String], noAliasCols: List[String]): Array[String] = {
    sourceCols.map(s => if (aliasCols.contains(s) && !noAliasCols.contains(s)) "pc." + s else s).toArray
  }

}
