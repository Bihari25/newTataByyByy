package com.optum.oap.backend.etl.enrichment

import com.optum.oap.backend.etl.common.{MapMasterIds, MapMedication}
import com.optum.oap.backend.loader.EnrichmentRunTimeVariables
import com.optum.oap.cdr.models.{allergy, patient_mpi, zh_med_map_dcc}
import com.optum.oap.sparkdataloader.{RuntimeVariables, TableInfo, UserDefinedFunctionForDataLoader}
import org.apache.spark.sql.functions.broadcast
import org.apache.spark.sql.{DataFrame, SparkSession}
import org.slf4j.LoggerFactory

object ALLERGY extends TableInfo[allergy] {

  val log = LoggerFactory.getLogger(this.getClass)

  override def dependsOn = Set("CDR_FE_ALLERGY", "PATIENT_MPI", "ZH_MED_MAP_DCC")

  override def name = "ALLERGY"

  override def saveDataFrameToParquet: Boolean = true

  override def partitions: Int = 32

  override def skipTable: Boolean = false

  override def ignoreExtraColumnsInDataFrame: Boolean = true

  override def createDataFrame(sparkSession: SparkSession,
                               loadedDependencies: Map[String, DataFrame],
                               udfMap: Map[String, UserDefinedFunctionForDataLoader],
                               runtimeVariables: RuntimeVariables): DataFrame = {
    import sparkSession.implicits._

    val allergyIn = loadedDependencies("CDR_FE_ALLERGY").as[allergy]
    val patXref = loadedDependencies("PATIENT_MPI").as[patient_mpi]
    val mapDccDf = broadcast(loadedDependencies("ZH_MED_MAP_DCC")).as[zh_med_map_dcc]

    val mappedAllergyIdDf = MapMasterIds.mapPatientIds(allergyIn.toDF, patXref.toDF, false)
    val partitionMultiplier = EnrichmentRunTimeVariables(runtimeVariables).partitionMultiplier
    val repNum = Math.ceil(partitions * partitionMultiplier).toInt
    val repartitionedAllergy = mappedAllergyIdDf.repartition(repNum, $"groupid", $"datasrc", $"client_ds_id", $"localallergencd")
    MapMedication.applyMedMap(repartitionedAllergy, false, mapDccDf.toDF(), null, "localallergencd", dccFlag = true)

  }


}
