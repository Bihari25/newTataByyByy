package com.optum.oap.backend.etl.enrichment

import com.optum.oap.backend.loader.EnrichmentRunTimeVariables
import com.optum.oap.backend.cdrTempModel.{concept_event_2, concept_event_result_parent_2, observation_nlp_smoking}
import com.optum.oap.cdr.models.zcm_obstype_code
import com.optum.oap.sparkdataloader.{RuntimeVariables, TableInfo, UserDefinedFunctionForDataLoader}
import org.apache.spark.sql.functions._
import org.apache.spark.sql.types.{IntegerType, LongType, StringType}
import org.apache.spark.sql.{DataFrame, Dataset, SparkSession}

object OBSERVATION_NLP_SMOKING extends TableInfo[observation_nlp_smoking] {
  override def dependsOn = Set("CONCEPT_EVENT_RESULT_PARENT_2", "CONCEPT_EVENT_2", "ZCM_OBSTYPE_CODE")

  override def name = "OBSERVATION_NLP_SMOKING"

  override def partitions: Int = 128

  override def ignoreExtraColumnsInDataFrame: Boolean = true

  override def createDataFrame(sparkSession: SparkSession,
                               loadedDependencies: Map[String, DataFrame],
                               udfMap: Map[String, UserDefinedFunctionForDataLoader],
                               runtimeVariables: RuntimeVariables): DataFrame = {
    import sparkSession.implicits._

    val zcmObstypeCode = broadcast(loadedDependencies("ZCM_OBSTYPE_CODE")).as[zcm_obstype_code]
    val partitionMultiplier = EnrichmentRunTimeVariables(runtimeVariables).partitionMultiplier

    val grpid = EnrichmentRunTimeVariables(runtimeVariables).clientId
    // handle groups with existing NLP data that has null cdsid (from SOA files).  TODO re-evaluate if this is still required with SOA team
    val cdsid_df = broadcast(Seq(grpid match {
      case "H406239" => "721"
      case "H770635" => "45"
      case "H973241" => "1201"
      case _ => null
    }).toDF("default_cdsid"))

    val lConceptAll = loadedDependencies("CONCEPT_EVENT_2")
      .where($"project" === lit("smoking_status"))
      .as[concept_event_2]

    // get max version per project
    val lConceptMaxVersion = broadcast(lConceptAll
      .groupBy("project")
      .agg(max("project_version").as("project_version")))
    // keep only records for max version
    val lConcept = lConceptAll.as("all")
      .join(lConceptMaxVersion.as("max"), $"all.project" === $"max.project" && $"all.project_version" === $"max.project_version", "inner")
      .select($"all.*")
      .as[concept_event_2]

    // keep only records for max version
    val lConceptParentLatest = loadedDependencies("CONCEPT_EVENT_RESULT_PARENT_2")
      .where($"project" === lit("smoking_status"))
      .as("all")
      .join(lConceptMaxVersion.as("max"), $"all.project" === $"max.project" && $"all.project_version" === $"max.project_version", "inner")
      .select($"all.*")
      .as[concept_event_result_parent_2]

    val anchorSet = lConceptParentLatest.where($"par_concept_event_result_key".isNull && $"concept_nm" === "smoking")
      .groupBy($"docid", $"concept_event_result_key")
      .agg(max($"concept_normalized_val").as("anchor"))  //use max to guarantee we get the same row every time, "first" won't

    val statusSet = lConceptParentLatest.where($"par_concept_event_result_key".isNotNull && $"concept_nm".like("status_%"))
      .as[concept_event_result_parent_2]

    val anchorAndStatusSet = anchorSet.as("a")
      .join(statusSet.as("s"), ($"a.concept_event_result_key" === $"s.par_concept_event_result_key"), "inner")
      .select($"s.docid", $"s.concept_event_result_frameid",  $"s.project", concat($"a.anchor", lit("_"), $"s.concept_nm").as("localresult")
      )

    val tempStatusSmoke = anchorAndStatusSet.as("p0")
      .join(lConceptParentLatest.as("ch0"), $"p0.concept_event_result_frameid" === $"ch0.concept_event_result_frameid" && $"ch0.concept_nm" === "date_smoking", "left")
      .select($"p0.docid", $"p0.project", $"p0.localresult",
        when($"ch0.concept_dt_type" === lit("unknown"), null).otherwise($"ch0.concept_dt_guess").as("resultdate")
      )

    val statusSmokeSet = tempStatusSmoke.as("t")
      .join(lConcept.as("c"), $"c.docid" === $"t.docid", "inner")
      .select(
        $"c.groupid",
        $"c.patientid",
        when($"c.encounterid".like("%?%"), null).otherwise($"c.encounterid").as("encounterid"),
        $"c.encounterdate".as("obsdate"),
        $"c.client_ds_id".cast(IntegerType).as("client_ds_id"),
        $"t.project".as("localcode"),
        lit("nlp").as("datasrc"),
        $"t.localresult",
        $"t.resultdate"
      ).distinct()

    val otherSet = lConceptParentLatest
      .where($"par_concept_event_result_key".isNotNull && $"concept_normalized_val".isNotNull && $"concept_nm" =!= lit("date_smoking") && !$"concept_nm".like("status%") )
      .select($"docid", $"concept_event_result_frameid", $"concept_nm".as("localcode"), $"concept_normalized_val".as("localresult"))

    val tempOtherSmoke = otherSet.as("p1")
      .join(lConceptParentLatest.as("ch1"), $"p1.concept_event_result_frameid" === $"ch1.concept_event_result_frameid" && $"ch1.concept_nm" === lit("date_smoking"), "left")
      .select($"p1.docid", $"p1.localcode", $"p1.localresult",
        when($"ch1.concept_dt_type" === lit("unknown"), null).otherwise($"ch1.concept_dt_guess").as("resultdate")
      )

    val otherSmokeAllSet = tempOtherSmoke.as("t1")
      .join(lConcept.as("c1"), $"c1.docid" === $"t1.docid", "inner")
      .select(
        $"c1.groupid",
        $"c1.patientid",
        when($"c1.encounterid".like("%?%"), null).otherwise($"c1.encounterid").as("encounterid"),
        $"c1.encounterdate".as("obsdate"),
        $"c1.client_ds_id".cast(IntegerType).as("client_ds_id"),
        $"t1.localcode",
        lit("nlp").as("datasrc"),
        $"t1.localresult",
        $"t1.resultdate"
      ).distinct()

    val observationNlpSmoking = statusSmokeSet.union(otherSmokeAllSet)

    observationNlpSmoking.as("n")
      .join(zcmObstypeCode.as("zcm"), $"zcm.groupid" === $"n.groupid" && $"zcm.datasrc" === $"n.datasrc" && upper($"zcm.obscode") === upper($"n.localcode"), "inner")
      .select(
      $"n.client_ds_id",
      $"n.datasrc",
      $"n.encounterid",
      lit(null).cast(StringType).as("facilityid"),
      $"n.groupid",
      lit(null).cast(StringType).as("grp_mpi"),
      lit(null).cast(LongType).as("hgpid"),
      lit(null).cast(StringType).as("local_method_cd"),
      lit(null).cast(StringType).as("local_method_desc"),
      lit(null).cast(StringType).as("local_obs_desc"),
      lit(null).cast(StringType).as("local_obs_type_cd"),
      $"zcm.localunit".as("local_obs_unit"),
      $"n.localcode".as("localcode"),
      $"n.localresult",
      to_timestamp($"n.obsdate", "yyyyMMdd").as("obsdate"),
      $"n.localresult".as("obsresult"),
      $"zcm.obstype",
      $"n.patientid",
      to_timestamp($"n.resultdate", "yyyyMMdd").as("resultdate"),
      lit(null).cast(StringType).as("statuscode"),
      $"obstype_std_units".as("std_obs_unit")
    ).toDF()

  }
}
