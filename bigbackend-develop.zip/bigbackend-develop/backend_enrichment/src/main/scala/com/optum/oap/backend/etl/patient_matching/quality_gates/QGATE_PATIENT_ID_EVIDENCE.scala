package com.optum.oap.backend.etl.patient_matching.quality_gates

import com.optum.oap.backend.cdrTempModel.{qgate_patient_id_status, pat_match_prep}
import com.optum.oap.backend.etl.common.CDRConstants
import com.optum.oap.cdr.models._
import com.optum.oap.sparkdataloader.{RuntimeVariables, TableInfo, UserDefinedFunctionForDataLoader}
import org.apache.spark.sql.functions.broadcast
import org.apache.spark.sql.{DataFrame, SparkSession}

object QGATE_PATIENT_ID_EVIDENCE extends TableInfo[qgate_patient_id_evidence] {
  override def dependsOn = Set("QGATE_PATIENT_ID_STATUS", "QGATE_PATIENT_ID_SUSPECTS", "PAT_MATCH_PREP", "CDR_FE_PATIENTADDR", "PATIENTDETAIL", "MAP_GENDER", "ICPM_PATIENTADDR")
  override def name = "QGATE_PATIENT_ID_EVIDENCE"

  override def createDataFrame(sparkSession: SparkSession,
                               loadedDependencies: Map[String, DataFrame],
                               udfMap: Map[String, UserDefinedFunctionForDataLoader],
                               runtimeVariables: RuntimeVariables): DataFrame = {
    import sparkSession.implicits._

    val patStatus = loadedDependencies("QGATE_PATIENT_ID_STATUS")
      .where($"status_cd".isInCollection(CDRConstants.CLEARED_AND_REFFERED_2_CLIENT_STATUS_IDS)).as[qgate_patient_id_status]
    val patSuspects = loadedDependencies("QGATE_PATIENT_ID_SUSPECTS").as[qgate_patient_id_suspects]
    val patAddr1 = loadedDependencies("CDR_FE_PATIENTADDR").drop("row_source","modified_date").as[patientaddr]
    val icpmpatientAddr = loadedDependencies("ICPM_PATIENTADDR").drop("row_source","modified_date").as[patientaddr]
    val patAddr = patAddr1.unionByName(icpmpatientAddr)
    val patDetail = loadedDependencies("PATIENTDETAIL")
      .where($"patientdetailtype" === "GENDER").as[patientdetail]
    val mapGender = broadcast(loadedDependencies("MAP_GENDER").as[map_gender])
    val tempPatMatchPrep = loadedDependencies("PAT_MATCH_PREP").as[pat_match_prep]

    val ids2chk = patSuspects.as("s")
      .join(patStatus.as("prev"), Seq("patientid", "client_ds_id"), "left")
      .where($"prev.groupid".isNull)
      .select($"s.groupid", $"s.client_ds_id", $"s.patientid").distinct

    tempPatMatchPrep.as("pts")
      .join(ids2chk.as("bad"), Seq("client_ds_id", "patientid"))
      .join(patAddr.as("pad"), Seq("client_ds_id", "patientid"), "left")
      .join(patDetail.as("pdet"), Seq("client_ds_id", "patientid"), "left")
      .join(mapGender.as("mg"), $"pdet.localvalue" === $"mg.mnemonic", "left")
      .select($"pts.groupid", $"pts.client_ds_id", $"pts.patientid", $"pts.dob",
        $"pts.fname".as("first_name"),
        $"pts.lname".as("last_name"),
        $"mg.cui".as("gender"),
        $"pad.address_line1".as("street_addr"),
        $"pad.city", $"pad.state", $"pad.zipcode"
      ).distinct
  }
}
