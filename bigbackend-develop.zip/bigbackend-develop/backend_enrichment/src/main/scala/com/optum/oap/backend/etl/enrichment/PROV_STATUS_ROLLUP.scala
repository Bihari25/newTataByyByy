package com.optum.oap.backend.etl.enrichment

import com.optum.oap.backend.loader.EnrichmentRunTimeVariables
import com.optum.oap.cdr.models.{int_claim_pharm, int_claim_prov, prov_status_rollup,map_prov_status}
import com.optum.oap.sparkdataloader.{RuntimeVariables, TableInfo, UserDefinedFunctionForDataLoader}
import org.apache.spark.sql.expressions.Window
import org.apache.spark.sql.{DataFrame, SparkSession}
import org.slf4j.LoggerFactory
import org.apache.spark.sql.functions.{coalesce, lit, _}

object PROV_STATUS_ROLLUP extends TableInfo[prov_status_rollup] {

  private val log = LoggerFactory.getLogger(this.getClass)

  override def dependsOn = Set("CDR_FE_PROV_STATUS_ROLLUP","INT_CLAIM_PROV","INT_CLAIM_MEDICAL", "INT_CLAIM_PHARM","MAP_PROV_STATUS")

  override def name = "PROV_STATUS_ROLLUP"

  override def partitions: Int = 32

  override def createDataFrame(sparkSession: SparkSession,
                               loadedDependencies: Map[String, DataFrame],
                               udfMap: Map[String, UserDefinedFunctionForDataLoader],
                               runtimeVariables: RuntimeVariables): DataFrame = {

    import sparkSession.implicits._

    val cdrProvStatusRollup = loadedDependencies("CDR_FE_PROV_STATUS_ROLLUP").as[prov_status_rollup]

    val cdrIntClaimProv = loadedDependencies("INT_CLAIM_PROV").as[int_claim_prov]

    val intClaimPharm = loadedDependencies("INT_CLAIM_PHARM").as[int_claim_pharm]

    val mapProvStatus = broadcast(loadedDependencies("MAP_PROV_STATUS")).as[map_prov_status]

    val intClaimMedical = loadedDependencies("INT_CLAIM_MEDICAL")

    val groupId = runtimeVariables.asInstanceOf[EnrichmentRunTimeVariables].clientId

    //*PROV_STATUS_ROLLUP*
    //Origin PROV_STATUS_ROLLUP rollup table
    val cdrProvStatusRollup1 = cdrProvStatusRollup.select( $"groupid",
      $"client_ds_id",
      $"datasrc",
      $"prov_status_id",
      $"prov_status_desc",
      $"prov_status_lv2",
      $"prov_status_lv2_desc",
      $"prov_status_lv1",
      $"prov_status_lv1_desc",
      $"prov_status_rollup")

    //TAKING DISTINCT PROV_STATUS IDS FROM THE PROV_STATUS ROLLUP TABLE
    val cdrProvStatusSelect = cdrProvStatusRollup1
      .dropDuplicates("prov_status_id")

    //SELECTING RECORDS OF INT_CLAIM_PROV TABLE WHOSE PROV_STATUS IDS ARE NOT IN THE PROV_STATUS ROLLUP TABLE
    val provStatusRollup = cdrIntClaimProv.as("a").join(cdrProvStatusSelect.as("b"),$"a.prov_status_id" === $"b.prov_status_id","left")
      .select($"a.groupid"
        ,$"a.client_ds_id"
        ,lit("int_claim_prov").as("datasrc")
        ,$"a.prov_status_id"
        ,substring(concat(lit("UNDEFINED ("), $"a.prov_status_id", lit(")")),1,150).as("prov_status_desc")
        ,$"b.prov_status_lv2"
        ,$"b.prov_status_lv2_desc"
        ,$"b.prov_status_lv1"
        ,$"b.prov_status_lv1_desc"
        ,$"b.prov_status_rollup"
      )
      .where($"a.prov_status_id".isNotNull && (length($"a.prov_status_id") <= 30) && $"b.prov_status_id".isNull)
      .groupBy($"groupid", $"datasrc", $"a.prov_status_id", $"prov_status_desc",
        $"b.prov_status_lv2", $"b.prov_status_lv2_desc", $"b.prov_status_lv1",
        $"b.prov_status_lv1_desc",$"b.prov_status_rollup")
      .agg(min($"client_ds_id").as("client_ds_id"))

    //UNION THE MISSING RECORDS FETCHED FROM INT_CLAIM_PROV AND THE ORIGINAL PROV_STATUS ROLLUP TABLE
    val cdrProvStatusRollup2 = cdrProvStatusRollup1.unionByName(provStatusRollup)

    //TAKING DISTINCT PROV_STATUS IDS FROM THE UNION PROV_STATUS ROLLUP TABLE
    val cdrProvStatusSelect2 = cdrProvStatusRollup2
      .dropDuplicates("prov_status_id")

    //SELECTING RECORDS OF INT_CLAIM_MEDICAL TABLE WHOSE PROV_STATUS IDS ARE NOT IN THE PROV_STATUS ROLLUP TABLE
    val intClaimMedical1 = intClaimMedical.as("a").join(cdrProvStatusSelect2.as("b"),$"a.serv_prov_status_id" === $"b.prov_status_id","left")
      .select($"a.groupid"
        ,$"a.client_ds_id"
        ,$"a.serv_prov_status_id".as("prov_status_id")
        ,lit("int_claim_medical").as("datasrc")
        ,substring(concat(lit("UNDEFINED ("), $"a.serv_prov_status_id", lit(")")),1,150).as("prov_status_desc")
        ,$"b.prov_status_lv2"
        ,$"b.prov_status_lv2_desc"
        ,$"b.prov_status_lv1"
        ,$"b.prov_status_lv1_desc"
        ,$"b.prov_status_rollup")
      .where($"a.serv_prov_status_id".isNotNull && (length($"a.serv_prov_status_id") <= 30) && $"b.prov_status_id".isNull)
      .groupBy($"groupid",$"prov_status_id",$"datasrc",$"prov_status_desc",
        $"b.prov_status_lv2",$"b.prov_status_lv2_desc",$"b.prov_status_lv1",$"b.prov_status_lv1_desc",$"b.prov_status_rollup")
      .agg(min($"client_ds_id").as("client_ds_id"))

    //UNION THE MISSING RECORDS FETCHED FROM INT_CLAIM_MEDICAL AND THE UNIONED PROV_STATUS ROLLUP and INT_CLAIM_PROV TABLES
    val cdrProvStatusRollup3 = cdrProvStatusRollup2.unionByName(intClaimMedical1)

    //TAKING DISTINCT PROV_STATUS IDS FROM THE UNION ROLLUP TABLE
    val cdrProvStatusSelect3 = cdrProvStatusRollup3
      .dropDuplicates("prov_status_id")

    //SELECTING RECORDS OF INT_CLAIM_MEDICAL TABLE WHOSE PROV_STATUS IDS ARE NOT IN THE INTCLAIMMEMBER  TABLE
    val intClaimPharm1 = intClaimPharm.as("a").join(cdrProvStatusSelect3.as("b"),$"a.presc_prov_status_id" === $"b.prov_status_id","left")
      .select($"a.groupid"
        ,$"a.client_ds_id"
        ,$"a.presc_prov_status_id" .as("prov_status_id")
        ,lit("int_claim_pharm").as("datasrc")
        ,substring(concat(lit("UNDEFINED ("), $"a.presc_prov_status_id", lit(")")),1,150).as("prov_status_desc")
        ,$"b.prov_status_lv2"
        ,$"b.prov_status_lv2_desc"
        ,$"b.prov_status_lv1"
        ,$"b.prov_status_lv1_desc"
        ,$"b.prov_status_rollup")
      .where($"a.presc_prov_status_id".isNotNull && (length($"a.presc_prov_status_id") <= 30) && $"b.prov_status_id".isNull)
      .groupBy($"groupid",$"prov_status_id",$"datasrc",$"prov_status_desc",
        $"b.prov_status_lv2",$"b.prov_status_lv2_desc",$"b.prov_status_lv1",$"b.prov_status_lv1_desc",$"b.prov_status_rollup")
      .agg(min($"client_ds_id").as("client_ds_id"))

    //*UNION*
    //NOW UNION THE MISSING RECORDS FETCHED FROM INT_CLAIM_PHARM AND THE UNIONED PROV_STATUS ROLLUP,INT_CLAIM_PROV, PROV_STATUS_ROLLUP TABLES
    val unionProvStatusRollup = cdrProvStatusRollup3.unionByName(intClaimPharm1)

    //APPLYING ADDITIONAL TRANSFORMATIONS ON THE UNION WITH THE FETCHED RECORDS OF INT_CLAIM_PROV AND INTCLAIMEMBER AND LOAD TO BACKEND.
    val rollup = unionProvStatusRollup.as("a").join(mapProvStatus.as("b"),($"a.prov_status_id" === $"b.localcode") && ($"b.groupid" === groupId),"left")
      .select(
        $"a.groupid"
        ,$"client_ds_id"
        ,$"datasrc"
        ,$"prov_status_id"
        ,substring(coalesce($"prov_status_desc", concat(lit("UNDEFINED ("),$"prov_status_id",lit(")"))),1,150).as("prov_status_desc")
        ,substring(coalesce($"prov_status_lv2", concat(lit("3."),$"prov_status_id")),1,30).as("prov_status_lv2")
        ,substring(when($"prov_status_lv2".isNull,coalesce($"prov_status_desc",concat(lit("UNDEFINED ("),$"prov_status_id",lit(")"))))
          .otherwise(coalesce($"prov_status_lv2_desc",concat(lit("UNDEFINED ("),$"prov_status_lv2",lit(")")))) ,1,150)
          .as("prov_status_lv2_desc")
        ,substring(coalesce($"prov_status_lv1",when($"prov_status_lv2".isNotNull,concat(lit("2."),$"prov_status_lv2"))
          .otherwise(concat(lit("3."),$"prov_status_id"))),1,30).as("prov_status_lv1")
        ,substring(when($"prov_status_lv1".isNull,
          when($"prov_status_lv2".isNull,coalesce($"prov_status_desc",concat(lit("UNDEFINED ("),$"prov_status_id",lit(")")) ))
            .otherwise(coalesce($"prov_status_lv2_desc",concat(lit("UNDEFINED ("),$"prov_status_lv2",lit(")")) )))
          .otherwise(coalesce($"prov_status_lv1_desc",concat(lit("UNDEFINED ("),$"prov_status_lv1",lit(")")))),1,150).as("prov_status_lv1_desc")
        ,when(upper(when($"prov_status_rollup" === lit("0"),lit("N"))
          .otherwise(when($"prov_status_rollup" === lit("1"),lit("Y"))
            .otherwise(when($"prov_status_rollup".isNull,lit("X"))
              .otherwise($"prov_status_rollup"))))
          .isin ("Y", "N", "U") ,upper(when($"prov_status_rollup" === lit("0"),lit("N"))
          .otherwise(when($"prov_status_rollup" === lit("1"),lit("Y"))
            .otherwise($"prov_status_rollup"))))
          .otherwise($"b.mappedvalue")
          .as("prov_status_rollup")
        ,row_number().over(Window.partitionBy($"prov_status_id")
          .orderBy(
            when($"prov_status_desc".isNotNull, lit(0)).otherwise(lit(1)),
            when($"prov_status_lv2".isNotNull, lit(0)).otherwise(lit(1)),
            when($"prov_status_lv1".isNotNull, lit(0)).otherwise(lit(1)),
            $"prov_status_desc",$"prov_status_lv2",$"prov_status_lv1", $"client_ds_id"
          )).as("rn")
      )
      .where($"a.prov_status_id".isNotNull && (length($"a.prov_status_id") <=30) && ($"rn"=== 1))
      .drop($"rn")

    rollup.toDF()
  }
}