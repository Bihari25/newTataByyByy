package com.optum.oap.backend.etl.summary

import com.optum.oap.cdr.models.{labresult, v_labcode_results, zh_lab_dict}
import com.optum.oap.sparkdataloader.{RuntimeVariables, TableInfo, UserDefinedFunctionForDataLoader}
import org.apache.spark.sql.functions.{lit, _}
import org.apache.spark.sql.types.{DoubleType, StringType}
import org.apache.spark.sql.{DataFrame, SparkSession}
import org.slf4j.LoggerFactory

object V_LABCODE_RESULTS extends TableInfo[v_labcode_results] {

  val log = LoggerFactory.getLogger(this.getClass)

  override def dependsOn = Set("ZH_LAB_DICT", "LABRESULT")

  override def name = "V_LABCODE_RESULTS"

  override def createDataFrame(sparkSession: SparkSession,
                               loadedDependencies: Map[String, DataFrame],
                               udfMap: Map[String, UserDefinedFunctionForDataLoader],
                               runtimeVariables: RuntimeVariables): DataFrame = {

    import sparkSession.implicits._


    val lab_dict = broadcast(loadedDependencies("ZH_LAB_DICT")).as[zh_lab_dict]

    val d = broadcast(lab_dict
      .select('groupid, 'client_ds_id, 'localcode
        , lower('localunits).as("localunits")
        , upper('localname).as("localname")
        , upper('localdesc).as("localdesc")
        , upper('localspecimentype).as("localspecimentype")
        , upper('localbodysite).as("localbodysite")
        , upper('localdatatype).as("localdatatype")
        , upper('localrefrange).as("localrefrange")
        , 'local_loinc_code)
      .groupBy('groupid, 'client_ds_id, 'localcode, 'localunits, 'localname, 'localdesc)
      .agg(
        min('localspecimentype).as("localspecimentype")
        , min('localbodysite).as("localbodysite")
        , min('localdatatype).as("localdatatype")
        , min('localrefrange).as("localrefrange")
        , min('local_loinc_code).as("local_loinc_code"))
    )


    val lab_result = loadedDependencies("LABRESULT").as[labresult]

    val r = lab_result
      .select('groupid, 'client_ds_id, 'localcode, 'localname, 'normalrange, 'localunits, 'localunits_inferred
        , 'localtestname, 'localresult_inferred, 'localresult_numeric, 'localresult, 'local_loinc_code, 'localspecimentype)

    val joined = r.join(d, Seq("groupid", "client_ds_id", "localcode"))
      .select('groupid, 'client_ds_id, 'localcode.as("code_value")
        , upper(substring(coalesce(r("localname"), d("localname"), lit("NO NAME IN DICTIONARY")), 1, 255)).as("dict_name")
        , upper(d("localdesc")).as("dict_def")
        , upper(coalesce(r("normalrange"), when('localrefrange.isNotNull, concat(lit("["), 'localrefrange, lit("]"))).otherwise(lit(null)))).as("ref_range")
        , upper(r("localtestname")).as("order_name")
        , d("localdatatype").as("data_type")
        , coalesce(r("localspecimentype"), d("localspecimentype")).as("specimen_name")
        , d("localbodysite").as("bodysite_name")
        , coalesce(r("local_loinc_code"), when(d("local_loinc_code").isNotNull, concat(lit("["), d("local_loinc_code"), lit("]"))).otherwise(lit(null))).as("local_loinc_code")
        , coalesce(r("localunits"), r("localunits_inferred"), when(d("localunits").isNotNull, concat(lit("["), d("localunits"), lit("]"))).otherwise(lit(null))).as("unit_name")
        , coalesce(r("localresult_inferred"), r("localresult_numeric")).as("local_result_inferred")
        , r("localresult")
      )

    val diff = d.select("groupid", "client_ds_id", "localcode")
      .except(r.select("groupid", "client_ds_id", "localcode"))
    // now join original with diff to get all missing in left_join
    val df = d.join(diff, Seq("groupid", "client_ds_id", "localcode"))
      .select("groupid",
        "client_ds_id",
        "localcode",
        "localunits",
        "localname",
        "localdesc",
        "localspecimentype",
        "localbodysite",
        "localdatatype",
        "localrefrange",
        "local_loinc_code")

    val df1 = df.select('groupid, 'client_ds_id, 'localcode.as("code_value")
      , upper(substring(coalesce(df("localname"), lit("NO NAME IN DICTIONARY")), 1, 255)).as("dict_name")
      , upper(df("localdesc")).as("dict_def")
      , upper(coalesce(when('localrefrange.isNotNull, concat(lit("["), 'localrefrange, lit("]"))).otherwise(lit(null)))).as("ref_range")
      , lit(null).cast(StringType).as("order_name")
      , df("localdatatype").as("data_type")
      , df("localspecimentype").as("specimen_name")
      , df("localbodysite").as("bodysite_name")
      , when(df("local_loinc_code").isNotNull, concat(lit("["), df("local_loinc_code"), lit("]"))).otherwise(lit(null)).as("local_loinc_code")
      , when(df("localunits").isNotNull, concat(lit("["), df("localunits"), lit("]"))).otherwise(lit(null)).as("unit_name")
      , lit(null).cast(DoubleType).as("local_result_inferred")
      , lit(null).cast(StringType).as("localresult")
    )

    joined.unionByName(df1).select(
      "groupid",
      "client_ds_id",
      "code_value",
      "dict_name",
      "dict_def",
      "ref_range",
      "order_name",
      "data_type",
      "specimen_name",
      "bodysite_name",
      "local_loinc_code",
      "unit_name",
      "local_result_inferred",
      "localresult"
    )

  }
}
