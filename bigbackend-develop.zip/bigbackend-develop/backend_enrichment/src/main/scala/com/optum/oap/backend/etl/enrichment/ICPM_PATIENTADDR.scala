package com.optum.oap.backend.etl.enrichment

import com.optum.oap.cdr.models.{int_claim_member, patientaddr}
import com.optum.oap.sparkdataloader.{RuntimeVariables, TableInfo, UserDefinedFunctionForDataLoader}
import org.apache.spark.sql.functions._
import org.apache.spark.sql.types.DataTypes
import org.apache.spark.sql.{DataFrame, SparkSession}
import org.slf4j.LoggerFactory

object ICPM_PATIENTADDR extends TableInfo[patientaddr] {

  val log = LoggerFactory.getLogger(this.getClass)

  override def dependsOn = Set("INT_CLAIM_MEMBER")

  override def name = "ICPM_PATIENTADDR"

  override def createDataFrame(sparkSession: SparkSession,
                               loadedDependencies: Map[String, DataFrame],
                               udfMap: Map[String, UserDefinedFunctionForDataLoader],
                               runtimeVariables: RuntimeVariables): DataFrame = {
    import sparkSession.implicits._

    val intClaimMemberIn = loadedDependencies("INT_CLAIM_MEMBER").as[int_claim_member]

    val cdrFePatientaddr = intClaimMemberIn.filter($"member_id".isNotNull
        && (coalesce($"member_addr_2",$"member_addr_1",$"member_city").isNotNull ||
            (length(regexp_replace($"member_state_code", "[\\p{Punct}0-9 ]", "")) === 2) ||
            (length(regexp_replace($"member_zip_code", "[\\p{Punct}0-9 ]", "")) === 0 &&
          length($"member_zip_code").isin(5,9,10))
        )
        && (length(regexp_replace($"member_state_code", "[\\p{Punct}0-9 ]", "")) === 2 ||
        $"member_state_code".isNull)
      )
      .select(
      $"groupid",
      $"client_ds_id",
      $"member_id".as("patientid"),
      $"member_addr_1".as("address_line1"),
      $"member_addr_2".as("address_line2"),
      $"member_city".as("city"),
      upper(regexp_replace($"member_state_code", "[\\p{Punct}0-9 ]", "")).as("state"),
      when(length(regexp_replace($"member_zip_code", "[\\p{Punct}0-9 ]", "")) === 0
        && length($"member_zip_code").isin(5,9,10),
          when(regexp_replace($"member_zip_code", "-", "").endsWith("0000"),
            substring(regexp_replace($"member_zip_code", "-", ""),1,5))
          .otherwise(regexp_replace($"member_zip_code", "-", ""))
      ).otherwise(null).as("zipcode"),
      $"member_addr_lon".cast(DataTypes.DoubleType).as("address_longitude"),
      $"member_addr_lat".cast(DataTypes.DoubleType).as("address_latitude"),
      when(coalesce($"member_eff_date",to_date($"eligibile_member_month", "yyyyMM")).isNull
          ,to_date(lit("20050101"), "yyyyMMdd"))
        .otherwise(coalesce($"member_eff_date",to_date($"eligibile_member_month", "yyyyMM"))).as("member_eff_date")
      )

    cdrFePatientaddr.groupBy($"groupid", $"client_ds_id", $"patientid", $"address_line1", $"address_line2"
      , $"city", $"state", $"zipcode", $"address_longitude", $"address_latitude")
      .agg(max($"member_eff_date").as("address_date"),
        lit("int_claim_member").as("datasrc"),
        lit(null).cast(DataTypes.StringType).as("address_type"),
        lit(null).cast(DataTypes.StringType).as("grp_mpi"),
        lit(null).cast(DataTypes.LongType).as("hgpid")
      )
  }
}

