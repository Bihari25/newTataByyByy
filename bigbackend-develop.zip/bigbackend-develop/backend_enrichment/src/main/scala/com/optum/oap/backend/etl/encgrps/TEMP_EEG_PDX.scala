package com.optum.oap.backend.etl.encgrps

import com.optum.oap.backend.cdrTempModel.temp_eeg_pdx
import com.optum.oap.sparkdataloader.QueryAndMetadata

//pull principal diagnoses and choose one per encounter
object TEMP_EEG_PDX extends  QueryAndMetadata[temp_eeg_pdx] {

  override def name: String = "TEMP_EEG_PDX"

  override def partitions: Int = 32

  override def sparkSql: String =
    """
      |SELECT a.* from (
      |  SELECT
      |      groupid,
      |      grp_mpi,
      |      dx_timestamp,
      |      client_ds_id,
      |      encounterid,
      |      mappeddiagnosis AS prindx,
      |      codetype AS prindx_codetype,
      |      coalesce(hosp_dx_flag,'N') AS hosp_dx_flag,
      |      ROW_NUMBER() OVER(
      |          PARTITION BY groupid,client_ds_id,encounterid
      |          ORDER BY
      |              coalesce(hosp_dx_flag,'N') DESC,
      |              CASE
      |                      WHEN coalesce(dischargetime,arrivaltime) >= to_timestamp('20151001','yyyyMMdd')
      |                           AND codetype = 'ICD10' THEN 1
      |                      WHEN coalesce(dischargetime,arrivaltime) < to_timestamp('20151001','yyyyMMdd')
      |                           AND codetype = 'ICD9' THEN 1
      |                      ELSE 2
      |                  END,mappeddiagnosis
      |      ) AS dxrank
      |  FROM
      |      diagnosis
      |      INNER JOIN temp_visit_enctr USING ( groupid,
      |                                          client_ds_id,
      |                                          encounterid,
      |                                          grp_mpi )
      |  WHERE
      |      primarydiagnosis = 1
      |      AND mappeddiagnosis IS NOT NULL
      |      AND length(mappeddiagnosis) < 9
      |      AND encounterid IS NOT NULL
      |      AND grp_mpi IS NOT NULL
      |      AND codetype IN (
      |          'ICD9',
      |          'ICD10'
      |      )
      |      AND hosp_dx_flag = 'Y'
      |) a
      |WHERE dxrank = 1
    """.stripMargin

  override def dependsOn: Set[String] = Set("DIAGNOSIS","TEMP_VISIT_ENCTR")
}