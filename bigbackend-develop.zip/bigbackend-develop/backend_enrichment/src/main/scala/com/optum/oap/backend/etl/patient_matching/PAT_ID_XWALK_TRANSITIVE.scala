package com.optum.oap.backend.etl.patient_matching

import com.optum.oap.backend.etl.common.CDRConstants
import com.optum.oap.backend.loader.EnrichmentRunTimeVariables
import com.optum.oap.cdr.models.pat_id_xwalk
import com.optum.oap.sparkdataloader.{RuntimeVariables, TableInfo, UserDefinedFunctionForDataLoader}
import org.apache.spark.sql.expressions.Window
import org.apache.spark.sql.functions._
import org.apache.spark.sql.{DataFrame, SparkSession}

import java.sql.Timestamp
import java.time.LocalDateTime
import scala.annotation.tailrec
import scala.collection.mutable

/**
  * Creator: bishu
  * Date: 11/25/20
  */
object PAT_ID_XWALK_TRANSITIVE extends TableInfo[pat_id_xwalk] {

  override def dependsOn = Set("PAT_ID_XWALK")

  override def createDataFrame(sparkSession: SparkSession,
                               loadedDependencies: Map[String, DataFrame],
                               udfMap: Map[String, UserDefinedFunctionForDataLoader],
                               runtimeVariables: RuntimeVariables): DataFrame = {
    import sparkSession.implicits._

    val patIdXwalk = loadedDependencies("PAT_ID_XWALK").as[pat_id_xwalk]
    val grpid = EnrichmentRunTimeVariables(runtimeVariables).clientId

    val window = {
      if (grpid.trim.equalsIgnoreCase("H984216")) Window.partitionBy($"old_id", $"old_id_type", $"client_ds_id")
      else Window.partitionBy($"old_id", $"old_id_type")
    }

    val tempSrcDups = patIdXwalk.as("x")
      .withColumn("max_rec_date", max($"record_date").over(window))
      .where($"record_date" === $"max_rec_date")
      .where($"old_id" =!= $"new_id")
      .select(
        $"groupid",
        $"client_ds_id",
        $"old_id",
        $"old_id_type",
        $"new_id",
        $"new_id_type",
        $"record_date"
      )

    val ab_where_clause = {
      if (grpid.trim.equalsIgnoreCase("H984216")) $"a.client_ds_id" === $"b.client_ds_id"
      else $"a.groupid" === $"b.groupid"
    }

    // make non transitive relations
    val non_trans_dep = tempSrcDups.as("a")
      .join(tempSrcDups.as("b"), $"a.new_id" === $"b.old_id" && $"a.old_id_type" === $"b.old_id_type" && $"a.new_id_type" === $"b.new_id_type" && ab_where_clause, "left")
      .where(
        $"a.groupid".isNotNull &&
          $"b.groupid".isNull
      )
      .select(
        $"a.groupid",
        $"a.client_ds_id",
        $"a.old_id",
        $"a.old_id_type",
        $"a.new_id",
        $"a.new_id_type",
        $"a.record_date"
      )

    val trans_dep_part1 = tempSrcDups.as("a")
      .join(tempSrcDups.as("b"), $"a.new_id" === $"b.old_id" && $"a.old_id_type" === $"b.old_id_type" && $"a.new_id_type" === $"b.new_id_type" && ab_where_clause, "left")
      .where($"b.groupid".isNotNull)
      .select($"a.*")

    // use non transitive dependency to find the final row(top most ) of transitive relation
    val trans_dep_part2 = non_trans_dep.as("a")
      .join(trans_dep_part1.as("b"), $"a.old_id" === $"b.new_id" && $"a.old_id_type" === $"b.old_id_type" && $"a.new_id_type" === $"b.new_id_type" && ab_where_clause, "left")
      .where($"b.groupid".isNotNull)
      .select($"a.*")

    // final transitive dependency
    val trans_dep = trans_dep_part1.union(trans_dep_part2)

    val groupedByIdType = {
      if (grpid.trim.equalsIgnoreCase("H984216")) {
        trans_dep.groupBy($"client_ds_id", $"old_id_type", $"new_id_type".as("groupingkey"))
      } else {
        trans_dep.groupBy($"old_id_type", $"new_id_type".as("groupingkey"))
      }
    }
      .agg(collect_list(struct(classOf[pat_id_xwalk].getDeclaredFields.toList.withFilter(!_.isSynthetic()).map(f => $"${f.getName}"): _*)).as("patlist"))
      .as[pat_list]

    val resolvedTransitiveDependency = groupedByIdType.flatMap(x => resolveTransitiveDependency(x.patlist))
      .select(
        $"groupid",
        $"client_ds_id",
        $"old_id",
        $"old_id_type",
        $"new_id",
        $"new_id_type",
        $"record_date")

    val all_dep = non_trans_dep.union(resolvedTransitiveDependency).distinct()

    all_dep.as("x")
      .withColumn("max_rec_date", max($"record_date").over(window))
      .where($"record_date" === $"max_rec_date")
      .select(
        $"groupid",
        $"client_ds_id",
        $"old_id",
        $"old_id_type",
        $"new_id",
        $"new_id_type",
        $"record_date"
      )
  }

  // resolve dependency
  def resolveTransitiveDependency(in: Seq[pat_id_xwalk]): Seq[pat_id_xwalk] = {
    import java.time.format.DateTimeFormatter
    val formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss")

    val oldIdsMap: mutable.HashMap[String, pat_id_xwalk] = mutable.HashMap()
    val newIdsMap: mutable.HashMap[String, pat_id_xwalk] = mutable.HashMap()

    for (x <- in) yield oldIdsMap.put(x.old_id, x)
    for (y <- in) yield {
      if (newIdsMap.contains(y.new_id)) {
        val old = newIdsMap.get(y.new_id)
        if (old.get.record_date before y.record_date) {
          newIdsMap.put(y.new_id, y)
        }
      } else {
        newIdsMap.put(y.new_id, y)
      }
    }

    @tailrec
    def dependencyHelper(counter: Int, input: pat_id_xwalk, processedNewIds: Set[String]): pat_id_xwalk = {
      if (counter >= CDRConstants.PATIENT_XWALK_MAX_ITERATION) {
        throw new Exception(s"did it go in some infinite loop ? old_id= ${input.old_id} new_id = ${input.new_id} ")
      }
      else if (input.new_id.equals(input.old_id)) input
      else if (oldIdsMap.contains(input.new_id)) {

        val newinput = oldIdsMap(input.new_id)
        val currentTime = Timestamp.valueOf(LocalDateTime.now().format(formatter))

        // there shouldn't be any null record_date, in case there are just using current time.
        val inputRecordDate = if (input.record_date == null) currentTime else input.record_date
        val newInputRecordDate = if (newinput.record_date == null) currentTime else newinput.record_date

        //  !! circular relation.
        if (input.old_id.equals(newinput.new_id)) {
          // circular dependency at exact same time. Looks bad data. Life must go on. find a tiebreaker
          if (inputRecordDate.equals(newInputRecordDate)) {
            val sortedIdsArray = Array(input.old_id, input.new_id).sorted // sort the ids
            input.copy(new_id = sortedIdsArray(0), record_date = inputRecordDate)
          } else {
            if (inputRecordDate.before(newInputRecordDate)) input.copy(new_id = newinput.new_id, record_date = newInputRecordDate)
            else input
          }
        }
        else if (processedNewIds.contains(input.new_id)) {
          // there is a circular relation but also another record is pointing to circle.
          if (newInputRecordDate.before(inputRecordDate)) input
          else if (newInputRecordDate.equals(inputRecordDate)) {
            val newIdsArray = processedNewIds.toArray.sorted
            val rd2 = if (input.record_date.before(newinput.record_date)) newinput.record_date else input.record_date
            input.copy(new_id = newIdsArray(0), record_date = rd2)
          }
          else {
            val modifiedInput = input.copy(new_id = newinput.new_id, record_date = newInputRecordDate)
            dependencyHelper(counter + 1, modifiedInput, processedNewIds ++ Set(input.new_id))
          }
        }
        else if (newInputRecordDate.before(inputRecordDate)) input
        else {
          val modifiedInput = input.copy(new_id = newinput.new_id, record_date = newInputRecordDate)
          dependencyHelper(counter + 1, modifiedInput, processedNewIds ++ Set(input.new_id))
        }
      }
      else {
        if (newIdsMap.contains(input.old_id)) {
          /**
            * check if this id is mapped by something which came later.
            * e.g
            * H000000	4027	P11	MRN	EP11	MRN	2002-06-25 21:37:00
            * H000000	4027	E23	MRN	P11	MRN	2019-01-17 06:51:00
            */
          val entry = newIdsMap.get(input.old_id)
          val origInput = oldIdsMap.get(input.old_id)
          if (entry.get.record_date.after(origInput.get.record_date)) {
            val fi = input.copy(new_id = input.old_id, record_date = entry.get.record_date)
            fi
          } else input
        } else input
        //        input
      }
    }

    val mappedDependency = in.map(x => dependencyHelper(0, x, Set()))
    mappedDependency
  }

  case class pat_list(groupingkey: String, patlist: Seq[pat_id_xwalk])

}
