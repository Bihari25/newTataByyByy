package com.optum.oap.backend.etl.cdrfe

import com.optum.oap.backend.etl.cdrfe.common.{Mpi_rule}
import com.optum.oap.backend.etl.cdrfe.config.CDRFEConfigReader
import com.optum.oap.backend.etl.common.CDRConstants
import com.optum.oap.backend.loader.EnrichmentRunTimeVariables
import com.optum.oap.backend.util.ImportResources._
import org.apache.spark.sql.functions.expr

/**
  * If buildType === Monthly
  *   Copy cdr_common.txt & cdr_maps.txt from mercury location
  * If buildType === Daily
  *   Copy cdr_common.txt, cdr_delta.txt & cdr_maps.txt from mercury location
  * @param enrichmentRunTimeVariables
  */
class CDRFERegistry(val enrichmentRunTimeVariables: EnrichmentRunTimeVariables) extends CDRFEConfigReader {

  import enrichmentRunTimeVariables._

  def getCDRFEEntities: Seq[CDRFE_ENTITY] = {

    val commonModels = if (buildType.equalsIgnoreCase(CDRConstants.MONTHLY_BUILD_TYPE)) {
      CDR_COMMON_ENTITIES.map(x => x.tableName)
    } else {
      (CDR_COMMON_ENTITIES ++ CDR_DELTA_ENTITIES).map(x => x.tableName)
    }

    val mapModels = CDR_MAPS_ENTITIES.map(record => record.tableName -> record.hasGroupId).toMap
    val clientDSIds = getCDRFEConfg.map(x => {
      if (buildType.equalsIgnoreCase(CDRConstants.MONTHLY_BUILD_TYPE))
        CDRFEDataSource(x.cds_id, s"${mercuryBasePath}/${x.cds_id}/**/${cdrCycle.toUpperCase}")
      else
        CDRFEDataSource(x.cds_id, s"${mercuryBasePath}/${x.cds_id}/**/${cdrCycle.toUpperCase}/${dailyEndDate.get.toUpperCase}")
    })

    val mapsQueryRegistry = mapModels.map {
      case model if MapsWithClientId(model._1) => CDRFE_ENTITY(model._1, Seq(CDRFEDataSource(0, mercuryMapsPath)), expr(s"client_id == '$clientId'"))
      case model if MapsWithInClauseFilter(model._1) => CDRFE_ENTITY(model._1, Seq(CDRFEDataSource(0, mercuryMapsPath)), expr(s"""groupid in ('$clientId', 'ALL', 'NULL', 'HTS')"""))
      case model if model._1.equalsIgnoreCase("MPI_RULE") =>  new CDRFE_ENTITY(model._1, Seq(CDRFEDataSource(0, mercuryMapsPath))) with Mpi_rule
      case model if model._2 => CDRFE_ENTITY(model._1, Seq(CDRFEDataSource(0, mercuryMapsPath)), expr(s"groupid == '$clientId'"))
      case model => CDRFE_ENTITY(model._1, Seq(CDRFEDataSource(0, mercuryMapsPath)))
    }

    val commonQueryRegistry = commonModels.map(model => {
      clientId match {
        case _ => model match {
          case _ => CDRFE_ENTITY(model, clientDSIds)
        }
      }
    })

    commonQueryRegistry ++ mapsQueryRegistry
  }
}

case class CDRFEDataSource(cdsId: Int, dataSourcePath: String)


