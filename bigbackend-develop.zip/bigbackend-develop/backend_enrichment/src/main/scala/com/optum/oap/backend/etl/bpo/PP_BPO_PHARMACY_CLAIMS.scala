package com.optum.oap.backend.etl.bpo

import com.optum.oap.backend.cdrTempModel.{temp_bpo_calculate_params, temp_bpo_patients}
import com.optum.oap.backend.etl.bpo.BpoUtil.getBpoInputParameters
import com.optum.oap.backend.etl.common.{IsSafeToNumber, TimestampTruncate}
import com.optum.oap.cdr.models.{denied_ind_rollup, _}
import com.optum.oap.sparkdataloader.{RuntimeVariables, TableInfo, UserDefinedFunctionForDataLoader}
import org.apache.spark.sql.functions._
import org.apache.spark.sql.types.{DateType, DoubleType, IntegerType, StringType}
import org.apache.spark.sql.{DataFrame, SparkSession}

/**
  *
  * Copyright 2019 Optum Analytics
  *
  * Date: 6/11/19
  *
  * Creator: pavula1
  */
object PP_BPO_PHARMACY_CLAIMS extends TableInfo[pp_bpo_pharmacy_claims] {
  override def dependsOn = Set("RXORDER",
    "ZO_BPO_MAP_EMPLOYER",
    "MAP_GENERIC_STATUS",
    "TEMP_BPO_PATIENTS",
    "TEMP_BPO_CALCULATE_PARAMS",
    "MAP_FORMULARY_INDICATOR",
    "TEMP_PP_BPO_PROVIDER_DETAIL_SPANS",
    "ZH_PROVIDER",
    "REF_HTS_NDC_CURRENT",
    "MAP_RX_FULFILLMENT_TYPE",
    "MAP_DAW",
    "ZO_DAW",
    "DENIED_IND_ROLLUP"
  )

  override def name = "PP_BPO_PHARMACY_CLAIMS"

  override def partitions: Int = 128

  override def createDataFrame(sparkSession: SparkSession,
                               loadedDependencies: Map[String, DataFrame],
                               udfMap: Map[String, UserDefinedFunctionForDataLoader],
                               runtimeVariables: RuntimeVariables): DataFrame = {

    import com.optum.oap.backend.etl.common.Functions._
    import sparkSession.implicits._

    val tempBpoPatients = loadedDependencies("TEMP_BPO_PATIENTS").as[temp_bpo_patients]
    val rxOrder = loadedDependencies("RXORDER").as[rxorder]
    val mapEmployer = broadcast(loadedDependencies("ZO_BPO_MAP_EMPLOYER")).as[zo_bpo_map_employer]
    val mapStatus = broadcast(loadedDependencies("MAP_GENERIC_STATUS")).as[map_generic_status]
    val provDetailSpans = loadedDependencies("TEMP_PP_BPO_PROVIDER_DETAIL_SPANS").as[pp_bpo_provider_detail_spans]
    val mapIndicator = broadcast(loadedDependencies("MAP_FORMULARY_INDICATOR")).as[map_formulary_indicator]
    val tempParams = loadedDependencies("TEMP_BPO_CALCULATE_PARAMS").as[temp_bpo_calculate_params]
    val zhProvider = loadedDependencies("ZH_PROVIDER").as[zh_provider]
    val refHtsNdcCurrent = loadedDependencies("REF_HTS_NDC_CURRENT").as[ref_hts_ndc_current]
    val mapRxFulfillmentType = broadcast(loadedDependencies("MAP_RX_FULFILLMENT_TYPE")).as[map_rx_fulfillment_type]
    val zoDaw = broadcast(loadedDependencies("ZO_DAW")).as[zo_daw]
    val mapDaw = broadcast(loadedDependencies("MAP_DAW")).as[map_daw]
    val deniedIndRollup = broadcast(loadedDependencies("DENIED_IND_ROLLUP")).as[denied_ind_rollup]


    val inputParameters = getBpoInputParameters(sparkSession, tempParams)
    val extractStartDate = inputParameters.engineStartDate
    val extractEndDate = date_add(lit(inputParameters.engineEndDate),1).cast(DateType)

    val deniedIndRollup_DF = deniedIndRollup.groupBy("groupId", "denied_flag")
      .agg(max($"denied_ind_rollup").alias("mx_denied_ind_rollup"))
      .select(
        $"groupId",
        $"denied_flag",
        $"mx_denied_ind_rollup")

    val tempPatients = tempBpoPatients.select($"grp_mpi").where($"payer" === 1 && $"grp_mpi".isNotNull).distinct()

    val df1 = rxOrder.alias("clm").where(TimestampTruncate.truncate(lit("DAY"), $"clm.issuedate").between(extractStartDate, extractEndDate))
      .join(tempPatients.alias("pat"), $"pat.grp_mpi" === $"clm.grp_mpi")
      .join(mapEmployer.alias("zo_map"), $"zo_map.client_ds_id" === $"clm.client_ds_id" && $"zo_map.groupid" === $"clm.groupid")
      .join(provDetailSpans.alias("pds"),
        $"pds.providerid" === $"clm.mstrprovid".cast(StringType)
          && $"clm.issuedate".between($"pds.prov_effective_dt", $"pds.prov_end_dt"), "left_outer")
      .join(mapStatus.alias("mgs"), $"mgs.groupid" === $"clm.groupid" && $"mgs.localcode" === $"clm.generic_status", "left")
      .join(mapIndicator.alias("mfi"), $"mfi.groupid" === $"clm.groupid" && $"mfi.localcode" === $"clm.formulary_indicator", "left")
      .join(zhProvider.alias("zhp"),
        $"clm.groupid" === $"zhp.groupid"
          && $"clm.client_ds_id" === $"zhp.client_ds_id"
          && $"clm.pharmacy_id" === $"zhp.localproviderid",
        "left_outer"
      )
      .join(refHtsNdcCurrent.alias("rndc"),
        coalesce($"clm.ndc11", $"clm.mappedndc") === $"rndc.ndc"
          && $"rndc.gbo_ind".isin(lit("0"), lit("1"), lit("2"), lit("9")),
        "left_outer"
      )
      .join(mapRxFulfillmentType.alias("mprx"),
        $"clm.groupid" === $"mprx.groupid"
          && $"clm.fulfillment_type_cd" === $"mprx.localcode",
        "left_outer"
      )
      .join(mapDaw.alias("mpd"),
        $"clm.groupid" === $"mpd.groupid"
          && $"clm.localdaw" === $"mpd.mnemonic",
        "left_outer"
      )
      .join(zoDaw.alias("zod"),
        $"mpd.cui" === $"zod.hts_cui",
        "left_outer"
      )
      .join(deniedIndRollup_DF.alias("dir"),
        $"clm.groupid" === $"dir.groupid"
        && $"clm.denied_flag" === $"dir.denied_flag",
        "left_outer"
      )
      .select($"clm.groupid",
        $"clm.grp_mpi".alias("memberid"),
        TimestampTruncate.truncate(lit("DAY"), $"clm.issuedate").alias("servicedate"),
        coalesce($"ndc11", $"mappedndc").alias("ndc"),
        when(IsSafeToNumber.isSafeToNumber($"localdaysupplied"), $"localdaysupplied").otherwise(lit(0)).alias("dayssupply"),
        when(IsSafeToNumber.isSafeToNumber($"quantityperfill"), $"quantityperfill").otherwise(lit(0)).cast(IntegerType).alias("quantity"),
        $"clm.mstrprovid".cast(StringType).alias("prescprovider"),
        $"clm.client_ds_id",
        when(IsSafeToNumber.isSafeToNumber($"paidamount"), $"paidamount").otherwise(null).alias("paidamount"),
        when(IsSafeToNumber.isSafeToNumber($"allowedamount"), $"allowedamount").otherwise(null).alias("allowedamount"),
        when(IsSafeToNumber.isSafeToNumber($"charge"), $"charge").otherwise(null).alias("requestedamount"),
        when(IsSafeToNumber.isSafeToNumber($"quantityperfill"), $"quantityperfill").otherwise(null).cast(IntegerType).alias("quantity_dispensed"),
        $"zo_map.employeraccountid".alias("employeraccountid"),
        coalesce($"clm.contract_id", $"zo_map.employeraccountid").alias("contract_id"),
        $"clm.network_paid_status".alias("network_paid_status"),
        $"clm.copay_amt".alias("copayamount"),
        $"clm.coinsurance_amt".alias("coinsamount"),
        $"clm.deductable_amt".alias("deductamount"),
        $"clm.pat_liability_amt".alias("patliabamount"),
        when(coalesce($"dir.mx_denied_ind_rollup",$"clm.denied_flag") === "Y", "Y")
          .when(coalesce($"dir.mx_denied_ind_rollup",$"clm.denied_flag") === "N", "N").alias("deniedflag"),
        when($"clm.pseudo_flag" === "Y", "Y")
          .when($"clm.pseudo_flag" === "N", "N").alias("pseudoflag"),
        when($"clm.presc_prov_status_id".isNotNull, $"clm.presc_prov_status_id")
          .otherwise($"pds.provider_status").as("provider_status"),
        coalesce(when($"mgs.cui" === "CH003869", "0")
          .when($"mgs.cui" === "CH003871", "1")
          .when($"mgs.cui" === "CH003870", "2")
          .when($"mgs.cui" === "CH003872", "9")
          .otherwise(null), $"rndc.gbo_ind").alias("genericstatus"),
        coalesce(when($"mfi.cui" === "CH003885", "1")
          .when($"mfi.cui" === "CH003874", "2")
          .when($"mfi.cui" === "CH003875", "3")
          .when($"mfi.cui" === "CH003876", "4")
          .when($"mfi.cui" === "CH003877", "5")
          .when($"mfi.cui" === "CH003886", "6")
          .when($"mfi.cui" === "CH003887", "7")
          .when($"mfi.cui" === "CH003888", "8")
          .when($"mfi.cui" === "CH003873", "0")
          .otherwise(lit(null)), lit(5)).alias("formulary"),
        $"clm.rxid".alias("rxid"),
        when($"clm.post_dt".gt($"clm.issuedate") && $"clm.post_dt".leq(current_date()), $"clm.post_dt")
          .otherwise($"clm.issuedate").alias("paymentdate"),
        $"zhp.master_hgprovid".cast(StringType).alias("pharmacyid"),
        $"clm.other_1_amt".alias("other_1_amt"),
        $"clm.other_2_amt".alias("other_2_amt"),
        $"clm.other_3_amt".alias("other_3_amt"),
        $"clm.other_4_amt".alias("other_4_amt"),
        coalesce(when($"mprx.cui" === "CH004108", "0")
          .when($"mfi.cui" === "CH004109", "1")
          .when($"mfi.cui" === "CH004110", "2")
          .otherwise(lit(null)),lit("2")).alias("pharmacytype"),
        $"clm.denied_flag".alias("denied_ind"),
        $"clm.spec_rx_ind".alias("spec_rx_ind"),
        $"zod.daw_code".cast(IntegerType).alias("daw"),
        $"clm.fillnum".alias("fillnum"),
        $"clm.coord_benefits_amt".alias("coord_benefits_amt"),
        $"clm.dispensing_fee".alias("dispensingfee"),
        $"clm.ingredient_cost_paid".alias("ingredientcost"),
        $"clm.not_covered_amt".alias("not_covered_amt"),
        $"clm.other_carrier_pay_amt".alias("other_carrier_pay_amt"),
        $"clm.admin_fee_amt".alias("admin_fee_amt"),
        $"clm.sales_tax_amt".alias("sales_tax_amt"),
        when($"clm.capitated_service_ind".isin(lit(0), lit(1)), $"clm.capitated_service_ind")
          .otherwise(lit(null).cast(IntegerType).alias("capitated_service_ind")).alias("capitated_service_ind"),
        $"clm.adjusted_rx_cnt".cast(DoubleType).alias("adjusted_rx_cnt"),
        $"clm.cust_attr_1".alias("cust_attr_1"),
        $"clm.cust_attr_2".alias("cust_attr_2"),
        $"clm.cust_attr_3".alias("cust_attr_3"),
        $"clm.cust_attr_4".alias("cust_attr_4"),
        $"clm.cust_attr_5".alias("cust_attr_5"),
        $"clm.cust_attr_6".alias("cust_attr_6"),
        $"clm.cust_attr_7".alias("cust_attr_7"),
        $"clm.cust_attr_8".alias("cust_attr_8"),
        $"clm.cust_attr_9".alias("cust_attr_9"),
        $"clm.cust_attr_10".alias("cust_attr_10"),
        $"clm.cust_attr_11".alias("cust_attr_11"),
        $"clm.cust_attr_12".alias("cust_attr_12"),
        $"clm.cust_attr_13".alias("cust_attr_13"),
        $"clm.cust_attr_14".alias("cust_attr_14"),
        $"clm.cust_attr_15".alias("cust_attr_15"),
        $"clm.cust_attr_16".alias("cust_attr_16"),
        $"clm.cust_attr_17".alias("cust_attr_17"),
        $"clm.cust_attr_18".alias("cust_attr_18"),
        $"clm.cust_attr_19".alias("cust_attr_19"),
        $"clm.cust_attr_20".alias("cust_attr_20"),
        when ($"clm.presc_prov_affil_id".isNotNull, $"clm.presc_prov_affil_id").otherwise($"pds.provaffiliationid").as("presc_prov_affil_id")
      ).distinct()

    val withRowNumberDf = appendRowNumberToDataframe(sparkSession, df1)

    withRowNumberDf.select(
      $"groupid",
      $"memberid",
      $"paymentdate",
      $"servicedate",
      $"ndc",
      $"dayssupply",
      $"quantity",
      $"prescprovider",
      lit("MED").alias("coverageclasscode"),
      lit("PAYER").alias("healthplansource"),
      concat(lit("PHM"), $"client_ds_id", lit("."), $"rownumber").alias("claimheader"),
      lit("Y").alias("networkstatus"),
      lit("AD").alias("mapsource"),
      $"paidamount",
      $"allowedamount",
      $"requestedamount",
      $"quantity_dispensed",
      $"employeraccountid",
      $"contract_id",
      $"network_paid_status",
      $"copayamount",
      $"coinsamount",
      $"deductamount",
      $"patliabamount",
      $"deniedflag",
      $"pseudoflag",
      $"provider_status",
      $"genericstatus",
      $"formulary",
      $"adjusted_rx_cnt",
      $"admin_fee_amt",
      $"capitated_service_ind",
      $"coord_benefits_amt",
      $"cust_attr_1",
      $"cust_attr_2",
      $"cust_attr_3",
      $"cust_attr_4",
      $"cust_attr_5",
      $"cust_attr_6",
      $"cust_attr_7",
      $"cust_attr_8",
      $"cust_attr_9",
      $"cust_attr_10",
      $"cust_attr_11",
      $"cust_attr_12",
      $"cust_attr_13",
      $"cust_attr_14",
      $"cust_attr_15",
      $"cust_attr_16",
      $"cust_attr_17",
      $"cust_attr_18",
      $"cust_attr_19",
      $"cust_attr_20",
      $"daw",
      $"denied_ind",
      $"fillnum",
      $"not_covered_amt",
      $"other_carrier_pay_amt",
      $"other_1_amt",
      $"other_2_amt",
      $"other_3_amt",
      $"other_4_amt",
      $"rxid",
      $"sales_tax_amt",
      lit(null).cast(StringType).alias("claimsource"),
      lit(null).cast(StringType).alias("dea"),
      lit(null).cast(StringType).alias("deniedreason"),
      $"dispensingfee",
      $"ingredientcost",
      $"pharmacyid",
      lit(null).cast(StringType).alias("pharmacyname"),
      $"pharmacytype",
      lit(null).cast(StringType).alias("supply_flag"),
      $"spec_rx_ind",
      $"presc_prov_affil_id"
    )


  }

}
