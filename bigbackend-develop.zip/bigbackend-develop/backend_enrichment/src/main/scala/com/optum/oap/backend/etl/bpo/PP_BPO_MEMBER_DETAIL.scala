package com.optum.oap.backend.etl.bpo

import com.optum.oap.backend.cdrTempModel.{temp_bpo_calculate_params, temp_bpo_insurance}
import com.optum.oap.backend.etl.common.CDRConstants
import com.optum.oap.cdr.models.{patient_summary, pp_bpo_member_detail, zo_bpo_map_employer}
import com.optum.oap.sparkdataloader.{RuntimeVariables, TableInfo, UserDefinedFunctionForDataLoader}
import org.apache.spark.sql.functions.{lit, _}
import org.apache.spark.sql.{DataFrame, SparkSession}


object PP_BPO_MEMBER_DETAIL extends TableInfo[pp_bpo_member_detail] {
  override def dependsOn = Set("TEMP_BPO_INSURANCE", "PATIENT_SUMMARY", "ZO_BPO_MAP_EMPLOYER", "TEMP_BPO_CALCULATE_PARAMS")

  override def name = "PP_BPO_MEMBER_DETAIL"

  override def createDataFrame(sparkSession: SparkSession,
                               loadedDependencies: Map[String, DataFrame],
                               udfMap: Map[String, UserDefinedFunctionForDataLoader],
                               runtimeVariables: RuntimeVariables): DataFrame = {

    import BpoUtil._
    import com.optum.oap.backend.etl.common.Functions._
    import sparkSession.implicits._

    val mapEmployer = broadcast(loadedDependencies("ZO_BPO_MAP_EMPLOYER")).as[zo_bpo_map_employer]
    val tempBpoInsurance = loadedDependencies("TEMP_BPO_INSURANCE").as[temp_bpo_insurance]
    val patientSummary = loadedDependencies("PATIENT_SUMMARY").as[patient_summary]
    val tempParams = broadcast(loadedDependencies("TEMP_BPO_CALCULATE_PARAMS")).as[temp_bpo_calculate_params]

    val inputParameters = getBpoInputParameters(sparkSession, tempParams)
    val endDate = inputParameters.engineEndDate

    val ins = tempBpoInsurance.where($"prodrank" === 1 &&
      to_date(date_format($"member_start", "yyyyMM"), "yyyyMM") >= to_date(substring($"dob", 1, 6), "yyyyMM")
      && $"member_start" <= to_timestamp(lit(endDate), CDRConstants.DATE_FORMAT_4Y2M2D))

    val windowedIns = ins
      .groupBy($"grp_mpi")
      .agg(
        collectListFromType[temp_bpo_insurance](sparkSession).as("insuranceList")
      )
      .as[InsPerGrpMpi]
      .flatMap(insDoc => {

        // sort the list of temp_bpo_insurance by member_start ("ORDER BY member_start")
        // since insDoc will only have a single grp_mpi, it is not necessary to "PARTITION BY grp_mpi"
        val sortedByMemberStart = insDoc.insuranceList.sortWith {
          case (left, right) => left.member_start.before(right.member_start)
        }

        windowForMatch(sortedByMemberStart, true)
      })

    val ecds = patientSummary.select($"grp_mpi")
      .where(!$"client_ds_id".isin(mapEmployer.select($"client_ds_id").distinct().collect().map(_.getInt(0)): _*)).distinct()

    bpoDetailAndII(windowedIns.toDF(), ecds)(sparkSession).as[pp_bpo_member_detail].toDF()
  }


}

case class InsPerGrpMpi(grp_mpi: String, insuranceList: Seq[temp_bpo_insurance])
