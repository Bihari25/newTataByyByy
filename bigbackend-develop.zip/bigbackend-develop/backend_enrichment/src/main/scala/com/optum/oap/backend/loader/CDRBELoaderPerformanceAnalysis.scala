package com.optum.oap.backend.loader

import java.text.SimpleDateFormat
import java.util.Calendar
import com.optum.oap.sparkdataloader.{TableInfo, TableLoadEvents}
import org.apache.spark.sql.SparkSession

trait CDRBELoaderPerformanceAnalysis extends TableLoadEvents {

  private val dateFormat = new SimpleDateFormat("yy/MM/dd HH:mm:ss")
  private val dummyPrefix = "WARN DataLoader$:"
  val logs = new java.util.concurrent.ConcurrentHashMap[String, Unit]

  override protected def preLoadTable(table: TableInfo[_ <: Product with Serializable], baseSparkSession: SparkSession): Unit = {
    logs.put(s"${dateFormat.format(Calendar.getInstance().getTime())} $dummyPrefix ${table.fullName}: Loading table", Unit)
  }

  /**
    * Extra second is to ensure that Finished is always after Loading for a given table
    * @param table
    * @param baseSparkSession
    */
  override protected def postLoadTable(table: TableInfo[_ <: Product with Serializable], baseSparkSession: SparkSession): Unit = {
    val instance = Calendar.getInstance()
    instance.add(Calendar.SECOND, 1)
    logs.put(s"${dateFormat.format(instance.getTime())} $dummyPrefix ${table.fullName}: Finished", Unit)
  }
}
