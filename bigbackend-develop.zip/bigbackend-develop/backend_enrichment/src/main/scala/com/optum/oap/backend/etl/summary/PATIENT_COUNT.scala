package com.optum.oap.backend.etl.summary

import java.time.Year

import com.optum.oap.cdr.models.{patient_count, patient_summary_grp_mpi, ref_imap_region}
import com.optum.oap.sparkdataloader.{RuntimeVariables, TableInfo, UserDefinedFunctionForDataLoader}
import org.apache.spark.sql.functions._
import org.apache.spark.sql.types.IntegerType
import org.apache.spark.sql.{DataFrame, SparkSession}
import org.slf4j.LoggerFactory

object PATIENT_COUNT extends TableInfo[patient_count] {

  val log = LoggerFactory.getLogger( this.getClass )

  override def dependsOn = Set(
    "PAT_RX_SUMMARY", "PAT_LABRESULT_SUMMARY", "PAT_DIAG_SUMMARY"
    , "PAT_PROC_SUMMARY", "PATIENT_SUMMARY_GRP_MPI", "REF_IMAP_REGION" )

  override def name = "PATIENT_COUNT"

  override def saveDataFrameToParquet: Boolean = true

  override def partitions: Int = 256

  override def skipTable: Boolean = false

  override def ignoreExtraColumnsInDataFrame: Boolean = false

  override def createDataFrame( sparkSession: SparkSession,
                                loadedDependencies: Map[String, DataFrame],
                                udfMap: Map[String, UserDefinedFunctionForDataLoader],
                                runtimeVariables: RuntimeVariables ): DataFrame = {

    import sparkSession.implicits._

    val fact_tables = Seq(
      ("ERX", "PAT_RX_SUMMARY")
      , ("LABS", "PAT_LABRESULT_SUMMARY")
      , ("DIAG", "PAT_DIAG_SUMMARY")
      , ("PROC", "PAT_PROC_SUMMARY")
    )

    val summary = fact_tables
      .map( f => getSummaryData( sparkSession, f._1, loadedDependencies( f._2 ) ).as[fact_summary] )
      .reduce( _.union( _ ) )

    val pat_summary_grp_mpi = loadedDependencies( "PATIENT_SUMMARY_GRP_MPI" ).as[patient_summary_grp_mpi]
      .withColumn( "mapped_gender_trim", trim( 'mapped_gender ) )
      .withColumn( "gender",
        when( 'mapped_gender_trim === "CH000033", "F" )
          .when( 'mapped_gender_trim === "CH000034", "M" )
          .when( 'mapped_gender_trim === "CH000035", "U" )
          .otherwise( "NULL" ) )
      .drop( 'mapped_gender_trim )
      .select(
        'groupid
        , 'grp_mpi
        , 'gender
        , substring( 'mapped_zipcode, 1, 5 ).alias( "zip" )
        , 'dob
        , round( lit( Year.now.getValue ) - 'yob.cast( IntegerType ) ).alias( "age" )
      )

    val pop_zcta = loadedDependencies( "REF_IMAP_REGION" ).as[ref_imap_region]
      .select(
        'state_desc.alias( "state" )
        , 'zip.alias( "zip" )
      )

    summary
      .join( pat_summary_grp_mpi, Seq( "groupid", "grp_mpi" ), "inner" )
      .join( broadcast(pop_zcta), Seq( "zip" ), "left_outer" )
      .select(
        'age, 'datasource, 'dob, 'gender, 'groupid, 'grp_mpi, 'state,
        'year.cast( IntegerType ).alias( "year" ), 'yearmo, 'zip.alias( "zipcode" )
      )
      .distinct()
  }

  private def getSummaryData( sparkSession: SparkSession, sourceName: String, sourceTableDF: DataFrame ): DataFrame = {

    import sparkSession.implicits._

    val startYear: Integer = 2005
    val endYear: Integer = Year.now.getValue

    sourceTableDF.withColumn( "yearmo", concat( 'dt_yr, 'dt_month ).cast( IntegerType ) )
      .filter( 'dt_yr.cast( IntegerType ) >= startYear && 'dt_yr.cast( IntegerType ) <= endYear )
      .select(
        'groupid
        , 'grp_mpi
        , 'dt_yr.alias( "year" )
        , concat( 'dt_yr, 'dt_month ).cast( IntegerType ).alias( "yearmo" )
        , lit( sourceName ).alias( "datasource" )
      )
      .distinct()
  }

  case class fact_summary( groupid: String, grp_mpi: String, year: String, yearmo: Integer, datasource: String )

}

