package com.optum.oap.backend.etl.enrichment

import com.optum.oap.backend.etl.common.MapMasterIds
import com.optum.oap.cdr.models.{health_maintenance, patient_mpi}
import com.optum.oap.sparkdataloader.{RuntimeVariables, TableInfo, UserDefinedFunctionForDataLoader}
import org.apache.spark.sql.{DataFrame, SparkSession}
import org.slf4j.LoggerFactory

object HEALTH_MAINTENANCE extends TableInfo[health_maintenance] {

  val log = LoggerFactory.getLogger(this.getClass)

  override def dependsOn = Set("CDR_FE_HEALTH_MAINTENANCE", "PATIENT_MPI")

  override def name = "HEALTH_MAINTENANCE"

  override def saveDataFrameToParquet: Boolean = true

  override def partitions: Int = 32

  override def skipTable: Boolean = false

  override def ignoreExtraColumnsInDataFrame: Boolean = true

  override def createDataFrame(sparkSession: SparkSession,
                               loadedDependencies: Map[String, DataFrame],
                               udfMap: Map[String, UserDefinedFunctionForDataLoader],
                               runtimeVariables: RuntimeVariables): DataFrame = {
    import sparkSession.implicits._

    val health_maintenanceIn = loadedDependencies("CDR_FE_HEALTH_MAINTENANCE").as[health_maintenance]
    val patXref = loadedDependencies("PATIENT_MPI").as[patient_mpi]

    MapMasterIds.mapPatientIds(health_maintenanceIn.toDF, patXref.toDF, false)
  }


}
