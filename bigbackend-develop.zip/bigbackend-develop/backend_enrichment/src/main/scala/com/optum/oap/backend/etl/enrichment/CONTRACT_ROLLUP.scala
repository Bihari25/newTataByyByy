  package com.optum.oap.backend.etl.enrichment

  import com.optum.oap.backend.etl.common.MapMasterIds
  import com.optum.oap.backend.loader.EnrichmentRunTimeVariables
  import com.optum.oap.cdr.models.{contract_rollup, int_claim_member, map_predicate_values, zo_bpo_map_employer}
  import com.optum.oap.sparkdataloader.{RuntimeVariables, TableInfo, UserDefinedFunctionForDataLoader}
  import org.apache.spark.sql.expressions.Window
  import org.apache.spark.sql.{DataFrame, SparkSession}
  import org.slf4j.LoggerFactory
  import org.apache.spark.sql.functions.{coalesce, lit, _}
  import org.apache.spark.sql.types.DataTypes
  import org.apache.spark.sql.types._

  object CONTRACT_ROLLUP extends TableInfo[contract_rollup] {

    private val log = LoggerFactory.getLogger(this.getClass)

    override def dependsOn = Set("CDR_FE_CONTRACT_ROLLUP","ZO_BPO_MAP_EMPLOYER","MAP_PREDICATE_VALUES","INT_CLAIM_MEMBER")

    override def name = "CONTRACT_ROLLUP"

    override def partitions: Int = 32

    override def createDataFrame(sparkSession: SparkSession,
                                 loadedDependencies: Map[String, DataFrame],
                                 udfMap: Map[String, UserDefinedFunctionForDataLoader],
                                 runtimeVariables: RuntimeVariables): DataFrame = {

      import sparkSession.implicits._

      val cdrContractRollup = loadedDependencies("CDR_FE_CONTRACT_ROLLUP").as[contract_rollup]

      val cdrZoMapEmployer = broadcast(loadedDependencies("ZO_BPO_MAP_EMPLOYER")).as[zo_bpo_map_employer]

      val intClaimMember = loadedDependencies("INT_CLAIM_MEMBER").as[int_claim_member]

      val mapPredicateValues = broadcast(loadedDependencies("MAP_PREDICATE_VALUES")).as[map_predicate_values]

      //*CONTRACT_ROLLUP*
      //Origin Front end Contract rollup table
      val cdrContractRollup1 = cdrContractRollup.select( $"GROUPID",
        $"CLIENT_DS_ID",
        $"CONTRACT_ID",
        $"DATASRC",
        $"CONTRACT_HIER",
        $"CONTRACT_DESC",
        $"CONTRACT_LV2",
        $"CONTRACT_LV2_DESC",
        $"CONTRACT_LV1",
        $"CONTRACT_LV1_DESC")

      //TAKING DISTINCT CONTRACT IDS FROM THE CONTRACT ROLLUP TABLE
      val cdrFeContractRollup = cdrContractRollup1
        .dropDuplicates("CONTRACT_ID")

      //*ZOMAPEMPLOYER*
      //FILTERING THE ZOMAPEMPLOYER TABLE WITH THE GROUPIDS FETCHED FROM THE MPV TABLE
      val cdrZoMapEmployer1 = cdrZoMapEmployer
        .select(
          cdrZoMapEmployer("GROUPID"),
          cdrZoMapEmployer("CLIENT_DS_ID"),
          lit("mapemployer").as("DATASRC"),
          cdrZoMapEmployer("EMPLOYERACCOUNTID").as("CONTRACT_ID"),
          coalesce($"EMPLOYERACCOUNTIDDESCRIPTION", $"EMPLOYERACCOUNTID").as("CONTRACT_DESC"),
          cdrZoMapEmployer("MIDEMPLOYERACCOUNT").as("CONTRACT_LV2"),
          cdrZoMapEmployer("MIDEMPLOYERACCOUNTDESCRIPTION").as("CONTRACT_LV2_DESC"),
          cdrZoMapEmployer("HIGHEMPLOYERACCOUNT").as("CONTRACT_LV1"),
          cdrZoMapEmployer("HIGHEMPLOYERACCOUNTDESCRIPTION").as("CONTRACT_LV1_DESC"))
        .where($"GROUPID" isin(mapPredicateValues.select($"GROUPID")
                            .where($"DATA_SRC"=== "PAYER_MAPS" && $"ENTITY" === "CONTRACT_ROLLUP" && $"COLUMN_VALUE" === "Y" )
                              .distinct().collect().map(_.getString(0)): _*))

      //SELECTING RECORDS OF ZOMAPEMPLOYER TABLE WHOSE CONTRACT IDS ARE NOT IN THE CONTRACT ROLLUP TABLE
      val contractRollup1 = cdrZoMapEmployer1.join(cdrFeContractRollup,cdrZoMapEmployer1("CONTRACT_ID") === cdrFeContractRollup("CONTRACT_ID"),"left")
        .select(cdrZoMapEmployer1("*"),
        lit(99).cast(IntegerType).as("CONTRACT_HIER"))
        .where((cdrZoMapEmployer1("CONTRACT_ID").isNotNull) && (length(cdrZoMapEmployer1("CONTRACT_ID")) <= 30) && (cdrFeContractRollup("CONTRACT_ID") isNull))
        .groupBy($"GROUPID",cdrZoMapEmployer1("CONTRACT_ID"), cdrZoMapEmployer1("CONTRACT_DESC"),
          cdrZoMapEmployer1("CONTRACT_LV2"), cdrZoMapEmployer1("CONTRACT_LV2_DESC"), cdrZoMapEmployer1("CONTRACT_LV1"),
          cdrZoMapEmployer1("CONTRACT_LV1_DESC"),cdrZoMapEmployer1("DATASRC"),$"CONTRACT_HIER")
        .agg(min($"CLIENT_DS_ID").as("CLIENT_DS_ID"))

      //UNION THE MISSING RECORDS FETCHED FROM ZOMAPEMPLOYER AND THE ORIGINAL CONTRACT ROLLUP TABLE
      val cdrContractRollup2 = cdrContractRollup1.unionByName(contractRollup1)

      //TAKING DISTINCT CONTRACT IDS FROM THE UNION CONTRACT ROLLUP TABLE
      val cdrFeContractRollup2 = cdrContractRollup2
        .dropDuplicates("CONTRACT_ID")

      //*INTCLAIMMEMBER*
      //SELECTING ALL RECORDS HAVING CLIENT_DS_ID VALUE MINIMUM OF THE INTCLAIMMEMBER TABLE
      val intclaimmember1 = intClaimMember
        .select($"GROUPID".as("GROUPID")
            ,$"CLIENT_DS_ID"
          , $"CONTRACT_ID".as("CONTRACT_ID")
        )
        .where($"CONTRACT_ID".isNotNull && length($"CONTRACT_ID") <= 30 )
        .groupBy($"GROUPID",$"CONTRACT_ID")
        .agg(min($"CLIENT_DS_ID").as("CLIENT_DS_ID"))

      //SELECTING RECORDS OF INTCLAIMMEMBER TABLE WHOSE CONTRACT IDS ARE NOT IN THE CONTRACT ROLLUP TABLE
      val intclaimmember2 = intclaimmember1.join(cdrFeContractRollup2,intclaimmember1("CONTRACT_ID") === cdrFeContractRollup2("CONTRACT_ID"),"left")
        .select(intclaimmember1("GROUPID")
        ,intclaimmember1("CLIENT_DS_ID")
        ,intclaimmember1("CONTRACT_ID")
          ,lit("int_claim_member").cast(StringType).as("DATASRC")
          ,lit(99).cast(IntegerType).as("CONTRACT_HIER")
          , concat(lit("UNDEFINED ("), intclaimmember1("CONTRACT_ID"), lit(")")).cast(StringType).as("CONTRACT_DESC")
        ,cdrFeContractRollup2("CONTRACT_LV2")
          ,cdrFeContractRollup2("CONTRACT_LV2_DESC")
          ,cdrFeContractRollup2("CONTRACT_LV1")
          ,cdrFeContractRollup2("CONTRACT_LV1_DESC"))
        .where((intclaimmember1("CONTRACT_ID").isNotNull) && (length(intclaimmember1("CONTRACT_ID")) <= 30) && (cdrFeContractRollup2("CONTRACT_ID") isNull))
        .groupBy($"GROUPID",intclaimmember1("CONTRACT_ID"),$"DATASRC",$"CONTRACT_HIER",$"CONTRACT_DESC",
          cdrFeContractRollup2("CONTRACT_LV2"),cdrFeContractRollup2("CONTRACT_LV2_DESC"),cdrFeContractRollup2("CONTRACT_LV1"),cdrFeContractRollup2("CONTRACT_LV1_DESC"))
        .agg(min($"client_ds_id").as("CLIENT_DS_ID"))

      //*UNION*
      //NOW UNION THE MISSING RECORDS FETCHED FROM INTCLAIMMEMBER AND THE UNION CONTRACT ROLLUP TABLE
      val union_origin_claim_zomap = cdrContractRollup2.unionByName(intclaimmember2)

      //APPLYING ADDITIONAL TRANSFORMATIONS ON THE UNION WITH THE FETCHED RECORDS OF ZOMAPEMPLOYER AND INTCLAIMEMBER AND LOAD TO BACKEND.
      val rollup = union_origin_claim_zomap.join(intclaimmember1,union_origin_claim_zomap("GROUPID")=== intclaimmember1("GROUPID") && union_origin_claim_zomap("CONTRACT_ID")=== intclaimmember1("CONTRACT_ID"),"left" )
        .join(cdrZoMapEmployer1,union_origin_claim_zomap("GROUPID")=== cdrZoMapEmployer1("GROUPID") && union_origin_claim_zomap("CONTRACT_ID")=== cdrZoMapEmployer1("CONTRACT_ID"),"left" )
        .select(
          union_origin_claim_zomap("CONTRACT_ID")
         , union_origin_claim_zomap("GROUPID")
         , union_origin_claim_zomap("DATASRC")
        ,coalesce(intclaimmember1("CLIENT_DS_ID"),cdrZoMapEmployer1("CLIENT_DS_ID"),union_origin_claim_zomap("CLIENT_DS_ID")).as("CLIENT_DS_ID")
        ,substring(coalesce(union_origin_claim_zomap("CONTRACT_DESC"), concat(lit("UNDEFINED ("),union_origin_claim_zomap("CONTRACT_ID"),lit(")"))),1,150).as("CONTRACT_DESC")
        ,substring(coalesce(union_origin_claim_zomap("CONTRACT_LV2"), concat(lit("3."),union_origin_claim_zomap("CONTRACT_ID"))),1,30).as("CONTRACT_LV2")
        ,substring(when(union_origin_claim_zomap("CONTRACT_LV2").isNull,coalesce(union_origin_claim_zomap("CONTRACT_DESC"),concat(lit("UNDEFINED ("),union_origin_claim_zomap("CONTRACT_ID"),lit(")"))))
                    .otherwise(coalesce(union_origin_claim_zomap("CONTRACT_LV2_DESC"),concat(lit("UNDEFINED ("),union_origin_claim_zomap("CONTRACT_LV2"),lit(")")))) ,1,150)
                  .as("CONTRACT_LV2_DESC")
        ,substring(when(union_origin_claim_zomap("CONTRACT_LV1").isNotNull,union_origin_claim_zomap("CONTRACT_LV1"))
                    .otherwise(when(union_origin_claim_zomap("CONTRACT_LV2").isNotNull,concat(lit("2."),union_origin_claim_zomap("CONTRACT_LV2")))
                    .otherwise(concat(lit("3."),union_origin_claim_zomap("CONTRACT_ID")))),1,30)
                  .as("CONTRACT_LV1")
          ,substring(when(union_origin_claim_zomap("CONTRACT_LV1").isNull,
            when(union_origin_claim_zomap("CONTRACT_LV2").isNull,coalesce(union_origin_claim_zomap("CONTRACT_DESC"),concat(lit("UNDEFINED ("),union_origin_claim_zomap("CONTRACT_ID"),lit(")")) ))
              .otherwise(coalesce(union_origin_claim_zomap("CONTRACT_LV2_DESC"),concat(lit("UNDEFINED ("),union_origin_claim_zomap("CONTRACT_LV2"),lit(")")) )))
              .otherwise(coalesce(union_origin_claim_zomap("CONTRACT_LV1_DESC"),concat(lit("UNDEFINED ("),union_origin_claim_zomap("CONTRACT_LV1"),lit(")")))),1,150)
                .as("CONTRACT_LV1_DESC")
        ,when(union_origin_claim_zomap("CONTRACT_HIER") isNull,lit(99)).otherwise(union_origin_claim_zomap("CONTRACT_HIER")).cast(IntegerType).as("CONTRACT_HIER")
        ,row_number().over(Window.partitionBy(union_origin_claim_zomap("CONTRACT_ID"))
            .orderBy(
              when(union_origin_claim_zomap("CONTRACT_DESC").isNotNull, lit(0)).otherwise(lit(1)),
              when(union_origin_claim_zomap("CONTRACT_LV2").isNotNull, lit(0)).otherwise(lit(1)),
              when(union_origin_claim_zomap("CONTRACT_LV1").isNotNull, lit(0)).otherwise(lit(1)),
              union_origin_claim_zomap("CONTRACT_DESC"),union_origin_claim_zomap("CONTRACT_LV2"),union_origin_claim_zomap("CONTRACT_LV1")
            )).as("rn"))
        .where((union_origin_claim_zomap("CONTRACT_ID") isNotNull ) && length(union_origin_claim_zomap("CONTRACT_ID"))<=30 && ($"rn"=== 1))
        .drop($"rn")

      rollup.toDF()
    }
  }
