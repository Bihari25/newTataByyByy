package com.optum.oap.backend.etl.enrichment

import com.optum.oap.backend.etl.common.MapMasterIds
import com.optum.oap.backend.loader.EnrichmentRunTimeVariables
import com.optum.oap.cdr.models.{employee_type_rollup, int_claim_member, map_employee_type}
import com.optum.oap.sparkdataloader.{RuntimeVariables, TableInfo, UserDefinedFunctionForDataLoader}
import org.apache.hadoop.yarn.webapp.hamlet.HamletSpec.SUB
import org.apache.spark.sql.expressions.Window
import org.apache.spark.sql.{DataFrame, SparkSession}
import org.slf4j.LoggerFactory
import org.apache.spark.sql.functions.{coalesce, length, regexp_replace, _}
import org.apache.spark.sql.types.DataTypes
import org.apache.spark.sql.types._

object EMPLOYEE_TYPE_ROLLUP extends TableInfo[employee_type_rollup] {

  private val log = LoggerFactory.getLogger(this.getClass)

  override def dependsOn = Set("CDR_FE_EMPLOYEE_TYPE_ROLLUP", "INT_CLAIM_MEMBER", "MAP_EMPLOYEE_TYPE")

  override def name = "EMPLOYEE_TYPE_ROLLUP"

  override def partitions: Int = 32

  override def createDataFrame(sparkSession: SparkSession,
                               loadedDependencies: Map[String, DataFrame],
                               udfMap: Map[String, UserDefinedFunctionForDataLoader],
                               runtimeVariables: RuntimeVariables): DataFrame = {

    import sparkSession.implicits._

    val cdrEmployeeTypeRollup = loadedDependencies("CDR_FE_EMPLOYEE_TYPE_ROLLUP").as[employee_type_rollup]

    val iCM = loadedDependencies("INT_CLAIM_MEMBER").as[int_claim_member]

    val cdrMET = broadcast(loadedDependencies("MAP_EMPLOYEE_TYPE")).as[map_employee_type]

    val groupId = runtimeVariables.asInstanceOf[EnrichmentRunTimeVariables].clientId

    //Frontend EmployeeType Rollup table
    val cdrFeEmployeeTypeRollup1 = cdrEmployeeTypeRollup.select(
      $"groupid",
      $"client_ds_id",
      $"datasrc",
      $"employee_type",
      $"employee_type_desc",
      $"employee_type_rollup"
    )

    //Filtering Frontend EmployeeType Rollup table
    val cdrFeETR = cdrFeEmployeeTypeRollup1
      .dropDuplicates("EMPLOYEE_TYPE")
      .select("*")

    //getting the records from intclaimmember whose emp_acct_id is not in the EmployeeType Rollup
    val iCM2 = iCM.as("a").join(cdrFeETR.as("b"), $"a.employee_type" === $"b.employee_type", "left")
      .select($"a.groupid",
        $"a.client_ds_id",
        lit("int_claim_member").cast(StringType).as("datasrc"),
        $"a.EMPLOYEE_TYPE",
        concat(lit("UNDEFINED ("), $"a.employee_type" , lit(")")).as("employee_type_desc"),
        $"b.employee_type_rollup"
      )
      .where(($"a.employee_type" isNotNull) && (length($"a.employee_type") <=30 )&& ($"b.employee_type" isNull))
      .groupBy($"a.groupid",
        $"a.employee_type"
        ,$"datasrc",
        $"employee_type_desc",
        $"b.employee_type_rollup")
      .agg(min($"client_ds_id").as("client_ds_id"))

    //union the missed records from intclaimmember and the original table
    val rollup1 = cdrFeEmployeeTypeRollup1.unionByName(iCM2)

    //Applying the additional logic and loading to the backend table.
    val rollup = rollup1.as("a").join(cdrMET.as("b"),($"a.employee_type" === $"b.localcode") && ($"b.groupid" === groupId), "left" )
      .select(
      $"a.groupid" .as("groupid")
      ,$"client_ds_id"
      ,$"datasrc"
      ,$"employee_type"
      ,substring(coalesce($"employee_type_desc", concat(lit("UNDEFINED ("),$"employee_type",lit(")"))),1,150).as("employee_type_desc")
      ,when(upper(when($"employee_type_rollup" === lit("0"),lit("N"))
          .otherwise(when(($"employee_type_rollup") === lit("1"),lit("Y"))
          .otherwise(when(($"employee_type_rollup") isNull,lit("X"))
          .otherwise($"employee_type_rollup"))))
          .isin ("Y", "N", "U") ,upper(when(($"employee_type_rollup") === lit("0"),lit("N"))
            .otherwise(when(($"employee_type_rollup") === lit("1"),lit("Y"))
            .otherwise($"employee_type_rollup"))))
          .otherwise($"b.mappedvalue")
          .as("employee_type_rollup")
      ,row_number().over(Window.partitionBy($"employee_type")
        .orderBy(
          when($"employee_type_desc".isNotNull, lit(0)).otherwise(lit(1)),
          when($"employee_type_rollup".isNotNull, lit(0)).otherwise(lit(1)),
          $"employee_type_desc",
          $"employee_type_rollup"
        )).as("rn")
    )
      .where( ($"employee_type" isNotNull) && (length($"employee_type") <=30) && ($"rn"=== 1))
      .drop($"rn")

    rollup.as[employee_type_rollup].toDF()
  }
}