## Checkpointing Notes

The Enrichment function has been extended to support _checkpointing_.

Both HDFS and S3 _checkpointing_ is supported and is determined by config:
```
  private def checkpointerFromConfig(conf: EnrichmentConf) =
    conf.clientBucket
      .map(_ => S3Checkpointer.fromClientBucketURI(new URI(getBasePath(ecdrPathConfig(conf))), AWSClientConfig.default.createS3Client()))
      .getOrElse(HDFSCheckpointer.fromPath(new Path(getBasePath(ecdrPathConfig(conf)))))
```

Checkpoint purge policy is driven by command line parameters:
```
    val purgePolicy =
      (conf.fullRun.toOption, getOptionalSeq(conf.targetTables)) match {
        case (Some(true), _) => PurgeAll
        case (_, Some(tables)) if tables.nonEmpty => PurgeSome(tables)
        case _ => PurgeNone
      }

    --fullRun  // this removes all previous checkpoints
    --targetTables Foo,Bar // this removes Foo and Bar checkpoints only

    otherwise we purge nothing
```
