package com.optum.oap.backend.acc

import com.optum.oap.backend.acc.util.AccUtil._
import com.optum.oap.sparklib.HDFSUtils
import org.apache.hadoop.fs.FileSystem
import org.apache.spark.sql
import org.apache.spark.sql.SparkSession
import org.slf4j.LoggerFactory

import scala.collection.mutable
import scala.concurrent.duration.Duration
import scala.concurrent.{Await, Future}

object Validation {

  private val log = LoggerFactory.getLogger(this.getClass)

  def fileLevelValidation(spark: SparkSession, allAccFilesConfig: Set[String], mapControlFileConfig: Seq[FileCount], basePathAcc: String): Unit = {
    val allAccFiles = allAccFilesConfig.map(f => f.toLowerCase).toSeq.sorted
    val mapControlFile = mapControlFileConfig.map(f => f.fileName.toLowerCase).sorted
    val missingFilesDiff = mapControlFile.diff(allAccFiles)
    val extraFilesDiff = allAccFiles.diff(mapControlFile)

    if (missingFilesDiff.nonEmpty) {
      throw ACCValidationException(s"Missing files: ${missingFilesDiff.mkString(", ")}")
    }

    if (extraFilesDiff.nonEmpty) {
      throw ACCValidationException(s"Extra files: ${extraFilesDiff.mkString(", ")}")
    }

    val zippedFileNames = allAccFiles.zip(mapControlFile)
    val mismatchedNames = zippedFileNames.map(files => {
      if (!files._1.equalsIgnoreCase(files._2)) s"File name ${files._1} does not match expected name ${files._2}" else ""
    }).mkString("\n").trim()

    val controlsValidationMsg = validateControlsFile(mapControlFileConfig, basePathAcc, spark, mapControlFileConfig.size)

    if (mismatchedNames.nonEmpty || controlsValidationMsg.nonEmpty) {
      throw ACCValidationException(s"$mismatchedNames\n\n$controlsValidationMsg")
    }
  }

  private def validateControlsFile(seqFileTotals: Seq[FileCount], filePath: String, session: SparkSession, expectedCount: Int): String = {
    val errors = mutable.ArrayBuffer[String]()
    import scala.concurrent.ExecutionContext.Implicits.global

    if (seqFileTotals.size != expectedCount) {
      errors.append(s"Count of records in controls file (${seqFileTotals.size}) does not match expected count of $expectedCount")
    } else {
      val result = Future.traverse(seqFileTotals) {
        f =>
          Future {

            try {
              val fullFilePath = s"$filePath/${f.fileName}"
              val rowCount = session.read.csv(fullFilePath).count()

              if (rowCount != (f.count)) {
                errors.append(s"Count for file $fullFilePath did not match. ACC file row count: $rowCount | Controls file row count: ${f.count}")
              }
            } catch {
              case e: Exception =>
                errors.append(s"Error while counting records for file ${f.fileName}. Check if the path exists.")
            }
          }
      }
      Await.result(result, Duration.Inf)
    }
    if (errors.nonEmpty && errors.lengthCompare(0) != 0) {
      s"${errors.mkString("---* Count mismatch errors *---", "\n", "---**---")}"
    } else ""

  }

  def txtFileValidation(spark: SparkSession, triggerFileConfig: Seq[FileCount], basePathAcc: String, fs: FileSystem): Unit = {
    val filesInPlace = triggerFileConfig.forall(file => HDFSUtils.ifPathExists(fs, ensureTrailingCharacter(basePathAcc, '/') + file.fileName + ".gz"))

    if (!filesInPlace) {
      throw ACCValidationException(s"Missing files in path $basePathAcc")
    }

    val txtFilesValidationMsg = validateFileCounts(spark, triggerFileConfig, basePathAcc, readText)

    if (txtFilesValidationMsg.nonEmpty) {
      throw ACCValidationException(s"$txtFilesValidationMsg")
    }
  }

  def validateFileCounts(session: SparkSession,seqFileTotals: Seq[FileCount], filePath: String, readData: (SparkSession, String) => sql.DataFrame): String = {
    val errors = mutable.ArrayBuffer[String]()
    import scala.concurrent.ExecutionContext.Implicits.global

    val result = Future.traverse(seqFileTotals) {
      f =>
        Future {

          try {
            val fullFilePath = getModelPath(filePath, f.fileName)
            val rowCount = readData(session, fullFilePath).count()

            log.warn(s"Count of file at $fullFilePath: $rowCount")

            if (rowCount != f.count) {
              errors.append(s"Count for file $fullFilePath did not match. ACC file row count: $rowCount | Trigger file row count: ${f.count}")
            }
          } catch {
            case e: Exception =>
              errors.append(s"Error while counting records for file ${f.fileName}. Check if the path exists.")
          }
        }
    }
    Await.result(result, Duration.Inf)
    if (errors.nonEmpty && errors.lengthCompare(0) != 0) {
      s"${errors.mkString("---* Count mismatch errors *---", "\n", "---**---")}"
    } else ""
  }

  def readParquet(sparkSession: SparkSession,filePath: String) = {
    sparkSession.read.parquet(filePath)
  }

  def readText(sparkSession: SparkSession, filePath: String) = {
    sparkSession.read.text(filePath + ".gz")
  }
}


  final case class ACCValidationException(private val message: String = "") extends Exception(message)

  case class FileCount(fileName: String, count: Long)