package com.optum.oap.backend.acc.models.ebm

import java.io.StringReader

import com.optum.oap.backend.acc.AbstractAcc
import com.optum.oap.backend.acc.lib.FieldReader
import com.optum.oap.backend.acc.util.AccUtil.parseToTimestamp
import com.optum.oap.cdr.models.ebm_facility_event
import com.optum.oap.utils.Resource.using

/**
  *
  * Copyright 2019 Optum Analytics
  *
  * Date: 9/3/19
  *
  * Creator: pavula1
  */
/*
 (
GRP_MPI                 POSITION(1:32),
FACILITY_EVENT_NUM      POSITION(33:42),
CARE_CATEGORY           POSITION(43:45),
HLDC                    POSITION(46:47),
ETG_NUMBER              POSITION(48:56),
UNIQ_REC_ID             POSITION(57:84),
EVENT_FROM_DT           POSITION(85:92) DATE "YYYYMMDD",
EVENT_TO_DT             POSITION(93:100) DATE "YYYYMMDD",
FILE_PROCESSING_MONTH   "TO_DATE ('${dataname%%_*}', 'YYYYMMDD')",
GROUPID                 CONSTANT "${groupid}"
)
  */
// 696922470                             3666S95           MED6627.69508131            2016060620160606
object EBMFacilityEventModel extends AbstractAcc[ebm_facility_event] {

  override def processRowHelper(data: String, groupId: String, fileProcessingMonth: String): ebm_facility_event = {
    using(new StringReader(data))(implicit reader => {
      val rd = FieldReader()
      import rd._

      val groupMpi = nullOnEmpty(readString(32)) // GRP_MPI
      val facilityEventNum = nullOnEmpty(readString(10, throwOnNoData = false)) // FACILITY_EVENT_NUM
      val careCategory = nullOnEmpty(readString(3, throwOnNoData = false)) // CARE_CATEGORY
      val hldcvalue = nullOnEmpty(readString(2, throwOnNoData = false)) // HLDC
      val etgNumber = nullOnEmpty(readString(9, throwOnNoData = false)) // ETG_NUMBER
      val uniqRecordId = nullOnEmpty(readString(28, throwOnNoData = false)) // UNIQ_REC_ID
      val eventFromDate = nullOnEmpty(readString(8, throwOnNoData = false)) // EVENT_FROM_DT
      val eventToDt = nullOnEmpty(readString(8, throwOnNoData = false)) // EVENT_TO_DT

      ebm_facility_event(care_category = careCategory,
        etg_number = etgNumber,
        event_from_dt = parseToTimestamp(eventFromDate).orNull,
        event_to_dt = parseToTimestamp(eventToDt).orNull,
        facility_event_num = if (facilityEventNum == null) null else facilityEventNum.toInt,
        file_processing_month = parseToTimestamp(fileProcessingMonth).orNull,
        groupid = groupId,
        grp_mpi = groupMpi,
        hldc = hldcvalue,
        uniq_rec_id = uniqRecordId)
    })
  }
}
