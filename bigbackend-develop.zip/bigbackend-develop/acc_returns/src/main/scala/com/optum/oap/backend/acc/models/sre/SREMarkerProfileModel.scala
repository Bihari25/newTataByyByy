package com.optum.oap.backend.acc.models.sre

import java.io.StringReader

import com.optum.oap.backend.acc.AbstractAcc
import com.optum.oap.backend.acc.lib.FieldReader
import com.optum.oap.cdr.models.sre_marker_profile
import com.optum.oap.utils.Resource.using

/**
  *
  * Copyright 2019 Optum Analytics
  *
  * Date: 9/4/19
  *
  * Creator: bpokharel(bishu)
  */
/**
  * FAMILY_ID  POSITION(1:30) ,
  * PATIENT_ID POSITION(31:32),
  * MARKER_ID  POSITION(33:40) ,
  * MARKER_TYPE POSITION(41:44),
  * GROUPID CONSTANT "${groupid}"
  */
//687486414                       18010000BASE
object SREMarkerProfileModel extends AbstractAcc[sre_marker_profile] {

  override def processRowHelper(data: String, groupId: String, fileProcessingMonth: String): sre_marker_profile = {
    using(new StringReader(data))(implicit reader => {
      val rd = FieldReader()
      import rd._

      val familyId = nullOnEmpty(readString(30)) // FAMILY_ID
      val patientId = nullOnEmpty(readString(2, throwOnNoData = false)) // PATIENT_ID
      val markerId = nullOnEmpty(readString(11, throwOnNoData = false)) // MARKER_ID
      val markerType = nullOnEmpty(readString(4, throwOnNoData = false)) // MARKER_TYPE
      val markerValue = nullOnEmpty(readString(15, throwOnNoData = false)) // MARKER_TYPE

      sre_marker_profile(family_id = familyId, patient_id = patientId, marker_id = markerId,
        marker_type = markerType, groupid = groupId, marker_value = markerValue.toDouble)
    })
  }
}
