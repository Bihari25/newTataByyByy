package com.optum.oap.backend.acc.models.hedis

import org.apache.spark.sql.{DataFrame, SparkSession, functions}
import org.apache.spark.sql.functions.{col, concat, lit, substring}
import org.apache.spark.sql.types.StructType

/**
  *
  * Copyright 2019 Optum Analytics
  *
  * Date: 9/12/19
  *
  * Creator: pavula1
  */
object HedisConversionModel {

  def processHedisAuditOutput(sparkSession: SparkSession, resPath: String, groupId: String, schema: StructType, yr: String) :DataFrame = {
    val df = sparkSession.read.option("header", "false")
      .option("delimiter", ",")
      .csv(resPath)
      .toDF("grp_mpi", "population_id", "measure_audit_key", "contributing_object_name", "metric_code", "metric_value", "episode_identifier", "measurement_end_date", "version")

    val df1 = df.withColumn("groupid", lit(groupId))
      .withColumn("hum_vers_yr", concat(lit("V"), substring(col("version"), -4, 4), lit("_"), lit(yr.toUpperCase())))
      .withColumn("version", substring(col("version"), -4, 4))
    val lowerCaseColsDF = df1.toDF(df1.columns.map(_.toLowerCase): _*)

    val colMap = schema.map(s => (s.name, s.dataType)).map(sf => functions.col(sf._1).cast(sf._2).as(sf._1))
    lowerCaseColsDF.select(colMap: _*)

  }

  def processHedisMeasureResult(sparkSession: SparkSession, resPath: String, groupId: String, schema: StructType, yr: String) :DataFrame = {
    val df = sparkSession.read.option("header", "false")
      .option("delimiter", ",")
      .csv(resPath)
      .toDF("measure_id", "measure_name", "stratification_id", "grp_mpi", "result_answer", "denominator_flag", "denominator_exclusion_flag", "denominator_exception_flag",
        "numerator_flag", "numerator_exclusion_flag", "measurement_end_date", "qualifying_date", "run_date", "episode_number", "expected_visit_count", "actual_visit_count",
        "member_month_count", "days_count", "discharge_count", "services_count", "surgery_weight", "base_risk_weight", "age_and_gender_weight", "dcc_weight", "comorbidity_weight",
      "age", "gender", "risk_score", "adjusted_probability", "variance", "dcc_category", "population_id", "X1", "X2", "X3", "X4", "X5", "version", "X6", "X7")

    val excludeColumns= Seq("X1", "X2", "X3", "X4", "X5", "X6", "X7")
    val df1 = df.withColumn("groupid", lit(groupId))
      .withColumn("hum_vers_yr", concat(lit("V"), substring(col("version"), -4, 4), lit("_"), lit(yr.toUpperCase())))
      .withColumn("version", substring(col("version"), -4, 4))
      .drop(excludeColumns: _*)
    val lowerCaseColsDF = df1.toDF(df1.columns.map(_.toLowerCase): _*)

    val colMap = schema.map(s => (s.name, s.dataType)).map(sf => functions.col(sf._1).cast(sf._2).as(sf._1))
    lowerCaseColsDF.select(colMap: _*)


  }

}
