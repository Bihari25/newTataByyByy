package com.optum.oap.backend.acc.models.sre

import java.io.StringReader

import com.optum.oap.backend.acc.AbstractAcc
import com.optum.oap.backend.acc.lib.FieldReader
import com.optum.oap.backend.acc.util.AccUtil.parseToTimestamp
import com.optum.oap.cdr.models.sre_uwrisksummary
import com.optum.oap.utils.Resource.using

/**
  *
  * Copyright 2019 Optum Analytics
  *
  * Date: 9/5/19
  *
  * Creator: bpokharel(bishu)
  */

/**
  * FAMILY_ID POSITION(1:30),
  * PATIENT_ID POSITION(31:32),
  * AGE POSITION(33:35),
  * GENDER POSITION(36:36),
  * UW_MEDRX_RISK POSITION(37:46),
  * UW_100K_MEDRX_RISK POSITION(47:56),
  * UW_MED_RISK POSITION(57:66),
  * UW_100K_MED_RISK POSITION(67:76),
  * UW_250K_MEDRX_PROB POSITION(77:86),
  * UW_100K_MEDRX_PROB POSITION(87:96),
  * UW_250K_MED_PROB POSITION(97:106),
  * UW_100K_MED_PROB POSITION(107:116),
  * DEMO_RISK POSITION(117:126),
  * INPUT_DATA_TYPE POSITION(127:127),
  * UW_ENROLL_LENGTH POSITION(128:130),
  * UW_PARTIAL_ENROLL POSITION(131:131),
  * GROUPING_END_DATE POSITION(132:139) DATE "YYYYMMDD",
  * ERROR_STATUS POSITION(140:140),
  * GROUPER_VERSION POSITION(141:144),
  * DATABASE_VERSION POSITION(145:146) ,
  * GROUPID CONSTANT "${groupid}"
  */
object SREUWRiskSummaryModel extends AbstractAcc[sre_uwrisksummary] {

  override def processRowHelper(data: String, groupId: String, fileProcessingMonth: String): sre_uwrisksummary = {
    using(new StringReader(data))(implicit reader => {
      val rd = FieldReader()
      import rd._


      val familyId = nullOnEmpty(readString(30)) // FAMILY_ID
      val patientId = nullOnEmpty(readString(2, throwOnNoData = false)) // PATIENT_ID
      val age = nullOnEmpty(readString(3, throwOnNoData = false)) // AGE
      val gender = nullOnEmpty(readString(1, throwOnNoData = false)) // GENDER
      val uwMedrxRisk = nullOnEmpty(readString(14, throwOnNoData = false)) // UW_MEDRX_RISK
      val uwMedRisk = nullOnEmpty(readString(14, throwOnNoData = false)) // UW_100K_MEDRX_RISK
      val inputDataType = nullOnEmpty(readString(1, throwOnNoData = false)) // INPUT_DATA_TYPE
      val uWEnrollLength = nullOnEmpty(readString(3, throwOnNoData = false)) // UW_ENROLL_LENGTH
      val uWPartialEnroll = nullOnEmpty(readString(1, throwOnNoData = false)) // UW_PARTIAL_ENROLL
      val groupingEndDate = nullOnEmpty(readString(8, throwOnNoData = false)) // GROUPING_END_DATE
      val errorStatus = nullOnEmpty(readString(1, throwOnNoData = false)) // ERROR_STATUS
      val databaseVersion = nullOnEmpty(readString(4, throwOnNoData = false)) // DATABASE_VERSION


      sre_uwrisksummary(
        family_id = familyId,
        patient_id = patientId,
        age = if (age == null) null else age.toInt,
        gender = gender,
        uw_medrx_risk = if (uwMedrxRisk == null) null else uwMedrxRisk.toDouble,
        uw_med_risk = if (uwMedRisk == null) null else uwMedRisk.toDouble,
        input_data_type = inputDataType,
        uw_enroll_length = if (uWEnrollLength == null) null else uWEnrollLength.toInt,
        uw_partial_enroll = uWPartialEnroll,
        grouping_end_date = parseToTimestamp(groupingEndDate).orNull,
        error_status = errorStatus,
        database_version = databaseVersion,
        groupid = groupId
      )
    })
  }
}
