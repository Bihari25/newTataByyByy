package com.optum.oap.backend.acc

import com.optum.oap.utils.CliUtils
import org.rogach.scallop.ScallopConf
import org.slf4j.LoggerFactory

class Conf(arguments: Seq[String]) extends ScallopConf(arguments) {
    val basePath = opt[String](required = false, name = "basePath", argName = "basePath", descr = "Base path for hdfs before client id directory. Example - hdfs://somhorton1/optum/data_factory", default =Some("s3://CLIENT_BUCKET"))
    val env = opt[String](required = true, name = "environment", argName = "environment", descr = "Define the environment. Valid values are dev, qa, stg, prd")
    val clientId = opt[String](required = true, name = "clientId", argName = "clientId", descr = "Define the client id")
    val dateStamp = opt[String](required = false, name = "dateStamp", argName = "dateStamp", descr = "Define the date stamp folder. Format - yyyyMMdd")
    val processIds = opt[String](required = false, name = "processIds", argName = "processIds", descr = "Comma delimited list of processids to run.")
    val createEmptyParquet = opt[Boolean](required = false, name = "createEmptyParquet", argName = "createEmptyParquet", descr = "Should empty parquet files be re-created/overridden")
    val cdrLevel = opt[String](required = false, name = "cdrLevel", argName = "cdrLevel", descr = "CDR level value : ecdr vs cdr_be")
    val cdrCycle = opt[String](required = false, name = "cdrCycle", argName = "cdrCycle", descr = "CDR cycle : cdr_201811")
    val instance = opt[String](required = false, name = "instance", argName = "instance", descr = "instance name e.g. 1")
    val stream = opt[String](required = false, name = "stream", argName = "stream", descr = "acc stream , e.g. sre, ebm")
  verify()
}

object AccReturnLoader {

  private val log = LoggerFactory.getLogger(this.getClass)

  def main(args: Array[String]): Unit = {
    val conf = new Conf(args)

    val createEmpty = conf.createEmptyParquet.toOption.getOrElse(false)
    if(!createEmpty && !conf.processIds.isDefined) {
      throw new IllegalArgumentException("processIds is a required parameter when not generating empty parquet files.")
    }

    if(createEmpty && (conf.cdrLevel.isEmpty || conf.cdrCycle.isEmpty || conf.instance.isEmpty)) {
      throw new IllegalArgumentException("cdrLevel, cdrCycle && instance are required parameters when generating empty parquet files.")
    }

    val input = ToParquetInput(
      conf.basePath(),
      conf.env(),
      conf.clientId(),
      CliUtils.getOptionalString(conf.dateStamp),
      conf.processIds.getOrElse("").split(",").toSeq,
      "cdr_data_type_mapping.txt",
      createEmpty,
      CliUtils.getOptionalString(conf.cdrLevel),
      CliUtils.getOptionalString(conf.cdrCycle),
      CliUtils.getOptionalString(conf.instance),
      CliUtils.getOptionalString(conf.stream)
    )
    if (input.stream.isDefined) {
      SreEbmConverter(input).convert
    } else {
      ParquetConverter(input).convert
    }
  }
}
