package com.optum.oap.backend.acc.models.qme

import org.apache.spark.sql.{DataFrame, SparkSession, functions}
import org.apache.spark.sql.functions.{col, concat, expr, lit, substring}
import org.apache.spark.sql.types.StructType
import org.apache.spark.sql.functions._
import org.slf4j.LoggerFactory


object QmeHedisConversionModel {

  private val log = LoggerFactory.getLogger(this.getClass)


  def processHedisAuditOutput(sparkSession: SparkSession, resPath: String, groupId: String, schema: StructType, yr: String) :DataFrame = {

    import sparkSession.implicits._

    val versionMappingFile=broadcast(readMappingfile(sparkSession))

    val df = sparkSession.read.option("header", "false")
      .option("delimiter", ",")
      .csv(resPath)
      .toDF("grp_mpi", "population_id", "measure_audit_key", "contributing_object_name", "metric_code", "metric_value", "episode_identifier", "measurement_end_date", "measure_set","measure_name")

    val excludeColumns= Seq("measure_name","measure_set")

    val df1 = df
      .join(versionMappingFile, Seq("measure_set"),"left_outer")
      .withColumn("groupid", lit(groupId))
      .withColumn("version",coalesce($"version", lit("9999")))
      .withColumn("hum_vers_yr", concat(lit("V"), substring(col("version"), -4, 4), lit("_"), lit(yr.toUpperCase())))
      .withColumn("measure_audit_key",substring(col("measure_audit_key"), 1, 40))
      .drop(excludeColumns: _*)

    val lowerCaseColsDF = df1.toDF(df1.columns.map(_.toLowerCase): _*)

    val colMap = schema.map(s => (s.name, s.dataType)).map(sf => functions.col(sf._1).cast(sf._2).as(sf._1))
    lowerCaseColsDF.select(colMap: _*)

  }

  def processHedisMeasureResult(sparkSession: SparkSession, resPath: String, groupId: String, schema: StructType, yr: String) :DataFrame = {
    import sparkSession.implicits._

    val versionMappingFile=broadcast(readMappingfile(sparkSession))

    val df = sparkSession.read.option("header", "false")
      .option("delimiter", ",")
      .csv(resPath)
      .toDF("measure_id", "measure_name", "stratification_id", "grp_mpi", "result_answer", "denominator_flag", "denominator_exclusion_flag", "denominator_exception_flag",
        "numerator_flag", "numerator_exclusion_flag", "measurement_end_date", "qualifying_date", "run_date", "episode_number", "expected_visit_count", "actual_visit_count",
        "member_month_count", "days_count", "discharge_count", "services_count", "surgery_weight", "base_risk_weight", "age_and_gender_weight", "dcc_weight", "comorbidity_weight",
        "age", "gender", "risk_score", "adjusted_probability", "variance", "dcc_category", "population_id", "Provider_organization_id","supplemental_only_flag","base_risk_weight_2","age_and_gender_weight_2","comorbidity_weight_2","measure_set","source_measure","CMS_hospital_id","outlier","PLD_DEN","PLD_NUM","PLD_NUMSUPP","PLD_EXCP","PLD_EXCL")

    val excludeColumns= Seq("Provider_organization_id","supplemental_only_flag","base_risk_weight_2","age_and_gender_weight_2","comorbidity_weight_2","measure_set","source_measure","CMS_hospital_id","outlier","PLD_DEN","PLD_NUM","PLD_NUMSUPP","PLD_EXCP","PLD_EXCL")

    val df1 = df.join(versionMappingFile, Seq("measure_set"),"left_outer")
      .withColumn("groupid", lit(groupId))
      .withColumn("version",coalesce($"version", lit("9999")))
      .withColumn("hum_vers_yr", concat(lit("V"), substring(col("version"), -4, 4), lit("_"), lit(yr.toUpperCase())))
      .drop(excludeColumns: _*)

    val lowerCaseColsDF = df1.toDF(df1.columns.map(_.toLowerCase): _*)

    val colMap = schema.map(s => (s.name, s.dataType)).map(sf => functions.col(sf._1).cast(sf._2).as(sf._1))
    lowerCaseColsDF.select(colMap: _*)

  }

  def readMappingfile(sparkSession: SparkSession) ={
    import sparkSession.implicits._
    val iStream = this.getClass.getClassLoader().getResourceAsStream("version_map.txt")
    scala.io.Source.fromInputStream(iStream).getLines.foldLeft(Map.empty[String, String]) {
      case (mapResult, versionfile) =>
        val configParts = versionfile.split("\\|")

        val measureSet = configParts(0).trim
        val version = configParts(1).trim
        mapResult + (measureSet -> version)
    }.toSeq.toDF("measure_set", "version")
  }
}
