package com.optum.oap.backend.acc.models.ebm

import java.io.StringReader

import com.optum.oap.backend.acc.AbstractAcc
import com.optum.oap.backend.acc.lib.FieldReader
import com.optum.oap.backend.acc.util.AccUtil.parseToTimestamp
import com.optum.oap.cdr.models.ebm_memcondfile
import com.optum.oap.utils.Resource.using

/**
  *
  * Copyright 2019 Optum Analytics
  *
  * Date: 9/3/19
  *
  * Creator: pavula1
  */
/*
(
GRP_MPI                 POSITION(1:32),
REPORT_CASE_ID          POSITION(33:38),
COND_CONF_QUAL          POSITION(39:39),
FILE_PROCESSING_MONTH   "TO_DATE ('${dataname%%_*}', 'YYYYMMDD')",
GROUPID                 CONSTANT "${groupid}",
PROCESS                 CONSTANT "M"
)
 */
//965884657                       108900C
object EBMMemberConditionModel extends AbstractAcc[ebm_memcondfile] {

  override def processRowHelper(data: String, groupId: String, fileProcessingMonth: String): ebm_memcondfile = {
    using(new StringReader(data))(implicit reader => {
      val rd = FieldReader()
      import rd._

      val groupMpi = nullOnEmpty(readString(32)) // GRP_MPI
      val reportCaseId = nullOnEmpty(readString(6, throwOnNoData = false)) // REPORT_CASE_ID
      val condConQual = nullOnEmpty(readString(1, throwOnNoData = false)) // COND_CONF_QUAL


      ebm_memcondfile(
        grp_mpi = groupMpi,
        report_case_id = if(reportCaseId == null) null else reportCaseId.toInt,
        cond_conf_qual = condConQual,
        file_processing_month = parseToTimestamp(fileProcessingMonth).orNull,
        groupid = groupId,
        process = "M"
      )
    })
  }
}
