package com.optum.oap.backend.acc.models.ebm

import java.io.StringReader

import com.optum.oap.backend.acc.AbstractAcc
import com.optum.oap.backend.acc.lib.FieldReader
import com.optum.oap.backend.acc.util.AccUtil.parseToTimestamp
import com.optum.oap.cdr.models.ebm_memberevent
import com.optum.oap.utils.Resource.using

/**
  *
  * Copyright 2019 Optum Analytics
  *
  * Date: 9/3/19
  *
  * Creator: pavula1
  */

/* (
GRP_MPI                 POSITION(1:32),
REPORT_CASE_ID          POSITION(33:38),
EVENT                   POSITION(39:42),
EVENT_FROM_DATE         POSITION(43:50) DATE "YYYYMMDD",
EPISODE_FROM_DATE       POSITION(51:58) DATE "YYYYMMDD",
EPISODE_THRU_DATE       POSITION(59:66) DATE "YYYYMMDD",
EVENT_THRU_DATE         POSITION(67:74) DATE "YYYYMMDD",
UNIQUE_RECID            POSITION(75:102),
CARE_CAT                POSITION(103:105),
AGE                     POSITION(106:108),
AGE_MONTHS              POSITION(109:112),
EPISODE_PROVIDER        POSITION(113:132),
EPISODE_PROV_SPEC       POSITION(133:134),
FILE_PROCESSING_MONTH   "TO_DATE ('${dataname%%_*}', 'YYYYMMDD')",
GROUPID                 CONSTANT "${groupid}" ,
PROCESS                 CONSTANT "M"
)
 */
// 818572563                       206800   520180621201806212018062120180621MED6212.12283351                34 41534773384            HL
object EBMEventModel extends AbstractAcc[ebm_memberevent] {
  override def processRowHelper(data: String, groupId: String, fileProcessingMonth: String): ebm_memberevent = {
    using(new StringReader(data))(implicit reader => {
      val rd = FieldReader()
      import rd._

      val groupMpi = nullOnEmpty(readString(32)) // GRP_MPI
      val reportCaseId = nullOnEmpty(readString(6, throwOnNoData = false)) // REPORT_CASE_ID
      val event = nullOnEmpty(readString(4, throwOnNoData = false)) // EVENT
      val eventFromDate = nullOnEmpty(readString(8, throwOnNoData = false)) // EVENT_FROM_DATE
      val episodeFromDate = nullOnEmpty(readString(8, throwOnNoData = false)) // EPISODE_FROM_DATE
      val episodeThroughDate = nullOnEmpty(readString(8, throwOnNoData = false)) // EPISODE_THRU_DATE
      val eventThroughDate = nullOnEmpty(readString(8, throwOnNoData = false)) // EVENT_THRU_DATE
      val uniqueRecordId = nullOnEmpty(readString(28, throwOnNoData = false)) // UNIQUE_RECID
      val careCat = nullOnEmpty(readString(3, throwOnNoData = false)) // CARE_CAT
      val age = nullOnEmpty(readString(3, throwOnNoData = false)) // AGE
      val ageMonths = nullOnEmpty(readString(4, throwOnNoData = false)) // AGE_MONTHS
      val episodeProvider = nullOnEmpty(readString(20, throwOnNoData = false)) // EPISODE_PROVIDER
      val episodeProvSpec = nullOnEmpty(readString(2, throwOnNoData = false)) // EPISODE_PROV_SPEC


      ebm_memberevent(
        age = if (age == null) null else age.toInt,
        age_months = if (ageMonths == null) null else ageMonths.toInt,
        care_cat = careCat,
        episode_from_date = parseToTimestamp(episodeFromDate).orNull,
        episode_prov_spec = episodeProvSpec,
        episode_provider = episodeProvider,
        episode_thru_date = parseToTimestamp(episodeThroughDate).orNull,
        event = if (event == null) null else event.toInt,
        event_from_date = parseToTimestamp(eventFromDate).orNull,
        event_thru_date = parseToTimestamp(eventThroughDate).orNull,
        file_processing_month = parseToTimestamp(fileProcessingMonth).orNull,
        groupid = groupId,
        grp_mpi = groupMpi,
        process = "M",
        report_case_id = if (reportCaseId == null) null else reportCaseId.toInt,
        unique_recid = uniqueRecordId
      )
    })

  }
}