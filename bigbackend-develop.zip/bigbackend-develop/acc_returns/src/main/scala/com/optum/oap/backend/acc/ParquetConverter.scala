package com.optum.oap.backend.acc

import com.optum.oap.backend.acc.Validation._
import com.optum.oap.backend.acc.models.qme.QmeHedisConversionModel
import com.optum.oap.backend.acc.util.AccUtil._
import com.optum.oap.backend.acc.util.{ACCParquetConversionException, AccUtil, EmptyParquetUtils}
import com.optum.oap.backend.util.ColumnDataTypeMapping
import com.optum.oap.backend.util.ConverterUtils._
import com.optum.oap.sparklib.{HDFSUtils, SparkUtils}
import com.optum.oap.utils.ExitCode
import com.optum.oap.utils.Resource._
import org.apache.hadoop.fs.FileSystem
import org.apache.spark.sql.catalyst.encoders.RowEncoder
import org.apache.spark.sql.{DataFrame, SaveMode, SparkSession}
import org.slf4j.LoggerFactory

import scala.collection.mutable
import scala.collection.mutable.ListBuffer
import scala.concurrent.duration.Duration
import scala.concurrent.{Await, Future}

/**
  *
  * Copyright 2019 Optum Analytics
  *
  * Date: 8/22/19
  *
  * Creator: pavula1
  */
class ParquetConverter(input: ToParquetInput) {

  private val log = LoggerFactory.getLogger(this.getClass)

  val saveMode = SaveMode.Overwrite

  def convert: ExitCode = {

    val configStream = this.getClass.getClassLoader().getResourceAsStream(input.configFile)

    val mapModelConfig = readAllConfig(configStream)

    val mapControlConfig = readControlConfig()

    using(SparkUtils.createSparkSession("acc_return-loader", verboseLogging = false, logWarnings = true))(implicit sparkSession => {
      HDFSUtils.setSecurityAuthentication("simple")
      val fs = HDFSUtils.getHDFSFileSystem(input.basePath)

      if (input.createEmptyParquet) {
        EmptyParquetUtils(sparkSession, input.clientId, input.env, input.cdrLevel, input.cdrCycle, input.instance, input.basePath, mapModelConfig, mapControlConfig).handleEmptyParquet
      } else {

        val hedisProcessIds = input.processIds.foldLeft(Seq.empty[String]) {
          case (hPI, processId) =>
            log.warn(s"ProcessId that is being processed $processId")
            val pathWithProcessId = getPathWithProcessId(input.basePath, input.env, input.cdrCycle.get, input.instance.get, processId)
            if (HDFSUtils.ifPathExists(fs, s"$pathWithProcessId/in_hedis")) {
              hPI :+ processId
            } else if (HDFSUtils.ifPathExists(fs, s"$pathWithProcessId/in_qme")) {
              log.warn(s"Calculated pathWithProcessId: ${pathWithProcessId} in ParquetConverter.convert")
              processQmeFiles(sparkSession, fs, mapControlConfig, mapModelConfig, pathWithProcessId)
              hPI
            }
            else {
              throw ACCParquetConversionException("The processid does not have the required hdfs directory for the return files.")
            }
        }

      }

      ExitCode.SUCCESS
    })
  }

  private def getPathForFiles(path: String, dateStamp: Option[String], fs: FileSystem): String = {

    val pathWithDate = if (dateStamp.isEmpty) getFilePathWithLatestDateDir(path, fs) else s"$path/${dateStamp.get}"

    val finalPath = s"$pathWithDate/landed"

    if (HDFSUtils.ifPathExists(fs, finalPath)) {
      log.warn(s"Final resolved path to look for ACC files: $finalPath")
      finalPath
    } else {
      throw ACCParquetConversionException(s"Resolved path $finalPath does not exists")
    }

  }

  def processEbmFiles(sparkSession: SparkSession, fs: FileSystem, mapControlConfig: Map[String, String], path: String): Unit = {
    import scala.concurrent.ExecutionContext.Implicits.global

    val ebmFilePath = getPathForFiles(s"$path/in_ebm/monthly", input.dateStamp, fs)

    log.warn(s"EBM file path $ebmFilePath")

    val controlTotalFiles = loadAndValidate(sparkSession, ebmFilePath, fs)

    val gzFiles = loadGZFiles(fs, ebmFilePath)

    val dfMap = mutable.Map[String, DataFrame]()

    controlTotalFiles.foreach(
      cFile =>  {
        val resPath = gzFiles(cFile.fileName)

        log.warn(s"Processing EBM file ${cFile.fileName} at location $resPath")
        val fileName = cFile.fileName.toLowerCase().split("_").drop(3).mkString("_").split("\\.").head

        val df = sparkSession.read.text(resPath)
        val clientId = input.clientId
        val outDf = df.map(r => ACCFactory(fileName).processRow(r.mkString, clientId, cFile.fileName.split("_").head))(RowEncoder(ACCFactory(fileName).schema))
        val modelName = mapControlConfig(fileName).toUpperCase()
        if (dfMap.contains(modelName)) {
          dfMap.put(modelName, dfMap(modelName).union(outDf))
        } else {
          dfMap.put(modelName, outDf)
        }
      })

    val result = Future.traverse(dfMap) {
      df =>
        Future {
          try {
            val destLocation = getDestinationPath(ebmFilePath, df._1.toUpperCase())
            sparkSession.sparkContext.setJobDescription(s"Processing {$df._1}")
            log.warn(s"Started writing EBM data to parquet file at $destLocation")
            df._2.repartition(16).write.mode(saveMode).format("parquet").save(destLocation)
          }  catch {
            case e: Exception =>
              throw ACCParquetConversionException(s"Error while processing {$df._1}: ${e.getMessage}")
          }
        }
    }
    Await.result(result, Duration.Inf)
    log.warn(s"Writing EBM data to parquet files completed successfully.")

  }

  def processSreFiles(sparkSession: SparkSession, fs: FileSystem, mapControlConfig: Map[String, String], path: String): Unit = {
    import scala.concurrent.ExecutionContext.Implicits.global
    val sreFilePath = getPathForFiles(s"$path/in_sre/monthly", input.dateStamp, fs)

    log.warn(s"SRE file path $sreFilePath")

    val controlTotalFiles = loadAndValidate(sparkSession, sreFilePath, fs)

    val gzFiles = loadGZFiles(fs, sreFilePath)

    val result = Future.traverse(controlTotalFiles) {
      cFile =>
        Future {
          val resPath = gzFiles(cFile.fileName)

          log.warn(s"Processing SRE file ${cFile.fileName} with location $resPath")
          val fileName = cFile.fileName.split("_").drop(2).mkString("_").split("\\.").head.toLowerCase()

          val df = sparkSession.read.text(resPath)
          val clientId = input.clientId
          val fileFirst =  cFile.fileName.split("_").head
          val outDf = df.map(r => ACCFactory(fileName).processRow(r.mkString, clientId, fileFirst))(RowEncoder(ACCFactory(fileName).schema))

          try {
            val destLocation = getDestinationPath(sreFilePath, mapControlConfig(fileName).toUpperCase())
            sparkSession.sparkContext.setJobDescription(s"Processing {$fileName}")
            log.warn(s"Started writing SRE data to parquet file at $destLocation")
            outDf.repartition(4).write.mode(saveMode).format("parquet").save(destLocation)
          } catch {
            case e: Exception =>
              throw ACCParquetConversionException(s"Error while processing  SRE file $fileName: ${e.getMessage}")
          }
        }
    }
    Await.result(result, Duration.Inf)

    log.warn(s"Writing SRE data to parquet files completed successfully.")

  }

  def processQmeFiles(sparkSession: SparkSession, fs: FileSystem, mapControlConfig: Map[String, String], mapModelConfig: Map[String, ListBuffer[ColumnDataTypeMapping]], path: String): Unit = {

    import scala.concurrent.ExecutionContext.Implicits.global

    val clientId = input.clientId
    val yearsProcessing : Seq[String] = Seq("yr0","yr1","yr2")
    val hedisDfMap = mutable.Map[String, DataFrame]()

    yearsProcessing.foreach(yr => {

      val hedisFilePath = s"$path/in_qme/$yr"

      log.warn(s"QME HEDIS file path $hedisFilePath")

      val controlTotalFiles = loadAndValidate(sparkSession, hedisFilePath, fs)

      val gzFiles = loadGZFiles(fs, hedisFilePath)

      controlTotalFiles.foreach(
        cFile => {
          val resPath = gzFiles(cFile.fileName)

          log.warn(s"Processing HEDIS file  location $resPath")
          val fileName = cFile.fileName.split("_").drop(4).mkString("_").split("\\.").head.toLowerCase()
          val modelName = mapControlConfig(fileName)
          val schema = getModelSchema(mapModelConfig(modelName.toLowerCase()))

          val outDf = if (modelName == "HEDIS_AUDIT_OUTPUT") QmeHedisConversionModel.processHedisAuditOutput(sparkSession, resPath, clientId, schema, yr) else QmeHedisConversionModel.processHedisMeasureResult(sparkSession, resPath, clientId, schema, yr)

          if (hedisDfMap.contains(modelName)) {
            hedisDfMap.put(modelName, hedisDfMap(modelName).union(outDf))
          } else {
            hedisDfMap.put(modelName, outDf)
          }

        })

      if(yr == yearsProcessing.last) {
        val result = Future.traverse(hedisDfMap) {
          df =>
            Future {
              try {
                val date = hedisFilePath.split("/").dropRight(1).last
                val processId= hedisFilePath.split("/").dropRight(4).last
                val destLocation = AccUtil.getDestinationPath(input.basePath,
                                                              input.env,
                                                              input.cdrCycle.get,
                                                              input.instance.get,
                                                              df._1.toUpperCase())
                sparkSession.sparkContext.setJobDescription(s"Processing {$df._1}")
                log.warn(s"Started writing QME HEDIS data to parquet file at $destLocation")
                df._2.write.mode(saveMode).format("parquet").save(destLocation)
              }
              catch {
                case e: Exception =>
                  throw ACCParquetConversionException(s"Error while processing QME HEDIS file ${df._1}: ${e.getMessage}")
              }

            }
        }
        Await.result(result, Duration.Inf)
      }

    })

    log.warn(s"Writing QME HEDIS data to parquet files completed successfully.")
  }


  def loadAndValidate(sparkSession:SparkSession, filePath: String, fs: FileSystem) :Seq[FileCount] = {
    val allFiles = HDFSUtils.getAllFiles(fs, filePath)
    val gzFiles = allFiles.filter(x => x._1.toLowerCase.contains(".gz"))
    val ctFile = allFiles.filter(x => x._1.toLowerCase.contains("control_totals.dat")|| x._1.toLowerCase.contains("control.ctl")) //change for Qme
    if (ctFile.size > 1) {
      throw ACCParquetConversionException(s"More than 1 control file exists at path $filePath")
    } else if (ctFile.size < 1) {
      throw ACCParquetConversionException(s"Control file does not exists at path $filePath")
    }

    val controlTotalFiles = loadControlTotalsFile(allFiles(ctFile.head._1))
    fileLevelValidation(sparkSession, gzFiles.keySet, controlTotalFiles, filePath)

    controlTotalFiles
  }

  def loadGZFiles(fs: FileSystem, filePath: String): Map[String, String] = {
    val allFiles = HDFSUtils.getAllFiles(fs, filePath)
    allFiles.filter(x => x._1.toLowerCase.contains(".gz"))
  }

}

object ParquetConverter {
  def apply(input: ToParquetInput): ParquetConverter = new ParquetConverter(input)
}


case class ToParquetInput(basePath: String, env: String, clientId: String, dateStamp: Option[String], processIds: Seq[String], configFile: String,
                          createEmptyParquet: Boolean = false, cdrLevel: Option[String], cdrCycle: Option[String], instance: Option[String], stream: Option[String])