package com.optum.oap.backend.acc.lib

import java.text.ParseException

import scala.annotation.tailrec

case class LongRefCell(var v: Long = 0L) // The hoops we jump through to avoid heap allocation

object LongParser {
  private val STATE_TRIM_LEFT = 0
  private val STATE_NEG = 1
  private val STATE_DIGITS = 2
  private val STATE_NEG_DIGITS = 3
  private val STATE_TRIM_RIGHT = 4

  private val MAX_MULTIPLIABLE_BY_10: Long = 922337203685477580L
  private val MIN_MULTIPLIABLE_BY_10: Long  = -922337203685477580L

  // Implement a DFA to parse a number
  def parse(implicit fieldSize: Int, buff: Array[Char], outValue: LongRefCell): Unit = {
    outValue.v = 0L
    parse(0, STATE_TRIM_LEFT)
  }

  @tailrec
  private def parse(pos: Int, state: Int)(implicit fieldSize: Int, buff: Array[Char], outValue: LongRefCell): Unit = {
    state match {
      case STATE_TRIM_LEFT =>
        if(pos < fieldSize) {
          val ch = buff(pos)
          if (ch == ' ') {
            parse(pos + 1, STATE_TRIM_LEFT)
          } else if (ch == '-') {
            parse(pos + 1, STATE_NEG)
          } else if (ch >= '0' && ch <= '9') {
            parse(pos, STATE_DIGITS)
          } else {
            fail
          }
        } else {
          fail
        }

      case STATE_NEG =>
        if(pos < fieldSize) {
          val ch = buff(pos)
          if(ch >= '0' && ch <= '9') {
            parse(pos, STATE_NEG_DIGITS)
          } else {
            fail
          }
        } else {
          fail
        }

      case STATE_DIGITS =>
        if(pos < fieldSize) {
          val ch = buff(pos)
          if(ch >= '0' && ch <= '9') {
            val t1 = outValue.v
            if(t1 > MAX_MULTIPLIABLE_BY_10) failFormat
            val t2 = t1 * 10L
            val digit = ch - '0'
            if(Long.MaxValue - digit < t2) failFormat
            outValue.v = t2 + digit
            parse(pos + 1, STATE_DIGITS)
          } else if(ch == ' ') {
            parse(pos + 1, STATE_TRIM_RIGHT)
          } else {
            fail
          }
        } // else, accepting state, fall through

      case STATE_NEG_DIGITS =>
        if(pos < fieldSize) {
          val ch = buff(pos)
          if(ch >= '0' && ch <= '9') {
            val t1 = outValue.v
            if(t1 < MIN_MULTIPLIABLE_BY_10) failFormat
            val t2 = t1 * 10
            val digit = ch - '0'
            if(Long.MinValue + digit > t2) failFormat
            outValue.v = t2 - digit
            parse(pos + 1, STATE_NEG_DIGITS)
          } else if(ch == ' ') {
            parse(pos + 1, STATE_TRIM_RIGHT)
          } else {
            fail
          }
        } // else, accepting state, fall through

      case STATE_TRIM_RIGHT =>
        if(pos < fieldSize) {
          val ch = buff(pos)
          if(ch == ' ') {
            parse(pos + 1, STATE_TRIM_RIGHT)
          } else {
            fail
          }
        } // else, accepting state, fall through

      case _ => throw new IllegalStateException()
    }
  }

  private def fail(implicit fieldSize: Int, buff: Array[Char]): Nothing = {
    throw new ParseException(s"Failed to parse the field '${new String(buff, 0, fieldSize)}' as a Long.", 0)
  }

  private def failFormat(implicit fieldSize: Int, buff: Array[Char]): Nothing = {
    throw new NumberFormatException(s"Underflow or overflow parsing the field '${new String(buff, 0, fieldSize)}' as a Long.")
  }
}