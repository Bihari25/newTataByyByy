package com.optum.oap.backend.acc

import com.optum.oap.backend.acc.util.AccUtil._
import com.optum.oap.backend.acc.util.{ACCParquetConversionException, AccUtil, EmptyParquetUtils}
import com.optum.oap.backend.util.ConverterUtils._
import com.optum.oap.sparklib.{HDFSUtils, SparkUtils}
import com.optum.oap.utils.ExitCode
import com.optum.oap.utils.Resource.using
import org.apache.hadoop.fs.FileSystem
import org.apache.spark.sql.catalyst.encoders.RowEncoder
import org.apache.spark.sql.{DataFrame, SaveMode, SparkSession}
import org.slf4j.LoggerFactory

import scala.collection.{Set, mutable}
import scala.concurrent.duration.Duration
import scala.concurrent.{Await, Future}
import scala.util.{Failure, Success}

class SreEbmConverter(input: ToParquetInput) extends Serializable {

  private val log = LoggerFactory.getLogger(this.getClass)

  val saveMode = SaveMode.Overwrite

  def convert: ExitCode = {

    val configStream = this.getClass.getClassLoader.getResourceAsStream(input.configFile)

    val mapModelConfig = readAllConfig(configStream)

    val mapControlConfig = readControlConfig()

    log.error("Here before creating spark session")

    using(SparkUtils.createSparkSession(s"ebm_sre_return_${input.clientId}_${input.cdrCycle}-loader", verboseLogging = true, logWarnings = true))(implicit sparkSession => {
      HDFSUtils.setSecurityAuthentication("simple")
      val fs = HDFSUtils.getHDFSFileSystem(input.basePath)

      if (input.createEmptyParquet) {
        EmptyParquetUtils(sparkSession, input.clientId, input.env, input.cdrLevel, input.cdrCycle, input.instance, input.basePath, mapModelConfig, mapControlConfig).handleEmptyParquet
      } else {

        input.processIds.foreach(processId => {
          log.warn(s"ProcessId that is being processed $processId")
          val streamPath = getAccInhouseBaseStreamPath(input.basePath, input.env, input.cdrCycle.get, input.instance.get)
          if (HDFSUtils.ifPathExists(fs, s"$streamPath/bpo_pyr_sre/$processId")) {
            processSreReturns(sparkSession, fs, mapControlConfig, s"$streamPath/bpo_pyr_sre/$processId", processId, input, "SRE")
          }
          else if (HDFSUtils.ifPathExists(fs, s"$streamPath/bpo_pyr_ebm/$processId")) {
            processEbmReturns(sparkSession, fs, mapControlConfig, s"$streamPath/bpo_pyr_ebm/$processId", processId, input, "EBM")
          }
          else {
            throw ACCParquetConversionException("The processid does not have the required hdfs directory for the return files.")
          }
        })
      }
      ExitCode.SUCCESS
    })
  }

  def processEbmReturns(sparkSession: SparkSession, fs: FileSystem, mapControlConfig: Map[String, String], path: String, processId: String, input: ToParquetInput, stream: String): Unit = {
    log.warn(s"running ebm processId=$processId, path= $path")
    val requiredEbmFiles = Set("PHYSICIANVISIT", "SUMMARYRESULT", "EVENT", "EVENTPHYSICIAN",
      "FACILITYEVENT", "MEMBERDETAIL", "MEMBERCONDITION", "DRUGADHERENCE")
    validateEbmReturnsJobCompletion(path, fs, stream, requiredEbmFiles)

    val allEndDataFolders = HDFSUtils.getAllSubDirs(fs, s"$path/analytic=ebm")
      .filter(f => f._1.startsWith("enddate="))

    val allDataFolders = for {
      endDateFolder <- allEndDataFolders
      allDomainFolders <- HDFSUtils.getAllSubDirs(fs, s"${endDateFolder._2}")
      mName = allDomainFolders._1.split("=").last.toUpperCase()
      if requiredEbmFiles.contains(mName)
    } yield {
      val dateStamp = AccUtil.getDateStamp(endDateFolder._1)
      outputh_folder_info(modelName = allDomainFolders._1, modelPath = allDomainFolders._2, dateStamp)
    }
    processDataFolders(allDataFolders, sparkSession, input.basePath, input.env, input.cdrCycle.get, input.instance.get, stream, mapControlConfig)
  }


  def validateEbmReturnsJobCompletion(filePath: String, fs: FileSystem, stream: String, requiredEbmFiles: Set[String]): Unit = {
    val successFileExists = HDFSUtils.ifPathExists(fs, s"$filePath/_SUCCESS")
    //now that success file exists, make sure all required files are also present
    if (successFileExists) {
      log.warn(s"_success file found for stream: $stream")
      log.warn(s"filepath: $filePath")

      // make sure all domains are present within each enddate folder
      val allDomainsPresentForAllEndDates = HDFSUtils.getAllSubDirs(fs, s"$filePath/analytic=ebm")
        .keys
        .filter(f => f.startsWith("enddate="))
        .map(endDateFolderName => {
          // get all files within enddate
          log.warn(s"processing enddate $endDateFolderName")
          val allAvailableDomainsUpperCased = HDFSUtils.getAllSubDirs(fs, s"$filePath/analytic=ebm/$endDateFolderName")
            .keys
            .map(x => x.split("=").last.toUpperCase().trim)
            .toSet
          log.warn(s"all available domains within $endDateFolderName =  $allAvailableDomainsUpperCased")
          requiredEbmFiles.subsetOf(allAvailableDomainsUpperCased)
        }).reduce(_ && _)

      if (!allDomainsPresentForAllEndDates) {
        throw ACCParquetConversionException(s"EBM returns doesn't contains all required files.")
      }
    } else {
      log.error(s"_success file not found for : $stream in path $filePath. Did EMR job complete successfully ??")
    }
  }

  def processSreReturns(sparkSession: SparkSession, fs: FileSystem, mapControlConfig: Map[String, String], path: String, processId: String, input: ToParquetInput, stream: String): Unit = {

    validateSreReturnsJobCompletion(path, fs, stream)
    //calculate all data folders
    val allOutputFolders = HDFSUtils.getAllSubDirs(fs, s"$path/analytic=sre")
    val allDataFolders = for {
      outputFolder <- allOutputFolders
      mName = outputFolder._1.split("=").last.toUpperCase()
    } yield {
      outputh_folder_info(modelName = mName, modelPath = outputFolder._2, "")
    }

    processDataFolders(allDataFolders, sparkSession, input.basePath, input.env, input.cdrCycle.get, input.instance.get, stream, mapControlConfig)
  }

  def processDataFolders(allDataFolders: Iterable[outputh_folder_info], sparkSession: SparkSession, basePath: String, env: String, cdrCycle: String, instance: String, stream: String, mapControlConfig: Map[String, String]): Unit = {
    val dfMap = mutable.Map[String, DataFrame]()
    allDataFolders.foreach(model_name_path => {
      log.warn(s"processing ${model_name_path.modelName} - ${model_name_path.modelPath}")
      val fileName = getModelName(model_name_path.modelName)
      val modelPath = model_name_path.modelPath
      val df = sparkSession.read.text(modelPath)
      val dateStamp = model_name_path.dateStamp
      if (stream.equalsIgnoreCase("EBM") && parseToTimestamp(dateStamp).isEmpty) {
        throw ACCParquetConversionException(s"Error parsing the datestamp for EBM files")
      }
      val outDf = df.map(r => ACCFactory(fileName).processRow(r.mkString, input.clientId, dateStamp))(RowEncoder(ACCFactory(fileName).schema))
      val modelName = mapControlConfig(fileName).toUpperCase()
      if (dfMap.contains(modelName)) {
        dfMap.put(modelName, dfMap(modelName).union(outDf))
      } else {
        dfMap.put(modelName, outDf)
      }
    })
    writeDataFrame(sparkSession, input.basePath, input.env, input.cdrCycle.get, input.instance.get, dfMap.toMap, stream)
  }

  def validateSreReturnsJobCompletion(filePath: String, fs: FileSystem, stream: String): Unit = {
    // make sure _SUCCESS folder is there. If there is _SUCCESS folder, its the indication that job succedded
    val successFileExists = HDFSUtils.ifPathExists(fs, s"$filePath/_SUCCESS")
    //now that success file exists, make sure all required files are also present
    if (successFileExists) {
      log.warn(s"_success file found for stream: $stream")
      log.warn(s"filepath: $filePath")
      val requiredSreFiles = Set("CMRISKSUMMARY", "MARKERPROFILE", "UWRISKSUMMARY")
      val allAvailableFilesUpperCased = HDFSUtils.getAllSubDirs(fs, s"$filePath/analytic=sre")
        .keys
        .map(x => x.split("=").last.toUpperCase().trim)
        .toSet
      log.warn(s"available files are ${allAvailableFilesUpperCased.mkString(",")}")
      log.warn(s"required files are ${requiredSreFiles.mkString(",")}")

      val allFilesPresent = requiredSreFiles.subsetOf(allAvailableFilesUpperCased)
      log.warn(s"all files present for stream ? $stream : $allFilesPresent")
      if (!allFilesPresent) {
        throw ACCParquetConversionException(s"Files not found required=${requiredSreFiles.toString()}, available=${allAvailableFilesUpperCased.toString()}")
      }
    } else {
      throw ACCParquetConversionException(s"_success file not found for : $stream in path $filePath. Did EMR job complete successfully ??")
    }
  }

  def writeDataFrame(sparkSession: SparkSession, basePath: String, env: String, cdrCycle: String, instance: String, resultDataframe: Map[String, DataFrame], stream: String): Unit = {
    log.warn("writing dataframe result to destination")
    log.warn(s"models to be written ${resultDataframe.keys}")
    import scala.concurrent.ExecutionContext.Implicits.global

    val allDataFrameFutures = resultDataframe.map(modelDf => {
      val fut = Future {
        val destLocation = AccUtil.getDestinationPath(basePath, env, cdrCycle, instance, modelDf._1.toUpperCase())
        sparkSession.sparkContext.setJobDescription(s"Processing {$modelDf._1}")
        log.warn(s"Started writing $stream data to parquet file at $destLocation")
        modelDf._2.repartition(16).write.mode(SaveMode.Overwrite).format("parquet").save(destLocation)
      }
      fut.onComplete {
        case Success(_) => log.warn(s"Done processing ${modelDf._2}")
        case Failure(_) => log.error(s" Failure processing ${modelDf._2}")
      }
      fut
    })

    val dataFrameSequences = Future.sequence(allDataFrameFutures)
    Await.result(dataFrameSequences, Duration.Inf)
    log.warn(s"Writing $stream data to parquet files completed succesfully.")
  }

}

object SreEbmConverter {
  def apply(input: ToParquetInput): SreEbmConverter = new SreEbmConverter(input)
}

//dateStamp is only relevant for ebm
case class outputh_folder_info(modelName: String, modelPath: String, dateStamp: String)

