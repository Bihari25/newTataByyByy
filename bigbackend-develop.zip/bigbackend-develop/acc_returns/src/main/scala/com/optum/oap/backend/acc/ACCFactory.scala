package com.optum.oap.backend.acc

import com.optum.oap.backend.acc.models.ebm._
import com.optum.oap.backend.acc.models.sre.{SRECMRiskSummaryModel, SREMarkerProfileModel, SREUWRiskSummaryModel}
import org.apache.spark.sql.catalyst.encoders.RowEncoder
import org.apache.spark.sql.catalyst.expressions.GenericRowWithSchema
import org.apache.spark.sql.types.StructType
import org.apache.spark.sql.{Encoders, Row}

import scala.reflect.runtime.universe.{TypeTag, _}

/**
  *
  * Copyright 2019 Optum Analytics
  *
  * Date: 9/9/19
  *
  * Creator: pavula1
  */
abstract class AbstractAcc[A <: Product : TypeTag] {

  final lazy val schema: StructType = getSchema
  final lazy val rowEncoder = RowEncoder(schema)

  /**
    * Method that returns the schema to validate against. Defaults to schema of the case class.
    * @return
    */
  protected def getSchema: StructType = {
    if (typeOf[A] == typeOf[Nothing]) {
      throw new NotImplementedError(s"Missing type parameter for AbstractAcc $typeOf[A]")
    }

    Encoders.product[A].schema
  }

  final def processRow(data: String, groupId: String, fileProcessingMonth: String): Row = {
    val convertToRow = processRowHelper(data, groupId, fileProcessingMonth)

    new GenericRowWithSchema(convertToRow.productIterator.toSeq.toArray, schema)
  }

  protected def processRowHelper(data: String, groupId: String, fileProcessingMonth: String): A
}

object ACCFactory {

  def apply(s: String) = s match {
    case "drugadherence" => EBMDrugAdherenceModel
    case "event" => EBMEventModel
    case "eventphysician" => EBMEventPhysicianModel
    case "facilityevent" => EBMFacilityEventModel
    case "membercondition" => EBMMemberConditionModel
    case "memberdetail" => EBMMemberDetailModel
    case "physicianvisit" => EBMPhysicianVisitModel
    case "summaryresult" => EBMSummaryResultModel
    case "cmrisksummary" => SRECMRiskSummaryModel
    case "markerprofile" => SREMarkerProfileModel
    case "uwrisksummary" => SREUWRiskSummaryModel
  }

}

