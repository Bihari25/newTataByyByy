package com.optum.oap.backend.acc.models.ebm

import java.io.StringReader

import com.optum.oap.backend.acc.AbstractAcc
import com.optum.oap.backend.acc.lib.FieldReader
import com.optum.oap.backend.acc.util.AccUtil.parseToTimestamp
import com.optum.oap.cdr.models.ebm_drugadherence
import com.optum.oap.utils.Resource.using

/**
  *
  * Copyright 2019 Optum Analytics
  *
  * Date: 9/3/19
  *
  * Creator: pavula1
  */
/*
(
GRP_MPI                 POSITION(1:32),
REPORT_CASE_ID          POSITION(33:38),
EVENT                   POSITION(39:42),
REPORT_RULE_ID          POSITION(43:51),
DRUG_CLASS              POSITION(52:56),
CLASS_TYPE              POSITION(57:59),
NDC                     POSITION(60:70),
FILL_BEG                POSITION(71:78) DATE "YYYYMMDD",
FILL_END                POSITION(79:86) DATE "YYYYMMDD",
FIRST_UNIQUE_REC_ID     POSITION(87:114),
LAST_UNIQUE_REC_ID      POSITION(115:142),
FIRST_FILL              POSITION(143:150) DATE "YYYYMMDD",
LAST_FILL               POSITION(151:158) DATE "YYYYMMDD",
PROV                    POSITION(159:178),
PROV_SPEC               POSITION(179:180),
PROV_PART_CODE          POSITION(181:181),
POSS_RATIO              POSITION(182:190),
ELAPSED_DAYS            POSITION(191:194),
DAYS_SUP                POSITION(195:198),
SCRIPT_CNT              POSITION(199:202),
CALC_TYPE               POSITION(203:203)
FILE_PROCESSING_MONTH   "TO_DATE ('${dataname%%_*}', 'YYYYMMDD')", //This date comes from filename for eg. if filename is 20190430_38798_H000166_ebm_facility_event then 20190430 is the date
GROUPID                 CONSTANT "${groupid}",
PROCESS                 CONSTANT "M"
)
*/
// 696438102                            0   0  216300148302DCC518620007062018043020190729PHM9010.1890534             PHM9010.2242750             2018050820190727                    XX      1.13 445 504   7F
object EBMDrugAdherenceModel extends AbstractAcc[ebm_drugadherence] {

  override def processRowHelper(data: String, groupId: String, fileProcessingMonth: String): ebm_drugadherence = {
    using(new StringReader(data))(implicit reader => {
      val rd = FieldReader()
      import rd._
      val groupMpi = nullOnEmpty(readString(32)) // GRP_MPI
      val reportCaseId = nullOnEmpty(readString(6, throwOnNoData = false)) // REPORT_CASE_ID
      val event = nullOnEmpty(readString(4, throwOnNoData = false)) // EVENT
      val reportRuleId = nullOnEmpty(readString(9, throwOnNoData = false)) // REPORT_RULE_ID
      val drugClass = nullOnEmpty(readString(5, throwOnNoData = false)) // DRUG_CLASS
      val classType = nullOnEmpty(readString(3, throwOnNoData = false)) // CLASS_TYPE
      val ndc = nullOnEmpty(readString(11, throwOnNoData = false)) // NDC
      val fillBegin = nullOnEmpty(readString(8, throwOnNoData = false)) // FILL_BEG
      val fillEnd = nullOnEmpty(readString(8, throwOnNoData = false)) // FILL_END
      val firstUniqueRecordId = nullOnEmpty(readString(28, throwOnNoData = false)) // FIRST_UNIQUE_REC_ID
      val lastUniqueRecordId = nullOnEmpty(readString(28, throwOnNoData = false)) // LAST_UNIQUE_REC_ID
      val firstFill = nullOnEmpty(readString(8, throwOnNoData = false)) // FIRST_FILL
      val lastFill = nullOnEmpty(readString(8, throwOnNoData = false)) // LAST_FILL
      val prov = nullOnEmpty(readString(20, throwOnNoData = false)) // PROV
      val provSpec = nullOnEmpty(readString(2, throwOnNoData = false)) // PROV_SPEC
      val provPartCode = nullOnEmpty(readString(1, throwOnNoData = false)) // PROV_PART_CODE
      val possRatio = nullOnEmpty(readString(9, throwOnNoData = false)) // POSS_RATIO
      val elapsedDays = nullOnEmpty(readString(4, throwOnNoData = false)) // ELAPSED_DAYS
      val daysSup = nullOnEmpty(readString(4, throwOnNoData = false)) // DAYS_SUP
      val scriptCnt = nullOnEmpty(readString(4, throwOnNoData = false)) // SCRIPT_CNT
      val calcType = nullOnEmpty(readString(1, throwOnNoData = false)) // CALC_TYPE

      ebm_drugadherence(calc_type = calcType,
        class_type = classType,
        days_sup =  if (daysSup == null) null else daysSup.toInt,
        drug_class = drugClass,
        elapsed_days = if (elapsedDays == null) null else elapsedDays.toInt,
        event = if (event == null) null else event.toInt,
        file_processing_month = parseToTimestamp(fileProcessingMonth).orNull,
        fill_beg = parseToTimestamp(fillBegin).orNull,
        fill_end = parseToTimestamp(fillEnd).orNull,
        first_fill = parseToTimestamp(firstFill).orNull,
        first_unique_rec_id = firstUniqueRecordId,
        groupid = groupId,
        grp_mpi = groupMpi,
        last_fill = parseToTimestamp(lastFill).orNull,
        last_unique_rec_id = lastUniqueRecordId,
        ndc = ndc,
        poss_ratio = if (possRatio == null) null else possRatio.toDouble,
        process = "M",
        prov = prov,
        prov_part_code = provPartCode,
        prov_spec = provSpec,
        report_case_id = if (reportCaseId == null) null else reportCaseId.toInt,
        report_rule_id = if (reportRuleId == null) null else reportRuleId.toInt,
        script_cnt = if (scriptCnt == null) null else scriptCnt.toInt

      )
    })
  }
}
