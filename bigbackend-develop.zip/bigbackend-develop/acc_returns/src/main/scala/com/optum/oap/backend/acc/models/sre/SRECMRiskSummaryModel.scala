package com.optum.oap.backend.acc.models.sre

import java.io.StringReader

import com.optum.oap.backend.acc.AbstractAcc
import com.optum.oap.backend.acc.lib.FieldReader
import com.optum.oap.backend.acc.util.AccUtil.parseToTimestamp
import com.optum.oap.cdr.models.sre_cmrisksummary
import com.optum.oap.utils.Resource.using

/**
  *
  * Copyright 2019 Optum Analytics
  *
  * Date: 9/5/19
  *
  * Creator: bpokharel(bishu)
  */
/**
  * FAMILY_ID POSITION(1:30) ,
  * PATIENT_ID POSITION(31:32) ,
  * AGE POSITION(33:35) ,
  * GENDER POSITION(36:36) ,
  * CM_RISK  POSITION(37:46) ,
  * CM_IP_PROB  POSITION(47:56) ,
  * CM_IP_REL_RISK  POSITION(57:66) ,
  * CM_3MO_RISK  POSITION(67:76) ,
  * CM_3MO_IP_PROB  POSITION(77:86) ,
  * CM_3MO_IP_REL_RISK  POSITION(87:96) ,
  * CM_ED_PROB  POSITION(97:106) ,
  * CM_ED_REL_RISK  POSITION(107:116) ,
  * CM_LAB_RISK  POSITION(117:126) ,
  * CM_IP_RISK  POSITION(127:136) ,
  * CM_OP_RISK  POSITION(137:146) ,
  * CM_PROF_RISK  POSITION(147:156) ,
  * CM_ANC_RISK  POSITION(157:166) ,
  * CM_RX_RISK  POSITION(167:176) ,
  * DEMO_RISK  POSITION(177:186) ,
  * INPUT_DATA_TYPE  POSITION(187:187) ,
  * GROUPING_END_DATE  POSITION(188:195) DATE "YYYYMMDD" ,
  * ERROR_STATUS POSITION(196:196) ,
  * DATABASE_VERSION POSITION(197:200) ,
  * GROUPER_VERSION POSITION(201:202) ,
  * GROUPID CONSTANT "${groupid}"
  */
object SRECMRiskSummaryModel extends AbstractAcc[sre_cmrisksummary] {

  override def processRowHelper(data: String, groupId: String, fileProcessingMonth: String): sre_cmrisksummary = {
    using(new StringReader(data))(implicit reader => {
      val rd = FieldReader()
      import rd._

      val familyId = nullOnEmpty(readString(30)) // FAMILY_ID
      val patientId = nullOnEmpty(readString(2, throwOnNoData = false)) // PATIENT_ID
      val age = nullOnEmpty(readString(3, throwOnNoData = false)) // AGE
      val gender = nullOnEmpty(readString(1, throwOnNoData = false)) // GENDER
      val cmRisk = nullOnEmpty(readString(14, throwOnNoData = false)) // CM_RISK
      val cmIpProb = nullOnEmpty(readString(14, throwOnNoData = false)) // CM_IP_PROB
      val cmIpRelRisk = nullOnEmpty(readString(14, throwOnNoData = false)) // CM_IP_REL_RISK
      val cm3MoIpProb = nullOnEmpty(readString(14, throwOnNoData = false)) // CM_3MO_IP_PROB
      val cm3MoIpRelRisk = nullOnEmpty(readString(14, throwOnNoData = false)) // CM_3MO_IP_REL_RISK
      val cmEdProb = nullOnEmpty(readString(14, throwOnNoData = false)) // CM_ED_PROB
      val cmEdRelRisk = nullOnEmpty(readString(14, throwOnNoData = false)) // CM_ED_REL_RISK
      val cmLabRisk = nullOnEmpty(readString(14, throwOnNoData = false)) // CM_LAB_RISK
      val cmRxRisk = nullOnEmpty(readString(14, throwOnNoData = false)) // CM_RX_RISK
      val demoRisk = nullOnEmpty(readString(14, throwOnNoData = false)) // DEMO_RISK
      val inputDataType = nullOnEmpty(readString(1, throwOnNoData = false)) // INPUT_DATA_TYPE
      val cmEnrollLength = nullOnEmpty(readString(3, throwOnNoData = false)) // CM_ENROLL_LENGTH
      val cmPartialEnroll = nullOnEmpty(readString(1, throwOnNoData = false)) // CM_PARTIAL_ENROLL
      val groupingEndDate = nullOnEmpty(readString(8, throwOnNoData = false)) // GROUPING_END_DATE
      val errorStatus = nullOnEmpty(readString(1, throwOnNoData = false)) // ERROR_STATUS
      val databaseVersion = nullOnEmpty(readString(4, throwOnNoData = false)) // DATABASE_VERSION

      sre_cmrisksummary(
        family_id = familyId,
        patient_id = patientId,
        age = if (age == null) null else age.toInt,
        gender = gender,
        cm_risk = if (cmRisk == null) null else cmRisk.toDouble,
        cm_ip_prob = if (cmIpProb == null) null else cmIpProb.toDouble,
        cm_ip_rel_risk = if (cmIpRelRisk == null) null else cmIpRelRisk.toDouble,
        cm_3mo_ip_prob = if (cm3MoIpProb == null) null else cm3MoIpProb.toDouble,
        cm_3mo_ip_rel_risk = if (cm3MoIpRelRisk == null) null else cm3MoIpRelRisk.toDouble,
        cm_ed_prob = if (cmEdProb == null) null else cmEdProb.toDouble,
        cm_ed_rel_risk = if (cmEdRelRisk == null) null else cmEdRelRisk.toDouble,
        cm_lab_risk = if (cmLabRisk == null) null else cmLabRisk.toDouble,
        cm_enroll_length = if (cmEnrollLength == null) null else cmEnrollLength.toInt,
        cm_partial_enroll = if (cmPartialEnroll == null) null else cmPartialEnroll.toString,
        cm_rx_risk = if (cmRxRisk == null) null else cmRxRisk.toDouble,
        demo_risk = if (demoRisk == null) null else demoRisk.toDouble,
        input_data_type = inputDataType,
        grouping_end_date = parseToTimestamp(groupingEndDate).orNull,
        error_status = errorStatus,
        database_version = databaseVersion,
        groupid = groupId
      )
    })
  }
}
