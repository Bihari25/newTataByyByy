package com.optum.oap.backend.acc.models.ebm

import java.io.StringReader

import com.optum.oap.backend.acc.AbstractAcc
import com.optum.oap.backend.acc.lib.FieldReader
import com.optum.oap.backend.acc.util.AccUtil.parseToTimestamp
import com.optum.oap.cdr.models.ebm_physician_visit
import com.optum.oap.utils.Resource.using

/**
  *
  * Copyright 2019 Optum Analytics
  *
  * Date: 9/3/19
  *
  * Creator: pavula1
  */
/* (
GRP_MPI                 POSITION(1:32),
REPORT_CASE_ID          POSITION(33:38),
REPORT_RULE_ID          POSITION(39:47),
EVENT                   POSITION(48:51),
PROVIDER_ID             POSITION(52:71),
PROV_SPEC               POSITION(72:73),
IMPUTED_PHY_FLAG        POSITION(74:74),
RULE_START_DATE         POSITION(75:82) DATE "YYYYMMDD",
RULE_END_DATE           POSITION(83:90) DATE "YYYYMMDD",
FIRST_VISIT_DATE        POSITION(91:98) DATE "YYYYMMDD",
LAST_VISIT_DATE         POSITION(99:106) DATE "YYYYMMDD",
NUM_OF_VISITS           POSITION(107:110),
AMOUNT_PAID             POSITION(111:121),
AMOUNT_CHARGED          POSITION(122:132),
FILE_PROCESSING_MONTH   "TO_DATE ('${dataname%%_*}', 'YYYYMMDD')",
GROUPID                 CONSTANT "${groupid}"
)
 */
// 965760907                            4  5160001   034790881            PAN20180501201904302018050420190424  12     218.50     631.83
object EBMPhysicianVisitModel extends AbstractAcc[ebm_physician_visit] {

  override def processRowHelper(data: String, groupId: String, fileProcessingMonth: String): ebm_physician_visit = {
    using(new StringReader(data))(implicit reader => {
      val rd = FieldReader()
      import rd._

      val groupMpi = nullOnEmpty(readString(32)) // GRP_MPI
      val reportCaseId = nullOnEmpty(readString(6, throwOnNoData = false)) // REPORT_CASE_ID
      val reportRuleId = nullOnEmpty(readString(9, throwOnNoData = false)) // REPORT_RULE_ID
      val event = nullOnEmpty(readString(4, throwOnNoData = false)) // EVENT
      val providerId = nullOnEmpty(readString(20, throwOnNoData = false)) // PROVIDER_ID
      val provSpec = nullOnEmpty(readString(2, throwOnNoData = false)) // PROV_SPEC
      val imputedPhyFlag = nullOnEmpty(readString(1, throwOnNoData = false)) // IMPUTED_PHY_FLAG
      val ruleStartDate = nullOnEmpty(readString(8, throwOnNoData = false)) // RULE_START_DATE
      val ruleEndDate = nullOnEmpty(readString(8, throwOnNoData = false)) // RULE_END_DATE
      val firstVisitDate = nullOnEmpty(readString(8, throwOnNoData = false)) // FIRST_VISIT_DATE
      val lastVisitDate = nullOnEmpty(readString(8, throwOnNoData = false)) // LAST_VISIT_DATE
      val numOfVisits = nullOnEmpty(readString(4, throwOnNoData = false)) // NUM_OF_VISITS
      val amountPaid = nullOnEmpty(readString(11, throwOnNoData = false)) // AMOUNT_PAID
      val amountCharged = nullOnEmpty(readString(11, throwOnNoData = false)) // AMOUNT_CHARGED


      ebm_physician_visit(
        amount_charged = if(amountCharged == null) null else amountCharged.toDouble,
        amount_paid = if(amountPaid == null) null else amountPaid.toDouble,
        event = if(event == null) null else event.toInt,
        file_processing_month = parseToTimestamp(fileProcessingMonth).orNull,
        first_visit_date = parseToTimestamp(firstVisitDate).orNull,
        groupid = groupId,
        grp_mpi = groupMpi,
        imputed_phy_flag = imputedPhyFlag,
        last_visit_date = parseToTimestamp(lastVisitDate).orNull,
        num_of_visits = if(numOfVisits == null) null else numOfVisits.toInt,
        prov_spec = provSpec,
        provider_id = providerId,
        report_case_id = if(reportCaseId == null) null else reportCaseId.toInt,
        report_rule_id = if(reportRuleId == null) null else reportRuleId.toInt,
        rule_end_date = parseToTimestamp(ruleEndDate).orNull,
        rule_start_date = parseToTimestamp(ruleStartDate).orNull
      )
    })

  }
}
