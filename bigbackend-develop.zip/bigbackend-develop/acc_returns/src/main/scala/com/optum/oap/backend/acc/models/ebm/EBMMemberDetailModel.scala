package com.optum.oap.backend.acc.models.ebm

import java.io.StringReader

import com.optum.oap.backend.acc.AbstractAcc
import com.optum.oap.backend.acc.lib.FieldReader
import com.optum.oap.backend.acc.util.AccUtil.parseToTimestamp
import com.optum.oap.cdr.models.ebm_memberdetail
import com.optum.oap.utils.Resource.using

/**
  *
  * Copyright 2019 Optum Analytics
  *
  * Date: 9/3/19
  *
  * Creator: pavula1
  */
/*
 (
GRP_MPI                 POSITION(1:32),
BIRTH_DATE              POSITION(33:40)  DATE "YYYYMMDD",
GENDER                  POSITION(41:41),
PCP1                    POSITION(42:61),
PCP1_SPEC               POSITION(62:63),
PCP1_FLAG               POSITION(64:64),
PCP2                    POSITION(65:84),
PCP2_SPEC               POSITION(85:86),
PCP2_FLAG               POSITION(87:87),
PCP3                    POSITION(88:107),
PCP3_SPEC               POSITION(108:109),
PCP3_FLAG               POSITION(110:110),
IMP_PROV                POSITION(111:130),
IMP_PROV_SPEC           POSITION(131:132),
IMP_PROV_FLAG           POSITION(133:133),
IMP_OB_PROV             POSITION(134:153),
IMP_OB_PROV_SPEC        POSITION(154:155),
IMP_OB_PROV_FLAG        POSITION(156:156),
AGE                     POSITION(157:159),
AGE_IN_MONTHS           POSITION(160:163),
REPORT_PER_END          POSITION(164:171) DATE "YYYYMMDD",
MED                     POSITION(172:175),
RX                      POSITION(176:179),
FILE_PROCESSING_MONTH   "TO_DATE ('${dataname%%_*}', 'YYYYMMDD')",
GROUPID                 CONSTANT "${groupid}",
PROCESS                 CONSTANT "M"
)
  */
// 696936578                       20120806F                       34764654            XX 61822275            XX 9999999999999999999999                          6  80201904301430   1
object EBMMemberDetailModel extends AbstractAcc[ebm_memberdetail] {

  override def processRowHelper(data: String, groupId: String, fileProcessingMonth: String): ebm_memberdetail = {
    using(new StringReader(data))(implicit reader => {
      val rd = FieldReader()
      import rd._

      val groupMpi = nullOnEmpty(readString(32)) // GRP_MPI
      val birthDate = nullOnEmpty(readString(8, throwOnNoData = false)) // BIRTH_DATE
      val gender = nullOnEmpty(readString(1, throwOnNoData = false)) // GENDER
      val pcp1 = nullOnEmpty(readString(20, throwOnNoData = false)) // PCP1
      val pcp1Spec = nullOnEmpty(readString(2, throwOnNoData = false)) // PCP1_SPEC
      val pcp1Flag = nullOnEmpty(readString(1, throwOnNoData = false)) // PCP1_FLAG
      val pcp2 = nullOnEmpty(readString(20, throwOnNoData = false)) // PCP2
      val pcp2Spec = nullOnEmpty(readString(2, throwOnNoData = false)) // PCP2_SPEC
      val pcp2Flag = nullOnEmpty(readString(1, throwOnNoData = false)) // PCP2_FLAG
      val pcp3 = nullOnEmpty(readString(20, throwOnNoData = false)) // PCP3
      val pcp3Spec = nullOnEmpty(readString(2, throwOnNoData = false)) // PCP3_SPEC
      val pcp3Flag = nullOnEmpty(readString(1, throwOnNoData = false)) // PCP3_FLAG
      val impProv = nullOnEmpty(readString(20, throwOnNoData = false)) // IMP_PROV
      val impProvSpec = nullOnEmpty(readString(2, throwOnNoData = false)) // IMP_PROV_SPEC
      val impProvFlag = nullOnEmpty(readString(1, throwOnNoData = false)) // IMP_PROV_FLAG
      val impObProv = nullOnEmpty(readString(20, throwOnNoData = false)) // IMP_OB_PROV
      val impObProvSpec = nullOnEmpty(readString(2, throwOnNoData = false)) // IMP_OB_PROV_SPEC
      val impObProvFlag = nullOnEmpty(readString(1, throwOnNoData = false)) // IMP_OB_PROV_FLAG
      val age = nullOnEmpty(readString(3, throwOnNoData = false)) // AGE
      val ageInMonths = nullOnEmpty(readString(4, throwOnNoData = false)) // AGE_IN_MONTHS
      val reportPerEnd = nullOnEmpty(readString(8, throwOnNoData = false)) // REPORT_PER_END
      val med = nullOnEmpty(readString(4, throwOnNoData = false)) // MED
      val rx = nullOnEmpty(readString(4, throwOnNoData = false)) // RX

      ebm_memberdetail(
        age = if(age == null) null else age.toInt,
        age_in_months = if(ageInMonths == null) null else ageInMonths.toInt,
        birth_date = parseToTimestamp(birthDate).orNull,
        file_processing_month = parseToTimestamp(fileProcessingMonth).orNull,
        gender = gender,
        groupid = groupId,
        grp_mpi = groupMpi,
        imp_ob_prov = impObProv,
        imp_ob_prov_flag = impObProvFlag,
        imp_ob_prov_spec = impObProvSpec,
        imp_prov = impProv,
        imp_prov_flag = impProvFlag,
        imp_prov_spec = impProvSpec,
        med = if(med == null) null else med.toInt,
        pcp1 = pcp1,
        pcp1_flag = pcp1Flag,
        pcp1_spec = pcp1Spec,
        pcp2 = pcp2,
        pcp2_flag = pcp2Flag,
        pcp2_spec = pcp2Spec,
        pcp3 = pcp3,
        pcp3_flag = pcp3Flag,
        pcp3_spec = pcp3Spec,
        process = "M",
        report_per_end = parseToTimestamp(reportPerEnd).orNull,
        rx = if(rx == null) null else rx.toInt
      )
    })
  }

}
