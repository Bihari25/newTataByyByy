package com.optum.oap.backend.acc.util

import java.io.{BufferedReader, InputStreamReader}
import java.sql.Timestamp
import java.text.SimpleDateFormat

import com.optum.oap.backend.acc.{ACCValidationException, FileCount}
import com.optum.oap.sparklib.HDFSUtils
import org.apache.hadoop.fs.{FileSystem, Path}

import scala.util.Try
import scala.xml.{Elem, XML}

/**
  *
  * Copyright 2019 Optum Analytics
  *
  * Date: 8/27/19
  *
  * Creator: pavula1
  */
object AccUtil {

  def OAQCLOUD: String = "OAQCloud_"

  def accFile: String = "accProcessingComplete"

  def readControlConfig(): Map[String, String] = {

    val iStream = this.getClass.getClassLoader().getResourceAsStream("cdr_control_table_map.txt")
    scala.io.Source.fromInputStream(iStream).getLines.foldLeft(Map.empty[String, String]) {
      case (mapResult, configLine) =>
        val configParts = configLine.split("\\|")

        val accFile = configParts(0).trim.toLowerCase
        val tableName = configParts(1).trim
        mapResult + (accFile -> tableName)
    }
  }

  def ensureTrailingCharacter(path: String, ch: Char): String = {
    if (path.last.equals(ch)) {
      path
    } else {
      path.concat(ch.toString)
    }
  }

  def getModelPath(basePath: String, modelName: String): String = {
    ensureTrailingCharacter(basePath, '/') + modelName
   }

  def getFileName(s : String, processId: String) = {
    s.substring(s.indexOf("/", s.indexOf(processId) + processId.length) + 1)
  }

  def getModelName(s: String) = {
    s.split("=").last.toLowerCase()
  }

  def getTransactionId(processId: String) = {
    processId.split("/").last
  }

  def loadFile(filePath: String) = {
    val path = new Path(filePath)
    val fs = HDFSUtils.getHDFSFileSystem(filePath)
    if (fs.exists(path)) {
      Some(new InputStreamReader(fs.open(path)))
    } else None
  }

  def loadXMLTriggerFile(filePath: String, processId: String): (String,Seq[FileCount]) = {
    val iStream = loadFile(filePath)

    if (iStream.isEmpty) {
      throw ACCValidationException(s"Input stream not available for XML trigger file path $filePath")
    }

    val xmlContent = XML.load(iStream.get)

    (getStatusXML(xmlContent), getTableCountXML(xmlContent, processId))
  }

  def loadAccProcessingStatus(filePath: String) = {
    val iStream = new BufferedReader(loadFile(filePath).get)

    getAccProcessingStatus(iStream)
  }

  def getAccProcessingStatus(iStream: BufferedReader) = {
    Stream.continually(iStream.readLine()).takeWhile(_ != null).filter(_.contains("Job Status:")).map(x => {
      val split = x.split(":")
      split.last
    }).head.trim
  }

  def getStatusXML(xmlContent: Elem): String = {
    (xmlContent \\ "JobHistory" \\ "ReqStatus").text
  }


  def getTableCountXML(xmlContent: Elem, processId: String) : Seq[FileCount] = {
    val outputFiles =  xmlContent \ "OutputFiles" \\ "OutputFile"

    outputFiles.map(outputfile => {
      val fileName = getFileName((outputfile \ "FileName").text, processId)
      val count = (outputfile \ "FileRecordCount").text.toInt
      FileCount(fileName, count)
    })
  }

  def loadControlTotalsFile(filePath: String): Seq[FileCount] = {
    val path = new Path(filePath)
    val fs = HDFSUtils.getHDFSFileSystem(filePath)
    val iStream = if (fs.exists(path)) {
      Some(new BufferedReader(new InputStreamReader(fs.open(path))))
    } else None

    if (iStream.isEmpty) {
      throw ACCValidationException(s"Input stream not available for controls file path $filePath")
    }

    Stream.continually(iStream.get.readLine()).takeWhile(_ != null).filter(_.contains('|')).filterNot(_.contains(".tar")).map(x => {
      val split = x.split("\\|")
      FileCount(split(0), split(1).toLong)
    })
  }

  def getAccInhouseBaseStreamPath(basePath: String, env: String, cdrCycle: String, instance: String): String = {
    val fs = HDFSUtils.getHDFSFileSystem(basePath)
    val path = s"${ensureTrailingCharacter(basePath, '/')}$env/cdr_be/$cdrCycle/$instance/acc_inhouse_returns"
    if (!HDFSUtils.ifPathExists(fs, path)) {
      throw ACCValidationException(s"Base stream path $path missing for client")
    }
    path
  }

  def getPathWithProcessId(basePath: String, env: String, cdrCycle: String, instance: String, processId: String): String = {
    val fs = HDFSUtils.getHDFSFileSystem(basePath)
    val path = s"${ensureTrailingCharacter(baseQMEPath(basePath, env, cdrCycle, instance),'/')}$processId"
    if (!HDFSUtils.ifPathExists(fs, path)) {
      throw ACCValidationException(s"Path with ProcessId $path missing for client")
    }
    path
  }

  def baseAccPath(basePath:String, env: String) :String= {
    s"${ensureTrailingCharacter(basePath, '/')}$env/external/acc/"
  }

  def baseQMEPath(basePath: String, env: String, cdrCycle: String, instance: String) :String= {
    val fs = HDFSUtils.getHDFSFileSystem(basePath)
    val path = s"${ensureTrailingCharacter(basePath, '/')}$env/cdr_be/$cdrCycle/$instance/qme_returns"
    if (!HDFSUtils.ifPathExists(fs, path)) {
      throw ACCValidationException(s"Base stream path $path missing for client")
    }
    path
  }

  def getDestinationPath(path: String, modelName: String): String = {
      path.split("/").dropRight(1).mkString("", "/", "/").concat("data/").concat(modelName)
  }

  def getDestinationPath(basePath: String, env: String, cdrCycle: String, instance: String): String = {
    s"$basePath/$env/cdr_be/$cdrCycle/$instance/default/"
  }

  def getDestinationPath(basePath: String, env: String, cdrCycle: String, instance: String, modelName: String): String = {
      s"$basePath/$env/cdr_be/$cdrCycle/$instance/default/$modelName"
  }

  def getFilePathWithLatestDateDir(path: String, fs: FileSystem): String = {
    val allDateDirsUnderProcessId = HDFSUtils.getAllSubDirs(fs, path)
    val latestDateDir = getLatestDateDir(allDateDirsUnderProcessId)

    if (latestDateDir.isEmpty) {
      throw ACCParquetConversionException(s"There are no date directories under $path")
    }

    s"$path/${latestDateDir.get._1}"
  }

  def getDateStamp(fileName : String) : String = {
    Try(fileName.split("/").filter(x => x.contains("enddate")).head.split("=").last).getOrElse("")
  }

  def getLatestDateDir(allDateDirsUnderProcessId: Map[String, String]): Option[(String, String)] = {
    if (allDateDirsUnderProcessId.isEmpty) {
      None
    } else {
      val sdf = new SimpleDateFormat("yyyyMMdd")
      val latestDate = allDateDirsUnderProcessId.map(dateDir => (dateDir._1, sdf.parse(dateDir._1))).toSeq.maxBy(f => f._2)
      Some(latestDate._1, allDateDirsUnderProcessId(latestDate._1))
    }
  }

  def parseToTimestamp(inputValue: String, pattern: String = "yyyyMMdd"): Option[java.sql.Timestamp] = {
    val simpleDateFormat = new SimpleDateFormat("yyyyMMdd")
    try {
      val value = simpleDateFormat.parse(inputValue)
      val timestamp = new Timestamp(value.getTime)
      Some(timestamp)
    } catch {
      case _: Exception => None
    }
  }

}

final case class ACCParquetConversionException(private val message: String = "") extends Exception(message)
