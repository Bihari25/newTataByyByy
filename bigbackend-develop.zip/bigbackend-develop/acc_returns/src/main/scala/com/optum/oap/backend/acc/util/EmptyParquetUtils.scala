package com.optum.oap.backend.acc.util

import com.optum.oap.backend.util.ColumnDataTypeMapping
import com.optum.oap.backend.util.ConverterUtils._
import com.optum.oap.sparklib.HDFSUtils
import org.apache.spark.sql.{Row, SaveMode, SparkSession}
import org.slf4j.LoggerFactory

import scala.collection.mutable.ListBuffer
import com.optum.oap.backend.acc.util.AccUtil._
/**
  *
  * Copyright 2019 Optum Analytics
  *
  * Date: 8/22/19
  *
  * Creator: pavula1
  */
case class EmptyParquetUtils(sparkSession: SparkSession, clientId: String, env: String, cdrLevel:  Option[String], cdrCycle:  Option[String], instance:  Option[String], baseDestPath: String, mapModelConfig: Map[String, ListBuffer[ColumnDataTypeMapping]],
                             mapControlConfig: Map[String,String]) {

  import EmptyParquetUtils._

  def handleEmptyParquet: Unit = {

      val fs = HDFSUtils.getHDFSFileSystem(baseDestPath)
      mapControlConfig.foreach(cFile => {

        val modalName = mapControlConfig(cFile._1)
        val modelSchema = getModelSchema(mapModelConfig(modalName.toLowerCase()))

        val nullRow = getSingleNullRow(modelSchema.length)
        val nullRdd = sparkSession.sparkContext.parallelize(Seq(nullRow))
        val df = sparkSession.createDataFrame(nullRdd, modelSchema).limit(0)

        val destPath = s"${getEmptyParquetFilesPath(baseDestPath, env, cdrLevel.get, cdrCycle.get, instance.get)}/${modalName.toUpperCase}"

        logger.warn(s"Writing empty df for model ${cFile._2} at $destPath")
        df.coalesce(1).write.mode(SaveMode.Append).parquet(destPath)
      })

  }

  private def getSingleNullRow(colCount: Int): Row = {
    val nullSeq = (1 to colCount).map(i => null)
    Row.fromSeq(nullSeq)
  }

  def getEmptyParquetFilesPath(basePath: String, env: String, cdrLevel: String, cdrCycle: String, instance: String): String =
    s"${ensureTrailingCharacter(basePath, '/')}$env/${cdrLevel.toLowerCase()}/${cdrCycle.toLowerCase()}/$instance/default"

}

object EmptyParquetUtils {
  private val logger = LoggerFactory.getLogger(this.getClass)
}
