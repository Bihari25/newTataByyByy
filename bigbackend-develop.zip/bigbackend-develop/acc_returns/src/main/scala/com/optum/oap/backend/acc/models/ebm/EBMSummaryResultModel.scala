package com.optum.oap.backend.acc.models.ebm

import java.io.StringReader

import com.optum.oap.backend.acc.AbstractAcc
import com.optum.oap.backend.acc.lib.FieldReader
import com.optum.oap.backend.acc.util.AccUtil.parseToTimestamp
import com.optum.oap.cdr.models.ebm_summaryresult
import com.optum.oap.utils.Resource.using

/**
  *
  * Copyright 2019 Optum Analytics
  *
  * Date: 9/3/19
  *
  * Creator: pavula1
  */

/* (
GRP_MPI                 POSITION(1:32),
REPORT_CASE_ID          POSITION(33:38),
EVENT                   POSITION(39:42),
REPORT_RULE_ID          POSITION(43:51),
TASK_NUMBER             POSITION(52:54),
RULE_TYPE_NUM           POSITION(55:58),
RESULT_FLAG             POSITION(59:61),
EBM_FLAG                POSITION(62:62),
COMP_FLAG               POSITION(63:63),
FILE_PROCESSING_MONTH   "TO_DATE ('${dataname%%_*}', 'YYYYMMDD')",
GROUPID                 CONSTANT "${groupid}",
PROCESS                 CONSTANT "M"
)
 */
object EBMSummaryResultModel extends AbstractAcc[ebm_summaryresult] {

  override def processRowHelper(data: String, groupId: String, fileProcessingMonth: String): ebm_summaryresult = {
    using(new StringReader(data))(implicit reader => {
      val rd = FieldReader()
      import rd._

      val groupMpi = nullOnEmpty(readString(32)) // GRP_MPI
      val reportCaseId = nullOnEmpty(readString(6, throwOnNoData = false)) // REPORT_CASE_ID
      val event = nullOnEmpty(readString(4, throwOnNoData = false)) // EVENT
      val reportRuleId = nullOnEmpty(readString(9, throwOnNoData = false)) // REPORT_RULE_ID
      val taskNumber = nullOnEmpty(readString(3, throwOnNoData = false)) // TASK_NUMBER
      val ruleTypeNum = nullOnEmpty(readString(4, throwOnNoData = false)) // RULE_TYPE_NUM
      val resultFlag = nullOnEmpty(readString(3, throwOnNoData = false)) // RESULT_FLAG
      val ebmFlag = nullOnEmpty(readString(1, throwOnNoData = false)) // EBM_FLAG
      val compFlag = nullOnEmpty(readString(1, throwOnNoData = false)) // COMP_FLAG

      ebm_summaryresult(
        comp_flag = compFlag,
        ebm_flag = ebmFlag,
        event = if (event == null) null else event.toInt,
        file_processing_month = parseToTimestamp(fileProcessingMonth).orNull,
        groupid = groupId,
        grp_mpi = groupMpi,
        process = "M",
        report_case_id = if (reportCaseId == null) null else reportCaseId.toInt,
        report_rule_id = if (reportRuleId == null) null else reportRuleId.toInt,
        result_flag = resultFlag,
        rule_type_num = if (ruleTypeNum == null) null else ruleTypeNum.toInt,
        task_number = if (taskNumber == null) null else taskNumber.toInt

      )

    })
  }
}
