package com.optum.oap.backend.acc.lib

import java.io.{IOException, Reader}

import scala.annotation.tailrec

case class FieldReader() {
  private var buffer: Array[Char] = new Array[Char](32)

  def readString(fieldSize: Int, trim: Boolean = true, throwOnNoData: Boolean = true)(implicit r: Reader): String = {
    if(readFieldChars(fieldSize, throwOnNoData = throwOnNoData)) {
      if (trim) {
        trimStringBuffer(fieldSize)
      } else {
        new String(buffer, 0, fieldSize)
      }
    } else {
      null
    }
  }

  def readLong(fieldSize: Int, outValue: LongRefCell, throwOnNoData: Boolean = true)(implicit r: Reader): Boolean = {
    if(readFieldChars(fieldSize, throwOnNoData = throwOnNoData)) {
      LongParser.parse(fieldSize, buffer, outValue)
      true
    } else {
      false
    }
  }

  def readNewline(throwOnNoData: Boolean = true)(implicit r: Reader): Boolean = {
    if(readFieldChars(2, throwOnNoData = throwOnNoData)) {
      if(buffer(0) != '\r' || buffer(1) != '\n') {
        throw new IOException("Expected a newline.")
      }
      true
    } else {
      false
    }
  }

  def skip(fieldSize: Int, throwOnNoData: Boolean = true)(implicit r: Reader): Boolean = {
    val charsSkipped = r.skip(fieldSize)
    if(charsSkipped == 0) {
      if(throwOnNoData) {
        throw new IOException("Attempted to skip field of size $fieldSize but only skipped 0 characters")
      } else {
        false
      }
    } else if(charsSkipped != fieldSize) {
      throw new IOException(s"Attempted to skip field of size $fieldSize but only skipped $charsSkipped characters.")
    } else {
      true
    }
  }

  def nullOnEmpty(str: String): String =
    if(str == null || str.length == 0)
      null
    else
      str

  private def trimStringBuffer(fieldSize: Int): String = {
    trimLeftFirst(0, fieldSize -1)
  }

  @tailrec
  private def trimLeftFirst(x: Int, y: Int): String = {
    if(x > y) {
      ""
    } else if(buffer(x) == ' ') {
      trimLeftFirst(x + 1, y)
    } else {
      trimRightSecond(x, y)
    }
  }

  @tailrec
  private def trimRightSecond(x: Int, y: Int): String = {
    if(x > y) {
      ""
    } else if(buffer(y) == ' ') {
      trimRightSecond(x, y - 1)
    } else {
      new String(buffer, x, y - x + 1)
    }
  }

  private def readFieldChars(fieldSize: Int, throwOnNoData: Boolean = true)(implicit r: Reader): Boolean = {
    ensureBuffer(fieldSize)
    if(readFieldChars(0, fieldSize)) {
      true
    } else if(throwOnNoData) {
      throw new IOException(s"Expected a field with $fieldSize characters but read zero characters.")
    } else {
      false
    }
  }

  @tailrec
  private def readFieldChars(pos: Int, charsRemaining: Int)(implicit r: Reader): Boolean = {
    val charsRead = r.read(buffer, pos, charsRemaining)
    if(charsRead == -1) {
      if(pos > 0) {
        throw new IOException(s"Read an incomplete field. Expected ${charsRemaining + pos} characters but only read $pos.")
      } else {
        false
      }
    } else if(charsRead == charsRemaining){
      true
    } else {
      readFieldChars(pos + charsRead, charsRemaining - charsRead)
    }
  }

  private def ensureBuffer(size: Int): Unit = {
    if(buffer.length < size) {
      buffer = new Array[Char](size)
    }
  }
}