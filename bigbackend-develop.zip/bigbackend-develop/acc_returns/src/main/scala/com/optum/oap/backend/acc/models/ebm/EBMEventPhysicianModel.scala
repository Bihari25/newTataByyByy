package com.optum.oap.backend.acc.models.ebm

import java.io.StringReader

import com.optum.oap.backend.acc.AbstractAcc
import com.optum.oap.backend.acc.lib.FieldReader
import com.optum.oap.backend.acc.util.AccUtil.parseToTimestamp
import com.optum.oap.cdr.models.ebm_event_physician
import com.optum.oap.utils.Resource.using

/**
  *
  * Copyright 2019 Optum Analytics
  *
  * Date: 9/3/19
  *
  * Creator: pavula1
  */
/* (
GRP_MPI                 POSITION(1:32),
REPORT_CASE_ID          POSITION(33:38),
EVENT                   POSITION(39:42),
PROVIDER_ID             POSITION(43:62),
PROV_SPEC               POSITION(63:64),
SUPPORT_FLAG            POSITION(65:65),
INITIAL_STATUS          POSITION(66:66),
LAST_VISIT_DATE         POSITION(67:74) DATE "YYYYMMDD" nullif LAST_VISIT_DATE = '00000000',
NUM_OF_VISITS           POSITION(75:78),
AMOUNT_PAID             POSITION(79:89),
AMOUNT_CHARGED          POSITION(90:100),
FIRST_VISIT_DATE        POSITION(101:108) DATE "YYYYMMDD" nullif FIRST_VISIT_DATE = '00000000',
FILE_PROCESSING_MONTH   "TO_DATE ('${dataname%%_*}', 'YYYYMMDD')",
GROUPID                 CONSTANT "${groupid}"
)
  */
// 965797725                       110000   034750175            GS N20190313   2      16.65     234.0320181001
object EBMEventPhysicianModel extends AbstractAcc[ebm_event_physician] {
  override def processRowHelper(data: String, groupId: String, fileProcessingMonth: String): ebm_event_physician = {
    using(new StringReader(data))(implicit reader => {
      val rd = FieldReader()
      import rd._

      val groupMpi = nullOnEmpty(readString(32)) // GRP_MPI
      val reportCaseId = nullOnEmpty(readString(6, throwOnNoData = false)) // REPORT_CASE_ID
      val event = nullOnEmpty(readString(4, throwOnNoData = false)) // EVENT
      val providerId = nullOnEmpty(readString(20, throwOnNoData = false)) // PROVIDER_ID
      val provSpec = nullOnEmpty(readString(2, throwOnNoData = false)) // PROV_SPEC
      val supportFlag = nullOnEmpty(readString(1, throwOnNoData = false)) // SUPPORT_FLAG
      val initialStatus = nullOnEmpty(readString(1, throwOnNoData = false)) // INITIAL_STATUS
      val lastVisitDate = nullOnEmpty(readString(8, throwOnNoData = false)) // LAST_VISIT_DATE
      val numOfVisits = nullOnEmpty(readString(4, throwOnNoData = false)) // NUM_OF_VISITS
      val amountPaid = nullOnEmpty(readString(11, throwOnNoData = false)) // AMOUNT_PAID
      val amountCharged = nullOnEmpty(readString(11, throwOnNoData = false)) // AMOUNT_CHARGED
      val firstVisitDate = nullOnEmpty(readString(8, throwOnNoData = false)) // FIRST_VISIT_DATE


      ebm_event_physician(
        amount_charged = if(amountCharged == null) null else amountCharged.toDouble,
        amount_paid = if(amountPaid == null) null else amountPaid.toDouble,
        event = if(event == null) null else event.toInt,
        file_processing_month = parseToTimestamp(fileProcessingMonth).orNull,
        first_visit_date = if(firstVisitDate == "00000000") null else parseToTimestamp(firstVisitDate).orNull,
        groupid = groupId,
        grp_mpi = groupMpi,
        initial_status = initialStatus,
        last_visit_date = if(lastVisitDate == "00000000") null else parseToTimestamp(lastVisitDate).orNull,
        num_of_visits = if(numOfVisits == null) null else numOfVisits.toInt,
        prov_spec = provSpec,
        provider_id = providerId,
        report_case_id = if(reportCaseId == null) null else reportCaseId.toInt,
        support_flag = supportFlag

      )
    })
  }
}