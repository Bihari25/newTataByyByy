SET ECHO OFF
SET FEEDBACK OFF
SET HEADING OFF
SET PAGESIZE 1000
SET LINESIZE 200
SET VERIFY OFF
define rel_cycle=&1
define src_schm=cdr_&rel_cycle
define environment=&2
SELECT  'GROUPID,DATA_STREAM_ID,STREAM_NAME,FIELD_DELIM,DESTINATION_NAME,OUTPUT_TAG,OUTPUT_TAG_EXT' as "c1" from dual
UNION
SELECT
     (groupid
     || ','
     || data_stream_id
     || ','
     || stream_name
     || ','
     || field_delim
     || ','
     || destination_name
     || ','
     || output_tag
     || ','
     || output_tag_ext) as "c1"
FROM
     (
         SELECT
             v.*,
             CASE
                 WHEN stream_name = 'hedis_monthly'         THEN 'bpo_pyr_hedis'
                 WHEN substr(stream_name,9) = 'ebm_monthly' THEN 'bpo_pyr_ebm'
                 WHEN stream_name = 'hedis_qme_monthly'         THEN 'bpo_pyr_hedis_qme'
                 ELSE substr(destination_name,5)
             END AS output_tag,
             CASE
                 WHEN stream_name = 'hedis_monthly'         THEN substr(replace(destination_name,'/','_'),-9)
                 WHEN substr(stream_name,9) = 'ebm_monthly' THEN 'ebm'
                 WHEN stream_name = 'hedis_qme_monthly'         THEN 'qme'
                 ELSE substr(destination_name,13)
             END AS output_tag_ext
         FROM
             (
                SELECT
                     groupid,
                     dict.data_stream_id,
                     dict.stream_name,
                     dict.field_delim,
                     CASE
                         WHEN dict.stream_name = bcc.client_id || '_ii_monthly' THEN substr(dict.destination_name,1,12)
                                                                                     || lower(bcc.extract_sql_dir)
                         ELSE dict.destination_name
                     END AS destination_name
                 FROM
                     metadata.outbound_file_dictv2 dict
                     INNER JOIN TABLE ( &src_schm..get_bpo_client_components_out() ) bcc
                                   ON (bcc.client_id = dict.groupid
                                       AND ((dict.stream_name LIKE '%' || lower(bcc.parent_type) || '_monthly%')
                                          or (dict.stream_name LIKE '%' || lower(bcc.parent_type) || '_qme_monthly%'))
                                       )
                 WHERE
                     (bcc.active_ind = 1 OR '&environment' = 'DEV')
                     AND substr(groupid,1,1) = 'H'
             ) v
         ORDER BY
             groupid,
             data_stream_id
     );
quit;
/