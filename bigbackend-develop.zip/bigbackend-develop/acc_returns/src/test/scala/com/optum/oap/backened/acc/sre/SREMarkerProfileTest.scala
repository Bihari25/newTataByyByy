package com.optum.oap.backened.acc.sre

import java.nio.file.Paths

import com.optum.oap.backend.acc.models.sre.SREMarkerProfileModel
import com.optum.oap.cdr.models.sre_marker_profile
import com.optum.oap.testutils.TestSparkSession
import org.junit.runner.RunWith
import org.scalatest.FlatSpec
import org.scalatest.Matchers._
import org.scalatest.junit.JUnitRunner

/**
  *
  * Copyright 2019 Optum Analytics
  *
  * Date: 9/4/19
  *
  * Creator: bpokharel(bishu)
  */
@RunWith(classOf[JUnitRunner])
class SREMarkerProfileTest extends FlatSpec with TestSparkSession {
  val spark = sparkSession

  import spark.implicits._

  it should "test end to end run of sre_marker_profile" in {
    val fileName = "37962_H303173_sre_markerProfile.gz"
    val inputFile = getClass.getClassLoader.getResource(fileName)
    val path = Paths.get(inputFile.toURI).toFile
    val df = spark.read.text(path.getAbsolutePath)
    val output = df.map(r => SREMarkerProfileModel.processRow(r.mkString, "H000166", null))(SREMarkerProfileModel.rowEncoder).as[sre_marker_profile]
    val firstRec = output.first()
    firstRec.family_id shouldBe "687486414"
    firstRec.patient_id shouldBe null
    firstRec.marker_id shouldBe "18010000123"
    firstRec.marker_type shouldBe "BASE"
    firstRec.marker_value shouldBe 987654.32154321
    firstRec.groupid shouldBe "H000166"
  }

}
