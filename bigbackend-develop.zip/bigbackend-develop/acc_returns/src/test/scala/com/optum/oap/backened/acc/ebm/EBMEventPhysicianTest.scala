package com.optum.oap.backened.acc.ebm

import java.nio.file.Paths
import java.sql.Timestamp

import com.optum.oap.backend.acc.ACCFactory
import com.optum.oap.backend.acc.models.ebm.EBMEventPhysicianModel
import com.optum.oap.cdr.models.ebm_event_physician
import com.optum.oap.testutils.TestSparkSession
import org.junit.runner.RunWith
import org.scalatest.FlatSpec
import org.scalatest.Matchers._
import org.scalatest.junit.JUnitRunner

@RunWith(classOf[JUnitRunner])
class EBMEventPhysicianTest extends FlatSpec with TestSparkSession {

  val spark = sparkSession

  import spark.implicits._

  it should "test end to end run of ebm_facility_event" in {
    val fileName = "20190430_38798_H000166_ebm_eventPhysician.gz"
    val inputFile = getClass.getClassLoader.getResource(fileName)
    val path = Paths.get(inputFile.toURI).toFile
    val df = spark.read.text(path.getAbsolutePath)

    val output = df
      .map(r => EBMEventPhysicianModel.processRow(r.mkString, "H000166",  fileName.split("_").head))(ACCFactory("eventphysician").rowEncoder).as[ebm_event_physician]
    val firstRec = output.first()
    firstRec.grp_mpi shouldBe "965797725"
    firstRec.amount_charged shouldBe 234.03
    firstRec.amount_paid shouldBe 16.65
    firstRec.event shouldBe 0
    firstRec.file_processing_month shouldBe Timestamp.valueOf("2019-04-30 00:00:00")
    firstRec.first_visit_date shouldBe Timestamp.valueOf("2018-10-01 00:00:00")
    firstRec.initial_status shouldBe "N"
    firstRec.last_visit_date shouldBe Timestamp.valueOf("2019-03-13 00:00:00")
    firstRec.event shouldBe 0
    firstRec.num_of_visits shouldBe 2
    firstRec.prov_spec shouldBe "GS"
    firstRec.provider_id shouldBe "34750175"
    firstRec.groupid shouldBe "H000166"
    firstRec.support_flag shouldBe null
    firstRec.report_case_id shouldBe 110000

  }


}
