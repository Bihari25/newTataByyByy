package com.optum.oap.backened.acc.ebm

import java.nio.file.Paths
import java.sql.Timestamp
import java.text.SimpleDateFormat

import com.optum.oap.backend.acc.models.ebm.EBMFacilityEventModel
import com.optum.oap.cdr.models.ebm_facility_event
import com.optum.oap.testutils.TestSparkSession
import org.junit.runner.RunWith
import org.scalatest.FlatSpec
import org.scalatest.Matchers._
import org.scalatest.junit.JUnitRunner

@RunWith(classOf[JUnitRunner])
class EBMFacilityEventTest extends FlatSpec with TestSparkSession {

  val spark = sparkSession

  import spark.implicits._

  it should "parse date" in {
    val simpleDateFormat = new SimpleDateFormat("yyyyMMdd")
    val value = simpleDateFormat.parse("20191231")
    val timestamp = new Timestamp(value.getTime)
    println(timestamp)
  }

  it should "test end to end run of ebm_facility_event" in {
    val fileName = "20190430_38798_H000166_ebm_facility_event.gz"
    val inputFile = getClass.getClassLoader.getResource(fileName)
    val path = Paths.get(inputFile.toURI).toFile
    val dataframe = spark.read.text(path.getAbsolutePath)
    val output = dataframe.map(r => EBMFacilityEventModel.processRow(r.mkString, "H000166", fileName.split("_").head))(EBMFacilityEventModel.rowEncoder).as[ebm_facility_event]
    val firstRec = output.first()
    firstRec.grp_mpi shouldBe "696922470"
    firstRec.care_category shouldBe "S95"
    firstRec.uniq_rec_id shouldBe "MED6627.69508131"
    firstRec.facility_event_num shouldBe 3666
    firstRec.file_processing_month shouldBe Timestamp.valueOf("2019-04-30 00:00:00")


  }

}
