package com.optum.oap.backened.acc

import java.io.File

import com.optum.oap.backend.acc.{ACCValidationException, FileCount, Validation}
import com.optum.oap.testutils.TestSparkSession
import org.junit.runner.RunWith
import org.scalatest.FlatSpec
import org.scalatest.Matchers._
import org.scalatest.junit.JUnitRunner

@RunWith(classOf[JUnitRunner])
class ValidationTest extends FlatSpec with TestSparkSession {

  val spark = sparkSession

  it should "test fileLevelValidation when count match" in {

    val resourcesDirectory = new File("src/test/resources")

    val accFiles = Set("20190430_38798_H000166_ebm_drugAdherence.gz", "20190430_38798_H000166_ebm_event.gz")
    val mapControlFiles = Seq(FileCount("20190430_38798_H000166_ebm_drugAdherence.gz", 2), FileCount("20190430_38798_H000166_ebm_event.gz", 2))
    Validation.fileLevelValidation(spark, accFiles, mapControlFiles, resourcesDirectory.getAbsolutePath)

  }


  it should "test fileLevelValidation when count not match" in {

    val resourcesDirectory = new File("src/test/resources")

    val accFiles = Set("20190430_38798_H000166_ebm_drugAdherence.gz", "20190430_38798_H000166_ebm_event.gz")
    val mapControlFiles = Seq(FileCount("20190430_38798_H000166_ebm_drugAdherence.gz", 3), FileCount("20190430_38798_H000166_ebm_event.gz", 2))
    val thrown = intercept[Exception] {
      Validation.fileLevelValidation(spark, accFiles, mapControlFiles, resourcesDirectory.getAbsolutePath)
    }
    thrown.getMessage.contains("Count mismatch errors") shouldBe true
  }

  it should "test fileLevelValidation when missing files" in {

    val resourcesDirectory = new File("src/test/resources")

    val accFiles = Set("20190430_38798_H000166_ebm_drugAdherence.gz")
    val mapControlFiles = Seq(FileCount("20190430_38798_H000166_ebm_drugAdherence.gz", 3), FileCount("20190430_38798_H000166_ebm_event.gz", 2))
    val thrown = intercept[ACCValidationException] {
      Validation.fileLevelValidation(spark, accFiles, mapControlFiles, resourcesDirectory.getAbsolutePath)
    }

    thrown.getMessage shouldBe "Missing files: 20190430_38798_h000166_ebm_event.gz"
  }

  it should "test fileLevelValidation when extra files" in {

    val resourcesDirectory = new File("src/test/resources")

    val accFiles = Set("20190430_38798_H000166_ebm_drugAdherence.gz", "20190430_38798_H000166_ebm_event.gz", "20190430_38798_H000166_ebm_eventPhysician")
    val mapControlFiles = Seq(FileCount("20190430_38798_H000166_ebm_drugAdherence.gz", 3), FileCount("20190430_38798_H000166_ebm_event.gz", 2))
    val thrown = intercept[ACCValidationException] {
      Validation.fileLevelValidation(spark, accFiles, mapControlFiles, resourcesDirectory.getAbsolutePath)
    }

    thrown.getMessage shouldBe "Extra files: 20190430_38798_h000166_ebm_eventphysician"
  }

}
