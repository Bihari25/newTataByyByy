package com.optum.oap.backened.acc.ebm

import java.nio.file.Paths
import java.sql.Timestamp

import com.optum.oap.backend.acc.models.ebm.EBMDrugAdherenceModel
import com.optum.oap.cdr.models.ebm_drugadherence
import com.optum.oap.testutils.TestSparkSession
import org.junit.runner.RunWith
import org.scalatest.FlatSpec
import org.scalatest.Matchers._
import org.scalatest.junit.JUnitRunner

@RunWith(classOf[JUnitRunner])
class EBMDrugAdherenceTest extends FlatSpec with TestSparkSession {

  val spark = sparkSession

  import spark.implicits._

  it should "test end to end run of ebm_facility_event" in {
    val fileName = "20190430_38798_H000166_ebm_drugAdherence.gz"
    val inputFile = getClass.getClassLoader.getResource(fileName)
    val path = Paths.get(inputFile.toURI).toFile
    val df = spark.read.text(path.getAbsolutePath)
    val output =  df.map(r => EBMDrugAdherenceModel.processRow(r.mkString, "H000166",  fileName.split("_").head))(EBMDrugAdherenceModel.rowEncoder).as[ebm_drugadherence]
    val firstRec = output.first()
    firstRec.grp_mpi shouldBe "696438102"
    firstRec.calc_type shouldBe "F"
    firstRec.class_type shouldBe "DCC"
    firstRec.days_sup shouldBe 504
    firstRec.file_processing_month shouldBe Timestamp.valueOf("2019-04-30 00:00:00")
    firstRec.drug_class shouldBe "48302"
    firstRec.elapsed_days shouldBe 445
    firstRec.event shouldBe 0
    firstRec.fill_beg shouldBe Timestamp.valueOf("2018-04-30 00:00:00")
    firstRec.fill_end shouldBe Timestamp.valueOf("2019-07-29 00:00:00")
  }


}
