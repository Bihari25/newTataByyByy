package com.optum.oap.backened.acc.qme

import java.nio.file.Paths
import java.sql.Timestamp

import com.optum.oap.backend.acc.models.qme.QmeHedisConversionModel
import com.optum.oap.backend.util.ConverterUtils.{getModelSchema, readAllConfig}
import com.optum.oap.cdr.models.{hedis_audit_output, hedis_measure_result}
import com.optum.oap.testutils.TestSparkSession
import org.junit.runner.RunWith
import org.scalatest.FlatSpec
import org.scalatest.Matchers._
import org.scalatest.junit.JUnitRunner

@RunWith(classOf[JUnitRunner])
class QmeHedisTest extends FlatSpec with TestSparkSession {

  val spark = sparkSession

  import spark.implicits._

  it should "test Hedis Audit Output" in {
    val fileName = "QME_OA_H000166_42648_auditOutput_yr0.txt.gz"
    val inputFile = getClass.getClassLoader.getResource(fileName)
    val path = Paths.get(inputFile.toURI).toFile

    val configStream = this.getClass.getClassLoader().getResourceAsStream("cdr_data_type_mapping.txt")
    val mapModelConfig = readAllConfig(configStream)
    val schema = getModelSchema(mapModelConfig("hedis_audit_output"))

    val df = QmeHedisConversionModel.processHedisAuditOutput(spark, path.getAbsolutePath, "H000166", schema, "yr0").as[hedis_audit_output]

    val firstRec = df.first()
    firstRec.contributing_object_name shouldBe "CAP01"
    firstRec.episode_identifier shouldBe "0"
    firstRec.groupid shouldBe "H000166"
    firstRec.grp_mpi shouldBe "227431008"
    firstRec.measure_audit_key shouldBe "CAP-Denominator:CAP01"
    firstRec.metric_code shouldBe "CAP01"
    firstRec.metric_value shouldBe "2019-12-31"
    firstRec.version shouldBe "2020"
    firstRec.hum_vers_yr shouldBe "V2020_YR0"
    firstRec.measurement_end_date shouldBe Timestamp.valueOf("2019-12-31 00:00:00")
  }

  it should "test Hedis Measure Result" in {
    val configStream = this.getClass.getClassLoader().getResourceAsStream("cdr_data_type_mapping.txt")
    val mapModalConfig = readAllConfig(configStream)
    val schema = getModelSchema(mapModalConfig("hedis_measure_result"))

    val fileName = "QME_OA_H000166_42648_measureResult_yr0.txt.gz"
    val inputFile = getClass.getClassLoader.getResource(fileName)
    val path = Paths.get(inputFile.toURI).toFile
    val measureDf = QmeHedisConversionModel.processHedisMeasureResult(spark, path.getAbsolutePath, "H000166", schema, "yr0").as[hedis_measure_result]
    val firstRec = measureDf.first()

    firstRec.measure_id shouldBe "CAP"
    firstRec.actual_visit_count shouldBe 0
    firstRec.adjusted_probability shouldBe 0.0
    firstRec.age shouldBe 6.0
    firstRec.age_and_gender_weight shouldBe 0.0
    firstRec.base_risk_weight shouldBe 0.0
    firstRec.comorbidity_weight shouldBe 0.0
    firstRec.days_count shouldBe 0.0
    firstRec.dcc_category shouldBe "0"
    firstRec.gender shouldBe "F"
    firstRec.groupid shouldBe "H000166"
    firstRec.grp_mpi shouldBe "227431008"
    firstRec.hum_vers_yr shouldBe "V2020_YR0"
    firstRec.measure_name shouldBe "CAP"
    firstRec.measurement_end_date shouldBe Timestamp.valueOf("2019-12-31 00:00:00")
    firstRec.member_month_count shouldBe 0
    firstRec.version shouldBe "2020"

  }


}
