package com.optum.oap.backened.acc.ebm

import java.nio.file.Paths
import java.sql.Timestamp

import com.optum.oap.backend.acc.models.ebm.EBMMemberDetailModel
import com.optum.oap.cdr.models.ebm_memberdetail
import com.optum.oap.testutils.TestSparkSession
import org.junit.runner.RunWith
import org.scalatest.FlatSpec
import org.scalatest.Matchers._
import org.scalatest.junit.JUnitRunner

@RunWith(classOf[JUnitRunner])
class EBMMemberDetailTest extends FlatSpec with TestSparkSession {

  val spark = sparkSession

  import spark.implicits._

  it should "test end to end run of ebm_facility_event" in {
    val fileName = "20190430_38798_H000166_ebm_memberDetail.gz"
    val inputFile = getClass.getClassLoader.getResource(fileName)
    val path = Paths.get(inputFile.toURI).toFile
    val df = spark.read.text(path.getAbsolutePath)
    val output = df.map(r=> EBMMemberDetailModel.processRow(r.mkString, "H000166", fileName.split("_").head))(EBMMemberDetailModel.rowEncoder).as[ebm_memberdetail]
    val firstRec = output.first()
    firstRec.file_processing_month shouldBe Timestamp.valueOf("2019-04-30 00:00:00")
    firstRec.birth_date shouldBe Timestamp.valueOf("2012-08-06 00:00:00")
    firstRec.groupid shouldBe "H000166"
    firstRec.process shouldBe "M"
    firstRec.grp_mpi shouldBe "696936578"
    firstRec.age shouldBe 6
    firstRec.age_in_months shouldBe 80
    firstRec.gender shouldBe "F"
    firstRec.imp_prov_spec shouldBe "99"
    firstRec.med shouldBe 1430
    firstRec.pcp2 shouldBe "34764654"
    firstRec.pcp2_spec shouldBe "XX"
    firstRec.pcp3 shouldBe "61822275"
    firstRec.pcp2_spec shouldBe "XX"


  }


}
