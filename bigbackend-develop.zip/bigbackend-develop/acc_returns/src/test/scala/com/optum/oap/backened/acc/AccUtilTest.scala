package com.optum.oap.backened.acc

import java.io.{BufferedReader, InputStreamReader}

import com.optum.oap.backend.acc.FileCount
import com.optum.oap.backend.acc.util.AccUtil
import com.optum.oap.testutils.TestSparkSession
import org.junit.runner.RunWith
import org.scalatest.FlatSpec
import org.scalatest.Matchers._
import org.scalatest.junit.JUnitRunner

import scala.xml.XML

@RunWith(classOf[JUnitRunner])
class AccUtilTest extends FlatSpec with TestSparkSession {

  val spark = sparkSession

  it should "test AccUtil readControlConfig" in {

    val controlConfig = AccUtil.readControlConfig()

    controlConfig("drugadherence") shouldBe "EBM_DRUGADHERENCE"
    controlConfig("event") shouldBe "EBM_MEMBEREVENT"
    controlConfig("eventphysician") shouldBe "EBM_EVENT_PHYSICIAN"
    controlConfig("membercondition") shouldBe "EBM_MEMCONDFILE"
    controlConfig("memberdetail") shouldBe "EBM_MEMBERDETAIL"
    controlConfig("physicianvisit") shouldBe "EBM_PHYSICIAN_VISIT"
    controlConfig("summaryresult") shouldBe "EBM_SUMMARYRESULT"
    controlConfig("cmrisksummary") shouldBe "SRE_CMRISKSUMMARY"
    controlConfig("markerprofile") shouldBe "SRE_MARKER_PROFILE"
    controlConfig("uwrisksummary") shouldBe "SRE_UWRISKSUMMARY"
    controlConfig("hedis_yr0_auditoutput") shouldBe "HEDIS_AUDIT_OUTPUT"
    controlConfig("hedis_yr0_measureresult") shouldBe "HEDIS_MEASURE_RESULT"
  }

  it should "test AccUtil ensureTrailingCharacter" in {

    val path = AccUtil.ensureTrailingCharacter("/tmp/padma", '/')
    path shouldBe "/tmp/padma/"

    val path1 = AccUtil.ensureTrailingCharacter("/tmp/padma/", '/')
    path1 shouldBe "/tmp/padma/"

  }

  it should "test basePath" in {
    val path = AccUtil.baseAccPath("/tmp/padma", "stg")

    path shouldBe "/tmp/padma/stg/external/acc/"
  }

  it should "test getDestinationPath" in  {
    val destPath = AccUtil.getDestinationPath("/${ENV}/external/acc/${processid}/in_ebm/monthly/{DATE}/landed", "EBM_DRUGADHERENCE")

    destPath shouldBe "/${ENV}/external/acc/${processid}/in_ebm/monthly/{DATE}/data/EBM_DRUGADHERENCE"
  }

  it should "test getLatestDateDir" in  {

    val allDateDirsUnderProcessId = Map("20190909" -> "/tmp/padma/H303173/stg/external/acc/38798/in_ebm/monthly/20190909", "20190913" -> "/tmp/padma/H303173/stg/external/acc/38798/in_ebm/monthly/20190913")

    val latestDir = AccUtil.getLatestDateDir(allDateDirsUnderProcessId)

    latestDir.get._1 shouldBe "20190913"
  }

  it should "load XML trigger file" in {
    val iStream = new InputStreamReader(this.getClass.getClassLoader.getResourceAsStream("validation_sre.xml"))
    val xmlContent = XML.load(iStream)
    val tableCounts = AccUtil.getTableCountXML(xmlContent, "45446/c7d33ee3-1512-4131-9512-d10323c3117b")

    val expectedResult = List(FileCount("analytic=sre/output=uwRiskSummary",208113),
                             FileCount("analytic=sre/output=cmRiskSummary",208113),
                             FileCount("analytic=sre/output=markerProfile", 3946277))

    tableCounts shouldBe expectedResult
  }

  it should "test getDestinationPath with clientid, env, cycle, instance" in {
    val destPath = AccUtil.getDestinationPath("basePath", "env", "cdr_cycle", "instance", "model_name")

    destPath shouldBe "basePath/env/cdr_be/cdr_cycle/instance/default/model_name"

    val destPath2 = AccUtil.getDestinationPath("basePath", "env", "cdr_cycle", "instance")

    destPath2 shouldBe "basePath/env/cdr_be/cdr_cycle/instance/default/"
  }

  it should "test getTransactionId" in {
    val transactionId = AccUtil.getTransactionId("45446/c7d33ee3-1512-4131-9512-d10323c3117b")

    transactionId shouldBe "c7d33ee3-1512-4131-9512-d10323c3117b"
  }

  it should "test getStatusXML" in {
    val iStream = new InputStreamReader(this.getClass.getClassLoader.getResourceAsStream("validation_sre.xml"))
    val xmlContent = XML.load(iStream)
    val status = AccUtil.getStatusXML(xmlContent)

    status shouldBe "Successful"
  }

  it should "test getAccProcessingStatus" in {
    val iStream = new BufferedReader(new InputStreamReader(this.getClass.getClassLoader.getResourceAsStream("accProcessingComplete")))
    val status = AccUtil.getAccProcessingStatus(iStream)

    status shouldBe "Successful"

  }

  it should "test getFileName" in {
    val modelName = AccUtil.getFileName("/misc/phiops/cdrbe/returns/H302436/stg/cdr_202104/bpo_pyr_ebm/45445/7cf732c5-6429-4e99-bbac-0caba7541d27/enddate=20210131/analytic=ebm/output=drugAdherence", "bpo_pyr_ebm/45445/7cf732c5-6429-4e99-bbac-0caba7541d27")

    modelName shouldBe "enddate=20210131/analytic=ebm/output=drugAdherence"
  }

  it should "load EBM Xml trigger file" in {
    val iStream = new InputStreamReader(this.getClass.getClassLoader.getResourceAsStream("validation_ebm.xml"))
    val xmlContent = XML.load(iStream)

    val tableCounts = AccUtil.getTableCountXML(xmlContent, "45445/7cf732c5-6429-4e99-bbac-0caba7541d27")

    val expectedResult = List(FileCount("enddate=20210228/analytic=ebm/output=physicianVisit", 3079242),
      FileCount("enddate=20201231/analytic=ebm/output=memberDates", 350624553),
      FileCount("enddate=20210228/analytic=ebm/output=memberDates", 350954885),
      FileCount("enddate=20210228/analytic=ebm/output=facilityEvent", 16290430))

    tableCounts shouldBe expectedResult
  }

  it should "test getModelName" in {
    val name1 = AccUtil.getModelName("enddate=20210228/analytic=ebm/output=facilityEvent")

    name1 shouldBe "facilityevent"

    val name2 = AccUtil.getModelName("analytic=sre/output=markerProfile")

    name2 shouldBe "markerprofile"

  }
}