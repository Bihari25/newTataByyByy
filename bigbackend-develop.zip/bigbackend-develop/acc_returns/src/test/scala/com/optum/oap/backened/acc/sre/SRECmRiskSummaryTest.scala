package com.optum.oap.backened.acc.sre

import java.nio.file.Paths
import java.sql.Timestamp

import com.optum.oap.backend.acc.models.sre.SRECMRiskSummaryModel
import com.optum.oap.cdr.models.sre_cmrisksummary
import com.optum.oap.testutils.TestSparkSession
import org.junit.runner.RunWith
import org.scalatest.FlatSpec
import org.scalatest.Matchers._
import org.scalatest.junit.JUnitRunner

/**
  *
  * Copyright 2019 Optum Analytics
  *
  * Date: 9/4/19
  *
  * Creator: bpokharel(bishu)
  */

@RunWith(classOf[JUnitRunner])
class SRECmRiskSummaryTest extends FlatSpec with TestSparkSession {

  val spark = sparkSession

  import spark.implicits._

  it should "test end to end run of sre_cmrisksummary" in {
    val fileName = "37962_H303173_sre_cmRiskSummary.txt"
    val inputFile = getClass.getClassLoader.getResource(fileName)
    val path = Paths.get(inputFile.toURI).toFile
    val df = spark.read.text(path.getAbsolutePath)
    val output = df.map(r => SRECMRiskSummaryModel.processRow(r.mkString, "H000166", null))(SRECMRiskSummaryModel.rowEncoder).as[sre_cmrisksummary]
    val firstRec = output.first()

    firstRec.family_id shouldBe "1025706320"
    firstRec.patient_id shouldBe null
    firstRec.age shouldBe 56
    firstRec.gender shouldBe "M"
    firstRec.cm_risk shouldBe 0.90730379
    firstRec.cm_ip_prob shouldBe 0.03821575
    firstRec.cm_ip_rel_risk shouldBe 1.44627356
    firstRec.cm_3mo_ip_prob shouldBe 0.00805404
    firstRec.cm_3mo_ip_rel_risk shouldBe 1.06051884
    firstRec.cm_ed_prob shouldBe 0.05053015
    firstRec.cm_ed_rel_risk shouldBe 0.80637909
    firstRec.cm_lab_risk shouldBe  0.90804580
    firstRec.cm_enroll_length shouldBe 366
    firstRec.cm_partial_enroll shouldBe "3"
    firstRec.cm_rx_risk shouldBe 0.88850495
    firstRec.demo_risk shouldBe 1.62117386
    firstRec.input_data_type shouldBe "0"
    firstRec.grouping_end_date shouldBe Timestamp.valueOf("2021-01-31 00:00:00")
    firstRec.error_status shouldBe "0"
    firstRec.database_version shouldBe "6180"
    firstRec.groupid shouldBe "H000166"
  }

}
