package com.optum.oap.backened.acc.ebm

import java.nio.file.Paths
import java.sql.Timestamp

import com.optum.oap.backend.acc.models.ebm.EBMEventModel
import com.optum.oap.cdr.models.ebm_memberevent
import com.optum.oap.testutils.TestSparkSession
import org.junit.runner.RunWith
import org.scalatest.FlatSpec
import org.scalatest.Matchers._
import org.scalatest.junit.JUnitRunner

@RunWith(classOf[JUnitRunner])
class EBMEventTest extends FlatSpec with TestSparkSession {

  val spark = sparkSession

  import spark.implicits._

  it should "test end to end run of ebm_facility_event" in {
    val fileName = "20190430_38798_H000166_ebm_event.gz"
    val inputFile = getClass.getClassLoader.getResource(fileName)
    val path = Paths.get(inputFile.toURI).toFile
    val df = spark.read.text(path.getAbsolutePath)
    val output = df.map(r => EBMEventModel.processRow(r.mkString, "H000166",  fileName.split("_").head))(EBMEventModel.rowEncoder).as[ebm_memberevent]
    val firstRec = output.first()
    firstRec.grp_mpi shouldBe "818572563"
    firstRec.age shouldBe 34
    firstRec.age_months shouldBe 415
    firstRec.care_cat shouldBe null
    firstRec.episode_from_date shouldBe Timestamp.valueOf("2018-06-21 00:00:00")
    firstRec.episode_prov_spec shouldBe "HL"
    firstRec.episode_provider shouldBe "34773384"
    firstRec.episode_thru_date shouldBe Timestamp.valueOf("2018-06-21 00:00:00")
    firstRec.event shouldBe 5
    firstRec.event_from_date shouldBe Timestamp.valueOf("2018-06-21 00:00:00")
    firstRec.event_thru_date shouldBe Timestamp.valueOf("2018-06-21 00:00:00")
    firstRec.file_processing_month shouldBe Timestamp.valueOf("2019-04-30 00:00:00")
    firstRec.groupid shouldBe "H000166"
    firstRec.process shouldBe "M"
    firstRec.report_case_id shouldBe 206800
    firstRec.unique_recid shouldBe "MED6212.12283351"


  }


}
