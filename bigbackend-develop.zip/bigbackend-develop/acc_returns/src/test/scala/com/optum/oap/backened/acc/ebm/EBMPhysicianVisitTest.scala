package com.optum.oap.backened.acc.ebm

import java.nio.file.Paths
import java.sql.Timestamp

import com.optum.oap.backend.acc.models.ebm.EBMPhysicianVisitModel
import com.optum.oap.cdr.models.ebm_physician_visit
import com.optum.oap.testutils.TestSparkSession
import org.junit.runner.RunWith
import org.scalatest.FlatSpec
import org.scalatest.Matchers._
import org.scalatest.junit.JUnitRunner

@RunWith(classOf[JUnitRunner])
class EBMPhysicianVisitTest extends FlatSpec with TestSparkSession {

  val spark = sparkSession

  import spark.implicits._

  it should "test end to end run of ebm_facility_event" in {
    val fileName = "20190430_38798_H000166_ebm_physicianVisit.gz"
    val inputFile = getClass.getClassLoader.getResource(fileName)
    val path = Paths.get(inputFile.toURI).toFile
    val df = spark.read.text(path.getAbsolutePath)
    val output = df.map(r=> EBMPhysicianVisitModel.processRow(r.mkString, "H000166", fileName.split("_").head))(EBMPhysicianVisitModel.rowEncoder).as[ebm_physician_visit]
    val firstRec = output.first()
    firstRec.grp_mpi shouldBe "965760907"
    firstRec.amount_charged shouldBe 631.83
    firstRec.amount_paid shouldBe 218.5
    firstRec.event shouldBe 0
    firstRec.file_processing_month shouldBe Timestamp.valueOf("2019-04-30 00:00:00")
    firstRec.first_visit_date shouldBe Timestamp.valueOf("2018-05-04 00:00:00")
    firstRec.imputed_phy_flag shouldBe "N"
    firstRec.num_of_visits shouldBe 12
    firstRec.last_visit_date shouldBe Timestamp.valueOf("2019-04-24 00:00:00")
    firstRec.rule_end_date shouldBe Timestamp.valueOf("2019-04-30 00:00:00")
    firstRec.rule_start_date shouldBe Timestamp.valueOf("2018-05-01 00:00:00")
    firstRec.prov_spec shouldBe "PA"
    firstRec.event shouldBe 0
    firstRec.num_of_visits shouldBe 12
    firstRec.provider_id shouldBe "34790881"
    firstRec.groupid shouldBe "H000166"
    firstRec.report_case_id shouldBe 4
    firstRec.report_rule_id shouldBe 5160001
  }


}
