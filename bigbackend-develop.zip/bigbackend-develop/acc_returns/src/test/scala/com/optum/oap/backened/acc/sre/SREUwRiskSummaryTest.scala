package com.optum.oap.backened.acc.sre

import java.nio.file.Paths
import java.sql.Timestamp

import com.optum.oap.backend.acc.models.sre.SREUWRiskSummaryModel
import com.optum.oap.cdr.models.sre_uwrisksummary
import com.optum.oap.testutils.TestSparkSession
import org.junit.runner.RunWith
import org.scalatest.FlatSpec
import org.scalatest.Matchers._
import org.scalatest.junit.JUnitRunner

/**
  *
  * Copyright 2019 Optum Analytics
  *
  * Date: 9/4/19
  *
  * Creator: bpokharel(bishu)
  */

@RunWith(classOf[JUnitRunner])
class SREUwRiskSummaryTest extends FlatSpec with TestSparkSession {
  val spark = sparkSession
  import spark.implicits._

  it should "test end to end run of sre_uwrisksummary" in {
    val fileName = "37962_H303173_sre_uwRiskSummary.gz"
    val inputFile = getClass.getClassLoader.getResource(fileName)
    val path = Paths.get(inputFile.toURI).toFile
    val df = spark.read.text(path.getAbsolutePath)
    val output = df.map(r => SREUWRiskSummaryModel.processRow(r.mkString, "H000166", null))(SREUWRiskSummaryModel.rowEncoder).as[sre_uwrisksummary]
    val firstRec = output.first()

    firstRec.family_id shouldBe "982813522"
    firstRec.patient_id shouldBe null
    firstRec.age shouldBe 19
    firstRec.gender shouldBe "M"
    firstRec.uw_medrx_risk shouldBe 0.1531
    firstRec.uw_med_risk shouldBe 0.4403
    firstRec.input_data_type shouldBe "0"
    firstRec.uw_enroll_length shouldBe 365
    firstRec.uw_partial_enroll shouldBe "3"
    firstRec.grouping_end_date shouldBe Timestamp.valueOf("2019-05-31 00:00:00")
    firstRec.error_status shouldBe "0"
    firstRec.database_version shouldBe "6101"
  }
}
