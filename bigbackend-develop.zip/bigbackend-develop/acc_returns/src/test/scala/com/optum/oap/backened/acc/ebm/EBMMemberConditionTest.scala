package com.optum.oap.backened.acc.ebm

import java.nio.file.Paths
import java.sql.Timestamp

import com.optum.oap.backend.acc.models.ebm.EBMMemberConditionModel
import com.optum.oap.cdr.models.ebm_memcondfile
import com.optum.oap.testutils.TestSparkSession
import org.junit.runner.RunWith
import org.scalatest.FlatSpec
import org.scalatest.Matchers._
import org.scalatest.junit.JUnitRunner

@RunWith(classOf[JUnitRunner])
class EBMMemberConditionTest extends FlatSpec with TestSparkSession {

  val spark = sparkSession

  import spark.implicits._

  it should "test end to end run of ebm_facility_event" in {
    val fileName = "20190430_38798_H000166_ebm_memberCondition.gz"
    val inputFile = getClass.getClassLoader.getResource(fileName)
    val path = Paths.get(inputFile.toURI).toFile
    val df = spark.read.text(path.getAbsolutePath)
    val output = df.map(r=> EBMMemberConditionModel.processRow(r.mkString, "H000166", fileName.split("_").head))(EBMMemberConditionModel.rowEncoder).as[ebm_memcondfile]
    val firstRec = output.first()
    firstRec.file_processing_month shouldBe Timestamp.valueOf("2019-04-30 00:00:00")
    firstRec.groupid shouldBe "H000166"
    firstRec.cond_conf_qual shouldBe "C"
    firstRec.process shouldBe "M"
    firstRec.report_case_id shouldBe 108900
    firstRec.grp_mpi shouldBe "965884657"


  }


}
