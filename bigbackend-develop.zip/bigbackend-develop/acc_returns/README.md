# ACC RETURNS
This module converts the gz files that are received from ACC into parquet files and 
loads them back into the corresponding cdr be location. For complete details please refers to the wiki's 
mentioned in the important wiki links section.
This module also has the different scripts that are called by external modules, will go into details of 
each script in the below sections.
Please refer to this wiki page on how to call each script for detailed parameters https://wiki.advisory.com/display/OACA/CDR+BackEnd+-+ACC+Returns

# Models
In the models directory we have the conversion models for all the three ACC Streams. The files we receive from ACC are fixed 
length for SRE and EBM and comma separated for HEDIS, the corresponding logic to read these files and map to case classes 
exists in the model classes.

# ACCFactory
We have a Factory method that is used for EBM and SRE to get the right model and convert the rows to the df.
In the future if we receive more files from ACC then we have to add a row in the cdr_control_table_map.txt file with filename,
mapping model name and then in the models directory add a model with corresponding logic and add the mapping in the ACCFactory 
should take of it.

# load_acc_data_hdfs.sh
This script is called by load_control_total.sh in ( https://svn.humedica.net/svn/ops/cdr/trunk/bash/load_control_totals.sh ).
The location of this file is configured in the configuration within the cdr project in svn to be used by load_control_total.sh
This script transfers the gz files into hdfs location.
for eg for EBM: /optum/data_factory/${CLIENT_ID}/${ENV}/external/acc/${processid}/in_ebm/monthly/{DATE}/landed

# trigger_postaccreturns_ifready.sh
Ths script checks if all streams for given cdrSchema are processed and corresponding returns are copied back to HDFS.
This script looks for ebm,sre,hedis_yr0,hedis_yr1,hedis_yr2 streams. If everything is done then invokes the jsonb.
jsonb calls invokes the script to convert the gz files to parquet followed by loading the parquet into the cdr be location.

# cdr_acc_return.sh
This script calculates the processIds if not passed and calls ACCReturnLoader by passing the required parameters and ACCReturnLoader will call the ParquetConverter 
and converts the corresponding streams gz files into the parquet files and places them in the hdfs external 
location.
for eg for EBM: /optum/data_factory/${CLIENT_ID}/${ENV}/external/acc/${processid}/in_ebm/monthly/{DATE}/data

# load_acc_data_cdrbe.sh
This script copies converted parquet file back to CDR BE location. Related processIds are calculated by using groupId,environment,accStreams and cdrSchema
if processIds are provided, processIds calculation will be ignored. For production, processIds are calculated rather than being passed.

# generate_configfile.sh
This script generates config file when the extracts are sent and called from bpo_extracts module, saves into HDFS to be later used during the acc-returns injection process for given processId. 
If file already exists, overwrites the existing file
Location of the the config file is /optum/data_factory/H303173/stg/external/acc/{process_id}/{process_id}_config.cfg

# generate_processids.sh
calculates and echoes the most recent processIds for the given acc streams. This script is used in cdr_acc_return.sh and locad_acc_data_cdrbe.sh

# How to invoke these scripts
Please refer to the wiki page on how invoke these scripts all the parameters listed there in detail 
https://wiki.advisory.com/display/OACA/CDR+BackEnd+-+ACC+Returns

# How to configure/enable a client to run BPO and ACC ingestion process.
A component 'BPO' needs to be added to a release-specific config file, for the specific group(s).

eg turning it on for H053731 and H218562 in 201912 release means updating https://svn.humedica.net/svn/ops/cdr/branches/CDR_201912/bash/backend/config/client_components.cfg
from
```$xslt
 {"client_id":"H053731", "components":"OADW,eOADW"}
 ,{"client_id":"H218562", "components":"OADW"}

to

{"client_id":"H053731", "components":"OADW,eOADW,BPO"}
,{"client_id":"H218562", "components":"OADW,BPO"}
```
# Inbound table
Information related to the returns that are received will be in job_control.inbound_file_trackerv2 table.
                                                           
# Important wiki links 
https://wiki.advisory.com/display/DATAPIPE/eCDR+Code+and+Data+Elements
https://wiki.advisory.com/display/OACA/CDR+BackEnd+-+ACC+Returns
