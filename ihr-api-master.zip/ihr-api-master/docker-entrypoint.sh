#!/bin/sh

export CLOUD_APP=$(echo $HOSTNAME | cut -d '-' -f1,2)
cd /logs
for i in $(ls -l | awk '{print $9}' | grep $CLOUD_APP | grep -v $HOSTNAME)
do 
echo -e “ Removing $i”
rm $i 
done

find /logs -type f -name "*.log" -mtime +30 -print -exec rm -rf {} \;
/opt/dynatrace/oneagent/dynatrace-agent64.sh /usr/lib/jvm/java-1.8-openjdk/bin/java -Xms64M -Xmx1G -jar /app/app.jar
