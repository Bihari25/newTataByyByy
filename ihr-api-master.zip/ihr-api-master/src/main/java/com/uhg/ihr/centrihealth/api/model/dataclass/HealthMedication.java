package com.uhg.ihr.centrihealth.api.model.dataclass;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.*;

import java.math.BigInteger;
import java.util.List;
import java.util.Map;

@EqualsAndHashCode(callSuper = false)
@AllArgsConstructor
@Data
@NoArgsConstructor
public class HealthMedication extends BaseDataClass {
    private DataClassEnums recordType;
    private String recordKey;
    private String medicationStartDate;
    private IhrTerm medication;
    private IhrTerm medicationStatus;
    private Integer daysSupply;
    private Double dosageQuantity;
    private String dosageFrequency;
    private IhrTerm doseFrequency;
    private IhrTerm dosageForm;
    private Float dispensedQuantity;
    private IhrTerm dosageUnit;
    private IhrTerm dispensedQuantityUnit;
    private String lastFillDate;
    private String icueSeqId;
    private String icueLastUpdateDate;
    private String clinicallyRelevantDate;
    private String orderDate;
    private String firstDoseDate;
    private String endDate;
    private String holdDate;
    private String restartedDate;
    private Boolean takenAsOrdered;
    private String adherenceStopdate;
    private Integer refillAuthorizedNumber;
    private Float refillCount;
    private IhrTerm refillCountUnit;
    private Boolean genericFlag;
    private String expectedFillDate;
    private String adminInstructions;
    private List<String> prescriptionId;
    private String lastUpdateDate;
    private String presenceStateTerm;
    private List<String> sensitivityClasses;
    private List<BigInteger> relatedConditions;
    private List<BigInteger> relatedProcedures;
    private List<BigInteger> relatedDevices;
    private List<BigInteger> relatedCareTeam;
    private List<BigInteger> relatedServiceProviders;
    private List<BigInteger> sourceClaims;
    private List<String> referenceIds;
    private List<String> dataSource;
    private List<String> drugClass;
    private String deaSchedule;
    private OrderingProvider orderingProvider;
    private Supplier supplier;
    private String genericDrugName;
    private String medicationReviewDate;
    private String reviewedBy;
    private String reviewerIhrActorIdentifier;
    private String informer;
    private String medicationReviewLastActivityDate;
    private List<Note> note;
    private List<BigInteger> relatedAllergies;
    private IhrTerm doseQuantityUnit;
    private IhrTerm dosageRoute;
    private List<IhrTerm> medicationReason;
    private IhrTerm informerObject;
    private String productType;
    private String classType;
    private String regAuthority;
    private String requestStatus;
    private String requestIntent;
    private String dispenseStatus;

    @JsonProperty("reviewedBy")
    private void extractEmployeeIdMap(Object reviewedByObj) {
        if (reviewedByObj instanceof Map) {
            Map<String, Object> reviewedByMap = (Map<String,Object>) reviewedByObj;
            if (!reviewedByMap.isEmpty() && reviewedByMap.containsKey("employeeId")) {
                this.reviewedBy = (String) reviewedByMap.get("employeeId");
            } else {
                this.reviewedBy = null;
            }
        } else if (reviewedByObj instanceof String) {
            this.reviewedBy = (String) reviewedByObj;
        }
    }

    @Builder
    public HealthMedication(BigInteger objectId, DataClassEnums recordType, String recordKey, String medicationStartDate, IhrTerm medication, IhrTerm medicationStatus, Integer daysSupply, Double dosageQuantity, String dosageFrequency, IhrTerm doseFrequency, IhrTerm dosageForm, Float dispensedQuantity, IhrTerm dosageUnit, IhrTerm dispensedQuantityUnit, String lastFillDate, String icueSeqId, String icueLastUpdateDate, String clinicallyRelevantDate, String orderDate, String firstDoseDate, String endDate, String holdDate, String restartedDate, Boolean takenAsOrdered, String adherenceStopdate, Integer refillAuthorizedNumber, Float refillCount, IhrTerm refillCountUnit, Boolean genericFlag, String expectedFillDate, String adminInstructions, List<String> prescriptionId, String lastUpdateDate, String presenceStateTerm, List<String> sensitivityClasses, List<BigInteger> relatedConditions, List<BigInteger> relatedProcedures, List<BigInteger> relatedDevices, List<BigInteger> relatedCareTeam, List<BigInteger> relatedServiceProviders, List<BigInteger> sourceClaims, List<String> referenceIds, List<String> dataSource, List<String> drugClass, String deaSchedule, OrderingProvider orderingProvider, Supplier supplier, String genericDrugName, String medicationReviewDate, String reviewedBy, String reviewerIhrActorIdentifier, String informer, String medicationReviewLastActivityDate, List<Note> note, List<BigInteger> relatedAllergies, IhrTerm doseQuantityUnit, IhrTerm dosageRoute, List<IhrTerm> medicationReason, IhrTerm informerObject, String productType, String classType, String regAuthority, String requestStatus, String requestIntent, String dispenseStatus) {
        super(objectId);
        this.recordType = recordType;
        this.recordKey = recordKey;
        this.medicationStartDate = medicationStartDate;
        this.medication = medication;
        this.medicationStatus = medicationStatus;
        this.daysSupply = daysSupply;
        this.dosageQuantity = dosageQuantity;
        this.dosageFrequency = dosageFrequency;
        this.doseFrequency = doseFrequency;
        this.dosageForm = dosageForm;
        this.dispensedQuantity = dispensedQuantity;
        this.dosageUnit = dosageUnit;
        this.dispensedQuantityUnit = dispensedQuantityUnit;
        this.lastFillDate = lastFillDate;
        this.icueSeqId = icueSeqId;
        this.icueLastUpdateDate = icueLastUpdateDate;
        this.clinicallyRelevantDate = clinicallyRelevantDate;
        this.orderDate = orderDate;
        this.firstDoseDate = firstDoseDate;
        this.endDate = endDate;
        this.holdDate = holdDate;
        this.restartedDate = restartedDate;
        this.takenAsOrdered = takenAsOrdered;
        this.adherenceStopdate = adherenceStopdate;
        this.refillAuthorizedNumber = refillAuthorizedNumber;
        this.refillCount = refillCount;
        this.refillCountUnit = refillCountUnit;
        this.genericFlag = genericFlag;
        this.expectedFillDate = expectedFillDate;
        this.adminInstructions = adminInstructions;
        this.prescriptionId = prescriptionId;
        this.lastUpdateDate = lastUpdateDate;
        this.presenceStateTerm = presenceStateTerm;
        this.sensitivityClasses = sensitivityClasses;
        this.relatedConditions = relatedConditions;
        this.relatedProcedures = relatedProcedures;
        this.relatedDevices = relatedDevices;
        this.relatedCareTeam = relatedCareTeam;
        this.relatedServiceProviders = relatedServiceProviders;
        this.sourceClaims = sourceClaims;
        this.referenceIds = referenceIds;
        this.dataSource = dataSource;
        this.drugClass = drugClass;
        this.deaSchedule = deaSchedule;
        this.orderingProvider = orderingProvider;
        this.supplier = supplier;
        this.genericDrugName = genericDrugName;
        this.medicationReviewDate = medicationReviewDate;
        this.reviewedBy = reviewedBy;
        this.reviewerIhrActorIdentifier = reviewerIhrActorIdentifier;
        this.informer = informer;
        this.medicationReviewLastActivityDate = medicationReviewLastActivityDate;
        this.note = note;
        this.relatedAllergies = relatedAllergies;
        this.doseQuantityUnit = doseQuantityUnit;
        this.dosageRoute = dosageRoute;
        this.medicationReason = medicationReason;
        this.informerObject = informerObject;
        this.productType = productType;
        this.classType = classType;
        this.regAuthority = regAuthority;
        this.requestStatus = requestStatus;
        this.requestIntent = requestIntent;
        this.dispenseStatus = dispenseStatus;
    }
}
