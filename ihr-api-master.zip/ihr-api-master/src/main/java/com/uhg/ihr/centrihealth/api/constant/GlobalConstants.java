package com.uhg.ihr.centrihealth.api.constant;

public interface GlobalConstants {

    String RECORD_KEY = "recordKey";
    String OBJECT_ID = "instanceId";
    String REFERENCE_IDS = "referenceIds";
    String SECURITY_LABELS_CODE = "R";
    String NOTE_TYPES = "Clinical Note";
    String EMPLOYEE_ID = "employeeId";
    String FDB_CODE_URL = "2.16.840.1.113883.6.64";
    String NPI = "NPI";
    String PRESCRIPTION_ID = "prescriptionId";
    String RELATED_CONDITION_IDS = "relatedConditionIds";
    String REVIEWER_IHR_ACTOR_IDENTIFIRE = "reviewerIhrActorIdentifier";
    String RELATED_DEVICE_INSTANCE_IDS = "relatedDeviceInstanceIds";
    String RELATED_CARE_TEAM_INSTANCE_IDS = "relatedCareTeamInstanceIds";
    String RELATED_SERVICE_FACILITY_PROVIDER_INSTANCE_IDS = "relatedServiceFacilityProviderInstanceIds";
    String RELATED_CONDITION_INSTANCE_IDS = "relatedConditionInstanceIds";
    String RELATED_OBSERVATION_INSTANCE_IDS = "relatedObservationInstanceIds";
    String SOURCE_CLAIM_IDS = "sourceClaimIds";
    String VACCINE_REFERENCE_IDS = "vaccineReferenceIds";
    String VACCINE_RECORD_KEY = "vaccineRecordKey";

}