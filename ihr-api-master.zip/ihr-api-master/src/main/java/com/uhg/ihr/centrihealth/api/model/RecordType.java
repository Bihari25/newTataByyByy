package com.uhg.ihr.centrihealth.api.model;

public enum RecordType {
    //1.0 only record types //FIXME: remove with 1.0
    ACTIVE_ADVERSE_REACTION,
    ACTIVE_HEALTH_CONDITION,
    ACTIVE_HEALTH_DEVICE,
    CURRENT_HEALTH_MEDICATION,
    HEALTH_MOTIVATION_SCORE,
    PAST_HEALTH_CONDITION,
    PAST_HEALTH_MEDICATION,
    TEST_AND_EXAM,

    //1.0 and 2.0 record types
    CARE_GIVER,
    CARE_TEAM,
    HEALTH_OBSERVATIONS,
    HEALTH_STATUS,
    PROCEDURE_HISTORY,
    SERVICE_FACILITY_PROVIDER,
    VISIT_HISTORY,

    //2.0 record types
    ADVERSE_REACTION,
    HEALTH_CONDITION,
    HEALTH_DEVICE,
    HEALTH_MEDICATION,
    IMMUNIZATIONS;

    public final static String RECORD_TYPE = "recordType";
}
