package com.uhg.ihr.centrihealth.api.model;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.annotation.JsonPropertyOrder;
import com.fasterxml.jackson.databind.JsonNode;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder(toBuilder = true)
@AllArgsConstructor
@NoArgsConstructor
@JsonPropertyOrder({ "apiVersion", "dataVersion", "schemaVersion", "correlationId", "language", "mbrID", "mbrId", "requestor", "dataClasses" })
public class IhrApiResponse {

    @JsonProperty
    private String apiVersion;

    @JsonProperty
    private String schemaVersion;

    @JsonProperty
    private String dataVersion;

    @JsonProperty
    private String correlationId;

    @JsonProperty
    private String language;

    /**
     * used for the 2.0+ response
     */
    @JsonInclude(JsonInclude.Include.NON_NULL)
    @JsonProperty("mbrId")
    private MId mbrId;

    //FIXME: remove with 1.0
    /**
     * used for the 1.0 response, deprecated
     */
    @Deprecated
    @JsonInclude(JsonInclude.Include.NON_NULL)
    @JsonProperty("mbrID")
    private MId mbrID;

    @JsonProperty
    private JsonNode dataClasses;

    @JsonProperty
    private Big5 requestor;
}