package com.uhg.ihr.centrihealth.api.service.fhir.deferred;

import org.hl7.fhir.r4.model.Procedure;

import java.util.function.Consumer;

public class ProcedureDeferredMapper extends DeferredMapper<Procedure> {

    public ProcedureDeferredMapper(Consumer<Procedure> mapper) {
        super(mapper);
    }
}
