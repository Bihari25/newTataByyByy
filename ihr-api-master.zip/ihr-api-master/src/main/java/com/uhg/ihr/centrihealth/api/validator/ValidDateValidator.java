package com.uhg.ihr.centrihealth.api.validator;

import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;

import javax.validation.ConstraintValidator;
import javax.validation.ConstraintValidatorContext;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Date;

@Slf4j
public class ValidDateValidator implements ConstraintValidator<ValidDate, String> {
    private final static String FORMAT = "yyyy/MM/dd";

    @Override
    public boolean isValid(final String value, final ConstraintValidatorContext constraintValidatorContext) {
        if (StringUtils.isEmpty(value)) {
            return false;
        }
        return isValidFormat(value);
    }

    private static boolean isValidFormat(final String value) {
        Date date = null;
        try {
            SimpleDateFormat sdf = new SimpleDateFormat(FORMAT);

            date = sdf.parse(value);
            if (!value.equals(sdf.format(date))) {
                log.debug("Invalid date");
                date = null;
            }

        } catch (ParseException ex) {
            log.debug("Invalid date");
        }
        return date != null;
    }
}