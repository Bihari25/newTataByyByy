package com.uhg.ihr.centrihealth.api.model.dataclass;

import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@Data
@NoArgsConstructor
public class Occupation {
    private IhrTermWithId concept;
    private List<IhrTermWithId> specialties;
}
