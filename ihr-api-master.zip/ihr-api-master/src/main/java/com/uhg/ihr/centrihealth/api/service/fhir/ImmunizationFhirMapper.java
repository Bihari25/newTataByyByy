package com.uhg.ihr.centrihealth.api.service.fhir;

import com.uhg.ihr.centrihealth.api.model.FhirResource;
import com.uhg.ihr.centrihealth.api.model.dataclass.Constants;
import com.uhg.ihr.centrihealth.api.model.dataclass.DataClass;
import com.uhg.ihr.centrihealth.api.model.dataclass.Immunizations;
import com.uhg.ihr.centrihealth.api.model.dataclass.Note;
import com.uhg.ihr.centrihealth.api.util.AppUtils;
import io.micrometer.core.instrument.util.StringUtils;
import lombok.Value;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections.CollectionUtils;
import org.hl7.fhir.r4.model.*;

@Slf4j
@Value(staticConstructor = "of")
public class ImmunizationFhirMapper implements FhirMapper<Immunizations, Immunization> {


    @Override
    public void map(FhirResource fhirResource, DataClass dataClasses) {
        if (dataClasses != null && CollectionUtils.isNotEmpty(dataClasses.getImmunizations())) {
            map(fhirResource, dataClasses.getImmunizations());
        }
    }

    @Override
    public void map(FhirResource fhirResource, Immunizations ihrImmunization) {
        Patient patient = fhirResource.getPatient();
        Bundle bundle = fhirResource.getBundle();

        Immunization immunization = new Immunization();
        immunization.setId(new IdType(createIdURI()));
        //record key
        if (null != ihrImmunization.getRecordKey()) {
            immunization.addIdentifier().setValue(ihrImmunization.getRecordKey())
                    .setType(new CodeableConcept().setText(Constants.RECORD_KEY));
        }
        //reference id
        if (CollectionUtils.isNotEmpty(ihrImmunization.getReferenceIds())) {
            immunization.addIdentifier().setValue(AppUtils.jsonEscape(ihrImmunization.getReferenceIds()))
                    .setType(new CodeableConcept().setText(Constants.REFERENCE_IDS));
        }

        //object id
        if (null != ihrImmunization.getObjectId()) {
            immunization.addIdentifier().setValue(ihrImmunization.getObjectId().toString())
                    .setType(new CodeableConcept().setText(Constants.INSTANCE_ID));
        }

        //concept
        if (null != ihrImmunization.getConcept()) {
            CodeableConcept code = new CodeableConcept();
            code.setText(ihrImmunization.getConcept().getIhrLaymanTerm())
                    .addCoding(new Coding()
                            .setDisplay(ihrImmunization.getConcept().getIhrTerm())
                            .setCode(ihrImmunization.getConcept().getSourceVocabularyCode())
                            .setSystem(ihrImmunization.getConcept().getSourceVocabulary()));
            if (StringUtils.isNotBlank(ihrImmunization.getConcept().getCpthcpcsCode())) {
                code.addCoding()
                        .setCode(ihrImmunization.getConcept().getCpthcpcsCode())
                        .setSystem(Constants.CPTHCPCS_CODE_URL);
            }
            immunization.addReasonCode(code);

        }

        //medication
        if (null != ihrImmunization.getMedication()) {
            immunization.setVaccineCode(new CodeableConcept().setText(ihrImmunization.getMedication().getIhrTerm())
                    .addCoding(new Coding()
                            .setDisplay(ihrImmunization.getMedication().getIhrLaymanTerm())
                            .setSystem(ihrImmunization.getMedication().getSourceVocabulary())
                            .setCode(ihrImmunization.getMedication().getSourceVocabularyCode())));
        }

        //generic flag
        if (null != ihrImmunization.getGenericFlag()) {
            immunization.addExtension(Constants.GENERIC_FLAG_URL, new BooleanType(ihrImmunization.getGenericFlag()));
        }
        //dosagequantity
        if (null != ihrImmunization.getDosageQuantity()) {
            SimpleQuantity doseQuantity = new SimpleQuantity();
            doseQuantity.setValue(ihrImmunization.getDosageQuantity());
            if (ihrImmunization.getDosageUnit() != null) {
                doseQuantity.setUnit(ihrImmunization.getDosageUnit().getIhrTerm());
            }
            immunization.setDoseQuantity(doseQuantity);
        }
        //dosage unit
        if (null != ihrImmunization.getDosageUnit()) {
            immunization.addExtension(Constants.DOSAGE_UNIT_URL, new CodeableConcept()
                    .setText(ihrImmunization.getDosageUnit().getIhrLaymanTerm())
                    .addCoding(new Coding()
                            .setDisplay(ihrImmunization.getDosageUnit().getIhrTerm())
                            .setSystem(ihrImmunization.getDosageUnit().getSourceVocabulary())
                            .setCode(ihrImmunization.getDosageUnit().getSourceVocabularyCode())));
        }
        //dosage frequency
        if (null != ihrImmunization.getDosageFrequency()) {
            immunization.addExtension(Constants.DOSAGE_FREQUENCY_URL, new StringType(ihrImmunization.getDosageFrequency()));
        }
        //dosage form
        if (null != ihrImmunization.getDosageForm()) {
            immunization.addExtension(Constants.DOSAGE_FORM_URL, new CodeableConcept()
                    .setText(ihrImmunization.getDosageForm().getIhrLaymanTerm())
                    .addCoding(new Coding()
                            .setDisplay(ihrImmunization.getDosageForm().getIhrTerm())
                            .setSystem(ihrImmunization.getDosageForm().getSourceVocabulary())
                            .setCode(ihrImmunization.getDosageForm().getSourceVocabularyCode())));
        }
        //doseNumber
        if (null != ihrImmunization.getMedication() && null != ihrImmunization.getMedication().getDoseNumber()) {
            immunization.addProtocolApplied(
                    new Immunization.ImmunizationProtocolAppliedComponent()
                            .setDoseNumber(new PositiveIntType().setValue(ihrImmunization.getMedication().getDoseNumber().intValue())));
        }
        //lotNumber
        if (null != ihrImmunization.getMedication() && null != ihrImmunization.getMedication().getLotNumber()) {
            immunization.setLotNumber(ihrImmunization.getMedication().getLotNumber());
        }
        //presence state term
        if (null != ihrImmunization.getPresenceStateTerm()) {
            immunization.addExtension(Constants.PRESENCE_STATE_TERM_URL, new StringType(ihrImmunization.getPresenceStateTerm()));
        }
        //health event date administartion date
        if (StringUtils.isNotBlank(ihrImmunization.getHealthEventDate())) {
            immunization.setOccurrence(toDateTimeTypeFromDate(ihrImmunization.getHealthEventDate()));
        }
        //Clinically relevant date
        if (StringUtils.isNotBlank(ihrImmunization.getClinicallyRelevantDate())) {
            immunization.addExtension(Constants.CLINICALLY_RELEVANT_DATE_URL, this.toDateTimeTypeFromDate(ihrImmunization.getClinicallyRelevantDate()));
        }
        //last update date
        if (StringUtils.isNotBlank(ihrImmunization.getLastUpdateDate())) {
            immunization.setMeta(new Meta().setLastUpdatedElement(toInstantTypeFromDate(ihrImmunization.getLastUpdateDate())));
        }
        // note
        if (CollectionUtils.isNotEmpty(ihrImmunization.getNote())) {
            for (Note note : ihrImmunization.getNote()) {
                immunization.addNote(getAnnotation(patient, note, fhirResource));
            }
        }
        //Related Conditions
        if (CollectionUtils.isNotEmpty(ihrImmunization.getRelatedConditions())) {
            immunization.addIdentifier().setValue(AppUtils.jsonEscape(ihrImmunization.getRelatedConditions()))
                    .setType(new CodeableConcept().setText(Constants.RELATED_CONDITION_INSTANCE_IDS));
        }
        //related observations
        if (CollectionUtils.isNotEmpty(ihrImmunization.getRelatedObservations())) {
            immunization.addIdentifier().setValue(AppUtils.jsonEscape(ihrImmunization.getRelatedObservations()))
                    .setType(new CodeableConcept().setText(Constants.RELATED_OBSERVATION_INSTANCE_IDS));
        }
        //related care team
        if (CollectionUtils.isNotEmpty(ihrImmunization.getRelatedCareTeam())) {
            immunization.addIdentifier().setValue(AppUtils.jsonEscape(ihrImmunization.getRelatedCareTeam()))
                    .setType(new CodeableConcept().setText(Constants.RELATED_CARE_TEAM_INSTANCE_IDS));
        }
        //related service facility providers
        if (CollectionUtils.isNotEmpty(ihrImmunization.getRelatedServiceProviders())) {
            immunization.addIdentifier().setValue(AppUtils.jsonEscape(ihrImmunization.getRelatedServiceProviders()))
                    .setType(new CodeableConcept().setText(Constants.RELATED_SERVICE_FACILITY_PROVIDER_INSTANCE_IDS));
        }
        //sensitivity classes
        if (CollectionUtils.isNotEmpty(ihrImmunization.getSensitivityClasses())) {
            immunization.addExtension(Constants.SENSITIVITY_CLASSES_URL,
                    new StringType(AppUtils.jsonEscape(ihrImmunization.getSensitivityClasses())));
        }
        //source claim ids
        if (CollectionUtils.isNotEmpty(ihrImmunization.getSourceClaimIds())) {
            immunization.addIdentifier().setValue(AppUtils.jsonEscape(ihrImmunization.getSourceClaimIds()))
                    .setType(new CodeableConcept().setText(Constants.SOURCE_CLAIM_IDS));
        }
        //data source
        if (CollectionUtils.isNotEmpty(ihrImmunization.getDataSource())) {
            immunization.addExtension(Constants.DATA_SOURCE_URL, new StringType(AppUtils.jsonEscape(ihrImmunization.getDataSource())));
        }

        //vaccineReferenceIds
        if (null != ihrImmunization.getMedication() && null != ihrImmunization.getMedication().getReferenceIds()) {
            immunization.addIdentifier().setValue(AppUtils.jsonEscape(ihrImmunization.getMedication().getReferenceIds()))
                    .setType(new CodeableConcept().setText(Constants.VACCINE_REFERENCE_IDS));
        }
        //recordKey //VACCINE_RECORD_KEY
        if (null != ihrImmunization.getMedication() && null != ihrImmunization.getMedication().getRecordKey()) {
            immunization.addIdentifier().setValue(ihrImmunization.getMedication().getRecordKey())
                    .setType(new CodeableConcept().setText(Constants.VACCINE_RECORD_KEY));
        }
        // note
        if (CollectionUtils.isNotEmpty(ihrImmunization.getNote())) {
            for (Note note : ihrImmunization.getNote()) {
                immunization.addNote(getAnnotation(patient, note, fhirResource));
            }
        }

        immunization.setPatient(new Reference(patient));

        // add resource into bundle
        bundle.addEntry().setFullUrl(immunization.getId()).setResource(immunization);
    }
}
