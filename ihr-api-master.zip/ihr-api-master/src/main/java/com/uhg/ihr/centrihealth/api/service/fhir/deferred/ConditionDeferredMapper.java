package com.uhg.ihr.centrihealth.api.service.fhir.deferred;

import org.hl7.fhir.r4.model.Condition;

import java.util.function.Consumer;

public class ConditionDeferredMapper extends DeferredMapper<Condition> {

    public ConditionDeferredMapper(Consumer<Condition> mapper) {
        super(mapper);
    }
}
