package com.uhg.ihr.centrihealth.api.service.fhir.v2;

import com.uhg.ihr.centrihealth.api.constant.GlobalConstants;
import com.uhg.ihr.centrihealth.api.constant.GlobalUrlConstant;
import com.uhg.ihr.centrihealth.api.model.FhirResource;
import com.uhg.ihr.centrihealth.api.model.dataclass.DataClass;
import com.uhg.ihr.centrihealth.api.model.dataclass.ProcedureHistory;
import com.uhg.ihr.centrihealth.api.service.fhir.FhirMapper;
import com.uhg.ihr.centrihealth.api.service.fhir.deferred.ObservationDeferredMapper;
import com.uhg.ihr.centrihealth.api.util.AppUtils;
import io.micrometer.core.instrument.util.StringUtils;
import lombok.Value;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections.CollectionUtils;
import org.hl7.fhir.exceptions.FHIRException;
import org.hl7.fhir.r4.model.Bundle;
import org.hl7.fhir.r4.model.Coding;
import org.hl7.fhir.r4.model.IdType;
import org.hl7.fhir.r4.model.Patient;
import org.hl7.fhir.r4.model.Procedure;
import org.hl7.fhir.r4.model.Reference;
import org.hl7.fhir.r4.model.StringType;

import java.math.BigInteger;

@Slf4j
@Value(staticConstructor = "of")
public class ProcedureFhir2Mapper implements FhirMapper<ProcedureHistory, Procedure> {

    @Override
    public void map(FhirResource fhirResource, DataClass dataClasses) {
        if (dataClasses != null && CollectionUtils.isNotEmpty(dataClasses.getProcedureHistory())) {
            map(fhirResource, dataClasses.getProcedureHistory());
        }
    }

    @Override
    public void map(FhirResource fhirResource, ProcedureHistory procedureHistory) {
        Patient patient = fhirResource.getPatient();
        Bundle bundle = fhirResource.getBundle();

        Procedure procedure = buildProcedure(fhirResource, procedureHistory);

        procedure.setSubject(new Reference(patient));

        // add resource to deferred mapper
        fhirResource.addFhirResourceToDeferredMapper(procedure, procedureHistory);

        //add resource in bundle
        bundle.addEntry().setFullUrl(procedure.getId()).setResource(procedure);
    }

    public Procedure buildProcedure(FhirResource fhirResource, ProcedureHistory procedureHistory) {

        Procedure procedure = new Procedure();
        procedure.setId(new IdType(createIdURI()));

        buildProcedureIdentifier(procedure, procedureHistory);
        buildProcedureExtension(procedure, procedureHistory);

        //health event
        if (null != procedureHistory.getHealthEvent() ) {
            procedure.getCode().setText(procedureHistory.getHealthEvent().getIhrLaymanTerm())
                    .addCoding(createCoding(procedureHistory.getHealthEvent().getSourceVocabulary(),
                            procedureHistory.getHealthEvent().getSourceVocabularyCode(),
                            procedureHistory.getHealthEvent().getIhrTerm()));

            if (null != procedureHistory.getHealthEvent() && null != procedureHistory.getHealthEvent().getCpthcpcsCode()) {
                procedure.getCode().addCoding(createCoding(GlobalUrlConstant.CPT_CODE_URL, procedureHistory.getHealthEvent().getCpthcpcsCode(), ""));
            }
        }
        //medicalDomain
        if (null != procedureHistory.getHealthEvent() && null != procedureHistory.getHealthEvent().getMedicalDomain()) {
            procedure.getCategory().setText(procedureHistory.getHealthEvent().getMedicalDomain());
        }
        //sensitivity classes
        if (CollectionUtils.isNotEmpty(procedureHistory.getSensitivityClasses())) {
            procedure.getMeta().getSecurity()
                    .add(new Coding().setSystem(GlobalUrlConstant.SECURITY_LABELS_URL).setCode(GlobalConstants.SECURITY_LABELS_CODE));
        }
        //health event date
        if (StringUtils.isNotBlank(procedureHistory.getHealthEventDate())) {
            procedure.setPerformed(toDateTimeTypeFromDate(procedureHistory.getHealthEventDate()));
        }
        //status
        if (null != procedureHistory.getHealthEventStatus() && null != procedureHistory.getHealthEventStatus().getIhrTerm()) {
                procedure.setStatus(getProcedureStatus(procedureHistory.getHealthEventStatus().getIhrTerm()));
        }
        //last updated date
        if (StringUtils.isNotBlank(procedureHistory.getLastUpdateDate())) {
            procedure.getMeta().setLastUpdatedElement(toInstantTypeFromDate(procedureHistory.getLastUpdateDate()));
        }
        //related observations
        if (CollectionUtils.isNotEmpty(procedureHistory.getRelatedObservations())) {
            for (BigInteger objectId : procedureHistory.getRelatedObservations()) {
                fhirResource.addDeferredFhirMapper(
                        objectId,
                        new ObservationDeferredMapper(observation -> observation.addPartOf(new Reference(procedure)))
                );
            }
        }
        return procedure;
    }

    private void buildProcedureExtension(Procedure procedure, ProcedureHistory procedureHistory) {
        //Clinically relevant date
        if (StringUtils.isNotBlank(procedureHistory.getClinicallyRelevantDate())) {
            procedure.addExtension(GlobalUrlConstant.CLINICAL_RELEVANT_DATE_URL, this.toDateTimeTypeFromDate(procedureHistory.getClinicallyRelevantDate()));
        }
        //presence state term
        if (StringUtils.isNotBlank(procedureHistory.getPresenceStateTerm())) {
            procedure.addExtension(GlobalUrlConstant.PRESENCESTATE_URL, new StringType(procedureHistory.getPresenceStateTerm()));
        }
    }

    private void buildProcedureIdentifier(Procedure procedure, ProcedureHistory procedureHistory) {

        //recordKey
        if (null != procedureHistory.getRecordKey()) {
            procedure.addIdentifier(createIdentifier(procedureHistory.getRecordKey(), GlobalConstants.RECORD_KEY));
        }
        //object id
        if (null != procedureHistory.getObjectId()) {
            procedure.addIdentifier(createIdentifier(procedureHistory.getObjectId().toString(), GlobalConstants.OBJECT_ID));
        }
        //reference id
        if (CollectionUtils.isNotEmpty(procedureHistory.getReferenceIds())) {
            procedure.addIdentifier(createIdentifier(AppUtils.jsonEscape(procedureHistory.getReferenceIds()),
                    GlobalConstants.REFERENCE_IDS));
        }
        //related conditions
        if (CollectionUtils.isNotEmpty(procedureHistory.getRelatedConditions())) {
            procedure.addIdentifier(createIdentifier(AppUtils.jsonEscape(procedureHistory.getRelatedConditions())
                    , GlobalConstants.RELATED_CONDITION_INSTANCE_IDS));
        }
        //related care team
        if (CollectionUtils.isNotEmpty(procedureHistory.getRelatedCareTeam())) {
            procedure.addIdentifier(createIdentifier(AppUtils.jsonEscape(procedureHistory.getRelatedCareTeam())
                    , GlobalConstants.RELATED_CARE_TEAM_INSTANCE_IDS));
        }
        //related service providers
        if (CollectionUtils.isNotEmpty(procedureHistory.getRelatedServiceProviders())) {
            procedure.addIdentifier(createIdentifier(AppUtils.jsonEscape(procedureHistory.getRelatedServiceProviders()),
                    GlobalConstants.RELATED_SERVICE_FACILITY_PROVIDER_INSTANCE_IDS));
        }
        //source claim ids
        if (CollectionUtils.isNotEmpty(procedureHistory.getSourceClaimIds())) {
            procedure.addIdentifier(createIdentifier(AppUtils.jsonEscape(procedureHistory.getSourceClaimIds())
                    , GlobalConstants.SOURCE_CLAIM_IDS));
        }
    }

    /**
     * Prepares the provided ihrTerm string into the expected format for ProcedureStatus.fromCode
     * If no code can be found then ProcedureStatus.UNKNOWN is returned and the error is logged
     *
     * @param ihrTerm The ihrTerm string to turn into a Procedure.ProcedureStatus code
     * @return Returns Procedure.ProcedureStatus enum base on provided string
     */
    private Procedure.ProcedureStatus getProcedureStatus(String ihrTerm) {
        String preparedIhrTerm = ihrTerm.toLowerCase();
        if (preparedIhrTerm.contains(" ")) {
            preparedIhrTerm = preparedIhrTerm.replaceAll(" ", "-");
        }
        if (preparedIhrTerm.contains("_")) {
            preparedIhrTerm = preparedIhrTerm.replaceAll("_", "-");
        }
        try {
            return Procedure.ProcedureStatus.fromCode(preparedIhrTerm);
        } catch (FHIRException e) {
            log.error("Error setting Procedure status: {}", e.getMessage());
            return Procedure.ProcedureStatus.UNKNOWN;
        }
    }
}