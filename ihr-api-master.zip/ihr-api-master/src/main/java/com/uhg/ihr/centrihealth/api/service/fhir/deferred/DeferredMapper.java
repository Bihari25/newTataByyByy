package com.uhg.ihr.centrihealth.api.service.fhir.deferred;

import org.hl7.fhir.r4.model.Resource;

import java.util.function.Consumer;

public abstract class DeferredMapper<T extends Resource> {

    private Consumer<T> mapper;

    public DeferredMapper(Consumer<T> mapper) {
        this.mapper = mapper;
    }

    public void processMapper(T fhirResource) {
        mapper.accept(fhirResource);
    }
}
