package com.uhg.ihr.centrihealth.api.model.dataclass;

import lombok.Builder;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

import java.math.BigInteger;
import java.util.List;

@Data
@EqualsAndHashCode(callSuper = false)
@NoArgsConstructor
public class HealthObservations extends BaseDataClass {
    private String recordType;
    private String recordKey;
    private String observationDate;
    private String lastUpdateDate;
    private String valueString;
    private IhrTerm observation;
    private IhrTerm observationUnitOfMeasure;
    private IhrTerm observationValue;
    private String referenceRange;
    private IhrTerm abnormalObservation;
    private List<String> sensitivityClasses;
    private List<String> dataSource;
    private List<String> referenceIds;
    private List<Note> note;
    private IhrTerm status;

    @Builder
    public HealthObservations(BigInteger objectId, String recordType, String recordKey, String observationDate, String lastUpdateDate, String valueString, IhrTerm observation, IhrTerm observationUnitOfMeasure, IhrTerm observationValue, String referenceRange, IhrTerm abnormalObservation, List<String> sensitivityClasses, List<String> dataSource, List<String> referenceIds, List<Note> note, IhrTerm status) {
        super(objectId);
        this.recordType = recordType;
        this.recordKey = recordKey;
        this.observationDate = observationDate;
        this.lastUpdateDate = lastUpdateDate;
        this.valueString = valueString;
        this.observation = observation;
        this.observationUnitOfMeasure = observationUnitOfMeasure;
        this.observationValue = observationValue;
        this.referenceRange = referenceRange;
        this.abnormalObservation = abnormalObservation;
        this.sensitivityClasses = sensitivityClasses;
        this.dataSource = dataSource;
        this.referenceIds = referenceIds;
        this.note = note;
        this.status = status;
    }
}
