package com.uhg.ihr.centrihealth.api.security;

import org.apache.commons.cli.CommandLine;
import org.apache.commons.cli.CommandLineParser;
import org.apache.commons.cli.DefaultParser;
import org.apache.commons.cli.HelpFormatter;
import org.apache.commons.cli.Option;
import org.apache.commons.cli.Options;
import org.apache.commons.cli.ParseException;
import org.codehaus.jackson.map.ObjectMapper;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.Arrays;
import java.util.List;
import java.util.stream.Collectors;

/**
 * Usage need to pass
 * -e for encryption
 * -d for decryption
 * -v for value to be encrypted or decrypted
 * -n for new version encryption or decryption
 * -p for private key wile decrypting  with new version
 * <p>
 * we must send either -e or -d and -v options while running the program for older version.
 * we must send either -e or (-d with -p) , -n and -v options while running the program for newer version.
 * encypted or decrypted value get printed on the console
 */
public class Main {
    private static final Logger LOGGER = LoggerFactory.getLogger(Main.class);
    private static final ObjectMapper MAPPER = new ObjectMapper();

    public static void main(String[] args) {
        Options options = new Options();

        Option encrypt = new Option("e", "option to encrypt");
        encrypt.setRequired(false);
        options.addOption(encrypt);

        Option value = new Option("v", "value", true, "Value to encrypt or decrypt");
        value.setRequired(true);
        options.addOption(value);

        Option decrypt = new Option("d", "option to decrypt");
        decrypt.setRequired(false);
        options.addOption(decrypt);

        Option version = new Option("n", "option to choose the version");
        version.setRequired(false);
        options.addOption(version);

        Option privateKey = new Option("p", "secretKey", true, "option to choose private key");
        privateKey.setRequired(false);
        options.addOption(privateKey);

        CommandLineParser parser = new DefaultParser();
        HelpFormatter formatter = new HelpFormatter();
        CommandLine cmd;

        try {
            cmd = parser.parse(options, args);

            Option[] options2 = cmd.getOptions();

            String encryptOpt = null;
            String decryptOpt = null;
            String privateKeyPath;

            List<Option> optionsList = Arrays.asList(options2);
            List<String> inputOptions = optionsList.stream().map(Option::getOpt).collect(Collectors.toList());

            if (inputOptions.contains("e") && inputOptions.contains("d")) {
                throw new ParseException("either encrypt or decrypt is allowed");
            }
            if (!(inputOptions.size() == 2) && !inputOptions.contains("n")) {
                throw new ParseException("Input parameters options should be  2, one is e or d and other is v ,it is not new version ");
            }
            if ((inputOptions.contains("n") && inputOptions.contains("d") && inputOptions.contains("p")) && !(inputOptions.size() == 4)) {
                throw new ParseException("Input parameters options should be  4, one is e or d , n , v and p ");
            }
            if ((inputOptions.contains("n") && inputOptions.contains("e")) && !(inputOptions.size() == 3)) {
                throw new ParseException("Input parameters options should be  3, one is e , n and v ");
            }

            for (String opt : inputOptions) {

                if (opt.equals("e")) {
                    encryptOpt = "e";
                    break;
                }
                if (opt.equals("d")) {
                    decryptOpt = "d";
                    break;
                }

            }
            String valueOpt = cmd.getOptionValue("value");
            privateKeyPath = cmd.getOptionValue("p");
            newVersion(decryptOpt, encryptOpt, valueOpt, privateKeyPath);
        } catch (ParseException e) {
            LOGGER.error("Could not parse the input parameters", e);
            formatter.printHelp("encryptORdecrypt", options);
        }
    }

    private static void newVersion(String decryptOpt, String encryptOpt, String valueOpt, String privateKeyPath) {

        String encryptData = null;
        String decryptData;
        try {
            if (encryptOpt != null) {
                //FIXME: this needs to be from command line input, not assumed
                //Encryptor encryptor = new Encryptor("configs/testPublicKey");
                //encryptData = MAPPER.writeValueAsString(encryptor.encrypt(valueOpt));
                System.out.println("encryptData :::" + encryptData);
            }
            if (decryptOpt != null) {
                Encryptor encryptor = new Encryptor("configs/testPublicKey", privateKeyPath);
                Encrypted encrypted = MAPPER.readValue(valueOpt, Encrypted.class);
                decryptData = encryptor.decrypt(encrypted);
                System.out.println("decryptData :::" + decryptData);
            }
        } catch (Exception e) {
            e.printStackTrace();
            System.out.println("error in encryption or decryption:::" + e.getMessage());
        }
    }
}
