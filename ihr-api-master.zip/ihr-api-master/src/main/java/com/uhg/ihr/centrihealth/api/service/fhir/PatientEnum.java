package com.uhg.ihr.centrihealth.api.service.fhir;

import java.util.Arrays;
import java.util.Set;
import java.util.stream.Collectors;

public enum PatientEnum {

    PATIENT("Patient");

    public static final Set<String> ENUM_VALUES = Arrays.stream(PatientEnum.values())
            .map(PatientEnum::getValue)
            .collect(Collectors.toSet());

    private String value;

    PatientEnum(String value) {
        this.value = value;
    }

    public String getValue() {
        return value;
    }
}
