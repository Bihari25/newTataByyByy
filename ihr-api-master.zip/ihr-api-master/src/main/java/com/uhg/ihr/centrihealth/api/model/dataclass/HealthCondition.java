package com.uhg.ihr.centrihealth.api.model.dataclass;

import lombok.*;

import java.math.BigInteger;
import java.util.List;

@Data
@EqualsAndHashCode(callSuper = false)
@NoArgsConstructor
@AllArgsConstructor
public class HealthCondition extends BaseDataClass {

    private String recordKey;
    private List<String> referenceIds;
    private IhrTerm healthCondition;
    private IhrTerm status;
    private String presenceStateTerm;
    private List<Note> note;
    private String onsetPeriodStart;
    private String onsetPeriodEnd;
    private IhrTerm asserterObject;
    private String recorderId;
    private String recordedDate;
    private String clinicallyRelevantDate;
    private String conditionStartDate;
    private String lastUpdateDate;
    private List<BigInteger> relatedConditions;
    private List<Integer> relatedObservations;
    private List<BigInteger> relatedCareTeam;
    private List<String> sensitivityClasses;
    private List<String> sourceClaimIds;
    private List<String> dataSource;

    private String onsetDate;//not in used
    private DataClassEnums recordType;//not in used
    private String clinicalCourse;

    @Builder
    public HealthCondition(BigInteger objectId, String recordKey, List<String> referenceIds, IhrTerm healthCondition, IhrTerm status, String presenceStateTerm, List<Note> note, String onsetPeriodStart, String onsetPeriodEnd, IhrTerm asserterObject, String recorderId, String recordedDate, String clinicallyRelevantDate, String conditionStartDate, String lastUpdateDate, List<BigInteger> relatedConditions, List<Integer> relatedObservations, List<BigInteger> relatedCareTeam, List<String> sensitivityClasses, List<String> sourceClaimIds, List<String> dataSource, String onsetDate, DataClassEnums recordType, String clinicalCourse) {
        super(objectId);
        this.recordKey = recordKey;
        this.referenceIds = referenceIds;
        this.healthCondition = healthCondition;
        this.status = status;
        this.presenceStateTerm = presenceStateTerm;
        this.note = note;
        this.onsetPeriodStart = onsetPeriodStart;
        this.onsetPeriodEnd = onsetPeriodEnd;
        this.asserterObject = asserterObject;
        this.recorderId = recorderId;
        this.recordedDate = recordedDate;
        this.clinicallyRelevantDate = clinicallyRelevantDate;
        this.conditionStartDate = conditionStartDate;
        this.lastUpdateDate = lastUpdateDate;
        this.relatedConditions = relatedConditions;
        this.relatedObservations = relatedObservations;
        this.relatedCareTeam = relatedCareTeam;
        this.sensitivityClasses = sensitivityClasses;
        this.sourceClaimIds = sourceClaimIds;
        this.dataSource = dataSource;
        this.onsetDate = onsetDate;
        this.recordType = recordType;
        this.clinicalCourse = clinicalCourse;
    }
}
