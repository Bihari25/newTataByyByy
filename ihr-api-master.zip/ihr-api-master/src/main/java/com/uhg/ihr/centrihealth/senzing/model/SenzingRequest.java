package com.uhg.ihr.centrihealth.senzing.model;

import com.fasterxml.jackson.annotation.JsonAutoDetect;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.google.common.collect.ImmutableList;
import com.google.common.collect.ImmutableMap;
import com.uhg.ihr.centrihealth.api.exception.IhrBadRequestException;
import com.uhg.ihr.centrihealth.api.model.Big5;
import com.uhg.ihr.centrihealth.api.model.Id;
import com.uhg.ihr.centrihealth.api.model.IdType;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * SenzingRequest class used as request contract to consume senzing api.
 *
 * @author ihr extract engineering team.
 * copyright (C) All rights reserved UHG
 */
@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
@JsonAutoDetect(fieldVisibility = JsonAutoDetect.Visibility.ANY)
@JsonInclude(JsonInclude.Include.NON_NULL)
public class SenzingRequest {

    public static final String PADDED_ID_KEY = "paddedId";
    public static final String UNPADDED_ID_KEY = "unpaddedId";

    @JsonProperty("name_first")
    private String nameFirst;

    @JsonProperty("name_last")
    private String nameLast;

    @JsonProperty("date_of_birth")
    private String dateOfBirth;

    @JsonProperty("hcid")
    private String hcId;

    @JsonProperty("uhcins_member_id")
    private String memberId;

    @JsonProperty("alt_member_id")
    private String altMemberId;

    @JsonProperty("ssn_number")
    private String ssnNumber;

    @JsonProperty("medicare_benf_id")
    private String medicareBenfId;

    @JsonProperty("subscriber_id")
    private String subscriberId;

    @JsonProperty("subscriber_id_pad")
    private String subscriberIdPad;

    @JsonProperty("search_id")
    private String searchId;

    @JsonProperty("IDENTIFIERS")
    private List<Map<String, String>> identifiers;

    @Slf4j
    public static class SenzingRequestBuilder {
        String hcId;
        String memberId;
        String altMemberId;
        String ssnNumber;
        String medicareBenfId;
        String subscriberId;
        private String searchId;
        private List<Map<String, String>> identifiers;

        public SenzingRequestBuilder id(Map<IdType, Id> map) {
            map.forEach((k, v) -> {
                switch (k) {
                    case hcId:
                        this.hcId = v.getId();
                        break;
                    case searchId:
                        Map<String, String> paddedIds = computePaddedIds(v.getId());
                        this.identifiers = ImmutableList.of(
                                ImmutableMap.of("SEARCH_ID", paddedIds.get(PADDED_ID_KEY)),
                                ImmutableMap.of("SEARCH_ID", paddedIds.get(UNPADDED_ID_KEY))
                        );
                        break;
                    case memberId:
                        this.memberId = v.getId();
                        this.altMemberId = v.getId();
                        break;
                    case SSN:
                        this.ssnNumber = v.getId();
                        break;
                    case MBI:
                        this.medicareBenfId = v.getId();
                        break;
                    case subscriberId:
                        Map<String, String> computedSubscriberIds = computePaddedIds(v.getId());
                        this.subscriberId = computedSubscriberIds.get(UNPADDED_ID_KEY);
                        this.subscriberIdPad = computedSubscriberIds.get(PADDED_ID_KEY);
                        break;
                    default:
                        log.warn("idType {} does not match hcId, memberId, SSN, MBI, subscriberId", k);
                }
            });
            return this;
        }

        /**
         * Method to compute and padd subscriber id based on search id.
         */
        public Map<String, String> computePaddedIds(String searchId) {
            String subscriberId;
            String subscriberPadId;

            // Validate is search id value  starting with zero or not.
            boolean isStartsWithZero = StringUtils.startsWith(searchId, "0");

            // Compute and populate with subscriber id's based search id is starting with zero or not.
            if (isStartsWithZero) {
                subscriberId = StringUtils.stripStart(searchId, "0");
                subscriberPadId = searchId;
            } else {
                String computedSubscriberId = StringUtils.isNotBlank(searchId) ? StringUtils.leftPad(searchId, 11, "0") : searchId;
                subscriberId = searchId;
                subscriberPadId = computedSubscriberId;
            }

            // Hold the computed subscriber ids results
            return ImmutableMap.of(UNPADDED_ID_KEY, subscriberId, PADDED_ID_KEY, subscriberPadId);
        }
    }

    public static SenzingRequest buildSenzingRequest(Big5 big5) {

        Map<IdType, Id> map = new HashMap<>();

        //add the legacy ids to the map from searchId and searchIdType
        if (big5.getIdType() == null || big5.getIdType() == IdType.searchId) {
            addSearchId(map, Id.builder().idType(big5.getIdType()).id(big5.getSearchId()).build());
        } else {
            map.put(big5.getIdType(), Id.builder().idType(big5.getIdType()).id(big5.getSearchId()).build());
        }

        //add the new ids from the ids[] array
        if (big5.getIds() != null) {
            big5.getIds().forEach(id -> {
                if (IdType.searchId == id.getIdType()) {
                    addSearchId(map, id);
                } else {
                    Id existingId = map.putIfAbsent(id.getIdType(), id);
                    if (existingId != null) {
                        throw new IhrBadRequestException("Duplicate IdType Error of Type " + id.getIdType());
                    }
                }
            });
        }
        return SenzingRequest.builder()
                .nameFirst(big5.getFirstName())
                .nameLast(big5.getLastName())
                .dateOfBirth(big5.getDateOfBirth())
                .id(map)
                .build();
    }

    private static void addSearchId(Map<IdType, Id> map, Id id) {
        Id existingId = map.putIfAbsent(IdType.searchId, id);
        if (existingId != null) {
            throw new IhrBadRequestException("Error adding searchId ");
        }

    }
}