package com.uhg.ihr.centrihealth.api.model.dataclass;

import lombok.Builder;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

import java.math.BigInteger;
import java.util.List;

@Data
@EqualsAndHashCode(callSuper = false)
@NoArgsConstructor
public class HealthDevice extends BaseDataClass {
    private String recordType;
    private String recordKey;
    private String medicalDeviceDate;
    private IhrTerm medicalDevice;
    private IhrTerm medicalDeviceStatus;
    private String lastDispenseDate;
    private Supplier supplier;
    private List<BigInteger> relatedCareTeam;
    private String presenceStateTerm;
    private List<String> dataSource;
    private String clinicallyRelevantDate;
    private List<String> referenceIds;
    private String lastUpdateDate;
    private List<String> sensitivityClasses;
    private List<Note> note;

    @Builder
    public HealthDevice(BigInteger objectId, String recordType, String recordKey, String medicalDeviceDate, IhrTerm medicalDevice, IhrTerm medicalDeviceStatus, String lastDispenseDate, Supplier supplier, List<BigInteger> relatedCareTeam, String presenceStateTerm, List<String> dataSource, String clinicallyRelevantDate, List<String> referenceIds, String lastUpdateDate, List<String> sensitivityClasses, List<Note> note) {
        super(objectId);
        this.recordType = recordType;
        this.recordKey = recordKey;
        this.medicalDeviceDate = medicalDeviceDate;
        this.medicalDevice = medicalDevice;
        this.medicalDeviceStatus = medicalDeviceStatus;
        this.lastDispenseDate = lastDispenseDate;
        this.supplier = supplier;
        this.relatedCareTeam = relatedCareTeam;
        this.presenceStateTerm = presenceStateTerm;
        this.dataSource = dataSource;
        this.clinicallyRelevantDate = clinicallyRelevantDate;
        this.referenceIds = referenceIds;
        this.lastUpdateDate = lastUpdateDate;
        this.sensitivityClasses = sensitivityClasses;
        this.note = note;
    }
}
