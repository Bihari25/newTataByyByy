package com.uhg.ihr.centrihealth.api.model.dataclass;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
public class DataClass {
    private List<AdverseReaction> adverseReactions;
    private List<HealthCondition> conditions;
    private List<HealthDevice> healthDevices;
    private List<CareGiver> careGivers;
    private List<IhrCareTeam> careTeam;
    private List<HealthMedication> medications;
    private List<HealthObservations> healthObservations;
    private List<HealthStatus> healthStatuses;
    private List<Immunizations> immunizations;
    private List<ProcedureHistory> procedureHistory;
    private List<ServiceProviders> serviceProviders;
    private List<VisitHistory> visitHistory;

}
