package com.uhg.ihr.centrihealth.api.model.dataclass;

import lombok.Builder;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

import java.math.BigInteger;
import java.util.List;

@Data
@EqualsAndHashCode(callSuper = false)
@NoArgsConstructor
public class HealthStatus extends BaseDataClass {
    private String recordType;
    private IhrTermWithId concept;
    private IhrTermWithId classification;
    private String clinicallyRelevantDate;
    private String expectedAchievement;
    private String startDate;
    private String dueDate;
    private String lastUpdateDate;
    private IhrTermWithId presenceState;
    private Evaluation evaluation;
    private List<String> sensitivityClasses;
    private List<BigInteger> relatedConditions;
    private List<String> dataSource;
    private String recordKey;
    private List<String> referenceIds;

    @Builder
    public HealthStatus(BigInteger objectId, String recordType, IhrTermWithId concept, IhrTermWithId classification, String clinicallyRelevantDate, String expectedAchievement, String startDate, String dueDate, String lastUpdateDate, IhrTermWithId presenceState, Evaluation evaluation, List<String> sensitivityClasses, List<BigInteger> relatedConditions, List<String> dataSource, String recordKey, List<String> referenceIds) {
        super(objectId);
        this.recordType = recordType;
        this.concept = concept;
        this.classification = classification;
        this.clinicallyRelevantDate = clinicallyRelevantDate;
        this.expectedAchievement = expectedAchievement;
        this.startDate = startDate;
        this.dueDate = dueDate;
        this.lastUpdateDate = lastUpdateDate;
        this.presenceState = presenceState;
        this.evaluation = evaluation;
        this.sensitivityClasses = sensitivityClasses;
        this.relatedConditions = relatedConditions;
        this.dataSource = dataSource;
        this.recordKey = recordKey;
        this.referenceIds = referenceIds;
    }
}
