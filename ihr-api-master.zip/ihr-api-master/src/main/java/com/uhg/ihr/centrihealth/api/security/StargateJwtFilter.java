package com.uhg.ihr.centrihealth.api.security;

import com.auth0.jwt.JWT;
import com.auth0.jwt.algorithms.Algorithm;
import com.auth0.jwt.exceptions.JWTVerificationException;
import com.google.common.collect.ImmutableSet;
import com.uhg.ihr.centrihealth.api.util.AppUtils;
import io.micronaut.context.annotation.Context;
import io.micronaut.context.annotation.Property;
import io.micronaut.context.annotation.Requires;
import io.micronaut.core.async.publisher.Publishers;
import io.micronaut.core.util.StringUtils;
import io.micronaut.http.HttpRequest;
import io.micronaut.http.MutableHttpResponse;
import io.micronaut.http.annotation.Filter;
import io.micronaut.http.filter.OncePerRequestHttpServerFilter;
import io.micronaut.http.filter.ServerFilterChain;
import io.micronaut.security.authentication.AuthenticationException;
import lombok.Getter;
import lombok.extern.slf4j.Slf4j;
import org.reactivestreams.Publisher;

import javax.inject.Singleton;
import javax.net.ssl.TrustManagerFactory;
import java.io.ByteArrayInputStream;
import java.io.InputStream;
import java.nio.charset.StandardCharsets;
import java.security.KeyStore;
import java.security.cert.CertificateException;
import java.util.Set;

import static io.micronaut.management.endpoint.EndpointDefaultConfiguration.PATH;

@Slf4j
@Singleton
@Context
@Filter("${" + PATH + ":/}**")
@Requires(property = "micronaut.security.stargate.enabled", notEquals = StringUtils.FALSE)
public class StargateJwtFilter extends OncePerRequestHttpServerFilter {
    private static final String TRUSTSTORE_PATH = "stargate-truststore.jks";
    private static final Set<String> ENVS = ImmutableSet.of("dev", "perf", "stage", "test");
    static final String MAGIC_TOKEN = "eyJhbGciOiJSUzUxMiJ9.eyJyb2xlIjoidXNlciIsImNyZWF0ZWQiOjE1MjI4NDk5OTE3OTcsInVzZXJuYW1lIjoiY2xvdWRzZGsifQ.dzfwWRugsnhPHB0RNT9lZHnX7gvNfGks_ivTc_dQ6-ejM6B1-Chx3WrwBE8drdy4ZbvkVTlHkHRSu3nBZi3Aw0wmN5N7UPUI0wP2KhAHGQS4-LOXgD58ioX9ep3k6hZQqy-oJor5Q3wZS8HJKMMY8izIROtJ5z-z5Y2RRw3ONnQLL5JR40hF9d5mFKA8Y1giEP32qg259MVbdkHNkI0ceq8hrXJ7w_OD4-JPteNhM9EeyNOmzjrKSEG-tkYrWI7g5xgvgMuO8iHFym4WhkDT6FNfcK2xs8QfCbJCZqV28xSIjbrm0El0L7kRzJbsKBxQ7FNJ35iaX18DpQMpu6usUQ";
    private static final String JWT_TOKEN = "JWT";
    private static final String PASWD = "StargateTrust";
    private static final Set<String> HEALTH_ENDPOINTS = ImmutableSet.of("/health", "/info", "/prometheus", "/status");

    private final boolean lowerEnv;
    private final boolean authIntranetJWT;
    private final String intranetSecret;

    @Getter
    private static int leeway = 0;

    private final TrustManagerFactory trustManagerFactory;

    public StargateJwtFilter(@Property(name = "micronaut.security.stargate.leeway") final Integer leeway,
                             @Property(name = "micronaut.application.environment") final String environment,
                             @Property(name = "micronaut.security.intranet.enabled") final boolean authIntranetJWT,
                             @Property(name = "micronaut.security.intranet.secret") final String intranetSecret) {
        lowerEnv = ENVS.contains(environment);
        log.info("found '{}' for the ENVIRONMENT environment variable. magic token is allowed: {}", environment, lowerEnv);
        if (!intranetSecret.matches("TBD") && !intranetSecret.isBlank()) {
            this.intranetSecret = intranetSecret;
            this.authIntranetJWT = authIntranetJWT;
        } else {
            this.authIntranetJWT = false;
            this.intranetSecret = "";
        }

        int inputLeeway = leeway == null || leeway < 0 ? 1 : leeway; //we want leeway to be positive
        StargateJwtFilter.leeway = Math.min(inputLeeway, 120); // and less than 120s

        try (InputStream is = AppUtils.readResourceAsStream(TRUSTSTORE_PATH)) {
            trustManagerFactory = TrustManagerFactory.getInstance(TrustManagerFactory.getDefaultAlgorithm());
            KeyStore ks = KeyStore.getInstance(KeyStore.getDefaultType());
            ks.load(is, PASWD.toCharArray());
            trustManagerFactory.init(ks);
            log.info("successfully initialized the StargateJwtFilter with leeway of {} seconds", StargateJwtFilter.leeway);
        } catch (Exception e) {
            throw new RuntimeException("unable to initialize the StargateJwtFilter", e);
        }
    }

    @Override
    protected Publisher<MutableHttpResponse<?>> doFilterOnce(HttpRequest<?> request, ServerFilterChain chain) {
        try {
            // allow /info, /health, /prometheus
            if (HEALTH_ENDPOINTS.contains(request.getPath())) {
                return chain.proceed(request);
            }

            String stargateJwt = request.getHeaders().get(JWT_TOKEN);
            if (stargateJwt == null || stargateJwt.isEmpty()) {
                throw new StargateJwtException(JWT_TOKEN + " header not found.");
            }
            stargateJwt = stargateJwt.replace("Bearer ", "");
            if (stargateJwt.isEmpty() || stargateJwt.equals("null")) {
                throw new StargateJwtException(JWT_TOKEN + " token not found.");
            }

            if (!MAGIC_TOKEN.equals(stargateJwt) || !lowerEnv) {
                try {
                    StargateJwtValidator.validate(stargateJwt, new ByteArrayInputStream(request.getBody().toString().getBytes(StandardCharsets.UTF_8)), trustManagerFactory, leeway);
                } catch (StargateJwtException | CertificateException e) {
                    if (authIntranetJWT) {
                        try {
                            JWT.require(Algorithm.HMAC256(intranetSecret)).build().verify(stargateJwt);
                        } catch (JWTVerificationException i) {
                            throw e;
                        }
                    } else {
                        throw e;
                    }
                }
            }
        } catch (Exception e) {
            if (e instanceof StargateJwtException) {
                log.info("jwt token validation failed: {}", e.getMessage());
            } else {
                log.info("error processing jwt: {}", e.getMessage());
            }
            return Publishers.just(new AuthenticationException(e.getMessage()));
        }

        return chain.proceed(request);
    }
}