package com.uhg.ihr.centrihealth.api.controller;

import ca.uhn.fhir.context.FhirContext;
import com.fasterxml.jackson.databind.JsonNode;
import com.google.common.collect.ImmutableSet;
import com.uhg.ihr.centrihealth.api.configuration.VersionConfiguration;
import com.uhg.ihr.centrihealth.api.exception.IhrGoneException;
import com.uhg.ihr.centrihealth.api.exception.IhrNotAcceptableException;
import com.uhg.ihr.centrihealth.api.exception.IhrNotFoundException;
import com.uhg.ihr.centrihealth.api.exception.IhrServerErrorException;
import com.uhg.ihr.centrihealth.api.filter.DataContentFilterBuilder;
import com.uhg.ihr.centrihealth.api.filter.DataFilter;
import com.uhg.ihr.centrihealth.api.logging.LoggingFilter;
import com.uhg.ihr.centrihealth.api.model.Big5;
import com.uhg.ihr.centrihealth.api.model.IhrApiRequest;
import com.uhg.ihr.centrihealth.api.model.IhrApiResponse;
import com.uhg.ihr.centrihealth.api.model.MongoDataRequest;
import com.uhg.ihr.centrihealth.api.security.SenzingTokenHelper;
import com.uhg.ihr.centrihealth.api.service.FhirService;
import com.uhg.ihr.centrihealth.api.service.MongoDataService;
import com.uhg.ihr.centrihealth.api.service.SenzingService;
import com.uhg.ihr.centrihealth.api.util.AppUtils;
import com.uhg.ihr.centrihealth.senzing.model.SenzingProperties;
import com.uhg.ihr.centrihealth.senzing.model.SenzingRequest;
import io.micronaut.context.annotation.Context;
import io.micronaut.context.annotation.Property;
import io.micronaut.http.HttpHeaders;
import io.micronaut.http.HttpRequest;
import io.micronaut.http.HttpResponse;
import io.micronaut.http.MediaType;
import io.micronaut.http.MutableHttpResponse;
import io.micronaut.http.annotation.Controller;
import io.micronaut.http.annotation.Header;
import io.micronaut.http.annotation.Post;
import io.micronaut.http.annotation.Put;
import io.micronaut.http.client.exceptions.HttpClientResponseException;
import io.micronaut.validation.Validated;
import io.reactivex.Maybe;
import io.reactivex.MaybeSource;
import lombok.extern.slf4j.Slf4j;
import org.hl7.fhir.r4.model.Bundle;

import javax.inject.Inject;
import javax.validation.Valid;
import java.util.Date;
import java.util.List;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.TimeoutException;
import java.util.regex.Matcher;
import java.util.regex.Pattern;


@Slf4j
@Validated
@Context
@Controller("/individual-health-records/v1.0")
public class ApiController {
    public static final String MONGO = "mongo";
    public static final long REQUEST_TIMEOUT_MS = 8500L;
    private static final String CONTENT_MEDIA_TYPE = MediaType.APPLICATION_JSON + ";charset=utf-8";
    private static final int CURRENT = 1;
    private static final Pattern PATTERN = Pattern.compile("^application\\/vnd\\.uhg\\.v([0-9]+)\\+json$");
    private static final String RESPONSE_HEADER = "X-UHG-Media-Type";
    private static final String RESPONSE_HEADER_PREFIX = "uhg.v";
    private static final String SENZING = "senzing";
    private static final String SENZING_SECOND = "senzing-second";
    private static final String REQUESTEE_IHRID = "requesteeIhrId";
    private static final String ACCEPT_FHIR = "application/fhir+json";
    private static final FhirContext FHIR_CONTEXT = FhirContext.forR4();
    private static final String REQUESTOR_IHRID = "requestorIhrId";
    public static final String ACCEPT_FHIR_V2 = "application/fhir2+json";

    private final String apiVersion;
    private final String dataVersion;
    private final String schemaVersion;
    private final SenzingProperties senzingProperties;
    private final String environment;

    @Inject
    private SenzingService senzingService;
    @Inject
    private MongoDataService mongoDataService;

    public ApiController(final SenzingProperties senzingProperties, final VersionConfiguration versionConfig, @Property(name = "micronaut.application.environment") final String environment) {

        this.senzingProperties = senzingProperties;
        log.info("initialized the API controller with SENZING_URL: {}, SENZING_SUBJECT: {}, " +
                        "SENZING_SECOND_ENABLED: {}, B50_SENZING_URL_SECOND: {}",
                senzingProperties.getSenzingUrl(), senzingProperties.getSubject(),
                senzingProperties.isSecondEnabled(), senzingProperties.getSenzingUrlSecond());

        // initialize api, data, schema version
        apiVersion = AppUtils.getBuildVersionFromManifestInfo();
        dataVersion = versionConfig.getDataVersion();
        schemaVersion = versionConfig.getSchemaVersion();
        this.environment = environment;

        if ("FIXME".equals(senzingProperties.getSecretKey())) {
            log.error("senzing secret key is not set and senzing is enabled!");
        }
    }

    private static boolean isFhir(final HttpHeaders headers) {
        for (MediaType mediaType : headers.accept()) {
            if (ACCEPT_FHIR.equals(mediaType.toString()) || ACCEPT_FHIR_V2.equals(mediaType.toString())) {
                return true;
            }
        }
        return false;
    }

    public static int getVersionFromHeader(final HttpHeaders headers) {
        int version = -1;
        if (headers.accept().contains(MediaType.ALL_TYPE) || headers.accept().contains(MediaType.of(MediaType.APPLICATION_JSON))) {
            version = CURRENT;
        }
        for (MediaType mediaType : headers.accept()) {
            if (ACCEPT_FHIR.equals(mediaType.toString()) || ACCEPT_FHIR_V2.equals(mediaType.toString())) {
                return 2;
            }
            Matcher matcher = PATTERN.matcher(mediaType.toString());
            if (matcher.matches()) {
                int parsed = Integer.parseInt(matcher.group(1));
                if (parsed > version) { //if there are multiple versions in Accept, pick the highest one
                    version = parsed;
                }
            }
        }
        return version;
    }

    private static String getResponseVersion(IhrApiResponse resp) {
        return resp.getSchemaVersion() == null ? CURRENT + ".0.0" : resp.getSchemaVersion();
    }

    private static MaybeSource handleError(Throwable e) {
        return handleErrorMessage(e, null);
    }

    private static MaybeSource handleErrorMessage(Throwable e, String info) {
        if (e instanceof HttpClientResponseException || e instanceof IhrServerErrorException) {
            return Maybe.error(e);
        }
        if (info != null) {
            return Maybe.error(new IhrNotFoundException(info + e.getMessage()));
        }

        return Maybe.error(new IhrNotFoundException(e.getMessage()));
    }

    @Post(uri = "/read", produces = CONTENT_MEDIA_TYPE, consumes = CONTENT_MEDIA_TYPE)
    public Maybe<MutableHttpResponse<?>> read(final HttpRequest<IhrApiRequest> request,
                                              final @Header("optum-cid-ext") String correlationId,
                                              final @Valid IhrApiRequest apiDto) {

        // Get the version number, consumer user name, collection from request headers.
        int version = getVersionFromHeader(request.getHeaders());

        if (version < 2) {
            throw new IhrGoneException("This version is no longer supported");
        }

        if (version > 2) {
            throw new IhrNotAcceptableException("cannot produce format " + request.getHeaders().accept());
        }

        return apiResponse(request, correlationId, apiDto)
                .timeout(REQUEST_TIMEOUT_MS, TimeUnit.MILLISECONDS)
                .doOnError(e -> {
                    if (e instanceof TimeoutException) {
                        LoggingFilter.addAttribute(request, "overallTimeout", true);
                    }
                })
                .map(resp -> buildResponse(resp, request,request.getHeaders()));
    }

    private MutableHttpResponse<?> buildResponse(final IhrApiResponse payload, final HttpRequest<IhrApiRequest> request,final HttpHeaders header) {
        if (isFhir(request.getHeaders())) {
            Bundle bundle = FhirService.fhirConvert(payload,header);
            return HttpResponse.ok(FHIR_CONTEXT.newJsonParser().encodeResourceToString(bundle))
                    .header(RESPONSE_HEADER, "application/fhir+json;charset=UTF-8")
                    .header(HttpHeaders.CONTENT_TYPE, "application/fhir+json;charset=UTF-8");
        }

        return HttpResponse.ok(payload)
                .header(RESPONSE_HEADER, RESPONSE_HEADER_PREFIX + getResponseVersion(payload));
    }

    private Maybe<IhrApiResponse> apiResponse(final HttpRequest<IhrApiRequest> request,
                                              final @Header("optum-cid-ext") String correlationId, final @Valid IhrApiRequest apiDto) {

        // Build data content filters based on version
        DataContentFilterBuilder dataContentFilterBuilder = new DataContentFilterBuilder(apiDto.getDataFilters());
        List<DataFilter> dataFilters = dataContentFilterBuilder.getDataFilters();

        if (apiDto.getRequestor() == null || apiDto.getRequestor().equals(apiDto.getMbrId().getBig5())) {
            return getIhrIdAndResponse(request, apiDto, apiDto.getMbrId().getBig5(), dataFilters, correlationId);
        } else {
            return getIhrIdAndLog(request, apiDto, correlationId)
                    .onErrorResumeNext(ApiController::handleError)
                    .flatMap(s -> getIhrIdAndResponse(request, apiDto, apiDto.getMbrId().getBig5(), dataFilters, correlationId));
        }
    }

    private Maybe<String> getIhrIdAndLog(final HttpRequest<IhrApiRequest> request, IhrApiRequest apiDto, final String correlationId) {
        return getSenzingMatch(request, correlationId, apiDto.getRequestor())
                .flatMap(ihrId -> {
                    LoggingFilter.addAttribute(request, REQUESTOR_IHRID, ihrId);
                    return Maybe.just(ihrId);
                })
                .onErrorResumeNext(e -> {
                    return handleErrorMessage(e, "unable to match requestor: ");
                });
    }

    private Maybe<IhrApiResponse> getIhrIdAndResponse(final HttpRequest<IhrApiRequest> request, IhrApiRequest apiDto,
                                                      Big5 big5, List<DataFilter> dataFilters, final String correlationId) {

        return getSenzingMatch(request, correlationId, big5)
                .flatMap(ihrId -> {
                    LoggingFilter.addAttribute(request, REQUESTEE_IHRID, ihrId);
                    return getPayload(request, ihrId, apiDto, dataFilters)
                            .map(json -> buildResponse(apiDto, json));
                })
                .onErrorResumeNext(e -> {
                    return handleErrorMessage(e, "unable to match user or requestee: ");
                });
    }

    private Maybe<String> getSenzingMatch(final HttpRequest<IhrApiRequest> request, final String correlationId, final Big5 big5) {
        SenzingRequest senzingRequest = SenzingRequest.buildSenzingRequest(big5);
        String senzingToken = SenzingTokenHelper.generateToken(senzingProperties.getSubject(), null, senzingProperties.getAudience(),
                new Date(), senzingProperties.getDuration(), senzingProperties.getRoles(), senzingProperties.getSecretKey());

        return senzingService.b50filterIhrId(request, senzingToken, senzingRequest, correlationId)
                .doOnSubscribe(sub -> LoggingFilter.logStart(request, SENZING))
                .doOnSuccess(ihrIdResponse -> LoggingFilter.logSuccess(request, SENZING))
                .doOnError(ex -> LoggingFilter.logFail(request, SENZING, ex.getMessage()))
                .onErrorResumeNext(ex -> {
                    if (senzingProperties.isSecondEnabled()) {
                        return getSecondSenzingMatch(request, correlationId, senzingRequest);
                    } else {
                        return Maybe.error(ex);
                    }
                })
                .onErrorResumeNext(ApiController::handleError);
    }

    private Maybe<String> getSecondSenzingMatch(final HttpRequest<IhrApiRequest> request, final String correlationId,
                                                SenzingRequest senzingRequest) {
        String senzingTokenSecond = SenzingTokenHelper.generateToken(senzingProperties.getSubject(), null,
                senzingProperties.getAudience(), new Date(), senzingProperties.getDuration(), senzingProperties.getRoles(),
                senzingProperties.getSecretKeySecond());
        return senzingService.b50filterIhrIdSecond(request, senzingTokenSecond, senzingRequest, correlationId)
                .doOnSubscribe(sub -> LoggingFilter.logStart(request, SENZING_SECOND))
                .doOnSuccess(ihrIdResponse -> LoggingFilter.logSuccess(request, SENZING_SECOND))
                .doOnError(ex -> LoggingFilter.logFail(request, SENZING_SECOND, ex.getMessage()))
                .onErrorResumeNext(ApiController::handleError);
    }

    private IhrApiResponse buildResponse(final IhrApiRequest apiDto, final JsonNode dataClasses) {

        return IhrApiResponse.builder()
                .correlationId(apiDto.getCorrelationId())
                .language(apiDto.getLanguage())
                .requestor(apiDto.getRequestor())
                .dataClasses(dataClasses == null ? null : dataClasses.get("dataClasses"))
                .apiVersion(apiVersion)
                .dataVersion(dataVersion)
                .schemaVersion(schemaVersion)
                .mbrId(apiDto.getMbrId()).build();
    }

    private Maybe<JsonNode> getPayload(final HttpRequest<?> request, final String ihrId, final IhrApiRequest apiDto, List<DataFilter> dataFilters) {

        // Build the mongo data request
        MongoDataRequest mongoDataRequest = MongoDataRequest.builder()
                .ihrId(ihrId)
                .dataClasses(apiDto.getDataClasses())
                .dataFilters(dataFilters)
                .language(apiDto.getLanguage())
                .build();

        return mongoDataService.getDataResponse(mongoDataRequest, request)
                .doOnSubscribe(sub -> LoggingFilter.logStart(request, MONGO))
                .doOnSuccess(pl -> {
                    LoggingFilter.logSuccess(request, MONGO);
                    Boolean isBasic = (Boolean) LoggingFilter.getAttribute(request, MongoDataService.BASIC_IHR);
                    if (isBasic != null && isBasic) {
                        LoggingFilter.addAttribute(request, "mongoStatus", LoggingFilter.FAILURE);
                    }
                })
                .doOnError(e -> LoggingFilter.logFail(request, MONGO, e.getMessage()));
    }

    @Put(uri = "{ihrId}/reset")
    public MutableHttpResponse<?> reset(final String ihrId) {
        log.info("reset called for ihrId {}", ihrId);
        if (!ImmutableSet.of("dev", "test", "perf").contains(environment)) {
            return HttpResponse.unauthorized();
        }

        mongoDataService.resetData(ihrId);

        return HttpResponse.ok("{ \"message\": \"reset data for actor: " + ihrId + "\"}");
    }

}