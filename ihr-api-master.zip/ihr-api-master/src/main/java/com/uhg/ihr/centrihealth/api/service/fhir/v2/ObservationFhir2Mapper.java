package com.uhg.ihr.centrihealth.api.service.fhir.v2;

import com.uhg.ihr.centrihealth.api.model.FhirResource;
import com.uhg.ihr.centrihealth.api.model.dataclass.DataClass;
import com.uhg.ihr.centrihealth.api.model.dataclass.HealthObservations;
import com.uhg.ihr.centrihealth.api.service.fhir.FhirMapper;
import com.uhg.ihr.centrihealth.api.util.AppUtils;
import io.micrometer.core.instrument.util.StringUtils;
import lombok.Value;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections.CollectionUtils;
import org.hl7.fhir.r4.model.*;

import static com.uhg.ihr.centrihealth.api.model.dataclass.Constants.*;


@Slf4j
@Value(staticConstructor = "of")
public class ObservationFhir2Mapper implements FhirMapper<HealthObservations, Observation> {

    public static final String LOINC_CODE_URL = "https://loinc.org/";

    @Override
    public void map(FhirResource fhirResource, DataClass dataClasses) {
        if (dataClasses != null && CollectionUtils.isNotEmpty(dataClasses.getHealthObservations())) {
            map(fhirResource, dataClasses.getHealthObservations());
        }
    }

    @Override
    public void map(FhirResource fhirResource, HealthObservations healthObservations) {
        Observation observation = new Observation();
        observation.setId(new IdType(createIdURI()));
        buildObservationResource(observation, fhirResource, healthObservations);
    }

    /**
     * Mapping logic for Observation fields. Comments made before mapping can be read as either
     *
     * Transcriber field (camel case) -> Observation field
     * or
     * FHIR resource -> Observation field
     *
     * @param observation        The provided Observation resource to build upon
     * @param fhirResource       The parent fhirResource
     * @param healthObservations The HealthObservation source
     */
    public void buildObservationResource(Observation observation, FhirResource fhirResource, HealthObservations healthObservations) {
        Patient patient = fhirResource.getPatient();
        Bundle bundle = fhirResource.getBundle();

        //Patient -> subject
        observation.setSubject(new Reference(patient));

        //lastUpdateDate -> meta.lastUpdated
        if (StringUtils.isNotBlank(healthObservations.getLastUpdateDate())) {
            Meta meta = getOrCreateMeta(observation);
            meta.setLastUpdated(FhirMapper.toDate(healthObservations.getLastUpdateDate()));
        }

        //sensitivityClass -> meta.security
        if (CollectionUtils.isNotEmpty(healthObservations.getSensitivityClasses())) {
            Meta meta = getOrCreateMeta(observation);
            meta.addSecurity(
                    new Coding()
                            .setCode(SECURITY_CODE)
                            .setSystem(SECURITY_SYSTEM_URL)
            );
        }

        //Procedure -> partOf
        fhirResource.addFhirResourceToDeferredMapper(observation, healthObservations);

        //recordKey -> identifier
        if (null != healthObservations.getRecordKey()) {
            observation.addIdentifier()
                    .setType(new CodeableConcept().setText(RECORD_KEY))
                    .setValue(healthObservations.getRecordKey());
        }

        //referenceIds -> identifier
        if (null != healthObservations.getReferenceIds()) {
            observation.addIdentifier()
                    .setType(new CodeableConcept().setText(REFERENCE_IDS))
                    .setValue(AppUtils.jsonEscape(healthObservations.getReferenceIds()));
        }

        //objectId -> identifier
        if (null != healthObservations.getObjectId()) {
            observation.addIdentifier()
                    .setType(new CodeableConcept().setText(INSTANCE_ID))
                    .setValue(healthObservations.getObjectId().toString());
        }

        //observation -> code
        if (null != healthObservations.getObservation()) {
            observation.setCode(
                    new CodeableConcept()
                            .setText(healthObservations.getObservation().getIhrLaymanTerm())
                            .addCoding(
                                    new Coding()
                                            .setDisplay(healthObservations.getObservation().getIhrTerm())
                                            .setSystem(healthObservations.getObservation().getSourceVocabulary())
                                            .setCode(healthObservations.getObservation().getSourceVocabularyCode())
                            )
            );

            if (StringUtils.isNotBlank(healthObservations.getObservation().getLoincCode())) {
                observation.getCode().addCoding(
                        new Coding()
                                .setSystem(LOINC_CODE_URL)
                                .setCode(healthObservations.getObservation().getLoincCode())
                );
            }
        }

        //observationValue -> valueCodeableConcept
        if (null != healthObservations.getObservationValue()) {
            observation.addComponent().getValueCodeableConcept()
                    .setText(healthObservations.getObservationValue().getIhrLaymanTerm())
                    .addCoding(
                            new Coding()
                                    .setDisplay(healthObservations.getObservationValue().getIhrTerm())
                                    .setSystem(healthObservations.getObservationValue().getSourceVocabulary())
                                    .setCode(healthObservations.getObservationValue().getSourceVocabularyCode())
                    );
        }

        //valueString -> valueString
        if (StringUtils.isNotBlank(healthObservations.getValueString())) {
            observation.setValue(new StringType(healthObservations.getValueString()));
        }

        //shortPreferredTerm -> extension
        if (null != healthObservations.getObservationUnitOfMeasure() && StringUtils.isNotBlank(healthObservations.getObservationUnitOfMeasure().getShortPreferredTerm())) {
            observation.addExtension(
                    new Extension()
                            .setUrl(VALUE_STRING_UNIT_OF_MEASURE_URL)
                            .setValue(new StringType(healthObservations.getObservationUnitOfMeasure().getShortPreferredTerm()))
            );
        }

        //observationDate -> effectiveDateTime
        if (StringUtils.isNotBlank(healthObservations.getObservationDate())) {
            observation.setEffective(toDateTimeTypeFromDate(healthObservations.getObservationDate()));
        }

        //status.IHRTerm -> status
        if (null != healthObservations.getStatus() && StringUtils.isNotBlank(healthObservations.getStatus().getIhrTerm())) {
            //TODO: ObservationV2 - Observation.status is a FHIR enum requiring a static list of IHR Terms to map from
            observation.setStatus(Observation.ObservationStatus.UNKNOWN);
        }

        //referenceRange -> referenceRange
        if (StringUtils.isNotBlank(healthObservations.getReferenceRange())) {
            observation.addReferenceRange().setText(healthObservations.getReferenceRange());
        }

        //abnormalObservation.sourceVocabularyCode -> interpretation
        if (null != healthObservations.getAbnormalObservation()) {
            observation.addInterpretation(
                    new CodeableConcept()
                            .setText(healthObservations.getAbnormalObservation().getIhrLaymanTerm())
                            .addCoding(
                                    new Coding()
                                            .setDisplay(healthObservations.getAbnormalObservation().getIhrTerm())
                                            .setSystem(healthObservations.getAbnormalObservation().getSourceVocabulary())
                                            .setCode(healthObservations.getAbnormalObservation().getSourceVocabularyCode())
                            )
            );
        }

        // add resource into bundle
        bundle.addEntry().setFullUrl(observation.getId()).setResource(observation);
    }
}
