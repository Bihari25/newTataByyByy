package com.uhg.ihr.centrihealth.api.model.dataclass;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.*;

import java.math.BigInteger;
import java.util.List;

@Data
@EqualsAndHashCode(callSuper = false)
@AllArgsConstructor
@NoArgsConstructor
public class AdverseReaction extends BaseDataClass {

    private String recordKey;
    private List<String> referenceIds;
    private IhrTerm asserterObject;
    private String recorderId;
    private String recordedDate;
    private IhrTerm adversereactiontype;
    private String allergenCategory;
    private List<IhrTerm> allergens;
    private List<Reaction> reactionsFHIR;
    private IhrTerm status;
    private String presenceStateTerm;
    private List<Note> note;
    private String onsetPeriodStart;
    private String onsetPeriodEnd;
    private String clinicallyRelevantDate;
    private String startDate;
    private List<String> sensitivityClasses;
    private List<String> dataSource;
    private String allergyIntoleranceType;

    //Kept reactions for backwards compatibility
    private String lastUpdateDate;
    //Kept reactions for backwards compatibility
    private List<Reaction> reactions;
    //Kept old onsetDate and endDate for backwards compatibility
    private String onsetDate;
    private String endDate;
    private String allergenType;
    private String allergyIntolerance;
    private String asserter;
    private DataClassEnums recordType;


    @JsonProperty("onsetPeriodStart")
    private void extractonsetPeriodStart(String onsetPeriodStart) {
        this.onsetDate = onsetPeriodStart;
        this.onsetPeriodStart = onsetPeriodStart;
    }

    @JsonProperty("onsetPeriodEnd")
    private void extractonsetPeriodEnd(String onsetPeriodEnd) {
        this.endDate = onsetPeriodEnd;
        this.onsetPeriodEnd = onsetPeriodEnd;
    }

    @Builder
    public AdverseReaction(BigInteger objectId, String recordKey, List<String> referenceIds, IhrTerm asserterObject, String recorderId, String recordedDate, IhrTerm adversereactiontype, String allergenCategory, List<IhrTerm> allergens, List<Reaction> reactionsFHIR, IhrTerm status, String presenceStateTerm, List<Note> note, String onsetPeriodStart, String onsetPeriodEnd, String clinicallyRelevantDate, String startDate, List<String> sensitivityClasses, List<String> dataSource, String allergyIntoleranceType, String lastUpdateDate, List<Reaction> reactions, String onsetDate, String endDate, String allergenType, String allergyIntolerance, String asserter, DataClassEnums recordType) {
        super(objectId);
        this.recordKey = recordKey;
        this.referenceIds = referenceIds;
        this.asserterObject = asserterObject;
        this.recorderId = recorderId;
        this.recordedDate = recordedDate;
        this.adversereactiontype = adversereactiontype;
        this.allergenCategory = allergenCategory;
        this.allergens = allergens;
        this.reactionsFHIR = reactionsFHIR;
        this.status = status;
        this.presenceStateTerm = presenceStateTerm;
        this.note = note;
        this.onsetPeriodStart = onsetPeriodStart;
        this.onsetPeriodEnd = onsetPeriodEnd;
        this.clinicallyRelevantDate = clinicallyRelevantDate;
        this.startDate = startDate;
        this.sensitivityClasses = sensitivityClasses;
        this.dataSource = dataSource;
        this.allergyIntoleranceType = allergyIntoleranceType;
        this.lastUpdateDate = lastUpdateDate;
        this.reactions = reactions;
        this.onsetDate = onsetDate;
        this.endDate = endDate;
        this.allergenType = allergenType;
        this.allergyIntolerance = allergyIntolerance;
        this.asserter = asserter;
        this.recordType = recordType;
    }
}