package com.uhg.ihr.centrihealth.api.logging;

import io.micronaut.context.annotation.Secondary;
import lombok.extern.slf4j.Slf4j;

import javax.inject.Singleton;

@Singleton
@Secondary
@Slf4j
public class KafkaLoggerStub implements KafkaLogger {

    @Override
    public void logBig5(String correlationId, String big5Encrypted) {
        log.info("Kafka Big5 Key: " + correlationId + "    Payload: " + big5Encrypted);
    }
}
