package com.uhg.ihr.centrihealth.api.service.fhir.v2;

import com.uhg.ihr.centrihealth.api.model.FhirResource;
import com.uhg.ihr.centrihealth.api.model.dataclass.Constants;
import com.uhg.ihr.centrihealth.api.model.dataclass.DataClass;
import com.uhg.ihr.centrihealth.api.model.dataclass.IhrTerm;
import com.uhg.ihr.centrihealth.api.model.dataclass.VisitHistory;
import com.uhg.ihr.centrihealth.api.service.fhir.FhirMapper;
import com.uhg.ihr.centrihealth.api.service.fhir.deferred.ConditionDeferredMapper;
import com.uhg.ihr.centrihealth.api.service.fhir.deferred.ProcedureDeferredMapper;
import com.uhg.ihr.centrihealth.api.util.AppUtils;
import io.micrometer.core.instrument.util.StringUtils;
import lombok.Value;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections.CollectionUtils;
import org.hl7.fhir.r4.model.*;
import org.hl7.fhir.r4.model.codesystems.DiagnosisRole;

import java.math.BigInteger;

@Slf4j
@Value(staticConstructor = "of")
public class EncounterFhir2Mapper implements FhirMapper<VisitHistory, Encounter> {

    @Override
    public void map(FhirResource fhirResource, DataClass dataClasses) {
        if (dataClasses != null && CollectionUtils.isNotEmpty(dataClasses.getVisitHistory())) {
            map(fhirResource, dataClasses.getVisitHistory());
        }
    }

    @Override
    public void map(FhirResource fhirResource, VisitHistory visitHistory) {
        Encounter encounter = new Encounter();
        encounter.setId(new IdType(createIdURI()));
        buildObservationResource(encounter, fhirResource, visitHistory);
    }

    /**
     * Mapping logic for Encounter fields. Comments made before mapping can be read as either
     *
     * Transcriber field (camel case) -> Encounter field
     * or
     * FHIR resource -> Encounter field
     *
     * @param encounter
     * @param fhirResource
     * @param visitHistory
     */
    public void buildObservationResource(Encounter encounter, FhirResource fhirResource, VisitHistory visitHistory) {
        Bundle bundle = fhirResource.getBundle();

        //Patient -> subject
        encounter.setSubject(new Reference(fhirResource.getPatient()));

        //recordKey -> identifier
        if (null != visitHistory.getRecordKey()) {
            encounter.addIdentifier()
                    .setValue(visitHistory.getRecordKey())
                    .setType(new CodeableConcept().setText(Constants.RECORD_KEY));
        }

        //referenceIds -> identifier
        if (CollectionUtils.isNotEmpty(visitHistory.getReferenceIds())) {
            encounter.addIdentifier()
                    .setValue(AppUtils.jsonEscape(visitHistory.getReferenceIds()))
                    .setType(new CodeableConcept().setText(Constants.REFERENCE_IDS));
        }

        //objectId -> identifier
        if (null != visitHistory.getObjectId()) {
            encounter.addIdentifier()
                    .setValue(visitHistory.getObjectId().toString())
                    .setType(new CodeableConcept().setText(Constants.INSTANCE_ID));
        }

        //sensitivityClasses -> meta.security
        if (CollectionUtils.isNotEmpty(visitHistory.getSensitivityClasses())) {
            encounter.getMeta().addSecurity()
                    .setCode(Constants.SECURITY_CODE)
                    .setSystem(Constants.SECURITY_SYSTEM_URL);
        }

        //visit -> type
        if (null != visitHistory.getVisit()) {
            CodeableConcept concept = new CodeableConcept()
                    .setText(visitHistory.getVisit().getIhrLaymanTerm())
                    .addCoding(
                            new Coding()
                                    .setDisplay(visitHistory.getVisit().getIhrTerm())
                                    .setSystem(visitHistory.getVisit().getSourceVocabulary())
                                    .setCode(visitHistory.getVisit().getSourceVocabularyCode())
                    );

            if (StringUtils.isNotBlank(visitHistory.getVisit().getCpthcpcsCode())) {
                concept.addCoding(
                        new Coding()
                                .setCode(visitHistory.getVisit().getCpthcpcsCode())
                                .setSystem(Constants.CPTHCPCS_CODE_URL)
                );
            }
            encounter.addType(concept);
        }

        //visitType -> class.display
        if (StringUtils.isNotBlank(visitHistory.getVisitType())) {
            encounter.setClass_(new Coding().setDisplay(visitHistory.getVisitType()));
        }

        //status -> status.display
        if (StringUtils.isNotBlank(visitHistory.getStatus())) {
            encounter.setStatus(Encounter.EncounterStatus.FINISHED);
        }

        //presenceStateTerm -> extension
        if (StringUtils.isNotBlank(visitHistory.getPresenceStateTerm())) {
            encounter.addExtension(Constants.PRESENCE_STATE_TERM_V2_URL, new StringType(visitHistory.getPresenceStateTerm()));
        }

        //admitDate and dischargeDate
        if (StringUtils.isNotBlank(visitHistory.getAdmitDate()) || StringUtils.isNotBlank(visitHistory.getDischargeDate())) {
            Period period = new Period();
            //admitDate -> period.start
            if (StringUtils.isNotBlank(visitHistory.getAdmitDate())) {
                period.setStartElement(toDateTimeTypeFromDate(visitHistory.getAdmitDate()));
            }
            //dischargeDate -> period.end
            if (StringUtils.isNotBlank(visitHistory.getDischargeDate())) {
                period.setEndElement(toDateTimeTypeFromDate(visitHistory.getDischargeDate()));
            }
            encounter.setPeriod(period);
        }

        //admittingDiagnosis -> diagnosis
        if (CollectionUtils.isNotEmpty(visitHistory.getAdmittingDiagnosis())) {
            for (IhrTerm term : visitHistory.getAdmittingDiagnosis()) {
                CodeableConcept codeableConcept = new CodeableConcept()
                        .setText(term.getIhrLaymanTerm())
                        .addCoding(new Coding()
                                .setDisplay(term.getIhrTerm())
                                .setCode(term.getSourceVocabularyCode())
                                .setSystem(term.getSourceVocabulary()));

                Condition condition = getOrCreateCondition(fhirResource, codeableConcept);
                encounter.addDiagnosis()
                        .setUse(
                                new CodeableConcept()
                                        .setText(DiagnosisRole.AD.getDisplay())
                                        .addCoding(
                                                new Coding()
                                                        .setCode(DiagnosisRole.AD.toCode())
                                                        .setSystem(DiagnosisRole.AD.getSystem())
                                                        .setDisplay(DiagnosisRole.AD.getDisplay())
                                        )
                        )
                        .setCondition(new Reference(condition));
            }
        }

        //dischargeDiagnosis -> diagnosis
        if (CollectionUtils.isNotEmpty(visitHistory.getDischargeDiagnosis())) {
            for (IhrTerm term : visitHistory.getDischargeDiagnosis()) {
                CodeableConcept codeableConcept = new CodeableConcept()
                        .setText(term.getIhrLaymanTerm())
                        .addCoding(new Coding()
                                .setDisplay(term.getIhrTerm())
                                .setCode(term.getSourceVocabularyCode())
                                .setSystem(term.getSourceVocabulary()));

                Condition condition = getOrCreateCondition(fhirResource, codeableConcept);
                encounter.addDiagnosis()
                        .setUse(
                                new CodeableConcept()
                                        .setText(DiagnosisRole.DD.getDisplay())
                                        .addCoding(
                                                new Coding()
                                                        .setSystem(DiagnosisRole.DD.getSystem())
                                                        .setCode(DiagnosisRole.DD.toCode())
                                                        .setDisplay(DiagnosisRole.DD.getDisplay())
                                        )
                        )
                        .setCondition(new Reference(condition));
            }
        }

        //admitSource -> hospitalization.admitSource
        if (StringUtils.isNotBlank(visitHistory.getAdmitSource())) {
            Encounter.EncounterHospitalizationComponent hospitalization = getOrCreateHospitalization(encounter);
            hospitalization.setAdmitSource(new CodeableConcept().setText(visitHistory.getAdmitSource()));
        }

        //dischargeDisposition -> hospitalization.dischargeDisposition
        if (null != visitHistory.getDischargeDisposition()) {
            Encounter.EncounterHospitalizationComponent hospitalization = getOrCreateHospitalization(encounter);
            hospitalization
                    .setDischargeDisposition(
                            new CodeableConcept()
                                    .setText(visitHistory.getDischargeDisposition().getIhrLaymanTerm())
                                    .addCoding(
                                            new Coding()
                                                    .setDisplay(visitHistory.getDischargeDisposition().getIhrTerm())
                                                    .setSystem(visitHistory.getDischargeDisposition().getSourceVocabulary())
                                                    .setCode(visitHistory.getDischargeDisposition().getSourceVocabularyCode())
                                    )
                    );
        }

        //clinicallyRelevantDate -> extension
        if (StringUtils.isNotBlank(visitHistory.getClinicallyRelevantDate())) {
            encounter.addExtension(Constants.CLINICALLY_RELEVANT_DATE_V2_URL, this.toDateTimeTypeFromDate(visitHistory.getClinicallyRelevantDate()));
        }

        //lastUpdateDate -> meta.lastUpdated
        if (StringUtils.isNotBlank(visitHistory.getLastUpdateDate())) {
            Meta meta = getOrCreateMeta(encounter);
            meta.setLastUpdatedElement(toInstantTypeFromDate(visitHistory.getLastUpdateDate()));
        }

        //relatedConditions -> diagnosis
        if (CollectionUtils.isNotEmpty(visitHistory.getRelatedConditions())) {
            for (BigInteger relatedCondition : visitHistory.getRelatedConditions()) {
                fhirResource.addDeferredFhirMapper(
                        relatedCondition,
                        new ConditionDeferredMapper(condition -> encounter.addDiagnosis().setCondition(new Reference(condition)))
                );
            }
        }

        //relatedProcedures -> diagnosis
        if (CollectionUtils.isNotEmpty(visitHistory.getRelatedProcedures())) {
            for (BigInteger relatedProcedure : visitHistory.getRelatedProcedures()) {
                fhirResource.addDeferredFhirMapper(
                        relatedProcedure,
                        new ProcedureDeferredMapper(procedure -> encounter.addDiagnosis().setCondition(new Reference(procedure)))
                );
            }
        }

        //relatedServiceProviders -> identifier
        if (CollectionUtils.isNotEmpty(visitHistory.getRelatedServiceProviders())) {
            encounter.addIdentifier()
                    .setValue(AppUtils.jsonEscape(visitHistory.getRelatedServiceProviders()))
                    .setType(new CodeableConcept().setText(Constants.RELATED_SERVICE_FACILITY_PROVIDER_INSTANCE_IDS));
        }

        //relationMedications -> identifier
        if (CollectionUtils.isNotEmpty(visitHistory.getRelatedMedications())) {
            encounter.addIdentifier()
                    .setValue(AppUtils.jsonEscape(visitHistory.getRelatedMedications()))
                    .setType(new CodeableConcept().setText(Constants.RELATED_MEDICATION_INSTANCE_IDS));
        }

        //relatedDevices -> identifier
        if (CollectionUtils.isNotEmpty(visitHistory.getRelatedDevices())) {
            encounter.addIdentifier()
                    .setValue(AppUtils.jsonEscape(visitHistory.getRelatedDevices()))
                    .setType(new CodeableConcept().setText(Constants.RELATED_DEVICE_INSTANCE_IDS));
        }

        //relatedImmunizations -> identifier
        if (CollectionUtils.isNotEmpty(visitHistory.getRelatedImmunizations())) {
            encounter.addIdentifier()
                    .setValue(AppUtils.jsonEscape(visitHistory.getRelatedImmunizations()))
                    .setType(new CodeableConcept().setText(Constants.RELATED_IMMUNIZATION_INSTANCE_IDS));
        }

        //relatedObservations -> identifier
        if (CollectionUtils.isNotEmpty(visitHistory.getRelatedObservations())) {
            encounter.addIdentifier()
                    .setValue(AppUtils.jsonEscape(visitHistory.getRelatedObservations()))
                    .setType(new CodeableConcept().setText(Constants.RELATED_OBSERVATION_INSTANCE_IDS));
        }

        //relatedCareTeams -> identifier
        if (CollectionUtils.isNotEmpty(visitHistory.getRelatedCareTeam())) {
            encounter.addIdentifier()
                    .setValue(AppUtils.jsonEscape(visitHistory.getRelatedCareTeam()))
                    .setType(new CodeableConcept().setText(Constants.RELATED_CARE_TEAM_INSTANCE_IDS));
        }

        //sourceClaimIds -> identifier
        if (CollectionUtils.isNotEmpty(visitHistory.getSourceClaimIds())) {
            encounter.addIdentifier()
                    .setValue(AppUtils.jsonEscape(visitHistory.getSourceClaimIds()))
                    .setType(new CodeableConcept().setText(Constants.SOURCE_CLAIM_IDS));
        }

        // add resource into bundle
        bundle.addEntry().setFullUrl(encounter.getId()).setResource(encounter);
    }

    public Encounter.EncounterHospitalizationComponent getOrCreateHospitalization(Encounter encounter) {
        if (encounter.hasHospitalization()) {
            return encounter.getHospitalization();
        } else {
            Encounter.EncounterHospitalizationComponent hospitalization = new Encounter.EncounterHospitalizationComponent();
            encounter.setHospitalization(hospitalization);
            return hospitalization;
        }
    }
}
