package com.uhg.ihr.centrihealth.api.model.dataclass;

import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor
public class Evaluation {
    private String date;
    private String targetResult;
    private String target;
    private IhrTermWithId targetType;
    private IhrTermWithId targetUnitOfMeasure;
    private IhrTermWithId status;
    private String comment;

}
