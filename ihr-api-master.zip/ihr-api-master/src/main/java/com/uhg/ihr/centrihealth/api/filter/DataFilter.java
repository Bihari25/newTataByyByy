package com.uhg.ihr.centrihealth.api.filter;

import com.fasterxml.jackson.databind.JsonNode;
import com.google.common.collect.ImmutableSet;

import java.util.Set;

/**
 * DataFilter class used to filter the payload data classes content.
 *
 * @author ihr api team
 * copyright (C) all rights reserved UHG
 */
public interface DataFilter {

    // Filters for clinicallyRelevantDate and presenceState
    // applies to below six data classes only and remaining classes are excluded
    Set<String> DATA_CLASS_FILTERS = ImmutableSet.<String>builder()
            .add("healthDevices")
            .add("healthStatuses")
            .add("immunizations")
            .add("medications")
            .add("procedureHistory")
            .add("visitHistory")
            .build();

    /**
     * Method to filter the data node based on given filter criteria.
     *
     * @return boolean
     */
    boolean filter(JsonNode dataNode);

    boolean isFilterableDataClass(String dataClass);

    Set<String> getFilterableDataClasses();

}
