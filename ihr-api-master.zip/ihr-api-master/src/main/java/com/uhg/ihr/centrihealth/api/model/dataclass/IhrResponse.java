package com.uhg.ihr.centrihealth.api.model.dataclass;

import com.uhg.ihr.centrihealth.api.model.MId;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.extern.slf4j.Slf4j;

@Data
@Slf4j
@NoArgsConstructor
public class IhrResponse {
    private String apiVersion;
    private String dataVersion;
    private String schemaVersion;
    private String correlationId;
    private String language;
    private MId mbrId;
    private DataClass dataClasses;
}
