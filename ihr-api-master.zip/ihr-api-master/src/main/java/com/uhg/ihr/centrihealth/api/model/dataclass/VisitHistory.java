package com.uhg.ihr.centrihealth.api.model.dataclass;

import lombok.Builder;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

import java.math.BigInteger;
import java.util.List;

@Data
@EqualsAndHashCode(callSuper = false)
@NoArgsConstructor
public class VisitHistory extends BaseDataClass {
    private String recordType;
    private String admitDate;
    private String recordKey;
    private String dischargeDate;
    private IhrTerm visit;
    private IhrTerm dischargeDisposition;
    private List<IhrTerm> admittingDiagnosis;
    private List<IhrTerm> dischargeDiagnosis;
    private String admitSource;
    private String presenceStateTerm;
    private String lastUpdateDate;
    private List<String> sensitivityClasses;
    private List<BigInteger> relatedConditions;
    private List<BigInteger> relatedMedications;
    private List<BigInteger> relatedProcedures;
    private List<BigInteger> relatedDevices;
    private List<BigInteger> relatedImmunizations;
    private List<BigInteger> relatedObservations;
    private List<BigInteger> relatedCareTeam;
    private List<BigInteger> relatedServiceProviders;
    private List<String> dataSource;
    private String visitType;
    private String placeOfService;
    private String clinicallyRelevantDate;
    private List<String> sourceClaimIds;
    private List<String> referenceIds;
    private String status;

    @Builder
    public VisitHistory(BigInteger objectId, String recordType, String admitDate, String recordKey, String dischargeDate, IhrTerm visit, IhrTerm dischargeDisposition, List<IhrTerm> admittingDiagnosis, List<IhrTerm> dischargeDiagnosis, String admitSource, String presenceStateTerm, String lastUpdateDate, List<String> sensitivityClasses, List<BigInteger> relatedConditions, List<BigInteger> relatedMedications, List<BigInteger> relatedProcedures, List<BigInteger> relatedDevices, List<BigInteger> relatedImmunizations, List<BigInteger> relatedObservations, List<BigInteger> relatedCareTeam, List<BigInteger> relatedServiceProviders, List<String> dataSource, String visitType, String placeOfService, String clinicallyRelevantDate, List<String> sourceClaimIds, List<String> referenceIds, String status) {
        super(objectId);
        this.recordType = recordType;
        this.admitDate = admitDate;
        this.recordKey = recordKey;
        this.dischargeDate = dischargeDate;
        this.visit = visit;
        this.dischargeDisposition = dischargeDisposition;
        this.admittingDiagnosis = admittingDiagnosis;
        this.dischargeDiagnosis = dischargeDiagnosis;
        this.admitSource = admitSource;
        this.presenceStateTerm = presenceStateTerm;
        this.lastUpdateDate = lastUpdateDate;
        this.sensitivityClasses = sensitivityClasses;
        this.relatedConditions = relatedConditions;
        this.relatedMedications = relatedMedications;
        this.relatedProcedures = relatedProcedures;
        this.relatedDevices = relatedDevices;
        this.relatedImmunizations = relatedImmunizations;
        this.relatedObservations = relatedObservations;
        this.relatedCareTeam = relatedCareTeam;
        this.relatedServiceProviders = relatedServiceProviders;
        this.dataSource = dataSource;
        this.visitType = visitType;
        this.placeOfService = placeOfService;
        this.clinicallyRelevantDate = clinicallyRelevantDate;
        this.sourceClaimIds = sourceClaimIds;
        this.referenceIds = referenceIds;
        this.status = status;
    }
}
