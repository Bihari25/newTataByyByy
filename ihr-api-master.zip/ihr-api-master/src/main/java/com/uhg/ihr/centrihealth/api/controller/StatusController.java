package com.uhg.ihr.centrihealth.api.controller;

import io.micronaut.http.HttpResponse;
import io.micronaut.http.MediaType;
import io.micronaut.http.MutableHttpResponse;
import io.micronaut.http.annotation.Controller;
import io.micronaut.http.annotation.Get;
import lombok.NoArgsConstructor;

@Controller("/status")
@NoArgsConstructor
public class StatusController {
    private static final String MESSAGE = "{\"status\":\"UP\",\"Message\":\"The service is up and running.\"}";
    private static final String CONTENT_MEDIA_TYPE = MediaType.APPLICATION_JSON + ";charset=utf-8";

    @Get(produces = CONTENT_MEDIA_TYPE)
    public MutableHttpResponse<String> read() {
        return HttpResponse.ok(MESSAGE);
    }

}
