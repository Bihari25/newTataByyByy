package com.uhg.ihr.centrihealth.api.logging;

public interface KafkaLogger {

    void logBig5(String correlationId, String big5Encrypted);
}
