package com.uhg.ihr.centrihealth.api.service.fhir.v2;

import com.uhg.ihr.centrihealth.api.constant.GlobalConstants;
import com.uhg.ihr.centrihealth.api.constant.GlobalUrlConstant;
import com.uhg.ihr.centrihealth.api.model.FhirResource;
import com.uhg.ihr.centrihealth.api.model.dataclass.DataClass;
import com.uhg.ihr.centrihealth.api.model.dataclass.Immunizations;
import com.uhg.ihr.centrihealth.api.model.dataclass.Note;
import com.uhg.ihr.centrihealth.api.service.fhir.FhirMapper;
import com.uhg.ihr.centrihealth.api.util.AppUtils;
import io.micrometer.core.instrument.util.StringUtils;
import lombok.Value;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections.CollectionUtils;
import org.hl7.fhir.r4.model.Bundle;
import org.hl7.fhir.r4.model.CodeableConcept;
import org.hl7.fhir.r4.model.Coding;
import org.hl7.fhir.r4.model.IdType;
import org.hl7.fhir.r4.model.Immunization;
import org.hl7.fhir.r4.model.Patient;
import org.hl7.fhir.r4.model.PositiveIntType;
import org.hl7.fhir.r4.model.Reference;
import org.hl7.fhir.r4.model.StringType;

@Slf4j
@Value(staticConstructor = "of")
public class ImmunizationFhir2Mapper implements FhirMapper<Immunizations, Immunization> {


    @Override
    public void map(FhirResource fhirResource, DataClass dataClasses) {
        if (dataClasses != null && CollectionUtils.isNotEmpty(dataClasses.getImmunizations())) {
            map(fhirResource, dataClasses.getImmunizations());
        }
    }

    @Override
    public void map(FhirResource fhirResource, Immunizations ihrImmunization) {
        Patient patient = fhirResource.getPatient();
        Bundle bundle = fhirResource.getBundle();

        Immunization immunization = buildImmunization(fhirResource, ihrImmunization);

        immunization.setPatient(new Reference(patient));
        // add resource into bundle
        bundle.addEntry().setFullUrl(immunization.getId()).setResource(immunization);
    }

    private Immunization buildImmunization(FhirResource fhirResource, Immunizations ihrImmunization) {

        Patient patient = fhirResource.getPatient();
        Immunization immunization = new Immunization();
        immunization.setId(new IdType(createIdURI()));

        buildImmunizationIdentifier(immunization, ihrImmunization);
        buildImmunizationExtension(immunization, ihrImmunization);
        buildImmunizationMedication(immunization, ihrImmunization);

        //sensitivity classes
        if (CollectionUtils.isNotEmpty(ihrImmunization.getSensitivityClasses())) {
            immunization.getMeta().getSecurity()
                    .add(new Coding().setSystem(GlobalUrlConstant.SECURITY_LABELS_URL).setCode(GlobalConstants.SECURITY_LABELS_CODE));
        }

        //concept
        if (null != ihrImmunization.getConcept()) {
            CodeableConcept code = new CodeableConcept();
            code.setText(ihrImmunization.getConcept().getIhrLaymanTerm())
                    .addCoding(createCoding(ihrImmunization.getConcept().getSourceVocabulary(),
                            ihrImmunization.getConcept().getSourceVocabularyCode(),
                            ihrImmunization.getConcept().getIhrTerm()));
            if (StringUtils.isNotBlank(ihrImmunization.getConcept().getCpthcpcsCode())) {
                code.addCoding(createCoding(GlobalUrlConstant.CPT_CODE_URL, ihrImmunization.getConcept().getCpthcpcsCode(), ""));
            }
            immunization.addReasonCode(code);

        }

        //health event date administartion date
        if (StringUtils.isNotBlank(ihrImmunization.getHealthEventDate())) {
            immunization.setOccurrence(toDateTimeTypeFromDate(ihrImmunization.getHealthEventDate()));
        }
        //notes
        if (null != ihrImmunization.getNote()) {
            for (Note note : ihrImmunization.getNote()) {
                immunization.addNote(createNote(patient, note, fhirResource));
            }
        }

        //last updated date
        if (StringUtils.isNotBlank(ihrImmunization.getLastUpdateDate())) {
            immunization.getMeta().setLastUpdatedElement(toInstantTypeFromDate(ihrImmunization.getLastUpdateDate()));
        }

        return immunization;

    }

    private void buildImmunizationMedication(Immunization immunization, Immunizations ihrImmunization) {
        //medication
        if (null != ihrImmunization.getMedication()) {
            immunization.setVaccineCode(new CodeableConcept().setText(ihrImmunization.getMedication().getIhrTerm())
                    .addCoding(createCoding(ihrImmunization.getMedication().getSourceVocabulary(),
                            ihrImmunization.getMedication().getSourceVocabularyCode(),
                            ihrImmunization.getMedication().getIhrLaymanTerm())));
        }

        //doseNumber
        if (null != ihrImmunization.getMedication() && null != ihrImmunization.getMedication().getDoseNumber()) {
            immunization.addProtocolApplied(
                    new Immunization.ImmunizationProtocolAppliedComponent()
                            .setDoseNumber(new PositiveIntType().setValue(ihrImmunization.getMedication().getDoseNumber().intValue())));
        }
        //lotNumber
        if (null != ihrImmunization.getMedication() && null != ihrImmunization.getMedication().getLotNumber()) {
            immunization.setLotNumber(ihrImmunization.getMedication().getLotNumber());
        }
        //vaccineReferenceIds
        if (null != ihrImmunization.getMedication() && null != ihrImmunization.getMedication().getReferenceIds()) {
            immunization.addIdentifier(createIdentifier(AppUtils.jsonEscape(ihrImmunization.getMedication().getReferenceIds()),
                    GlobalConstants.VACCINE_REFERENCE_IDS));
        }
        //vaccineReCord key
        if (null != ihrImmunization.getMedication() && null != ihrImmunization.getMedication().getRecordKey()) {
            immunization.addIdentifier(createIdentifier(ihrImmunization.getMedication().getRecordKey(),
                    GlobalConstants.VACCINE_RECORD_KEY));
        }
    }

    private void buildImmunizationExtension(Immunization immunization, Immunizations ihrImmunization) {
        //Clinically relevant date
        if (StringUtils.isNotBlank(ihrImmunization.getClinicallyRelevantDate())) {
            immunization.addExtension(GlobalUrlConstant.CLINICAL_RELEVANT_DATE_URL, this.toDateTimeTypeFromDate(ihrImmunization.getClinicallyRelevantDate()));
        }

        //presence state term
        if (StringUtils.isNotBlank(ihrImmunization.getPresenceStateTerm())) {
            immunization.addExtension(GlobalUrlConstant.PRESENCESTATE_URL, new StringType(ihrImmunization.getPresenceStateTerm()));
        }
    }

    private void buildImmunizationIdentifier(Immunization immunization, Immunizations ihrImmunization) {
        //recordKey
        if (null != ihrImmunization.getRecordKey()) {
            immunization.addIdentifier(createIdentifier(ihrImmunization.getRecordKey(), GlobalConstants.RECORD_KEY));
        }
        //object id
        if (null != ihrImmunization.getObjectId()) {
            immunization.addIdentifier(createIdentifier(ihrImmunization.getObjectId().toString(), GlobalConstants.OBJECT_ID));
        }
        //reference id
        if (CollectionUtils.isNotEmpty(ihrImmunization.getReferenceIds())) {
            immunization.addIdentifier(createIdentifier(AppUtils.jsonEscape(ihrImmunization.getReferenceIds()),
                    GlobalConstants.REFERENCE_IDS));
        }
        //related observations
        if (CollectionUtils.isNotEmpty(ihrImmunization.getRelatedObservations())) {
            immunization.addIdentifier(createIdentifier(AppUtils.jsonEscape(ihrImmunization.getRelatedObservations())
                    , GlobalConstants.RELATED_OBSERVATION_INSTANCE_IDS));
        }
        //related care team
        if (CollectionUtils.isNotEmpty(ihrImmunization.getRelatedCareTeam())) {
            immunization.addIdentifier(createIdentifier(AppUtils.jsonEscape(ihrImmunization.getRelatedCareTeam())
                    , GlobalConstants.RELATED_CARE_TEAM_INSTANCE_IDS));
        }
        //related service providers
        if (CollectionUtils.isNotEmpty(ihrImmunization.getRelatedServiceProviders())) {
            immunization.addIdentifier(createIdentifier(AppUtils.jsonEscape(ihrImmunization.getRelatedServiceProviders()),
                    GlobalConstants.RELATED_SERVICE_FACILITY_PROVIDER_INSTANCE_IDS));
        }
        //source claim ids
        if (CollectionUtils.isNotEmpty(ihrImmunization.getSourceClaimIds())) {
            immunization.addIdentifier(createIdentifier(AppUtils.jsonEscape(ihrImmunization.getSourceClaimIds())
                    , GlobalConstants.SOURCE_CLAIM_IDS));
        }
        //related conditions
        if (CollectionUtils.isNotEmpty(ihrImmunization.getRelatedConditions())) {
            immunization.addIdentifier(createIdentifier(AppUtils.jsonEscape(ihrImmunization.getRelatedConditions())
                    , GlobalConstants.RELATED_CONDITION_INSTANCE_IDS));
        }


    }
}