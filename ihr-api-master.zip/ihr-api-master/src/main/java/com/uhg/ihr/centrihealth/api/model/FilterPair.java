package com.uhg.ihr.centrihealth.api.model;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.validation.constraints.NotBlank;

/**
 * DataFilter class used to define filters criteria to filter dataclasses data.
 *
 * @author ihr extract engineering team.
 * @CopyRight (C) All rights reserved to UHG Inc. It's Illegal to reproduce this code.
 */
@Data
@NoArgsConstructor
public class FilterPair {

    @JsonProperty
    @NotBlank(message="The request could not be validated. A filter key was not provided.")
    private String key;

    @JsonProperty
    private String value;
}
