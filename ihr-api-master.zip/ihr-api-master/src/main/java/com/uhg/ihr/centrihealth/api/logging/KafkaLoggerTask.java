package com.uhg.ihr.centrihealth.api.logging;

import io.micronaut.configuration.kafka.annotation.KafkaKey;
import io.micronaut.context.annotation.Requires;
import io.micronaut.context.annotation.Value;
import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.extern.slf4j.Slf4j;

import javax.inject.Inject;
import javax.inject.Singleton;
import java.util.ArrayList;
import java.util.List;

@Slf4j
@Requires(property = "kafka.producers.big5logger.enabled", value = "true")
@Singleton
public class KafkaLoggerTask implements KafkaLogger {

    private static final String messageBufferMutex = "1";

    private List<KafkaBufferMessage> messageBuffer;
    private int maxBufferMessages;
    private long sleepTime;
    private Thread kafkaThread;
    private KafkaLoggerClient producer;

    @Inject
    public KafkaLoggerTask(KafkaLoggerClient producer,
                           @Value("${kafka.producers.big5logger.manager.max.messages}") int kafkaLoggerMaxBufferMsgs,
                           @Value("${kafka.producers.big5logger.manager.sleep.ms}") long sleepTime) {
        this.producer = producer;
        this.messageBuffer = new ArrayList<>();
        this.maxBufferMessages = kafkaLoggerMaxBufferMsgs;
        this.sleepTime = sleepTime;
        this.kafkaThread = new Thread(new KafkaSendLoop());
        this.kafkaThread.start();
    }

    private class KafkaSendLoop implements Runnable {

        @Override
        public void run() {
            while(true) {
                boolean bufferEmpty = true;
                List<KafkaBufferMessage> processList = null;
                synchronized (messageBufferMutex) {
                    bufferEmpty = messageBuffer.isEmpty();

                    if (!bufferEmpty) {
                        processList = messageBuffer;
                        messageBuffer = new ArrayList<>();
                    }
                }

                if (bufferEmpty) {
                    try {
                        Thread.sleep(sleepTime);
                    } catch (InterruptedException ignored) {
                        //Ignored
                    }
                } else {
                    if (processList != null) {
                        try {
                            processList
                                    .forEach(message -> producer.logBig5(message.correlationId, message.log));
                        } catch (Exception e) {
                            log.error("Failed to send log messages to kafka due to error: " + e.getMessage());
                        }
                    }
                }
            }
        }

    }

    @Data
    @AllArgsConstructor
    private class KafkaBufferMessage {
        private String correlationId;
        private String log;
    }

    public void logBig5(@KafkaKey String correlationId, String big5Encrypted) {
        synchronized (messageBufferMutex) {
            if (messageBuffer.size() < maxBufferMessages) {
                this.messageBuffer.add(new KafkaBufferMessage(correlationId, big5Encrypted));
            } else {
                log.warn("Kafka message buffer full, could not add log for correlation id: " + correlationId);
            }
        }
    }
}
