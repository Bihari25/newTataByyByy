package com.uhg.ihr.centrihealth.api.model.dataclass;

import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@NoArgsConstructor

public class ClinicalNote {
    private String noteType;
    private String clinicalNoteDateTime;
    private String clinicalNoteText;
    private String clinicalNoteAuthor;
}
