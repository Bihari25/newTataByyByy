package com.uhg.ihr.centrihealth.api.model;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.uhg.ihr.centrihealth.api.model.dataclass.BaseDataClass;
import com.uhg.ihr.centrihealth.api.model.dataclass.CareGiver;
import com.uhg.ihr.centrihealth.api.service.fhir.deferred.*;
import lombok.*;
import lombok.extern.slf4j.Slf4j;
import org.hl7.fhir.r4.model.*;

import javax.validation.constraints.NotBlank;
import java.math.BigInteger;
import java.util.HashMap;
import java.util.Map;

@Slf4j
@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class FhirResource {

    @JsonProperty
    @NotBlank(message = "A bundle object must required.")
    private Bundle bundle;

    @JsonProperty
    @NotBlank(message = "A patient object must required.")
    private Patient patient;

    @JsonProperty
    private Map<String, Practitioner> practitioner;

    @JsonProperty
    private Map<String, PractitionerRole> practitionerRole;

    @JsonProperty
    private Map<String, RelatedPerson> relatedPerson;

    @JsonProperty
    private Map<String, Organization> organization;

    @JsonProperty
    private Map<String, Condition> condition;

    @JsonProperty
    private Map<String, Observation> observation;

    @JsonProperty
    private Map<String, Location> location;

    @JsonProperty
    private Map<String, Specimen> specimen;

    @Getter(value = AccessLevel.PRIVATE)
    private final Map<BigInteger, FhirDeferredMap<Observation>> observationDeferredMappers = new HashMap<>();
    @Getter(value = AccessLevel.PRIVATE)
    private final Object observationMapMutex = new Object();

    @Getter(value = AccessLevel.PRIVATE)
    private final Map<BigInteger, FhirDeferredMap<Condition>> conditionDeferredMappers = new HashMap<>();
    @Getter(value = AccessLevel.PRIVATE)
    private final Object conditionMapMutex = new Object();

    @Getter(value = AccessLevel.PRIVATE)
    private final Map<BigInteger, FhirDeferredMap<Procedure>> procedureDeferredMappers = new HashMap<>();
    @Getter(value = AccessLevel.PRIVATE)
    private final Object procedureMapMutex = new Object();

    /**
     * This method is NOT SYNCHRONIZED an will throw an error if accessing methods do not synchronize when calling this
     * method. Handles all logic for creating and searching the provided map.
     *
     * @param transcribedObjectId The Transcribed objectId of the Fhir Resource
     * @param fhirDeferredMaps    The deferred maps for a type of Fhir Resource
     * @return Returns a new or existing FhirDeferredMap of type T inferred by the provided fhirDeferredMaps
     */
    private static <T extends Resource> FhirDeferredMap<T> getDeferredMap(BigInteger transcribedObjectId, Map<BigInteger, FhirDeferredMap<T>> fhirDeferredMaps) {
        FhirDeferredMap<T> deferredMap = fhirDeferredMaps.get(transcribedObjectId);

        if (deferredMap == null) {
            deferredMap = new FhirDeferredMap<>();
            fhirDeferredMaps.put(transcribedObjectId, deferredMap);
        }
        return deferredMap;
    }

    /**
     * Add a Fhir Resource to it's
     *
     * @param resource
     * @param transcribedDataClass
     * @param <T>
     * @param <R>
     */
    public <T extends Resource, R extends BaseDataClass> void addFhirResourceToDeferredMapper(T resource, R transcribedDataClass) {

        if (resource instanceof Observation) {
            synchronized (observationMapMutex) {
                getDeferredMap(transcribedDataClass.getObjectId(), observationDeferredMappers).addFhirResource((Observation) resource);
            }
        } else if (resource instanceof Condition) {
            synchronized (conditionMapMutex) {
                getDeferredMap(transcribedDataClass.getObjectId(), conditionDeferredMappers).addFhirResource((Condition) resource);
            }
        } else if (resource instanceof Procedure) {
            synchronized (procedureMapMutex) {
                getDeferredMap(transcribedDataClass.getObjectId(), procedureDeferredMappers).addFhirResource((Procedure) resource);
            }
        } else {
            log.error("Deferred mapper not implemented for FHIR resource " + resource.getClass().getName());
        }
    }

    public void addDeferredFhirMapper(BigInteger objectId, DeferredMapper deferredMapper) {

        if (deferredMapper instanceof ObservationDeferredMapper) {
            synchronized (observationMapMutex) {
                getDeferredMap(objectId, observationDeferredMappers).addDeferredMapper((ObservationDeferredMapper) deferredMapper);
            }
        } else if (deferredMapper instanceof ConditionDeferredMapper) {
            synchronized (conditionMapMutex) {
                getDeferredMap(objectId, conditionDeferredMappers).addDeferredMapper((ConditionDeferredMapper) deferredMapper);
            }
        } else if (deferredMapper instanceof ProcedureDeferredMapper) {
            synchronized (procedureMapMutex) {
                getDeferredMap(objectId, procedureDeferredMappers).addDeferredMapper((ProcedureDeferredMapper) deferredMapper);
            }
        } else {
            log.error("No logic for deferredMapper of type " + deferredMapper.getClass().getName() + " has been implemented.");
        }
    }

    public void processDeferredMappings() {
        log.info("START - Processing deferred mappers");
        observationDeferredMappers.forEach((id, linker) -> linker.processMappers(id));
        conditionDeferredMappers.forEach((id, linker) -> linker.processMappers(id));
        procedureDeferredMappers.forEach((id, linker) -> linker.processMappers(id));
        log.info("FINISH - Processing deferred mappers");
    }
}
