package com.uhg.ihr.centrihealth.api.service.fhir;

import com.uhg.ihr.centrihealth.api.model.FhirResource;
import com.uhg.ihr.centrihealth.api.model.dataclass.Constants;
import com.uhg.ihr.centrihealth.api.model.dataclass.DataClass;
import com.uhg.ihr.centrihealth.api.model.dataclass.HealthObservations;
import com.uhg.ihr.centrihealth.api.model.dataclass.Note;
import com.uhg.ihr.centrihealth.api.util.AppUtils;
import io.micrometer.core.instrument.util.StringUtils;
import lombok.Value;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections.CollectionUtils;
import org.hl7.fhir.r4.model.Bundle;
import org.hl7.fhir.r4.model.CodeableConcept;
import org.hl7.fhir.r4.model.Coding;
import org.hl7.fhir.r4.model.IdType;
import org.hl7.fhir.r4.model.Meta;
import org.hl7.fhir.r4.model.Observation;
import org.hl7.fhir.r4.model.Patient;
import org.hl7.fhir.r4.model.Reference;
import org.hl7.fhir.r4.model.StringType;

@Slf4j
@Value(staticConstructor = "of")
public class ObservationFhirMapper implements FhirMapper<HealthObservations, Observation> {

    private static final String OBSERVATION_UNITS_URL = "http://unitsofmeasure.org";
    private static final String LOINC_CODE_URL = "https://loinc.org/";

    @Override
    public void map(FhirResource fhirResource, DataClass dataClasses) {
        if (dataClasses != null && CollectionUtils.isNotEmpty(dataClasses.getHealthObservations())) {
            map(fhirResource, dataClasses.getHealthObservations());
        }
    }

    @Override
    public void map(FhirResource fhirResource, HealthObservations healthObservations) {
        Patient patient = fhirResource.getPatient();
        Bundle bundle = fhirResource.getBundle();

        Observation observation = new Observation();
        observation.setId(new IdType(createIdURI()));
        //record key
        if (null != healthObservations.getRecordKey()) {
            observation.addIdentifier().setValue(healthObservations.getRecordKey())
                    .setType(new CodeableConcept().setText(Constants.RECORD_KEY));
        }
        //object id
        if (null != healthObservations.getObjectId()) {
            observation.addIdentifier().setValue(healthObservations.getObjectId().toString())
                    .setType(new CodeableConcept().setText(Constants.INSTANCE_ID));
        }
        //reference id
        if (CollectionUtils.isNotEmpty(healthObservations.getReferenceIds())) {
            observation.addIdentifier().setValue(AppUtils.jsonEscape(healthObservations.getReferenceIds()))
                    .setType(new CodeableConcept().setText(Constants.REFERENCE_IDS));
        }
        // note
        if (CollectionUtils.isNotEmpty(healthObservations.getNote())) {
            for (Note note : healthObservations.getNote()) {
                observation.addNote(getAnnotation(patient, note, fhirResource));
            }
        }
        //observation date
        if (StringUtils.isNotBlank(healthObservations.getObservationDate())) {
            observation.setEffective(toDateTimeTypeFromDate(healthObservations.getObservationDate()));
        }
        //observation value
        if (null != healthObservations.getObservationValue()) {
            observation.addComponent().getValueCodeableConcept().setText(healthObservations.getObservationValue().getIhrLaymanTerm())
                    .addCoding(new Coding()
                            .setDisplay(healthObservations.getObservationValue().getIhrTerm())
                            .setSystem(healthObservations.getObservationValue().getSourceVocabulary())
                            .setCode(healthObservations.getObservationValue().getSourceVocabularyCode()));
        }
        //observation concept
        if (null != healthObservations.getObservation()) {
            observation.setCode(new CodeableConcept()
                    .setText(healthObservations.getObservation().getIhrLaymanTerm())
                    .addCoding(new Coding()
                            .setDisplay(healthObservations.getObservation().getIhrTerm())
                            .setSystem(healthObservations.getObservation().getSourceVocabulary())
                            .setCode(healthObservations.getObservation().getSourceVocabularyCode())));
            if (StringUtils.isNotBlank(healthObservations.getObservation().getLoincCode())) {
                observation.getCode().addCoding(new Coding()
                        .setSystem(LOINC_CODE_URL)
                        .setCode(healthObservations.getObservation().getLoincCode()));
            }
        }
        //observation units
        if (null != healthObservations.getObservationUnitOfMeasure()) {
            observation.addExtension(OBSERVATION_UNITS_URL, new CodeableConcept()
                    .setText(healthObservations.getObservationUnitOfMeasure().getIhrLaymanTerm())
                    .addCoding(new Coding()
                            .setDisplay(healthObservations.getObservationUnitOfMeasure().getIhrTerm())
                            .setSystem(healthObservations.getObservationUnitOfMeasure().getSourceVocabulary())
                            .setCode(healthObservations.getObservationUnitOfMeasure().getSourceVocabularyCode())));
        }
        //reference range
        if (StringUtils.isNotBlank(healthObservations.getReferenceRange())) {
            observation.addReferenceRange().setText(healthObservations.getReferenceRange());
        }
        //abnormal observation
        if (null != healthObservations.getAbnormalObservation()) {
            observation.addComponent().addInterpretation().setText(healthObservations.getAbnormalObservation().getIhrLaymanTerm())
                    .addCoding(new Coding()
                            .setDisplay(healthObservations.getAbnormalObservation().getIhrTerm())
                            .setSystem(healthObservations.getAbnormalObservation().getSourceVocabulary())
                            .setCode(healthObservations.getAbnormalObservation().getSourceVocabularyCode()));
        }
        //sensitivity classes
        if (CollectionUtils.isNotEmpty(healthObservations.getSensitivityClasses())) {
            observation.addExtension(Constants.SENSITIVITY_CLASSES_URL, new StringType(AppUtils.jsonEscape(healthObservations.getSensitivityClasses())));
        }
        //data source
        if (CollectionUtils.isNotEmpty(healthObservations.getDataSource())) {
            observation.addExtension(Constants.DATA_SOURCE_URL, new StringType(AppUtils.jsonEscape(healthObservations.getDataSource())));
        }
        //last updated date
        if (StringUtils.isNotBlank(healthObservations.getLastUpdateDate())) {
            observation.setMeta(new Meta().setLastUpdated(FhirMapper.toDate(healthObservations.getLastUpdateDate())));
        }
        //Value String
        if (StringUtils.isNotBlank(healthObservations.getValueString())) {
            observation.setValue(new StringType(healthObservations.getValueString()));
        }
        //status
        if (null != healthObservations.getStatus()) {
            observation.addExtension(Constants.STATUS_URL, new CodeableConcept()
                    .setText(healthObservations.getStatus().getIhrLaymanTerm())
                    .addCoding(new Coding()
                            .setDisplay(healthObservations.getStatus().getIhrTerm())
                            .setSystem(Constants.OBSERVATION_SYSTEM_STATUS_URL)
                            .setCode(healthObservations.getStatus().getSourceVocabularyCode())));
        }
        observation.setSubject(new Reference(patient));

        // add resource into bundle
        bundle.addEntry().setFullUrl(observation.getId()).setResource(observation);
    }
}
