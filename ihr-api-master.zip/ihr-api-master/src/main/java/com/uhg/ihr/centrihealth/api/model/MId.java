package com.uhg.ihr.centrihealth.api.model;

import com.fasterxml.jackson.annotation.JsonProperty;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.validation.Valid;
import javax.validation.constraints.NotNull;

@Data
@Builder(toBuilder = true)
@AllArgsConstructor
@NoArgsConstructor
public class MId {
    @JsonProperty
    @Deprecated
    private String idType;

    @JsonProperty
    @Deprecated
    private String idValue;

    @JsonProperty(value = "big5")
    @NotNull(message="The big 5 record may not be null.")
    @Valid
    private Big5 big5;
}
