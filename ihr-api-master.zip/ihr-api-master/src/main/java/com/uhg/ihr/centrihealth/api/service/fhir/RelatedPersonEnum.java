package com.uhg.ihr.centrihealth.api.service.fhir;

import java.util.Arrays;
import java.util.Set;
import java.util.stream.Collectors;

public enum RelatedPersonEnum {

    CARE_GIVER("Caregiver"),
    FAMILY_MEMBER("Family Member"),
    GUARDIAN("Guardian"),
    HEALTH_CARE_PROXY("Health Care Proxy"),
    OTHER("Other"),
    POWER_OF_ATTORNEY("Power of Attorney");

    public static final Set<String> ENUM_VALUES = Arrays.stream(RelatedPersonEnum.values())
            .map(RelatedPersonEnum::getValue)
            .collect(Collectors.toSet());
    private String value;

    RelatedPersonEnum(String value) {
        this.value = value;
    }

    public String getValue() {
        return value;
    }
}
