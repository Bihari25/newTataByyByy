package com.uhg.ihr.centrihealth.api.model.dataclass;

import lombok.*;

import java.math.BigInteger;
import java.util.List;

@Data
@EqualsAndHashCode(callSuper = false)
@NoArgsConstructor
@AllArgsConstructor
public class Immunizations extends BaseDataClass {
    private String recordKey;
    private List<String> referenceIds;
    private IhrTerm concept;
    private String dosageFrequency;
    private IhrTerm dosageForm;
    private IhrTerm medication;
    private Boolean genericFlag;
    private Float dosageQuantity;
    private IhrTerm dosageUnit;
    private String presenceStateTerm;
    private String healthEventDate;
    private String clinicallyRelevantDate;
    private String lastUpdateDate;
    private List<Note> note;
    private List<BigInteger> relatedConditions;
    private List<BigInteger> relatedObservations;
    private List<BigInteger> relatedCareTeam;
    private List<BigInteger> relatedServiceProviders;
    private List<String> sensitivityClasses;
    private List<String> sourceClaimIds;
    private List<String> dataSource;
    private String recordType; //Not in use

    @Builder
    public Immunizations(BigInteger objectId, String recordKey, List<String> referenceIds, IhrTerm concept, String dosageFrequency, IhrTerm dosageForm, IhrTerm medication, Boolean genericFlag, Float dosageQuantity, IhrTerm dosageUnit, String presenceStateTerm, String healthEventDate, String clinicallyRelevantDate, String lastUpdateDate, List<Note> note, List<BigInteger> relatedConditions, List<BigInteger> relatedObservations, List<BigInteger> relatedCareTeam, List<BigInteger> relatedServiceProviders, List<String> sensitivityClasses, List<String> sourceClaimIds, List<String> dataSource, String recordType) {
        super(objectId);
        this.recordKey = recordKey;
        this.referenceIds = referenceIds;
        this.concept = concept;
        this.dosageFrequency = dosageFrequency;
        this.dosageForm = dosageForm;
        this.medication = medication;
        this.genericFlag = genericFlag;
        this.dosageQuantity = dosageQuantity;
        this.dosageUnit = dosageUnit;
        this.presenceStateTerm = presenceStateTerm;
        this.healthEventDate = healthEventDate;
        this.clinicallyRelevantDate = clinicallyRelevantDate;
        this.lastUpdateDate = lastUpdateDate;
        this.note = note;
        this.relatedConditions = relatedConditions;
        this.relatedObservations = relatedObservations;
        this.relatedCareTeam = relatedCareTeam;
        this.relatedServiceProviders = relatedServiceProviders;
        this.sensitivityClasses = sensitivityClasses;
        this.sourceClaimIds = sourceClaimIds;
        this.dataSource = dataSource;
        this.recordType = recordType;
    }
}