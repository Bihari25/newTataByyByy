package com.uhg.ihr.centrihealth.api.util;

import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.google.common.io.CharStreams;
import com.uhg.ihr.centrihealth.api.exception.IhrException;
import io.micronaut.core.io.ResourceResolver;
import io.micronaut.core.io.scan.ClassPathResourceLoader;
import org.apache.commons.lang3.StringUtils;

import java.io.InputStream;
import java.io.InputStreamReader;
import java.nio.charset.StandardCharsets;
import java.util.Date;
import java.util.List;
import java.util.Optional;
import java.util.jar.Attributes;
import java.util.jar.Manifest;

public class AppUtils {
    public static final String[] DATE_PATTERNS = {"yyyy-MM-dd", "yyyy-MM-dd HH:mm:ss", "yyyy-MM-dd'T'HH:mm:ss'Z'"};

    public static final String CLINICALLY_RELEVANT_DATE = "clinicallyRelevantDate";
    public static final String CLINICALLY_RELEVANT_START_DATE = "clinicallyRelevantStartDate";
    public static final String CLINICALLY_RELEVANT_END_DATE = "clinicallyRelevantEndDate";
    public static final String PRESENCE_STATE = "PresenceState";
    public static final String PRESENCE_STATE_TERM = "presenceStateTerm";
    public static final String X_CONSUMER_HEADER = "X-Consumer-Username";

    private static final ObjectMapper MAPPER = new ObjectMapper();

    /**
     * Method to validate given date with in given start & end date.
     *
     */
    public static boolean isDateInBetween(final Date startDate, final Date endDate, final Date inputDate) {
        return !(inputDate.before(startDate) || inputDate.after(endDate));
    }

    /**
     * Method to get the build version from Manifest.MF file.
     *
     * @return String
     */
    public static String getBuildVersionFromManifestInfo() {
        String buildVersion;
        try (InputStream is = Thread.currentThread().getContextClassLoader().getResourceAsStream("META-INF/MANIFEST.MF")) {
            /* Validate build version is present; if not ser default value. */
            Manifest manifest = new Manifest(is);
            Attributes attrs = manifest.getMainAttributes();
            buildVersion = StringUtils.isNotBlank(attrs.getValue("Build-Version")) ? attrs.getValue("Build-Version") : "0.0.1";
        } catch (Exception ex) {
            buildVersion = "0.0.1";
        }

        return buildVersion;
    }

    public static InputStream readResourceAsStream(String resourcePath) {
        Optional<ClassPathResourceLoader> loader = new ResourceResolver().getLoader(ClassPathResourceLoader.class);
        if (!loader.isPresent()) {
            throw new IhrException("unable to resolve resource loader");
        }
        return loader.get().getResourceAsStream("classpath:" + resourcePath)
                .orElseThrow(() -> new RuntimeException("unable to read resource"));
    }

    public static String readResource(String resourcePath) {
        InputStream is = readResourceAsStream(resourcePath);

        try (InputStreamReader reader = new InputStreamReader(is, StandardCharsets.UTF_8)) {
            return CharStreams.toString(reader);
        } catch (Exception e) {
            throw new IhrException("unable to read resource", e);
        }
    }

    public static String jsonEscape(List<?> value)  {
        try {
            return MAPPER.writeValueAsString(value);
        }
        catch (JsonProcessingException ex) {
            throw new IhrException("unable to parse list", ex);
        }
    }
}