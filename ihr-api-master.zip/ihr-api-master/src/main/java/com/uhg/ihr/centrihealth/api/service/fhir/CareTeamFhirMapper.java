package com.uhg.ihr.centrihealth.api.service.fhir;

import com.uhg.ihr.centrihealth.api.model.FhirResource;
import com.uhg.ihr.centrihealth.api.model.dataclass.Constants;
import com.uhg.ihr.centrihealth.api.model.dataclass.DataClass;
import com.uhg.ihr.centrihealth.api.model.dataclass.IhrCareTeam;
import com.uhg.ihr.centrihealth.api.model.dataclass.IhrTermWithId;
import com.uhg.ihr.centrihealth.api.model.dataclass.Occupation;
import com.uhg.ihr.centrihealth.api.util.AppUtils;
import io.micrometer.core.instrument.util.StringUtils;
import lombok.Value;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections.CollectionUtils;
import org.hl7.fhir.r4.model.Bundle;
import org.hl7.fhir.r4.model.CareTeam;
import org.hl7.fhir.r4.model.CodeableConcept;
import org.hl7.fhir.r4.model.Coding;
import org.hl7.fhir.r4.model.HumanName;
import org.hl7.fhir.r4.model.IdType;
import org.hl7.fhir.r4.model.Identifier;
import org.hl7.fhir.r4.model.Patient;
import org.hl7.fhir.r4.model.Period;
import org.hl7.fhir.r4.model.Practitioner;
import org.hl7.fhir.r4.model.PractitionerRole;
import org.hl7.fhir.r4.model.Reference;

@Slf4j
@Value(staticConstructor = "of")
public class CareTeamFhirMapper implements FhirMapper<IhrCareTeam, CareTeam> {

    @Override
    public void map(FhirResource fhirResource, DataClass dataClasses) {
        if (dataClasses != null && CollectionUtils.isNotEmpty(dataClasses.getCareTeam())) {
            map(fhirResource, dataClasses.getCareTeam());
        }
    }

    @Override
    public void map(FhirResource fhirResource, IhrCareTeam ihrCareTeam) {
        Bundle bundle = fhirResource.getBundle();
        Patient patient = fhirResource.getPatient();

        CareTeam careTeam = new CareTeam();
        careTeam.setId(new IdType(createIdURI()));
        PractitionerRole practitionerRole = null;
        Practitioner practitioner = null;

        //related entity npinum
        if (StringUtils.isNotBlank(ihrCareTeam.getRelatedEntityNPInum())) {
            Identifier identifier = new Identifier()
                    .setValue(ihrCareTeam.getRelatedEntityNPInum())
                    .setType(new CodeableConcept().addCoding(new Coding()
                            .setCode(Constants.NPI)
                            .setDisplay(Constants.NPI_DISPLAY)
                            .setSystem(Constants.NPI_URL)));

            practitioner = getOrCreatePractitioner(fhirResource, identifier);
        }
        //related entity mpin
        if (StringUtils.isNotBlank(ihrCareTeam.getRelatedEntityMPIN())) {
            Identifier identifier = new Identifier()
                    .setValue(ihrCareTeam.getRelatedEntityMPIN())
                    .setType(new CodeableConcept()
                            .addCoding(new Coding().setCode(Constants.MPIN.toUpperCase())
                                    .setDisplay(Constants.MPIN_DISPLAY)
                                    .setSystem(Constants.MPIN_URL)));
            if (practitioner == null) {
                practitioner = getOrCreatePractitioner(fhirResource, identifier);
            } else {
                practitioner.addIdentifier(identifier);
            }
        }
        //record type
        if (null != ihrCareTeam.getRecordType()) {
            careTeam.setText(createNarrative(ihrCareTeam.getRecordType().getValue()));
        }
        //record key
        if (null != ihrCareTeam.getRecordKey()) {
            careTeam.addIdentifier().setValue(ihrCareTeam.getRecordKey())
                    .setType(new CodeableConcept().setText(Constants.RECORD_KEY));
        }
        //object id
        if (null != ihrCareTeam.getObjectId()) {
            careTeam.addIdentifier().setValue(ihrCareTeam.getObjectId().toString())
                    .setType(new CodeableConcept().setText(Constants.INSTANCE_ID));
        }
        //reference id
        if (CollectionUtils.isNotEmpty(ihrCareTeam.getReferenceIds())) {
            careTeam.addIdentifier().setValue(AppUtils.jsonEscape(ihrCareTeam.getReferenceIds()))
                    .setType(new CodeableConcept().setText(Constants.REFERENCE_IDS));
        }
        //name
        if (StringUtils.isNotBlank(ihrCareTeam.getPrefix())
                || StringUtils.isNotBlank(ihrCareTeam.getFirstName())
                || StringUtils.isNotBlank(ihrCareTeam.getRelatedEntityName())
                || StringUtils.isNotBlank(ihrCareTeam.getLastName())) {

            HumanName humanName = new HumanName()
                    .setFamily(ihrCareTeam.getLastName())
                    .addGiven(ihrCareTeam.getFirstName())
                    .addGiven(StringUtils.isBlank(ihrCareTeam.getMiddleName()) ? "" : ihrCareTeam.getMiddleName())
                    .setText(ihrCareTeam.getRelatedEntityName())
                    .addPrefix(ihrCareTeam.getPrefix());

            if (practitioner == null) {
                practitioner = getOrCreatePractitioner(fhirResource, humanName);
            } else {
                practitioner.addName(humanName);
            }
        }
        //related entity role term
        if (StringUtils.isNotBlank(ihrCareTeam.getRelatedEntityRoleTerm())) {
            careTeam.getParticipantFirstRep().addRole()
                    .setText(Constants.RELATED_ENTITY_ROLE_TERM)
                    .addCoding(new Coding().setDisplay(ihrCareTeam.getRelatedEntityRoleTerm()));
        }
        //relationship start and end date
        Period period = new Period();
        if (StringUtils.isNotBlank(ihrCareTeam.getRelationshipStartDate())) {
            period.setStartElement(toDateTimeTypeFromDate(ihrCareTeam.getRelationshipStartDate()));
        }
        if (StringUtils.isNotBlank(ihrCareTeam.getRelationshipEndDate())) {
            period.setEndElement(toDateTimeTypeFromDate(ihrCareTeam.getRelationshipEndDate()));
        }
        careTeam.getParticipantFirstRep().setPeriod(period);

        //occupations
        if (null != ihrCareTeam.getOccupations() && !ihrCareTeam.getOccupations().isEmpty()) {
            for (Occupation occupation : ihrCareTeam.getOccupations()) {
                CodeableConcept concept = new CodeableConcept();
                if (null != occupation.getConcept()) {
                    concept.setText(occupation.getConcept().getIhrLaymanTerm())
                            .addCoding(new Coding()
                                    .setDisplay(occupation.getConcept().getIhrTerm())
                                    .setSystem(occupation.getConcept().getSourceVocabulary())
                                    .setCode(occupation.getConcept().getSourceVocabularyCode()))
                            .addCoding(new Coding()
                                    .setCode(occupation.getConcept().getIhrId())
                                    .setSystem(Constants.OCCUPATION_IHRID));
                }

                if (CollectionUtils.isNotEmpty(occupation.getSpecialties())) {
                    for (IhrTermWithId ihrTerm : occupation.getSpecialties()) {
                        concept.addExtension(Constants.SPECIALTY_URL, new CodeableConcept()
                                .setText(ihrTerm.getIhrLaymanTerm())
                                .addCoding(new Coding()
                                        .setDisplay(ihrTerm.getIhrTerm())
                                        .setSystem(ihrTerm.getSourceVocabulary())
                                        .setCode(ihrTerm.getSourceVocabularyCode()))
                                .addCoding(new Coding()
                                        .setCode(ihrTerm.getIhrId())
                                        .setSystem(Constants.DOMAIN_SPECIALTY_IHRID)));

                    }
                }
                if (practitionerRole == null) {
                    practitionerRole = getOrCreatePractitionerRole(fhirResource, concept);
                } else {
                    practitionerRole.addCode(concept);
                }
            }
        }
        if (practitionerRole == null) {
            practitionerRole = getOrCreatePractitionerRole(fhirResource, new CodeableConcept());
        }
        practitionerRole.setPractitioner(new Reference(practitioner));

        careTeam.setSubject(new Reference(patient)).getParticipantFirstRep().setMember(new Reference(practitionerRole));
        // add resource into bundle
        bundle.addEntry().setFullUrl(careTeam.getId()).setResource(careTeam);
    }
}
