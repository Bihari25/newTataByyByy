package com.uhg.ihr.centrihealth.api.model.dataclass;

import lombok.*;

import java.math.BigInteger;
import java.util.List;

@Data
@EqualsAndHashCode(callSuper = false)
@AllArgsConstructor
@NoArgsConstructor
public class CareGiver extends BaseDataClass {
    private String recordType;
    private String recordKey;
    private String relationshipToIndividual;
    private String relatedEntityName;
    private String relatedEntityRoleTerm;
    private String relationshipStartDate;
    private String relationshipEndDate;
    private List<String> referenceIds;

    @Builder
    public CareGiver(BigInteger objectId, String recordType, String recordKey, String relationshipToIndividual, String relatedEntityName, String relatedEntityRoleTerm, String relationshipStartDate, String relationshipEndDate, List<String> referenceIds) {
        super(objectId);
        this.recordType = recordType;
        this.recordKey = recordKey;
        this.relationshipToIndividual = relationshipToIndividual;
        this.relatedEntityName = relatedEntityName;
        this.relatedEntityRoleTerm = relatedEntityRoleTerm;
        this.relationshipStartDate = relationshipStartDate;
        this.relationshipEndDate = relationshipEndDate;
        this.referenceIds = referenceIds;
    }
}
