package com.uhg.ihr.centrihealth.api.exception;

import lombok.RequiredArgsConstructor;

@RequiredArgsConstructor
public class IhrGoneException extends RuntimeException {
    public IhrGoneException(String message) {
        super(message);
    }
}