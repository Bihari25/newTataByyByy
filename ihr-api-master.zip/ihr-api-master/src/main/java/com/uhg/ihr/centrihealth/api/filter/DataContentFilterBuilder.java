package com.uhg.ihr.centrihealth.api.filter;

import com.uhg.ihr.centrihealth.api.exception.IhrBadRequestException;
import com.uhg.ihr.centrihealth.api.model.FilterPair;
import com.uhg.ihr.centrihealth.api.util.AppUtils;
import io.micronaut.core.util.CollectionUtils;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.extern.slf4j.Slf4j;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.ArrayList;
import java.util.List;
import java.util.Objects;
import java.util.Set;

/**
 * DataContentFilterBuilder used to build the data filter based on requested filters.
 *
 * @author ihr api team
 * copyright (C) all rights reserved UHG
 */
@Slf4j
@NoArgsConstructor
public class DataContentFilterBuilder {

    @Getter
    private List<DataFilter> dataFilters;

    public DataContentFilterBuilder(Set<FilterPair> dataContentFilters) {
        dataFilters = new ArrayList<>();

        if (CollectionUtils.isNotEmpty(dataContentFilters)) {
            // Compute and build clinical relevant date filter
            computeStartAndEndDateFilters(dataContentFilters, this.dataFilters);

            // Iterate and build data filters.
            for (FilterPair filterPair : dataContentFilters) {
                if (AppUtils.PRESENCE_STATE.equals(filterPair.getKey())) {
                    this.dataFilters.add(new PresenceStateFilter(filterPair.getValue()));
                }
            }
        }
    }

    /**
     * Method to compute start and end date filters.
     */
    public void computeStartAndEndDateFilters(Set<FilterPair> inputFilters, List<DataFilter> dataFilters) throws IhrBadRequestException {
        FilterPair clinicalStartDate = inputFilters.stream().filter(filterPair -> filterPair.getKey().equalsIgnoreCase(AppUtils.CLINICALLY_RELEVANT_START_DATE)).findAny().orElse(null);
        FilterPair clinicalEndDate = inputFilters.stream().filter(filterPair -> filterPair.getKey().equalsIgnoreCase(AppUtils.CLINICALLY_RELEVANT_END_DATE)).findAny().orElse(null);

        // Validate if request have both start and end date filter or only start date or end date.
        if (Objects.nonNull(clinicalStartDate) && Objects.nonNull(clinicalEndDate)) {
            dataFilters.add(new ClinicallyRelevantDateFilter(clinicalStartDate.getValue(), clinicalEndDate.getValue()));
        } else if (Objects.nonNull(clinicalStartDate)) {
            //Get current date time
            LocalDateTime now = LocalDateTime.now();
            DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");
            String endDate = now.format(formatter);

            dataFilters.add(new ClinicallyRelevantDateFilter(clinicalStartDate.getValue(), endDate));
        } else if (Objects.nonNull(clinicalEndDate)) {
            throw new IhrBadRequestException("Data can't filter only with end date; Please provide start date");
        }
    }

}
