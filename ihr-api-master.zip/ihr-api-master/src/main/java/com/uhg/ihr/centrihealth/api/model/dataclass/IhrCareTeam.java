package com.uhg.ihr.centrihealth.api.model.dataclass;

import java.math.BigInteger;
import java.util.List;

import lombok.*;

@Data
@EqualsAndHashCode(callSuper = false)
@AllArgsConstructor
@NoArgsConstructor
public class IhrCareTeam extends BaseDataClass {
    private DataClassEnums recordType;
    private String recordKey;
    private String personRoleTerm;
    private String prefix;
    private String firstName;
    private String middleName;
    private String lastName;
    private String relatedEntityName;
    private String relatedEntityNPInum;
    private String relatedEntityMPIN;
    private String relatedEntityRoleTerm;
    private String relationshipStartDate;
    private String relationshipEndDate;
    private String relationshipStatus;
    private List<Occupation> occupations;
    private List<String> referenceIds;

    @Builder
    public IhrCareTeam(BigInteger objectId, DataClassEnums recordType, String recordKey, String personRoleTerm, String prefix, String firstName, String middleName, String lastName, String relatedEntityName, String relatedEntityNPInum, String relatedEntityMPIN, String relatedEntityRoleTerm, String relationshipStartDate, String relationshipEndDate, String relationshipStatus, List<Occupation> occupations, List<String> referenceIds) {
        super(objectId);
        this.recordType = recordType;
        this.recordKey = recordKey;
        this.personRoleTerm = personRoleTerm;
        this.prefix = prefix;
        this.firstName = firstName;
        this.middleName = middleName;
        this.lastName = lastName;
        this.relatedEntityName = relatedEntityName;
        this.relatedEntityNPInum = relatedEntityNPInum;
        this.relatedEntityMPIN = relatedEntityMPIN;
        this.relatedEntityRoleTerm = relatedEntityRoleTerm;
        this.relationshipStartDate = relationshipStartDate;
        this.relationshipEndDate = relationshipEndDate;
        this.relationshipStatus = relationshipStatus;
        this.occupations = occupations;
        this.referenceIds = referenceIds;
    }
}
