package com.uhg.ihr.centrihealth.api.model;

import com.fasterxml.jackson.annotation.JsonAutoDetect;
import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.*;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.text.StringEscapeUtils;

@Slf4j
@Data
@Builder
@ToString
@NoArgsConstructor
@AllArgsConstructor
@JsonAutoDetect(fieldVisibility = JsonAutoDetect.Visibility.ANY)
@JsonInclude(JsonInclude.Include.NON_NULL)
public class Payload {
    public static final String DATA_CLASSES = "dataClasses";
    private static final ObjectMapper MAPPER = new ObjectMapper();

    @JsonProperty
    private String ihrIdentifier;

    @JsonProperty
    private String language;

    @JsonProperty
    private String taxonomy;

    @JsonProperty
    private String payload;

    private JsonNode payloadJson;

    @Getter
    @Setter
    private JsonNode filteredJson;

    public static String sanitize(String input) {
        if (input != null) {
            input = input.replace("''", "'");
        }
        return StringEscapeUtils.unescapeJava(StringUtils.strip(input, "\""));
    }

    public JsonNode getPayloadJson() {
        if (payloadJson == null && payload != null) {
            try { //try unsanitized first, this should be the default path
                this.payloadJson = MAPPER.readValue(payload, JsonNode.class);
            }
            catch (Exception e) { // if that fails, try the sanitized version
                log.warn("attempting to re-try json parsing for actor {}", ihrIdentifier);
                String payload2 = sanitize(payload);
                try {
                    this.payloadJson = MAPPER.readValue(payload2, JsonNode.class);
                } catch (Exception ex) {
                    throw new RuntimeException("Unable to parse JSON from payload for " + ihrIdentifier);
                }
            }
        }
        return this.payloadJson;
    }
}