package com.uhg.ihr.centrihealth.api.service.fhir.v2;

import com.uhg.ihr.centrihealth.api.constant.GlobalConstants;
import com.uhg.ihr.centrihealth.api.constant.GlobalUrlConstant;
import com.uhg.ihr.centrihealth.api.model.FhirResource;
import com.uhg.ihr.centrihealth.api.model.dataclass.DataClass;
import com.uhg.ihr.centrihealth.api.model.dataclass.HealthMedication;
import com.uhg.ihr.centrihealth.api.model.dataclass.IhrTerm;
import com.uhg.ihr.centrihealth.api.model.dataclass.Note;
import com.uhg.ihr.centrihealth.api.service.fhir.FhirMapper;
import com.uhg.ihr.centrihealth.api.service.fhir.PatientEnum;
import com.uhg.ihr.centrihealth.api.service.fhir.PractitionerRoleEnum;
import com.uhg.ihr.centrihealth.api.service.fhir.RelatedPersonEnum;
import com.uhg.ihr.centrihealth.api.util.AppUtils;
import io.micrometer.core.instrument.util.StringUtils;
import lombok.Value;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections.CollectionUtils;
import org.hl7.fhir.exceptions.FHIRException;
import org.hl7.fhir.r4.model.BooleanType;
import org.hl7.fhir.r4.model.Bundle;
import org.hl7.fhir.r4.model.CodeableConcept;
import org.hl7.fhir.r4.model.DecimalType;
import org.hl7.fhir.r4.model.Dosage;
import org.hl7.fhir.r4.model.HumanName;
import org.hl7.fhir.r4.model.IdType;
import org.hl7.fhir.r4.model.Identifier;
import org.hl7.fhir.r4.model.Location;
import org.hl7.fhir.r4.model.Medication;
import org.hl7.fhir.r4.model.MedicationDispense;
import org.hl7.fhir.r4.model.MedicationKnowledge;
import org.hl7.fhir.r4.model.MedicationRequest;
import org.hl7.fhir.r4.model.MedicationStatement;
import org.hl7.fhir.r4.model.Meta;
import org.hl7.fhir.r4.model.Organization;
import org.hl7.fhir.r4.model.Patient;
import org.hl7.fhir.r4.model.Period;
import org.hl7.fhir.r4.model.Practitioner;
import org.hl7.fhir.r4.model.PractitionerRole;
import org.hl7.fhir.r4.model.Quantity;
import org.hl7.fhir.r4.model.Reference;
import org.hl7.fhir.r4.model.RelatedPerson;
import org.hl7.fhir.r4.model.StringType;

@Slf4j
@Value(staticConstructor = "of")
public class MedicationFhir2Mapper implements FhirMapper<HealthMedication, Medication> {


    @Override
    public void map(FhirResource fhirResource, DataClass dataClasses) {
        if (dataClasses != null && CollectionUtils.isNotEmpty(dataClasses.getMedications())) {
            map(fhirResource, dataClasses.getMedications());
        }
    }

    @Override
    public void map(FhirResource fhirResource, final HealthMedication healthMedication) {
        Bundle bundle = fhirResource.getBundle();
        Patient patient = fhirResource.getPatient();

        //medication
        Medication medication = buildMedication(fhirResource, healthMedication);

        //medicationKnowledge
        MedicationKnowledge medicationKnowledge = buildMedicationKnowledge(fhirResource, healthMedication);
        medicationKnowledge.getAssociatedMedication().add(new Reference(medication));

        //MedicationRequest
        MedicationRequest medicationRequest = buildMedicationRequest(fhirResource, healthMedication);
        medicationRequest.setMedication(new Reference(medication));
        medicationRequest.setSubject(new Reference(patient));

        //MedicationDespance
        MedicationDispense medicationDispense = buildMedicationDispense(fhirResource, healthMedication);
        medicationDispense.setMedication(new Reference(medication));
        medicationDispense.setSubject(new Reference(patient));

        //MedicationStatement
        MedicationStatement statement = buildMedicatioStatement(fhirResource, healthMedication);
        statement.setMedication(new Reference(medication));
        statement.setSubject(new Reference(patient));

        //add medication resource in bundle
        bundle.addEntry().setFullUrl(medication.getId()).setResource(medication);
        bundle.addEntry().setFullUrl(medicationKnowledge.getId()).setResource(medicationKnowledge);
        bundle.addEntry().setFullUrl(medicationRequest.getId()).setResource(medicationRequest);
        bundle.addEntry().setFullUrl(medicationDispense.getId()).setResource(medicationDispense);
        bundle.addEntry().setFullUrl(statement.getId()).setResource(statement);

    }

    public MedicationStatement buildMedicatioStatement(FhirResource fhirResource, HealthMedication healthMedication) {
        Patient patient = fhirResource.getPatient();
        MedicationStatement statement = new MedicationStatement();
        statement.setId(new IdType(createIdURI()));

        //lastUpdateDate
        if (null != healthMedication.getLastUpdateDate()) {
            statement.setMeta(new Meta().setLastUpdatedElement(toInstantTypeFromDate(healthMedication.getLastUpdateDate())));
        }

        Dosage dosage = new Dosage();
        statement.getDosage().add(dosage);
        //dosage quantity  & dosage quantity Unit
        if (null != healthMedication.getDosageQuantity()) {
            Dosage.DosageDoseAndRateComponent component = new Dosage.DosageDoseAndRateComponent();
            Quantity quantity = new Quantity();
            component.setDose(quantity.setValue(healthMedication.getDosageQuantity()));
            if (null != healthMedication.getDoseQuantityUnit()) {
                quantity.setUnit(healthMedication.getDoseQuantityUnit().getIhrTerm());
            }
            dosage.getDoseAndRate().add(component);
        }
        //doseFrequency
        if (healthMedication.getDoseFrequency() != null) {
            dosage.getTiming().getCode()
                    .setText(healthMedication.getDoseFrequency().getIhrLaymanTerm())
                    .addCoding(createCoding(healthMedication.getDoseFrequency().getSourceVocabulary(),
                            healthMedication.getDoseFrequency().getSourceVocabularyCode(),
                            healthMedication.getDoseFrequency().getIhrTerm()));

        }
        // dosageRoute
        if (null != healthMedication.getDosageRoute()) {
            dosage.getRoute().setText(healthMedication.getDosageRoute().getIhrLaymanTerm())
                    .getCoding().add(createCoding(healthMedication.getDosageRoute().getSourceVocabulary(),
                    healthMedication.getDosageRoute().getSourceVocabularyCode(),
                    healthMedication.getDosageRoute().getIhrTerm()));
        }
        //adminInstructions
        if (null != healthMedication.getAdminInstructions()) {
            dosage.setText(healthMedication.getAdminInstructions());
        }
        //medicationStatus
        if (null != healthMedication.getMedicationStatus()) {
            try {
                statement.setStatus(MedicationStatement.
                        MedicationStatementStatus.fromCode(healthMedication.getMedicationStatus().getIhrTerm().toLowerCase()));
            } catch (FHIRException e) {
                log.error("Error setting Medication status: {}", e.getMessage());
                statement.setStatus(MedicationStatement.MedicationStatementStatus.UNKNOWN);
            }
        }
        //presence state term
        if (null != healthMedication.getPresenceStateTerm()) {
            statement.addExtension(GlobalUrlConstant.PRESENCESTATE_URL, new StringType(healthMedication.getPresenceStateTerm()));
        }
        //medicationReason
        if (CollectionUtils.isNotEmpty(healthMedication.getMedicationReason())) {
            for (IhrTerm medicationReason : healthMedication.getMedicationReason()) {
                statement.getReasonCode().add(new CodeableConcept()
                        .addCoding(createCoding(medicationReason.getSourceVocabulary(), medicationReason.getSourceVocabularyCode(), "")));
            }
        }
        //icueSeqId
        if (StringUtils.isNotBlank(healthMedication.getIcueSeqId())) {
            statement.addExtension(GlobalUrlConstant.ICUE_SEQ_ID_URL, new StringType(healthMedication.getIcueSeqId()));
        }
        //icue last update date
        if (null != healthMedication.getIcueLastUpdateDate()) {
            statement.addExtension(GlobalUrlConstant.ICUE_LAST_UPDATE_DATE_URL, toDateTimeTypeFromDate(healthMedication.getIcueLastUpdateDate()));
        }

        Period period = new Period();
        //First Dose Date and End Date
        if (StringUtils.isNotBlank(healthMedication.getFirstDoseDate())) {
            period.setStartElement(toDateTimeTypeFromDate(healthMedication.getFirstDoseDate()));
            statement.setEffective(period);
        }
        if (StringUtils.isNotBlank(healthMedication.getEndDate())) {
            period.setEndElement(toDateTimeTypeFromDate(healthMedication.getEndDate()));
            statement.setEffective(period);
        }
        //Hold Date
        if (StringUtils.isNotBlank(healthMedication.getHoldDate())) {
            statement.addExtension(GlobalUrlConstant.HOLD_DATE_URL, toDateTimeTypeFromDate(healthMedication.getHoldDate()));
        }
        //Restart Date
        if (StringUtils.isNotBlank(healthMedication.getRestartedDate())) {
            statement.addExtension(GlobalUrlConstant.RESTART_DATE_URL, toDateTimeTypeFromDate(healthMedication.getRestartedDate()));
        }
        //TakenAsOrdered
        if (null != healthMedication.getTakenAsOrdered()) {
            statement.addExtension(GlobalUrlConstant.TAKEN_AS_ORDERED_URL, new BooleanType(healthMedication.getTakenAsOrdered()));
        }
        //Adherence STop Date
        if (StringUtils.isNotBlank(healthMedication.getAdherenceStopdate())) {
            statement.addExtension(GlobalUrlConstant.ADHERENCE_STOP_DATE_URL, toDateTimeTypeFromDate(healthMedication.getAdherenceStopdate()));
        }
        //expected fill date
        if (StringUtils.isNotBlank(healthMedication.getExpectedFillDate())) {
            statement.addExtension(GlobalUrlConstant.EXPECTED_FILL_DATE_URL, toDateTypeFromDate(healthMedication.getExpectedFillDate()));

        }
        //medicationReviewDate;
        if (StringUtils.isNotBlank(healthMedication.getMedicationReviewDate())) {
            statement.setDateAssertedElement(this.toDateTimeTypeFromDate(healthMedication.getMedicationReviewDate()));
        }
        // medicationReviewLastActivityDate
        if (StringUtils.isNotBlank(healthMedication.getMedicationReviewLastActivityDate())) {
            statement.getMeta().addExtension(GlobalUrlConstant.REVIEW_LAST_ACTIVITY_DATE_URL, this.toDateTimeTypeFromDate((healthMedication.getMedicationReviewLastActivityDate())));
        }
        //reviewedBy;
        if (StringUtils.isNotBlank(healthMedication.getReviewedBy())) {
            statement.addIdentifier(createIdentifier(healthMedication.getReviewedBy(), GlobalConstants.EMPLOYEE_ID));
        }
        // InformerObject
        if (null != healthMedication.getInformerObject() && null != healthMedication.getInformerObject().getSourceVocabularyCode()) {
            if (RelatedPersonEnum.ENUM_VALUES.contains(healthMedication.getInformerObject().getSourceVocabularyCode())) {
                CodeableConcept relationShip = new CodeableConcept().setText(healthMedication.getInformerObject().getSourceVocabularyCode());
                RelatedPerson relatedPerson = getOrCreateRelatedPerson(fhirResource, relationShip);
                statement.setInformationSource(new Reference(relatedPerson));
            } else if (PractitionerRoleEnum.ENUM_VALUES.contains(healthMedication.getInformerObject().getSourceVocabularyCode())) {
                CodeableConcept practitionerCode = new CodeableConcept().setText(healthMedication.getInformerObject().getSourceVocabularyCode());
                PractitionerRole practitionerRole = getOrCreatePractitionerRole(fhirResource, practitionerCode);
                statement.setInformationSource(new Reference(practitionerRole));
            } else if (PatientEnum.ENUM_VALUES.contains(healthMedication.getInformerObject().getIhrTerm())) {
                statement.setInformationSource(new Reference(patient));
            }
        }
        //notes
        if (null != healthMedication.getNote()) {
            for (Note note : healthMedication.getNote()) {
                statement.addNote(createNote(patient, note, fhirResource));
            }
        }
        //medicationStartDate
        if (StringUtils.isNotBlank(healthMedication.getMedicationStartDate())) {
            statement.addExtension(GlobalUrlConstant.START_DATE_URL, toDateTimeTypeFromDate(healthMedication.getMedicationStartDate()));
        }
        //clinicallyRelevantDate
        if (StringUtils.isNotBlank(healthMedication.getClinicallyRelevantDate())) {
            statement.addExtension(GlobalUrlConstant.CLINICAL_RELEVANT_DATE_URL, toDateTimeTypeFromDate(healthMedication.getClinicallyRelevantDate()));
        }
        //referenceId
        if (CollectionUtils.isNotEmpty(healthMedication.getReferenceIds())) {
            statement.addIdentifier(createIdentifier(AppUtils.jsonEscape(healthMedication.getReferenceIds()), GlobalConstants.REFERENCE_IDS));

        }
        //related conditions
        if (CollectionUtils.isNotEmpty(healthMedication.getRelatedConditions())) {
            statement.addIdentifier(createIdentifier(AppUtils.jsonEscape(healthMedication.getRelatedConditions()),
                    GlobalConstants.RELATED_CONDITION_IDS));

        }
        //reviewerihrActorIdentifer
        if (StringUtils.isNotBlank(healthMedication.getReviewerIhrActorIdentifier())) {
            statement.addIdentifier(createIdentifier(healthMedication.getReviewerIhrActorIdentifier(),
                    GlobalConstants.REVIEWER_IHR_ACTOR_IDENTIFIRE));
        }
        //related devices
        if (CollectionUtils.isNotEmpty(healthMedication.getRelatedDevices())) {
            statement.addIdentifier(createIdentifier(AppUtils.jsonEscape(healthMedication.getRelatedDevices()),
                    GlobalConstants.RELATED_DEVICE_INSTANCE_IDS));
        }
        //related careteam
        if (CollectionUtils.isNotEmpty(healthMedication.getRelatedCareTeam())) {
            statement.addIdentifier(createIdentifier(AppUtils.jsonEscape(healthMedication.getRelatedCareTeam()),
                    GlobalConstants.RELATED_CARE_TEAM_INSTANCE_IDS));
        }
        //related service providers
        if (CollectionUtils.isNotEmpty(healthMedication.getRelatedServiceProviders())) {
            statement.addIdentifier(createIdentifier(AppUtils.jsonEscape(healthMedication.getRelatedServiceProviders()),
                    GlobalConstants.RELATED_SERVICE_FACILITY_PROVIDER_INSTANCE_IDS));

        }
        return statement;
    }

    private MedicationDispense buildMedicationDispense(FhirResource fhirResource, HealthMedication healthMedication) {
        MedicationDispense medicationDispense = new MedicationDispense();
        medicationDispense.setId(new IdType(createIdURI()));

        //dispenseStatus
        if (null != healthMedication.getDispenseStatus()) {
            medicationDispense.setStatus(MedicationDispense.MedicationDispenseStatus
                    .fromCode(healthMedication.getDispenseStatus()));
        }
        //lastFillDate
        if (null != healthMedication.getLastFillDate()) {
            medicationDispense.setWhenPrepared(FhirMapper.toDate(healthMedication.getLastFillDate()));
        }
        //daysSupply
        if (null != healthMedication.getDaysSupply()) {
            medicationDispense.setDaysSupply(new Quantity().setValue(healthMedication.getDaysSupply()));
        }
        //refill count
        if (null != healthMedication.getRefillCount()) {
            medicationDispense.addExtension(GlobalUrlConstant.REFILL_COUNT,
                    new DecimalType(healthMedication.getRefillCount()));
        }
        //Dispense Quantity value with unit
        if (null != healthMedication.getDispensedQuantity()) {
            Quantity dispenseQuantity = new Quantity();
            dispenseQuantity.setValue(healthMedication.getDispensedQuantity());
            if (null != healthMedication.getDispensedQuantityUnit()) {
                dispenseQuantity.setUnit(healthMedication.getDispensedQuantityUnit().getIhrTerm());
            }
            medicationDispense.setQuantity(dispenseQuantity);
        }
        //supplier
        if (null != healthMedication.getSupplier()) {
            Location location = getOrCreateNewLocation(fhirResource, healthMedication.getSupplier());
            medicationDispense.setLocation(new Reference(location));
        }
        //prescriptionId
        if (null != healthMedication.getPrescriptionId() && !healthMedication.getPrescriptionId().isEmpty()) {
            medicationDispense.addIdentifier(createIdentifier(AppUtils.jsonEscape(healthMedication.getPrescriptionId()), GlobalConstants.PRESCRIPTION_ID));
        }
        return medicationDispense;
    }

    private MedicationRequest buildMedicationRequest(FhirResource fhirResource, HealthMedication healthMedication) {

        MedicationRequest medicationRequest = new MedicationRequest();
        medicationRequest.setId(new IdType(createIdURI()));

        // requestStatus new field added
        if (null != healthMedication.getRequestStatus()) {
            medicationRequest.setStatus(MedicationRequest.MedicationRequestStatus.fromCode(healthMedication.getRequestStatus().toLowerCase()));
        }

        // requestIntent new field added
        if (null != healthMedication.getRequestIntent()) {
            medicationRequest.setIntent(MedicationRequest.MedicationRequestIntent
                    .fromCode(healthMedication.getRequestIntent().toLowerCase()));
        }
        //orderDate
        if (null != healthMedication.getOrderDate()) {
            medicationRequest.setAuthoredOnElement(toDateTimeTypeFromDate((healthMedication.getOrderDate())));
        }

        //orderingProvider
        if (null != healthMedication.getOrderingProvider()) {
            Identifier identifier = createIdentifier(healthMedication.getOrderingProvider().getOrderingProviderNPInum()
                    , GlobalConstants.NPI);
            Practitioner practitioner = getOrCreatePractitioner(fhirResource, identifier);
            medicationRequest.setRequester(new Reference(practitioner.addName(new HumanName()
                    .setText(healthMedication.getOrderingProvider().getOrderingProviderName()))));
        }

        //refillAuthorizedNumber
        if (null != healthMedication.getRefillAuthorizedNumber()) {
            medicationRequest.getDispenseRequest().setNumberOfRepeatsAllowed(healthMedication.getRefillAuthorizedNumber());
        }

        return medicationRequest;
    }

    private MedicationKnowledge buildMedicationKnowledge(FhirResource fhirResource, HealthMedication healthMedication) {

        Bundle bundle = fhirResource.getBundle();

        MedicationKnowledge medicationKnowledge = new MedicationKnowledge();
        medicationKnowledge.setId(new IdType(createIdURI()));

        // genericDrugName
        if (null != healthMedication.getGenericDrugName()) {
            medicationKnowledge.getSynonym().add(new StringType(healthMedication.getGenericDrugName()));

        }
        //productType new added field
        if (null != healthMedication.getProductType()) {
            medicationKnowledge.getProductType().add(new CodeableConcept()
                    .setText(healthMedication.getProductType()));
        }

        MedicationKnowledge.MedicationKnowledgeMedicineClassificationComponent
                classificationComponent = new MedicationKnowledge.MedicationKnowledgeMedicineClassificationComponent();
        medicationKnowledge.getMedicineClassification().add(classificationComponent);
        //classType new added field
        if (null != healthMedication.getClassType()) {
            classificationComponent.getType().setText(healthMedication.getClassType());

        }
        //drugClass
        if (null != healthMedication.getDrugClass()) {
            classificationComponent.getClassification()
                    .add(new CodeableConcept()
                            .setText(AppUtils.jsonEscape(healthMedication.getDrugClass())));
        }

        MedicationKnowledge.MedicationKnowledgeRegulatoryComponent
                knowledgeRegulatoryComponent = new MedicationKnowledge.MedicationKnowledgeRegulatoryComponent();
        medicationKnowledge.getRegulatory().add(knowledgeRegulatoryComponent);

        // regAuthority new added field
        if (null != healthMedication.getRegAuthority()) {
            Organization organization = getOrCreateOrganization(fhirResource, healthMedication.getRegAuthority());
            knowledgeRegulatoryComponent.setRegulatoryAuthority(new Reference(organization));
        }
        //deaSchedule
        if (null != healthMedication.getDeaSchedule()) {
            knowledgeRegulatoryComponent.addSchedule().getSchedule().setText(healthMedication.getDeaSchedule());
        }

        return medicationKnowledge;
    }

    private Medication buildMedication(FhirResource fhirResource, HealthMedication healthMedication) {
        Medication medication = new Medication();
        medication.setId(new IdType(createIdURI()));

        //Medication
        if (null != healthMedication.getMedication()) {
            medication.getCode().setText(healthMedication.getMedication().getIhrLaymanTerm())
                    .getCoding().add(createCoding(healthMedication.getMedication().getSourceVocabulary(),
                    healthMedication.getMedication().getSourceVocabularyCode(),
                    healthMedication.getMedication().getIhrTerm()));

            //fdbcode (need to check both should have any link or not)
            if (StringUtils.isNotBlank(healthMedication.getMedication().getFdbCode()) && StringUtils.isNotBlank(healthMedication.getMedication().getFdbCodeType())) {
                medication.getCode().getCoding().add(createCoding(GlobalConstants.FDB_CODE_URL,
                        healthMedication.getMedication().getFdbCode(),
                        null));
                medication.getCode().getCoding().add(createCoding(GlobalConstants.FDB_CODE_URL,
                        healthMedication.getMedication().getFdbCodeType(),
                        null));
            }
            //RxNormCode
            if (StringUtils.isNotBlank(healthMedication.getMedication().getRxNormCode())) {
                medication.getCode().getCoding().add(createCoding(GlobalUrlConstant.RX_NORM_CODE_URL,
                        healthMedication.getMedication().getRxNormCode(),
                        null));
            }
            //MedispanCode
            if (StringUtils.isNotBlank(healthMedication.getMedication().getMediSpanCode())) {
                medication.getCode().getCoding().add(createCoding(GlobalUrlConstant.MEDI_SPAN_CODE_URL,
                        healthMedication.getMedication().getMediSpanCode(),
                        null));
            }
        }
        //dosageForm
        if (null != healthMedication.getDosageForm()) {
            medication.getForm().setText(healthMedication.getDosageForm().getIhrLaymanTerm())
                    .getCoding().add(createCoding(healthMedication.getDosageForm().getSourceVocabulary(),
                    healthMedication.getDosageForm().getSourceVocabularyCode(),
                    healthMedication.getDosageForm().getIhrTerm()));
        }

        if (null != healthMedication.getSensitivityClasses()) {
            medication.getMeta().getSecurity()
                    .add(createCoding(GlobalUrlConstant.SECURITY_LABELS_URL, GlobalConstants.SECURITY_LABELS_CODE, null));
        }
        return medication;
    }
}
