package com.uhg.ihr.centrihealth.api.service.fhir.deferred;

import org.hl7.fhir.r4.model.Observation;

import java.util.function.Consumer;

public class ObservationDeferredMapper extends DeferredMapper<Observation> {

    public ObservationDeferredMapper(Consumer<Observation> mapper) {
        super(mapper);
    }
}
