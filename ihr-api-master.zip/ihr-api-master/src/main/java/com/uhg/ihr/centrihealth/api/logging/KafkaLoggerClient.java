package com.uhg.ihr.centrihealth.api.logging;

import io.micronaut.configuration.kafka.annotation.KafkaClient;
import io.micronaut.configuration.kafka.annotation.KafkaKey;
import io.micronaut.configuration.kafka.annotation.Topic;
import io.micronaut.context.annotation.Requires;

@Requires(property = "kafka.producers.big5logger.enabled", value = "true")
@KafkaClient("big5logger")
public interface KafkaLoggerClient {

    @Topic("${kafka.producers.big5logger.topic}")
    void logBig5(@KafkaKey String correlationId, String big5Encrypted);
}
