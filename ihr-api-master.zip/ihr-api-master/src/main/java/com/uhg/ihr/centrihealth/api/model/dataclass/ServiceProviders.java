package com.uhg.ihr.centrihealth.api.model.dataclass;

import lombok.Builder;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;

import java.math.BigInteger;
import java.util.List;

@Data
@EqualsAndHashCode(callSuper = false)
@NoArgsConstructor
public class ServiceProviders extends BaseDataClass {
    private String recordType;
    private String recordKey;
    private String providerType;
    private String relatedEntityName;
    private String relatedEntityNPInum;
    private String relatedEntityMPIN;
    private String relatedEntityRoleTerm;
    private String relationshipStartDate;
    private String relationshipEndDate;
    private List<Occupation> occupations;
    private List<String> referenceIds;

    @Builder
    public ServiceProviders(BigInteger objectId, String recordType, String recordKey, String providerType, String relatedEntityName, String relatedEntityNPInum, String relatedEntityMPIN, String relatedEntityRoleTerm, String relationshipStartDate, String relationshipEndDate, List<Occupation> occupations, List<String> referenceIds) {
        super(objectId);
        this.recordType = recordType;
        this.recordKey = recordKey;
        this.providerType = providerType;
        this.relatedEntityName = relatedEntityName;
        this.relatedEntityNPInum = relatedEntityNPInum;
        this.relatedEntityMPIN = relatedEntityMPIN;
        this.relatedEntityRoleTerm = relatedEntityRoleTerm;
        this.relationshipStartDate = relationshipStartDate;
        this.relationshipEndDate = relationshipEndDate;
        this.occupations = occupations;
        this.referenceIds = referenceIds;
    }
}
