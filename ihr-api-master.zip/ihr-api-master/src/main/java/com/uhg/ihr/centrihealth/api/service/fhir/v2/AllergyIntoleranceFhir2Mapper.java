package com.uhg.ihr.centrihealth.api.service.fhir.v2;

import com.uhg.ihr.centrihealth.api.constant.GlobalConstants;
import com.uhg.ihr.centrihealth.api.constant.GlobalUrlConstant;
import com.uhg.ihr.centrihealth.api.model.FhirResource;
import com.uhg.ihr.centrihealth.api.model.dataclass.AdverseReaction;
import com.uhg.ihr.centrihealth.api.model.dataclass.DataClass;
import com.uhg.ihr.centrihealth.api.model.dataclass.IhrTerm;
import com.uhg.ihr.centrihealth.api.model.dataclass.Note;
import com.uhg.ihr.centrihealth.api.model.dataclass.Reaction;
import com.uhg.ihr.centrihealth.api.service.fhir.FhirMapper;
import com.uhg.ihr.centrihealth.api.service.fhir.PatientEnum;
import com.uhg.ihr.centrihealth.api.service.fhir.PractitionerRoleEnum;
import com.uhg.ihr.centrihealth.api.service.fhir.RelatedPersonEnum;
import com.uhg.ihr.centrihealth.api.util.AppUtils;
import io.micrometer.core.instrument.util.StringUtils;
import io.micronaut.core.util.CollectionUtils;
import lombok.Value;
import lombok.extern.slf4j.Slf4j;
import org.hl7.fhir.r4.model.AllergyIntolerance;
import org.hl7.fhir.r4.model.Bundle;
import org.hl7.fhir.r4.model.CodeableConcept;
import org.hl7.fhir.r4.model.Coding;
import org.hl7.fhir.r4.model.IdType;
import org.hl7.fhir.r4.model.Meta;
import org.hl7.fhir.r4.model.Patient;
import org.hl7.fhir.r4.model.Period;
import org.hl7.fhir.r4.model.Practitioner;
import org.hl7.fhir.r4.model.PractitionerRole;
import org.hl7.fhir.r4.model.Reference;
import org.hl7.fhir.r4.model.RelatedPerson;
import org.hl7.fhir.r4.model.StringType;

@Slf4j
@Value(staticConstructor = "of")
public class AllergyIntoleranceFhir2Mapper implements FhirMapper<AdverseReaction, AllergyIntolerance> {

    @Override
    public void map(FhirResource fhirResource, DataClass dataClasses) {
        if (dataClasses != null && CollectionUtils.isNotEmpty(dataClasses.getAdverseReactions())) {
            map(fhirResource, dataClasses.getAdverseReactions());
        }
    }

    @Override
    public void map(final FhirResource fhirResource, final AdverseReaction adverseReaction) {
        Bundle bundle = fhirResource.getBundle();

        AllergyIntolerance allergyIntolerance = buildAllergyIntolerance(fhirResource, adverseReaction);
        //add resource in bundle
        bundle.addEntry().setFullUrl(allergyIntolerance.getId()).setResource(allergyIntolerance);

    }

    private AllergyIntolerance buildAllergyIntolerance(FhirResource fhirResource, AdverseReaction adverseReaction) {

        Patient patient = fhirResource.getPatient();

        AllergyIntolerance allergyIntolerance = new AllergyIntolerance();
        allergyIntolerance.setId(new IdType(createIdURI()));

        //recordKey
        if (null != adverseReaction.getRecordKey()) {
            allergyIntolerance.addIdentifier(createIdentifier(adverseReaction.getRecordKey(), GlobalConstants.RECORD_KEY));
        }
        //object id
        if (null != adverseReaction.getObjectId()) {
            allergyIntolerance.addIdentifier(createIdentifier(adverseReaction.getObjectId().toString(), GlobalConstants.OBJECT_ID));
        }

        //adversereactiontype  need to check no mapping found in doc
      /* if (null != adverseReaction.getAdversereactiontype()) {
            allergyIntolerance.setType(AllergyIntolerance.AllergyIntoleranceType.
                    fromCode(adverseReaction.getAdversereactiontype().getIhrTerm()));
        }*/

        // allergyIntoleranceType
        if (StringUtils.isNotEmpty(adverseReaction.getAllergyIntoleranceType())) {
            allergyIntolerance.setType(AllergyIntolerance.AllergyIntoleranceType.
                    fromCode(adverseReaction.getAllergyIntoleranceType()));
        }

        // allergens should be Array of object not object
        if (null != adverseReaction.getAllergens() && !adverseReaction.getAllergens().isEmpty()) {
            for (IhrTerm term : adverseReaction.getAllergens()) {

                allergyIntolerance.getCode().setText(term.getIhrLaymanTerm())
                        .addCoding(createCoding(term.getSourceVocabulary(), term.getSourceVocabularyCode(), term.getIhrTerm()));

            }
        }

        // allergenCategory
        if (StringUtils.isNotBlank(adverseReaction.getAllergenCategory())) {
            allergyIntolerance.addCategory(AllergyIntolerance.AllergyIntoleranceCategory
                    .fromCode(adverseReaction.getAllergenCategory().toLowerCase()));
        }

        //reference id
        if (CollectionUtils.isNotEmpty(adverseReaction.getReferenceIds())) {
            allergyIntolerance.addIdentifier(createIdentifier(AppUtils.jsonEscape(adverseReaction.getReferenceIds()),
                    GlobalConstants.REFERENCE_IDS));
        }

        // asserterObject
        if (null != adverseReaction.getAsserterObject() && null != adverseReaction.getAsserterObject().getSourceVocabularyCode()) {
            if (RelatedPersonEnum.ENUM_VALUES.contains(adverseReaction.getAsserterObject().getSourceVocabularyCode())) {
                CodeableConcept relationShip = new CodeableConcept().setText(adverseReaction.getAsserterObject().getSourceVocabularyCode());
                RelatedPerson relatedPerson = getOrCreateRelatedPerson(fhirResource, relationShip);
                allergyIntolerance.setAsserter(new Reference(relatedPerson));

            } else if (PractitionerRoleEnum.ENUM_VALUES.contains(adverseReaction.getAsserterObject().getSourceVocabularyCode())) {
                CodeableConcept practitionerCode = new CodeableConcept().setText(adverseReaction.getAsserterObject().getSourceVocabularyCode());
                PractitionerRole practitionerRole = getOrCreatePractitionerRole(fhirResource, practitionerCode);
                allergyIntolerance.setAsserter(new Reference(practitionerRole));
            } else if (PatientEnum.ENUM_VALUES.contains(adverseReaction.getAsserterObject().getIhrTerm())) {
                allergyIntolerance.setAsserter(new Reference(patient));
            }
        }

        // recorderId
        if (StringUtils.isNotBlank(adverseReaction.getRecorderId())) {
            Practitioner practitioner = getOrCreatePractitioner(fhirResource,
                    createIdentifier(adverseReaction.getRecorderId(), GlobalConstants.EMPLOYEE_ID));
            allergyIntolerance.setRecorder(new Reference(practitioner));
        }

        // recordedDate
        if (StringUtils.isNotBlank(adverseReaction.getRecordedDate())) {
            allergyIntolerance.setRecordedDateElement(toDateTimeTypeFromDate(adverseReaction.getRecordedDate()));
        }

        //reactionsFHIR(add Manifestation,  Severity)
        if (null != adverseReaction.getReactionsFHIR() && !adverseReaction.getReactionsFHIR().isEmpty()) {
            AllergyIntolerance.AllergyIntoleranceReactionComponent component
                    = new AllergyIntolerance.AllergyIntoleranceReactionComponent();
            for (Reaction reaction : adverseReaction.getReactionsFHIR()) {
                component.addManifestation().setText(reaction.getConcept().getIhrLaymanTerm())
                        .addCoding(createCoding(reaction.getConcept().getSourceVocabulary(),
                                reaction.getConcept().getSourceVocabularyCode(), reaction.getConcept().getIhrTerm())
                        );
                if (null != reaction.getSeverity().getIhrTerm()) {
                    component.setSeverity(AllergyIntolerance.AllergyIntoleranceSeverity
                            .fromCode(reaction.getSeverity().getIhrTerm().toLowerCase()));//need to check
                }
                allergyIntolerance.getReaction().add(component);
            }
        }

        //status
        if (null != adverseReaction.getStatus()) {
            allergyIntolerance.setClinicalStatus(new CodeableConcept()
                    .setText(adverseReaction.getStatus().getIhrTerm()));
        }
        //notes
        if (null != adverseReaction.getNote()) {
            for (Note note : adverseReaction.getNote()) {
                allergyIntolerance.addNote(createNote(patient, note, fhirResource));
            }
        }

        //presence state term
        if (StringUtils.isNotBlank(adverseReaction.getPresenceStateTerm())) {
            allergyIntolerance.addExtension(GlobalUrlConstant.PRESENCESTATE_URL, new StringType(adverseReaction.getPresenceStateTerm()));
        }

        //Onset period start date
        Period onsetPeriod = new Period();
        if (StringUtils.isNotEmpty(adverseReaction.getOnsetPeriodStart())) {
            allergyIntolerance.setOnset(onsetPeriod.setStartElement(toDateTimeTypeFromDate(adverseReaction.getOnsetPeriodStart())));
        }
        //Onset period end date
        if (StringUtils.isNotEmpty(adverseReaction.getOnsetPeriodEnd())) {
            allergyIntolerance.setOnset(onsetPeriod.setEndElement(toDateTimeTypeFromDate(adverseReaction.getOnsetPeriodEnd())));
        }

        //Clinically relevant date
        if (StringUtils.isNotBlank(adverseReaction.getClinicallyRelevantDate())) {
            allergyIntolerance.addExtension(GlobalUrlConstant.CLINICAL_RELEVANT_DATE_URL,
                    toDateTimeTypeFromDate(adverseReaction.getClinicallyRelevantDate()));
        }

        //Start Date
        if (StringUtils.isNotBlank(adverseReaction.getStartDate())) {
            allergyIntolerance.addExtension(GlobalUrlConstant.START_DATE_URL, toDateTypeFromDate(adverseReaction.getStartDate()));
        }
        //last updated date
        if (StringUtils.isNotBlank(adverseReaction.getLastUpdateDate())) {
            allergyIntolerance.setMeta(new Meta().setLastUpdatedElement(toInstantTypeFromDate(adverseReaction.getLastUpdateDate())));
        }

        //sensitivity classes
        if (CollectionUtils.isNotEmpty(adverseReaction.getSensitivityClasses())) {
            allergyIntolerance.getMeta().getSecurity()
                    .add(new Coding().setSystem(GlobalUrlConstant.SECURITY_LABELS_URL).setCode(GlobalConstants.SECURITY_LABELS_CODE));
        }

        //add patient
        allergyIntolerance.setPatient(new Reference(patient));

        return allergyIntolerance;

    }
}
