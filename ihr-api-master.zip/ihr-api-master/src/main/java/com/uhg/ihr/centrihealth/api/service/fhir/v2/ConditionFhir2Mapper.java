package com.uhg.ihr.centrihealth.api.service.fhir.v2;

import com.uhg.ihr.centrihealth.api.constant.GlobalConstants;
import com.uhg.ihr.centrihealth.api.constant.GlobalUrlConstant;
import com.uhg.ihr.centrihealth.api.model.FhirResource;
import com.uhg.ihr.centrihealth.api.model.dataclass.DataClass;
import com.uhg.ihr.centrihealth.api.model.dataclass.HealthCondition;
import com.uhg.ihr.centrihealth.api.model.dataclass.Note;
import com.uhg.ihr.centrihealth.api.service.fhir.FhirMapper;
import com.uhg.ihr.centrihealth.api.service.fhir.PatientEnum;
import com.uhg.ihr.centrihealth.api.service.fhir.PractitionerRoleEnum;
import com.uhg.ihr.centrihealth.api.service.fhir.RelatedPersonEnum;
import com.uhg.ihr.centrihealth.api.util.AppUtils;
import io.micrometer.core.instrument.util.StringUtils;
import lombok.Value;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections.CollectionUtils;
import org.hl7.fhir.r4.model.Bundle;
import org.hl7.fhir.r4.model.CodeableConcept;
import org.hl7.fhir.r4.model.Coding;
import org.hl7.fhir.r4.model.Condition;
import org.hl7.fhir.r4.model.IdType;
import org.hl7.fhir.r4.model.Identifier;
import org.hl7.fhir.r4.model.Meta;
import org.hl7.fhir.r4.model.Patient;
import org.hl7.fhir.r4.model.Practitioner;
import org.hl7.fhir.r4.model.PractitionerRole;
import org.hl7.fhir.r4.model.Reference;
import org.hl7.fhir.r4.model.RelatedPerson;
import org.hl7.fhir.r4.model.StringType;

@Slf4j
@Value(staticConstructor = "of")
public class ConditionFhir2Mapper implements FhirMapper<HealthCondition, Condition> {

    @Override
    public void map(FhirResource fhirResource, DataClass dataClasses) {
        if (dataClasses != null && CollectionUtils.isNotEmpty(dataClasses.getConditions())) {
            map(fhirResource, dataClasses.getConditions());
        }
    }

    @Override
    public void map(FhirResource fhirResource, HealthCondition healthCondition) {

        Patient patient = fhirResource.getPatient();
        Bundle bundle = fhirResource.getBundle();
        //Condition
        Condition condition = buildCondition(fhirResource, healthCondition);
        condition.setSubject(new Reference(patient));

        // add resource to deferred mapper
        fhirResource.addFhirResourceToDeferredMapper(condition, healthCondition);

        // add resource into bundle
        bundle.addEntry().setFullUrl(condition.getId()).setResource(condition);
    }

    private Condition buildCondition(FhirResource fhirResource, HealthCondition healthCondition) {
        Patient patient = fhirResource.getPatient();
        Condition condition = new Condition();
        condition.setId(new IdType(createIdURI()));

        //Last Update Date
        if (StringUtils.isNotBlank(healthCondition.getLastUpdateDate())) {
            condition.setMeta(new Meta().setLastUpdatedElement(toInstantTypeFromDate(healthCondition.getLastUpdateDate())));
        }
        //sensitivity classes
        if (CollectionUtils.isNotEmpty(healthCondition.getSensitivityClasses())) {
            condition.getMeta().getSecurity()
                    .add(new Coding().setSystem(GlobalUrlConstant.SECURITY_LABELS_URL).setCode(GlobalConstants.SECURITY_LABELS_CODE));
        }
        //recordKey
        if (null != healthCondition.getRecordKey()) {
            condition.addIdentifier(createIdentifier(healthCondition.getRecordKey(), GlobalConstants.RECORD_KEY));
        }
        //object id
        if (null != healthCondition.getObjectId()) {
            condition.addIdentifier(createIdentifier(healthCondition.getObjectId().toString(), GlobalConstants.OBJECT_ID));
        }
        //reference id
        if (CollectionUtils.isNotEmpty(healthCondition.getReferenceIds())) {
            condition.addIdentifier(createIdentifier(AppUtils.jsonEscape(healthCondition.getReferenceIds()),
                    GlobalConstants.REFERENCE_IDS));
        }
        //health condition
        if (null != healthCondition.getHealthCondition()) {
            condition.getCode().setText(healthCondition.getHealthCondition().getIhrLaymanTerm())
                    .addCoding(createCoding(healthCondition.getHealthCondition().getSourceVocabulary(),
                            healthCondition.getHealthCondition().getSourceVocabularyCode(),
                            healthCondition.getHealthCondition().getIhrTerm()));

            if (StringUtils.isNotBlank(healthCondition.getHealthCondition().getIcd10cmCode())) {
                condition.getCode().addCoding(createCoding(GlobalUrlConstant.ICD_10_CM_URL,
                        healthCondition.getHealthCondition().getIcd10cmCode(), ""));
            }
        }
        //clinicalCourse    (Condition.stage.summary.text) new mapping added
        if (StringUtils.isNotBlank(healthCondition.getClinicalCourse())) {
            condition.addStage(new Condition.ConditionStageComponent().setSummary(new CodeableConcept().setText(healthCondition.getClinicalCourse())));
        }
        //status
        if (null != healthCondition.getStatus() && null != healthCondition.getStatus().getIhrTerm()) {
            condition.setClinicalStatus(new CodeableConcept().setText(healthCondition.getStatus().getIhrTerm()));
        }
        //presence state term
        if (StringUtils.isNotBlank(healthCondition.getPresenceStateTerm())) {
            condition.addExtension(GlobalUrlConstant.PRESENCESTATE_URL, new StringType(healthCondition.getPresenceStateTerm()));
        }
        // asserterObject
        if (null != healthCondition.getAsserterObject() && null != healthCondition.getAsserterObject().getSourceVocabularyCode()) {
            if (RelatedPersonEnum.ENUM_VALUES.contains(healthCondition.getAsserterObject().getSourceVocabularyCode())) {
                CodeableConcept relationShip = new CodeableConcept().setText(healthCondition.getAsserterObject().getSourceVocabularyCode());
                RelatedPerson relatedPerson = getOrCreateRelatedPerson(fhirResource, relationShip);
                condition.setAsserter(new Reference(relatedPerson));

            } else if (PractitionerRoleEnum.ENUM_VALUES.contains(healthCondition.getAsserterObject().getSourceVocabularyCode())) {
                CodeableConcept practitionerCode = new CodeableConcept().setText(healthCondition.getAsserterObject().getSourceVocabularyCode());
                PractitionerRole practitionerRole = getOrCreatePractitionerRole(fhirResource, practitionerCode);
                condition.setAsserter(new Reference(practitionerRole));
            } else if (PatientEnum.ENUM_VALUES.contains(healthCondition.getAsserterObject().getIhrTerm())) {
                condition.setAsserter(new Reference(patient));
            }
        }
        //recordedId
        if (StringUtils.isNotBlank(healthCondition.getRecorderId())) {
            Identifier identifier = createIdentifier(healthCondition.getRecorderId(),
                    GlobalConstants.EMPLOYEE_ID);
            Practitioner practitioner = getOrCreatePractitioner(fhirResource, identifier);
            condition.setRecorder(new Reference(practitioner));
        }
        //recorded Date
        if (StringUtils.isNotEmpty(healthCondition.getRecordedDate())) {
            condition.setRecordedDateElement(toDateTimeTypeFromDate(healthCondition.getRecordedDate()));
        }
        //Onset period start
        if (StringUtils.isNotEmpty(healthCondition.getOnsetPeriodStart())) {
            condition.setOnset(toDateTimeTypeFromDate(healthCondition.getOnsetPeriodStart()));
        }
        //onsetPeriodEnd
        if (StringUtils.isNotEmpty(healthCondition.getOnsetPeriodEnd())) {
            condition.setAbatement(toDateTimeTypeFromDate(healthCondition.getOnsetPeriodEnd()));
        }
        //notes
        if (null != healthCondition.getNote()) {
            for (Note note : healthCondition.getNote()) {
                condition.addNote(createNote(patient, note, fhirResource));
            }
        }
        //Clinically relevant date
        if (StringUtils.isNotBlank(healthCondition.getClinicallyRelevantDate())) {
            condition.addExtension(GlobalUrlConstant.CLINICAL_RELEVANT_DATE_URL, toDateTimeTypeFromDate(healthCondition.getClinicallyRelevantDate()));

        }
        //condition start date
        if (StringUtils.isNotBlank(healthCondition.getConditionStartDate())) {
            condition.addExtension(GlobalUrlConstant.START_DATE_URL, toDateTimeTypeFromDate(healthCondition.getConditionStartDate()));
        }
        //related conditions
        if (CollectionUtils.isNotEmpty(healthCondition.getRelatedConditions())) {
            condition.addIdentifier(createIdentifier(AppUtils.jsonEscape(healthCondition.getRelatedConditions())
                    , GlobalConstants.RELATED_CONDITION_INSTANCE_IDS));
        }
        //related observations
        if (CollectionUtils.isNotEmpty(healthCondition.getRelatedObservations())) {
            condition.addIdentifier(createIdentifier(AppUtils.jsonEscape(healthCondition.getRelatedObservations())
                    , GlobalConstants.RELATED_OBSERVATION_INSTANCE_IDS));
        }
        //related care team
        if (CollectionUtils.isNotEmpty(healthCondition.getRelatedCareTeam())) {
            condition.addIdentifier(createIdentifier(AppUtils.jsonEscape(healthCondition.getRelatedCareTeam())
                    , GlobalConstants.RELATED_CARE_TEAM_INSTANCE_IDS));
        }
        //source claim ids
        if (CollectionUtils.isNotEmpty(healthCondition.getSourceClaimIds())) {
            condition.addIdentifier(createIdentifier(AppUtils.jsonEscape(healthCondition.getSourceClaimIds())
                    , GlobalConstants.SOURCE_CLAIM_IDS));
        }

        return condition;
    }
}