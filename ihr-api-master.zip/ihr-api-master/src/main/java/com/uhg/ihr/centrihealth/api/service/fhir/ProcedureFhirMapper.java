package com.uhg.ihr.centrihealth.api.service.fhir;

import com.uhg.ihr.centrihealth.api.model.FhirResource;
import com.uhg.ihr.centrihealth.api.model.dataclass.Constants;
import com.uhg.ihr.centrihealth.api.model.dataclass.DataClass;
import com.uhg.ihr.centrihealth.api.model.dataclass.IhrTerm;
import com.uhg.ihr.centrihealth.api.model.dataclass.Note;
import com.uhg.ihr.centrihealth.api.model.dataclass.ProcedureHistory;
import com.uhg.ihr.centrihealth.api.service.fhir.deferred.ObservationDeferredMapper;
import com.uhg.ihr.centrihealth.api.util.AppUtils;
import io.micrometer.core.instrument.util.StringUtils;
import lombok.Value;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections.CollectionUtils;
import org.hl7.fhir.r4.model.Bundle;
import org.hl7.fhir.r4.model.CodeableConcept;
import org.hl7.fhir.r4.model.Coding;
import org.hl7.fhir.r4.model.IdType;
import org.hl7.fhir.r4.model.Meta;
import org.hl7.fhir.r4.model.Patient;
import org.hl7.fhir.r4.model.Procedure;
import org.hl7.fhir.r4.model.Reference;
import org.hl7.fhir.r4.model.ServiceRequest;
import org.hl7.fhir.r4.model.Specimen;
import org.hl7.fhir.r4.model.StringType;

@Slf4j
@Value(staticConstructor = "of")
public class ProcedureFhirMapper implements FhirMapper<ProcedureHistory, Procedure> {

    @Override
    public void map(FhirResource fhirResource, DataClass dataClasses) {
        if (dataClasses != null && CollectionUtils.isNotEmpty(dataClasses.getProcedureHistory())) {
            map(fhirResource, dataClasses.getProcedureHistory());
        }
    }

    @Override
    public void map(FhirResource fhirResource, ProcedureHistory procedureHistory) {
        Patient patient = fhirResource.getPatient();
        Bundle bundle = fhirResource.getBundle();

        Procedure procedure = new Procedure();
        procedure.setId(new IdType(createIdURI()));

        ServiceRequest serviceRequest = null;

        //record key
        if (StringUtils.isNotBlank(procedureHistory.getRecordKey())) {
            procedure.addIdentifier().setValue(procedureHistory.getRecordKey())
                    .setType(new CodeableConcept().setText(Constants.RECORD_KEY));
        }
        //object id
        if (null != procedureHistory.getObjectId()) {
            procedure.addIdentifier().setValue(procedureHistory.getObjectId().toString())
                    .setType(new CodeableConcept().setText(Constants.INSTANCE_ID));
        }
        //reference id
        if (CollectionUtils.isNotEmpty(procedureHistory.getReferenceIds())) {
            procedure.addIdentifier().setValue(AppUtils.jsonEscape(procedureHistory.getReferenceIds()))
                    .setType(new CodeableConcept().setText(Constants.REFERENCE_IDS));
        }
        //health event
        if (null != procedureHistory.getHealthEvent()) {
            procedure.setCode(new CodeableConcept().setText(procedureHistory.getHealthEvent().getIhrLaymanTerm())
                    .addCoding(new Coding()
                            .setDisplay(procedureHistory.getHealthEvent().getIhrTerm())
                            .setSystem(procedureHistory.getHealthEvent().getSourceVocabulary())
                            .setCode(procedureHistory.getHealthEvent().getSourceVocabularyCode())));
            if (StringUtils.isNotBlank(procedureHistory.getHealthEvent().getCpthcpcsCode())) {
                procedure.getCode()
                        .addCoding(new Coding()
                                .setSystem(Constants.CPTHCPCS_CODE_URL)
                                .setCode(procedureHistory.getHealthEvent().getCpthcpcsCode()));
            }
            if (StringUtils.isNotBlank(procedureHistory.getHealthEvent().getMedicalDomain())) {
                procedure.addExtension(Constants.MEDICAL_DOMAIN_URL, new StringType(procedureHistory.getHealthEvent().getMedicalDomain()));
            }
        }
        //presence state term
        if (StringUtils.isNotBlank(procedureHistory.getPresenceStateTerm())) {
            procedure.addExtension(Constants.PRESENCE_STATE_TERM_URL, new StringType(procedureHistory.getPresenceStateTerm()));
        }
        //status
        if (null != procedureHistory.getHealthEventStatus()) {
            procedure.addExtension(Constants.STATUS_URL, new CodeableConcept()
                    .setText(procedureHistory.getHealthEventStatus().getIhrLaymanTerm())
                    .addCoding(new Coding()
                            .setDisplay(procedureHistory.getHealthEventStatus().getIhrTerm())
                            .setSystem(procedureHistory.getHealthEventStatus().getSourceVocabulary())
                            .setCode(procedureHistory.getHealthEventStatus().getSourceVocabularyCode())));
        }
        //health event category text
        if (StringUtils.isNotBlank(procedureHistory.getHealthEventCategoryText())) {
            procedure.addExtension(Constants.IHR_PROCEDURE_CATEGORY_TEXT, new StringType(procedureHistory.getHealthEventCategoryText()));
        }
        //specimens
        if (null != procedureHistory.getSpecimens() && !procedureHistory.getSpecimens().isEmpty()) {
            for (IhrTerm term : procedureHistory.getSpecimens()) {
                serviceRequest = new ServiceRequest();
                Specimen specimen = getOrCreateSpecimen(fhirResource, term);
                serviceRequest.addSpecimen(new Reference(specimen));
            }
        }
        //health event date
        if (StringUtils.isNotBlank(procedureHistory.getHealthEventDate())) {
            procedure.setPerformed(toDateTimeTypeFromDate(procedureHistory.getHealthEventDate()));
        }
        //Clinically relevant date
        if (StringUtils.isNotBlank(procedureHistory.getClinicallyRelevantDate())) {
            procedure.addExtension(Constants.CLINICALLY_RELEVANT_DATE_URL, toDateTimeTypeFromDate(procedureHistory.getClinicallyRelevantDate()));
        }
        //health event order date
        if (StringUtils.isNotBlank(procedureHistory.getHealthEventOrderDate())) {
            if (null == serviceRequest) {
                serviceRequest = new ServiceRequest();
            }
            serviceRequest.setAuthoredOnElement(toDateTimeTypeFromDate(procedureHistory.getHealthEventOrderDate()));
        }
        //last update date
        if (StringUtils.isNotBlank(procedureHistory.getLastUpdateDate())) {
            procedure.setMeta(new Meta().setLastUpdatedElement(toInstantTypeFromDate(procedureHistory.getLastUpdateDate())));
        }
        // note
        if (CollectionUtils.isNotEmpty(procedureHistory.getNote())) {
            for (Note note : procedureHistory.getNote()) {
                procedure.addNote(getAnnotation(patient, note, fhirResource));
            }
        }
        //related devices
        if (CollectionUtils.isNotEmpty(procedureHistory.getRelatedConditions())) {
            procedure.addIdentifier()
                    .setValue(AppUtils.jsonEscape(procedureHistory.getRelatedConditions()))
                    .setType(new CodeableConcept().setText(Constants.RELATED_CONDITION_INSTANCE_IDS));
        }
        //related observations
        if (CollectionUtils.isNotEmpty(procedureHistory.getRelatedObservations())) {
            procedure.addIdentifier()
                    .setValue(AppUtils.jsonEscape(procedureHistory.getRelatedObservations()))
                    .setType(new CodeableConcept().setText(Constants.RELATED_OBSERVATION_INSTANCE_IDS));
        }
        //related care team
        if (CollectionUtils.isNotEmpty(procedureHistory.getRelatedCareTeam())) {
            procedure.addIdentifier()
                    .setValue(AppUtils.jsonEscape(procedureHistory.getRelatedCareTeam()))
                    .setType(new CodeableConcept().setText(Constants.RELATED_CARE_TEAM_INSTANCE_IDS));
        }
        //related care team
        if (CollectionUtils.isNotEmpty(procedureHistory.getRelatedServiceProviders())) {
            procedure.addIdentifier()
                    .setValue(AppUtils.jsonEscape(procedureHistory.getRelatedServiceProviders()))
                    .setType(new CodeableConcept().setText(Constants.RELATED_SERVICE_FACILITY_PROVIDER_INSTANCE_IDS));
        }
        //sensitivity class
        if (CollectionUtils.isNotEmpty(procedureHistory.getSensitivityClasses())) {
            procedure.addExtension(Constants.SENSITIVITY_CLASSES_URL, new StringType(AppUtils.jsonEscape(procedureHistory.getSensitivityClasses())));
        }
        //source claim ids
        if (CollectionUtils.isNotEmpty(procedureHistory.getSourceClaimIds())) {
            procedure.addIdentifier()
                    .setValue(AppUtils.jsonEscape(procedureHistory.getSourceClaimIds()))
                    .setType(new CodeableConcept().setText(Constants.SOURCE_CLAIM_IDS));
        }
        //data sources
        if (CollectionUtils.isNotEmpty(procedureHistory.getDataSource())) {
            procedure.addExtension(Constants.DATA_SOURCE_URL, new StringType(AppUtils.jsonEscape(procedureHistory.getDataSource())));
        }
        if (null != serviceRequest) {
            serviceRequest.setId(new IdType(createIdURI()));
            procedure.addBasedOn(new Reference(serviceRequest));
            bundle.addEntry().setFullUrl(serviceRequest.getId()).setResource(serviceRequest);
        }
        //related observations references
        if (CollectionUtils.isNotEmpty(procedureHistory.getRelatedObservations())) {
            ObservationDeferredMapper referencer = new ObservationDeferredMapper(observation -> observation.addPartOf(new Reference(procedure)));
            procedureHistory.getRelatedObservations().forEach(objectId -> fhirResource.addDeferredFhirMapper(objectId, referencer));
        }
        procedure.setSubject(new Reference(patient));

        //add resource in bundle
        bundle.addEntry().setFullUrl(procedure.getId()).setResource(procedure);
    }
}
