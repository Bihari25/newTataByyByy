package com.uhg.ihr.centrihealth.api.service.fhir;

import com.uhg.ihr.centrihealth.api.model.FhirResource;
import com.uhg.ihr.centrihealth.api.model.dataclass.AdverseReaction;
import com.uhg.ihr.centrihealth.api.model.dataclass.Constants;
import com.uhg.ihr.centrihealth.api.model.dataclass.DataClass;
import com.uhg.ihr.centrihealth.api.model.dataclass.IhrTerm;
import com.uhg.ihr.centrihealth.api.model.dataclass.Note;
import com.uhg.ihr.centrihealth.api.model.dataclass.Reaction;
import com.uhg.ihr.centrihealth.api.util.AppUtils;
import io.micrometer.core.instrument.util.StringUtils;
import lombok.Value;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections.CollectionUtils;
import org.hl7.fhir.r4.model.AllergyIntolerance;
import org.hl7.fhir.r4.model.Bundle;
import org.hl7.fhir.r4.model.CodeableConcept;
import org.hl7.fhir.r4.model.Coding;
import org.hl7.fhir.r4.model.IdType;
import org.hl7.fhir.r4.model.Identifier;
import org.hl7.fhir.r4.model.Meta;
import org.hl7.fhir.r4.model.Patient;
import org.hl7.fhir.r4.model.Period;
import org.hl7.fhir.r4.model.Practitioner;
import org.hl7.fhir.r4.model.PractitionerRole;
import org.hl7.fhir.r4.model.Reference;
import org.hl7.fhir.r4.model.RelatedPerson;
import org.hl7.fhir.r4.model.StringType;

@Slf4j
@Value(staticConstructor = "of")
public class AllergyIntoleranceFhirMapper implements FhirMapper<AdverseReaction, AllergyIntolerance> {
    
    @Override
    public void map(FhirResource fhirResource, DataClass dataClasses) {
        if (dataClasses != null && CollectionUtils.isNotEmpty(dataClasses.getAdverseReactions())) {
            map(fhirResource, dataClasses.getAdverseReactions());
        }
    }

    @Override
    public void map(final FhirResource fhirResource, final AdverseReaction adverseReaction) {
        Bundle bundle = fhirResource.getBundle();
        Patient patient = fhirResource.getPatient();

        AllergyIntolerance allergyIntolerance = new AllergyIntolerance();
        allergyIntolerance.setId(new IdType(createIdURI()));

        //record key
        if (null != adverseReaction.getRecordKey()) {
            allergyIntolerance.addIdentifier().setValue(adverseReaction.getRecordKey())
                    .setType(new CodeableConcept().setText(Constants.RECORD_KEY));
        }
        //reference id
        if (CollectionUtils.isNotEmpty(adverseReaction.getReferenceIds())) {
            allergyIntolerance.addIdentifier().setValue(AppUtils.jsonEscape(adverseReaction.getReferenceIds()))
                    .setType(new CodeableConcept().setText(Constants.REFERENCE_IDS));
        }
        //object id
        if (null != adverseReaction.getObjectId()) {
            allergyIntolerance.addIdentifier()
                    .setValue(adverseReaction.getObjectId().toString())
                    .setType(new CodeableConcept().setText(Constants.INSTANCE_ID));
        }
        //add patient
        allergyIntolerance.setPatient(new Reference(patient));

        // asserterObject
        if (null != adverseReaction.getAsserterObject() && null != adverseReaction.getAsserterObject().getSourceVocabularyCode()) {
            if (RelatedPersonEnum.ENUM_VALUES.contains(adverseReaction.getAsserterObject().getSourceVocabularyCode())) {
                CodeableConcept relationShip = new CodeableConcept().setText(adverseReaction.getAsserterObject().getSourceVocabularyCode());
                RelatedPerson relatedPerson = getOrCreateRelatedPerson(fhirResource, relationShip);
                allergyIntolerance.setAsserter(new Reference(relatedPerson));

            } else if (PractitionerRoleEnum.ENUM_VALUES.contains(adverseReaction.getAsserterObject().getSourceVocabularyCode())) {
                CodeableConcept practitionerCode = new CodeableConcept().setText(adverseReaction.getAsserterObject().getSourceVocabularyCode());
                PractitionerRole practitionerRole = getOrCreatePractitionerRole(fhirResource, practitionerCode);
                allergyIntolerance.setAsserter(new Reference(practitionerRole));
            } else if (PatientEnum.ENUM_VALUES.contains(adverseReaction.getAsserterObject().getIhrTerm())) {
                allergyIntolerance.setAsserter(new Reference(patient));
            }
        }
        //recorderId
        if (StringUtils.isNotBlank(adverseReaction.getRecorderId())) {
            Identifier identifier = new Identifier()
                    .setValue(adverseReaction.getRecorderId())
                    .setType(new CodeableConcept().setText(Constants.EMPLOYEE_ID));
            Practitioner practitioner = getOrCreatePractitioner(fhirResource, identifier);
            allergyIntolerance.setRecorder(new Reference(practitioner));
        }
        // recordedDate
        if (StringUtils.isNotBlank(adverseReaction.getRecordedDate())) {
            allergyIntolerance.setRecordedDateElement(toDateTimeTypeFromDate(adverseReaction.getRecordedDate()));
        }
        //adverse reaction type
        if (null != adverseReaction.getAdversereactiontype()) {
            allergyIntolerance.setCode(new CodeableConcept()
                    .setText(adverseReaction.getAdversereactiontype().getIhrLaymanTerm())
                    .addCoding(new Coding()
                            .setDisplay(adverseReaction.getAdversereactiontype().getIhrTerm())
                            .setSystem(adverseReaction.getAdversereactiontype().getSourceVocabulary())
                            .setCode(adverseReaction.getAdversereactiontype().getSourceVocabularyCode())));
            if (StringUtils.isNotBlank(adverseReaction.getAdversereactiontype().getIcd10cmCode())) {
                allergyIntolerance.getCode().addCoding(new Coding()
                        .setCode(adverseReaction.getAdversereactiontype().getIcd10cmCode())
                        .setSystem(Constants.ICD_10_CM_CODE_URL));
            }
        }
        //allergenCategory
        if (StringUtils.isNotBlank(adverseReaction.getAllergenCategory())) {
            allergyIntolerance.addCategory(AllergyIntolerance.AllergyIntoleranceCategory
                    .fromCode(adverseReaction.getAllergenCategory()));
        }
        AllergyIntolerance.AllergyIntoleranceReactionComponent component
                = allergyIntolerance.addReaction();
        //allergens
        if (null != adverseReaction.getAllergens() && !adverseReaction.getAllergens().isEmpty()) {
            for (IhrTerm term : adverseReaction.getAllergens()) {

                component.setSubstance(new CodeableConcept()
                        .setText(term.getIhrLaymanTerm())
                        .addCoding(new Coding()
                                .setDisplay(term.getIhrTerm())
                                .setSystem(term.getSourceVocabulary())
                                .setCode(term.getSourceVocabularyCode())));
            }
        }
        //reactionsFHIR
        if (null != adverseReaction.getReactionsFHIR() && !adverseReaction.getReactionsFHIR().isEmpty()) {
            for (Reaction reaction : adverseReaction.getReactionsFHIR()) {

                component.addManifestation().setText(reaction.getConcept().getIhrLaymanTerm())
                        .addCoding(new Coding()
                                .setDisplay(reaction.getConcept().getIhrTerm())
                                .setSystem(reaction.getConcept().getSourceVocabulary())
                                .setCode(reaction.getConcept().getSourceVocabularyCode()));
                //add Severity
                component.setSeverity(AllergyIntolerance.AllergyIntoleranceSeverity
                        .fromCode(reaction.getSeverity().getSourceVocabularyCode()));
                //allergyIntolerance.addReaction(component);
            }
        }
        //status
        if (null != adverseReaction.getStatus()) {
            allergyIntolerance.setClinicalStatus(new CodeableConcept()
                    .setText(adverseReaction.getStatus().getIhrLaymanTerm())
                    .addCoding(new Coding()
                            .setDisplay(adverseReaction.getStatus().getIhrTerm())
                            .setCode(adverseReaction.getStatus().getSourceVocabularyCode())
                            .setSystem(adverseReaction.getStatus().getSourceVocabulary())));
        }
        //presence state term
        if (StringUtils.isNotBlank(adverseReaction.getPresenceStateTerm())) {
            allergyIntolerance.addExtension(Constants.PRESENCE_STATE_TERM_URL, new StringType(adverseReaction.getPresenceStateTerm()));
        }
        // note
        if (CollectionUtils.isNotEmpty(adverseReaction.getNote())) {
            for (Note note : adverseReaction.getNote()) {
                allergyIntolerance.addNote(getAnnotation(patient, note, fhirResource));
            }
        }
        //Onset period
        Period onsetPeriod = new Period();
        if (StringUtils.isNotEmpty(adverseReaction.getOnsetPeriodStart())) {
            allergyIntolerance.setOnset(onsetPeriod.setStartElement(toDateTimeTypeFromDate(adverseReaction.getOnsetPeriodStart())));
        }
        if (StringUtils.isNotEmpty(adverseReaction.getOnsetPeriodEnd())) {
            allergyIntolerance.setOnset(onsetPeriod.setEndElement(toDateTimeTypeFromDate(adverseReaction.getOnsetPeriodEnd())));
        }
        //Clinically relevant date
        if (StringUtils.isNotBlank(adverseReaction.getClinicallyRelevantDate())) {
            allergyIntolerance.addExtension(Constants.CLINICALLY_RELEVANT_DATE_URL, toDateTimeTypeFromDate(adverseReaction.getClinicallyRelevantDate()));
        }
        //Start Date
        if (StringUtils.isNotBlank(adverseReaction.getStartDate())) {
            allergyIntolerance.addExtension(Constants.START_DATE_URL, toDateTypeFromDate(adverseReaction.getStartDate()));
        }
        //last updated date
        if (StringUtils.isNotBlank(adverseReaction.getLastUpdateDate())) {
            allergyIntolerance.setMeta(new Meta().setLastUpdatedElement(toInstantTypeFromDate(adverseReaction.getLastUpdateDate())));
        }
        //sensitivity classes
        if (CollectionUtils.isNotEmpty(adverseReaction.getSensitivityClasses())) {
            allergyIntolerance.addExtension(Constants.SENSITIVITY_CLASSES_URL,
                    new StringType(AppUtils.jsonEscape(adverseReaction.getSensitivityClasses())));
        }
        //data source
        if (CollectionUtils.isNotEmpty(adverseReaction.getDataSource())) {
            allergyIntolerance.addExtension(Constants.DATA_SOURCE_URL,
                    new StringType(AppUtils.jsonEscape(adverseReaction.getDataSource())));
        }
        //add resource in bundle
        bundle.addEntry().setFullUrl(allergyIntolerance.getId()).setResource(allergyIntolerance);
    }
}
