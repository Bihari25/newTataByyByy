package com.uhg.ihr.centrihealth.api.service.fhir;

import com.uhg.ihr.centrihealth.api.model.FhirResource;
import com.uhg.ihr.centrihealth.api.model.dataclass.Constants;
import com.uhg.ihr.centrihealth.api.model.dataclass.DataClass;
import com.uhg.ihr.centrihealth.api.model.dataclass.HealthMedication;
import com.uhg.ihr.centrihealth.api.model.dataclass.IhrTerm;
import com.uhg.ihr.centrihealth.api.model.dataclass.Note;
import com.uhg.ihr.centrihealth.api.util.AppUtils;
import io.micrometer.core.instrument.util.StringUtils;
import lombok.Value;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections.CollectionUtils;
import org.hl7.fhir.r4.model.BooleanType;
import org.hl7.fhir.r4.model.Bundle;
import org.hl7.fhir.r4.model.CodeableConcept;
import org.hl7.fhir.r4.model.Coding;
import org.hl7.fhir.r4.model.DecimalType;
import org.hl7.fhir.r4.model.Duration;
import org.hl7.fhir.r4.model.HumanName;
import org.hl7.fhir.r4.model.IdType;
import org.hl7.fhir.r4.model.Identifier;
import org.hl7.fhir.r4.model.Location;
import org.hl7.fhir.r4.model.Medication;
import org.hl7.fhir.r4.model.MedicationDispense;
import org.hl7.fhir.r4.model.MedicationRequest;
import org.hl7.fhir.r4.model.MedicationStatement;
import org.hl7.fhir.r4.model.Meta;
import org.hl7.fhir.r4.model.Patient;
import org.hl7.fhir.r4.model.Period;
import org.hl7.fhir.r4.model.Practitioner;
import org.hl7.fhir.r4.model.PractitionerRole;
import org.hl7.fhir.r4.model.Quantity;
import org.hl7.fhir.r4.model.Reference;
import org.hl7.fhir.r4.model.RelatedPerson;
import org.hl7.fhir.r4.model.StringType;
import org.hl7.fhir.r4.model.Timing;

import java.util.ArrayList;
import java.util.List;

@Slf4j
@Value(staticConstructor = "of")
public class MedicationStatementFhirMapper implements FhirMapper<HealthMedication, MedicationStatement> {

    private static final String PRESCRIPTION_ID = "prescriptionId";
    private static final String FIRST_DOSE_DATE = "firstDoseDate";
    private static final String EXPECTED_FILL_DATE = "expectedFillDate";
    private static final String ICUE_LAST_UPDATE_DATE = "icueLastUpdateDate";
    private static final String REFILL_COUNT = "https://new-wiki.optum.com/display/IHRI/IHR+API+Refill+Count";
    private static final String LAST_FILL_DATE = "lastFillDate";
    private static final String RX_NORM_CODE_URL = "http://www.nlm.nih.gov/research/umls/rxnorm";
    private static final String MEDI_SPAN_CODE_URL = "https://www.wolterskluwercdi.com";
    private static final String ICUE_SEQ_ID_DISPLAY = "icueMedicationSequenceId";

    @Override
    public void map(FhirResource fhirResource, DataClass dataClasses) {
        if (dataClasses != null && CollectionUtils.isNotEmpty(dataClasses.getMedications())) {
            map(fhirResource, dataClasses.getMedications());
        }
    }

    @Override
    public void map(FhirResource fhirResource, HealthMedication healthMedication) {
        Bundle bundle = fhirResource.getBundle();
        Patient patient = fhirResource.getPatient();

        Medication medication = new Medication();
        medication.setId(new IdType(createIdURI()));

        MedicationStatement medicationStatement = new MedicationStatement();
        medicationStatement.setId(new IdType(createIdURI()));

        MedicationRequest medicationRequest = new MedicationRequest();
        medicationRequest.setId(new IdType(createIdURI()));

        MedicationDispense medicationDispense = new MedicationDispense();
        medicationDispense.setId(new IdType(createIdURI()));
        //record key
        if (null != healthMedication.getRecordKey()) {
            medicationStatement.addIdentifier().setValue(healthMedication.getRecordKey())
                    .setType(new CodeableConcept().setText(Constants.RECORD_KEY));
        }
        //object id
        if (null != healthMedication.getObjectId()) {
            medicationStatement.addIdentifier()
                    .setValue(healthMedication.getObjectId().toString())
                    .setType(new CodeableConcept().setText(Constants.INSTANCE_ID));
        }
        //related allergies
        if (null != healthMedication.getRelatedAllergies()) {
            medicationStatement.addIdentifier()
                    .setValue(healthMedication.getRelatedAllergies().toString())
                    .setType(new CodeableConcept().setText(Constants.RELATED_ALLERGY_INSTANCE_IDS));
        }
        //medication
        if (null != healthMedication.getMedication()) {
            medication.setCode(new CodeableConcept()
                    .setText(healthMedication.getMedication().getIhrLaymanTerm())
                    .addCoding(new Coding()
                            .setDisplay(healthMedication.getMedication().getIhrTerm())
                            .setSystem(healthMedication.getMedication().getSourceVocabulary())
                            .setCode(healthMedication.getMedication().getSourceVocabularyCode())));
            //fdbcode
            if (StringUtils.isNotBlank(healthMedication.getMedication().getFdbCode()) && StringUtils.isNotBlank(healthMedication.getMedication().getFdbCodeType())) {
                medication.getCode().addCoding()
                        .setSystem(Constants.FDB_CODE_URL)
                        .setCode(healthMedication.getMedication().getFdbCode());
                medication.getCode().addCoding()
                        .setSystem(Constants.FDB_CODE_URL)
                        .setCode(healthMedication.getMedication().getFdbCodeType());
            }
            //RxNormCode
            if (StringUtils.isNotBlank(healthMedication.getMedication().getRxNormCode())) {
                medication.getCode().addCoding()
                        .setSystem(RX_NORM_CODE_URL)
                        .setCode(healthMedication.getMedication().getRxNormCode());
            }
            //MedispanCode
            if (StringUtils.isNotBlank(healthMedication.getMedication().getMediSpanCode())) {
                medication.getCode().addCoding()
                        .setSystem(MEDI_SPAN_CODE_URL)
                        .setCode(healthMedication.getMedication().getMediSpanCode());
            }
        }
        //icueSeqId
        if (StringUtils.isNotBlank(healthMedication.getIcueSeqId())) {
            medicationStatement.addIdentifier().setValue(healthMedication.getIcueSeqId())
                    .setType(new CodeableConcept().setText(ICUE_SEQ_ID_DISPLAY));
        }
        //medication status
        if (null != healthMedication.getMedicationStatus()) {
            medicationStatement.addExtension(Constants.STATUS_URL, new CodeableConcept()
                    .setText(healthMedication.getMedicationStatus().getIhrLaymanTerm())
                    .addCoding(new Coding()
                            .setDisplay(healthMedication.getMedicationStatus().getIhrTerm())
                            .setSystem(healthMedication.getMedicationStatus().getSourceVocabulary())
                            .setCode(healthMedication.getMedicationStatus().getSourceVocabularyCode())));
        }
        //presence state term
        if (StringUtils.isNotBlank(healthMedication.getPresenceStateTerm())) {
            medicationStatement.addExtension(Constants.PRESENCE_STATE_TERM_URL, new StringType(healthMedication.getPresenceStateTerm()));
        }
        //days supply
        if (null != healthMedication.getDaysSupply()) {
            Duration duration = new Duration();
            duration.setValue(healthMedication.getDaysSupply());
            medicationRequest.setDispenseRequest(
                    new MedicationRequest.MedicationRequestDispenseRequestComponent().
                            setExpectedSupplyDuration(duration));
        }

        //dosage quantity  & dosage quantity Unit
        if (null != healthMedication.getDosageQuantity()) {
            Quantity quantity = new Quantity();
            medicationStatement.getDosageFirstRep().getDoseAndRateFirstRep()
                    .setDose(quantity.setValue(healthMedication.getDosageQuantity())
                            .setSystem(Constants.DOSAGE_QUANTITY_URL));
            if (healthMedication.getDoseQuantityUnit() != null) {
                quantity.setUnit(healthMedication.getDoseQuantityUnit().getIhrTerm());
                quantity.setCode(healthMedication.getDoseQuantityUnit().getSourceVocabularyCode());
                quantity.setSystem(healthMedication.getDoseQuantityUnit().getSourceVocabulary());
            }
        }

        // dosageRoute
        if (null != healthMedication.getDosageRoute()) {
            medicationStatement.getDosageFirstRep().setRoute(new CodeableConcept()
                    .setText(healthMedication.getDosageRoute().getIhrLaymanTerm())
                    .addCoding(new Coding()
                            .setDisplay(healthMedication.getDosageRoute().getIhrTerm())
                            .setSystem(healthMedication.getDosageRoute().getSourceVocabulary())
                            .setCode(healthMedication.getDosageRoute().getSourceVocabularyCode())));
        }
        //dosage frequency
        if (healthMedication.getDoseFrequency() != null) {
            medicationStatement.getDosageFirstRep()
                    .setTiming(new Timing().setCode(new CodeableConcept()
                            .setText(healthMedication.getDoseFrequency().getIhrLaymanTerm())
                            .addCoding(new Coding()
                                    .setDisplay(healthMedication.getDoseFrequency().getIhrTerm())
                                    .setSystem(Constants.DOSAGE_URL)
                                    .setCode(healthMedication.getDoseFrequency().getSourceVocabularyCode()))));
        }
        //dosage form
        if (null != healthMedication.getDosageForm()) {
            medication.setForm(new CodeableConcept()
                    .setText(healthMedication.getDosageForm().getIhrLaymanTerm())
                    .addCoding(new Coding()
                            .setDisplay(healthMedication.getDosageForm().getIhrTerm())
                            .setSystem(healthMedication.getDosageForm().getSourceVocabulary())
                            .setCode(healthMedication.getDosageForm().getSourceVocabularyCode())));
        }
        //admin instructions
        if (StringUtils.isNotBlank(healthMedication.getAdminInstructions())) {
            medicationStatement.getDosageFirstRep().setText(healthMedication.getAdminInstructions());
        }
        //prescription id
        if (null != healthMedication.getPrescriptionId() && !healthMedication.getPrescriptionId().isEmpty()) {
            for (String id : healthMedication.getPrescriptionId()) {
                medicationStatement.addIdentifier().setValue(id)
                        .setType(new CodeableConcept().setText(PRESCRIPTION_ID));
            }
        }
        //refill authorized number
        if (null != healthMedication.getRefillAuthorizedNumber()) {
            medicationRequest.getDispenseRequest().setNumberOfRepeatsAllowed(healthMedication.getRefillAuthorizedNumber());
        }
        //refill count
        if (null != healthMedication.getRefillCount()) {
            medicationDispense.addExtension(REFILL_COUNT,
                    new DecimalType(healthMedication.getRefillCount()));
        }
        //Dispense Quantity
        if (null != healthMedication.getDispensedQuantity()) {
            Quantity dispenseQuantity = new Quantity(healthMedication.getDispensedQuantity());
            if (null != healthMedication.getDispensedQuantityUnit()) {
                dispenseQuantity.setUnit(healthMedication.getDispensedQuantityUnit().getIhrTerm());
                dispenseQuantity.setCode(healthMedication.getDispensedQuantityUnit().getSourceVocabularyCode());
                dispenseQuantity.setSystem(healthMedication.getDispensedQuantityUnit().getSourceVocabulary());
            }
            medicationDispense.setQuantity(dispenseQuantity);
        }
        //Dispense Quantity Unit TODO: DEPRECIATE EVENTUALLY
        if (null != healthMedication.getDispensedQuantityUnit()) {
            medicationDispense.getType()
                    .setText(healthMedication.getDispensedQuantityUnit().getIhrLaymanTerm())
                    .addCoding(new Coding().setDisplay(healthMedication.getDispensedQuantityUnit().getIhrTerm())
                            .setCode(healthMedication.getDispensedQuantityUnit().getSourceVocabularyCode())
                            .setSystem(healthMedication.getDispensedQuantityUnit().getSourceVocabulary()));
        }
        //Generic Flag
        if (null != healthMedication.getGenericFlag()) {
            medicationStatement.addExtension(Constants.GENERIC_FLAG_URL, new BooleanType(healthMedication.getGenericFlag()));
        }
        //medication start date
        if (healthMedication.getMedicationStartDate() != null) {
            medicationStatement.addExtension(Constants.START_DATE_URL, toDateTimeTypeFromDate(healthMedication.getMedicationStartDate()));
        }
        //Clinically Relevant Date
        if (StringUtils.isNotBlank(healthMedication.getClinicallyRelevantDate())) {
            medicationStatement.addExtension(Constants.CLINICALLY_RELEVANT_DATE_URL, toDateTimeTypeFromDate(healthMedication.getClinicallyRelevantDate()));
        }
        //Order Date
        if (StringUtils.isNotBlank(healthMedication.getOrderDate())) {
            medicationRequest.setAuthoredOnElement(toDateTimeTypeFromDate((healthMedication.getOrderDate())));
        }
        Period period = new Period();
        //First Dose Date and End Date
        if (StringUtils.isNotBlank(healthMedication.getFirstDoseDate())) {
            period.setStartElement(toDateTimeTypeFromDate(healthMedication.getFirstDoseDate()));
            medicationStatement.setEffective(period);
        }
        if (StringUtils.isNotBlank(healthMedication.getEndDate())) {
            period.setEndElement(toDateTimeTypeFromDate(healthMedication.getEndDate()));
            medicationStatement.setEffective(period);
        }
        //Hold Date
        if (StringUtils.isNotBlank(healthMedication.getHoldDate())) {
            period.addExtension(Constants.IHR_HOLD_DATE_URL, toDateTimeTypeFromDate(healthMedication.getHoldDate()));
            medicationStatement.setEffective(period);
        }
        //Restart Date
        if (StringUtils.isNotBlank(healthMedication.getRestartedDate())) {
            period.addExtension(Constants.IHR_RESTART_DATE_URL, toDateTimeTypeFromDate(healthMedication.getRestartedDate()));
            medicationStatement.setEffective(period);
        }
        //TakenAsOrdered
        if (null != healthMedication.getTakenAsOrdered()) {
            medicationStatement.addExtension(Constants.TAKEN_AS_ORDERED_URL, new BooleanType(healthMedication.getTakenAsOrdered()));
        }
        //Adherence STop Date
        if (StringUtils.isNotBlank(healthMedication.getAdherenceStopdate())) {
            medicationStatement.addExtension(Constants.IHR_ADHERENCE_DATE_URL, toDateTimeTypeFromDate(healthMedication.getAdherenceStopdate()));
        }
        //expected fill date
        if (StringUtils.isNotBlank(healthMedication.getExpectedFillDate())) {
            medicationStatement.addExtension(EXPECTED_FILL_DATE, toDateTypeFromDate(healthMedication.getExpectedFillDate()));

        }
        //last fill date
        if (StringUtils.isNotBlank(healthMedication.getLastFillDate())) {
            medicationStatement.addExtension(LAST_FILL_DATE, toDateTypeFromDate(healthMedication.getLastFillDate()));
        }
        //last update date
        if (StringUtils.isNotBlank(healthMedication.getLastUpdateDate())) {
            medicationStatement.setMeta(new Meta().setLastUpdatedElement(toInstantTypeFromDate(healthMedication.getLastUpdateDate())));
        }
        //icue last update date
        if (null != healthMedication.getIcueLastUpdateDate()) {
            medicationStatement.addExtension(ICUE_LAST_UPDATE_DATE, toDateTimeTypeFromDate(healthMedication.getIcueLastUpdateDate()));
        }
        //related conditions
        if (CollectionUtils.isNotEmpty(healthMedication.getRelatedConditions())) {
            medicationStatement.addIdentifier()
                    .setType(new CodeableConcept().setText(Constants.RELATED_CONDITION_INSTANCE_IDS))
                    .setValue(AppUtils.jsonEscape(healthMedication.getRelatedConditions()));
        }
        //related devices
        if (CollectionUtils.isNotEmpty(healthMedication.getRelatedDevices())) {
            medicationStatement.addIdentifier()
                    .setValue(AppUtils.jsonEscape(healthMedication.getRelatedDevices()))
                    .setType(new CodeableConcept().setText(Constants.RELATED_DEVICE_INSTANCE_IDS));
        }
        //related careteam
        if (CollectionUtils.isNotEmpty(healthMedication.getRelatedCareTeam())) {
            medicationStatement.addIdentifier()
                    .setValue(AppUtils.jsonEscape(healthMedication.getRelatedCareTeam()))
                    .setType(new CodeableConcept().setText(Constants.RELATED_CARE_TEAM_INSTANCE_IDS));
        }
        //related service providers
        if (CollectionUtils.isNotEmpty(healthMedication.getRelatedServiceProviders())) {
            medicationStatement.addIdentifier()
                    .setValue(AppUtils.jsonEscape(healthMedication.getRelatedServiceProviders()))
                    .setType(new CodeableConcept().setText(Constants.RELATED_SERVICE_FACILITY_PROVIDER_INSTANCE_IDS));
        }
        //sensitivity classes
        if (CollectionUtils.isNotEmpty(healthMedication.getSensitivityClasses())) {
            medicationStatement.addExtension(Constants.SENSITIVITY_CLASSES_URL
                    , new StringType(AppUtils.jsonEscape(healthMedication.getSensitivityClasses())));
        }
        //data source
        if (CollectionUtils.isNotEmpty(healthMedication.getDataSource())) {
            medicationStatement.addExtension(Constants.DATA_SOURCE_URL,
                    new StringType(AppUtils.jsonEscape(healthMedication.getDataSource())));
        }
        //medication drug class
        if (CollectionUtils.isNotEmpty(healthMedication.getDrugClass())) {
            medication.addExtension(Constants.DRUG_CLASS_URL,
                    new StringType(AppUtils.jsonEscape(healthMedication.getDrugClass())));
        }
        //referenceId
        if (CollectionUtils.isNotEmpty(healthMedication.getReferenceIds())) {
            medicationStatement.addIdentifier()
                    .setValue(AppUtils.jsonEscape(healthMedication.getReferenceIds()))
                    .setType(new CodeableConcept().setText(Constants.REFERENCE_IDS));
        }
        //deaSchedule
        if (StringUtils.isNotEmpty(healthMedication.getDeaSchedule())) {
            medication.addExtension(Constants.DEA_SCHEDULE_URL,
                    new StringType(healthMedication.getDeaSchedule()));
        }
        //ordering provider
        if (null != healthMedication.getOrderingProvider()) {
            Identifier identifier = new Identifier()
                    .setValue(healthMedication.getOrderingProvider().getOrderingProviderNPInum())
                    .setType(new CodeableConcept()
                            .addCoding(new Coding().setCode(Constants.NPI)
                                    .setDisplay(Constants.NPI_DISPLAY)
                                    .setSystem(Constants.NPI_URL)));

            Practitioner practitioner = getOrCreatePractitioner(fhirResource, identifier);
            medicationRequest.setRequester(new Reference(practitioner.addName(new HumanName()
                                    .setText(healthMedication.getOrderingProvider().getOrderingProviderName()))));
        }
        //supplier
        if (null != healthMedication.getSupplier()) {
            Location location = getOrCreateLocation(fhirResource, healthMedication.getSupplier());
            medicationDispense.setLocation(new Reference(location));
        }
        //generic drugname
        if (StringUtils.isNotBlank(healthMedication.getGenericDrugName())) {
            medication.addExtension(Constants.GENERIC_DRUG_URL, new StringType(healthMedication.getGenericDrugName()));
        }
        // note
        if (CollectionUtils.isNotEmpty(healthMedication.getNote())) {
            for (Note note : healthMedication.getNote()) {
                medicationStatement.addNote(getAnnotation(patient, note, fhirResource));
            }
        }
        //  medicationReviewDate;
        if (StringUtils.isNotBlank(healthMedication.getMedicationReviewDate())) {
            medicationStatement.setDateAssertedElement(this.toDateTimeTypeFromDate(healthMedication.getMedicationReviewDate()));
        }
        //reviewedBy;
        if (StringUtils.isNotBlank(healthMedication.getReviewedBy())) {
            medicationStatement.addIdentifier().setValue(healthMedication.getReviewedBy())
                    .setType(new CodeableConcept().setText(Constants.EMPLOYEE_ID));
        }
        //reviewerihrActorIdentifer
        if (StringUtils.isNotBlank(healthMedication.getReviewerIhrActorIdentifier())) {
            medicationStatement.addIdentifier().setValue(healthMedication.getReviewerIhrActorIdentifier())
                    .setType(new CodeableConcept().setText(Constants.REVIEWER_IHR_ACTOR_ID));
        }
        // medicationReviewLastActivityDate
        if (StringUtils.isNotBlank(healthMedication.getMedicationReviewLastActivityDate())) {
            medicationStatement.getMeta().addExtension(Constants.MEDICATION_REVIEW_DATE_URL, this.toDateTimeTypeFromDate((healthMedication.getMedicationReviewLastActivityDate())));
        }
        // InformerObject
        if (null != healthMedication.getInformerObject() && null != healthMedication.getInformerObject().getSourceVocabularyCode()) {
            if (RelatedPersonEnum.ENUM_VALUES.contains(healthMedication.getInformerObject().getSourceVocabularyCode())) {
                CodeableConcept relationShip = new CodeableConcept().setText(healthMedication.getInformerObject().getSourceVocabularyCode());
                RelatedPerson relatedPerson = getOrCreateRelatedPerson(fhirResource, relationShip);
                medicationStatement.setInformationSource(new Reference(relatedPerson));
            } else if (PractitionerRoleEnum.ENUM_VALUES.contains(healthMedication.getInformerObject().getSourceVocabularyCode())) {
                CodeableConcept practitionerCode = new CodeableConcept().setText(healthMedication.getInformerObject().getSourceVocabularyCode());
                PractitionerRole practitionerRole = getOrCreatePractitionerRole(fhirResource, practitionerCode);
                medicationStatement.setInformationSource(new Reference(practitionerRole));
            } else if (PatientEnum.ENUM_VALUES.contains(healthMedication.getInformerObject().getIhrTerm())) {
                medicationStatement.setInformationSource(new Reference(patient));
            }
        }
        // conceptChid
        if (null != healthMedication.getMedication() && StringUtils.isNotEmpty(healthMedication.getMedication().getConceptChid())) {
            medication.addIdentifier().setValue(healthMedication.getMedication().getConceptChid())
                    .setType(new CodeableConcept().setText(Constants.CONCEPT_CHID));
        }
        // add medicationReason
        if (CollectionUtils.isNotEmpty(healthMedication.getMedicationReason())) {
            for (IhrTerm medicationReason : healthMedication.getMedicationReason()) {
                medicationStatement.getReasonCode().add(new CodeableConcept()
                        .addCoding(new Coding()
                                .setSystem(medicationReason.getSourceVocabulary())
                                .setCode(medicationReason.getSourceVocabularyCode())));
            }
        }
        //subject
        medicationStatement.setSubject(new Reference(patient));
        List<Reference> referenceRequest = new ArrayList<>();
        referenceRequest.add(new Reference(medicationRequest));
        List<Reference> referenceDispense = new ArrayList<>();
        referenceDispense.add(new Reference(medicationDispense));
        medicationStatement.setPartOf(referenceDispense).setBasedOn(referenceRequest).setMedication(new Reference(medication));

        //add resource into bundle
        bundle.addEntry().setFullUrl(medication.getId()).setResource(medication);
        bundle.addEntry().setFullUrl(medicationStatement.getId()).setResource(medicationStatement);
        bundle.addEntry().setFullUrl(medicationRequest.getId()).setResource(medicationRequest);
        bundle.addEntry().setFullUrl(medicationDispense.getId()).setResource(medicationDispense);
    }
}