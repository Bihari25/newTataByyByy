package com.uhg.ihr.centrihealth.api.model.dataclass;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.EqualsAndHashCode;
import lombok.NoArgsConstructor;
import java.math.BigInteger;
import java.util.List;

@EqualsAndHashCode(callSuper = false)
@AllArgsConstructor
@Data
@NoArgsConstructor
public class ProcedureHistory extends BaseDataClass {
    private String recordKey;
    private DataClassEnums recordType;
    private String healthEventDate;
    private String healthEventOrderDate;
    private String healthEventCategoryText;
    private IhrTerm healthEvent;
    private List<IhrTerm> specimens;
    private String presenceStateTerm;
    private IhrTerm healthEventStatus;
    private String lastUpdateDate;
    private List<String> sensitivityClasses;
    private List<String> sourceClaimIds;
    private List<BigInteger> relatedConditions;
    private List<BigInteger> relatedObservations;
    private List<BigInteger> relatedCareTeam;
    private List<BigInteger> relatedServiceProviders;
    private List<String> dataSource;
    private String clinicallyRelevantDate;
    private List<String> referenceIds;
    private List<Note> note;

    @Builder
    public ProcedureHistory(BigInteger objectId, String recordKey, DataClassEnums recordType, String healthEventDate, String healthEventOrderDate, String healthEventCategoryText, IhrTerm healthEvent, List<IhrTerm> specimens, String presenceStateTerm, IhrTerm healthEventStatus, String lastUpdateDate, List<String> sensitivityClasses, List<String> sourceClaimIds, List<BigInteger> relatedConditions, List<BigInteger> relatedObservations, List<BigInteger> relatedCareTeam, List<BigInteger> relatedServiceProviders, List<String> dataSource, String clinicallyRelevantDate, List<String> referenceIds, List<Note> note) {
        super(objectId);
        this.recordKey = recordKey;
        this.recordType = recordType;
        this.healthEventDate = healthEventDate;
        this.healthEventOrderDate = healthEventOrderDate;
        this.healthEventCategoryText = healthEventCategoryText;
        this.healthEvent = healthEvent;
        this.specimens = specimens;
        this.presenceStateTerm = presenceStateTerm;
        this.healthEventStatus = healthEventStatus;
        this.lastUpdateDate = lastUpdateDate;
        this.sensitivityClasses = sensitivityClasses;
        this.sourceClaimIds = sourceClaimIds;
        this.relatedConditions = relatedConditions;
        this.relatedObservations = relatedObservations;
        this.relatedCareTeam = relatedCareTeam;
        this.relatedServiceProviders = relatedServiceProviders;
        this.dataSource = dataSource;
        this.clinicallyRelevantDate = clinicallyRelevantDate;
        this.referenceIds = referenceIds;
        this.note = note;
    }
}
