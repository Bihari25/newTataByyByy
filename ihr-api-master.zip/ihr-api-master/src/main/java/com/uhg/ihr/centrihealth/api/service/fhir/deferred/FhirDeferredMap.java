package com.uhg.ihr.centrihealth.api.service.fhir.deferred;

import lombok.extern.slf4j.Slf4j;
import org.hl7.fhir.r4.model.Resource;

import java.math.BigInteger;
import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;

@Slf4j
public class FhirDeferredMap<T extends Resource> {

    private T fhirResource;
    private List<DeferredMapper<T>> deferredMappers;

    public FhirDeferredMap() {
        this.deferredMappers = new LinkedList<>();
    }

    public void addDeferredMapper(DeferredMapper<T> deferredMapper) {
        if (fhirResource != null) {
            deferredMapper.processMapper(fhirResource);
        } else {
            synchronized (this) {
                if (this.deferredMappers == null) {
                    this.deferredMappers = new ArrayList<>();
                }
                deferredMappers.add(deferredMapper);
            }
        }
    }

    public void addFhirResource(T resource) {
        this.fhirResource = resource;
    }

    public void processMappers(BigInteger objectId) {
        if (fhirResource == null) {
            String type = "UNKNOWN";
            if (this.deferredMappers != null && !this.deferredMappers.isEmpty()) {
                type = this.deferredMappers.get(0).getClass().getSimpleName();
            }
            log.error("No FHIR resource available for deferred mappers of type " + type + " for objectId " + objectId);
        } else {
            synchronized (this) {
                this.deferredMappers.forEach(mapper -> mapper.processMapper(fhirResource));
                this.deferredMappers = null;
            }
        }
    }
}
