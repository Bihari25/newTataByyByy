package com.uhg.ihr.centrihealth.api.service.fhir;

import com.uhg.ihr.centrihealth.api.model.FhirResource;
import com.uhg.ihr.centrihealth.api.model.dataclass.Constants;
import com.uhg.ihr.centrihealth.api.model.dataclass.DataClass;
import com.uhg.ihr.centrihealth.api.model.dataclass.ServiceProviders;
import com.uhg.ihr.centrihealth.api.util.AppUtils;
import io.micrometer.core.instrument.util.StringUtils;
import lombok.Value;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections.CollectionUtils;
import org.hl7.fhir.r4.model.Bundle;
import org.hl7.fhir.r4.model.CareTeam;
import org.hl7.fhir.r4.model.CodeableConcept;
import org.hl7.fhir.r4.model.Coding;
import org.hl7.fhir.r4.model.IdType;
import org.hl7.fhir.r4.model.Organization;
import org.hl7.fhir.r4.model.Period;
import org.hl7.fhir.r4.model.Reference;

@Slf4j
@Value(staticConstructor = "of")
public class PracitionerRoleFhirMapper implements FhirMapper<ServiceProviders, CareTeam> {

    @Override
    public void map(FhirResource fhirResource, DataClass dataClasses) {
        if (dataClasses != null && CollectionUtils.isNotEmpty(dataClasses.getServiceProviders())) {
            map(fhirResource, dataClasses.getServiceProviders());
        }
    }

    @Override
    public void map(FhirResource fhirResource, ServiceProviders serviceProviders) {
        Bundle bundle = fhirResource.getBundle();

        CareTeam careTeam = new CareTeam();
        careTeam.setId(new IdType(createIdURI()));

        Organization organization = new Organization();
        organization.setId(new IdType(createIdURI()));

        //record type
        if (StringUtils.isNotBlank(serviceProviders.getRecordType())) {
            careTeam.setText(createNarrative(serviceProviders.getRecordType()));
        }
        //record key
        if (null != serviceProviders.getRecordKey()) {
            organization.addIdentifier().setValue(serviceProviders.getRecordKey())
                    .setType(new CodeableConcept().setText((Constants.RECORD_KEY)));
        }
        //object id
        if (null != serviceProviders.getObjectId()) {
            organization.addIdentifier().setValue(serviceProviders.getObjectId().toString())
                    .setType(new CodeableConcept().setText(Constants.INSTANCE_ID));
        }
        //reference id
        if (CollectionUtils.isNotEmpty(serviceProviders.getReferenceIds())) {
            organization.addIdentifier().setValue(AppUtils.jsonEscape(serviceProviders.getReferenceIds()))
                    .setType(new CodeableConcept().setText(Constants.REFERENCE_IDS));
        }
        //related entity npi num
        if (StringUtils.isNotBlank(serviceProviders.getRelatedEntityNPInum())) {
            organization.addIdentifier().setValue(serviceProviders.getRelatedEntityNPInum())
                    .setType(new CodeableConcept()
                            .addCoding(new Coding().setCode(Constants.NPI)
                                    .setDisplay(Constants.NPI_DISPLAY)
                                    .setSystem(Constants.NPI_URL)));
        }
        //related entity name
        if (StringUtils.isNotBlank(serviceProviders.getRelatedEntityName())) {
            organization.setName(serviceProviders.getRelatedEntityName());
        }
        //related entity mpin
        if (StringUtils.isNotBlank(serviceProviders.getRelatedEntityMPIN())) {
            organization.addIdentifier().setValue(serviceProviders.getRelatedEntityMPIN())
                    .setType(new CodeableConcept()
                            .addCoding(new Coding().setCode(Constants.MPIN.toUpperCase())
                                    .setSystem(Constants.MPIN_URL)
                                    .setDisplay(Constants.MPIN_DISPLAY)));
        }
        //related entity role term
        if (StringUtils.isNotBlank(serviceProviders.getRelatedEntityRoleTerm())) {
            careTeam.getParticipantFirstRep().addRole()
                    .addCoding(new Coding().setDisplay(serviceProviders.getRelatedEntityRoleTerm()));
        }
        //relationship start date && EndDate
        if (StringUtils.isNotBlank(serviceProviders.getRelationshipStartDate()) || StringUtils.isNotBlank(serviceProviders.getRelationshipEndDate())) {
            Period period = new Period();
            period.setStartElement(StringUtils.isNotBlank(serviceProviders.getRelationshipStartDate()) ? toDateTimeTypeFromDate(serviceProviders.getRelationshipStartDate()) : null);
            period.setEndElement(StringUtils.isNotBlank(serviceProviders.getRelationshipEndDate()) ? toDateTimeTypeFromDate(serviceProviders.getRelationshipEndDate()) : null);
            careTeam.setPeriod(period);
        }
        careTeam.getParticipantFirstRep().setMember(new Reference(organization));

        // add resource into bundle
        bundle.addEntry().setFullUrl(organization.getId()).setResource(organization);
        bundle.addEntry().setFullUrl(careTeam.getId()).setResource(careTeam);
    }
}

