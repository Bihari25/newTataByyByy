package com.uhg.ihr.centrihealth.api.constant;

public interface GlobalUrlConstant {

    String IHR_NOTE_TYPE_URL = "https://github.optum.com/pages/IHR/ihr-api-docs/docs/APIs/IHR-Data-Definitions/ihrFhirExtensions/ihrNoteType";
    String PRESENCESTATE_URL = "https://github.optum.com/pages/IHR/ihr-api-docs/docs/APIs/IHR-Data-Definitions/ihrFhirExtensions/presenceState";
    String CLINICAL_RELEVANT_DATE_URL = "https://github.optum.com/pages/IHR/ihr-api-docs/docs/APIs/IHR-Data-Definitions/ihrFhirExtensions/clinicallyRelevantDate";
    String START_DATE_URL = "https://github.optum.com/pages/IHR/ihr-api-docs/docs/APIs/IHR-Data-Definitions/ihrFhirExtensions/startDate";
    String SECURITY_LABELS_URL = "http://hl7.org/fhir/ValueSet/security-labels";
    String RX_NORM_CODE_URL = "http://www.nlm.nih.gov/research/umls/rxnorm";
    String MEDI_SPAN_CODE_URL = "http://terminology.hl7.org/CodeSystem/mddid";
    String REFILL_COUNT = "https://github.optum.com/pages/IHR/ihr-api-docs/docs/APIs/IHR-Data-Definitions/ihrFhirExtensions/refillCount";
    String ICUE_SEQ_ID_URL = "https://github.optum.com/pages/IHR/ihr-api-docs/docs/APIs/IHR-Data-Definitions/ihrFhirExtensions/icueSeqId";
    String ICUE_LAST_UPDATE_DATE_URL = "https://github.optum.com/pages/IHR/ihr-api-docs/docs/APIs/IHR-Data-Definitions/ihrFhirExtensions/icueLastUpdateDate";
    String HOLD_DATE_URL = "https://github.optum.com/pages/IHR/ihr-api-docs/docs/APIs/IHR-Data-Definitions/ihrFhirExtensions/holdDate";
    String RESTART_DATE_URL = "https://github.optum.com/pages/IHR/ihr-api-docs/docs/APIs/IHR-Data-Definitions/ihrFhirExtensions/restartDate";
    String TAKEN_AS_ORDERED_URL = "https://github.optum.com/pages/IHR/ihr-api-docs/docs/APIs/IHR-Data-Definitions/ihrFhirExtensions/takenAsOrdered";
    String ADHERENCE_STOP_DATE_URL = "https://github.optum.com/pages/IHR/ihr-api-docs/docs/APIs/IHR-Data-Definitions/ihrFhirExtensions/adherenceStopDate";
    String EXPECTED_FILL_DATE_URL = "https://github.optum.com/pages/IHR/ihr-api-docs/docs/APIs/IHR-Data-Definitions/ihrFhirExtensions/expectedFillDate";
    String REVIEW_LAST_ACTIVITY_DATE_URL = "https://github.optum.com/pages/IHR/ihr-api-docs/docs/APIs/IHR-Data-Definitions/ihrFhirExtensions/reviewLastActivityDate";
    String ICD_10_CM_URL = "http://hl7.org/fhir/sid/icd-10-cm";
    String CPT_CODE_URL = "http://www.ama-assn.org/go/cpt";
}