package com.uhg.ihr.centrihealth.api.service.fhir;

import com.uhg.ihr.centrihealth.api.model.FhirResource;
import com.uhg.ihr.centrihealth.api.model.dataclass.Constants;
import com.uhg.ihr.centrihealth.api.model.dataclass.DataClass;
import com.uhg.ihr.centrihealth.api.model.dataclass.HealthCondition;
import com.uhg.ihr.centrihealth.api.model.dataclass.Note;
import com.uhg.ihr.centrihealth.api.util.AppUtils;
import io.micrometer.core.instrument.util.StringUtils;
import lombok.Value;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.collections.CollectionUtils;
import org.hl7.fhir.r4.model.Bundle;
import org.hl7.fhir.r4.model.CodeableConcept;
import org.hl7.fhir.r4.model.Coding;
import org.hl7.fhir.r4.model.Condition;
import org.hl7.fhir.r4.model.IdType;
import org.hl7.fhir.r4.model.Identifier;
import org.hl7.fhir.r4.model.Meta;
import org.hl7.fhir.r4.model.Patient;
import org.hl7.fhir.r4.model.Period;
import org.hl7.fhir.r4.model.Practitioner;
import org.hl7.fhir.r4.model.PractitionerRole;
import org.hl7.fhir.r4.model.Reference;
import org.hl7.fhir.r4.model.RelatedPerson;
import org.hl7.fhir.r4.model.StringType;

@Slf4j
@Value(staticConstructor = "of")
public class ConditionFhirMapper implements FhirMapper<HealthCondition, Condition> {

    @Override
    public void map(FhirResource fhirResource, DataClass dataClasses) {
        if (dataClasses != null && CollectionUtils.isNotEmpty(dataClasses.getConditions())) {
            map(fhirResource, dataClasses.getConditions());
        }
    }

    @Override
    public void map(FhirResource fhirResource, HealthCondition healthCondition) {
        Patient patient = fhirResource.getPatient();
        Bundle bundle = fhirResource.getBundle();

        Condition condition = new Condition();
        condition.setId(new IdType(createIdURI()));
        //record key
        if (null != healthCondition.getRecordKey()) {
            condition.addIdentifier().setValue(healthCondition.getRecordKey())
                    .setType(new CodeableConcept().setText(Constants.RECORD_KEY));
        }
        //referenceId
        if (CollectionUtils.isNotEmpty(healthCondition.getReferenceIds())) {
            condition.addIdentifier()
                    .setValue(AppUtils.jsonEscape(healthCondition.getReferenceIds()))
                    .setType(new CodeableConcept().setText(Constants.REFERENCE_IDS));

        }
        //object id
        if (null != healthCondition.getObjectId()) {
            condition.addIdentifier()
                    .setValue(healthCondition.getObjectId().toString())
                    .setType(new CodeableConcept().setText(Constants.INSTANCE_ID));
        }
        //health condition
        if (null != healthCondition.getHealthCondition()) {
            condition.setCode(new CodeableConcept()
                    .setText(healthCondition.getHealthCondition().getIhrLaymanTerm())
                    .addCoding(new Coding()
                            .setDisplay(healthCondition.getHealthCondition().getIhrTerm())
                            .setSystem(healthCondition.getHealthCondition().getSourceVocabulary())
                            .setCode(healthCondition.getHealthCondition().getSourceVocabularyCode())));
            if (StringUtils.isNotBlank(healthCondition.getHealthCondition().getIcd10cmCode())) {
                condition.getCode()
                        .addCoding(new Coding()
                                .setSystem(Constants.ICD_10_CM_CODE_URL)
                                .setCode(healthCondition.getHealthCondition().getIcd10cmCode()));
            }
            //Condition Clinical Course
            if (StringUtils.isNotBlank(healthCondition.getHealthCondition().getClinicalCourse())) {
                condition.addExtension(Constants.IHR_CONDITION_CLINICAL_COURSE_URL, new StringType(healthCondition.getHealthCondition().getClinicalCourse()));
            }
        }
        //status
        if (null != healthCondition.getStatus()) {
            condition.addExtension(Constants.STATUS_URL, new CodeableConcept()
                    .setText(healthCondition.getStatus().getIhrLaymanTerm())
                    .addCoding(new Coding()
                            .setDisplay(healthCondition.getStatus().getIhrTerm())
                            .setSystem(healthCondition.getStatus().getSourceVocabulary())
                            .setCode(healthCondition.getStatus().getSourceVocabularyCode())));

        }
        //presence state term
        if (StringUtils.isNotBlank(healthCondition.getPresenceStateTerm())) {
            condition.addExtension(Constants.PRESENCE_STATE_TERM_URL, new StringType(healthCondition.getPresenceStateTerm()));
        }
        // note
        if (CollectionUtils.isNotEmpty(healthCondition.getNote())) {
            for (Note note : healthCondition.getNote()) {
                condition.addNote(getAnnotation(patient, note, fhirResource));
            }
        }
        //Onset period start & end
        Period onsetPeriod = new Period();
        if (StringUtils.isNotEmpty(healthCondition.getOnsetPeriodStart())) {
            condition.setOnset(onsetPeriod.setStartElement(toDateTimeTypeFromDate(healthCondition.getOnsetPeriodStart())));
        }
        if (StringUtils.isNotEmpty(healthCondition.getOnsetPeriodEnd())) {
            condition.setOnset(onsetPeriod.setEndElement(toDateTimeTypeFromDate(healthCondition.getOnsetPeriodEnd())));
        }
        // asserterObject
        if (null != healthCondition.getAsserterObject() && null != healthCondition.getAsserterObject().getSourceVocabularyCode()) {
            if (RelatedPersonEnum.ENUM_VALUES.contains(healthCondition.getAsserterObject().getSourceVocabularyCode())) {
                CodeableConcept relationShip = new CodeableConcept().setText(healthCondition.getAsserterObject().getSourceVocabularyCode());
                RelatedPerson relatedPerson = getOrCreateRelatedPerson(fhirResource, relationShip);
                condition.setAsserter(new Reference(relatedPerson));

            } else if (PractitionerRoleEnum.ENUM_VALUES.contains(healthCondition.getAsserterObject().getSourceVocabularyCode())) {
                CodeableConcept practitionerCode = new CodeableConcept().setText(healthCondition.getAsserterObject().getSourceVocabularyCode());
                PractitionerRole practitionerRole = getOrCreatePractitionerRole(fhirResource, practitionerCode);
                condition.setAsserter(new Reference(practitionerRole));
            } else if (PatientEnum.ENUM_VALUES.contains(healthCondition.getAsserterObject().getIhrTerm())) {
                condition.setAsserter(new Reference(patient));
            }
        }
        //recordedId
        if (StringUtils.isNotBlank(healthCondition.getRecorderId())) {
            Identifier identifier = new Identifier()
                    .setValue(healthCondition.getRecorderId())
                    .setType(new CodeableConcept().setText(Constants.EMPLOYEE_ID));
            Practitioner practitioner = getOrCreatePractitioner(fhirResource, identifier);
            condition.setRecorder(new Reference(practitioner));
        }
        //recorded Date
        if (StringUtils.isNotEmpty(healthCondition.getRecordedDate())) {
            condition.setRecordedDateElement(toDateTimeTypeFromDate(healthCondition.getRecordedDate()));
        }
        //Clinically relevant date
        if (StringUtils.isNotBlank(healthCondition.getClinicallyRelevantDate())) {
            condition.addExtension(Constants.CLINICALLY_RELEVANT_DATE_URL, toDateTimeTypeFromDate(healthCondition.getClinicallyRelevantDate()));

        }
        //condition start date
        if (StringUtils.isNotBlank(healthCondition.getConditionStartDate())) {
            condition.addExtension(Constants.START_DATE_URL, toDateTimeTypeFromDate(healthCondition.getConditionStartDate()));
        }
        //Last Update Date
        if (StringUtils.isNotBlank(healthCondition.getLastUpdateDate())) {
            condition.setMeta(new Meta().setLastUpdatedElement(toInstantTypeFromDate(healthCondition.getLastUpdateDate())));
        }
        //add subject
        condition.setSubject(new Reference(patient));

        //related conditions
        if (CollectionUtils.isNotEmpty(healthCondition.getRelatedConditions())) {
            condition.addIdentifier()
                    .setValue(AppUtils.jsonEscape(healthCondition.getRelatedConditions()))
                    .setType(new CodeableConcept().setText(Constants.RELATED_CONDITION_INSTANCE_IDS));
        }
        //related observations
        if (CollectionUtils.isNotEmpty(healthCondition.getRelatedObservations())) {
            condition.addIdentifier()
                    .setValue(AppUtils.jsonEscape(healthCondition.getRelatedObservations()))
                    .setType(new CodeableConcept().setText(Constants.RELATED_OBSERVATION_INSTANCE_IDS));
        }
        //related care team
        if (CollectionUtils.isNotEmpty(healthCondition.getRelatedCareTeam())) {
            condition.addIdentifier()
                    .setValue(AppUtils.jsonEscape(healthCondition.getRelatedCareTeam()))
                    .setType(new CodeableConcept().setText(Constants.RELATED_CARE_TEAM_INSTANCE_IDS));
        }
        //sensitivity class
        if (CollectionUtils.isNotEmpty(healthCondition.getSensitivityClasses())) {
            condition.addExtension(Constants.SENSITIVITY_CLASSES_URL,
                    new StringType(AppUtils.jsonEscape(healthCondition.getSensitivityClasses())));
        }
        //source claim ids
        if (CollectionUtils.isNotEmpty(healthCondition.getSourceClaimIds())) {
            condition.addIdentifier()
                    .setValue(AppUtils.jsonEscape(healthCondition.getSourceClaimIds()))
                    .setType(new CodeableConcept().setText(Constants.SOURCE_CLAIM_IDS));
        }
        //data sources
        if (CollectionUtils.isNotEmpty(healthCondition.getDataSource())) {
            condition.addExtension(Constants.DATA_SOURCE_URL, new StringType(AppUtils.jsonEscape(healthCondition.getDataSource())));
        }
        // add resource into bundle
        bundle.addEntry().setFullUrl(condition.getId()).setResource(condition);
    }
}
