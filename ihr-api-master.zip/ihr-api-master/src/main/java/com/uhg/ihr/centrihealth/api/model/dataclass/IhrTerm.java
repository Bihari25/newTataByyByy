package com.uhg.ihr.centrihealth.api.model.dataclass;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;
import java.math.BigInteger;
import java.util.List;

@Builder(toBuilder = true)
@AllArgsConstructor
@Data
@NoArgsConstructor
public class IhrTerm {
    private String ihrLaymanTerm;
    private String ihrTerm;
    private String ihrCode;
    private String sourceVocabulary;
    private String sourceVocabularyCode;
    private String fdbCode;
    private String fdbCodeType;
    private String rxNormCode;
    private String mediSpanCode;
    private String icd10cmCode;
    private String cpthcpcsCode;
    private String clinicalCourse;
    private String medicalDomain;
    private String loincCode;
    private String conceptChid;
    private List<String> referenceIds;
    public BigInteger doseNumber;
    public String lotNumber;
    public String recordKey;
    public String shortPreferredTerm;
}
