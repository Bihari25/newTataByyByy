package com.uhg.ihr.centrihealth.api.fhir

import com.uhg.ihr.centrihealth.api.util.MongoWireMockBaseTest
import io.micronaut.test.annotation.MicronautTest
import spock.lang.Unroll

@MicronautTest
class BundleUtilsSpec extends MongoWireMockBaseTest {

    @Unroll
    def "Bundle test #desc"() {

        when:
        BundleUtils.isRequestValid(file)

        then:
        true

        where:
        desc                       | file
        "Small"                    | "bundleTestSmall.json"
        "Large"                    | "bundleTestLarge.json"
        "With patient resource"    | "bundleWithPatientRes.json"
        "Without patient resource" | "bundleWithoutPatientRes.json"
    }
}
