package com.uhg.ihr.centrihealth.api.util;

import com.mongodb.MongoClient;
import com.mongodb.client.MongoCollection;
import com.mongodb.client.MongoDatabase;
import de.flapdoodle.embed.mongo.MongodExecutable;
import de.flapdoodle.embed.mongo.MongodProcess;
import de.flapdoodle.embed.mongo.MongodStarter;
import de.flapdoodle.embed.mongo.MongosExecutable;
import de.flapdoodle.embed.mongo.MongosProcess;
import de.flapdoodle.embed.mongo.MongosStarter;
import de.flapdoodle.embed.mongo.config.IMongodConfig;
import de.flapdoodle.embed.mongo.config.IMongosConfig;
import de.flapdoodle.embed.mongo.config.MongodConfigBuilder;
import de.flapdoodle.embed.mongo.config.MongosConfigBuilder;
import de.flapdoodle.embed.mongo.config.Net;
import de.flapdoodle.embed.mongo.config.Storage;
import de.flapdoodle.embed.mongo.config.Timeout;
import de.flapdoodle.embed.mongo.distribution.Version;
import de.flapdoodle.embed.process.runtime.Network;
import io.micronaut.core.io.socket.SocketUtils;
import org.bson.Document;

import java.io.IOException;

public class MongoEmbededProcess {

    private static final String DATABASE_NAME = "apidata";
    private static final String DATABASE_ADMIN = "admin";
    private static final String B50_COLLECTION = "ihr_gold_transcribed_collection";
    private static final String IHR2_COLLECTION = "external_api_payload_v2";
    private static final String defaultHost = "localhost";
    private static final int defaultPort = 27017;
    private static final String username = "apidata_test";
    private static final String userpass = "apidata_test";
    private static final Integer timeOut = 300000;
    private static final String REPLICA_SET_INITIATE = "replSetInitiate";

    private static MongodProcess mongodProcess;
    private static MongosProcess mongosProcess;
    private static MongodExecutable mongodExe;
    private static MongosExecutable mongosExe;
    private static MongoClient mongoClient;

    public static MongoCollection<Document> getCollection(String databaseName, String collectionName) {

        MongoCollection<Document> collection = null;
        try {
            createMongoClient();
            if (mongoClient != null) {
                MongoDatabase mongoDatabase = mongoClient.getDatabase(databaseName);
                collection = mongoDatabase.getCollection(collectionName);
            }
        } catch (Exception e) {
                return null;
        }
        return collection;
    }

    public static void createMongoClient() {
        if (mongoClient != null) {
            return;
        }
        try {
            if (!SocketUtils.isTcpPortAvailable(defaultPort)) {
                return;
            }
            startMongoDb(defaultPort);

            try (MongoClient client = new MongoClient(defaultHost, defaultPort)) {
                client.getDatabase(DATABASE_ADMIN).runCommand(new Document(REPLICA_SET_INITIATE, new Document()));
                mongoClient = client;
            }
            /*ServerAddress serverAddress = new ServerAddress(defaultHost, defaultPort);
            MongoCredential mongoCredential = MongoCredential.createCredential(username, DATABASE_NAME, userpass.toCharArray());
            MongoClientOptions clientOptions = MongoClientOptions.builder()
                    .connectTimeout(timeOut)
                    .socketTimeout(timeOut)
                    .serverSelectionTimeout(timeOut).build();
            mongoClient = new MongoClient(serverAddress, mongoCredential, clientOptions);
            MongoDatabase database = mongoClient.getDatabase(DATABASE_NAME);
            database.runCommand(new Document(REPLICA_SET_INITIATE, new Document()));*/
        }
        catch (Exception ie) {
            ie.printStackTrace();
        }
        return;
    }

    private static void startMongoDb(int defaultConfigPort) throws IOException {
        IMongodConfig mongodConfig = new MongodConfigBuilder()
                .version(Version.Main.PRODUCTION)
                .net(new Net(defaultConfigPort, Network.localhostIsIPv6()))
                .replication(new Storage(null, "testRepSet", 5000))
                .configServer(true)
                .timeout(new Timeout(timeOut))
                .build();

        mongodExe = MongodStarter.getDefaultInstance().prepare(mongodConfig);
        mongodProcess = mongodExe.start();
    }

    private static void startMongoShell(int defaultConfigPort) {
        try {
            int mongosPort = Network.getFreeServerPort();
            System.out.println("Shell free server port: " + mongosPort);
            IMongosConfig mongosConfig = new MongosConfigBuilder()
                    .version(Version.Main.PRODUCTION)
                    .net(new Net(mongosPort, Network.localhostIsIPv6()))
                    .configDB(defaultHost + ":" + defaultConfigPort)
                    .replicaSet("testRepSet")
                    .build();
            mongosExe = MongosStarter.getDefaultInstance().prepare(mongosConfig);
            mongosProcess = mongosExe.start();
        } catch (Exception ie) {
            ie.printStackTrace();
        }
    }

    public static void tearDown() {
        if (mongodProcess != null) { mongodProcess.stop(); }
        if (mongodExe != null) { mongodExe.stop(); }
        if (mongosProcess != null) { mongosProcess.stop(); }
        if (mongosExe != null) { mongosExe.stop(); }
    }

}
