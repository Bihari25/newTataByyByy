package com.uhg.ihr.centrihealth.api.util

import com.mongodb.MongoClient
import com.mongodb.MongoException
import com.mongodb.client.MongoCollection
import com.mongodb.client.MongoDatabase
import com.mongodb.client.model.Filters
import groovy.util.logging.Slf4j
import io.reactivex.Flowable
import io.reactivex.Single
import org.bson.Document
import org.bson.conversions.Bson
import spock.lang.Unroll

import javax.validation.constraints.NotBlank

@Slf4j
@Unroll
class MongoTestService {

    private static final String username = "apidata_test"
    private static final String userpass = "apidata_test"
    private static final Integer timeOut = 10000
    private static final String HOST = "localhost"
    public static final Integer PORT = 27017
    private static MongoClient mongoClient = new MongoClient(HOST, PORT)

    static MongoCollection<Document> getCollection(String databaseName, String collectionName) {
        MongoCollection<Document> collection = null
        try {
            /*ServerAddress serverAddress = new ServerAddress(host, port)
            MongoCredential mongoCredential = MongoCredential.createCredential(username, databaseName, userpass.toCharArray());
            MongoClientOptions clientOptions = MongoClientOptions.builder()
                    .connectTimeout(timeOut).socketTimeout(timeOut).serverSelectionTimeout(timeOut)
                    .build()
            MongoClient mongoClient = new MongoClient(serverAddress, mongoCredential, clientOptions)*/
            MongoDatabase database = mongoClient.getDatabase(databaseName)
            collection = database.getCollection(collectionName)
        } catch (MongoException ex) {
            log.info("Exception MongoTestService - getCollection():", ex.printStackTrace())
        }
        return collection
    }

    static boolean insertOrReplaceDocument(MongoCollection<Document> collection, Document document) {
        try {
            Bson filter = Filters.eq("_id", document.get("_id"))
            Document myDoc = collection.find(filter).first()
            if (myDoc != null) {
                Flowable.fromArray(collection.deleteOne(filter))
            }
            collection.insertOne(document)
            return true
        } catch (Exception ex) {
            log.info("Exception MongoTestService - insertOrReplaceDocument():", ex.printStackTrace())
            return false
        }
    }

    static Document filterDocuments(MongoCollection<Document> collection, @NotBlank String id) {
        try {
            Bson filter = Filters.eq("_id", id)
            Document myDoc = collection.find(filter).first()
            if (myDoc == null) {
                return null
            }
            Single<List<Document>> carrier = Flowable.fromIterable(collection.find(filter)).toList()
            return carrier.blockingGet().get(0)
        } catch (Exception ex) {
            log.info("Exception MongoTestService - filterDocuments():", ex.printStackTrace())
            return null
        }
    }

    static boolean deleteDocuments(MongoCollection<Document> collection, @NotBlank String id) {
        try {
            Bson filter = Filters.eq("_id", id)
            Document myDoc = collection.find(filter).first()
            if (myDoc == null) {
                return false
            }
            Flowable.fromArray(collection.deleteOne(filter))
            return true
        } catch (Exception ex) {
            log.info("Exception MongoTestService - deleteDocuments():", ex.printStackTrace())
            return false
        }
    }

    static List<Document> loadIhrDocuments(MongoCollection<Document> collection) {
        try {
            Single<List<Document>> carrier = Flowable.fromPublisher(collection.find()).toList()
            return carrier.blockingGet()
        } catch (Exception ex) {
            log.info("Exception MongoTestService - loadIhrDocuments():", ex.printStackTrace())
            return null
        }
    }

    static dropDatabases() {
        try {
            mongoClient.getDatabaseNames().stream()
                    .forEach({ db -> db.equals("admin") ? 0 : mongoClient.getDatabase(db).drop()})
        } catch (Exception ex) {
            log.info("Exception MongoTestService - dropDatabases():", ex.printStackTrace())
        }
    }
}
