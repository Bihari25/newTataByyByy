package com.uhg.ihr.centrihealth.api.fhir;

import io.micronaut.core.util.CollectionUtils;
import io.micronaut.core.util.StringUtils;
import org.hl7.fhir.r4.model.AllergyIntolerance;
import org.hl7.fhir.r4.model.Annotation;
import org.hl7.fhir.r4.model.Bundle;
import org.hl7.fhir.r4.model.CareTeam;
import org.hl7.fhir.r4.model.Coding;
import org.hl7.fhir.r4.model.Condition;
import org.hl7.fhir.r4.model.Device;
import org.hl7.fhir.r4.model.DomainResource;
import org.hl7.fhir.r4.model.Encounter;
import org.hl7.fhir.r4.model.Extension;
import org.hl7.fhir.r4.model.HealthcareService;
import org.hl7.fhir.r4.model.HumanName;
import org.hl7.fhir.r4.model.Identifier;
import org.hl7.fhir.r4.model.Immunization;
import org.hl7.fhir.r4.model.MedicationStatement;
import org.hl7.fhir.r4.model.Meta;
import org.hl7.fhir.r4.model.Observation;
import org.hl7.fhir.r4.model.Organization;
import org.hl7.fhir.r4.model.Patient;
import org.hl7.fhir.r4.model.PractitionerRole;
import org.hl7.fhir.r4.model.Procedure;
import org.hl7.fhir.r4.model.Reference;
import org.hl7.fhir.r4.model.RelatedPerson;
import org.hl7.fhir.r4.model.StringType;

import java.util.List;

public class ResourceValidator {

    public static void validate(Bundle bundle, DomainResource dResource, Meta meta, List<Annotation> notes,
                                List<Identifier> identifiers, String resourceType) {

        System.out.println("Report ## " + ++BundleUtils.report + " : " + resourceType);
        System.out.println("Last updated date: " + meta.getLastUpdated());
        domainResourceValidation(bundle, dResource);

        List<Coding> tagList = meta.getTag();
        boolean tagExists = CollectionUtils.isNotEmpty(tagList);
        if (tagExists) {
            for (Coding coding : tagList) {
                if ("actionFlag".equalsIgnoreCase(coding.getCode())) {
                    System.out.println("Tag - display: " + coding.getDisplay());
                }
            }
        } else {
            System.out.println("No tag");
        }

        if (CollectionUtils.isNotEmpty(notes)) {
            for (Annotation annotation : notes) {
                // annotation.getAuthorStringType() != null
                if (annotation.getAuthor() != null
                        && annotation.getAuthor() instanceof StringType
                        && StringUtils.isEmpty(annotation.getAuthorStringType().toString())
                        && StringUtils.isNotEmpty(annotation.getText())) {
                    System.err.println("Note text without author string");
                }
                // annotation.getAuthorReference() != null
                if (annotation.getAuthor() != null
                        && annotation.getAuthor() instanceof Reference
                        && annotation.getAuthorReference() != null
                        && validateReference(bundle, annotation.getAuthorReference())
                        && StringUtils.isEmpty(annotation.getAuthorReference().getReference())
                        && StringUtils.isNotEmpty(annotation.getText())) {
                    System.err.println("Note text without author reference");
                }
            }
        }

        boolean recordKey = true, instanceId = true;
        for (Identifier identifier : identifiers) {
            if (identifier.getType() == null) {
                System.err.println("Identifier type missing");
            } else {
                if (StringUtils.isEmpty(identifier.getType().getText())) {
                    System.err.println("Identifier type - text missing");
                }
                if (StringUtils.isEmpty(identifier.getValue())) {
                    System.err.println("Identifier type - value missing");
                }
                if (StringUtils.isEmpty(identifier.getAssigner().getReference())) {
                    System.err.println("Identifier type - reference missing");
                } else {
                    validateReference(bundle, identifier.getAssigner());
                }
                if (identifier.getType().getText().contains("recordKey")) {
                    recordKey = false;
                }
                if (identifier.getType().getText().contains("instanceId")) {
                    instanceId = false;
                }
                if (identifier.getType().getText().contains("relatedProcedureInstanceIds")) {
                    // "value": "[6,7]", "assigner": { "reference": "#1" }
                    // with current code we can not get related CareTeam (identifier.getAssigner().getResource())
                }
                if (identifier.getType().getText().contains("relatedCareTeamInstanceIds")) {
                    // same as relatedProcedureInstanceIds
                }
            }
        }
        if (recordKey) {
            System.err.println("Identifier recordKey missing");
        }
        if (instanceId) {
            System.err.println("Identifier instanceId missing");
        }
    }

    private static boolean validateReference(Bundle bundle, Reference reference) {
        if (reference.getResource() instanceof Organization) {
            Organization org = (Organization) reference.getResource();
            if (org.getId() == null || !org.getName().equalsIgnoreCase("UHG")) {
                System.err.println("Invalid organization");
            }
        }
        if (reference.getResource() instanceof RelatedPerson) {
            RelatedPerson rp = (RelatedPerson) reference.getResource();
            if (rp.getId() == null) {
                System.err.println("Invalid relatedPerson");
            } else {
                for (HumanName hn : rp.getName()) {
                    if (hn.getGiven().toString().length() <= 0) {
                        System.err.println("Invalid relatedPerson name");
                    }
                }
            }
        }
        validateResourceId(bundle, reference.getReference());
        return true;
    }

    private static void validateResourceId(Bundle bundle, String resourceId) {
        for (Bundle.BundleEntryComponent entity : bundle.getEntry()) {
            if (resourceId.equalsIgnoreCase(entity.getResource().getId())) {
                return;
            }
        }
        System.err.println("Resource reference id is contained");
    }

    private static void domainResourceValidation(Bundle bundle, DomainResource domainResource) {

        if (domainResource instanceof Condition) {
            Condition resource = (Condition) domainResource;
        } else if (domainResource instanceof MedicationStatement) {
            MedicationStatement resource = (MedicationStatement) domainResource;
            Reference ref = resource.getSubject();
            if (ref != null) {
                Patient patient = (Patient) ref.getResource();
                if (patient != null) {
                    validateResourceId(bundle, patient.getId());
                }
            }
        } else if (domainResource instanceof AllergyIntolerance) {
            AllergyIntolerance resource = (AllergyIntolerance) domainResource;
        } else if (domainResource instanceof Observation) {
            Observation resource = (Observation) domainResource;
        } else if (domainResource instanceof CareTeam) {
            CareTeam resource = (CareTeam) domainResource;
            Reference ref = resource.getSubject();
            if (ref != null) {
                Patient patient = (Patient) ref.getResource();
                if (patient != null) {
                    validateResourceId(bundle, patient.getId());
                }
            }

            for (Extension ext : resource.getExtension()) {
                if ("https://hl7.org/fhir/R4/healthcareservice.html".equalsIgnoreCase(ext.getUrl())
                    && ext.getValue() instanceof Reference) {
                    HealthcareService hcs = (HealthcareService)((Reference) ext.getValue()).getResource();
                    if (!"HealthcareService".equalsIgnoreCase(hcs.getResourceType().name())) {
                        System.err.println("Invalid Healthcare Service");
                    }
                }
            }

            for (CareTeam.CareTeamParticipantComponent participant : resource.getParticipant()) {
                if (participant.getMember().getResource() instanceof Patient) {
                    Patient patient = (Patient) participant.getMember().getResource();
                    if (patient != null) {
                        validateResourceId(bundle, patient.getId());
                    }
                }
                if (participant.getMember().getResource() instanceof PractitionerRole) {
                    PractitionerRole role = (PractitionerRole) participant.getMember().getResource();
                    validateResourceId(bundle, role.getId());
                }
                if (participant.getMember().getResource() instanceof Organization) {
                    Organization org = (Organization) participant.getMember().getResource();
                    if (resource.getText().getId().equalsIgnoreCase("SERVICE_FACILITY_PROVIDER")) {
                        validateReference(bundle, org.getIdentifier().get(0).getAssigner());
                    }
                }
            }

        } else if (domainResource instanceof Device) {
            Device resource = (Device) domainResource;
        } else if (domainResource instanceof Immunization) {
            Immunization resource = (Immunization) domainResource;
        } else if (domainResource instanceof Procedure) {
            Procedure resource = (Procedure) domainResource;
        } else if (domainResource instanceof Encounter) {
            Encounter resource = (Encounter) domainResource;
        }
    }
}
