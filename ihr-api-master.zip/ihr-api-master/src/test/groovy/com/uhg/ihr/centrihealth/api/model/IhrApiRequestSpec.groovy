package com.uhg.ihr.centrihealth.api.model

import com.fasterxml.jackson.databind.ObjectMapper
import com.uhg.ihr.centrihealth.util.JsonUtils
import com.uhg.ihr.centrihealth.util.TestData
import spock.lang.Shared
import spock.lang.Specification
import spock.lang.Unroll

import javax.validation.ConstraintViolation
import javax.validation.Validation
import javax.validation.Validator
import javax.validation.ValidatorFactory

@Unroll
class IhrApiRequestSpec extends Specification {

    @Shared
    Set<RecordType> dataClasses = [RecordType.ADVERSE_REACTION]

    @Shared
    ValidatorFactory factory = Validation.buildDefaultValidatorFactory()

    def "Check for a Null Member Id"() {
        setup:
        def request = IhrApiRequest
                .builder()
                .correlationId(correlationId)
                .language(language)
                .dataClasses(dataClasses)
                .build()

        when:
        Validator validator = factory.getValidator()
        Set<ConstraintViolation<IhrApiRequest>> violations = validator.validate(request)
        def message = violations.first()
        def returned = message.message

        then:
        violations.size() == 1
        returned == expected

        where:
        memberId | language | correlationId | expected
        null     | "EN"     | "unit test 1" | "The member id record may not be null."
    }


    def "Check for Bad Data"() {
        setup:
        def request = new IhrApiRequest()
        def memberId = new MId()
        memberId.setIdType idType
        memberId.setIdValue idValue
        def big5 = new Big5()
        big5.setDateOfBirth "1999/10/10"
        big5.setFirstName "first"
        big5.setLastName "last"
        big5.setPolicyNumber "policy"
        big5.setSearchId "id"
        memberId.setBig5 big5
        request.setMbrId memberId
        request.setLanguage language
        request.setDataClasses dataClasses as Set<RecordType>
        request.setCorrelationId correlationId

        when:
        Validator validator = factory.getValidator()
        Set<ConstraintViolation<IhrApiRequest>> violations = validator.validate(request)
        def message = violations.size() > 0 ? violations.first() : null
        def returned = message == null ? null : message.message

        then:
        violations.size() == 1
        returned == expected

        where:
        idType    | idValue   | language | correlationId | expected
        "RALLYID" | "value 1" | null     | "unit test 1" | "The request could not be validated. An invalid language was provided."
        "RALLYID" | "value 1" | "EN"     | null          | "The request could not be validated. A correlation id was not provided."
        "RALLYID" | "value 1" | "FR"     | "unit test 1" | "The request could not be validated. An invalid language was provided."
    }


    def "Check for Good Data"() {
        setup:
        def big5 = Big5.builder()
                .firstName(firstName)
                .lastName(lastName)
                .dateOfBirth(dateOfBirth)
                .policyNumber(policyNum)
                .searchId(searchId)
                .build()
        def memberId = MId.builder()
                .big5(big5)
                .idType(idType)
                .idValue(idValue)
                .build()
        def request = IhrApiRequest.builder()
                .mbrId(memberId)
                .language(language)
                .dataClasses(dataClasses)
                .correlationId(correlationId)
                .build()

        when:
        Validator validator = factory.getValidator()
        Set<ConstraintViolation<IhrApiRequest>> violations = validator.validate(request)

        then:
        violations.size() == 0

        where:
        idType   | idValue   | dateOfBirth  | language | firstName | lastName | policyNum | searchId | correlationId | expected
        "type 1" | "value 1" | "1999/10/10" | "EN"     | "first"   | "last"   | "policy"  | "id"     | "unit test 1" | "The member id record may not be null."
        null     | "value 1" | "1999/10/10" | "EN"     | "first"   | "last"   | "policy"  | "id"     | "unit test 1" | "The member id record may not be null."
        "type 1" | null      | "1999/10/10" | "EN"     | "first"   | "last"   | "policy"  | "id"     | "unit test 1" | "The member id record may not be null."
        null     | null      | "1999/10/10" | "EN"     | "first"   | "last"   | "policy"  | "id"     | "unit test 1" | "The member id record may not be null."
    }

    def "Setter/Getter methods"() {
        when:
        IhrApiRequest ihrApiRequest = TestData.sampleIhrApiRequest()

        then:
        ihrApiRequest.correlationId == "CR1234"
        ihrApiRequest.language == "EN"
        ihrApiRequest.dataClasses.size() == 2
    }


    def "Validate for member id for: #version"() {
        given:
        ObjectMapper objectMapper = new ObjectMapper()

        when:
        def result = objectMapper.readValue(requestJson, IhrApiRequest.class)

        then:
        result.mbrId.big5.lastName == "xmog_ln9"

        where:
        version         | requestJson
        "For version 1" | "{ \"correlationId\": \"123\", \"language\": \"EN\", \"mbrID\": { \"big5\": { \"firstName\": \"xmog_fn9\", \"lastName\": \"xmog_ln9\", \"dateOfBirth\": \"1929/06/02\", \"policyNumber\": \"rt10367\", \"searchId\": \"66676575\" }, \"idType\": \"RALLYID\", \"idValue\": \"STD85230440511\" }, \"dataClasses\": [ \"ADVERSE_REACTION\" ] }"
        "For version 2" | "{ \"correlationId\": \"123\", \"language\": \"EN\", \"mbrId\": { \"big5\": { \"firstName\": \"xmog_fn9\", \"lastName\": \"xmog_ln9\", \"dateOfBirth\": \"1929/06/02\", \"policyNumber\": \"rt10367\", \"searchId\": \"66676575\" }, \"idType\": \"RALLYID\", \"idValue\": \"STD85230440511\" }, \"dataClasses\": [ \"ADVERSE_REACTION\" ] }"
    }

    def "Validate for data filters"() {
        given:
        IhrApiRequest sampleRequest = TestData.sampleIhrApiRequest()
        def dataFilter = [new FilterPair(key: 'ClinicalRelevantStartDate', value: '2019-11-17'),
                          new FilterPair(key: 'ClinicalRelevantEndDate', value: '2019-12-17'),
                          new FilterPair(key: 'PresenceState', value: 'PRESENT')]

        sampleRequest.dataFilters = dataFilter

        when:
        def result = JsonUtils.serializeJson(sampleRequest)

        then:
        result
        result.contains('ClinicalRelevantStartDate')
        result.contains('ClinicalRelevantEndDate')
        result.contains('PresenceState')
    }
}
