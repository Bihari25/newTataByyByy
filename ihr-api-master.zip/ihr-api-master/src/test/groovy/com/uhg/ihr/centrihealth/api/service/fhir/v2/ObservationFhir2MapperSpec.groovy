package com.uhg.ihr.centrihealth.api.service.fhir.v2

import com.uhg.ihr.centrihealth.api.model.FhirResource
import com.uhg.ihr.centrihealth.api.model.dataclass.Constants
import com.uhg.ihr.centrihealth.api.model.dataclass.DataClass
import com.uhg.ihr.centrihealth.api.model.dataclass.HealthObservations
import com.uhg.ihr.centrihealth.api.model.dataclass.IhrTerm
import com.uhg.ihr.centrihealth.api.service.fhir.BaseFhirSpecification
import com.uhg.ihr.centrihealth.api.service.fhir.FhirMapper
import com.uhg.ihr.centrihealth.api.util.AppUtils
import org.apache.commons.lang3.StringUtils
import org.hl7.fhir.r4.model.*
import spock.lang.Shared
import spock.lang.Unroll

class ObservationFhir2MapperSpec extends BaseFhirSpecification {

    //Shared between tests
    @Shared
    private ObservationFhir2Mapper mapper

    //Unique for each test
    private FhirResource fhirResource
    private HealthObservations healthObservations
    private Observation observation

    def setupSpec() {
        mapper = ObservationFhir2Mapper.of()
    }

    def setup() {
        fhirResource = buildFhirResource()
        healthObservations = new HealthObservations()
        observation = new Observation()
    }

    @Unroll
    def "#desc1 will #desc2"() {
        given:

        DataClass dataClass = DataClass.builder().healthObservations(hObservations).build()

        when:
        mapper.map(fhirResource, dataClass)
        List<Observation> observations = getResourcesOfTypeFromBundle(fhirResource.getBundle(), Observation.class)

        then:
        observations.size() == (hObservations == null ? 0 : hObservations.size())

        where:
        desc1                   | desc2                    | hObservations
        "No healthObservation"  | "not map to observation" | null
        "One healthObservation" | "map one observation"    | List.of(new HealthObservations())
        "Two healthObservation" | "map two observations"   | List.of(new HealthObservations(), new HealthObservations())
    }

    def "encounter id set"() {
        given:

        when:
        mapper.map(fhirResource, healthObservations)
        Observation foundObservation = getFirstBundleResource(fhirResource.getBundle(), Observation.class)

        then:
        foundObservation != null
        StringUtils.isNotBlank(foundObservation.getId())
    }

    def "patient -> subject"() {
        given:

        when:
        mapper.buildObservationResource(observation, fhirResource, healthObservations)

        then:
        observation.getSubject().getResource() instanceof Patient
        (observation.getSubject().getResource() as Patient).getId() == fhirResource.getPatient().getId()
    }

    def "lastUpdateDate -> meta.lastUpdated"() {
        given:
        Meta meta = new Meta()
        observation.setMeta(meta)
        and:
        String lastUpdateDate = "2000/01/01"
        and:
        healthObservations.setLastUpdateDate(lastUpdateDate)

        when:
        mapper.buildObservationResource(observation, fhirResource, healthObservations)

        then:
        meta.getLastUpdated() == FhirMapper.toDate(lastUpdateDate)
    }

    def "sensitivityClass -> meta.security"() {
        given:
        Meta meta = new Meta()
        observation.setMeta(meta)
        and:
        healthObservations.setSensitivityClasses(List.of("SENSITIVE"))

        when:
        mapper.buildObservationResource(observation, fhirResource, healthObservations)

        then:
        meta.getSecurity() != null
        meta.getSecurity(Constants.SECURITY_SYSTEM_URL, Constants.SECURITY_CODE) != null
    }

    def "Procedure -> partOf"() {
        given:
        FhirResource mockFhirResource = buildMockedFhirResource(fhirResource.getBundle(), fhirResource.getPatient())

        when:
        mapper.buildObservationResource(observation, mockFhirResource, healthObservations)

        then:
        1 * mockFhirResource.addFhirResourceToDeferredMapper(observation, healthObservations)
    }

    def "recordKey -> identifier"() {
        given:
        String recordKey = "123456789"
        and:
        healthObservations.setRecordKey(recordKey)

        when:
        mapper.buildObservationResource(observation, fhirResource, healthObservations)

        then:
        observation.getIdentifier() != null
        observation.getIdentifier().get(0).getValue() == recordKey
        observation.getIdentifier().get(0).getType().getText() == Constants.RECORD_KEY
    }

    def "referenceIds -> identifier"() {
        given:
        String referenceId = "AAA12345"
        and:
        healthObservations.setReferenceIds(List.of(referenceId))

        when:
        mapper.buildObservationResource(observation, fhirResource, healthObservations)

        then:
        observation.getIdentifier() != null
        observation.getIdentifier().get(0).getValue() == AppUtils.jsonEscape(List.of(referenceId))
        observation.getIdentifier().get(0).getType().getText() == Constants.REFERENCE_IDS
    }

    def "objectId -> identifier"() {
        given:
        long objectId = 123456
        and:
        healthObservations.setObjectId(BigInteger.valueOf(objectId))

        when:
        mapper.buildObservationResource(observation, fhirResource, healthObservations)

        then:
        observation.getIdentifier() != null
        observation.getIdentifier().get(0).getValue() == objectId.toString()
        observation.getIdentifier().get(0).getType().getText() == Constants.INSTANCE_ID
    }

    @Unroll
    def "observation -> code with #desc"() {
        given:
        IhrTerm observationTerm = buildBasicIhrTerm()
        and:
        if (loincCode != null) {
            observationTerm.setLoincCode(loincCode)
        }
        and:
        healthObservations.setObservation(observationTerm)

        when:
        mapper.buildObservationResource(observation, fhirResource, healthObservations)
        CodeableConcept code = observation.getCode()

        then:
        code != null
        code.getText() == observationTerm.getIhrLaymanTerm()
        code.getCoding().get(0).getDisplay() == observationTerm.getIhrTerm()
        code.getCoding().get(0).getSystem() == observationTerm.getSourceVocabulary()
        code.getCoding().get(0).getCode() == observationTerm.getSourceVocabularyCode()
        if (loincCode == null) {
            code.getCoding().size() == 1
        } else {
            code.getCoding().get(1).getSystem() == ObservationFhir2Mapper.LOINC_CODE_URL
            code.getCoding().get(1).getCode() == observationTerm.getLoincCode()
        }

        where:
        desc            | loincCode
        "no loinc code" | null
        "loinc code"    | "LoincCodeStuff"
    }

    def "observationValue -> valueCodeableConcept"() {
        given:
        IhrTerm observationTerm = buildBasicIhrTerm()
        and:
        healthObservations.setObservationValue(observationTerm)

        when:
        mapper.buildObservationResource(observation, fhirResource, healthObservations)
        CodeableConcept code = observation.getComponentFirstRep().getValueCodeableConcept()

        then:
        code != null
        code.getText() == observationTerm.getIhrLaymanTerm()
        code.getCoding().get(0).getDisplay() == observationTerm.getIhrTerm()
        code.getCoding().get(0).getSystem() == observationTerm.getSourceVocabulary()
        code.getCoding().get(0).getCode() == observationTerm.getSourceVocabularyCode()
    }

    def "valueString -> valueString"() {
        given:
        String valueString = "ValueString13456789"
        and:
        healthObservations.setValueString(valueString)

        when:
        mapper.buildObservationResource(observation, fhirResource, healthObservations)

        then:
        observation.getValue() instanceof StringType
        (observation.getValue() as StringType).getValue() == valueString
    }

    def "shortPreferredTerm -> extension"() {
        given:
        String shortPreferredTerm = "ShortPreferredTerm777777"
        and:
        IhrTerm observationUnitOfMeasure = buildBasicIhrTerm()
        observationUnitOfMeasure.setShortPreferredTerm(shortPreferredTerm)
        and:
        healthObservations.setObservationUnitOfMeasure(observationUnitOfMeasure)

        when:
        mapper.buildObservationResource(observation, fhirResource, healthObservations)

        then:
        observation.getExtension() != null
        observation.getExtensionByUrl(Constants.VALUE_STRING_UNIT_OF_MEASURE_URL) != null
        observation.getExtensionByUrl(Constants.VALUE_STRING_UNIT_OF_MEASURE_URL).getValue() instanceof StringType
        (observation.getExtensionByUrl(Constants.VALUE_STRING_UNIT_OF_MEASURE_URL).getValue() as StringType).getValue() == shortPreferredTerm
    }

    def "observationDate -> effectiveDateTime"() {
        given:
        String observationDate = "2000/02/02"
        and:
        healthObservations.setObservationDate(observationDate)

        when:
        mapper.buildObservationResource(observation, fhirResource, healthObservations)

        then:
        observation.getEffective() != null
        observation.getEffective() instanceof DateTimeType
        (observation.getEffective() as DateTimeType).equalsShallow(mapper.toDateTimeTypeFromDate(observationDate))
    }

    def "status.IHRTerm -> status"() {
        given:
        IhrTerm status = buildBasicIhrTerm()
        and:
        healthObservations.setStatus(status)

        when:
        mapper.buildObservationResource(observation, fhirResource, healthObservations)

        then:
        observation.getStatus() == Observation.ObservationStatus.UNKNOWN
    }

    def "referenceRange -> referenceRange"() {
        given:
        String referenceRange = "SomeReferenceRange555555"
        and:
        healthObservations.setReferenceRange(referenceRange)

        when:
        mapper.buildObservationResource(observation, fhirResource, healthObservations)

        then:
        observation.getReferenceRange() != null
        observation.getReferenceRange().get(0).getText() == referenceRange
    }

    def "abnormalObservation.sourceVocabularyCode -> interpretation"() {
        given:
        IhrTerm abnormalObservation = buildBasicIhrTerm()
        and:
        healthObservations.setAbnormalObservation(abnormalObservation)

        when:
        mapper.buildObservationResource(observation, fhirResource, healthObservations)

        then:
        observation.getInterpretation() != null
        observation.getInterpretation().get(0).getText() == abnormalObservation.getIhrLaymanTerm()
        observation.getInterpretation().get(0).getCodingFirstRep().getDisplay() == abnormalObservation.getIhrTerm()
        observation.getInterpretation().get(0).getCodingFirstRep().getSystem() == abnormalObservation.getSourceVocabulary()
        observation.getInterpretation().get(0).getCodingFirstRep().getCode() == abnormalObservation.getSourceVocabularyCode()
    }

    def "add resource to bundle"() {
        given:

        when:
        mapper.buildObservationResource(observation, fhirResource, healthObservations)
        Observation observationBundled = getFirstBundleResource(fhirResource.getBundle(), Observation.class)

        then:
        observationBundled != null
        observationBundled.getId() == observation.getId()
    }
}
