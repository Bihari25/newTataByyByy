package com.uhg.ihr.centrihealth.api.exception

import com.uhg.ihr.centrihealth.api.rest.ApiControllerSpec
import io.micronaut.http.HttpResponse
import io.micronaut.http.client.exceptions.HttpClientException
import spock.lang.Specification

class HttpClientExceptionHandlerSpec extends Specification {

    HttpClientExceptionHandler httpClientExceptionHandler = new HttpClientExceptionHandler()

    def "HttpClientExceptionHandler:handle"() {
        when:
        HttpResponse result = httpClientExceptionHandler.handle(ApiControllerSpec.baseRequest(), new HttpClientException("uh oh"))

        then:
        result.body().toString().contains("there was an error handling this request")
        result.getStatus().getCode() == 500
    }

}