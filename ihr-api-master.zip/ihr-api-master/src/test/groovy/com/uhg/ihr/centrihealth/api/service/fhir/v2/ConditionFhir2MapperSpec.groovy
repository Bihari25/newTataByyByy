package com.uhg.ihr.centrihealth.api.service.fhir.v2

import com.uhg.ihr.centrihealth.api.constant.GlobalConstants
import com.uhg.ihr.centrihealth.api.constant.GlobalUrlConstant
import com.uhg.ihr.centrihealth.api.model.FhirResource
import com.uhg.ihr.centrihealth.api.model.dataclass.HealthCondition
import com.uhg.ihr.centrihealth.api.model.dataclass.IhrTerm
import com.uhg.ihr.centrihealth.api.model.dataclass.Note
import com.uhg.ihr.centrihealth.api.service.fhir.BaseFhirSpecification
import com.uhg.ihr.centrihealth.util.TestData
import org.hl7.fhir.r4.model.*
import spock.lang.Shared
import spock.lang.Unroll

@Unroll
class ConditionFhir2MapperSpec extends BaseFhirSpecification {

    @Shared
    static ConditionFhir2Mapper mapper = ConditionFhir2Mapper.of()

    @Unroll
    def "Test AConditionFhir2 all identifiers fhir conversion #test_name"() {

        when:
        // map to fhir resource
        HealthCondition healthCondition = HealthCondition.builder()
                .recordKey(recordKey)
                .relatedObservations(relatedCondCare as List<Integer>)
                .relatedCareTeam(relatedCondCare as List<BigInteger>)
                .sensitivityClasses(referenceIDs as List<String>)
                .sourceClaimIds(referenceIDs as List<String>)
                .relatedConditions(relatedCondCare as List<BigInteger>)
                .recorderId(recorderId)
                .objectId(objectId)
                .referenceIds(referenceIDs as List<String>)
                .build()
        Condition condition = getFhirResourceCondition(healthCondition)

        def res_objectId = getValueOfIdentifier(condition.getIdentifier(), GlobalConstants.OBJECT_ID)
        def res_recordKey = getValueOfIdentifier(condition.getIdentifier(), GlobalConstants.RECORD_KEY)
        def res_referenceId = getValueOfIdentifier(condition.getIdentifier(), GlobalConstants.REFERENCE_IDS)
        def res_recorderId = (condition.getRecorder().getResource() == null) ? null
                : (condition.getRecorder().getResource() as Practitioner).getIdentifier().get(0).getValue()

        def res_relatedConditions = getValueOfIdentifier(condition.getIdentifier(), GlobalConstants.RELATED_CONDITION_INSTANCE_IDS)
        def res_relatedObservations = getValueOfIdentifier(condition.getIdentifier(), GlobalConstants.RELATED_OBSERVATION_INSTANCE_IDS)
        def res_relatedCareTeam = getValueOfIdentifier(condition.getIdentifier(), GlobalConstants.RELATED_CARE_TEAM_INSTANCE_IDS)
        def res_sourceClaimIds = getValueOfIdentifier(condition.getIdentifier(), GlobalConstants.SOURCE_CLAIM_IDS)

        then:

        res_objectId == checkNull(objectId)
        res_referenceId == checkIsListNull(referenceIDs)
        res_recordKey == checkNull(recordKey)
        res_recorderId == recorderId
        res_relatedConditions == checkIsListNull(relatedCondCare)
        res_relatedObservations == checkIsListNull(relatedCondCare)
        res_relatedCareTeam == checkIsListNull(relatedCondCare)
        res_sourceClaimIds == checkIsListNull(referenceIDs)

        where:

        test_name            | relatedCondCare | objectId | recorderId | recordKey                                                      | referenceIDs
        "happy  Path check " | [12344, 1231]   | 9        | "981232"   | "o*}Dci^Vj2DS9mggDvEzepfVVqzx{ZEsiUvmmn<+gbH%HEjP.xoJ0P2h8Y(h" | ["2009-01-02T03:04:44Z-Rally-1sE"]
        "null check "        | null            | null     | null       | null                                                           | null
    }

    @Unroll
    def "Test ConditionFhir2 note"() {
        when:
        Note note = buildSampleNote(text, time, author, noteType)

        HealthCondition healthCondition = HealthCondition.builder()
                .note(Arrays.asList(note))
                .build();
        Condition ai = getFhirResourceCondition(healthCondition);
        def res_note = ai.getNote().get(0)
        Extension noteTypeValue = getExtensionFromList(res_note.getExtension(), GlobalUrlConstant.IHR_NOTE_TYPE_URL)
        def authorReference = res_note.getAuthorReference().getResource()
        def authorReferenceIdentifier = getAuthorReferenceIdentifier(authorReference, GlobalConstants.EMPLOYEE_ID)

        then:

        noteTypeValue.getValue().toString() == noteType
        res_note.getText() == text
        res_note.getTimeElement().getValueAsString() == time
        res_note.getAuthorReference().getResource().fhirType() == resourceType.toString()
        authorReferenceIdentifier.getValue() == author

        where:

        noteType          | text                         | time                   | author         || resourceType
        "Clinical Note"   | "Patient reports."           | "2019-03-28T00:00:00Z" | "ACT000123456" || ResourceType.Practitioner
        "PatientNote"     | "This medication is working" | "2018-03-28T00:00:00Z" | "ACT000000111" || ResourceType.Patient
        "Clinical Note"   | "Patient reports medication" | "2020-07-28T11:11:11Z" | "ACT098763"    || ResourceType.Practitioner
        "PatientTypeNote" | "This medication"            | "2012-03-28T00:00:00Z" | "ACT0003456"   || ResourceType.Patient
        ""                | "This medication"            | "2018-03-28T00:00:00Z" | "ACT0003456"   || ResourceType.Patient
        null              | "This medication report "    | "2014-03-28T00:00:00Z" | "ACT0003456"   || ResourceType.Patient
    }

    @Unroll
    def "Test ConditionFhir2 asserter object #desc"() {
        when:
        // map to fhir resource
        HealthCondition healthCondition = HealthCondition.builder().asserterObject(
                IhrTerm.builder()
                        .ihrLaymanTerm(laymanTerm)
                        .ihrTerm(ihrTerm)
                        .sourceVocabulary(sVocabulary)
                        .sourceVocabularyCode(svCode)
                        .build()).build()

        Condition condition = getFhirResourceCondition(healthCondition)

        def res_Asserter = condition.getAsserter()

        then:

        getAsserterText(condition.getAsserter(), desc) == svCode

        where:

        desc                 | laymanTerm              | sVocabulary              | svCode                  | ihrTerm
        "RelatedPerson-1"    | "Care giver"            | "http://snomed.info/sct" | "Caregiver"             | "Caregiver"
        "RelatedPerson-2"    | "Family Member"         | "http://snomed.info/sct" | "Family Member"         | "Family Member"
        "RelatedPerson-3"    | "Health Care Proxy"     | "http://snomed.info/sct" | "Health Care Proxy"     | "Health Care Proxy"
        "RelatedPerson-4"    | "Power of Attorney"     | "http://snomed.info/sct" | "Power of Attorney"     | "Power of Attorney"
        "RelatedPerson-5"    | "Other"                 | "http://snomed.info/sct" | "Other"                 | "Other"

        "PractitionerRole-1" | "Facility Staff"        | "http://snomed.info/sct" | "Facility Staff"        | "Facility Staff"
        "PractitionerRole-2" | "Medical Director"      | "http://snomed.info/sct" | "Medical Director"      | "Medical Director"
        "PractitionerRole-3" | "Myself"                | "http://snomed.info/sct" | "Myself"                | "Myself"
        "PractitionerRole-4" | "Pharmacist"            | "http://snomed.info/sct" | "Pharmacist"            | "Pharmacist"
        "PractitionerRole-5" | "Prescriber"            | "http://snomed.info/sct" | "Prescriber"            | "Prescriber"
        "PractitionerRole-6" | "Primary Care Provider" | "http://snomed.info/sct" | "Primary Care Provider" | "Primary Care Provider"
        "Patient"            | "Patient"               | "http://snomed.info/sct" | "cinderella"            | "Patient"

        "All are null"       | null                    | null                     | null                    | null
    }

    def "Test  Condition Code CodeableConcept #desc"() {
        when:
        //build v2 resource
        FhirResource fhirResource = FhirResource.builder()
                .bundle(new Bundle().setType(Bundle.BundleType.SEARCHSET))
                .patient(TestData.defaultPatient()).build()
        // map to fhir resource
        HealthCondition healthCondition = HealthCondition.builder()

                .healthCondition(IhrTerm.builder()
                        .ihrLaymanTerm(laymanTerm)
                        .ihrTerm(ihrTerm)
                        .sourceVocabulary(sVocabulary)
                        .sourceVocabularyCode(svCode)
                        .icd10cmCode(icd10cmCode)
                        .build()).build()

        mapper.map(fhirResource, healthCondition)
        Bundle bundle = fhirResource.getBundle()

        Condition condition = getFirstBundleResource(bundle, ResourceType.Condition)

        def res_healthConCode = condition.getCode()
        def res_healthCondition = res_healthConCode.getCodingFirstRep()

        then:

        res_healthConCode.getText() == checkNull(laymanTerm)
        res_healthCondition.getDisplay() == checkNull(ihrTerm)
        res_healthCondition.getSystem() == checkNull(sVocabulary)
        res_healthCondition.getCode() == checkNull(svCode)

        where:

        desc           | laymanTerm | sVocabulary              | svCode    | ihrTerm    | icd10cmCode
        "Happy Path"   | "oralText" | "http://snomed.info/sct" | "7898989" | "oralCode" | "J66"
        "All are null" | null       | null                     | null      | null       | null
    }

    def "test all dateTime in condition #desc"() {
        when:
        // build v2 resource
        FhirResource fhirResource = FhirResource.builder()
                .bundle(new Bundle().setType(Bundle.BundleType.SEARCHSET))
                .patient(TestData.defaultPatient()).build()
        // map to fhir resource
        HealthCondition healthCondition = HealthCondition.builder()
                .onsetPeriodStart(startValue)
                .onsetPeriodEnd(endValue)
                .recordedDate(startValue)
                .lastUpdateDate(startValue)
                .build()

        mapper.map(fhirResource, healthCondition)
        Bundle bundle = fhirResource.getBundle()

        Condition condition = getFirstBundleResource(bundle, ResourceType.Condition)

        def lastUpdateDate = condition.getMeta().getLastUpdatedElement()
        def recodedDate = condition.getRecordedDateElement()

        then:
        condition.getOnsetDateTimeType().getValueAsString() == checkNull(startValue)
        condition.getAbatementDateTimeType().getValueAsString() == checkNull(endValue)
        recodedDate.getValueAsString() == checkNull(startValue)
        lastUpdateDate.getValueAsString() == checkNull(startValue)

        where:
        desc               || startValue             | endValue
        "happy path 1"     || "2019-06-19T00:00:00Z" | "2021-07-19T00:00:00Z"
        "start date empty" || null                   | "2010-07-19T00:00:00Z"
        "end date empty"   || "2019-05-20T00:00:00Z" | null
        "both empty"       || null                   | null
    }


    def "Test  Extension of List<String> #desc"() {
        when:
        //build v2 resource
        FhirResource fhirResource = FhirResource.builder()
                .bundle(new Bundle().setType(Bundle.BundleType.SEARCHSET))
                .patient(TestData.defaultPatient()).build()
        // map to fhir resource

        HealthCondition healthCondition = HealthCondition.builder()
                .presenceStateTerm(presenceStateTerm)
                .clinicallyRelevantDate(clinicRelevantDate)
                .conditionStartDate(condiStartDate)
                .build()

        mapper.map(fhirResource, healthCondition)
        Bundle bundle = fhirResource.getBundle()

        Condition condition = getFirstBundleResource(bundle, ResourceType.Condition)

        def res_presenceStateTerm = getValueOfExtension(condition.getExtension(), GlobalUrlConstant.PRESENCESTATE_URL)
        def res_clinicRelevantDate = getDateAsStringFromExtension(condition.getExtensionByUrl(GlobalUrlConstant.CLINICAL_RELEVANT_DATE_URL))
        def res_condiStartDate = getDateAsStringFromExtension(condition.getExtensionByUrl(GlobalUrlConstant.START_DATE_URL))

        then:

        res_presenceStateTerm == checkNull(presenceStateTerm)
        res_clinicRelevantDate == checkNull(clinicRelevantDate)
        res_condiStartDate == checkNull(condiOutStartDate)
        where:

        desc         | presenceStateTerm           | clinicRelevantDate     | condiStartDate || condiOutStartDate
        "Happy path" | "presenceStateTerm-example" | "2021-01-02T03:04:44Z" | "2008/07/15"   || "2008-07-15T00:00:00Z"
        "null check" | null                        | null                   | null           || null
    }


    def "Test  status and clincal cource #desc"() {
        when:
        //build v2 resource
        FhirResource fhirResource = FhirResource.builder()
                .bundle(new Bundle().setType(Bundle.BundleType.SEARCHSET))
                .patient(TestData.defaultPatient()).build()
        // map to fhir resource
        HealthCondition healthCondition = HealthCondition.builder()
                .clinicalCourse(clinicalCourse)
                .status(IhrTerm.builder()
                        .ihrTerm(ihrTerm)
                        .build()).build()

        mapper.map(fhirResource, healthCondition)
        Bundle bundle = fhirResource.getBundle()

        Condition condition = getFirstBundleResource(bundle, ResourceType.Condition)

        def res_healthStatus = condition.getClinicalStatus()
        def clinical_cource = condition.getStageFirstRep().getSummary()
        then:

        res_healthStatus.getText() == checkNull(ihrTerm)
        clinical_cource.getText() == checkNull(clinicalCourse)


        where:

        desc           | ihrTerm    | clinicalCourse
        "Happy Path"   | "oralCode" | "Active"
        "All are null" | null       | null

    }


    static getFhirResourceCondition(HealthCondition condition) {
        //build v2 resource
        FhirResource fhirResource = FhirResource.builder()
                .bundle(new Bundle().setType(Bundle.BundleType.SEARCHSET))
                .patient(TestData.defaultPatient())
                .practitioner(TestData.practitionerMap())
                .practitionerRole(TestData.practitionerRoleMap())
                .relatedPerson(TestData.relatedPersonMap()).build()
        mapper.map(fhirResource, condition)
        Bundle bundle = fhirResource.getBundle()

        Condition con = getFirstBundleResource(bundle, ResourceType.Condition)
        return con;
    }

    private String getAsserterText(Reference asserter, String desc) {
        if (asserter.getResource() == null)
            return null;
        else if (desc.contains("RelatedPerson")) {
            return (asserter.getResource() as RelatedPerson).getRelationship().get(0).getText();
        } else if (desc.contains("PractitionerRole")) {
            return (asserter.getResource() as PractitionerRole).getCode().get(0).getText();
        } else if (desc.contains("Patient")) {
            return (asserter.getResource() as Patient).getName().get(0).getGiven().get(0)
        } else {
            return null;
        }
    }
}
