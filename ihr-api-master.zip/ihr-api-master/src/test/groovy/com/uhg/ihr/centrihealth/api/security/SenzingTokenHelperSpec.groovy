package com.uhg.ihr.centrihealth.api.security


import spock.lang.Specification

class SenzingTokenHelperSpec extends Specification {
    def today = new Date()
    def sampleRoles = ["admin"]
    def defaultSecret = 'THISISNOTREALn2rDSDA!!5u8x/A%D*G-KaPdSgVkDASDASDASYp3s6v9y$B&E(H+MbQeThWmZDSDSq4t7w!z%C*F-KKLJ@NcRf'
    def tokenDuration = new Long(30000)

    def "SenzingTokenHelper: generateToken"() {
        when:
        def result = SenzingTokenHelper.generateToken("ihr-external-api", null, null, today, tokenDuration, sampleRoles, defaultSecret)
        then:
        result
        result.length() > 0
        result.contains("eyJ0eXA")
    }

}