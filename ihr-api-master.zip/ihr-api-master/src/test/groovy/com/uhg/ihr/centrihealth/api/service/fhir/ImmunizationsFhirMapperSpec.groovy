package com.uhg.ihr.centrihealth.api.service.fhir


import com.uhg.ihr.centrihealth.api.model.FhirResource
import com.uhg.ihr.centrihealth.api.model.dataclass.Constants
import com.uhg.ihr.centrihealth.api.model.dataclass.IhrTerm
import com.uhg.ihr.centrihealth.api.model.dataclass.Immunizations
import com.uhg.ihr.centrihealth.util.TestData
import org.hl7.fhir.r4.model.Bundle
import org.hl7.fhir.r4.model.CodeableConcept
import org.hl7.fhir.r4.model.Immunization
import org.hl7.fhir.r4.model.IntegerType
import org.hl7.fhir.r4.model.ResourceType
import spock.lang.Shared
import spock.lang.Unroll

class ImmunizationsFhirMapperSpec extends BaseFhirSpecification {
    @Shared
    static ImmunizationFhirMapper mapper = ImmunizationFhirMapper.of()

    @Unroll
    def "Immunization all identifiers fhir conversion"() {

        when:
        // map to fhir resource
        Immunizations immunizations = Immunizations.builder().recordKey(recordKey)
                .objectId(objectId as BigInteger)
                .referenceIds(referenceIDs as List<String>)
                .relatedCareTeam(relatedCareTeamIds as List<BigInteger>)
                .relatedConditions(conditionInstanceID as List<BigInteger>)
                .relatedObservations(observationInstanceID as List<BigInteger>)
                .sourceClaimIds(sourceClaimIDs as List<String>)
                .build()

        Immunization imm = getFhirResourceImmunization(immunizations)

        def res_objectId = getValueOfIdentifier(imm.getIdentifier(), Constants.INSTANCE_ID)
        def res_recordKey = getValueOfIdentifier(imm.getIdentifier(), Constants.RECORD_KEY)

        def res_careTeamInstanceId = getValueOfIdentifier(imm.getIdentifier(), Constants.RELATED_CARE_TEAM_INSTANCE_IDS)
        def res_conditionInstanceId = getValueOfIdentifier(imm.getIdentifier(), Constants.RELATED_CONDITION_INSTANCE_IDS)
        def res_observationInstanceId = getValueOfIdentifier(imm.getIdentifier(), Constants.RELATED_OBSERVATION_INSTANCE_IDS)

        def res_sourceClaimIds = getValueOfIdentifier(imm.getIdentifier(), Constants.SOURCE_CLAIM_IDS)
        def res_referenceId = getValueOfIdentifier(imm.getIdentifier(), Constants.REFERENCE_IDS)


        then:

        res_objectId == checkNull(objectId)

        res_referenceId == checkIsListNull(referenceIDs)
        res_recordKey == checkNull(recordKey)

        res_careTeamInstanceId == checkIsListNull(relatedCareTeamIds)
        res_conditionInstanceId == checkIsListNull(conditionInstanceID)
        res_observationInstanceId == checkIsListNull(observationInstanceID)
        res_sourceClaimIds == checkIsListNull(sourceClaimIDs)


        where:
        test_name            | objectId | recordKey                                                      | referenceIDs                       | concept       | conditionInstanceID | observationInstanceID | sourceClaimIDs      | relatedCareTeamIds
        "happy  Path check " | 9        | "o*}Dci^Vj2DS9mggDvEzepfVVqzx{ZEsiUvmmn<+gbH%HEjP.xoJ0P2h8Y(h" | ["2009-01-02T03:04:44Z-Rally-1sE"] | [123456, 789] | [66464, 83737]      | [123456, 789]         | ["ABCDE", "TESTID"] | [2110756776942227460, 2110756776942227460, 2110756776942227460]
        "null check "        | null     | null                                                           | null                               | null          | null                | null                  | null                | null
    }

    @Unroll
    def "Test  CodeableConcept #desc"() {
        when:
        // map to fhir resource
        Immunizations immunizations = Immunizations.builder()
                .concept(IhrTerm.builder()
                        .ihrLaymanTerm(laymanTerm)
                        .ihrTerm(ihrTerm)
                        .sourceVocabulary(sVocabulary)
                        .sourceVocabularyCode(svCode)
                        .icd10cmCode(icd10cmCode)
                        .build()).build()

        Immunization imm = getFhirResourceImmunization(immunizations)

        def res_CodeableConcept = imm.getReasonCode().get(0) as CodeableConcept
        def res_Coding = res_CodeableConcept.getCodingFirstRep()

        then:

        res_CodeableConcept.getText() == checkNull(laymanTerm)
        res_Coding.getDisplay() == checkNull(ihrTerm)
        res_Coding.getSystem() == checkNull(sVocabulary)
        res_Coding.getCode() == checkNull(svCode)


        where:

        desc           | laymanTerm | sVocabulary              | svCode    | ihrTerm    | icd10cmCode
        "Happy Path"   | "oralText" | "http://snomed.info/sct" | "7898989" | "oralCode" | "J66"
        "All are null" | null       | null                     | null      | null       | null

    }

    @Unroll
    def "Test  enum and all dateTime attributes"() {
        when:
        // map to fhir resource
        Immunizations immunizations = Immunizations.builder()
                .presenceStateTerm(presenceStateTerm)
                .healthEventDate(healthEventDate)
                .clinicallyRelevantDate(clinicallyRelevantDate)
                .lastUpdateDate(lastUpdateDate)
                .build()
        Immunization imm = getFhirResourceImmunization(immunizations)

        def res_presenceStateTerm = getValueOfExtension(imm.getExtension(), Constants.PRESENCE_STATE_TERM_URL)
        def res_healthEventDate = getDateTimeValue(imm.getOccurrence())
        def res_clinicallyRelevantDate = getDateAsStringFromExtension(imm.getExtensionByUrl(Constants.CLINICALLY_RELEVANT_DATE_URL))
        def res_lastUpdateDate = getLastUpdateDate(imm.getMeta())
        then:
        res_presenceStateTerm == checkNull(presenceStateTerm)
        res_healthEventDate == checkNull(healthEventDate)
        res_clinicallyRelevantDate == checkNull(clinicallyRelevantDate)
        res_lastUpdateDate == checkNull(lastUpdateDate)
        where:
        desc         | presenceStateTerm | healthEventDate        | clinicallyRelevantDate | lastUpdateDate
        "Happy path" | "Past Occurrence" | "2021-03-02T03:04:44Z" | "2021-01-02T03:04:44Z" | "2021-02-27T03:04:44Z"
        "All Null"   | null              | null                   | null                   | null
    }

    @Unroll
    def "Test  medication #desc"() {
        when:
        // map to fhir resource
        Immunizations immunizations = Immunizations.builder()
                .medication(IhrTerm.builder()
                        .ihrLaymanTerm(laymanTerm)
                        .ihrTerm(ihrTerm)
                        .sourceVocabulary(sVocabulary)
                        .sourceVocabularyCode(svCode)
                        .referenceIds(referenceIDs as List<String>)
                        .recordKey(recordKey)
                        .build()).build()

        Immunization imm = getFhirResourceImmunization(immunizations)
        def res_CodeableConcept = imm.getVaccineCode()
        def res_Coding = res_CodeableConcept.getCodingFirstRep()
        def res_referenceId = getValueOfIdentifier(imm.getIdentifier(), Constants.VACCINE_REFERENCE_IDS)
        def res_recordKey = getValueOfIdentifier(imm.getIdentifier(), Constants.VACCINE_RECORD_KEY)
        then:
        res_CodeableConcept.getText() == ihrTerm
        res_Coding.getDisplay() == laymanTerm
        res_Coding.getSystem() == sVocabulary
        res_Coding.getCode() == svCode
        res_referenceId == checkIsListNull(referenceIDs)
        res_recordKey == checkNull(recordKey)
        where:
        desc           | laymanTerm             | sVocabulary       | svCode        | ihrTerm                                                  | referenceIDs                         | recordKey
        "Happy Path"   | "Adacel Intramuscular" | "NDC Foreign Key" | "49281040010" | "Adacel Intramuscular Suspension 5-2-15.5 LF-mcg/0.5 mL" | ["2010-01-02T03:04:44Z-vaccine-1sE"] | "recordkey-vaccine-1sE"
        "All are null" | null                   | null              | null          | null                                                     | null                                 | null
    }

    @Unroll
    def "Test all dosage attributes #desc"() {
        when:
        // map to fhir resource
        Immunizations immunizations = Immunizations.builder()
                .dosageUnit(IhrTerm.builder()
                        .ihrLaymanTerm(laymanTerm)
                        .ihrTerm(ihrTerm)
                        .sourceVocabulary(sVocabulary)
                        .sourceVocabularyCode(svCode)
                        .build())
                .dosageForm(IhrTerm.builder()
                        .ihrLaymanTerm(laymanTerm)
                        .ihrTerm(ihrTerm)
                        .sourceVocabulary(sVocabulary)
                        .sourceVocabularyCode(svCode)
                        .build()).build()

        immunizations.setDosageQuantity(dosageQuantity)
        immunizations.setDosageFrequency(dosageFrequency)

        Immunization imm = getFhirResourceImmunization(immunizations)
        def res_dosageUnit = imm.getExtensionByUrl(Constants.DOSAGE_UNIT_URL)
        def res_dosageForm = imm.getExtensionByUrl(Constants.DOSAGE_FORM_URL)

        def res_dosageUnit_codeableConcept = res_dosageUnit.value as CodeableConcept
        def res_dosageForm_codeableConcept = res_dosageForm.value as CodeableConcept

        def res_dosageUnit_coding = res_dosageUnit_codeableConcept.getCodingFirstRep()
        def res_dosageForm_coding = res_dosageForm_codeableConcept.getCodingFirstRep()

        def res_dosageQuantity = imm.getDoseQuantity()
        def res_dosageFrequency = getValueOfExtension(imm.getExtension(), Constants.DOSAGE_FREQUENCY_URL)
        then:

        //verify dosageUnit
        res_dosageUnit_codeableConcept.getText() == laymanTerm
        res_dosageUnit_coding.getDisplay() == ihrTerm
        res_dosageUnit_coding.getSystem() == sVocabulary
        res_dosageUnit_coding.getCode() == svCode

        //verify dosageForm
        res_dosageForm_codeableConcept.getText() == laymanTerm
        res_dosageForm_coding.getDisplay() == ihrTerm
        res_dosageForm_coding.getSystem() == sVocabulary
        res_dosageForm_coding.getCode() == svCode

        //verify dosageQuantity
        res_dosageQuantity.value == dosageQuantity
        res_dosageQuantity.getUnit() == ihrTerm

        //verify dosageFrequency
        res_dosageFrequency == dosageFrequency

        where:
        desc           | laymanTerm | sVocabulary    | svCode   | ihrTerm  | dosageQuantity | dosageFrequency
        "Happy Path"   | "Ontology" | "IHR Ontology" | "mcg/mL" | "mcg/mL" | 10             | "nightly at bedtime"
        "All are null" | null       | null           | null     | null     | 0              | null

    }

    @Unroll
//    @SuppressWarnings
    def "Test doseNumber and lotNumber"() {
        when:
        // map to fhir resource
        Immunizations immunizations = Immunizations.builder()
                .medication(IhrTerm.builder()
                        .lotNumber(lotNumber)
                        .doseNumber(doseNumber as BigInteger)
                        .build()).build()

        Immunization imm = getFhirResourceImmunization(immunizations)
        def res_doseNumber = (imm.protocolApplied.get(0).getDoseNumber() as IntegerType).value
        imm.getProtocolAppliedFirstRep().getDoseNumber()

        def res_lotNumber = imm.lotNumber
        then:
        res_doseNumber == doseNumber
        res_lotNumber == lotNumber
        where:
        doseNumber | lotNumber
        12         | "2"
    }

    static getFhirResourceImmunization(Immunizations immunizations) {
        //build v2 resource
        FhirResource fhirResource = FhirResource.builder()
                .bundle(new Bundle().setType(Bundle.BundleType.SEARCHSET))
                .patient(TestData.defaultPatient()).build()
        mapper.map(fhirResource, immunizations)
        Bundle bundle = fhirResource.getBundle()

        Immunization imm = getFirstBundleResource(bundle, ResourceType.Immunization)
    }
}