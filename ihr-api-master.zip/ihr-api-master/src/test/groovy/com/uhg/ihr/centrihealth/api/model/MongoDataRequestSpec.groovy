package com.uhg.ihr.centrihealth.api.model

import com.uhg.ihr.centrihealth.api.filter.DataFilter
import spock.lang.Specification

class MongoDataRequestSpec extends Specification {
    MongoDataRequest sampleMongoDataRequest = new MongoDataRequest(ihrId:"TST123", dataClasses: new HashSet<RecordType>(),
    dataFilters: new ArrayList<DataFilter>(), language: "EN")


    def "getters/setter"() {
        when:
        MongoDataRequest mongoDataRequest = sampleMongoDataRequest

        then:
        mongoDataRequest.getIhrId() == "TST123"
        mongoDataRequest.getDataClasses().size() == 0
        mongoDataRequest.getDataFilters().size() == 0
        mongoDataRequest.getLanguage() == "EN"
    }

    def "Test builder"(){
        when:
        def result = MongoDataRequest.builder().ihrId("TST123").dataClasses(new HashSet<RecordType>())
                .dataFilters(new ArrayList<DataFilter>()).build()

        then:
        result.ihrId == "TST123"
    }

    def "Test toString"() {
        given:
        MongoDataRequest mongoDataRequest = sampleMongoDataRequest

        when:
        def result = mongoDataRequest.toString()

        then:
        result.contains("MongoDataRequest(ihrId=TST123, dataClasses=[], dataFilters=[], language=EN)")
    }

}
