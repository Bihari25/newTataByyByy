package com.uhg.ihr.centrihealth.api.service.fhir

import com.fasterxml.jackson.databind.JsonNode
import com.fasterxml.jackson.databind.node.ArrayNode
import com.uhg.ihr.centrihealth.api.model.Payload
import com.uhg.ihr.centrihealth.api.model.dataclass.Constants
import com.uhg.ihr.centrihealth.api.service.FhirService
import com.uhg.ihr.centrihealth.util.TestData
import org.hl7.fhir.instance.model.api.IBaseResource
import org.hl7.fhir.r4.model.Bundle
import org.hl7.fhir.r4.model.Coding
import org.hl7.fhir.r4.model.Device
import org.hl7.fhir.r4.model.Extension
import org.hl7.fhir.r4.model.Identifier
import org.hl7.fhir.r4.model.ResourceType

class HealthDeviceFhirMapperSpec extends BaseFhirSpecification {

    def recordKey = "o*}Dci^Vj2DS9mggDvEzepfVVqzx{ZEsiUvmmn<+gbH%HEjP.xoJ0P2h8Y(h"

    def "Healthdevice mapper happy path testcase 1 "() {

        given:
        Payload samplePayload = TestData.buildSamplePayload("device.json")
        JsonNode dataNode = samplePayload.payloadJson['dataClasses'] as JsonNode
        Bundle bundle = FhirService.fhirConvert(getApiResponse(dataNode))
        Device device = getFirstBundleResource(bundle, ResourceType.Device)

        Identifier identifier = getIdentifierFromList(device.getIdentifier(), Constants.RECORD_KEY)
        Identifier instanceId = getIdentifierFromList(device.getIdentifier(), Constants.INSTANCE_ID)
        Identifier careTeamInstanceId = getIdentifierFromList(device.getIdentifier(), Constants.RELATED_CARE_TEAM_INSTANCE_IDS)
        ArrayNode careTeamIds = MAPPER.readTree(careTeamInstanceId.getValue()) as ArrayNode
        Identifier referenceIds = getIdentifierFromList(device.getIdentifier(), Constants.REFERENCE_IDS)

        IBaseResource resource = device.getOwner().getResource()
        Identifier npiId = getIdentifier(resource.getIdentifier(), Constants.NPI_URL)

        Extension extensionCl = getExtensionFromList(device.getExtension(), Constants.CLINICALLY_RELEVANT_DATE_URL)
        Extension extensionSen = getExtensionFromList(device.getExtension(), Constants.SENSITIVITY_CLASSES_URL)
        Extension extensionDat = getExtensionFromList(device.getExtension(), Constants.DATA_SOURCE_URL)

        String lastUpdated = getLastUpdateDate(device.getMeta())
        Coding type = getCodingFromList(device.getType().getCoding(), "CPT4/HCPCS/CDT Vocabulary")

        expect:
        identifier.getValue().toString() == recordKey
        instanceId.getValue().toString() == "19120521002272"
        careTeamIds.size() == 3
        lastUpdated.substring(0, 10) == "2019-02-17"
        extensionCl.getValueAsPrimitive().getValueAsString() == "2018-02-17T11:45:41Z"
        type.getDisplay().toString() == "Breast pump, electric (AC and/or DC)"
        careTeamInstanceId.getValue().toString() == "[123456,789,34]"
        referenceIds.getValue().toString() == "[\"2019-01-02T03:04:44Z-Rally-1sE\"]"
        extensionSen.getValue().toString() == "[\"Substance Abuse\",\"Genetics\"]"
        extensionDat.getValue().toString() == "[\"System Interface Data Acquisition Method\"]"
        npiId.getValue() == "1699718775"
        npiId.getSystem() == Constants.NPI_URL
    }
}

