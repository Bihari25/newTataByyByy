package com.uhg.ihr.centrihealth.api.service.fhir

import ca.uhn.fhir.context.FhirContext
import com.fasterxml.jackson.databind.JsonNode
import com.fasterxml.jackson.databind.ObjectMapper
import com.google.common.collect.Iterables
import com.uhg.ihr.centrihealth.api.model.Big5
import com.uhg.ihr.centrihealth.api.model.FhirResource
import com.uhg.ihr.centrihealth.api.model.IhrApiResponse
import com.uhg.ihr.centrihealth.api.model.dataclass.Constants
import com.uhg.ihr.centrihealth.api.model.dataclass.Evaluation
import com.uhg.ihr.centrihealth.api.model.dataclass.IhrTerm
import com.uhg.ihr.centrihealth.api.model.dataclass.Note
import com.uhg.ihr.centrihealth.api.model.dataclass.Supplier
import com.uhg.ihr.centrihealth.api.service.IhrFhirMapper
import com.uhg.ihr.centrihealth.api.util.AppUtils
import com.uhg.ihr.centrihealth.util.TestData
import io.micronaut.core.util.CollectionUtils
import io.micronaut.http.HttpRequest
import org.hl7.fhir.instance.model.api.IBaseResource
import org.hl7.fhir.r4.model.Annotation
import org.hl7.fhir.r4.model.Bundle
import org.hl7.fhir.r4.model.CodeableConcept
import org.hl7.fhir.r4.model.Coding
import org.hl7.fhir.r4.model.DateTimeType
import org.hl7.fhir.r4.model.DateType
import org.hl7.fhir.r4.model.Extension
import org.hl7.fhir.r4.model.HumanName
import org.hl7.fhir.r4.model.Identifier
import org.hl7.fhir.r4.model.Meta
import org.hl7.fhir.r4.model.Patient
import org.hl7.fhir.r4.model.Resource
import org.hl7.fhir.r4.model.ResourceType
import org.hl7.fhir.r4.model.StringType
import org.hl7.fhir.r4.model.Type
import spock.lang.Shared
import spock.lang.Specification

import java.time.LocalDate
import java.time.ZoneId
import java.time.ZoneOffset
import java.time.format.DateTimeFormatter

class BaseFhirSpecification extends Specification {

    @Shared
    static final ObjectMapper MAPPER = new ObjectMapper()

    @Shared
    static final FhirContext FHIR_CONTEXT = FhirContext.forR4()

    @Shared
    public static final DateTimeFormatter FORMATTER = DateTimeFormatter.ofPattern("yyyy/MM/dd", Locale.US)

    @Shared
    TimeZone DEFAULT_TIMEZONE = TimeZone.getDefault()

    static String TOKEN = "Bearer eyJhbGciOiJSUzUxMiJ9.eyJyb2xlIjoidXNlciIsImNyZWF0ZWQiOjE1MjI4NDk5OTE3OTcsInVzZXJuYW1lIjoiY2xvdWRzZGsifQ.dzfwWRugsnhPHB0RNT9lZHnX7gvNfGks_ivTc_dQ6-ejM6B1-Chx3WrwBE8drdy4ZbvkVTlHkHRSu3nBZi3Aw0wmN5N7UPUI0wP2KhAHGQS4-LOXgD58ioX9ep3k6hZQqy-oJor5Q3wZS8HJKMMY8izIROtJ5z-z5Y2RRw3ONnQLL5JR40hF9d5mFKA8Y1giEP32qg259MVbdkHNkI0ceq8hrXJ7w_OD4-JPteNhM9EeyNOmzjrKSEG-tkYrWI7g5xgvgMuO8iHFym4WhkDT6FNfcK2xs8QfCbJCZqV28xSIjbrm0El0L7kRzJbsKBxQ7FNJ35iaX18DpQMpu6usUQ"
    static String CORRELATION_ID = "abcdefg1234567"
    static String CORRELATION_HEADER = "optum-cid-ext"
    static String CONSUMER_USER_NAME_HEADER = "X-Consumer-Username"
    static String CONSUMER_USER_NAME = "abc.def"

    def setupSpec() {
        TimeZone.setDefault(TimeZone.getTimeZone(ZoneId.of("UTC")))
    }

    def cleanupSpec() {
        TimeZone.setDefault(DEFAULT_TIMEZONE)
    }

    static toDate(String date) {
        return Date.from(LocalDate.parse(date, FORMATTER).atStartOfDay(ZoneOffset.UTC).toInstant())
    }

    static String bundleToString(Bundle bundle) {
        FHIR_CONTEXT.newJsonParser().encodeResourceToString(bundle)
    }

    static Identifier getIdentifierFromList(List<Identifier> ids, String name) {
        List<Identifier> found = ids.findAll { id -> name == id.getType().getText() || name == id.getValue() }
        return Iterables.getOnlyElement(found)
    }

    static Identifier getIdentifier(List<Identifier> ids, String name) {
        List<Identifier> found = ids.findAll { id -> name == id.getSystem() || name == id.getValue() }
        return Iterables.getOnlyElement(found)
    }

    static Extension getExtensionFromList(List<Extension> extensions, String url) {
        List<Extension> found = extensions.findAll { id -> url.equals(id.getUrl()) }
        return Iterables.getOnlyElement(found)
    }

    static Coding getCodingFromList(List<Coding> codings, String name) {
        List<Coding> found = codings.findAll { id -> name == id.getSystem() || name == id.getDisplay() || name == id.getCode() }
        return Iterables.getOnlyElement(found)
    }

    static Annotation getNoteFromList(List<Annotation> note, String text) {
        List<Annotation> found = note.findAll { id -> text == id.getText() || text == id.getAuthor() }
        return Iterables.getOnlyElement(found)
    }

    static Annotation getNote(List<Annotation> note, String text) {
        List<Annotation> found = note.findAll { id -> text == id.getText() }
        return Iterables.getOnlyElement(found)
    }

    static Identifier getAuthorReferenceIdentifier(IBaseResource resource, String identifierType) {
        return getIdentifierFromList(resource.getIdentifier(), identifierType)
    }

    static baseRequest() {
        return HttpRequest.POST("/individual-health-records/v1.0/read", TestData.sampleIhrApiRequest())
                .header(CORRELATION_HEADER, CORRELATION_ID)
                .header(CONSUMER_USER_NAME_HEADER, CONSUMER_USER_NAME)
                .header("JWT", TOKEN)
    }

    static big5Base() {
        return Big5.builder().firstName("santa").lastName("claus").dateOfBirth("1940/01/01")
    }

    static String getPresenceStateTermValue(List<Extension> extensions) {
        String url = Constants.PRESENCE_STATE_TERM_URL
        def val=getExtensionFromList(extensions, url).value as StringType
        return (val!=null)?val.value:val
    }

    static String getLastUpdateDate(Meta meta) {
        return meta.getLastUpdatedElement().getValueAsString()
    }

    static IhrApiResponse getApiResponse(JsonNode payload) {
        return IhrApiResponse.builder()
                .dataClasses(payload)
                .mbrId(TestData.sampleMid()).build();
    }

    static buildExtension(String url, String value) {
        return new Extension().setUrl(url).setValue(new StringType(value))
    }

    static buildIdentifier(String code, String text, String value) {
        return new Identifier().setType(buildCodeableConcept(text, null, code, null)).setValue(value)
    }

    static buildOrganizationIdentifier(String system, String value) {
        return new Identifier().setSystem(system).setValue(value)
    }

    static CodeableConcept buildCodeableConcept(String text, String display, String code, String system) {
        return new CodeableConcept()
                .setText(text)
                .addCoding(buildCoding(display, code, system))
    }

    static Coding buildCoding(String display, String code, String system) {
        return new Coding()
                .setDisplay(display)
                .setCode(code)
                .setSystem(system)
    }

    static Evaluation buildEvaluation(String dateTimeType, String stringType) {
        Evaluation evaluation = new Evaluation()
        evaluation.setDate(dateTimeType)
        evaluation.setTargetResult(stringType)
        return evaluation
    }

    static Supplier buildSupplier(String supplierName, String npiNum) {
        Supplier supplier = new Supplier()
        supplier.setName(supplierName)
        supplier.setNpinum(npiNum)
        return supplier
    }

    static buildIhrTerm(String ihrTerm, String laymanTerm, String sVocabulary, String svCode) {
        IhrTerm ihrTermObj = new IhrTerm()
        ihrTermObj.setIhrTerm(ihrTerm)
        ihrTermObj.setIhrLaymanTerm(laymanTerm)
        ihrTermObj.setSourceVocabulary(sVocabulary)
        ihrTermObj.setSourceVocabularyCode(svCode)
        return ihrTermObj
    }

    static buildHumanName(String family, String given, String middle, String text, String prefix) {
        return new HumanName()
                .setFamily(family)
                .addGiven(given)
                .addGiven(middle)
                .setText(text)
                .addPrefix(prefix);
    }

    static Note buildSampleNote(String text, String time, String author, String noteType) {
        return Note.builder()
                .text(text)
                .time(time)
                .author(author)
                .noteType(noteType)
                .build()
    }

    static getFirstBundleResource(Bundle bundle, ResourceType resourceType) {
        for (Bundle.BundleEntryComponent entity : bundle.getEntry()) {
            if (resourceType == entity.getResource().getResourceType()) {
                return entity.getResource();
            }
        }
    }

    static <R extends Resource> R getFirstBundleResource(Bundle bundle, Class<R> resourceTypeClass) {
        ResourceType resourceType = ResourceType.valueOf(resourceTypeClass.getSimpleName())
        return resourceTypeClass.cast(getFirstBundleResource(bundle, resourceType))
    }

    static <R extends Resource> List<R> getResourcesOfTypeFromBundle(Bundle bundle, Class<R> resourceTypeClass) {
        List<R> resources = new ArrayList<>()
        for (Bundle.BundleEntryComponent entity : bundle.getEntry()) {
            if (entity.getResource().getClass() == resourceTypeClass) {
                resources.add(resourceTypeClass.cast(entity.getResource()))
            }
        }
        return resources
    }

    static buildPatientResource() {
        return IhrFhirMapper.buildPatientResource(
                Big5.builder()
                        .firstName("Joe")
                        .lastName("Bob")
                        .dateOfBirth("1992/01/01")
                        .searchId("333888999")
                        .build()
        )
    }

    static buildBundleResource() {
        return new Bundle()
                .setType(Bundle.BundleType.SEARCHSET)
                .setId("BundleId99999999")
    }

    FhirResource buildMockedFhirResource(Bundle bundle, Patient patient) {
        FhirResource fhirResource = Mock()
        fhirResource.getPatient() >> patient
        fhirResource.getBundle() >> bundle
        return fhirResource
    }

    static buildFhirResource() {
        Patient patient = buildPatientResource()
        Bundle bundle = buildBundleResource()
        return buildFhirResource(bundle, patient)
    }

    static buildFhirResource(Bundle bundle, Patient patient) {
        return FhirResource.builder()
                .bundle(bundle)
                .patient(patient)
                .practitioner(new HashMap<>())
                .practitionerRole(new HashMap<>())
                .relatedPerson(new HashMap<>())
                .organization(new HashMap<>())
                .condition(new HashMap<>())
                .observation(new HashMap<>())
                .location(new HashMap<>())
                .specimen(new HashMap<>())
                .build()
    }

    static buildBasicIhrTerm() {
        return buildBasicIhrTerm("IhrTerm", "LaymanTerm", "SourceVocabulary", "SourceVocabularyCode")
    }

    static buildBasicIhrTerm(String ihrTerm, String ihrLaymanTerm, String sourceVocab, String sourceVocabCode) {
        return IhrTerm.builder()
                .ihrLaymanTerm(ihrLaymanTerm)
                .ihrTerm(ihrTerm)
                .sourceVocabulary(sourceVocab)
                .sourceVocabularyCode(sourceVocabCode)
                .build()
    }

    static omitNull(final String value) {
        return value == null ? "" : value;
    }

    static omitNull(final Type value) {
        return value == null ? "" : value.toString();
    }

    static String checkNull(value) {
        if (null != value) {
            return value.toString()
        }
        return null
    }

    static String checkIsListNull(List<?> value) {
        //Added null != value to overcome ambiguous method call
        if (null != value && CollectionUtils.isNotEmpty(value)) {
            return AppUtils.jsonEscape(value)
        }
        return null
    }

    static String getValueOfIdentifier(List<Identifier> ids, String name) {
        List<Identifier> found = ids.findAll { id -> name == id.getType().getText() || name == id.getValue() }
        if (found.size() > 0) {
            def identifier = Iterables.getOnlyElement(found)
            return identifier.getValue()
        } else return null
    }

    static String getValueOfExtension(List<Extension> extensions, String url) {
        List<Extension> found = extensions.findAll { id -> url.equals(id.getUrl()) }
        if (found.size() > 0) {
            def extension = Iterables.getOnlyElement(found)
            return extension.getValue()
        } else return null
    }

    static getDateAsStringFromExtension(Extension ext) {
        if (null != ext && null != ext.getValue()) {
            if (ext.getValue() instanceof DateTimeType) {
                DateTimeType date = ext.getValue()
                return date.getValueAsString()
            } else if (ext.getValue() instanceof DateType) {
                DateType date = ext.getValue()
                return date.getValueAsString()
            }
        }
        return null
    }

    static String toDateTimeTypeFromDate(String date) {
        Date dateValue = toDate(date);
        return new DateTimeType(dateValue == null ? "" : dateValue.toInstant().toString());
    }

    static String getDateTimeValue(Type type) {
        if (type == null)
            return null;
        return (type as DateTimeType).getValueAsString()
    }
}