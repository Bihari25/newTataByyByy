package com.uhg.ihr.centrihealth.api.filter

import com.fasterxml.jackson.databind.JsonNode
import com.fasterxml.jackson.databind.node.ObjectNode
import com.fasterxml.jackson.databind.node.TextNode
import com.uhg.ihr.centrihealth.api.exception.IhrBadRequestException
import com.uhg.ihr.centrihealth.api.model.Payload
import com.uhg.ihr.centrihealth.util.TestData
import spock.lang.Specification
import spock.lang.Unroll

@Unroll
class PresenceStateFilterSpec extends Specification {
    TestData testData = new TestData()


    def "filter with data node happy path scenarios: #desc"() {
        given:
        Payload samplePayload = testData.buildSamplePayload("datafilter-payload.json")
        JsonNode dataNode = samplePayload.payloadJson['dataClasses']['medications'][0]
        PresenceStateFilter presenceStateFilter = new PresenceStateFilter(filterValue)

        when:
        def result = presenceStateFilter.filter(dataNode)

        then:
        result == expectedResult

        where:
        desc                                                         | filterValue                || expectedResult
        "Single filter"                                              | "Present"                  || true
        "Multiple filters"                                           | "Present, Past Occurrence" || true
        "Multiple filters with valid and invalid value matching"     | "Present, Test1"           || true
        "'Past Occurrence' filter with non matching"                 | "Past Occurrence"          || false
        "'Not Present' filter with non matching"                     | "Not Present"              || false
        "'Planned Occurrence' filter with non matching"              | "Planned Occurrence"       || false
        "Multiple filters with valid and invalid value non matching" | "Past Occurrence, Test1"   || false
    }

    def "filter for empty present state edge case: #desc"() {
        given:
        Payload samplePayload = testData.buildSamplePayload("datafilter-payload.json")
        JsonNode dataNode = samplePayload.payloadJson['dataClasses']['medications'][0]
        dataNode.putAt('presenceStateTerm', pStateValue)

        when:
        PresenceStateFilter presenceStateFilter = new PresenceStateFilter("Present")
        def result = presenceStateFilter.filter(dataNode)

        then:
        result == true

        where:
        desc                        | pStateValue
        "Null present state"        | null
        "Empty space present state" | new TextNode(" ")
        "Empty present state"       | new TextNode("")
    }

    def "filter value is null or empty failure path scenarios: #desc"() {
        when:
        PresenceStateFilter presenceStateFilter = new PresenceStateFilter(filterValue)

        then:
        IhrBadRequestException ihrBadRequestEx = thrown()
        ihrBadRequestEx.message.contains("PresenceState value can't be null or empty")

        where:
        desc                        | filterValue
        "Empty filter value "       | ""
        "Empty space filter value " | " "
        "Null filter value "        | null
    }

    def "Invalid presence state filter values failure path scenarios: #desc"() {
        when:
        PresenceStateFilter presenceStateFilter = new PresenceStateFilter(filterValue)

        then:
        IhrBadRequestException ihrBadRequestEx = thrown()
        ihrBadRequestEx.message.contains("Requested presence state filter values are invalid")

        where:
        desc                             | filterValue
        "Single invalid filter value"    | "Test1"
        "Multiple invalid filter values" | "Test1, Test2, Test3"
    }


    def "filter for if there is no presence state term edge case"() {
        given:
        Payload samplePayload = testData.buildSamplePayload("datafilter-payload.json")
        JsonNode dataNode = samplePayload.payloadJson['dataClasses']['medications'][0]
        ((ObjectNode)dataNode).remove('presenceStateTerm')

        when:
        PresenceStateFilter presenceStateFilter = new PresenceStateFilter("Present")
        def result = presenceStateFilter.filter(dataNode)

        then:
        result == false
    }

}
