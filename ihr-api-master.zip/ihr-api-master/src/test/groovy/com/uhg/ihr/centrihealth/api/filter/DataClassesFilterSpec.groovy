package com.uhg.ihr.centrihealth.api.filter

import com.fasterxml.jackson.databind.JsonNode
import com.fasterxml.jackson.databind.node.JsonNodeFactory
import com.fasterxml.jackson.databind.node.ObjectNode
import com.uhg.ihr.centrihealth.api.model.FilterPair
import com.uhg.ihr.centrihealth.api.model.Payload
import com.uhg.ihr.centrihealth.api.util.AppUtils
import com.uhg.ihr.centrihealth.util.TestData
import spock.lang.Specification
import spock.lang.Unroll

import java.util.stream.Collectors

@Unroll
class DataClassesFilterSpec extends Specification {

    TestData testData = new TestData()

    def "filterDataClassesContent happy path : #scenario"() {
        given:
        Payload samplePayload = testData.buildSamplePayload("datafilter-payload.json")
        def dataClassesPayload = samplePayload.payloadJson['dataClasses']['_children'] as LinkedHashMap<String, JsonNode>
        def dataFilters = buildDataFilters(dataContentFilters)

        when:
        def result = DataClassesFilter.filterAllowedDataClassesByCriteria(dataClassesPayload, dataFilters)

        then:
        result['medications'].size() == medicationSize
        result['procedureHistory'].size() == phSize
        result['visitHistory'].size() == vhSize

        where:
        scenario                                       | dataContentFilters                                                                                              || medicationSize || phSize || vhSize
        "Empty or no filters"                          | [] as Set<FilterPair>                                                                                           || 3              || 2      || 2
        "Null filters"                                 | null                                                                                                            || 3              || 2      || 2
        "Filter for start date"                        | [new FilterPair(key: AppUtils.CLINICALLY_RELEVANT_START_DATE, value: '2018-12-25')] as Set<FilterPair>          || 2              || 1      || 1
        "Filter for start date time"                   | [new FilterPair(key: AppUtils.CLINICALLY_RELEVANT_START_DATE, value: '2018-12-25 13:10:24')] as Set<FilterPair> || 1              || 0      || 0
        "Filter for present state"                     | [new FilterPair(key: AppUtils.PRESENCE_STATE, value: "Present")] as Set<FilterPair>                             || 2              || 1      || 1
        "Filter for past occurrence"                   | [new FilterPair(key: AppUtils.PRESENCE_STATE, value: "Past Occurrence")] as Set<FilterPair>                     || 1              || 1      || 1
        "Filter for present and past occurrence"       | [new FilterPair(key: AppUtils.PRESENCE_STATE, value: "Present, Past Occurrence")] as Set<FilterPair>            || 3              || 2      || 2
        "Filter for start and end date"                | [new FilterPair(key: AppUtils.CLINICALLY_RELEVANT_START_DATE, value: '2018-12-25'),
                                                          new FilterPair(key: AppUtils.CLINICALLY_RELEVANT_END_DATE, value: '2019-12-25')] as Set<FilterPair>            || 2              || 1      || 1
        "Filter for start and present"                 | [new FilterPair(key: AppUtils.CLINICALLY_RELEVANT_START_DATE, value: '2018-12-25'),
                                                          new FilterPair(key: AppUtils.PRESENCE_STATE, value: "Present")] as Set<FilterPair>                             || 2              || 1      || 1
        "Filter for invalid start and past occurrence" | [new FilterPair(key: AppUtils.CLINICALLY_RELEVANT_START_DATE, value: '2018-12-25'),
                                                          new FilterPair(key: AppUtils.PRESENCE_STATE, value: "Past Occurrence")] as Set<FilterPair>                     || 0              || 0      || 0
        "Filter for valid start and past occurrence"   | [new FilterPair(key: AppUtils.CLINICALLY_RELEVANT_START_DATE, value: '2018-01-25'),
                                                          new FilterPair(key: AppUtils.PRESENCE_STATE, value: "Past Occurrence")] as Set<FilterPair>                     || 1              || 0      || 1
        "Filter for start/end date and presence state" | [new FilterPair(key: AppUtils.CLINICALLY_RELEVANT_START_DATE, value: '2018-12-25'),
                                                          new FilterPair(key: AppUtils.CLINICALLY_RELEVANT_END_DATE, value: '2019-12-25'),
                                                          new FilterPair(key: AppUtils.PRESENCE_STATE, value: "Present")] as Set<FilterPair>                             || 2              || 1      || 1
    }

    def "dataClassesFilteringByCriteria : #scenario"() {
        given:
        Payload samplePayload = testData.buildSamplePayload("datafilter-payload.json")
        def dataClassesPayload = samplePayload.payloadJson['dataClasses']['_children'] as LinkedHashMap<String, JsonNode>
        def dataFilters = buildDataFilters(dataContentFilters)


        when:
        def result = DataClassesFilter.filterAllowedDataClassesByCriteria(dataClassesPayload, dataFilters)

        then:
        result['medications'].size() == medicationSize
        result['procedureHistory'].size() == phSize
        result['visitHistory'].size() == vhSize

        where:
        scenario                                       | dataContentFilters                                                                                     || medicationSize || phSize || vhSize
        "Filter for start date"                        | [new FilterPair(key: AppUtils.CLINICALLY_RELEVANT_START_DATE, value: '2018-12-25')] as Set<FilterPair> || 2              || 1      || 1
        "Filter for present state"                     | [new FilterPair(key: AppUtils.PRESENCE_STATE, value: "Present")] as Set<FilterPair>                    || 2              || 1      || 1
        "Filter for past occurrence"                   | [new FilterPair(key: AppUtils.PRESENCE_STATE, value: "Past Occurrence")] as Set<FilterPair>            || 1              || 1      || 1
        "Filter for present and past occurrence"       | [new FilterPair(key: AppUtils.PRESENCE_STATE, value: "Present, Past Occurrence")] as Set<FilterPair>   || 3              || 2      || 2
        "Filter for start and end date"                | [new FilterPair(key: AppUtils.CLINICALLY_RELEVANT_START_DATE, value: '2018-12-25'),
                                                          new FilterPair(key: AppUtils.CLINICALLY_RELEVANT_END_DATE, value: '2019-12-25')] as Set<FilterPair>   || 2              || 1      || 1
        "Filter for start and present"                 | [new FilterPair(key: AppUtils.CLINICALLY_RELEVANT_START_DATE, value: '2018-12-25'),
                                                          new FilterPair(key: AppUtils.PRESENCE_STATE, value: "Present")] as Set<FilterPair>                    || 2              || 1      || 1
        "Filter for invalid start and past occurrence" | [new FilterPair(key: AppUtils.CLINICALLY_RELEVANT_START_DATE, value: '2018-12-25'),
                                                          new FilterPair(key: AppUtils.PRESENCE_STATE, value: "Past Occurrence")] as Set<FilterPair>            || 0              || 0      || 0
        "Filter for valid start and past occurrence"   | [new FilterPair(key: AppUtils.CLINICALLY_RELEVANT_START_DATE, value: '2018-01-25'),
                                                          new FilterPair(key: AppUtils.PRESENCE_STATE, value: "Past Occurrence")] as Set<FilterPair>            || 1              || 0      || 1
        "Filter for start/end date and presence state" | [new FilterPair(key: AppUtils.CLINICALLY_RELEVANT_START_DATE, value: '2018-12-25'),
                                                          new FilterPair(key: AppUtils.CLINICALLY_RELEVANT_END_DATE, value: '2019-12-25'),
                                                          new FilterPair(key: AppUtils.PRESENCE_STATE, value: "Present")] as Set<FilterPair>                    || 2              || 1      || 1

    }

    def "filteredDataByCriteria : #scenario"() {
        given:
        Payload samplePayload = testData.buildSamplePayload("datafilter-payload.json")
        JsonNode dataNode = samplePayload.payloadJson['dataClasses']['medications'] as JsonNode
        def dataFilters = buildDataFilters(dataContentFilters)


        when:
        def result = DataClassesFilter.filterDataByCriteria('medications', dataNode, dataFilters)

        then:
        result.size() == expectedSize

        where:
        scenario                                       | dataContentFilters                                                                                     || expectedSize
        "Filter for start date"                        | [new FilterPair(key: AppUtils.CLINICALLY_RELEVANT_START_DATE, value: '2018-12-25')] as Set<FilterPair> || 2
        "Filter for present state"                     | [new FilterPair(key: AppUtils.PRESENCE_STATE, value: "Present")] as Set<FilterPair>                    || 2
        "Filter for past occurrence"                   | [new FilterPair(key: AppUtils.PRESENCE_STATE, value: "Past Occurrence")] as Set<FilterPair>            || 1
        "Filter for present and past occurrence"       | [new FilterPair(key: AppUtils.PRESENCE_STATE, value: "Present, Past Occurrence")] as Set<FilterPair>   || 3
        "Filter for start and end date"                | [new FilterPair(key: AppUtils.CLINICALLY_RELEVANT_START_DATE, value: '2018-12-25'),
                                                          new FilterPair(key: AppUtils.CLINICALLY_RELEVANT_END_DATE, value: '2019-12-25')] as Set<FilterPair>   || 2
        "Filter for start and present"                 | [new FilterPair(key: AppUtils.CLINICALLY_RELEVANT_START_DATE, value: '2018-12-25'),
                                                          new FilterPair(key: AppUtils.PRESENCE_STATE, value: "Present")] as Set<FilterPair>                    || 2
        "Filter for invalid start and past occurrence" | [new FilterPair(key: AppUtils.CLINICALLY_RELEVANT_START_DATE, value: '2018-12-25'),
                                                          new FilterPair(key: AppUtils.PRESENCE_STATE, value: "Past Occurrence")] as Set<FilterPair>            || 0
        "Filter for valid start and past occurrence"   | [new FilterPair(key: AppUtils.CLINICALLY_RELEVANT_START_DATE, value: '2018-01-25'),
                                                          new FilterPair(key: AppUtils.PRESENCE_STATE, value: "Past Occurrence")] as Set<FilterPair>            || 1
        "Filter for start/end date and presence state" | [new FilterPair(key: AppUtils.CLINICALLY_RELEVANT_START_DATE, value: '2018-12-25'),
                                                          new FilterPair(key: AppUtils.CLINICALLY_RELEVANT_END_DATE, value: '2019-12-25'),
                                                          new FilterPair(key: AppUtils.PRESENCE_STATE, value: "Present")] as Set<FilterPair>                    || 2
    }

    def "filteredDataByCriteria crDate, pStateTerm empty/null edge cases : #scenario"() {
        given:
        Payload samplePayload = testData.buildSamplePayload("datafilter-payload-empty-crd-pstate.json")
        JsonNode dataNode = samplePayload.payloadJson['dataClasses']['medications'] as JsonNode
        def dataFilters = buildDataFilters(dataContentFilters)


        when:
        def result = DataClassesFilter.filterDataByCriteria('medications', dataNode, dataFilters)

        then:
        result.size() == expectedSize

        where:
        scenario                                       | dataContentFilters                                                                                     || expectedSize
        "Filter for start date"                        | [new FilterPair(key: AppUtils.CLINICALLY_RELEVANT_START_DATE, value: '2018-12-25')] as Set<FilterPair> || 3
        "Filter for present state"                     | [new FilterPair(key: AppUtils.PRESENCE_STATE, value: "Present")] as Set<FilterPair>                    || 3
        "Filter for past occurrence"                   | [new FilterPair(key: AppUtils.PRESENCE_STATE, value: "Past Occurrence")] as Set<FilterPair>            || 2
        "Filter for present and past occurrence"       | [new FilterPair(key: AppUtils.PRESENCE_STATE, value: "Present, Past Occurrence")] as Set<FilterPair>   || 3
        "Filter for start and end date"                | [new FilterPair(key: AppUtils.CLINICALLY_RELEVANT_START_DATE, value: '2018-12-25'),
                                                          new FilterPair(key: AppUtils.CLINICALLY_RELEVANT_END_DATE, value: '2019-12-25')] as Set<FilterPair>   || 3
        "Filter for start and present"                 | [new FilterPair(key: AppUtils.CLINICALLY_RELEVANT_START_DATE, value: '2018-12-25'),
                                                          new FilterPair(key: AppUtils.PRESENCE_STATE, value: "Present")] as Set<FilterPair>                    || 3
        "Filter for invalid start and past occurrence" | [new FilterPair(key: AppUtils.CLINICALLY_RELEVANT_START_DATE, value: '2018-12-25'),
                                                          new FilterPair(key: AppUtils.PRESENCE_STATE, value: "Past Occurrence")] as Set<FilterPair>            || 2
        "Filter for valid start and past occurrence"   | [new FilterPair(key: AppUtils.CLINICALLY_RELEVANT_START_DATE, value: '2018-01-25'),
                                                          new FilterPair(key: AppUtils.PRESENCE_STATE, value: "Past Occurrence")] as Set<FilterPair>            || 2
        "Filter for start/end date and presence state" | [new FilterPair(key: AppUtils.CLINICALLY_RELEVANT_START_DATE, value: '2018-12-25'),
                                                          new FilterPair(key: AppUtils.CLINICALLY_RELEVANT_END_DATE, value: '2019-12-25'),
                                                          new FilterPair(key: AppUtils.PRESENCE_STATE, value: "Present")] as Set<FilterPair>                    || 3
    }

    def "it gets the union of filterable data classes #scenario"() {
        given:
        def filters = buildDataFilters(dataContentFilters as Set<FilterPair>)

        when:
        def filterClasses = DataClassesFilter.getClassesToFilter(filters)

        then:
        filterClasses.size() == expectedSize

        where:
        scenario                 | dataContentFilters                                                       || expectedSize
        "no filters"             | Collections.emptySet()                                                   || 0
        "null filters"           | null                                                                     || 0
        "1 filter"               | [new FilterPair(key: AppUtils.PRESENCE_STATE, value: "Past Occurrence")] || 6
        "2 filters with overlap" | [new FilterPair(key: AppUtils.CLINICALLY_RELEVANT_START_DATE, value: '2018-01-25'),
                                    new FilterPair(key: AppUtils.PRESENCE_STATE, value: "Past Occurrence")] || 6
        "3 filters with overlap" | [new FilterPair(key: AppUtils.CLINICALLY_RELEVANT_START_DATE, value: '2018-01-25'),
                                    new FilterPair(key: AppUtils.PRESENCE_STATE, value: "Past Occurrence"),
                                    new FilterPair(key: AppUtils.PRESENCE_STATE, value: "Present")]         || 6
    }

    def "it only builds filters for specific classes"() {
        when:
        def presenceStateFilter = new PresenceStateFilter("Present")
        def clinicallyRelevantDateFilter = new ClinicallyRelevantDateFilter("2018-01-25", "2018-01-26")

        then:
        presenceStateFilter.getFilterableDataClasses().size() == 6
        clinicallyRelevantDateFilter.getFilterableDataClasses().size() == 6
        DataFilter.DATA_CLASS_FILTERS == presenceStateFilter.getFilterableDataClasses()
        DataFilter.DATA_CLASS_FILTERS == clinicallyRelevantDateFilter.getFilterableDataClasses()
    }

    def "it leaves unfiltered classes untouched #scenario"() {
        when:
        Payload samplePayload = testData.buildSamplePayload("datafilter-payload.json")
        JsonNode classes = samplePayload.getPayloadJson().get("dataClasses").get(dataClass)

        //build aggressive filter
        def dataFilters = buildDataFilters([new FilterPair(key: AppUtils.PRESENCE_STATE, value: "Not Present"),
                                            new FilterPair(key: AppUtils.CLINICALLY_RELEVANT_START_DATE, value: '2001-01-25'),
                                            new FilterPair(key: AppUtils.CLINICALLY_RELEVANT_END_DATE, value: '2001-01-26')] as Set<FilterPair>)

        def filteredClass = DataClassesFilter.filterDataByCriteria(dataClass, classes, dataFilters)

        then:
        //prove that the classes have 0 'Not Present' - everything would be filtered
        presSize == getNodesWithPresenceState(classes, "Present").size()
        notPresSize == getNodesWithPresenceState(classes, "Not Present").size()

        //show after filtering conditions is untouched and medications is wiped out
        filteredSize == filteredClass.size()

        where:
        scenario               | dataClass     || notPresSize | presSize | filteredSize
        "conditions untouched" | "conditions"  || 0           | 7        | 7
        "medications blanked"  | "medications" || 0           | 2        | 0
    }

    def "filter building gracefully handles null and empty"() {
        when:
        def nullFilters = DataClassesFilter.getClassesToFilter(null)
        def emptyFilters = DataClassesFilter.getClassesToFilter(Collections.emptyList())

        then:
        nullFilters.size() == 0
        emptyFilters.size() == 0
    }

    def "it passesFilter #scenario"() {
        when:
        ObjectNode nodes = null
        if (nodeValue != null) {
            nodes = new ObjectNode(JsonNodeFactory.instance)
            nodes.put("presenceStateTerm", nodeValue)
        }

        then:
        passes == DataClassesFilter.passesFilter(dataClass, new PresenceStateFilter("Present"), nodes)

        where:
        scenario           | dataClass     | nodeValue     | passes
        "not filterable"   | "conditions"  | null          | true
        "filterable, pass" | "medications" | "Present"     | true
        "filterable, fail" | "medications" | "Not Present" | false
    }

    // Build data content filters.
    static List<DataFilter> buildDataFilters(Set<FilterPair> dataContentFilters) {
        DataContentFilterBuilder dataContentFilterBuilder = new DataContentFilterBuilder(dataContentFilters)
        return dataContentFilterBuilder.getDataFilters()
    }

    static List<JsonNode> getNodesWithPresenceState(JsonNode nodes, String presenceState) {
        return nodes.collect().stream()
                .filter({ node -> presenceState == node.get("presenceStateTerm").asText("") })
                .collect(Collectors.toList())
    }
}
