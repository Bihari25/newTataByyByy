package com.uhg.ihr.centrihealth.api.service.fhir.v2

import com.uhg.ihr.centrihealth.api.constant.GlobalConstants
import com.uhg.ihr.centrihealth.api.constant.GlobalUrlConstant
import com.uhg.ihr.centrihealth.api.model.FhirResource
import com.uhg.ihr.centrihealth.api.model.dataclass.IhrTerm
import com.uhg.ihr.centrihealth.api.model.dataclass.Immunizations
import com.uhg.ihr.centrihealth.api.model.dataclass.Note
import com.uhg.ihr.centrihealth.api.service.fhir.BaseFhirSpecification
import com.uhg.ihr.centrihealth.util.TestData
import org.hl7.fhir.r4.model.*
import spock.lang.Shared
import spock.lang.Unroll

class ImmunizationsFhir2MapperSpec extends BaseFhirSpecification {
    @Shared
    static ImmunizationFhir2Mapper mapper = ImmunizationFhir2Mapper.of()

    @Unroll
    def "Immunization all identifiers fhir conversion"() {

        when:
        // map to fhir resource
        Immunizations immunizations = Immunizations.builder()
                .recordKey(recordKey)
                .objectId(objectId)
                .referenceIds(referenceIDs as List<String>)
                .relatedConditions(conditionInstanceID as List<BigInteger>)
                .relatedCareTeam(relatedCareTeamIds as List<BigInteger>)
                .relatedObservations(observationInstanceID as List<BigInteger>)
                .sourceClaimIds(sourceClaimIDs as List<String>)
                .medication(IhrTerm.builder()
                        .referenceIds(sourceClaimIDs as List<String>)
                        .recordKey(recordKey)
                        .build())
                .build()

        Immunization imm = getFhirResourceImmunization(immunizations)

        def res_objectId = getValueOfIdentifier(imm.getIdentifier(), GlobalConstants.OBJECT_ID)
        def res_recordKey = getValueOfIdentifier(imm.getIdentifier(), GlobalConstants.RECORD_KEY)
        def vac_res_recordKey = getValueOfIdentifier(imm.getIdentifier(), GlobalConstants.VACCINE_RECORD_KEY)
        def res_conditionInstanceId = getValueOfIdentifier(imm.getIdentifier(), GlobalConstants.RELATED_CONDITION_INSTANCE_IDS)
        def res_careTeamInstanceId = getValueOfIdentifier(imm.getIdentifier(), GlobalConstants.RELATED_CARE_TEAM_INSTANCE_IDS)
        def res_observationInstanceId = getValueOfIdentifier(imm.getIdentifier(), GlobalConstants.RELATED_OBSERVATION_INSTANCE_IDS)

        def res_sourceClaimIds = getValueOfIdentifier(imm.getIdentifier(), GlobalConstants.SOURCE_CLAIM_IDS)
        def res_referenceId = getValueOfIdentifier(imm.getIdentifier(), GlobalConstants.REFERENCE_IDS)


        then:

        res_objectId == checkNull(objectId)
        res_referenceId == checkIsListNull(referenceIDs)
        res_recordKey == checkNull(recordKey)
        vac_res_recordKey == checkNull(recordKey)
        res_careTeamInstanceId == checkIsListNull(relatedCareTeamIds)
        res_observationInstanceId == checkIsListNull(observationInstanceID)
        res_sourceClaimIds == checkIsListNull(sourceClaimIDs)
        res_conditionInstanceId == checkIsListNull(conditionInstanceID)


        where:
        test_name            | objectId | recordKey                                                      | referenceIDs                       | concept       | conditionInstanceID | observationInstanceID | sourceClaimIDs      | relatedCareTeamIds
        "happy  Path check " | 9        | "o*}Dci^Vj2DS9mggDvEzepfVVqzx{ZEsiUvmmn<+gbH%HEjP.xoJ0P2h8Y(h" | ["2009-01-02T03:04:44Z-Rally-1sE"] | [123456, 789] | [66464, 83737]      | [123456, 789]         | ["ABCDE", "TESTID"] | [2110756776942227460, 2110756776942227460, 2110756776942227460]
        "null check "        | null     | null                                                           | null                               | null          | null                | null                  | null                | null
    }

    @Unroll
    def "Test  immunization Concept #desc"() {
        when:
        // map to fhir resource
        Immunizations immunizations = Immunizations.builder()
                .concept(IhrTerm.builder()
                        .ihrLaymanTerm(laymanTerm)
                        .ihrTerm(ihrTerm)
                        .sourceVocabulary(sVocabulary)
                        .sourceVocabularyCode(svCode)
                        .icd10cmCode(icd10cmCode)
                        .build()).build()

        Immunization imm = getFhirResourceImmunization(immunizations)

        def res_CodeableConcept = imm.getReasonCode().get(0) as CodeableConcept
        def res_Coding = res_CodeableConcept.getCodingFirstRep()

        then:

        res_CodeableConcept.getText() == checkNull(laymanTerm)
        res_Coding.getDisplay() == checkNull(ihrTerm)
        res_Coding.getSystem() == checkNull(sVocabulary)
        res_Coding.getCode() == checkNull(svCode)


        where:

        desc           | laymanTerm | sVocabulary              | svCode    | ihrTerm    | icd10cmCode
        "Happy Path"   | "oralText" | "http://snomed.info/sct" | "7898989" | "oralCode" | "J66"
        "All are null" | null       | null                     | null      | null       | null

    }

    @Unroll
    def "Test  enum and all dateTime attributes"() {
        when:
        // map to fhir resource
        Immunizations immunizations = Immunizations.builder()
                .presenceStateTerm(presenceStateTerm)
                .healthEventDate(healthEventDate)
                .clinicallyRelevantDate(clinicallyRelevantDate)
                .lastUpdateDate(lastUpdateDate)
                .build()
        Immunization imm = getFhirResourceImmunization(immunizations)

        def res_presenceStateTerm = getValueOfExtension(imm.getExtension(), GlobalUrlConstant.PRESENCESTATE_URL)
        def res_healthEventDate = getDateTimeValue(imm.getOccurrence())
        def res_clinicallyRelevantDate = getDateAsStringFromExtension(imm.getExtensionByUrl(GlobalUrlConstant.CLINICAL_RELEVANT_DATE_URL))
        def res_lastUpdateDate = getLastUpdateDate(imm.getMeta())
        then:
        res_presenceStateTerm == checkNull(presenceStateTerm)
        res_healthEventDate == checkNull(healthEventDate)
        res_clinicallyRelevantDate == checkNull(clinicallyRelevantDate)
        res_lastUpdateDate == checkNull(lastUpdateDate)
        where:
        desc         | presenceStateTerm | healthEventDate        | clinicallyRelevantDate | lastUpdateDate
        "Happy path" | "Past Occurrence" | "2021-03-02T03:04:44Z" | "2021-01-02T03:04:44Z" | "2021-02-27T03:04:44Z"
        "All Null"   | null              | null                   | null                   | null
    }

    @Unroll
    def "Test  medication #desc"() {
        when:
        // map to fhir resource
        Immunizations immunizations = Immunizations.builder()
                .medication(IhrTerm.builder()
                        .ihrLaymanTerm(laymanTerm)
                        .ihrTerm(ihrTerm)
                        .sourceVocabulary(sVocabulary)
                        .sourceVocabularyCode(svCode)
                        .build()).build()

        Immunization imm = getFhirResourceImmunization(immunizations)
        def res_CodeableConcept = imm.getVaccineCode()
        def res_Coding = res_CodeableConcept.getCodingFirstRep()

        then:
        res_CodeableConcept.getText() == ihrTerm
        res_Coding.getDisplay() == laymanTerm
        res_Coding.getSystem() == sVocabulary
        res_Coding.getCode() == svCode

        where:
        desc           | laymanTerm             | sVocabulary       | svCode        | ihrTerm
        "Happy Path"   | "Adacel Intramuscular" | "NDC Foreign Key" | "49281040010" | "Adacel Intramuscular Suspension 5-2-15.5 LF-mcg/0.5 mL"
        "All are null" | null                   | null              | null          | null
    }


    @Unroll
    @SuppressWarnings
    def "Test doseNumber and lotNumber"() {
        when:
        // map to fhir resource
        Immunizations immunizations = Immunizations.builder()
                .medication(IhrTerm.builder()
                        .lotNumber(lotNumber)
                        .doseNumber(doseNumber)
                        .build()).build()

        Immunization imm = getFhirResourceImmunization(immunizations)
        def res_doseNumber = (imm.protocolApplied.get(0).getDoseNumber() as IntegerType).value
        imm.getProtocolAppliedFirstRep().getDoseNumber()

        def res_lotNumber = imm.lotNumber
        then:
        res_doseNumber == doseNumber
        res_lotNumber == lotNumber
        where:
        doseNumber | lotNumber
        12         | "2"
    }


    @Unroll
    def "Test ImmunizationFhir2 note"() {
        when:
        Note note = buildSampleNote(text, time, author, noteType)

        Immunizations immunizations = Immunizations.builder()
                .note(Arrays.asList(note))
                .build();
        Immunization imm = getFhirResourceImmunization(immunizations)
        def res_note = imm.getNote().get(0)
        Extension noteTypeValue = getExtensionFromList(res_note.getExtension(), GlobalUrlConstant.IHR_NOTE_TYPE_URL)
        def authorReference = res_note.getAuthorReference().getResource()
        def authorReferenceIdentifier = getAuthorReferenceIdentifier(authorReference, GlobalConstants.EMPLOYEE_ID)

        then:

        noteTypeValue.getValue().toString() == noteType
        res_note.getText() == text
        res_note.getTimeElement().getValueAsString() == time
        res_note.getAuthorReference().getResource().fhirType() == resourceType.toString()
        authorReferenceIdentifier.getValue() == author

        where:

        noteType          | text                         | time                   | author         || resourceType
        "Clinical Note"   | "Patient reports."           | "2019-03-28T00:00:00Z" | "ACT000123456" || ResourceType.Practitioner
        "PatientNote"     | "This medication is working" | "2018-03-28T00:00:00Z" | "ACT000000111" || ResourceType.Patient
        "Clinical Note"   | "Patient reports medication" | "2020-07-28T11:11:11Z" | "ACT098763"    || ResourceType.Practitioner
        "PatientTypeNote" | "This medication"            | "2012-03-28T00:00:00Z" | "ACT0003456"   || ResourceType.Patient
        ""                | "This medication"            | "2018-03-28T00:00:00Z" | "ACT0003456"   || ResourceType.Patient
        null              | "This medication report "    | "2014-03-28T00:00:00Z" | "ACT0003456"   || ResourceType.Patient
    }


    static getFhirResourceImmunization(Immunizations imm) {
        //build v2 resource
        FhirResource fhirResource = FhirResource.builder()
                .bundle(new Bundle().setType(Bundle.BundleType.SEARCHSET))
                .patient(TestData.defaultPatient())
                .practitioner(TestData.practitionerMap())
                .practitionerRole(TestData.practitionerRoleMap())
                .relatedPerson(TestData.relatedPersonMap()).build()
        mapper.map(fhirResource, imm)
        Bundle bundle = fhirResource.getBundle()

        Immunization immunization = getFirstBundleResource(bundle, ResourceType.Immunization)
        return immunization;
    }


}