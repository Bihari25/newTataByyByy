package com.uhg.ihr.centrihealth.api.service.fhir


import com.uhg.ihr.centrihealth.api.model.FhirResource
import com.uhg.ihr.centrihealth.api.model.dataclass.Constants
import com.uhg.ihr.centrihealth.api.model.dataclass.HealthCondition
import com.uhg.ihr.centrihealth.api.model.dataclass.IhrTerm
import com.uhg.ihr.centrihealth.util.TestData
import org.hl7.fhir.instance.model.api.IBaseResource
import org.hl7.fhir.r4.model.*
import spock.lang.Shared
import spock.lang.Unroll

@Unroll
class ConditionFhirMapperSpec extends BaseFhirSpecification {

    @Shared
    ConditionFhirMapper mapper = ConditionFhirMapper.of()

    def "condition all identifier test cases #desc"() {

        when:

        FhirResource fhirResource = FhirResource.builder()
                .bundle(new Bundle().setType(Bundle.BundleType.SEARCHSET))
                .patient(TestData.defaultPatient()).build()
        // map to fhir resource
        HealthCondition healthCondition = HealthCondition.builder()
                .recordKey(recordKey)
                .objectId(objectId as BigInteger)
                .referenceIds(referenceIDs as List<String>)
                .relatedCareTeam(relateadCareTeamIds as List<BigInteger>)
                .relatedConditions(conditionInstanceID as List<BigInteger>)
                .relatedObservations(observationInstanceID as List<Integer>)
                .sourceClaimIds(sourceClaimIDs as List<String>)
                .build()

        mapper.map(fhirResource, healthCondition)
        Bundle bundle = fhirResource.getBundle()

        Condition cd = getFirstBundleResource(bundle, ResourceType.Condition)

        def res_objectId = getValueOfIdentifier(cd.getIdentifier(), Constants.INSTANCE_ID)
        def res_recordKey = getValueOfIdentifier(cd.getIdentifier(), Constants.RECORD_KEY)

        def res_careTeamInstanceId = getValueOfIdentifier(cd.getIdentifier(), Constants.RELATED_CARE_TEAM_INSTANCE_IDS)
        def res_conditionInstanceId = getValueOfIdentifier(cd.getIdentifier(), Constants.RELATED_CONDITION_INSTANCE_IDS)
        def res_observationInstanceId = getValueOfIdentifier(cd.getIdentifier(), Constants.RELATED_OBSERVATION_INSTANCE_IDS)

        def res_sourceClaimIds = getValueOfIdentifier(cd.getIdentifier(), Constants.SOURCE_CLAIM_IDS)
        def res_referenceId = getValueOfIdentifier(cd.getIdentifier(), Constants.REFERENCE_IDS)


        then:

        res_objectId == checkNull(objectId)

        res_referenceId == checkIsListNull(referenceIDs)
        res_recordKey == checkNull(recordKey)

        res_careTeamInstanceId == checkIsListNull(relateadCareTeamIds)
        res_conditionInstanceId == checkIsListNull(conditionInstanceID)
        res_observationInstanceId == checkIsListNull(observationInstanceID)
        res_sourceClaimIds == checkIsListNull(sourceClaimIDs)


        where:
        desc            | objectId | recordKey                                                      | referenceIDs                       | relateadCareTeamIds | conditionInstanceID | observationInstanceID | sourceClaimIDs
        "happy  Path check " | 9        | "o*}Dci^Vj2DS9mggDvEzepfVVqzx{ZEsiUvmmn<+gbH%HEjP.xoJ0P2h8Y(h" | ["2009-01-02T03:04:44Z-Rally-1sE"] | [123456, 789]       | [66464, 83737]      | [123456, 789]         | ["ABCDE", "TESTID"]
        "null check "        | null     | null                                                           | null                               | null                | null                | null                  | null
    }

    def "Test  Extension of List<String> #desc"() {
        when:
        //build v2 resource
        FhirResource fhirResource = FhirResource.builder()
                .bundle(new Bundle().setType(Bundle.BundleType.SEARCHSET))
                .patient(TestData.defaultPatient()).build()
        // map to fhir resource

        HealthCondition healthCondition = HealthCondition.builder()

                .healthCondition(IhrTerm.builder()
                        .clinicalCourse(clinicalCourse)
                        .build())
                .status(IhrTerm.builder()
                        .sourceVocabularyCode(statusVal)
                        .sourceVocabulary(statusVal)
                        .ihrLaymanTerm(statusVal)
                        .ihrTerm(statusVal)
                        .build())
                .presenceStateTerm(presenceStateTerm)
                .clinicallyRelevantDate(clinicRelevantDate)
                .conditionStartDate(condiStartDate)
                .sensitivityClasses(sensitivityClasses)
                .dataSource(dataSources)
                .build()

        mapper.map(fhirResource, healthCondition)
        Bundle bundle = fhirResource.getBundle()

        Condition condition = getFirstBundleResource(bundle, ResourceType.Condition)

        def statusCode = null
        def res_clinicalCourse = getValueOfExtension(condition.getExtension(), Constants.IHR_CONDITION_CLINICAL_COURSE_URL)

        Extension status = getExtensionFromList(condition.getExtension(), Constants.STATUS_URL)
        if (status != null) {
            CodeableConcept statusConcept = status.castToCodeableConcept(status.getValue())
            statusCode = getCodingFromList(statusConcept.getCoding(), statusVal)
        }
        def res_presenceStateTerm = getValueOfExtension(condition.getExtension(), Constants.PRESENCE_STATE_TERM_URL)
        def res_clinicRelevantDate = getDateAsStringFromExtension(condition.getExtensionByUrl(Constants.CLINICALLY_RELEVANT_DATE_URL))
        def res_condiStartDate = getDateAsStringFromExtension(condition.getExtensionByUrl(Constants.START_DATE_URL))
        def res_sensitivityClasses = getValueOfExtension(condition.getExtension(), Constants.SENSITIVITY_CLASSES_URL)
        def res_dataSources = getValueOfExtension(condition.getExtension(), Constants.DATA_SOURCE_URL)

        then:

        res_clinicalCourse == checkNull(clinicalCourse)
        statusCode.getDisplay() == checkNull(statusVal)
        res_presenceStateTerm == checkNull(presenceStateTerm)
        res_clinicRelevantDate == checkNull(clinicRelevantDate)
        res_condiStartDate == checkNull(condiOutStartDate)
        res_sensitivityClasses == checkIsListNull(sensitivityClasses)
        res_dataSources == checkIsListNull(dataSources)

        where:

        desc         | clinicalCourse | statusVal | presenceStateTerm   | clinicRelevantDate     | condiStartDate || condiOutStartDate      | sensitivityClasses              | dataSources
        "Happy path" | "Chronic"      | "Active"  | "presenceStateTerm" | "2021-01-02T03:04:44Z" | "2008/07/15"   || "2008-07-15T00:00:00Z" | ["Mental Behaviorial Disorder"] | ["Data Sources"]
        "null check" | null           | null      | null                | null                   | null           || null                   | null                            | null
    }


    def "Test  CodeableConcept #desc"() {
        when:
        //build v2 resource
        FhirResource fhirResource = FhirResource.builder()
                .bundle(new Bundle().setType(Bundle.BundleType.SEARCHSET))
                .patient(TestData.defaultPatient()).build()
        // map to fhir resource
        HealthCondition healthCondition = HealthCondition.builder()

                .healthCondition(IhrTerm.builder()
                        .ihrLaymanTerm(laymanTerm)
                        .ihrTerm(ihrTerm)
                        .sourceVocabulary(sVocabulary)
                        .sourceVocabularyCode(svCode)
                        .icd10cmCode(icd10cmCode)
                        .build()).build()

        mapper.map(fhirResource, healthCondition)
        Bundle bundle = fhirResource.getBundle()

        Condition condition = getFirstBundleResource(bundle, ResourceType.Condition)

        def res_healthConCode = condition.getCode()
        def res_healthCondition = res_healthConCode.getCodingFirstRep()

        then:

        res_healthConCode.getText() == checkNull(laymanTerm)
        res_healthCondition.getDisplay() == checkNull(ihrTerm)
        res_healthCondition.getSystem() == checkNull(sVocabulary)
        res_healthCondition.getCode() == checkNull(svCode)


        where:

        desc           | laymanTerm | sVocabulary              | svCode    | ihrTerm    | icd10cmCode
        "Happy Path"   | "oralText" | "http://snomed.info/sct" | "7898989" | "oralCode" | "J66"
        "All are null" | null       | null                     | null      | null       | null

    }

    def "test all dateTime in condition #desc"() {
        when:
        // build v2 resource
        FhirResource fhirResource = FhirResource.builder()
                .bundle(new Bundle().setType(Bundle.BundleType.SEARCHSET))
                .patient(TestData.defaultPatient()).build()
        // map to fhir resource
        HealthCondition healthCondition = HealthCondition.builder()
                .onsetPeriodStart(startValue)
                .onsetPeriodEnd(endValue)
                .recordedDate(startValue)
                .lastUpdateDate(startValue)
                .build()

        mapper.map(fhirResource, healthCondition)
        Bundle bundle = fhirResource.getBundle()

        Condition condition = getFirstBundleResource(bundle, ResourceType.Condition)

        def recodedDate = condition.getRecordedDateElement()
        Period period = condition.getOnsetPeriod()
        DateTimeType onsetPeriodStart = period.getStartElement()
        DateTimeType onsetPeriodEnd = period.getEndElement()
        def lastUpdateDate = condition.getMeta().getLastUpdatedElement()


        then:
        onsetPeriodStart.getValueAsString() == checkNull(startValue)
        onsetPeriodEnd.getValueAsString() == checkNull(endValue)
        recodedDate.getValueAsString() == checkNull(startValue)
        lastUpdateDate.getValueAsString() == checkNull(startValue)

        where:
        desc               || startValue             | endValue
        "happy path 1"     || "2019-06-19T00:00:00Z" | "2021-07-19T00:00:00Z"
        "start date empty" || null                   | "2010-07-19T00:00:00Z"
        "end date empty"   || "2019-05-20T00:00:00Z" | null
        "both empty"       || null                   | null
    }

    @Unroll
    def "test cases for condition asserterObject  #desc"() {
        when:

        // map to fhir resource
        HealthCondition healthCondition = HealthCondition.builder()
                .asserterObject(IhrTerm.builder()
                        .ihrTerm(ihrTerm)
                        .ihrLaymanTerm("laymanTerm")
                        .sourceVocabulary("sourceVocabulary")
                        .sourceVocabularyCode(sourceVocabularyCode)
                        .build()).build()

        FhirResource fhirResource = buildFhirResource(new Bundle().setType(Bundle.BundleType.SEARCHSET), TestData.defaultPatient())

        // map to fhir resource
        mapper.map(fhirResource, healthCondition)
        Bundle bundle = fhirResource.getBundle()
        Condition condition = getFirstBundleResource(bundle, ResourceType.Condition) as Condition


        def informationSource = getAsserterObjectTextFromResource(condition)

        then:

        informationSource == ihrTerm

        where:
        desc                                                | sourceVocabularyCode    || ihrTerm
        "happy path PractitionerRole-Prescriber"            | "Prescriber"            || "Prescriber"
        "happy path PractitionerRole-Facility Staff"        | "Facility Staff"        || "Facility Staff"
        "happy path PractitionerRole-Medical Director"      | "Medical Director"      || "Medical Director"
        "happy path PractitionerRole-Myself"                | "Myself"                || "Myself"
        "happy path PractitionerRole-Pharmacist"            | "Pharmacist"            || "Pharmacist"
        "happy path PractitionerRole-Primary Care Provider" | "Primary Care Provider" || "Primary Care Provider"
        "happy path RelatedPerson-Caregiver"                | "Caregiver"             || "Caregiver"
        "happy path RelatedPerson-Family Member"            | "Family Member"         || "Family Member"
        "happy path RelatedPerson-Guardian"                 | "Guardian"              || "Guardian"
        "happy path RelatedPerson-Health Care Proxy"        | "Health Care Proxy"     || "Health Care Proxy"
        "happy path RelatedPerson-Other"                    | "Other"                 || "Other"
        "happy path RelatedPerson-Power of Attorney"        | "Power of Attorney"     || "Power of Attorney"
        "happy path Patient"                                | "Patient"               || "Patient"
        "invalid medSourceVocabularyCode information text"  | "Unknown Value"         || null
        "invalid medSourceVocabularyCode information text"  | null                    || null

    }

    static getAsserterObjectTextFromResource(Condition condition) {
        IBaseResource resource = ((Reference) condition.getAsserter()).getResource()
        if (resource instanceof RelatedPerson) {
            RelatedPerson relatedPerson = (RelatedPerson) resource
            return relatedPerson.getRelationship().get(0).getText()
        } else if (resource instanceof PractitionerRole) {
            PractitionerRole practitionerRole = (PractitionerRole) resource
            return practitionerRole.getCode().get(0).getText()
        } else if (resource instanceof Patient) {
            return "Patient"
        }
        return null
    }

}
