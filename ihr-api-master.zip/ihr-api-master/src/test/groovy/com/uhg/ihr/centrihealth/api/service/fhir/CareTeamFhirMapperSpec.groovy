package com.uhg.ihr.centrihealth.api.service.fhir

import com.fasterxml.jackson.databind.JsonNode
import com.google.common.collect.Iterables
import com.uhg.ihr.centrihealth.api.model.FhirResource
import com.uhg.ihr.centrihealth.api.model.Payload
import com.uhg.ihr.centrihealth.api.model.dataclass.AdverseReaction
import com.uhg.ihr.centrihealth.api.model.dataclass.Constants
import com.uhg.ihr.centrihealth.api.model.dataclass.DataClassEnums
import com.uhg.ihr.centrihealth.api.model.dataclass.IhrCareTeam
import com.uhg.ihr.centrihealth.api.service.FhirService
import com.uhg.ihr.centrihealth.util.TestData
import org.hl7.fhir.r4.model.AllergyIntolerance
import org.hl7.fhir.r4.model.Bundle
import org.hl7.fhir.r4.model.CareTeam
import org.hl7.fhir.r4.model.CodeableConcept
import org.hl7.fhir.r4.model.Coding
import org.hl7.fhir.r4.model.DateTimeType
import org.hl7.fhir.r4.model.Extension
import org.hl7.fhir.r4.model.Identifier
import org.hl7.fhir.r4.model.Patient
import org.hl7.fhir.r4.model.Period
import org.hl7.fhir.r4.model.Practitioner
import org.hl7.fhir.r4.model.PractitionerRole
import org.hl7.fhir.r4.model.RelatedPerson
import org.hl7.fhir.r4.model.ResourceType
import spock.lang.Shared

class CareTeamFhirMapperSpec extends BaseFhirSpecification {

    def resource = "CARE_TEAM"
    @Shared
    CareTeamFhirMapper mapper = CareTeamFhirMapper.of()

    def "care team mapper happy path "() {
        given:
        Payload samplePayload = TestData.buildSamplePayload("careteam.json")
        JsonNode dataNode = samplePayload.payloadJson['dataClasses'] as JsonNode
        Bundle bundle = FhirService.fhirConvert(getApiResponse(dataNode))
        CareTeam careTeam = getFirstBundleResource(bundle, ResourceType.CareTeam)

        def text_id = careTeam.getText().getId().toString()
        Identifier identifier1 = getIdentifierFromList(careTeam.getIdentifier(), Constants.INSTANCE_ID)
        Coding role = getCodingFromList(careTeam.getParticipant().get(0).getRole().get(0).getCoding(), "Prescribing Provider")
        def startDate = careTeam.getParticipant().get(0).getPeriod().getStartElement().getValueAsString()

        Patient patient = (Patient) careTeam.getSubject().getResource()

        PractitionerRole practitionerRole = (PractitionerRole) careTeam.getParticipant().get(0).getMember().getResource()
        Coding code = getCodingFromList(practitionerRole.getCode().get(0).getCoding(), "SOC16928")
        Coding speciality = getCodingFromList(((CodeableConcept) practitionerRole.getCode().get(0).getExtension().get(0).getValue()).getCoding(), "speciality sourceCode")

        Practitioner practitioner = (Practitioner) practitionerRole.getPractitioner().getResource()
        String name = practitioner.getName().get(0).getText().toString()

        expect:
        resource == text_id
        identifier1.getValue().toString() == "19523819001558"
        role.getDisplay() == "Prescribing Provider"
        startDate.substring(0, 10) == "2018-03-28"
        code.getSystem().toString() == "Occupation IhrId"
        speciality.getDisplay().toString() == "Family Medicine"
        name == "Trcka, Leslie A"
    }

    def "test identifier  #desc"() {
        when:
        // build v2 resource
        IhrCareTeam ihrCareTeam = IhrCareTeam.builder()
                .relatedEntityNPInum(npiValue).relatedEntityMPIN(mpinValue).recordType(DataClassEnums.CARE_TEAM)
                .build()
        FhirResource fhirResource = buildFhirResource(TestData.defaultBundle(), TestData.defaultPatient())
        // map to fhir resource
        mapper.map(fhirResource, ihrCareTeam)
        Bundle bundle = fhirResource.getBundle()
        CareTeam careTeam = getFirstBundleResource(bundle, ResourceType.CareTeam)
        PractitionerRole practitionerRole = null
        Practitioner practitioner = null
        def identNpi = null
        def identMpin = null

        if (null != careTeam.getParticipant() && careTeam.getParticipant().size() > 0) {
            practitionerRole = (PractitionerRole) careTeam.getParticipantFirstRep().getMember().getResource()
            if (practitionerRole.getPractitioner() != null) {
                practitioner = practitionerRole.getPractitioner().getResource()
            }
        }
        if (null != practitioner && practitioner.getIdentifier().size() > 0) {
            identNpi = getIdentifierValue(practitioner, npiValue)
            identMpin = getIdentifierValue(practitioner, mpinValue)

        }

        then:

        identNpi == npi
        identMpin == mpin

        where:
        desc            | npiValue   | mpinValue     || npi        | mpin
        "happy path "   | "123444"   | "2345678911"  || "123444"   | "2345678911"
        "both empty"    | null       | null          || null       | null
        "npi present"   | "ASE12345" | null          || "ASE12345" | null
        "mpin present " | null       | "ACC12334556" || null       | "ACC12334556"
    }

    static String getIdentifierValue(practitioner, String id) {
        String value = null
        def identifierList = practitioner.getIdentifier()
        for (Identifier identifier : identifierList) {
            if (identifier.getValue() == id) {
                value = identifier.getValue().toString()
            }
        }
        return value
    }
}