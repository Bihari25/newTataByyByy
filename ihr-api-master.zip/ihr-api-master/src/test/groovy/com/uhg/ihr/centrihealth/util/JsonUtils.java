package com.uhg.ihr.centrihealth.util;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.fasterxml.jackson.core.JsonParser;
import com.fasterxml.jackson.databind.DeserializationFeature;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.apache.commons.lang3.StringUtils;

/**
 * JsonUtil class used to handle serialize and de-serialize JSON.
 *
 * @author ihr api engineering team.
 * (C) All rights reserved UHG
 */
public class JsonUtils {
    private static final ObjectMapper MAPPER = new ObjectMapper()
            .configure(DeserializationFeature.FAIL_ON_UNKNOWN_PROPERTIES, false)
            .configure(JsonParser.Feature.ALLOW_UNQUOTED_FIELD_NAMES, true)
            .setSerializationInclusion(JsonInclude.Include.NON_NULL);

    public static <T> String serializeJson(T object) {
        String jsonInString = null;
        if (object != null) {
            try {
                jsonInString = MAPPER.writeValueAsString(object);
            } catch (Exception e) {
                throw new RuntimeException("unable to write object as json", e);
            }
        }
        return jsonInString;
    }

    public static <T> T deserializeJson(Class<T> clazz, String json) {
        T deSerializedValue = null;
        if (StringUtils.isNotBlank(json)) {
            try {
                deSerializedValue = MAPPER.readValue(json, clazz);
            } catch (Exception e) {
                throw new RuntimeException("unable to process the json", e);
            }
        }
        return deSerializedValue;
    }

}