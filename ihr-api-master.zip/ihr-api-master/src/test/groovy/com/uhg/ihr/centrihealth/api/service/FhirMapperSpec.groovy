package com.uhg.ihr.centrihealth.api.service

import com.uhg.ihr.centrihealth.api.model.FhirResource
import com.uhg.ihr.centrihealth.api.model.dataclass.Constants
import com.uhg.ihr.centrihealth.api.model.dataclass.DataClass
import com.uhg.ihr.centrihealth.api.model.dataclass.Evaluation
import com.uhg.ihr.centrihealth.api.model.dataclass.IhrTerm
import com.uhg.ihr.centrihealth.api.model.dataclass.Note
import com.uhg.ihr.centrihealth.api.model.dataclass.Supplier
import com.uhg.ihr.centrihealth.api.service.fhir.FhirMapper
import com.uhg.ihr.centrihealth.util.TestData
import org.hl7.fhir.r4.model.Condition
import org.hl7.fhir.r4.model.Extension
import org.hl7.fhir.r4.model.Identifier
import org.hl7.fhir.r4.model.Location
import org.hl7.fhir.r4.model.Observation
import org.hl7.fhir.r4.model.Organization
import org.hl7.fhir.r4.model.Patient
import org.hl7.fhir.r4.model.Practitioner
import org.hl7.fhir.r4.model.PractitionerRole
import org.hl7.fhir.r4.model.RelatedPerson
import org.hl7.fhir.r4.model.ResourceType
import org.hl7.fhir.r4.model.Specimen
import spock.lang.Shared
import spock.lang.Unroll

import java.time.ZoneId
import java.time.ZonedDateTime

@Unroll
class FhirMapperSpec extends TestData implements FhirMapper {

    @Shared
    Practitioner practitioner = defaultPractitioner()

    @Shared
    PractitionerRole practitionerRole = defaultPractitionerRole()

    @Shared
    RelatedPerson relatedPerson = defaultRelatedPerson()

    @Shared
    Organization organization = defaultOrganization()

    @Shared
    Condition condition = defaultCondition()

    @Shared
    Observation observation = defaultObservation()

    @Shared
    Location location = defaultLocation()

    @Shared
    Specimen specimen = defaultSpecimen()

    @Shared
    FhirResource fhirResource = defaultFhirResource()

    @Override
    void map(FhirResource fhirResource, DataClass dataClass) {}

    @Override
    void map(FhirResource fhirResource, Object dataClass) {}

    private int UUID_LENGTH = 45

    def "it matches dates with hyphens"() {
        when:
        def expected = isDatePatternHyphen(value)

        then:
        expected == result

        //FIXME: need more tests
        where:
        desc   | value || result
        "null" | null  || false
    }

    def "it matches dates with slashes"() {
        when:
        def expected = isDatePatternSlash(value)

        then:
        expected == result

        //FIXME: need more tests
        where:
        desc   | value || result
        "null" | null  || false
    }

    def "it determines if it's date or dateTime"() {
        when:
        def expected = isDateTime(value)

        then:
        expected == result

        //FIXME: need more tests
        where:
        desc   | value || result
        "null" | null  || false
    }

    def "validate extension #desc"() {
        when:
        def valueString = "HappyPath" == desc ? value : value + "Unhappy"
        def extensions = [buildExtension(Constants.PERSON_ROLE_TERM, value)] as List<Extension>

        then:
        def expected = isExtensionExists(extensions, Constants.PERSON_ROLE_TERM, valueString)
        expected == result

        where:
        desc          | value     || result
        "HappyPath"   | "Patient" || true
        "UnhappyPath" | "Doctor"  || false
    }

    def "validate Annotation"() {

        when:
        Patient patient = defaultPatient()
        Note note = buildSampleNote(text, time, author, noteType)
        FhirResource fhirResource = buildFhirResource(defaultBundle(), patient)
        def annotation = getAnnotation(patient, note, fhirResource)

        Extension noteTypeValue = getExtensionFromList(annotation.getExtension(), "https://new-wiki.optum.com/display/IHRI/ihrNoteType")
        def authorReference = annotation.getAuthorReference().getResource()
        def authorReferenceIdentifier = getAuthorReferenceIdentifier(authorReference, Constants.DATA_AUTHOR_IDENTIFIER)

        then:
        noteTypeValue.getValue().toString() == noteType
        annotation.getText() == text
        annotation.getTimeElement().getValueAsString() == time
        annotation.getAuthorReference().getResource().fhirType() == resourceType.toString()
        authorReferenceIdentifier.getValue() == author

        where:
        noteType          | text                         | time                   | author         || resourceType
        "Clinical Note"   | "Patient reports."           | "2019-03-28T00:00:00Z" | "ACT000123456" || ResourceType.Practitioner
        "PatientNote"     | "This medication is working" | "2018-03-28T00:00:00Z" | "ACT000000111" || ResourceType.Patient
        "Clinical Note"   | "Patient reports medication" | "2020-07-28T11:11:11Z" | "ACT098763"    || ResourceType.Practitioner
        "PatientTypeNote" | "This medication"            | "2012-03-28T00:00:00Z" | "ACT0003456"   || ResourceType.Patient
        ""                | "This medication"            | "2018-03-28T00:00:00Z" | "ACT0003456"   || ResourceType.Patient
        null              | "This medication report "    | "2014-03-28T00:00:00Z" | "ACT0003456"   || ResourceType.Patient
    }

    def "validate todate #desc"() {

        when:
        def date = toDate(value)
        ZonedDateTime zdt = date.toInstant().atZone(ZoneId.of(zoneId))

        then:
        zdt.getYear() == year
        zdt.getMonthValue() == month
        zdt.getDayOfMonth() == day
        zdt.getHour() == hours
        zdt.getMinute() == minutes
        zdt.getSecond() == seconds
        zdt.getNano() == nanos
        zdt.getZone().id == zoneId

        where:
        desc | value                           || year | month | day | hours | minutes | seconds | nanos     | zoneId
        "1"  | "2015-02-07T13:28:17.239+02:00" || 2015 | 2     | 7   | 11    | 28      | 17      | 239000000 | "UTC"
        "2"  | "2019/06/19"                    || 2019 | 6     | 19  | 0     | 0       | 0       | 0         | "UTC"
        "3"  | "2019-06-19"                    || 2019 | 6     | 19  | 0     | 0       | 0       | 0         | "UTC"
        "4"  | "2015-02-07T13:28:17-05:00"     || 2015 | 2     | 7   | 18    | 28      | 17      | 0         | "UTC"
        "5"  | "2017-01-01T00:00:00Z"          || 2017 | 1     | 1   | 0     | 0       | 0       | 0         | "UTC"
        "6"  | "2017-01-01T00:00:00.000Z"      || 2017 | 1     | 1   | 0     | 0       | 0       | 0         | "UTC"
        "7"  | "2015-02-07T13:28:17.249Z"      || 2015 | 2     | 7   | 13    | 28      | 17      | 249000000 | "UTC"
        "8"  | "2019-06-19T21:09:29Z"          || 2019 | 6     | 19  | 21    | 9       | 29      | 0         | "UTC"
        "9"  | "2019-06-19T21:09:29+00:30"     || 2019 | 6     | 19  | 20    | 39      | 29      | 0         | "UTC"
        "10" | "2019-06-19"                    || 2019 | 6     | 18  | 19    | 0       | 0       | 0         | "America/Chicago"
    }

    def "test invalid dates #desc"() {

        when:
        def date = toDate(value)

        then:
        date == null

        where:
        desc | value
        "1"  | "2019"
        "2"  | "2019-06"
        "3"  | "0019-06-19"
        "4"  | "2019-13-19"
        "5"  | "3019-13-19"
        "6"  | "2019-06-32"
        "7"  | "2019-06-19T21:09:29"
        "8"  | null
    }

    def "validate identifier #desc"() {

        when:
        def identifierList = [buildIdentifier(null, text, value)] as List<Identifier>
        def identifier = buildIdentifier(null, newText, newValue)

        then:
        def expected = isIdentifierExists(identifierList, identifier)
        expected == result

        where:
        desc          | text                             | newText                          | value     | newValue  || result
        "HappyPath"   | Constants.DATA_AUTHOR_IDENTIFIER | Constants.DATA_AUTHOR_IDENTIFIER | "patient" | "patient" || true
        "Not Found 1" | Constants.DATA_AUTHOR_IDENTIFIER | Constants.RECORD_KEY             | "patient" | "patient" || false
        "Not Found 2" | Constants.INSTANCE_ID            | Constants.INSTANCE_ID            | "patient" | "doctor"  || false
        "Not Found 3" | ""                               | Constants.REFERENCE_IDS          | "doctor"  | "doctor"  || false
        "Not Found 4" | null                             | Constants.DATA_AUTHOR_IDENTIFIER | "patient" | "patient" || false
        "Not Found 5" | Constants.RECORD_KEY             | ""                               | "doctor"  | "doctor"  || false
        "Not Found 6" | Constants.INSTANCE_ID            | null                             | "doctor"  | "doctor"  || false
        "Not Found 7" | Constants.REFERENCE_IDS          | Constants.REFERENCE_IDS          | null      | "doctor"  || false
        "Not Found 8" | Constants.REFERENCE_IDS          | Constants.REFERENCE_IDS          | "doctor"  | null      || false
        "Not Found 9" | Constants.REFERENCE_IDS          | Constants.REFERENCE_IDS          | "doctor"  | ""        || false
        "Not Found10" | Constants.REFERENCE_IDS          | Constants.REFERENCE_IDS          | ""        | "doctor"  || false
    }

    def "test new practitioner with identifier #desc"() {

        when:
        String id = practitioner.getId()
        String practitionerKey = getPractitionerKey(practitioner.getIdentifier().get(0))
        fhirResource.getPractitioner().put(practitionerKey, practitioner)

        def identifier = buildIdentifier(null, text, value)
        def newPractitioner = getOrCreatePractitioner(fhirResource, identifier)
        def idMatched = newPractitioner.getId() == id

        then:
        idMatched == expected
        newPractitioner.getId().length() == UUID_LENGTH
        newPractitioner.getIdentifier().get(0).getType().getText() == newText
        newPractitioner.getIdentifier().get(0).getValue() == newValue

        where:
        desc       | text               | value        || newText            | newValue     | expected
        "Existing" | "Medical Director" | "1234567890" || "Medical Director" | "1234567890" | true
        "New 1"    | "employeeId"       | "S001010301" || "employeeId"       | "S001010301" | false
        "New 2"    | ""                 | "S001010301" || null               | "S001010301" | false
        "New 3"    | null               | "S001010301" || null               | "S001010301" | false
        "New 4"    | "employeeId"       | ""           || "employeeId"       | null         | false
        "New 5"    | "employeeId"       | null         || "employeeId"       | null         | false
    }

    def "test new practitioner with humanName #desc"() {

        when:
        String id = practitioner.getId()
        String practitionerKey = omitNull(practitioner.getName().get(0).getText())
        fhirResource.getPractitioner().put(practitionerKey, practitioner)

        def humanName = buildHumanName(null, null, null, text, null)
        def newPractitioner = getOrCreatePractitioner(fhirResource, humanName)
        def idMatched = newPractitioner.getId() == id

        then:
        idMatched == expected
        newPractitioner.getId().length() == UUID_LENGTH
        newPractitioner.getName().get(0).getText() == newText

        where:
        desc       | text              || newText           | expected
        "Existing" | "Mosley, David H" || "Mosley, David H" | true
        "New 1"    | "Bond, James A"   || "Bond, James A"   | false
        "New 2"    | ""                || null              | false
        "New 3"    | null              || null              | false
    }

    def "test new practitioner role with identifier #desc"() {

        when:
        String id = practitionerRole.getId()
        String practitionerRoleKey = getPractitionerRoleKey(practitionerRole.getIdentifier().get(0))
        fhirResource.getPractitionerRole().put(practitionerRoleKey, practitionerRole)

        def identifier = buildIdentifier(code, null, value)
        def newPractitioner = getOrCreatePractitionerRole(fhirResource, identifier)
        def idMatched = newPractitioner.getId() == id

        then:
        idMatched == expected
        newPractitioner.getId().length() == UUID_LENGTH
        newPractitioner.getIdentifier().get(0).getType().getCoding().get(0).getCode() == newCode
        newPractitioner.getIdentifier().get(0).getValue() == newValue

        where:
        desc       | code   | value        || newCode | newValue     | expected
        "Existing" | "NPI"  | "1234567890" || "NPI"   | "1234567890" | true
        "New 1"    | "ABCD" | "S001010301" || "ABCD"  | "S001010301" | false
        "New 2"    | ""     | "S001010301" || null    | "S001010301" | false
        "New 3"    | null   | "S001010301" || null    | "S001010301" | false
        "New 4"    | "ABCD" | ""           || "ABCD"  | null         | false
        "New 5"    | "ABCD" | null         || "ABCD"  | null         | false
    }

    def "test new practitioner role with practitioner code #desc"() {

        when:
        String id = practitionerRole.getId()
        String practitionerRoleKey = omitNull(practitionerRole.getCode().get(0).getText())
        fhirResource.getPractitionerRole().put(practitionerRoleKey, practitionerRole)

        def practitionerCode = buildCodeableConcept(text, null, null, null)
        def newPractitioner = getOrCreatePractitionerRole(fhirResource, practitionerCode)
        def idMatched = newPractitioner.getId() == id

        then:
        idMatched == expected
        newPractitioner.getId().length() == UUID_LENGTH
        newPractitioner.getCode().get(0).getCoding().isEmpty() == newCode
        newPractitioner.getCode().get(0).getText() == newText

        where:
        desc       | code  | text               || newCode | newText            | expected
        "Existing" | "NPI" | "Medical Director" || true    | "Medical Director" | true
        "New 1"    | "NPI" | "Nurse"            || false   | "Nurse"            | false
        "New 2"    | ""    | "Nurse"            || false   | "Nurse"            | false
        "New 3"    | null  | "Nurse"            || false   | "Nurse"            | false
        "New 4"    | "NPI" | ""                 || false   | null               | false
        "New 5"    | "NPI" | null               || false   | null               | false
    }

    def "test new related person with humanName #desc"() {

        when:
        String id = relatedPerson.getId()
        String humanNameKey = getHumanNameKey(relatedPerson.getName().get(0))
        fhirResource.getRelatedPerson().put(humanNameKey, relatedPerson)

        def humanName = buildHumanName(family, given, middle, text, prefix)
        def newRelatedPerson = getOrCreateRelatedPerson(fhirResource, humanName)
        def idMatched = newRelatedPerson.getId() == id

        then:
        idMatched == expected
        newRelatedPerson.getId().length() == UUID_LENGTH
        newRelatedPerson.getName().get(0).getFamily() == newFamily
        newRelatedPerson.getName().get(0).getGivenAsSingleString() == givenString
        newRelatedPerson.getName().get(0).getText() == newText
        newRelatedPerson.getName().get(0).getPrefixAsSingleString() == newPrefix

        where:
        desc       | family   | given   | middle | text              | prefix || newFamily | givenString | newText           | newPrefix | expected
        "Existing" | "Mosley" | "David" | "H"    | "Mosley, David H" | "DR."  || "Mosley"  | "David H"   | "Mosley, David H" | "DR."     | true
        "New 1"    | "Bond"   | "James" | "W"    | "Bond, James W"   | "Mr."  || "Bond"    | "James W"   | "Bond, James W"   | "Mr."     | false
        "New 2"    | ""       | "James" | "W"    | "Bond, James W"   | "Mr."  || null      | "James W"   | "Bond, James W"   | "Mr."     | false
        "New 3"    | null     | "James" | "W"    | "Bond, James W"   | "Mr."  || null      | "James W"   | "Bond, James W"   | "Mr."     | false
        "New 4"    | "Bond"   | ""      | "W"    | "Bond, James W"   | "Mr."  || "Bond"    | "W"         | "Bond, James W"   | "Mr."     | false
        "New 5"    | "Bond"   | null    | "W"    | "Bond, James W"   | "Mr."  || "Bond"    | "W"         | "Bond, James W"   | "Mr."     | false
        "New 6"    | "Bond"   | "James" | "W"    | ""                | "Mr."  || "Bond"    | "James W"   | null              | "Mr."     | false
    }

    def "test new related person with relationShip #desc"() {

        when:
        String id = relatedPerson.getId()
        String relatedPersonKey = omitNull(relatedPerson.getRelationship().get(0).getText())
        fhirResource.getRelatedPerson().put(relatedPersonKey, relatedPerson)

        def relationShip = buildCodeableConcept(text, null, null, null)
        def newRelatedPerson = getOrCreateRelatedPerson(fhirResource, relationShip)
        def idMatched = newRelatedPerson.getId() == id

        then:
        idMatched == expected
        newRelatedPerson.getId().length() == UUID_LENGTH
        newRelatedPerson.getRelationship().get(0).getCoding().isEmpty() == newCode
        newRelatedPerson.getRelationship().get(0).getText() == newText

        where:
        desc       | code  | text                || newCode | newText             | expected
        "Existing" | "NPI" | "Health Care Proxy" || true    | "Health Care Proxy" | true
        "New 1"    | "NPI" | "Related Person"    || false   | "Related Person"    | false
        "New 2"    | ""    | "Related Person"    || false   | "Related Person"    | false
        "New 3"    | null  | "Related Person"    || false   | "Related Person"    | false
        "New 4"    | "NPI" | ""                  || false   | null                | false
        "New 5"    | "NPI" | null                || false   | null                | false
    }

    def "test new organization with identifier #desc"() {

        when:
        String id = organization.getId()
        String organizationKey = getOrganizationKey(organization.getIdentifier().get(0))
        fhirResource.getOrganization().put(organizationKey, organization)

        def orgIdentifier = buildOrganizationIdentifier(system, value)
        def newOrganizationn = getOrCreateOrganization(fhirResource, orgIdentifier)
        def idMatched = newOrganizationn.getId() == id

        then:
        idMatched == expected
        newOrganizationn.getId().length() == UUID_LENGTH
        newOrganizationn.getIdentifier().get(0).getSystem() == newSystem
        newOrganizationn.getIdentifier().get(0).getValue() == newValue

        where:
        desc       | system                           | value        || newSystem                        | newValue     | expected
        "Existing" | "http://hl7.org/fhir/sid/us-npi" | "1234567890" || "http://hl7.org/fhir/sid/us-npi" | "1234567890" | true
        "New 1"    | "http://hl7.org/fhir/sid/us-npi" | "S12345"     || "http://hl7.org/fhir/sid/us-npi" | "S12345"     | false
        "New 2"    | ""                               | "S12345"     || null                             | "S12345"     | false
        "New 3"    | null                             | "S12345"     || null                             | "S12345"     | false
        "New 4"    | "http://hl7.org/fhir/sid/us-npi" | ""           || "http://hl7.org/fhir/sid/us-npi" | null         | false
        "New 5"    | "http://hl7.org/fhir/sid/us-npi" | null         || "http://hl7.org/fhir/sid/us-npi" | null         | false
        "New 6"    | null                             | null         || null                             | null         | false
    }

    def "test new condition with condition code #desc"() {

        when:
        String id = condition.getId()
        String conditionKey = getConditionKey(condition.getCode())
        fhirResource.getCondition().put(conditionKey, condition)

        def conditionCode = buildCodeableConcept(text, display, code, system)
        def newCondition = getOrCreateCondition(fhirResource, conditionCode)
        def idMatched = newCondition.getId() == id

        then:
        idMatched == expected
        newCondition.getId().length() == UUID_LENGTH
        newCondition.getCode().getText() == newText
        newCondition.getCode().getCoding().get(0).getDisplay() == newDisplay
        newCondition.getCode().getCoding().get(0).getCode() == newCode
        newCondition.getCode().getCoding().get(0).getSystem() == newSystem

        where:
        desc       | text               | display            | code    | system                 || newText            | newDisplay         | newCode | newSystem              | expected
        "Existing" | "Anxiety Disorder" | "Anxiety Disorder" | "F41.9" | "ICD10 Diagnosis Code" || "Anxiety Disorder" | "Anxiety Disorder" | "F41.9" | "ICD10 Diagnosis Code" | true
        "New 1"    | "Feeling Well"     | "Feeling Well"     | "B00.7" | "Open System"          || "Feeling Well"     | "Feeling Well"     | "B00.7" | "Open System"          | false
        "New 2"    | ""                 | "Feeling Well"     | "B00.7" | "Open System"          || null               | "Feeling Well"     | "B00.7" | "Open System"          | false
        "New 3"    | null               | "Feeling Well"     | "B00.7" | "Open System"          || null               | "Feeling Well"     | "B00.7" | "Open System"          | false
        "New 4"    | "Feeling Well"     | ""                 | "B00.7" | "Open System"          || "Feeling Well"     | null               | "B00.7" | "Open System"          | false
        "New 5"    | "Feeling Well"     | null               | "B00.7" | "Open System"          || "Feeling Well"     | null               | "B00.7" | "Open System"          | false
        "New 6"    | "Feeling Well"     | "Feeling Well"     | ""      | "Open System"          || "Feeling Well"     | "Feeling Well"     | null    | "Open System"          | false
        "New 7"    | "Feeling Well"     | "Feeling Well"     | null    | "Open System"          || "Feeling Well"     | "Feeling Well"     | null    | "Open System"          | false
        "New 8"    | "Feeling Well"     | "Feeling Well"     | "B00.7" | ""                     || "Feeling Well"     | "Feeling Well"     | "B00.7" | null                   | false
        "New 9"    | "Feeling Well"     | "Feeling Well"     | "B00.7" | null                   || "Feeling Well"     | "Feeling Well"     | "B00.7" | null                   | false
    }

    def "test new observation with target #desc"() {

        when:
        String id = observation.getId()
        def dtt = observation.getEffective()
        def targetResult = observation.getValue()
        String observationKey = getObservationKey(dtt, targetResult)
        fhirResource.getObservation().put(observationKey, observation)

        Evaluation evaluation = buildEvaluation(dateTimeType, stringType)
        def newObservation = getOrCreateObservation(fhirResource, evaluation)
        def idMatched = newObservation.getId() == id

        then:
        idMatched == expected
        newObservation.getId().length() == UUID_LENGTH
        newObservation.getEffective().getProperties().get("valueAsString") == newDateTimeType
        newObservation.getValue().toString() == newStringType

        where:
        desc       | dateTimeType           | stringType || newDateTimeType        | newStringType | expected
        "Existing" | "2019-07-20T00:00:00Z" | "7.3"      || "2019-07-20T00:00:00Z" | "7.3"         | true
        "New 1"    | "2019-09-20T00:00:00Z" | "7.6"      || "2019-09-20T00:00:00Z" | "7.6"         | false
        "New 2"    | ""                     | "7.6"      || ""                     | "7.6"         | false
        "New 3"    | null                   | "7.6"      || ""                     | "7.6"         | false
        "New 4"    | "2019-09-20T00:00:00Z" | ""         || "2019-09-20T00:00:00Z" | ""            | false
        "New 5"    | "2019-09-20T00:00:00Z" | null       || "2019-09-20T00:00:00Z" | null          | false
        "New 6"    | null                   | null       || ""                     | null          | false
    }

    def "test new location with supplier #desc"() {

        when:
        String id = location.getId()
        Supplier supplier = defaultSupplier()
        String locationKey = getLocationKey(supplier)
        fhirResource.getLocation().put(locationKey, location)

        Supplier newSupplier = buildSupplier(supplierName, npiNum)
        def newLocation = getOrCreateLocation(fhirResource, newSupplier)
        def idMatched = newLocation.getId() == id

        then:
        idMatched == expected
        newLocation.getId().length() == UUID_LENGTH
        newLocation.getName() == newSupplierName
        newLocation.getIdentifier().get(0).getValue() == newnpiNum

        where:
        desc       | supplierName             | npiNum       || newSupplierName          | newnpiNum    | expected
        "Existing" | "Liberty Medical Supply" | "1950076532" || "Liberty Medical Supply" | "1950076532" | true
        "New 1"    | "New Medical"            | "1950076000" || "New Medical"            | "1950076000" | false
        "New 2"    | ""                       | "1950076000" || null                     | "1950076000" | false
        "New 3"    | null                     | "1950076000" || null                     | "1950076000" | false
        "New 4"    | "New Medical"            | ""           || "New Medical"            | null         | false
        "New 5"    | "New Medical"            | null         || "New Medical"            | null         | false
        "New 6"    | null                     | null         || null                     | null         | false
    }

    def "test new specimen #desc"() {

        when:
        String id = specimen.getId()
        IhrTerm defaultIhrTerm = defaultIhrTerm()
        String specimenKey = getSpecimensKey(defaultIhrTerm)
        fhirResource.getSpecimen().put(specimenKey, specimen)

        IhrTerm newIhrTerm = buildIhrTerm(ihrTerm, laymanTerm, sVocabulary, svCode)
        def newSpecimen = getOrCreateSpecimen(fhirResource, newIhrTerm)
        def idMatched = newSpecimen.getId() == id

        then:
        idMatched == expected
        newSpecimen.getId().length() == UUID_LENGTH
        newSpecimen.getType().getText() == newLaymanTerm
        newSpecimen.getType().getCoding().get(0).getCode() == newSvCode
        newSpecimen.getType().getCoding().get(0).getDisplay() == newIhrTermStr
        newSpecimen.getType().getCoding().get(0).getSystem() == newSvocabulary

        where:
        desc       | ihrTerm  | laymanTerm | sVocabulary         | svCode      || newIhrTermStr | newLaymanTerm | newSvocabulary      | newSvCode   | expected
        "Existing" | "Blood"  | "Blood"    | "SNOMEDCT Specimen" | "119297000" || "Blood"       | "Blood"       | "SNOMEDCT Specimen" | "119297000" | true
        "New 1"    | "Tablet" | "Tablet"   | "New Specimen"      | "119297222" || "Tablet"      | "Tablet"      | "New Specimen"      | "119297222" | false
        "New 2"    | ""       | "Tablet"   | "New Specimen"      | "119297222" || null          | "Tablet"      | "New Specimen"      | "119297222" | false
        "New 3"    | null     | "Tablet"   | "New Specimen"      | "119297222" || null          | "Tablet"      | "New Specimen"      | "119297222" | false
        "New 4"    | "Tablet" | ""         | "New Specimen"      | "119297222" || "Tablet"      | null          | "New Specimen"      | "119297222" | false
        "New 5"    | "Tablet" | null       | "New Specimen"      | "119297222" || "Tablet"      | null          | "New Specimen"      | "119297222" | false
        "New 6"    | "Tablet" | "Tablet"   | ""                  | "119297222" || "Tablet"      | "Tablet"      | null                | "119297222" | false
        "New 7"    | "Tablet" | "Tablet"   | null                | "119297222" || "Tablet"      | "Tablet"      | null                | "119297222" | false
        "New 8"    | "Tablet" | "Tablet"   | "New Specimen"      | ""          || "Tablet"      | "Tablet"      | "New Specimen"      | null        | false
        "New 9"    | null     | null       | null                | null        || null          | null          | null                | null        | false
    }
}