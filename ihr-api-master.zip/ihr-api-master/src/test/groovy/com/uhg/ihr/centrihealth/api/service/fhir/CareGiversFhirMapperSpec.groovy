package com.uhg.ihr.centrihealth.api.service.fhir

import com.fasterxml.jackson.databind.JsonNode
import com.uhg.ihr.centrihealth.api.model.FhirResource
import com.uhg.ihr.centrihealth.api.model.Payload
import com.uhg.ihr.centrihealth.api.model.dataclass.CareGiver
import com.uhg.ihr.centrihealth.api.model.dataclass.Constants
import com.uhg.ihr.centrihealth.api.model.dataclass.Note
import com.uhg.ihr.centrihealth.api.service.FhirService
import com.uhg.ihr.centrihealth.util.TestData
import org.hl7.fhir.r4.model.Bundle
import org.hl7.fhir.r4.model.CareTeam
import org.hl7.fhir.r4.model.Identifier
import org.hl7.fhir.r4.model.Patient
import org.hl7.fhir.r4.model.Reference
import org.hl7.fhir.r4.model.RelatedPerson
import org.hl7.fhir.r4.model.Resource
import org.hl7.fhir.r4.model.ResourceType
import spock.lang.Shared
import spock.lang.Unroll

@Unroll
class CareGiversFhirMapperSpec extends BaseFhirSpecification {

    def resource = "CARE_GIVER"
    @Shared
    CareGiverFhirMapper mapper = CareGiverFhirMapper.of()

    def "care givers mapper happy path "() {

        given:
        Payload samplePayload = TestData.buildSamplePayload("careGivers.json")
        JsonNode dataNode = samplePayload.payloadJson['dataClasses'] as JsonNode
        Bundle bundle = FhirService.fhirConvert(getApiResponse(dataNode))
        CareTeam careTeam = getFirstBundleResource(bundle, ResourceType.CareTeam)

        def text_id = careTeam.getText().getId().toString()
        Identifier instanceId = getIdentifierFromList(careTeam.getIdentifier(), Constants.INSTANCE_ID)
        Identifier referenceId = getIdentifierFromList(careTeam.getIdentifier(), Constants.REFERENCE_IDS)
        String startdate = careTeam.getPeriod().getStartElement().getValueAsString()

        RelatedPerson relatedPerson = (RelatedPerson) careTeam.getParticipant().get(0).getMember().getResource()
        def relatedPersonName = relatedPerson.getName().get(0).getText()

        expect:
        text_id == resource
        instanceId.getValue().toString() == "36904978693011"
        referenceId.getValue().toString() == "[\"2019-01-02T03:04:44Z-Rally-1sE\"]"
        relatedPersonName == "Smith, John J"
        startdate.substring(0, 10) == "2019-09-03"

    }

    def "realted person data  "() {

        when:
        // build v2 resource
        CareGiver careGiver = CareGiver.builder()
                .relatedEntityName(relatedEntityName)
                .relatedEntityRoleTerm(relatedEntityRoleTerm)
                .build()
        //create fhir resource
        FhirResource fhirResource = buildFhirResource(TestData.defaultBundle(), TestData.defaultPatient())
        // map to fhir resource
        mapper.map(fhirResource, careGiver)
        Bundle bundle = fhirResource.getBundle()
        CareTeam careTeam = getFirstBundleResource(bundle, ResourceType.CareTeam)
        def relatedPersonName = null
        def relationship = null
        RelatedPerson relatedPerson = null

        if (null != careTeam.getParticipant() && careTeam.getParticipant().size() > 0) {
            relatedPerson = (RelatedPerson) careTeam.getParticipant().get(0).getMember().getResource()
        }
        if (null != relatedPerson) {
            if (null != relatedPerson.getName() && relatedPerson.getName().size() > 0) {
                relatedPersonName = relatedPerson.getName().get(0).getText()
            }
            if (null != relatedPerson.getRelationship() && relatedPerson.getRelationship().size() > 0) {
                relationship = relatedPerson.getRelationship().get(0).getText()
            }
        }
        then:
        relationship == relationshipTextValue
        relatedPersonName == humanNameValue

        where:
        desc                               | relatedEntityName | relatedEntityRoleTerm || relationshipTextValue || humanNameValue
        "both present "                    | "Smith, John J"   | "Patient Data"        || "Patient Data"        || "Smith, John J"
        "related Entity Role Term present" | null              | "Patient"             || "Patient"             || null
        "related Entity Name present"      | "Test"            | null                  || null                  || "Test"
        "not present"                      | null              | null                  || null                  || null

    }
}
