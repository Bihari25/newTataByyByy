package com.uhg.ihr.centrihealth.api.service.fhir.v2

import com.uhg.ihr.centrihealth.api.model.FhirResource
import com.uhg.ihr.centrihealth.api.model.dataclass.Constants
import com.uhg.ihr.centrihealth.api.model.dataclass.DataClass
import com.uhg.ihr.centrihealth.api.model.dataclass.HealthCondition
import com.uhg.ihr.centrihealth.api.model.dataclass.IhrTerm
import com.uhg.ihr.centrihealth.api.model.dataclass.ProcedureHistory
import com.uhg.ihr.centrihealth.api.model.dataclass.VisitHistory
import com.uhg.ihr.centrihealth.api.service.fhir.BaseFhirSpecification
import com.uhg.ihr.centrihealth.api.util.AppUtils
import org.apache.commons.lang3.StringUtils
import org.hl7.fhir.r4.model.CodeableConcept
import org.hl7.fhir.r4.model.Coding
import org.hl7.fhir.r4.model.Condition
import org.hl7.fhir.r4.model.DateTimeType
import org.hl7.fhir.r4.model.Encounter
import org.hl7.fhir.r4.model.Extension
import org.hl7.fhir.r4.model.IdType
import org.hl7.fhir.r4.model.Identifier
import org.hl7.fhir.r4.model.Patient
import org.hl7.fhir.r4.model.Period
import org.hl7.fhir.r4.model.Procedure
import org.hl7.fhir.r4.model.StringType
import org.hl7.fhir.r4.model.codesystems.DiagnosisRole
import spock.lang.Shared
import spock.lang.Unroll

class EncounterFhir2MapperSpec extends BaseFhirSpecification {

    //Shared between tests
    @Shared
    private EncounterFhir2Mapper mapper

    //Unique for each test
    private FhirResource fhirResource
    private VisitHistory visitHistory
    private Encounter encounter

    def setupSpec() {
        mapper = EncounterFhir2Mapper.of()
    }

    def setup() {
        fhirResource = buildFhirResource()
        visitHistory = new VisitHistory()
        encounter = new Encounter()
    }

    @Unroll
    def "#desc1 will #desc2"() {
        given:

        DataClass dataClass = DataClass.builder().visitHistory(visits).build()

        when:
        mapper.map(fhirResource, dataClass)
        List<Encounter> encounters = getResourcesOfTypeFromBundle(fhirResource.getBundle(), Encounter.class)

        then:
        encounters.size() == (visits == null ? 0 : visits.size())

        where:
        desc1              | desc2                  | visits
        "No visitHistory"  | "not map to encounter" | null
        "One visitHistory" | "map one encounter"    | List.of(new VisitHistory())
        "Two visitHistory" | "map two encounters"   | List.of(new VisitHistory(), new VisitHistory())
    }

    def "encounter id set"() {
        given:

        when:
        mapper.map(fhirResource, visitHistory)
        Encounter foundEncounter = getFirstBundleResource(fhirResource.getBundle(), Encounter.class)

        then:
        foundEncounter != null
        StringUtils.isNotBlank(foundEncounter.getId())
    }

    def "Patient -> subject"() {
        given:

        when:
        mapper.buildObservationResource(encounter, fhirResource, visitHistory)

        then:
        encounter.getSubject() != null
        encounter.getSubject().getResource() instanceof Patient
        (encounter.getSubject().getResource() as Patient).getId() == fhirResource.getPatient().getId()
    }

    def "recordKey -> identifier"() {
        given:
        visitHistory.setRecordKey("SomeRecordKey737485")

        when:
        mapper.buildObservationResource(encounter, fhirResource, visitHistory)

        then:
        encounter.getIdentifier() != null
        encounter.getIdentifierFirstRep().getType().getText() == Constants.RECORD_KEY
        encounter.getIdentifierFirstRep().getValue() == visitHistory.getRecordKey()
    }

    def "referenceIds -> identifier"() {
        given:
        visitHistory.setReferenceIds(List.of("Ref234567"))

        when:
        mapper.buildObservationResource(encounter, fhirResource, visitHistory)

        then:
        encounter.getIdentifier() != null
        encounter.getIdentifierFirstRep().getType().getText() == Constants.REFERENCE_IDS
        encounter.getIdentifierFirstRep().getValue() == AppUtils.jsonEscape(visitHistory.getReferenceIds())
    }

    def "objectId -> identifier"() {
        given:
        long objectId = 12345678L
        and:
        visitHistory.setObjectId(BigInteger.valueOf(objectId))

        when:
        mapper.buildObservationResource(encounter, fhirResource, visitHistory)

        then:
        encounter.getIdentifier() != null
        encounter.getIdentifierFirstRep().getType().getText() == Constants.INSTANCE_ID
        encounter.getIdentifierFirstRep().getValue() == objectId.toString()
    }

    def "sensitivityClasses -> meta.security"() {
        given:
        visitHistory.setSensitivityClasses(List.of("Sensitive"))

        when:
        mapper.buildObservationResource(encounter, fhirResource, visitHistory)

        then:
        encounter.getMeta() != null
        encounter.getMeta().getSecurity(Constants.SECURITY_SYSTEM_URL, Constants.SECURITY_CODE) != null
    }

    @Unroll
    def "visit -> type with #desc"() {
        given:
        IhrTerm visit = buildBasicIhrTerm()
        visit.setCpthcpcsCode(cptCode)
        and:
        visitHistory.setVisit(visit)

        when:
        mapper.buildObservationResource(encounter, fhirResource, visitHistory)
        CodeableConcept type = encounter.getTypeFirstRep()

        then:
        type != null
        type.getText() == visit.getIhrLaymanTerm()
        type.getCoding().get(0).getDisplay() == visit.getIhrTerm()
        type.getCoding().get(0).getSystem() == visit.getSourceVocabulary()
        type.getCoding().get(0).getCode() == visit.getSourceVocabularyCode()
        if (cptCode != null) {
            Coding cptCodeObj
            for (Coding code : type.getCoding()) {
                if (code.getSystem() == Constants.CPTHCPCS_CODE_URL) {
                    cptCodeObj = code
                    break
                }
            }
            cptCodeObj != null
            cptCodeObj.getSystem() == Constants.CPTHCPCS_CODE_URL
            cptCodeObj.getCode() == visit.getCpthcpcsCode()
        }

        where:
        desc               | cptCode
        "no cpthcpcs code" | null
        "cpthcpcs code"    | "cpthcpcsCode13857"
    }

    def "visitType -> class.display"() {
        given:
        visitHistory.setVisitType("TestingVisitType")

        when:
        mapper.buildObservationResource(encounter, fhirResource, visitHistory)

        then:
        encounter.getClass_() != null
        encounter.getClass_().getDisplay() == visitHistory.getVisitType()
    }

    def "status -> status.display"() {
        given:
        visitHistory.setStatus("StatusIsgood")

        when:
        mapper.buildObservationResource(encounter, fhirResource, visitHistory)

        then:
        encounter.getStatus() == Encounter.EncounterStatus.FINISHED
    }

    def "presenceStateTerm -> extension"() {
        given:
        visitHistory.setPresenceStateTerm("PresentStateTerm")

        when:
        mapper.buildObservationResource(encounter, fhirResource, visitHistory)
        Extension state = encounter.getExtensionByUrl(Constants.PRESENCE_STATE_TERM_V2_URL)

        then:
        state != null
        state.getValue() instanceof StringType
        (state.getValue() as StringType).getValue() == visitHistory.getPresenceStateTerm()
    }

    @Unroll
    def "admitDate is #admit and dischargeDate is #discharge"() {
        given:
        visitHistory.setAdmitDate(admit)
        visitHistory.setDischargeDate(discharge)

        when:
        mapper.buildObservationResource(encounter, fhirResource, visitHistory)
        Period period = encounter.getPeriod()

        then:
        period != null || (admit == null && discharge == null)
        if (admit != null) {
            period.getStartElement().equalsShallow(mapper.toDateTimeTypeFromDate(admit))
        }
        if (discharge != null) {
            period.getEndElement().equalsShallow(mapper.toDateTimeTypeFromDate(discharge))
        }

        where:
        admit        | discharge
        null         | null
        "2000/01/01" | null
        null         | "2005/12/12"
        "2000/01/01" | "2005/12/12"
    }

    @Unroll
    def "admittingDiagnosis -> diagnosis with #desc"() {
        given:
        visitHistory.setAdmittingDiagnosis(admitList)

        when:
        mapper.buildObservationResource(encounter, fhirResource, visitHistory)
        List<Encounter.DiagnosisComponent> diagnosis = encounter.getDiagnosis()

        then:
        diagnosis != null
        diagnosis.size() == admitList.size()
        diagnosis.get(0).getUse().getText() == DiagnosisRole.AD.getDisplay()
        diagnosis.get(0).getUse().getCodingFirstRep().getCode() == DiagnosisRole.AD.toCode()
        diagnosis.get(0).getUse().getCodingFirstRep().getSystem() == DiagnosisRole.AD.getSystem()
        diagnosis.get(0).getUse().getCodingFirstRep().getDisplay() == DiagnosisRole.AD.getDisplay()

        where:
        desc          | admitList
        "1 diagnosis" | List.of(buildBasicIhrTerm())
        "2 diagnosis" | List.of(buildBasicIhrTerm(), buildBasicIhrTerm("term1", "layman1", "vocab1", "source1"))
    }

    @Unroll
    def "dischargeDiagnosis -> diagnosis with #desc"() {
        given:
        visitHistory.setDischargeDiagnosis(dischargeList)

        when:
        mapper.buildObservationResource(encounter, fhirResource, visitHistory)
        List<Encounter.DiagnosisComponent> diagnosis = encounter.getDiagnosis()

        then:
        diagnosis != null
        diagnosis.size() == dischargeList.size()
        diagnosis.get(0).getUse().getText() == DiagnosisRole.DD.getDisplay()
        diagnosis.get(0).getUse().getCodingFirstRep().getCode() == DiagnosisRole.DD.toCode()
        diagnosis.get(0).getUse().getCodingFirstRep().getSystem() == DiagnosisRole.DD.getSystem()
        diagnosis.get(0).getUse().getCodingFirstRep().getDisplay() == DiagnosisRole.DD.getDisplay()

        where:
        desc          | dischargeList
        "1 diagnosis" | List.of(buildBasicIhrTerm())
        "2 diagnosis" | List.of(buildBasicIhrTerm(), buildBasicIhrTerm("term1", "layman1", "vocab1", "source1"))
    }

    def "admitSource -> hospitalization.admitSource"() {
        given:
        visitHistory.setAdmitSource("admittanceSource")

        when:
        mapper.buildObservationResource(encounter, fhirResource, visitHistory)
        Encounter.EncounterHospitalizationComponent hospitalization = encounter.getHospitalization()

        then:
        hospitalization.getAdmitSource() != null
        hospitalization.getAdmitSource().getText() == visitHistory.getAdmitSource()
    }

    def "dischargeDisposition -> hospitalization.dischargeDisposition"() {
        given:
        IhrTerm dischargeDisposition = buildBasicIhrTerm()
        and:
        visitHistory.setDischargeDisposition(dischargeDisposition)

        when:
        mapper.buildObservationResource(encounter, fhirResource, visitHistory)
        Encounter.EncounterHospitalizationComponent hospitalization = encounter.getHospitalization()
        CodeableConcept fhirDischargeDisposition

        then:
        (fhirDischargeDisposition = hospitalization.getDischargeDisposition()) != null
        fhirDischargeDisposition.getText() == dischargeDisposition.getIhrLaymanTerm()
        fhirDischargeDisposition.getCodingFirstRep().getDisplay() == dischargeDisposition.getIhrTerm()
        fhirDischargeDisposition.getCodingFirstRep().getSystem() == dischargeDisposition.getSourceVocabulary()
        fhirDischargeDisposition.getCodingFirstRep().getCode() == dischargeDisposition.getSourceVocabularyCode()
    }

    def "clinicallyRelevantDate -> extension"() {
        given:
        visitHistory.setClinicallyRelevantDate("2000/02/01")

        when:
        mapper.buildObservationResource(encounter, fhirResource, visitHistory)

        then:
        encounter.getExtensionByUrl(Constants.CLINICALLY_RELEVANT_DATE_V2_URL) != null
        encounter.getExtensionByUrl(Constants.CLINICALLY_RELEVANT_DATE_V2_URL).getValue() instanceof DateTimeType
        (encounter.getExtensionByUrl(Constants.CLINICALLY_RELEVANT_DATE_V2_URL).getValue() as DateTimeType).equalsShallow(mapper.toDateTimeTypeFromDate(visitHistory.getClinicallyRelevantDate()))
    }

    def "lastUpdateDate -> meta.lastUpdated"() {
        given:
        visitHistory.setLastUpdateDate("2005/05/04")

        when:
        mapper.buildObservationResource(encounter, fhirResource, visitHistory)

        then:
        encounter.getMeta() != null
        encounter.getMeta().getLastUpdatedElement() != null
        encounter.getMeta().getLastUpdatedElement().equalsShallow(mapper.toInstantTypeFromDate(visitHistory.getLastUpdateDate()))
    }

    def "relatedConditions -> diagnosis"() {
        given:
        BigInteger conditionId = BigInteger.valueOf(1234L)
        and:
        visitHistory.setRelatedConditions(List.of(conditionId))
        and:
        Condition condition = new Condition()
        condition.setId(new IdType(mapper.createIdURI()))
        and:
        fhirResource.addFhirResourceToDeferredMapper(condition, HealthCondition.builder().objectId(conditionId).build())

        when:
        mapper.buildObservationResource(encounter, fhirResource, visitHistory)

        then:
        encounter.getDiagnosisFirstRep() != null
        encounter.getDiagnosisFirstRep().getCondition().getResource() == condition
    }


    def "relatedProcedures -> diagnosis"() {
        given:
        BigInteger procedureId = BigInteger.valueOf(1234L)
        and:
        visitHistory.setRelatedProcedures(List.of(procedureId))
        and:
        Procedure procedure = new Procedure()
        procedure.setId(new IdType(mapper.createIdURI()))
        and:
        fhirResource.addFhirResourceToDeferredMapper(procedure, ProcedureHistory.builder().objectId(procedureId).build())

        when:
        mapper.buildObservationResource(encounter, fhirResource, visitHistory)

        then:
        encounter.getDiagnosisFirstRep() != null
        encounter.getDiagnosisFirstRep().getCondition().getResource() == procedure
    }

    @Unroll
    def "#desc -> identifier"() {
        given:

        when:
        mapper.buildObservationResource(encounter, fhirResource, localVisitHistory)
        Identifier identifier = encounter.getIdentifierFirstRep()

        then:
        identifier != null
        identifier.getValue() == AppUtils.jsonEscape(List.of(relatedIds))
        identifier.getType().getText() == expectedType

        where:
        desc                      | relatedIds                 | expectedType                                             | localVisitHistory
        "relatedServiceProviders" | BigInteger.valueOf(1234L)  | Constants.RELATED_SERVICE_FACILITY_PROVIDER_INSTANCE_IDS | VisitHistory.builder().relatedServiceProviders(List.of(relatedIds)).build()
        "relatedMedications"      | BigInteger.valueOf(3333L)  | Constants.RELATED_MEDICATION_INSTANCE_IDS                | VisitHistory.builder().relatedMedications(List.of(relatedIds)).build()
        "relatedDevices"          | BigInteger.valueOf(2222L)  | Constants.RELATED_DEVICE_INSTANCE_IDS                    | VisitHistory.builder().relatedDevices(List.of(relatedIds)).build()
        "relatedImmunizations"    | BigInteger.valueOf(57864L) | Constants.RELATED_IMMUNIZATION_INSTANCE_IDS              | VisitHistory.builder().relatedImmunizations(List.of(relatedIds)).build()
        "relatedObservations"     | BigInteger.valueOf(4756L)  | Constants.RELATED_OBSERVATION_INSTANCE_IDS               | VisitHistory.builder().relatedObservations(List.of(relatedIds)).build()
        "relatedCareTeams"        | BigInteger.valueOf(38483L) | Constants.RELATED_CARE_TEAM_INSTANCE_IDS                 | VisitHistory.builder().relatedCareTeam(List.of(relatedIds)).build()
    }

    def "sourceClaimIds -> identifier"() {
        given:
        visitHistory.setSourceClaimIds(List.of("ClaimIds"))

        when:
        mapper.buildObservationResource(encounter, fhirResource, visitHistory)
        Identifier identifier = encounter.getIdentifierFirstRep()

        then:
        identifier != null
        identifier.getValue() == AppUtils.jsonEscape(visitHistory.getSourceClaimIds())
        identifier.getType().getText() == Constants.SOURCE_CLAIM_IDS
    }

    def "add to bundle"() {
        given:
        encounter.setId(new IdType(mapper.createIdURI()))

        when:
        mapper.buildObservationResource(encounter, fhirResource, visitHistory)
        Encounter foundEncounter = getFirstBundleResource(fhirResource.getBundle(), Encounter.class)

        then:
        foundEncounter != null
        foundEncounter == encounter
    }
}
