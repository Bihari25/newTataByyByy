package com.uhg.ihr.centrihealth.senzing.model


import spock.lang.Specification

class SenzingPropertiesSpec extends Specification {

    SenzingProperties sampleSenzingProperties = new SenzingProperties(senzingUrl: "http://example.com", senzingUrlSecond: "http://second.com", subject: "tTest", duration: 3000, secretKey: "AbcXyv838!", secretKeySecond: "secabc", roles: ["dev", "qa"], audience: "test-aud")

    def "SenzingProperties: getters/setter"() {
        when:
        SenzingProperties senzingProperties = sampleSenzingProperties
        then:
        senzingProperties.getSenzingUrl() == "http://example.com"
        senzingProperties.getRoles().size() == 2
        senzingProperties.getRoles()[0] == "dev"
        senzingProperties.getDuration() == 3000
        senzingProperties.getSubject() == "tTest"
        senzingProperties.getSecretKey() == "AbcXyv838!"
        senzingProperties.getAudience() == "test-aud"
    }

    def "SenzingProperties: toString"() {
        when:
        SenzingProperties senzingProperties = sampleSenzingProperties
        def result = senzingProperties.toString()
        then:

        result.contains("SenzingProperties(senzingUrl=http://example.com, senzingUrlSecond=http://second.com, subject=tTest, duration=3000, secretKey=AbcXyv838!, secretKeySecond=secabc, roles=[dev, qa], audience=test-aud, secondEnabled=false)")

    }
}