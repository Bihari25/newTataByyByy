package com.uhg.ihr.centrihealth.api.service

import com.google.common.collect.ImmutableList
import com.uhg.ihr.centrihealth.api.client.B50SenzingClient
import com.uhg.ihr.centrihealth.api.exception.IhrNotFoundException
import com.uhg.ihr.centrihealth.api.util.AppUtils
import com.uhg.ihr.centrihealth.senzing.model.SenzingLookup
import com.uhg.ihr.centrihealth.senzing.model.SenzingRequest
import com.uhg.ihr.centrihealth.util.JsonUtils
import com.uhg.ihr.centrihealth.util.TestData
import io.micronaut.http.HttpRequest
import io.reactivex.Maybe
import spock.lang.Specification
import spock.lang.Unroll

@Unroll
class SenzingServiceSpec extends Specification {

    def req = HttpRequest.POST("/read", TestData.sampleIhrApiRequest())
            .header("Accept", "application/vnd.uhg.v2+json")
            .header("optum-cid-ext", "Testing")

    def "filterIhrId finds the correct act chid"() {
        given:
        SenzingService senzingService = new SenzingService()
        B50SenzingClient mockSenzingClient = Mock(B50SenzingClient)
        senzingService.b50SenzingClient = mockSenzingClient
        def sampleRequestJson = AppUtils.readResource("senzing-request.json")
        def senzingRequest = JsonUtils.deserializeJson(SenzingRequest.class, sampleRequestJson)
        def sampleResponseJson = AppUtils.readResource("senzing-response-api.json")
        def senzingResponse = JsonUtils.deserializeJson(LinkedHashMap.class, sampleResponseJson)
        def expectedApiResponse = Maybe.just(senzingResponse)

        when:
        String result = senzingService.b50filterIhrId(req, TestData.TOKEN, senzingRequest, "corrId").blockingGet()

        then:
        1 * mockSenzingClient.fetchEntities(_, _, _, _) >> { expectedApiResponse }
        result == "ACT33716240"
    }

    def "searchIhrId scenario: #desc"() {
        given:
        def apiResponse = AppUtils.readResource(input)
        def senzingResponse = JsonUtils.deserializeJson(LinkedHashMap.class, apiResponse)

        when:
        def result = SenzingService.searchIhrId(req, senzingResponse, "corrId")

        then:
        result == expectedIhr

        where:
        desc                   | input                                     || expectedIhr
        "Single Search Result" | "senzing-response-api.json"               || "ACT33716240"
        "Multi Search Result"  | "senzing-multi-results-response-api.json" || "ACT33716240"
    }

    def "searchIhrId more: #desc"() {

        given:
        def apiResponse = AppUtils.readResource(input)
        def senzingResponse = JsonUtils.deserializeJson(LinkedHashMap.class, apiResponse)

        when:
        def result
        def exception = false

        try {
            result = SenzingService.searchIhrId(req, senzingResponse, "corrId")
        } catch (Exception e) {
            result = e.getMessage()
            exception = true
        }

        then:
        exception == expectException
        result.contains(resultString)

        // 2 records, both match level 2 = fail
        // 2 records, both match level 1 = fail
        // 2 records, first 1, second 2 = succeed
        // 3 records, first 2, second 3, third 1 = succeed
        where:
        desc                    | input                       || expectException | resultString
        "2 level 2s"            | "senzing-match-2-2.json"    || true            | "Unable to find"
        "2 level 1s"            | "senzing-match-1-1-r2.json" || true            | "multiple ihr identifiers: [ACT1, ACT2]"
        "1 level 1 multi first" | "senzing-match-1-2.json"    || false           | "ACT1"
        "1 level 1 multi last"  | "senzing-match-1-2-3.json"  || false           | "ACT3"
    }


    def "searchIhrId for empty/null data in senzing response: #desc"() {
        given:
        def apiResponse = AppUtils.readResource(input)
        def sampleRequestJson = AppUtils.readResource("senzing-request.json")
        def senzingRequest = JsonUtils.deserializeJson(SenzingRequest.class, sampleRequestJson)
        senzingRequest.memberId = "113456789"
        def senzingResponse = JsonUtils.deserializeJson(LinkedHashMap.class, apiResponse)

        def expectedMessage = dataFlag ? "Unable to find ihr identifier (IhrId) because senzing response data is empty" :
                "Unable to find ihr identifier (IhrId) because senzing response search results are empty"

        when:
        SenzingService.searchIhrId(req, senzingResponse, "corrId")

        then:
        IhrNotFoundException ihrEx = thrown()
        ihrEx.message.contains(expectedMessage)

        where:
        desc                                       | input                              | dataFlag
        "Empty data in senzing response"           | "senzing-empty-data.json"          | true
        "Null data in senzing response "           | "senzing-null-data.json"           | true
        "Empty search results in senzing response" | "senzing-empty-searchresults.json" | false
        "Null search results in senzing response"  | "senzing-null-searchresults.json"  | false
    }


    def "Test owner chid scenarios #desc"() {

        given:
        def apiResponse = AppUtils.readResource(input)
        def senzingResponse = JsonUtils.deserializeJson(LinkedHashMap.class, apiResponse)
        def dataJson = (Map<String, Object>) senzingResponse.get(SenzingLookup.DATA)
        List<Map<String, Object>> searchResults = (List<Map<String, Object>>) dataJson.get(SenzingLookup.RESULTS)
        Map<String, Object> resultData = searchResults.get(resultPosition - 1)

        when:
        def result = SenzingService.getOwnerChid(resultData)

        then:
        result == expectedIhr

        where:
        desc             | input                       | resultPosition || expectedIhr
        "first of 1-1"   | "senzing-match-1-1-r2.json" | 1              || "ACT1"
        "first of 1-1"   | "senzing-match-1-1-r2.json" | 2              || "ACT2"
        "first of 1-2"   | "senzing-match-1-2.json"    | 1              || "ACT1"
        "second of 1-2"  | "senzing-match-1-2.json"    | 2              || "ACT2"
        "first of 2-2"   | "senzing-match-2-2.json"    | 1              || "ACT1"
        "second of 2-2"  | "senzing-match-2-2.json"    | 2              || "ACT2"
        "first of 3"     | "senzing-match-3-1-r2.json" | 1              || "232ACTI109731247973826560"
        "second of 3"    | "senzing-match-3-1-r2.json" | 2              || "886ACTI175222969147838465"
        "first of 1-2-3" | "senzing-match-1-2-3.json"  | 1              || "ACT1"
        "third of 1-2-3" | "senzing-match-1-2-3.json"  | 3              || "ACT3"
    }

    def "getLogDataFromResult scenario: #desc"() {
        given:
        def apiResponse = AppUtils.readResource(input)
        def senzingResponse = JsonUtils.deserializeJson(LinkedHashMap.class, apiResponse)
        def dataJson = (LinkedHashMap<String, Object>) senzingResponse.get(SenzingLookup.DATA)
        def searchResults = (List<LinkedHashMap<String, Object>>) dataJson.get(SenzingLookup.RESULTS)

        when:
        def result = SenzingService.getLogDataFromResult(searchResults[0])

        then:
        result == expectedIhr

        where:
        desc                   | input                                     || expectedIhr
        "Single Search Result" | "senzing-response-api.json"               || "ACT33716240:1:+NAME+DOB+GENDER+MEDICARE_BENF_ID"
        "Multi Search Result"  | "senzing-multi-results-response-api.json" || "ACT33716240:1:+NAME+DOB+GENDER+MEDICARE_BENF_ID"
        "error"                | "senzing-log-error.json"                  || "unknown"
    }

    def "it finds lines of business: #desc"() {
        when:
        def result = SenzingService.fetchLobsFromSenzingResponse(["records": records], chid)
        then:
        result == expectedLobs

        where:
        desc               | chid    | records                                                                                                                                || expectedLobs
        "empty1"           | "A1234" | null                                                                                                                                   || []
        "empty2"           | "A1234" | []                                                                                                                                     || []
        "empty3"           | "A1234" | [["originalSourceData": null]]                                                                                                         || []
        "No LOBs"          | "A1234" | [["originalSourceData": ["Global_Actor_ID": "A1234"]]]                                                                                 || []
        "one LOB"          | "A1234" | [["originalSourceData": ["Global_Actor_ID": "A1234", "LOB": "MR"]]]                                                                    || ["MR"]
        "no matching chid" | "A1234" | [["originalSourceData": ["Global_Actor_ID": "A123", "LOB": "MR"]]]                                                                     || []
        "two LOBs"         | "A1234" | [["originalSourceData": ["Global_Actor_ID": "A1234", "LOB": "MR"]], ["originalSourceData": ["Global_Actor_ID": "A1234", "LOB": "CS"]]] || ["MR", "CS"]

    }

    def "getIdFromList #desc"() {
        when:
        def result
        def exception = false

        try {
            result = SenzingService.getIdFromList(input)
        }
        catch (Exception e) {
            result = e.getMessage()
            exception = true
        }

        then:
        exception == expectException
        result.contains(resultString)

        where:
        desc       | input                                 || expectException | resultString
        "null"     | null                                  || true            | "Unable to find"
        "empty"    | new ArrayList()                       || true            | "Unable to find"
        "single"   | ImmutableList.of("hello-id")          || false           | "hello-id"
        "multiple" | ImmutableList.of("hello-id", "uh-oh") || true            | "[hello-id, uh-oh]"
    }

    def "lob lookup from list: #desc"() {
        when:
        def result = SenzingService.getLobFromList(input)

        then:
        result == resultString

        where:
        desc       | input                                  || resultString
        "empty"    | new ArrayList()                        || ""
        "single"   | ImmutableList.of("ELIG_MR")            || "ELIG_MR"
        "multiple" | ImmutableList.of("ELIG_MR", "ELIG_CS") || "ELIG_MR"
    }

}