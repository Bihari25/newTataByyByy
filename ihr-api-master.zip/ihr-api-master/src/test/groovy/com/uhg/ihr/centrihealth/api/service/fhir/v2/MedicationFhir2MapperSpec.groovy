package com.uhg.ihr.centrihealth.api.service.fhir.v2

import com.uhg.ihr.centrihealth.api.constant.GlobalConstants
import com.uhg.ihr.centrihealth.api.constant.GlobalUrlConstant
import com.uhg.ihr.centrihealth.api.model.FhirResource
import com.uhg.ihr.centrihealth.api.model.dataclass.HealthMedication
import com.uhg.ihr.centrihealth.api.model.dataclass.IhrTerm
import com.uhg.ihr.centrihealth.api.model.dataclass.Note
import com.uhg.ihr.centrihealth.api.service.fhir.BaseFhirSpecification
import com.uhg.ihr.centrihealth.util.TestData
import org.hl7.fhir.instance.model.api.IBaseResource
import org.hl7.fhir.r4.model.*
import spock.lang.Shared
import spock.lang.Unroll

@Unroll
class MedicationFhir2MapperSpec extends BaseFhirSpecification {

    @Shared
    static MedicationFhir2Mapper mapper = MedicationFhir2Mapper.of()

    @Unroll
    def "Test Medication  fhir conversion #Medication"() {

        when:
        // map to fhir resource
        HealthMedication healthMedication = HealthMedication.builder()
                .medication(IhrTerm.builder()
                        .ihrLaymanTerm(laymanTerm)
                        .ihrTerm(ihrTerm)
                        .sourceVocabulary(sVocabulary)
                        .sourceVocabularyCode(svCode)
                        .fdbCode(fdbCode)
                        .fdbCodeType(fdbCodeType)
                        .rxNormCode(rxNormCode)
                        .mediSpanCode(mediSpanCode).build())
                .sensitivityClasses(sensitivityClasses as List<String>)
                .dosageForm(IhrTerm.builder()
                        .ihrLaymanTerm(laymanTerm)
                        .ihrTerm(ihrTerm)
                        .sourceVocabulary(sVocabulary)
                        .sourceVocabularyCode(svCode)
                        .build())
                .build()

        Medication medication = getFhirResourceMedication(healthMedication)
        def med_code = medication.getCode().getCodingFirstRep()
        def rxNormCode_val = null
        def mediSpanCode_val = null
        if (rxNormCode != null) {
            rxNormCode_val = getCodingFromList(medication.getCode().getCoding(), GlobalUrlConstant.RX_NORM_CODE_URL).getCode()
        }
        if (mediSpanCode != null) {
            mediSpanCode_val = getCodingFromList(medication.getCode().getCoding(), GlobalUrlConstant.MEDI_SPAN_CODE_URL).getCode()

        }

        then:

        medication.getCode().getText() == checkNull(laymanTerm)
        med_code.getDisplay() == checkNull(ihrTerm)
        med_code.getSystem() == checkNull(sVocabulary)
        med_code.getCode() == checkNull(svCode)
        rxNormCode_val == checkNull(rxNormCode)
        mediSpanCode_val == checkNull(mediSpanCode)

        where:

        desc           | laymanTerm | sVocabulary              | svCode    | ihrTerm    | icd10cmCode | fdbCode   | fdbCodeType   | rxNormCode   | mediSpanCode   | sensitivityClasses
        "Happy Path"   | "oralText" | "http://snomed.info/sct" | "7898989" | "oralCode" | "J66"       | "fdbCode" | "fdbCodeType" | "rxNormCode" | "mediSpanCode" | ["Mental Behaviorial Disorder"]
        "All are null" | null       | null                     | null      | null       | null        | null      | null          | null         | null           | null

    }

    @Unroll
    def "Test Medication Knowledge  fhir conversion #medicationKnowledge"() {

        when:
        // map to fhir resource
        HealthMedication healthMedication = HealthMedication.builder()
                .genericDrugName(genericDrugName)
                .productType(productType)
                .classType(classType)
                .drugClass(drugClass as List<String>)
                .deaSchedule(deaSchedule)
                .build()

        MedicationKnowledge medicationKnowledge = getFhirResourceMedicationKnowledge(healthMedication)
        def synonym_value = null
        if (genericDrugName != null) {
            synonym_value = medicationKnowledge.getSynonym().get(0).getValue()
        }
        def productType_value = medicationKnowledge.getProductTypeFirstRep().getText()
        def classType_value = medicationKnowledge.getMedicineClassificationFirstRep().getType().getText()
        def drugClass_value = medicationKnowledge.getMedicineClassificationFirstRep().getClassificationFirstRep().getText()
        def deaSchedule_value = medicationKnowledge.getRegulatoryFirstRep().getScheduleFirstRep().getSchedule().getText()

        then:

        synonym_value == checkNull(genericDrugName)
        productType_value == checkNull(productType)
        classType_value == checkNull(classType)
        drugClass_value == checkIsListNull(drugClass)
        deaSchedule_value == checkNull(deaSchedule)

        where:

        desc           | genericDrugName                 | productType        | classType   | drugClass     | deaSchedule
        "Happy Path  " | "Fluoxetine Oral Capsule 20 mg" | "productTypeValue" | "classType" | ["drugClass"] | "deaScheduleValue"
        "all are null" | null                            | null               | null        | null          | null
    }

    @Unroll
    def "Test Medication Request  fhir conversion #MedicationRequest"() {

        when:
        // map to fhir resource
        HealthMedication healthMedication = HealthMedication.builder()
                .requestStatus(requestStatus)
                .requestIntent(requestIntent)
                .orderDate(orderDate)
                .refillAuthorizedNumber(refillAuthorizedNumber)
                .build()

        def status_value = null
        def intent_value = null
        def orderDate_value = null
        def refill_value = null

        MedicationRequest medicationRequest = getFhirResourceMedicationRequest(healthMedication)

        if (requestStatus != null) {
            status_value = medicationRequest.getStatus().toString().toLowerCase()
        }
        if (requestIntent != null) {
            intent_value = medicationRequest.getIntent().toString().toLowerCase()
        }
        if (orderDate != null) {
            orderDate_value = medicationRequest.getAuthoredOnElement().getValueAsString()
        }
        if (refillAuthorizedNumber != null) {
            refill_value = medicationRequest.getDispenseRequest().getNumberOfRepeatsAllowed()
        }

        then:

        status_value == checkNull(requestStatus)
        intent_value == checkNull(requestIntent)
        orderDate_value == checkNull(orderDate)
        refill_value == refillAuthorizedNumber

        where:

        desc               | requestStatus | requestIntent | orderDate              | refillAuthorizedNumber
        "Happy Path  "     | "active"      | "proposal"    | "2018-03-28T00:00:00Z" | 12
        "all null value  " | null          | null          | null                   | null

    }

    @Unroll
    def "Test MedicationDispense Request  fhir conversion #MedicationDispense"() {

        when:
        // map to fhir resource
        HealthMedication healthMedication = HealthMedication.builder()
                .dispenseStatus(dispenseStatus)
                .daysSupply(daySupply)
                .refillCount(refillCount)
                .dispensedQuantity(dispanceQuantity)
                .dispensedQuantityUnit(IhrTerm.builder()
                        .ihrTerm(ihrTerm)
                        .build())
                .prescriptionId(prescriptionId)
                .build()

        MedicationDispense medicationDispense = getFhirResourceMedicationDispense(healthMedication)

        def status_value = (dispenseStatus == null) ? null : medicationDispense.getStatus().toString().toLowerCase()
        def daySupply_value = (daySupply == null) ? null : medicationDispense.getDaysSupply().getValue().toInteger()
        def ihrTerm_value = (ihrTerm == null) ? null : medicationDispense.getQuantity().getUnit()
        def prescription_value = (prescriptionId == null) ? null : getValueOfIdentifier(medicationDispense.getIdentifier(),
                GlobalConstants.PRESCRIPTION_ID)
        def refill_count_value = (refillCount == null) ? null :
                getExtensionFromList(medicationDispense.getExtension(), GlobalUrlConstant.REFILL_COUNT)

        def refill_count_value_int = (refill_count_value == null) ? null : refill_count_value
                .castToDecimal(refill_count_value.getValue()).getValueAsInteger()

        then:

        status_value == checkNull(dispenseStatus)
        daySupply_value == daySupply
        ihrTerm_value == checkNull(ihrTerm)
        prescription_value == checkIsListNull(prescriptionId)
        refill_count_value_int == refillCount

        where:

        desc              | dispenseStatus | daySupply | refillCount | dispanceQuantity | ihrTerm  | prescriptionId
        "Happy Path  "    | "preparation"  | 3         | 5.0         | 2.0              | "Tablet" | ["1234"]
        "all null value " | null           | null      | null        | null             | null     | null

    }

    @Unroll
    def "Test MedicationStatement all identifiers fhir conversion #test_name"() {

        when:
        // map to fhir resource
        HealthMedication healthMedication = HealthMedication.builder()

                .relatedServiceProviders(relatedServiceProviders)
                .relatedDevices(relatedDevices)
                .relatedCareTeam(relatedCareTeamIds)
                .reviewerIhrActorIdentifier(reviewerIhrActorIdentifier)
                .relatedConditions(conditionInstanceID)
                .referenceIds(referenceIDs)
                .build()

        MedicationStatement med_stmt = getFhirResourceMedicationStatement(healthMedication)

        def reviewerIhrActorIdentifier_value = getValueOfIdentifier(med_stmt.getIdentifier(), GlobalConstants.REVIEWER_IHR_ACTOR_IDENTIFIRE)
        def referenceIDs_value = getValueOfIdentifier(med_stmt.getIdentifier(), GlobalConstants.REFERENCE_IDS)
        def relatedDevices_value = getValueOfIdentifier(med_stmt.getIdentifier(), GlobalConstants.RELATED_DEVICE_INSTANCE_IDS)
        def conditionInstanceID_value = getValueOfIdentifier(med_stmt.getIdentifier(), GlobalConstants.RELATED_CONDITION_IDS)
        def relatedServiceProviders_value = getValueOfIdentifier(med_stmt.getIdentifier(), GlobalConstants.RELATED_SERVICE_FACILITY_PROVIDER_INSTANCE_IDS)
        def relatedCareTeamIds_value = getValueOfIdentifier(med_stmt.getIdentifier(), GlobalConstants.RELATED_CARE_TEAM_INSTANCE_IDS)


        then:

        reviewerIhrActorIdentifier_value == checkNull(reviewerIhrActorIdentifier)
        referenceIDs_value == checkIsListNull(referenceIDs)
        relatedDevices_value == checkIsListNull(relatedDevices)
        conditionInstanceID_value == checkIsListNull(conditionInstanceID)
        relatedServiceProviders_value == checkIsListNull(relatedServiceProviders)
        relatedCareTeamIds_value == checkIsListNull(relatedCareTeamIds)

        where:
        test_name            | reviewerIhrActorIdentifier | referenceIDs                       | relatedDevices | conditionInstanceID | relatedServiceProviders | relatedCareTeamIds
        "happy  Path check " | "ACT123456"                | ["2009-01-02T03:04:44Z-Rally-1sE"] | [123456, 789]  | [66464, 83737]      | [1222, 4324]            | [21107567769, 21107567769, 211075677]
        "null check "        | null                       | null                               | null           | null                | null                    | null
    }

    @Unroll
    def "Test Medicationfhir2 note"() {
        when:
        Note note = buildSampleNote(text, time, author, noteType)

        HealthMedication healthMedication = HealthMedication.builder()
                .note(Arrays.asList(note))
                .build();
        MedicationStatement med_stmt = getFhirResourceMedicationStatement(healthMedication)
        def res_note = med_stmt.getNote().get(0)
        Extension noteTypeValue = getExtensionFromList(res_note.getExtension(), GlobalUrlConstant.IHR_NOTE_TYPE_URL)
        def authorReference = res_note.getAuthorReference().getResource()
        def authorReferenceIdentifier = getAuthorReferenceIdentifier(authorReference, GlobalConstants.EMPLOYEE_ID)
        then:
        noteTypeValue.getValue().toString() == noteType
        res_note.getText() == text
        res_note.getTimeElement().getValueAsString() == time
        res_note.getAuthorReference().getResource().fhirType() == resourceType.toString()
        authorReferenceIdentifier.getValue() == author
        where:
        noteType          | text                         | time                   | author         || resourceType
        "Clinical Note"   | "Patient reports."           | "2019-03-28T00:00:00Z" | "ACT000123456" || ResourceType.Practitioner
        "PatientNote"     | "This medication is working" | "2018-03-28T00:00:00Z" | "ACT000000111" || ResourceType.Patient
        "Clinical Note"   | "Patient reports medication" | "2020-07-28T11:11:11Z" | "ACT098763"    || ResourceType.Practitioner
        "PatientTypeNote" | "This medication"            | "2012-03-28T00:00:00Z" | "ACT0003456"   || ResourceType.Patient
        ""                | "This medication"            | "2018-03-28T00:00:00Z" | "ACT0003456"   || ResourceType.Patient
        null              | "This medication report "    | "2014-03-28T00:00:00Z" | "ACT0003456"   || ResourceType.Patient

    }

    @Unroll
    def "Test Medication Statement .dosage.timing.route #desc"() {
        when:
        HealthMedication healthMedication = HealthMedication.builder()
                .dosageQuantity(dosageQuantity)
                .doseFrequency(IhrTerm.builder()
                        .ihrTerm(ihrTerm)
                        .ihrLaymanTerm(ihrLaymanTerm)
                        .sourceVocabulary(sourceVocabulary)
                        .sourceVocabularyCode(sourceVocabularyCode)
                        .build())
                .dosageRoute(IhrTerm.builder()
                        .ihrTerm(ihrTerm)
                        .ihrLaymanTerm(ihrLaymanTerm)
                        .sourceVocabulary(sourceVocabulary)
                        .sourceVocabularyCode(sourceVocabularyCode)
                        .build())
                .doseQuantityUnit(IhrTerm.builder()
                        .ihrTerm(ihrTerm)
                        .build())
                .build();

        MedicationStatement med_stmt = getFhirResourceMedicationStatement(healthMedication)
        Dosage dosage = med_stmt.getDosageFirstRep()

        Dosage.DosageDoseAndRateComponent doseAndRate = dosage.getDoseAndRateFirstRep()

        def dosageQuantity_value = (dosageQuantity == null) ? null : doseAndRate.getDoseQuantity().getValue()
        def dosageQuantity_unit = doseAndRate.getDoseQuantity().getUnit()

        def doseFre_ihrLterm = dosage.getTiming().getCode().getText()

        def doseFre_ihrterm = dosage.getTiming().getCode().getCodingFirstRep().getDisplay()
        def doseFre_srcV = dosage.getTiming().getCode().getCodingFirstRep().getSystem()
        def doseFre_srcVC = dosage.getTiming().getCode().getCodingFirstRep().getCode()

        CodeableConcept dose_route = dosage.getRoute()
        def dosageRoute_lemanTerm = dose_route.getText()
        def dosageRoute_ihrTerm = dose_route.getCodingFirstRep().getDisplay()
        def dosageRoute_src = dose_route.getCodingFirstRep().getSystem()
        def dosageRoute_srcCode = dose_route.getCodingFirstRep().getCode()

        then:

        dosageQuantity_value == dosageQuantity
        dosageQuantity_unit == ihrTerm
        doseFre_ihrLterm == ihrLaymanTerm
        doseFre_ihrterm == ihrTerm
        doseFre_srcV == sourceVocabulary
        doseFre_srcVC == sourceVocabularyCode
        dosageRoute_lemanTerm == ihrLaymanTerm
        dosageRoute_ihrTerm == ihrTerm
        dosageRoute_src == sourceVocabulary
        dosageRoute_srcCode == sourceVocabularyCode

        where:

        desc         | dosageQuantity | ihrTerm   | ihrLaymanTerm   | sourceVocabulary   | sourceVocabularyCode
        "happy path" | 1.0            | "ihrTerm" | "ihrLaymanTerm" | "sourceVocabulary" | "sourceVocabularyCode"
        "All nulls"  | null           | null      | null            | null               | null
    }

    @Unroll
    def "Medication Statement test cases for informationSourceObject  #desc"() {
        when:
        // build v2 resource
        HealthMedication healthMedication = HealthMedication.builder()
                .informerObject(IhrTerm.builder()
                        .ihrTerm("ihrTerm")
                        .ihrLaymanTerm("laymanTerm")
                        .sourceVocabulary("sourceVocabulary")
                        .sourceVocabularyCode(medSourceVocabularyCode)
                        .build()).build()

        MedicationStatement med_stmt = getFhirResourceMedicationStatement(healthMedication)

        def informationSource = getInformationObjectTextFromResource(med_stmt)

        then:

        informationSource == informationSourceExpectedValue

        where:
        desc                                                | medSourceVocabularyCode || informationSourceExpectedValue
        "happy path PractitionerRole-Prescriber"            | "Prescriber"            || "Prescriber"
        "happy path PractitionerRole-Facility Staff"        | "Facility Staff"        || "Facility Staff"
        "happy path PractitionerRole-Medical Director"      | "Medical Director"      || "Medical Director"
        "happy path PractitionerRole-Myself"                | "Myself"                || "Myself"
        "happy path PractitionerRole-Pharmacist"            | "Pharmacist"            || "Pharmacist"
        "happy path PractitionerRole-Primary Care Provider" | "Primary Care Provider" || "Primary Care Provider"
        "happy path RelatedPerson-Caregiver"                | "Caregiver"             || "Caregiver"
        "happy path RelatedPerson-Family Member"            | "Family Member"         || "Family Member"
        "happy path RelatedPerson-Guardian"                 | "Guardian"              || "Guardian"
        "happy path RelatedPerson-Health Care Proxy"        | "Health Care Proxy"     || "Health Care Proxy"
        "happy path RelatedPerson-Other"                    | "Other"                 || "Other"
        "happy path RelatedPerson-Power of Attorney"        | "Power of Attorney"     || "Power of Attorney"
        "invalid medSourceVocabularyCode information text"  | "Unknown Value"         || null
        "invalid medSourceVocabularyCode information text"  | null                    || null

    }


    def "MedicationStatement  Extension of List<String> #desc"() {
        when:
        HealthMedication healthMedication = HealthMedication.builder()

                .presenceStateTerm(presenceStateTerm)
                .icueSeqId(icueSeqId)
                .icueLastUpdateDate(dateValue)
                .holdDate(dateValue)
                .restartedDate(dateValue)
                .takenAsOrdered(takenAsOrdered)
                .adherenceStopdate(dateValue)
                .expectedFillDate(dateValue)
                .medicationReviewLastActivityDate(dateValue)
                .medicationStartDate(dateValue)
                .clinicallyRelevantDate(dateValue)
                .build()

        MedicationStatement medicationStatement = getFhirResourceMedicationStatement(healthMedication)


        def presenceStateTerm_value = getValueOfExtension(medicationStatement.getExtension(), GlobalUrlConstant.PRESENCESTATE_URL)
        def icuSeqId_value = getValueOfExtension(medicationStatement.getExtension(), GlobalUrlConstant.ICUE_SEQ_ID_URL)

        def last_icue_date = getDateAsStringFromExtension(medicationStatement.getExtensionByUrl(GlobalUrlConstant.ICUE_LAST_UPDATE_DATE_URL))
        def hold_date_value = getDateAsStringFromExtension(medicationStatement.getExtensionByUrl(GlobalUrlConstant.HOLD_DATE_URL))
        def restart_date_value = getDateAsStringFromExtension(medicationStatement.getExtensionByUrl(GlobalUrlConstant.RESTART_DATE_URL))
        def adherance_stop_data_value = getDateAsStringFromExtension(medicationStatement.getExtensionByUrl(GlobalUrlConstant.ADHERENCE_STOP_DATE_URL))
        def expected_fill_date_value = getDateAsStringFromExtension(medicationStatement.getExtensionByUrl(GlobalUrlConstant.EXPECTED_FILL_DATE_URL))//2021-01-02

        then:

        presenceStateTerm_value == checkNull(presenceStateTerm)
        icuSeqId_value == checkNull(icueSeqId)
        last_icue_date == checkNull(dateValue)
        hold_date_value == checkNull(dateValue)
        restart_date_value == checkNull(dateValue)
        adherance_stop_data_value == checkNull(dateValue)
        expected_fill_date_value == checkNull(expectedDateValue)


        where:

        desc          | presenceStateTerm   | icueSeqId   | dateValue              | takenAsOrdered || expectedDateValue
        "Happy path"  | "presenceStateTerm" | "icueSeqId" | "2021-01-02T03:04:44Z" | true           || "2021-01-02"
        "null  check" | null                | null        | null                   | null           || null

    }

    @Unroll
    def "#ihrTerm medicationStatus -> statement.status"() {
        given:
        FhirResource fhirResource = buildFhirResource()
        and:
        IhrTerm medStatusTerm = buildBasicIhrTerm(ihrTerm, "TheLayman", "SomeVocab", "VocabCode")
        and:
        HealthMedication medication = HealthMedication.builder()
                .medicationStatus(medStatusTerm)
                .build()

        when:
        MedicationStatement statement = mapper.buildMedicatioStatement(fhirResource, medication)

        then:
        statement != null
        statement.getStatus() != null
        statement.getStatus() == expectedHL7

        where:
        ihrTerm    | expectedHL7
        "Active"   | MedicationStatement.MedicationStatementStatus.ACTIVE
        "sToPped"  | MedicationStatement.MedicationStatementStatus.STOPPED
        "Resolved" | MedicationStatement.MedicationStatementStatus.UNKNOWN
    }


    static getFhirResourceMedicationStatement(HealthMedication healthMedication) {
        //build v2 resource
        FhirResource fhirResource = FhirResource.builder()
                .bundle(new Bundle().setType(Bundle.BundleType.SEARCHSET))
                .patient(TestData.defaultPatient())
                .practitioner(TestData.practitionerMap())
                .practitionerRole(TestData.practitionerRoleMap())
                .relatedPerson(TestData.relatedPersonMap()).build()
        mapper.map(fhirResource, healthMedication)
        Bundle bundle = fhirResource.getBundle()

        MedicationStatement medicationStatement = getFirstBundleResource(bundle, ResourceType.MedicationStatement)
        return medicationStatement;
    }

    static getFhirResourceMedicationDispense(HealthMedication healthMedication) {
        //build v2 resource
        FhirResource fhirResource = FhirResource.builder()
                .bundle(new Bundle().setType(Bundle.BundleType.SEARCHSET))
                .patient(TestData.defaultPatient())
                .practitioner(TestData.practitionerMap())
                .practitionerRole(TestData.practitionerRoleMap())
                .relatedPerson(TestData.relatedPersonMap()).build()
        mapper.map(fhirResource, healthMedication)
        Bundle bundle = fhirResource.getBundle()

        MedicationDispense medicationDispense = getFirstBundleResource(bundle, ResourceType.MedicationDispense)
        return medicationDispense;
    }

    static getFhirResourceMedicationKnowledge(HealthMedication healthMedication) {
        //build v2 resource
        FhirResource fhirResource = FhirResource.builder()
                .bundle(new Bundle().setType(Bundle.BundleType.SEARCHSET))
                .patient(TestData.defaultPatient())
                .practitioner(TestData.practitionerMap())
                .practitionerRole(TestData.practitionerRoleMap())
                .relatedPerson(TestData.relatedPersonMap()).build()
        mapper.map(fhirResource, healthMedication)
        Bundle bundle = fhirResource.getBundle()

        MedicationKnowledge medicationKnowledge = getFirstBundleResource(bundle, ResourceType.MedicationKnowledge)
        return medicationKnowledge;
    }


    static getFhirResourceMedicationRequest(HealthMedication healthMedication) {
        //build v2 resource
        FhirResource fhirResource = FhirResource.builder()
                .bundle(new Bundle().setType(Bundle.BundleType.SEARCHSET))
                .patient(TestData.defaultPatient())
                .practitioner(TestData.practitionerMap())
                .practitionerRole(TestData.practitionerRoleMap())
                .relatedPerson(TestData.relatedPersonMap()).build()
        mapper.map(fhirResource, healthMedication)
        Bundle bundle = fhirResource.getBundle()

        MedicationRequest medicationRequest = getFirstBundleResource(bundle, ResourceType.MedicationRequest)
        return medicationRequest;
    }


    static getFhirResourceMedication(HealthMedication healthMedication) {
        //build v2 resource
        FhirResource fhirResource = FhirResource.builder()
                .bundle(new Bundle().setType(Bundle.BundleType.SEARCHSET))
                .patient(TestData.defaultPatient())
                .practitioner(TestData.practitionerMap())
                .practitionerRole(TestData.practitionerRoleMap())
                .relatedPerson(TestData.relatedPersonMap()).build()
        mapper.map(fhirResource, healthMedication)
        Bundle bundle = fhirResource.getBundle()

        Medication medication = getFirstBundleResource(bundle, ResourceType.Medication)
        return medication;
    }

    static getInformationObjectTextFromResource(MedicationStatement ms) {
        IBaseResource resource = ((Reference) ms.getInformationSource()).getResource()
        if (resource instanceof RelatedPerson) {
            RelatedPerson relatedPerson = (RelatedPerson) resource
            return relatedPerson.getRelationship().get(0).getText()
        } else if (resource instanceof PractitionerRole) {
            PractitionerRole practitionerRole = (PractitionerRole) resource
            return practitionerRole.getCode().get(0).getText()
        }
        return null
    }

}
