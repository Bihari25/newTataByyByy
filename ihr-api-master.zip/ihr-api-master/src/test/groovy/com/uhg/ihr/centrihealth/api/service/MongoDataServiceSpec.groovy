package com.uhg.ihr.centrihealth.api.service

import com.fasterxml.jackson.databind.JsonNode
import com.fasterxml.jackson.databind.ObjectMapper
import com.fasterxml.jackson.databind.node.ArrayNode
import com.fasterxml.jackson.databind.node.ObjectNode
import com.google.common.base.Strings
import com.google.common.collect.ImmutableSet
import com.mongodb.reactivestreams.client.MongoClient
import com.uhg.ihr.centrihealth.api.exception.IhrNotFoundException
import com.uhg.ihr.centrihealth.api.filter.ClinicallyRelevantDateFilter
import com.uhg.ihr.centrihealth.api.filter.DataFilter
import com.uhg.ihr.centrihealth.api.filter.PresenceStateFilter
import com.uhg.ihr.centrihealth.api.model.Payload
import com.uhg.ihr.centrihealth.api.model.RecordType
import com.uhg.ihr.centrihealth.api.model.dataclass.DataClass
import com.uhg.ihr.centrihealth.api.service.fhir.BaseFhirSpecification
import com.uhg.ihr.centrihealth.api.util.AppUtils
import com.uhg.ihr.centrihealth.util.TestData
import io.micronaut.http.HttpRequest
import io.micronaut.http.MediaType
import org.bson.Document
import spock.lang.Ignore
import spock.lang.Shared
import spock.lang.Unroll

import java.time.Duration
import java.time.Instant
import java.util.stream.Collectors

@Unroll
class MongoDataServiceSpec extends BaseFhirSpecification {

    //TODO Need to revisit test integration test with observable.
    /*
     @Shared
     @AutoCleanup
     private EmbeddedServer embeddedServer = ApplicationContext.run(EmbeddedServer)

     @Shared
     private MongoClient mongoClient = embeddedServer.applicationContext.getBean(MongoClient)
     MongoClient mockMongoClient = Mock(MongoClient)
     MongoDataService mongoDataService = new MongoDataService(mockMongoClient)
     */

    MongoDataService mongoDataService = new MongoDataService(_ as MongoClient, _ as MongoClient, "","", false)

    @Shared
    def expectedApiCollection = "external_api_payload_v2"
    @Shared
    def expectedB50ApiCollection = "transcribed_api_payload_v2"
    @Shared
    ObjectMapper MAPPER = new ObjectMapper()

    def "filterPayload = happy path scenarios: #desc"() {
        given:
        def ihrApiRequest = TestData.sampleIhrApiRequest()
        String dataClassesPayload = AppUtils.readResource("document-payload.json")
        Document sampleDoc = buildSampleDocument(dataClassesPayload)
        Set<RecordType> requestedDataClasses = dataClasses
        ihrApiRequest.dataClasses = requestedDataClasses
        def dataFilters = [] as List<DataFilter>

        when:
        JsonNode node = MongoDataService.filterPayload(sampleDoc, requestedDataClasses, dataFilters)

        then:
        outputSize == node.get('dataClasses').size()

        where:
        desc                         | dataClasses                                                                           || outputSize
        "Version-2 Service Provider" | [RecordType.SERVICE_FACILITY_PROVIDER]                                                || 1
        "Version-2 Health Cases"     | [RecordType.HEALTH_CONDITION, RecordType.HEALTH_MEDICATION, RecordType.HEALTH_DEVICE] || 3
    }

    def "filterPayload for failure path"() {
        given:
        def ihrApiRequest = TestData.sampleIhrApiRequest()
        ihrApiRequest.dataClasses = [RecordType.SERVICE_FACILITY_PROVIDER] as Set<RecordType>
        def dataFilters = [] as List<DataFilter>

        when:
        MongoDataService.filterPayload(null, ihrApiRequest.getDataClasses(), dataFilters)

        then:
        IhrNotFoundException ihrEx = thrown()
        ihrEx.message.contains("user was matched but no corresponding data was found")
    }

    def "filteredResponse without data filters scenarios: #desc"() {
        given:
        Payload samplePayload = TestData.buildSamplePayload("payload-sample.json")
        Set<RecordType> requestedDataClasses = dataClasses

        when:
        JsonNode node = MongoDataService.filteredResponse(samplePayload.payloadJson, requestedDataClasses, null)

        then:
        outputSize == node.get('dataClasses').size()

        where:
        desc                          | dataClasses                                                                           || outputSize
        "Empty data classes"          | []                                                                                    || 0
        "1 requested data classes"    | [RecordType.SERVICE_FACILITY_PROVIDER]                                                || 1
        "3 requested data classes"    | [RecordType.IMMUNIZATIONS, RecordType.CARE_TEAM, RecordType.ADVERSE_REACTION]         || 3
        "Health related data classes" | [RecordType.HEALTH_CONDITION, RecordType.HEALTH_MEDICATION, RecordType.HEALTH_DEVICE] || 3
    }

    def "filteredResponse with data filters scenarios: #desc"() {
        given:
        Payload samplePayload = TestData.buildSamplePayload("datafilter-payload.json")
        Set<RecordType> requestedDataClasses = dataClasses
        def dataFilters = [new ClinicallyRelevantDateFilter('2018-12-25', '2019-12-25'),
                           new PresenceStateFilter("Present")] as List<DataFilter>

        when:
        JsonNode node = MongoDataService.filteredResponse(samplePayload.payloadJson, requestedDataClasses, dataFilters)

        then:
        node.get('dataClasses').size() == outputSize
        node.get('dataClasses').get('medications').size() == 2
        node.get('dataClasses').get('conditions').size() == 7

        where:
        desc                          | dataClasses                                                                           || outputSize
        "Health related data classes" | [RecordType.HEALTH_CONDITION, RecordType.HEALTH_MEDICATION, RecordType.HEALTH_DEVICE] || 3
    }

    @Ignore
    def "filtering speed test"() {
        given:
        Payload samplePayload = TestData.buildSamplePayload("payload-sample.json")
        Set<String> requestedDataClasses = MongoDataService.REQUEST_DC_TO_JSON_DC.keySet()

        when:
        Instant start = Instant.now()

        for (int i = 0; i < 1000000; i++) {
            def result = MongoDataService.filterDataClasses(samplePayload.payloadJson, requestedDataClasses)
            MongoDataService.addEmptyClassesBack(requestedDataClasses, result)
        }

        System.out.println(Duration.between(start, Instant.now()).toMillis())

        then:
        true
    }

    def "filterDataClasses scenarios: #desc"() {
        given:
        Payload samplePayload = TestData.buildSamplePayload("payload-sample.json")
        Set<String> requestedDataClasses = dataClasses.size() > 0 ? dataClasses.collect({
            it.toLowerCase()
        }) : new HashSet<>() as Set<String>

        Set<String> emptyDataClasses = emptyClasses.size() > 0 ? emptyClasses.collect({
            it.toLowerCase()
        }) : new HashSet<>() as Set<String>

        when:
        def result = MongoDataService.filterDataClasses(samplePayload.payloadJson, requestedDataClasses)

        then:
        outputSize == result.size()
        // ensure the requested data classes are present
        for (String dc : requestedDataClasses) {
            assert result.keySet().contains(MongoDataService.REQUEST_DC_TO_JSON_DC.get(dc))
        }
        // ensure the empty data classes are there and are empty
        // ensure the other data classes are there and have something
        for (String dc : requestedDataClasses) {
            JsonNode node = result.get(MongoDataService.REQUEST_DC_TO_JSON_DC.get(dc))
            assert node != null

            if (emptyDataClasses.contains(dc)) {
                assert node.size() == 0
            } else {
                assert node.size() > 0
            }
        }

        where:
        desc                          | dataClasses                                                                                                            || outputSize | emptyClasses
        "Empty data classes"          | []                                                                                                                     || 0          | []
        "1 requested data classes"    | [RecordType.SERVICE_FACILITY_PROVIDER.toString()]                                                                      || 1          | [RecordType.SERVICE_FACILITY_PROVIDER.toString()]
        "3 requested data classes"    | [RecordType.IMMUNIZATIONS.toString(), RecordType.CARE_TEAM.toString(), RecordType.ADVERSE_REACTION.toString()]         || 3          | [RecordType.ADVERSE_REACTION.toString()]
        "Health related data classes" | [RecordType.HEALTH_CONDITION.toString(), RecordType.HEALTH_MEDICATION.toString(), RecordType.HEALTH_DEVICE.toString()] || 3          | [RecordType.HEALTH_DEVICE.toString()]
    }

    def "filterDataClasses handles errors gracefully: #desc"() {
        given:
        Payload samplePayload = TestData.buildSamplePayload("payload-sample-extra-dc.json")
        Set<String> requestedDataClasses = dataClasses != null && dataClasses.size() > 0 ? dataClasses.collect({
            it.toLowerCase()
        }) : new HashSet<>() as Set<String>

        when:
        def result = MongoDataService.filterDataClasses(samplePayload.payloadJson, requestedDataClasses)

        then:
        null != samplePayload.payloadJson.get("dataClasses").get("extra")     // bad extra dataclass exists
        null != samplePayload.payloadJson.get("dataClasses").get("extra_more")
        null == samplePayload.payloadJson.get("dataClasses").get("extra2")
        outputSize == result.size()

        // ensure the empty data classes are there and are empty
        // ensure the other data classes are there and have something
        for (String dc : requestedDataClasses) {
            JsonNode node = result.get(MongoDataService.REQUEST_DC_TO_JSON_DC.get(dc))
            assert node == null
        }

        where:
        desc                    | dataClasses            || outputSize
        "Empty data classes"    | []                     || 0
        "dc that doesnt exist"  | ["idontexist"]         || 0
        "dcs that doesnt exist" | ["idontexist", "nope"] || 0
        "null"                  | null                   || 0
    }

    def "documentToJsonNode converts correctly"() {
        given:
        String dataClassesPayload = AppUtils.readResource("document-payload.json")
        Document sampleDoc = buildSampleDocument(dataClassesPayload)

        when:
        def result = MongoDataService.documentToJsonNode(sampleDoc)

        then:
        result.get("_id").toString().contains("iHRID223334444")
        result.get("dataClasses").size() == 12
    }

    def "the requestToJsonMap has 12 dataclasses"() {
        given:
        Map<String, String> requestToJson = MongoDataService.REQUEST_DC_TO_JSON_DC

        when:
        def countPayloadDcs = requestToJson.keySet().size()
        def countReqDcs = requestToJson.values().stream().collect(Collectors.toSet()).size()

        then:
        countPayloadDcs == 12
        countReqDcs == 12
    }

    def "it adds filtered classes back #desc"() {
        given:
        // these are the input data classes that the request wants
        Set<String> dcStrings = new HashSet<>()
        if (inputDc == "default") { // 12 DCs for full request from, eg a Rally client
            dcStrings = ImmutableSet.<String> builder()
                    .add("adverse_reaction").add("care_team")
                    .add("care_giver").add("health_condition")
                    .add("health_device").add("health_medication")
                    .add("health_observations").add("health_status")
                    .add("immunizations").add("procedure_history")
                    .add("service_facility_provider").add("visit_history")
                    .build()
        } else {
            if (!Strings.isNullOrEmpty(inputDc)) {
                dcStrings.addAll(inputDc.split(","))
            }
        }

        // this is the payload that came from mongo and has been filtered
        ArrayNode array = MAPPER.createArrayNode()
        Map<String, JsonNode> payloadMap = new LinkedHashMap<>()

        if (!Strings.isNullOrEmpty(payloadDc)) {
            Arrays.asList(payloadDc.split(",")).stream()
                    .forEach({ pl -> payloadMap.put(pl, array) })
        }

        // these are the classes that will have been filtered out and need to be added back
        List<String> empty = Collections.emptyList()
        if (!Strings.isNullOrEmpty(emptyClasses)) {
            empty = Arrays.asList(emptyClasses.split(","))
        }

        expect:
        assert postSize == payloadMap.size() + empty.size() //this is to keep our test case valid
        assert payloadMap.size() == preSize
        empty.forEach({ cl ->
            assert null == payloadMap.get(cl)
        })

        when:
        MongoDataService.addEmptyClassesBack(dcStrings, payloadMap)

        then:
        assert payloadMap.size() == postSize
        empty.forEach({ cl ->
            assert null != payloadMap.get(cl)
        })

        //ensure no EXTRA/invalid data classes are added
        payloadMap.keySet().forEach({ cl ->
            assert MongoDataService.VALID_RESPONSE_CLASSES.contains(cl)
        })

        where:
        desc                | inputDc                                 | payloadDc              || preSize | postSize | emptyClasses
        "empty payload"     | "default"                               | ""                     || 0       | 12       | "adverseReactions,careGivers,careTeam,conditions,healthDevices,healthObservations," +
                "healthStatuses,immunizations,procedureHistory,medications,serviceProviders,visitHistory"
        "payload missing 1" | "default"                               | "adverseReactions,careGivers,careTeam,conditions,healthDevices,healthObservations" +
                ",healthStatuses,immunizations,procedureHistory,serviceProviders,visitHistory" || 11      | 12       | "medications"
        "payload missing 3" | "default"                               | "adverseReactions,careGivers,healthDevices,healthObservations," +
                "healthStatuses,immunizations,procedureHistory,serviceProviders,visitHistory"  || 9       | 12       | "careTeam,conditions,medications"
        "empty input"       | ""                                      | "adverseReactions,careGivers,healthDevices,healthObservations," +
                "healthStatuses,immunizations,procedureHistory,serviceProviders,visitHistory"  || 9       | 9        | ""
        "null input"        | null                                    | "adverseReactions,careGivers,healthDevices,healthObservations," +
                "healthStatuses,immunizations,procedureHistory,serviceProviders,visitHistory"  || 9       | 9        | ""
        //test with a 1.0 DC string - SHOULD NOT GET ADDED
        "1.0 dc"            | "active_adverse_reaction,health_status" | ""                     || 0       | 1        | "healthStatuses"
        "1.0 dc2"           | "active_adverse_reaction,health_status" | "healthStatuses"       || 1       | 1        | ""
    }

    /**
     * Method to build sample mongodb document.
     */
    private static Document buildSampleDocument(String payloadJson) {
        Document payload = Document.parse(payloadJson)

        Document document = new Document()
        document.put("_id", "iHRID223334444")
        document.put("dataClasses", payload)
        document
    }

    def "Test getlanguageCollection"() {

        when:
        def languageCollection = MongoDataService.getLanguageCollection(reqLanguage, originalCollection)

        then:
        languageCollection == result

        where:
        reqLanguage     | originalCollection                || result
        "EN"            | "external_api_ii"                 || "external_api_ii"
        "EN"            | "external_api_payload_v2"         || "external_api_payload_v2"
        "EN"            | "ihr_gold_transcribed_collection" || "ihr_gold_transcribed_collection"
        "ES"            | "external_api_payload_sec_v2"     || "external_api_payload_sec_v2_es"
        "ES"            | "ihr_gold_transcribed_collection" || "ihr_gold_transcribed_collection_es"
    }

    def "Test buildBasicIhr #desc"() {

        when:
        HttpRequest req = baseRequest().accept(MediaType.of("application/vnd.nah.v1+json"))
        def buildBasicIhr = MongoDataService.buildBasicIhr(req, new Throwable())

        def dataClassCount = 0
        def adverseReactions = false
        def careGivers = false
        def careTeam = false
        def conditions = false
        def healthDevices = false
        def healthObservations = false
        def healthStatuses = false
        def immunizations = false
        def medications = false
        def procedureHistory = false
        def serviceProviders = false
        def visitHistory = false

        then:
        for (def dataClass : buildBasicIhr) {
            if (dataClass.getProperties().key == "adverseReactions") {
                dataClassCount ++
                adverseReactions = dataClass.getProperties().value.getProperties().empty
            } else if (dataClass.getProperties().key == "careGivers") {
                dataClassCount ++
                careGivers = dataClass.getProperties().value.getProperties().empty
            } else if (dataClass.getProperties().key == "careTeam") {
                dataClassCount ++
                careTeam = dataClass.getProperties().value.getProperties().empty
            } else if (dataClass.getProperties().key == "conditions") {
                dataClassCount ++
                conditions = dataClass.getProperties().value.getProperties().empty
            } else if (dataClass.getProperties().key == "healthDevices") {
                dataClassCount ++
                healthDevices = dataClass.getProperties().value.getProperties().empty
            } else if (dataClass.getProperties().key == "healthObservations") {
                dataClassCount ++
                healthObservations = dataClass.getProperties().value.getProperties().empty
            } else if (dataClass.getProperties().key == "healthStatuses") {
                dataClassCount ++
                healthStatuses = dataClass.getProperties().value.getProperties().empty
            } else if (dataClass.getProperties().key == "immunizations") {
                dataClassCount ++
                immunizations = dataClass.getProperties().value.getProperties().empty
            } else if (dataClass.getProperties().key == "medications") {
                dataClassCount ++
                medications = dataClass.getProperties().value.getProperties().empty
            } else if (dataClass.getProperties().key == "procedureHistory") {
                dataClassCount ++
                procedureHistory = dataClass.getProperties().value.getProperties().empty
            } else if (dataClass.getProperties().key == "serviceProviders") {
                dataClassCount ++
                serviceProviders = dataClass.getProperties().value.getProperties().empty
            } else if (dataClass.getProperties().key == "visitHistory") {
                dataClassCount ++
                visitHistory = dataClass.getProperties().value.getProperties().empty
            }
        }

        adverseReactions == isEmpty
        careGivers == isEmpty
        careTeam == isEmpty
        conditions == isEmpty
        healthDevices == isEmpty
        healthObservations == isEmpty
        healthStatuses == isEmpty
        immunizations == isEmpty
        medications == isEmpty
        procedureHistory == isEmpty
        serviceProviders == isEmpty
        visitHistory == isEmpty
        dataClassCount == dataClassCountValue - 1    // -1 for "class"
        RecordType.values().size() == 20

        where:
        desc            || isEmpty          || dataClassCountValue
        "Empty Check"   || true             || DataClass.builder().build().getProperties().size()
    }

    def "medication reviewedBy #desc"() {
        given:
        ObjectMapper mapper = getMAPPER()
        ObjectNode document = mapper.createObjectNode()
        ArrayNode healthMedArray = mapper.createArrayNode()
        ObjectNode healthMedication = mapper.createObjectNode()
        healthMedArray.add(healthMedication)
        document.set("medications", healthMedArray)
        if (reviewedByExists) {
            ObjectNode reviewedByObj = mapper.createObjectNode()
            healthMedication.set("reviewedBy", reviewedByObj)
            if (employeeIdExists) {
//                reviewedByObj.put("name","some name")
                reviewedByObj.put("employeeId","empId1234")
            }
        } else {
            healthMedication.put("reviewedBy", "empId1234")
        }

        when:
        def finalObj = mapper.treeToValue(document, DataClass.class)

        then:
        finalObj != null

        where:
        desc                 || reviewedByExists || employeeIdExists
        "exists"             || true             || true
        "missing employeeId" || true             || false
        "missing"            || false            || false
    }



    //FIXME: needs integration test cases
    //IF senzing match AND mongo no data test cases
    //basic - log entries
    // mongoStatus: failure
    // mongoReason: <reason>
    // returnBasicIhr: true

    //real - log entries
    // mongoStatus: success
    // mongoReason: - NOT PRESENT IN LOGS -
    // returnBasicIhr: - NOT PRESENT IN LOGS -

    // want to avoid situation where mongo has an issue, we return ~100% empty ihrs and mongo success
    // true mongo issue - log entries (might need one for primary, one for secondary)
    // mongoStatus: failure
    // mongoReason: <reason>
    // returnBasicIhr: - NOT PRESENT IN LOGS -

}
