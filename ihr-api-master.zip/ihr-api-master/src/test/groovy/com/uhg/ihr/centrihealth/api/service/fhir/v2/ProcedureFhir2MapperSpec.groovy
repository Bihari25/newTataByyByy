package com.uhg.ihr.centrihealth.api.service.fhir.v2

import com.uhg.ihr.centrihealth.api.constant.GlobalConstants
import com.uhg.ihr.centrihealth.api.constant.GlobalUrlConstant
import com.uhg.ihr.centrihealth.api.model.FhirResource
import com.uhg.ihr.centrihealth.api.model.dataclass.HealthObservations
import com.uhg.ihr.centrihealth.api.model.dataclass.IhrTerm
import com.uhg.ihr.centrihealth.api.model.dataclass.ProcedureHistory
import com.uhg.ihr.centrihealth.api.service.fhir.BaseFhirSpecification
import com.uhg.ihr.centrihealth.util.TestData
import org.hl7.fhir.r4.model.Bundle
import org.hl7.fhir.r4.model.Observation
import org.hl7.fhir.r4.model.Procedure
import org.hl7.fhir.r4.model.ResourceType
import spock.lang.Shared
import spock.lang.Unroll

class ProcedureFhir2MapperSpec extends BaseFhirSpecification {

    @Shared
    static ProcedureFhir2Mapper mapper = ProcedureFhir2Mapper.of()

    @Unroll
    def "Immunization all identifiers fhir conversion"() {

        when:
        // map to fhir resource
        ProcedureHistory procedure = ProcedureHistory.builder()
                .recordKey(recordKey)
                .objectId(objectId as BigInteger)
                .referenceIds(referenceIDs as List<String>)
                .relatedConditions(conditionInstanceID as List<BigInteger>)
                .relatedCareTeam(relatedCareTeamIds as List<BigInteger>)
                .sourceClaimIds(sourceClaimIDs as List<String>)
                .build()

        Procedure procedure_obj = getFhirResourceProcedure(procedure)

        def res_objectId = getValueOfIdentifier(procedure_obj.getIdentifier(), GlobalConstants.OBJECT_ID)
        def res_recordKey = getValueOfIdentifier(procedure_obj.getIdentifier(), GlobalConstants.RECORD_KEY)
        def res_conditionInstanceId = getValueOfIdentifier(procedure_obj.getIdentifier(), GlobalConstants.RELATED_CONDITION_INSTANCE_IDS)
        def res_careTeamInstanceId = getValueOfIdentifier(procedure_obj.getIdentifier(), GlobalConstants.RELATED_CARE_TEAM_INSTANCE_IDS)
        def res_sourceClaimIds = getValueOfIdentifier(procedure_obj.getIdentifier(), GlobalConstants.SOURCE_CLAIM_IDS)
        def res_referenceId = getValueOfIdentifier(procedure_obj.getIdentifier(), GlobalConstants.REFERENCE_IDS)


        then:

        res_objectId == checkNull(objectId)
        res_referenceId == checkIsListNull(referenceIDs)
        res_recordKey == checkNull(recordKey)
        res_careTeamInstanceId == checkIsListNull(relatedCareTeamIds)
        res_sourceClaimIds == checkIsListNull(sourceClaimIDs)
        res_conditionInstanceId == checkIsListNull(conditionInstanceID)


        where:
        test_name            | objectId | recordKey                                                      | referenceIDs                       | concept       | conditionInstanceID | sourceClaimIDs      | relatedCareTeamIds
        "happy  Path check " | 9        | "o*}Dci^Vj2DS9mggDvEzepfVVqzx{ZEsiUvmmn<+gbH%HEjP.xoJ0P2h8Y(h" | ["2009-01-02T03:04:44Z-Rally-1sE"] | [123456, 789] | [66464, 83737]      | ["ABCDE", "TESTID"] | [2110756776942227460, 2110756776942227460, 2110756776942227460]
        "null check "        | null     | null                                                           | null                               | null          | null                | null                | null
    }


    @Unroll
    def "Test ProcedureHistory sensitivity classes #desc"() {
        when:

        ProcedureHistory procedure = ProcedureHistory.builder()
                .sensitivityClasses(sensitivityClasses)
                .build();
        Procedure procedure_obj = getFhirResourceProcedure(procedure)

        def res_sensitivityClasses_system = (!procedure_obj.getMeta().getSecurity().isEmpty())
                ? procedure_obj.getMeta().getSecurity().get(0).getSystem() : null
        def res_sensitivityClasses_code = (!procedure_obj.getMeta().getSecurity().isEmpty())
                ? procedure_obj.getMeta().getSecurity().get(0).getCode() : null

        then:

        res_sensitivityClasses_system == sensitivityClasses_system
        res_sensitivityClasses_code == sensitivityClasses_code

        where:
        test_name    | ihrTerm                | sensitivityClasses              | sensitivityClasses_system             | sensitivityClasses_code
        "happy path" | "Antineoplastic Agent" | ["Mental Behaviorial Disorder"] | GlobalUrlConstant.SECURITY_LABELS_URL | GlobalConstants.SECURITY_LABELS_CODE
        "All nulls"  | null                   | null                            | null                                  | null
    }


    @Unroll
    def "Test  procedure Concept #desc"() {
        when:
        // map to fhir resource
        ProcedureHistory procedure = ProcedureHistory.builder()
                .healthEvent(IhrTerm.builder()
                        .ihrLaymanTerm(laymanTerm)
                        .ihrTerm(ihrTerm)
                        .sourceVocabulary(sVocabulary)
                        .sourceVocabularyCode(svCode)
                        .cpthcpcsCode(svCode)
                        .medicalDomain(sVocabulary)
                        .build()).build()

        Procedure procedure_obj = getFhirResourceProcedure(procedure)
        def res_CodeableConcept = procedure_obj.getCode()
        def res_Coding = res_CodeableConcept.getCodingFirstRep()
        def cateory_text = procedure_obj.getCategory().getText()


        then:

        res_CodeableConcept.getText() == checkNull(laymanTerm)
        res_Coding.getDisplay() == checkNull(ihrTerm)
        res_Coding.getSystem() == checkNull(sVocabulary)
        res_Coding.getCode() == checkNull(svCode)
        cateory_text == checkNull(sVocabulary)


        where:

        test_name      | laymanTerm | sVocabulary              | svCode    | ihrTerm    | icd10cmCode
        "Happy Path"   | "oralText" | "http://snomed.info/sct" | "7898989" | "oralCode" | "J66"
        "All are null" | null       | null                     | null      | null       | null

    }

    @Unroll
    def "Test  procedure Status #desc"() {
        when:
        // map to fhir resource
        ProcedureHistory procedure = ProcedureHistory.builder()
                .healthEventStatus(IhrTerm.builder()
                        .ihrTerm(ihrTerm)
                        .build()).build()

        Procedure procedure_obj = getFhirResourceProcedure(procedure)
        def status = null
        def status_res = null
        status = procedure_obj.getStatus()
        if (null != status) {
            status_res = status.toCode()
        }
        then:

        status_res == checkNull(ihrTerm)

        where:

        test_name      | ihrTerm
        "Happy Path"   | "preparation"
        "All are null" | null

    }

    @Unroll
    def "Test  extension and all dateTime attributes"() {
        when:
        // map to fhir resource
        ProcedureHistory procedure = ProcedureHistory.builder()
                .presenceStateTerm(presenceStateTerm)
                .healthEventDate(healthEventDate)
                .clinicallyRelevantDate(clinicallyRelevantDate)
                .lastUpdateDate(lastUpdateDate)
                .build()
        Procedure procedure_obj = getFhirResourceProcedure(procedure)

        def res_presenceStateTerm = getValueOfExtension(procedure_obj.getExtension(), GlobalUrlConstant.PRESENCESTATE_URL)
        def res_clinicallyRelevantDate = getDateAsStringFromExtension(procedure_obj.getExtensionByUrl(GlobalUrlConstant.CLINICAL_RELEVANT_DATE_URL))
        def res_healthEventDate = getDateTimeValue(procedure_obj.getPerformedDateTimeType())
        def res_lastUpdateDate = getLastUpdateDate(procedure_obj.getMeta())

        then:

        res_presenceStateTerm == checkNull(presenceStateTerm)
        res_healthEventDate == checkNull(healthEventDate)
        res_clinicallyRelevantDate == checkNull(clinicallyRelevantDate)
        res_lastUpdateDate == checkNull(lastUpdateDate)

        where:

        test_name    | presenceStateTerm | healthEventDate        | clinicallyRelevantDate | lastUpdateDate
        "Happy path" | "Past Occurrence" | "2021-03-02T03:04:44Z" | "2021-01-02T03:04:44Z" | "2021-02-27T03:04:44Z"
        "All Null"   | null              | null                   | null                   | null
    }

    @Unroll
    def "#ihrTerm medicationStatus -> statement.status"() {
        given:
        FhirResource fhirResource = buildFhirResource()
        and:
        IhrTerm healthStatusTerm = buildBasicIhrTerm(ihrTerm, "TheLayman", "SomeVocab", "VocabCode")
        and:
        ProcedureHistory history = ProcedureHistory.builder()
                .healthEventStatus(healthStatusTerm)
                .build()

        when:
        Procedure procedure = mapper.buildProcedure(fhirResource, history)

        then:
        procedure != null
        procedure.getStatus() != null
        procedure.getStatus() == expectedHL7

        where:
        ihrTerm       | expectedHL7
        "Completed"      | Procedure.ProcedureStatus.COMPLETED
        "sToPped"     | Procedure.ProcedureStatus.STOPPED
        "In Progress" | Procedure.ProcedureStatus.INPROGRESS
        "BadStatus"   | Procedure.ProcedureStatus.UNKNOWN
    }

    def "relatedObservations -> Observation.partOf"() {
        given:
        FhirResource fhirResource = buildFhirResource()
        and:
        BigInteger objectId = BigInteger.valueOf(12345)
        Observation observation = new Observation()
        HealthObservations healthObservation = HealthObservations.builder().objectId(objectId).build()
        and:
        ProcedureHistory history = ProcedureHistory.builder()
        .relatedObservations(List.of(objectId))
        .build()

        when:
        fhirResource.addFhirResourceToDeferredMapper(observation, healthObservation)
        Procedure procedure = mapper.buildProcedure(fhirResource, history)

        then:
        observation.getPartOfFirstRep() != null
        (observation.getPartOfFirstRep().getResource() as Procedure).getId() == procedure.getId()
    }

    static getFhirResourceProcedure(ProcedureHistory procedureHistory) {
        //build v2 resource
        FhirResource fhirResource = FhirResource.builder()
                .bundle(new Bundle().setType(Bundle.BundleType.SEARCHSET))
                .patient(TestData.defaultPatient())
                .practitioner(TestData.practitionerMap())
                .practitionerRole(TestData.practitionerRoleMap())
                .relatedPerson(TestData.relatedPersonMap()).build()
        mapper.map(fhirResource, procedureHistory)
        Bundle bundle = fhirResource.getBundle()

        Procedure procedure = getFirstBundleResource(bundle, ResourceType.Procedure)
        return procedure;
    }
}