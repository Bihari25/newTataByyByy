package com.uhg.ihr.centrihealth.api.service.fhir

import com.uhg.ihr.centrihealth.api.model.FhirResource
import com.uhg.ihr.centrihealth.api.model.dataclass.AdverseReaction
import com.uhg.ihr.centrihealth.api.model.dataclass.Constants
import com.uhg.ihr.centrihealth.api.model.dataclass.IhrTerm
import com.uhg.ihr.centrihealth.api.model.dataclass.Reaction
import com.uhg.ihr.centrihealth.util.TestData
import org.hl7.fhir.r4.model.*
import spock.lang.Shared
import spock.lang.Unroll

@Unroll
class AllergyIntoleranceFhirMapperSpec extends BaseFhirSpecification {

    @Shared
    static AllergyIntoleranceFhirMapper mapper = AllergyIntoleranceFhirMapper.of()

    @Unroll
    def "AllergyIntolerance all identifiers fhir conversion #test_name"() {

        when:
        // map to fhir resource
        AdverseReaction adverseReaction = AdverseReaction.builder()
                .recordKey(recordKey)
                .recorderId(recorderId)
                .objectId(objectId)
                .referenceIds(referenceIDs as List<String>)
                .build()
        AllergyIntolerance ai = getFhirResourceAllergyIntolerance(adverseReaction)

        def res_objectId = getValueOfIdentifier(ai.getIdentifier(), Constants.INSTANCE_ID)
        def res_recordKey = getValueOfIdentifier(ai.getIdentifier(), Constants.RECORD_KEY)
        def res_referenceId = getValueOfIdentifier(ai.getIdentifier(), Constants.REFERENCE_IDS)
        def res_recorderId = (ai.getRecorder().getResource() == null) ? null : (ai.getRecorder().getResource() as Practitioner).getIdentifier().get(0).getValue()

        then:

        res_objectId == checkNull(objectId)
        res_referenceId == checkIsListNull(referenceIDs)
        res_recordKey == checkNull(recordKey)
        res_recorderId == recorderId

        where:
        test_name            | objectId | recorderId | recordKey                                                      | referenceIDs
        "happy  Path check " | 9        | "981232"   | "o*}Dci^Vj2DS9mggDvEzepfVVqzx{ZEsiUvmmn<+gbH%HEjP.xoJ0P2h8Y(h" | ["2009-01-02T03:04:44Z-Rally-1sE"]
        "null check "        | null     | null       | null                                                           | null
    }

    @Unroll
    def "Test all AllergyIntolerance asserter object #desc"() {
        when:
        // map to fhir resource
        AdverseReaction adverseReaction = AdverseReaction.builder().asserterObject(
                IhrTerm.builder()
                        .ihrLaymanTerm(laymanTerm)
                        .ihrTerm(ihrTerm)
                        .sourceVocabulary(sVocabulary)
                        .sourceVocabularyCode(svCode)
                        .build()).build()
        AllergyIntolerance ai = getFhirResourceAllergyIntolerance(adverseReaction)

        def res_Asserter = ai.getAsserter()
        then:
        getAsserterText(ai.getAsserter(), desc) == svCode
        where:

        desc                 | laymanTerm              | sVocabulary              | svCode                  | ihrTerm
        "RelatedPerson-1"    | "Care giver"            | "http://snomed.info/sct" | "Caregiver"             | "Caregiver"
        "RelatedPerson-2"    | "Family Member"         | "http://snomed.info/sct" | "Family Member"         | "Family Member"
        "RelatedPerson-3"    | "Health Care Proxy"     | "http://snomed.info/sct" | "Health Care Proxy"     | "Health Care Proxy"
        "RelatedPerson-4"    | "Power of Attorney"     | "http://snomed.info/sct" | "Power of Attorney"     | "Power of Attorney"
        "RelatedPerson-5"    | "Other"                 | "http://snomed.info/sct" | "Other"                 | "Other"

        "PractitionerRole-1" | "Facility Staff"        | "http://snomed.info/sct" | "Facility Staff"        | "Facility Staff"
        "PractitionerRole-2" | "Medical Director"      | "http://snomed.info/sct" | "Medical Director"      | "Medical Director"
        "PractitionerRole-3" | "Myself"                | "http://snomed.info/sct" | "Myself"                | "Myself"
        "PractitionerRole-4" | "Pharmacist"            | "http://snomed.info/sct" | "Pharmacist"            | "Pharmacist"
        "PractitionerRole-5" | "Prescriber"            | "http://snomed.info/sct" | "Prescriber"            | "Prescriber"
        "PractitionerRole-6" | "Primary Care Provider" | "http://snomed.info/sct" | "Primary Care Provider" | "Primary Care Provider"
        "Patient"            | "Patient"               | "http://snomed.info/sct" | "cinderella"            | "Patient"

        "All are null"       | null                    | null                     | null                    | null
    }

    @Unroll
    def "Test AdverseReaction type #desc"() {
        when:
        // map to fhir resource
        AdverseReaction adverseReaction = AdverseReaction.builder().adversereactiontype(
                IhrTerm.builder()
                        .ihrLaymanTerm(laymanTerm)
                        .ihrTerm(ihrTerm)
                        .sourceVocabulary(sVocabulary)
                        .sourceVocabularyCode(svCode)
                        .icd10cmCode(icd10cmCode)
                        .build()).build();
        AllergyIntolerance ai = getFhirResourceAllergyIntolerance(adverseReaction);
        def res_CodeableConcept = ai.getCode();
        def res_Coding = res_CodeableConcept.getCodingFirstRep();
        then:
        res_CodeableConcept.getText() == laymanTerm
        res_Coding.getDisplay() == ihrTerm
        res_Coding.getSystem() == sVocabulary
        if (desc.contains("icd"))
            res_Coding.getCode() == svCode
        else
            res_Coding.getCode() == icd10cmCode

        where:

        desc                            | laymanTerm                                    | sVocabulary        | svCode       | ihrTerm                                                        | icd10cmCode
        "happy path"                    | "Adverse reaction to immunosuppressive drugs" | "ICD-10 Diagnosis" | "T45.1X5AA2" | "Adverse Effect of Antineoplastic and Immunosuppressive Drugs" | ""
        "happy path-non blank icd code" | "Adverse reaction to immunosuppressive drugs" | "ICD-10 Diagnosis" | "T45.1X5A"   | "Adverse Effect of Antineoplastic and Immunosuppressive Drugs" | "T376.1X5A"
        "All nulls"                     | null                                          | null               | null         | null                                                           | null
    }

    @Unroll
    def "Test allergens type #desc"() {
        when:

        // map to fhir resource
        def iTerm = IhrTerm.builder()
                .ihrLaymanTerm(laymanTerm)
                .ihrTerm(ihrTerm)
                .sourceVocabulary(sVocabulary)
                .sourceVocabularyCode(svCode)
                .build();
        List<IhrTerm> ihrTerms = new ArrayList<>();
        ihrTerms.add(iTerm);

        AdverseReaction adverseReaction = AdverseReaction.builder().allergens(ihrTerms).build();
        AllergyIntolerance ai = getFhirResourceAllergyIntolerance(adverseReaction);

        AllergyIntolerance.AllergyIntoleranceReactionComponent  componentList   =ai.getReactionFirstRep();
        def substance = componentList.getSubstance()
        def res_Coding = substance.getCodingFirstRep()

        then:

        substance.getText() == laymanTerm
        res_Coding.getDisplay() == ihrTerm
        res_Coding.getSystem() == sVocabulary
        res_Coding.getCode() == svCode

        where:

        desc         | laymanTerm                | sVocabulary                      | svCode      | ihrTerm
        "happy path" | "Chemotherapy Medication" | "SNOMEDCT Substance Foreign Key" | "419933005" | "Antineoplastic Agent"
        "All nulls"  | null                      | null                             | null        | null
    }

    @Unroll
    def "Test reactions type #desc"() {
        when:
        // map to fhir resource
        def reaction = new Reaction();
        reaction.setConcept(IhrTerm.builder()
                .ihrLaymanTerm(laymanTerm)
                .ihrTerm(ihrTerm)
                .sourceVocabulary(sVocabulary)
                .sourceVocabularyCode(svCode)
                .build());
        List<Reaction> reactions = new ArrayList<>();
        reactions.add(reaction);
        reaction.setSeverity(IhrTerm.builder()
                .sourceVocabularyCode(severitySVocabulary)
                .build())


        AdverseReaction adverseReaction = AdverseReaction.builder().reactionsFHIR(reactions).build();
        AllergyIntolerance ai = getFhirResourceAllergyIntolerance(adverseReaction);
        def res_reaction = ai.getReaction().get(0).getManifestation().get(0);
        def res_reaction_coding = res_reaction.getCodingFirstRep();
        def res_severity = ai.getReaction().get(0).getSeverity();
        then:
        res_reaction.getText() == laymanTerm
        res_reaction_coding.getDisplay() == ihrTerm
        res_reaction_coding.getSystem() == sVocabulary
        res_reaction_coding.getCode() == svCode
        if (desc.contains("nulls"))
            res_severity == severitySVocabulary;
        else
            res_severity.toString().toLowerCase() == severitySVocabulary;

        where:

        desc         | laymanTerm                | sVocabulary                             | svCode     | ihrTerm                | severitySVocabulary
        "happy path" | "Chemotherapy Medication" | "SNOMEDCT Clinical Finding Foreign Key" | "39579001" | "Antineoplastic Agent" | "moderate"
        "All nulls"  | null                      | null                                    | null       | null                   | null
    }

    @Unroll
    def "test all dateTime fields in AdverseReaction #desc"() {
        when:
        AdverseReaction adverseReaction = AdverseReaction.builder()
                .onsetPeriodEnd(onsetPeriodEnd)
                .onsetPeriodStart(onsetPeriodStart)
                .clinicallyRelevantDate(clinicallyRelevantDate)
                .startDate(startDate)
                .lastUpdateDate(lastUpdateDate)
                .recordedDate(recordedDate).build();
        AllergyIntolerance ai = getFhirResourceAllergyIntolerance(adverseReaction);
        def res_onset = ai.getOnset() as Period;
        def res_onsetStart = (res_onset == null) ? null : res_onset.getStartElement().getValueAsString();
        def res_onsetEnd = (res_onset == null) ? null : res_onset.getEndElement().getValueAsString();
        def res_clinicallyRelevantDate = getDateAsStringFromExtension(ai.getExtensionByUrl(Constants.CLINICALLY_RELEVANT_DATE_URL))
        def res_lastUpdateDate = getLastUpdateDate(ai.getMeta())
        def res_startDate = getDateAsStringFromExtension(ai.getExtensionByUrl(Constants.START_DATE_URL))
        def res_recordedDate = ai.getRecordedDateElement().getValueAsString()

        then:
        res_onsetStart == checkNull(onsetPeriodStart)
        res_onsetEnd == checkNull(onsetPeriodEnd)
        res_clinicallyRelevantDate == checkNull(clinicallyRelevantDate)
        res_startDate == checkNull(startDate)
        res_lastUpdateDate == checkNull(lastUpdateDate)
        res_recordedDate == checkNull(recordedDate)

        where:
        desc         | onsetPeriodEnd         | onsetPeriodStart       | clinicallyRelevantDate | startDate    | lastUpdateDate         | recordedDate
        "happy path" | "2011-08-01T19:04:54Z" | "2020-06-13T00:00:00Z" | "2020-07-21T00:00:00Z" | "2018-05-13" | "2020-06-19T00:00:00Z" | "2015-09-28T21:09:29Z"
        "All null"   | null                   | null                   | null                   | null         | null                   | null

    }

    @Unroll
    def "Test AllergyIntolerance #desc"() {
        when:
        AdverseReaction adverseReaction = AdverseReaction.builder()
                .status(IhrTerm.builder()
                        .ihrLaymanTerm(laymanTerm)
                        .ihrTerm(ihrTerm)
                        .sourceVocabulary(sVocabulary)
                        .sourceVocabularyCode(svCode)
                        .build())
                .sensitivityClasses(sensitivityClasses)
                .dataSource(dataSource as List<String>).build();
        AllergyIntolerance ai = getFhirResourceAllergyIntolerance(adverseReaction);
        def res_clinicalStatus = ai.getClinicalStatus()
        def res_clinicalStatus_coding = res_clinicalStatus.getCodingFirstRep()
        def res_sensitivityClasses = getValueOfExtension(ai.getExtension(), Constants.SENSITIVITY_CLASSES_URL)
        def res_datasource=getValueOfExtension(ai.getExtension(), Constants.DATA_SOURCE_URL)

        then:

        res_clinicalStatus.getText() == laymanTerm
        res_clinicalStatus_coding.getSystem() == sVocabulary
        res_clinicalStatus_coding.getCode() == svCode
        res_clinicalStatus_coding.getDisplay() == ihrTerm
        res_sensitivityClasses == checkIsListNull(sensitivityClasses)
        res_datasource==checkIsListNull(dataSource)

        where:
        desc         | laymanTerm                | sVocabulary                             | svCode     | ihrTerm                | sensitivityClasses              | dataSource
        "happy path" | "Chemotherapy Medication" | "SNOMEDCT Clinical Finding Foreign Key" | "39579001" | "Antineoplastic Agent" | ["Mental Behaviorial Disorder"] | ["System Interface Data Acquisition Method"]
        "All nulls"  | null                      | null                                    | null       | null                   | null                            | null
    }

    static getFhirResourceAllergyIntolerance(AdverseReaction adverseReaction) {
        //build v2 resource
        FhirResource fhirResource = FhirResource.builder()
                .bundle(new Bundle().setType(Bundle.BundleType.SEARCHSET))
                .patient(TestData.defaultPatient())
                .practitioner(TestData.practitionerMap())
                .practitionerRole(TestData.practitionerRoleMap())
                .relatedPerson(TestData.relatedPersonMap()).build()
        mapper.map(fhirResource, adverseReaction)
        Bundle bundle = fhirResource.getBundle()

        AllergyIntolerance ai = getFirstBundleResource(bundle, ResourceType.AllergyIntolerance)
        return ai;
    }

    private String getAsserterText(Reference asserter, String desc) {
        if (asserter.getResource() == null)
            return null;
        else if (desc.contains("RelatedPerson")) {
            return (asserter.getResource() as RelatedPerson).getRelationship().get(0).getText();
        } else if (desc.contains("PractitionerRole")) {
            return (asserter.getResource() as PractitionerRole).getCode().get(0).getText();
        } else if (desc.contains("Patient")) {
            return (asserter.getResource() as Patient).getName().get(0).getGiven().get(0)
        } else {
            return null;
        }
    }
}
