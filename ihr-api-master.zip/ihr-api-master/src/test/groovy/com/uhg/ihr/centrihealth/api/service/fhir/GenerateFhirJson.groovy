package com.uhg.ihr.centrihealth.api.service.fhir

import com.fasterxml.jackson.databind.JsonNode
import com.uhg.ihr.centrihealth.api.model.Payload
import com.uhg.ihr.centrihealth.api.service.FhirService
import com.uhg.ihr.centrihealth.util.TestData
import org.hl7.fhir.r4.model.Bundle

class GenerateFhirJson extends BaseFhirSpecification {

    def "generate fhir json from api json file"() {
        given:
        Payload samplePayload = TestData.buildSamplePayload("immunizations.json")
        JsonNode dataNode = samplePayload.payloadJson['dataClasses'] as JsonNode
        Bundle bundle = FhirService.fhirConvert(getApiResponse(dataNode))
        String fhirResponse = bundleToString(bundle)
        println(fhirResponse)

    }

}