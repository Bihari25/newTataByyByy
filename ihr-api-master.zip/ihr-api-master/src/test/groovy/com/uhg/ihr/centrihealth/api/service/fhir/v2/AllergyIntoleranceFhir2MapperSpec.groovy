package com.uhg.ihr.centrihealth.api.service.fhir

import com.uhg.ihr.centrihealth.api.constant.GlobalConstants
import com.uhg.ihr.centrihealth.api.constant.GlobalUrlConstant
import com.uhg.ihr.centrihealth.api.model.FhirResource
import com.uhg.ihr.centrihealth.api.model.dataclass.*
import com.uhg.ihr.centrihealth.api.service.fhir.v2.AllergyIntoleranceFhir2Mapper
import com.uhg.ihr.centrihealth.util.TestData
import org.hl7.fhir.r4.model.*
import spock.lang.Shared
import spock.lang.Unroll

@Unroll
class AllergyIntoleranceFhir2MapperSpec extends BaseFhirSpecification {

    @Shared
    static AllergyIntoleranceFhir2Mapper mapper = AllergyIntoleranceFhir2Mapper.of()

    @Unroll
    def "Test AllegryIntoleranceFhir2 all identifiers fhir conversion #test_name"() {

        when:
        // map to fhir resource
        AdverseReaction adverseReaction = AdverseReaction.builder()
                .recordKey(recordKey)
                .recorderId(recorderId)
                .objectId(objectId)
                .referenceIds(referenceIDs as List<String>)
                .build()
        AllergyIntolerance ai = getFhirResourceAllergyIntolerance(adverseReaction)

        def res_objectId = getValueOfIdentifier(ai.getIdentifier(), GlobalConstants.OBJECT_ID)
        def res_recordKey = getValueOfIdentifier(ai.getIdentifier(), Constants.RECORD_KEY)
        def res_referenceId = getValueOfIdentifier(ai.getIdentifier(), Constants.REFERENCE_IDS)
        def res_recorderId = (ai.getRecorder().getResource() == null) ? null : (ai.getRecorder().getResource() as Practitioner).getIdentifier().get(0).getValue()

        then:

        res_objectId == checkNull(objectId)
        res_referenceId == checkIsListNull(referenceIDs)
        res_recordKey == checkNull(recordKey)
        res_recorderId == recorderId

        where:
        test_name            | objectId | recorderId | recordKey                                                      | referenceIDs
        "happy  Path check " | 9        | "981232"   | "o*}Dci^Vj2DS9mggDvEzepfVVqzx{ZEsiUvmmn<+gbH%HEjP.xoJ0P2h8Y(h" | ["2009-01-02T03:04:44Z-Rally-1sE"]
        "null check "        | null     | null       | null                                                           | null
    }

    @Unroll
    def "Test AllegryIntoleranceFhir2 asserter object #desc"() {
        when:
        // map to fhir resource
        AdverseReaction adverseReaction = AdverseReaction.builder().asserterObject(
                IhrTerm.builder()
                        .ihrLaymanTerm(laymanTerm)
                        .ihrTerm(ihrTerm)
                        .sourceVocabulary(sVocabulary)
                        .sourceVocabularyCode(svCode)
                        .build()).build()
        AllergyIntolerance ai = getFhirResourceAllergyIntolerance(adverseReaction)

        def res_Asserter = ai.getAsserter()
        then:
        getAsserterText(ai.getAsserter(), desc) == svCode
        where:

        desc                 | laymanTerm              | sVocabulary              | svCode                  | ihrTerm
        "RelatedPerson-1"    | "Care giver"            | "http://snomed.info/sct" | "Caregiver"             | "Caregiver"
        "RelatedPerson-2"    | "Family Member"         | "http://snomed.info/sct" | "Family Member"         | "Family Member"
        "RelatedPerson-3"    | "Health Care Proxy"     | "http://snomed.info/sct" | "Health Care Proxy"     | "Health Care Proxy"
        "RelatedPerson-4"    | "Power of Attorney"     | "http://snomed.info/sct" | "Power of Attorney"     | "Power of Attorney"
        "RelatedPerson-5"    | "Other"                 | "http://snomed.info/sct" | "Other"                 | "Other"

        "PractitionerRole-1" | "Facility Staff"        | "http://snomed.info/sct" | "Facility Staff"        | "Facility Staff"
        "PractitionerRole-2" | "Medical Director"      | "http://snomed.info/sct" | "Medical Director"      | "Medical Director"
        "PractitionerRole-3" | "Myself"                | "http://snomed.info/sct" | "Myself"                | "Myself"
        "PractitionerRole-4" | "Pharmacist"            | "http://snomed.info/sct" | "Pharmacist"            | "Pharmacist"
        "PractitionerRole-5" | "Prescriber"            | "http://snomed.info/sct" | "Prescriber"            | "Prescriber"
        "PractitionerRole-6" | "Primary Care Provider" | "http://snomed.info/sct" | "Primary Care Provider" | "Primary Care Provider"
        "Patient"            | "Patient"               | "http://snomed.info/sct" | "cinderella"            | "Patient"

        "All are null"       | null                    | null                     | null                    | null
    }

    @Unroll
    def "Test AllegryIntoleranceFhir2 Type #desc"() {
        when:
        // map to fhir resource
        AdverseReaction adverseReaction = AdverseReaction.builder().allergyIntoleranceType(allergyIntoleranceType).build();
        AllergyIntolerance ai = getFhirResourceAllergyIntolerance(adverseReaction);
        def res_type = ai.getType().toString().toLowerCase()
        then:
        println(res_type)
        println(allergyIntoleranceType)
        res_type == checkNull(allergyIntoleranceType)
        where:

        desc                           | allergyIntoleranceType
        "happy path type -allergy"     | "allergy"
        "happy path type -intolerance" | "intolerance"
    }

    @Unroll
    def "Test allergens type #desc"() {
        when:

        // map to fhir resource
        def iTerm = IhrTerm.builder()
                .ihrLaymanTerm(laymanTerm)
                .ihrTerm(ihrTerm)
                .sourceVocabulary(sVocabulary)
                .sourceVocabularyCode(svCode)
                .build();
        List<IhrTerm> ihrTerms = new ArrayList<>();
        ihrTerms.add(iTerm);

        AdverseReaction adverseReaction = AdverseReaction.builder().allergens(ihrTerms).build();
        AllergyIntolerance ai = getFhirResourceAllergyIntolerance(adverseReaction);
        def substance = ai.getCode()
        def res_Coding = ai.getCode().getCodingFirstRep()

        then:

        substance.getText() == laymanTerm
        res_Coding.getDisplay() == ihrTerm
        res_Coding.getSystem() == sVocabulary
        res_Coding.getCode() == svCode

        where:

        desc         | laymanTerm                | sVocabulary                      | svCode      | ihrTerm
        "happy path" | "Chemotherapy Medication" | "SNOMEDCT Substance Foreign Key" | "419933005" | "Antineoplastic Agent"
        "All nulls"  | null                      | null                             | null        | null
    }

    @Unroll
    def "Test reactions type #desc"() {
        when:
        // map to fhir resource
        def reaction = new Reaction();
        reaction.setConcept(IhrTerm.builder()
                .ihrLaymanTerm(laymanTerm)
                .ihrTerm(ihrTerm)
                .sourceVocabulary(sVocabulary)
                .sourceVocabularyCode(svCode)
                .build());
        List<Reaction> reactions = new ArrayList<>();
        reactions.add(reaction);
        reaction.setSeverity(IhrTerm.builder()
                .sourceVocabularyCode(severitySVocabulary)
                .build())


        AdverseReaction adverseReaction = AdverseReaction.builder().reactionsFHIR(reactions).build();
        AllergyIntolerance ai = getFhirResourceAllergyIntolerance(adverseReaction);
        def res_reaction = ai.getReaction().get(0).getManifestation().get(0);
        def res_reaction_coding = res_reaction.getCodingFirstRep();
        def res_severity = ai.getReaction().get(0).getSeverity();
        then:
        res_reaction.getText() == laymanTerm
        res_reaction_coding.getDisplay() == ihrTerm
        res_reaction_coding.getSystem() == sVocabulary
        res_reaction_coding.getCode() == svCode
        if (desc.contains("nulls"))
            res_severity == severitySVocabulary;
        else
            res_severity.toString().toLowerCase() == severitySVocabulary;

        where:

        desc         | laymanTerm                | sVocabulary                             | svCode     | ihrTerm                | severitySVocabulary
        "happy path" | "Chemotherapy Medication" | "SNOMEDCT Clinical Finding Foreign Key" | "39579001" | "Antineoplastic Agent" | "moderate"
        "All nulls"  | null                      | null                                    | null       | null                   | null
    }

    @Unroll
    def "test all dateTime fields in AdverseReaction #desc"() {
        when:
        AdverseReaction adverseReaction = AdverseReaction.builder()
                .onsetPeriodEnd(onsetPeriodEnd)
                .onsetPeriodStart(onsetPeriodStart)
                .clinicallyRelevantDate(clinicallyRelevantDate)
                .startDate(startDate)
                .lastUpdateDate(lastUpdateDate)
                .recordedDate(recordedDate).build();
        AllergyIntolerance ai = getFhirResourceAllergyIntolerance(adverseReaction);
        def res_onset = ai.getOnset() as Period;
        def res_onsetStart = (res_onset == null) ? null : res_onset.getStartElement().getValueAsString();
        def res_onsetEnd = (res_onset == null) ? null : res_onset.getEndElement().getValueAsString();
        def res_clinicallyRelevantDate = getDateAsStringFromExtension(ai.getExtensionByUrl(GlobalUrlConstant.CLINICAL_RELEVANT_DATE_URL))
        def res_lastUpdateDate = getLastUpdateDate(ai.getMeta())
        def res_startDate = getDateAsStringFromExtension(ai.getExtensionByUrl(GlobalUrlConstant.START_DATE_URL))
        def res_recordedDate = ai.getRecordedDateElement().getValueAsString()

        then:
        res_onsetStart == checkNull(onsetPeriodStart)
        res_onsetEnd == checkNull(onsetPeriodEnd)
        res_clinicallyRelevantDate == checkNull(clinicallyRelevantDate)
        res_startDate == checkNull(startDate)
        res_lastUpdateDate == checkNull(lastUpdateDate)
        res_recordedDate == checkNull(recordedDate)

        where:
        desc         | onsetPeriodEnd         | onsetPeriodStart       | clinicallyRelevantDate | startDate    | lastUpdateDate         | recordedDate
        "happy path" | "2011-08-01T19:04:54Z" | "2020-06-13T00:00:00Z" | "2020-07-21T00:00:00Z" | "2018-05-13" | "2020-06-19T00:00:00Z" | "2015-09-28T21:09:29Z"
        "All null"   | null                   | null                   | null                   | null         | null                   | null

    }

    @Unroll
    def "Test AllergyIntolerance clinicalstatus and sensitivityclasses #desc"() {
        when:
        AdverseReaction adverseReaction = AdverseReaction.builder()
                .status(IhrTerm.builder()
                        .ihrTerm(ihrTerm)
                        .build())
                .sensitivityClasses(sensitivityClasses)
                .build();
        AllergyIntolerance ai = getFhirResourceAllergyIntolerance(adverseReaction);
        def res_clinicalStatus = ai.getClinicalStatus()
        def secCoding = ai.getMeta().getSecurity()
        def res_sensitivityClasses_system = (!ai.getMeta().getSecurity().isEmpty()) ? ai.getMeta().getSecurity().get(0).getSystem() : null
        def res_sensitivityClasses_code = (!ai.getMeta().getSecurity().isEmpty()) ? ai.getMeta().getSecurity().get(0).getCode() : null

        then:
        res_clinicalStatus.getText() == ihrTerm
        res_sensitivityClasses_system == sensitivityClasses_system
        res_sensitivityClasses_code == sensitivityClasses_code

        where:
        desc         | ihrTerm                | sensitivityClasses              | sensitivityClasses_system             | sensitivityClasses_code
        "happy path" | "Antineoplastic Agent" | ["Mental Behaviorial Disorder"] | GlobalUrlConstant.SECURITY_LABELS_URL | GlobalConstants.SECURITY_LABELS_CODE
        "All nulls"  | null                   | null                            | null                                  | null
    }

    @Unroll
    def "Test AllegryIntoleranceFhir2 category"() {
        when:
        AdverseReaction adverseReaction = AdverseReaction.builder()
                .allergenCategory(category)
                .build();
        AllergyIntolerance ai = getFhirResourceAllergyIntolerance(adverseReaction);

        then:
        result == ai.getCategory().get(0).value.toString().toLowerCase().contains(category)

        where:
        desc                  | category     | result
        "Verify happy path 1" | "food"       | true
        "Verify happy path 2" | "medication" | true
        "Verify happy path 3" | "medication" | true
        "Verify happy path 4" | "biologic"   | true
    }

    @Unroll
    def "Test AllegryIntoleranceFhir2 presenceStateTerm"() {
        when:
        AdverseReaction adverseReaction = AdverseReaction.builder()
                .presenceStateTerm(presenceStateTerm)
                .build();
        AllergyIntolerance ai = getFhirResourceAllergyIntolerance(adverseReaction);
        def res_presenceStateTerm = getValueOfExtension(ai.getExtension(), GlobalUrlConstant.PRESENCESTATE_URL)
        then:
        res_presenceStateTerm == checkNull(result)
        where:
        desc                  | presenceStateTerm | result
        "Verify happy path"   | "Past Occurrence" | "Past Occurrence"
        "Verify empty string" | ""                | null
        "Verify with null"    | null              | null

    }

    @Unroll
    def "Test AllegryIntoleranceFhir2 note"() {
        when:
        Note note = buildSampleNote(text, time, author, noteType)

        AdverseReaction adverseReaction = AdverseReaction.builder()
                .note(Arrays.asList(note))
                .build();
        AllergyIntolerance ai = getFhirResourceAllergyIntolerance(adverseReaction);
        def res_note = ai.getNote().get(0)
        Extension noteTypeValue = getExtensionFromList(res_note.getExtension(), GlobalUrlConstant.IHR_NOTE_TYPE_URL)
        def authorReference = res_note.getAuthorReference().getResource()
        def authorReferenceIdentifier = getAuthorReferenceIdentifier(authorReference, GlobalConstants.EMPLOYEE_ID)
        then:
        noteTypeValue.getValue().toString() == noteType
        res_note.getText() == text
        res_note.getTimeElement().getValueAsString() == time
        res_note.getAuthorReference().getResource().fhirType() == resourceType.toString()
        authorReferenceIdentifier.getValue() == author
        where:
        noteType          | text                         | time                   | author         || resourceType
        "Clinical Note"   | "Patient reports."           | "2019-03-28T00:00:00Z" | "ACT000123456" || ResourceType.Practitioner
        "PatientNote"     | "This medication is working" | "2018-03-28T00:00:00Z" | "ACT000000111" || ResourceType.Patient
        "Clinical Note"   | "Patient reports medication" | "2020-07-28T11:11:11Z" | "ACT098763"    || ResourceType.Practitioner
        "PatientTypeNote" | "This medication"            | "2012-03-28T00:00:00Z" | "ACT0003456"   || ResourceType.Patient
        ""                | "This medication"            | "2018-03-28T00:00:00Z" | "ACT0003456"   || ResourceType.Patient
        null              | "This medication report "    | "2014-03-28T00:00:00Z" | "ACT0003456"   || ResourceType.Patient

    }

    static getFhirResourceAllergyIntolerance(AdverseReaction adverseReaction) {
        //build v2 resource
        FhirResource fhirResource = FhirResource.builder()
                .bundle(new Bundle().setType(Bundle.BundleType.SEARCHSET))
                .patient(TestData.defaultPatient())
                .practitioner(TestData.practitionerMap())
                .practitionerRole(TestData.practitionerRoleMap())
                .relatedPerson(TestData.relatedPersonMap()).build()
        mapper.map(fhirResource, adverseReaction)
        Bundle bundle = fhirResource.getBundle()

        AllergyIntolerance ai = getFirstBundleResource(bundle, ResourceType.AllergyIntolerance)
        return ai;
    }

    private String getAsserterText(Reference asserter, String desc) {
        if (asserter.getResource() == null)
            return null;
        else if (desc.contains("RelatedPerson")) {
            return (asserter.getResource() as RelatedPerson).getRelationship().get(0).getText();
        } else if (desc.contains("PractitionerRole")) {
            return (asserter.getResource() as PractitionerRole).getCode().get(0).getText();
        } else if (desc.contains("Patient")) {
            return (asserter.getResource() as Patient).getName().get(0).getGiven().get(0)
        } else {
            return null;
        }
    }
}
