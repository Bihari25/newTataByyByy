package com.uhg.ihr.centrihealth.api.service.fhir

import com.fasterxml.jackson.databind.JsonNode
import com.fasterxml.jackson.databind.node.ArrayNode
import com.uhg.ihr.centrihealth.api.model.Payload
import com.uhg.ihr.centrihealth.api.model.dataclass.Constants
import com.uhg.ihr.centrihealth.api.service.FhirService
import com.uhg.ihr.centrihealth.util.TestData
import org.hl7.fhir.r4.model.Bundle
import org.hl7.fhir.r4.model.Coding
import org.hl7.fhir.r4.model.Condition
import org.hl7.fhir.r4.model.DateTimeType
import org.hl7.fhir.r4.model.Encounter
import org.hl7.fhir.r4.model.Extension
import org.hl7.fhir.r4.model.Identifier
import org.hl7.fhir.r4.model.ResourceType

class EncounterFhirMapperSpec extends BaseFhirSpecification {

    def "encounter mapper happy path "() {

        given:
        Payload samplePayload = TestData.buildSamplePayload("encounter.json")
        JsonNode dataNode = samplePayload.payloadJson['dataClasses'] as JsonNode
        Bundle bundle = FhirService.fhirConvert(getApiResponse(dataNode))
        Encounter encounter = getFirstBundleResource(bundle, ResourceType.Encounter)

        String lastUpdated = getLastUpdateDate(encounter.getMeta())
        Extension presenceState = getExtensionFromList(encounter.getExtension(), Constants.PRESENCE_STATE_TERM_URL)
        Extension clinicallyRelevantDate = getExtensionFromList(encounter.getExtension(), Constants.CLINICALLY_RELEVANT_DATE_URL)
        String clinicallyRelevantDateValue = clinicallyRelevantDate.castToDateTime(clinicallyRelevantDate.getValue()).getValueAsString()
        Extension extensionSen = getExtensionFromList(encounter.getExtension(), Constants.SENSITIVITY_CLASSES_URL)
        Extension extensionDat = getExtensionFromList(encounter.getExtension(), Constants.DATA_SOURCE_URL)

        Identifier instanceId = getIdentifierFromList(encounter.getIdentifier(), Constants.INSTANCE_ID)
        Identifier careTeamInstanceId = getIdentifierFromList(encounter.getIdentifier(), Constants.RELATED_CARE_TEAM_INSTANCE_IDS)
        ArrayNode careTeamIds = MAPPER.readTree(careTeamInstanceId.getValue()) as ArrayNode
        Identifier referenceIds = getIdentifierFromList(encounter.getIdentifier(), Constants.REFERENCE_IDS)
        Identifier sourceClaimIds = getIdentifierFromList(encounter.getIdentifier(), Constants.SOURCE_CLAIM_IDS)
        Identifier conditionInstanceId = getIdentifierFromList(encounter.getIdentifier(), Constants.RELATED_CONDITION_INSTANCE_IDS)
        Identifier observationInstanceId = getIdentifierFromList(encounter.getIdentifier(), Constants.RELATED_OBSERVATION_INSTANCE_IDS)
        Identifier medicationInstanceId = getIdentifierFromList(encounter.getIdentifier(), Constants.RELATED_MEDICATION_INSTANCE_IDS)
        Identifier procedureInstanceId = getIdentifierFromList(encounter.getIdentifier(), Constants.RELATED_PROCEDURE_INSTANCE_IDS)
        Identifier deviceInstanceId = getIdentifierFromList(encounter.getIdentifier(), Constants.RELATED_DEVICE_INSTANCE_IDS)
        Identifier immunizationInstanceId = getIdentifierFromList(encounter.getIdentifier(), Constants.RELATED_IMMUNIZATION_INSTANCE_IDS)
        Identifier sfpInstanceId = getIdentifierFromList(encounter.getIdentifier(), Constants.RELATED_SERVICE_FACILITY_PROVIDER_INSTANCE_IDS)

        ArrayNode sourceClaimIdsArray = MAPPER.readTree(sourceClaimIds.getValue()) as ArrayNode

        String classification = encounter.getClass_().getDisplay().toString()
        Coding type = getCodingFromList(encounter.getType().get(0).getCoding(), "Inpatient Visit")
        def location = encounter.getLocation().get(0).getLocation().properties.get("display").toString();
        Coding discharge = getCodingFromList(encounter.getHospitalization().getDischargeDisposition().getCoding(), "IP ADT Discharge Disposition")
        Coding diagnosisuse = getCodingFromList(encounter.getDiagnosis().get(0).getUse().getCoding(), "Admitting Diagnosis")
        DateTimeType start = encounter.getPeriod().getStartElement()

        Condition condition = encounter.getDiagnosis().get(0).getCondition().getResource()
        Coding conditionCode = getCodingFromList(condition.getCode().getCoding(), "ICD-10 Diagnosis")

        expect:
        lastUpdated.substring(0, 10) == "2019-09-04"
        presenceState.getValue().toString() == "Present"
        clinicallyRelevantDateValue == "2019-06-19T21:09:29Z"
        instanceId.getValue().toString() == "36904128193011"
        careTeamIds.size() == 2
        careTeamIds.get(0).asInt() == 1234
        sourceClaimIdsArray.get(0).asLong() == 7458632377
        location == "Inpatient Hospital"
        discharge.getDisplay().toString() == "Discharged to Home or Self Care (Routine Discharge)"
        diagnosisuse.getSystem().toString() == "http://hl7.org/implement/standards/fhir/valueset-diagnosis-role.html"
        classification == "Inpatient Patient Classification"
        start.getValueAsString().substring(0, 10) == "2018-04-24"
        type.getSystem().toString() == "IP ADT Patient Type"
        conditionCode.getCode().toString() == "I62.00"
        referenceIds.getValue().toString() == "[\"1234463535\"]"
        sourceClaimIds.getValue().toString() == "[\"7458632377\"]"
        conditionInstanceId.getValue().toString() == "[36674180598117,36904565693021]"
        observationInstanceId.getValue().toString() == "[333333,555555]"
        medicationInstanceId.getValue().toString() == "[11111,22222]"
        procedureInstanceId.getValue().toString() == "[66666,66666]"
        deviceInstanceId.getValue().toString() == "[12345566,12334]"
        immunizationInstanceId.getValue().toString() == "[1233456,433222]"
        sfpInstanceId.getValue().toString() == "[13356001458,525266262]"
        extensionSen.getValue().toString() == "[\"CommunicableDiseases\"]"
        extensionDat.getValue().toString() == "[\"System Interface Data Acquisition Method\"]"
    }
}


