package com.uhg.ihr.centrihealth.api.validator

import com.uhg.ihr.centrihealth.api.model.RecordType
import com.uhg.ihr.centrihealth.api.validator.ValidRecordTypeValidator
import spock.lang.Specification

class ValidRecordTypeValidatorSpec extends Specification {
    def "Test Invalid Record Type"() {
        given:
        def validator = new ValidRecordTypeValidator()
        Set<RecordType> recordTypes = new HashSet<>()

        expect:
        !validator.isValid(recordTypes, null)
    }

    def "Test Valid Record Type"() {
        given:
        def validator = new ValidRecordTypeValidator()
        Set<RecordType> recordTypes = new HashSet<>()
        recordTypes.add(RecordType.ADVERSE_REACTION)

        expect:
        validator.isValid(recordTypes, null)
    }

}
