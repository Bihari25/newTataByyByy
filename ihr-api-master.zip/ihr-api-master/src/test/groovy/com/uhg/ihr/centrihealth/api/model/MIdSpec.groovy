package com.uhg.ihr.centrihealth.api.model

import spock.lang.Specification

class MIdSpec extends Specification {

    def "builder and toString work as expected"() {
        setup:
        String dateOfBirth = "2010/10/10"
        String firstName = "first"
        String lastName = "last"
        String policyNumber = "policy"
        String searchId = "id"
        String idType = "type 1"
        String idValue = "value 1"
        def big5 = Big5.builder().dateOfBirth(dateOfBirth).firstName(firstName).lastName(lastName).policyNumber(policyNumber).searchId(searchId).build()

        when:
        def mId = MId.builder()
                .idType(idType)
                .idValue(idValue)
                .big5(big5)
                .build()

        then:
        def newBig5 = mId.getBig5()
        newBig5.dateOfBirth == dateOfBirth
        newBig5.firstName == firstName
        newBig5.lastName == lastName
        newBig5.policyNumber == policyNumber
        newBig5.searchId == searchId
        mId.idType == idType
        mId.idValue == idValue
        mId.toString() == "MId(idType=type 1, idValue=value 1, big5=Big5(firstName=first, lastName=last, dateOfBirth=2010/10/10, policyNumber=policy, searchId=id, idType=null, ids=null))"
    }
}
