package com.uhg.ihr.centrihealth.api.filter

import com.uhg.ihr.centrihealth.api.exception.IhrBadRequestException
import com.uhg.ihr.centrihealth.api.model.FilterPair
import com.uhg.ihr.centrihealth.api.util.AppUtils
import spock.lang.Specification
import spock.lang.Unroll

@Unroll
class DataContentFilterBuilderSpec extends Specification {

    def "computeStartAndEndDateFilters happy path scenario: #desc"() {
        given:
        DataContentFilterBuilder dataContentFilterBuilder = new DataContentFilterBuilder()
        List<DataFilter> dataFilters = new ArrayList<>()

        when:
        dataContentFilterBuilder.computeStartAndEndDateFilters(inputFilters, dataFilters)

        then:
        dataFilters.size() == expectedSize

        where:
        scenario                                       | inputFilters                                                                                           || expectedSize
        "Filter for start date"                        | [new FilterPair(key: AppUtils.CLINICALLY_RELEVANT_START_DATE, value: '2018-12-25')] as Set<FilterPair> || 1
        "Filter for start and end date"                | [new FilterPair(key: AppUtils.CLINICALLY_RELEVANT_START_DATE, value: '2018-12-25'),
                                                          new FilterPair(key: AppUtils.CLINICALLY_RELEVANT_END_DATE, value: '2019-12-25')] as Set<FilterPair>   || 1
    }

    def "computeStartAndEndDateFilters exception path scenario: #desc"() {
        given:
        DataContentFilterBuilder dataContentFilterBuilder = new DataContentFilterBuilder()
        List<DataFilter> dataFilters = new ArrayList<>()

        when:
        dataContentFilterBuilder.computeStartAndEndDateFilters(inputFilters, dataFilters)

        then:
        dataFilters.size() == expectedSize
        IhrBadRequestException ihrBadRequestEx = thrown()
        ihrBadRequestEx.message.contains("Data can't filter only with end date; Please provide start date")

        where:
        scenario                   | inputFilters                                                                                         || expectedSize
        "Filter for only end date" | [new FilterPair(key: AppUtils.CLINICALLY_RELEVANT_END_DATE, value: '2018-12-25')] as Set<FilterPair> || 0
    }

    def "constructor with parameters happy path scenario: #desc"() {
        when:
        DataContentFilterBuilder dataContentFilterBuilder = new DataContentFilterBuilder(inputFilters)

        then:
        dataContentFilterBuilder.getDataFilters().size() == expectedSize

        where:
        scenario                                       | inputFilters                                                                                           || expectedSize
        "Empty or no filters"                          | [] as Set<FilterPair>                                                                                  || 0
        "Null filters"                                 | null                                                                                                   || 0
        "Filter for start date only"                   | [new FilterPair(key: AppUtils.CLINICALLY_RELEVANT_START_DATE, value: '2018-12-25')] as Set<FilterPair> || 1
        "Filter for presence state only"               | [new FilterPair(key: AppUtils.PRESENCE_STATE, value: "Present")] as Set<FilterPair>                    || 1
        "Filter for start and end date"                | [new FilterPair(key: AppUtils.CLINICALLY_RELEVANT_START_DATE, value: '2018-12-25'),
                                                          new FilterPair(key: AppUtils.CLINICALLY_RELEVANT_END_DATE, value: '2019-12-25')] as Set<FilterPair>   || 1
        "Filter for start date and present state"      | [new FilterPair(key: AppUtils.CLINICALLY_RELEVANT_START_DATE, value: '2018-12-25'),
                                                          new FilterPair(key: AppUtils.PRESENCE_STATE, value: "Present")] as Set<FilterPair>                    || 2
        "Filter for start/,end date and present state" | [new FilterPair(key: AppUtils.CLINICALLY_RELEVANT_START_DATE, value: '2018-12-25'),
                                                          new FilterPair(key: AppUtils.CLINICALLY_RELEVANT_END_DATE, value: '2019-12-25'),
                                                          new FilterPair(key: AppUtils.PRESENCE_STATE, value: "Present")] as Set<FilterPair>                    || 2

    }

    def "constructor with parameters exception path scenario: #desc"() {
        when:
        DataContentFilterBuilder dataContentFilterBuilder = new DataContentFilterBuilder(inputFilters)

        then:
        IhrBadRequestException ihrBadRequestEx = thrown()
        ihrBadRequestEx.message.contains("Data can't filter only with end date; Please provide start date")

        where:
        scenario                                | inputFilters
        "Filter for end date only"              | [new FilterPair(key: AppUtils.CLINICALLY_RELEVANT_END_DATE, value: '2018-12-25')] as Set<FilterPair>
        "Filter for end date and present state" | [new FilterPair(key: AppUtils.CLINICALLY_RELEVANT_END_DATE, value: '2018-12-25'),
                                                   new FilterPair(key: AppUtils.PRESENCE_STATE, value: "Present")] as Set<FilterPair>
    }

}
