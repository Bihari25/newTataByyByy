package com.uhg.ihr.centrihealth.util

import com.fasterxml.jackson.databind.JsonNode
import com.uhg.ihr.centrihealth.api.model.*
import com.uhg.ihr.centrihealth.api.model.dataclass.DataClass
import com.uhg.ihr.centrihealth.api.model.dataclass.IhrResponse
import com.uhg.ihr.centrihealth.api.model.dataclass.IhrTerm
import com.uhg.ihr.centrihealth.api.model.dataclass.Supplier
import com.uhg.ihr.centrihealth.api.service.fhir.BaseFhirSpecification
import com.uhg.ihr.centrihealth.api.util.AppUtils
import org.apache.commons.lang3.RandomStringUtils
import org.hl7.fhir.r4.model.*

/**
 * TestData class acts like test harness for sample data for Unit and Integration test cases.
 *
 * @author Ihr-Api Engineering Team
 * copyright (C) All rights reserved UHG
 */
class TestData extends BaseFhirSpecification {
    static final String TOKEN = 'Bearer eyJhbGciOiJSUzUxMiJ9.eyJyb2xlIjoidXNlciIsImNyZWF0ZWQiOjE1MjI4NDk5OTE3OTcsInVzZXJuYW1lIjoiY2xvdWRzZGsifQ.dzfwWRugsnhPHB0RNT9lZHnX7gvNfGks_ivTc_dQ6-ejM6B1-Chx3WrwBE8drdy4ZbvkVTlHkHRSu3nBZi3Aw0wmN5N7UPUI0wP2KhAHGQS4-LOXgD58ioX9ep3k6hZQqy-oJor5Q3wZS8HJKMMY8izIROtJ5z-z5Y2RRw3ONnQLL5JR40hF9d5mFKA8Y1giEP32qg259MVbdkHNkI0ceq8hrXJ7w_OD4-JPteNhM9EeyNOmzjrKSEG-tkYrWI7g5xgvgMuO8iHFym4WhkDT6FNfcK2xs8QfCbJCZqV28xSIjbrm0El0L7kRzJbsKBxQ7FNJ35iaX18DpQMpu6usUQ'

    /**
     * Method to build ihr api request.
     *
     * @return IhrApiRequest
     */
    static IhrApiRequest sampleIhrApiRequest() {
        def sampleDataClasses = [RecordType.HEALTH_CONDITION, RecordType.HEALTH_DEVICE] as Set<RecordType>
        return IhrApiRequest.builder().mbrId(sampleMid()).correlationId("CR1234")
                .language("EN").requestor(sampleBig5()).dataClasses(sampleDataClasses).build()
    }

    /**
     * Method to build sample ihr api response.
     *
     * @return IhrApiResponse
     */
    static IhrApiResponse sampleIhrApiResponse() {
        return IhrApiResponse.builder().correlationId("CR1234").apiVersion("1.0.0")
                .dataVersion("2.0.0").language("EN").schemaVersion("1.0.0").mbrId(sampleMid()).build()
    }

    static IhrResponse sampleIhrResponse() {
        IhrResponse response = new IhrResponse()
        Payload samplePayload = buildSamplePayload("datafilter-payload.json")
        JsonNode dataNode = samplePayload.payloadJson['dataClasses']
        response.setDataClasses(MAPPER.treeToValue(dataNode, DataClass.class))
        response.setMbrId(sampleMid())
        return response
    }

    /**
     * Method to build sample member id information.
     *
     * @return MId
     */
    static MId sampleMid() {
        return MId.builder().idType("RALLYID").idValue("Mbr1234").big5(sampleBig5()).build()
    }

    /**
     * Method to build sample big 5 information.
     *
     * @return Big5
     */
    static Big5 sampleBig5() {
        return Big5.builder().firstName("TFName").lastName("TLName")
                .policyNumber("TPLCY12345").searchId("TSrch1234").dateOfBirth("2001/01/01").build()
    }

    /**
     * Method to build sample play load.
     *
     * @param fileName
     * @return Payload
     */
    static Payload buildSamplePayload(String fileName) {
        String payloadContent = AppUtils.readResource(fileName)
        return Payload.builder()
                .language("EN")
                .taxonomy("Not Used")
                .ihrIdentifier("ACT12345678")
                .payload(payloadContent)
                .build()
    }

    static String randomChid() {
        return RandomStringUtils.randomAlphanumeric(9).toUpperCase()
    }

    static String createIdURI() {
        return "urn:uuid:" + UUID.randomUUID().toString()
    }

    static HumanName defaultHumanName() {
        return new HumanName()
                .setFamily("Mosley")
                .addGiven("David")
                .addGiven("H")
                .setText("Mosley, David H")
                .addPrefix("DR.")
    }

    static Identifier defaultPractitionerIdentifier() {
        return new Identifier().setType(defaultPractitionerCode()).setValue("1234567890")
    }

    static Identifier defaultOrganizationIdentifier() {
        return new Identifier().setSystem("http://hl7.org/fhir/sid/us-npi").setValue("1234567890")
    }

    static CodeableConcept defaultPractitionerCode() {
        return new CodeableConcept()
                .addCoding(new Coding().setCode("NPI"))
                .setText("Medical Director")
    }

    static CodeableConcept defaultRelationship() {
        return new CodeableConcept().setText("Health Care Proxy")
    }

    static CodeableConcept defautConditionCode() {
        return new CodeableConcept()
                .setText("Anxiety Disorder")
                .addCoding(new Coding()
                        .setDisplay("Anxiety Disorder")
                        .setCode("F41.9")
                        .setSystem("ICD10 Diagnosis Code"))
    }

    static CodeableConcept defautSpecimenCode() {
        return new CodeableConcept()
                .setText("Blood")
                .addCoding(new Coding()
                        .setCode("119297000")
                        .setDisplay("Blood")
                        .setSystem("SNOMEDCT Specimen"))
    }

    static Patient defaultPatient() {
        Patient patient = new Patient().setId(createIdURI())
        return patient.addName(new HumanName().setFamily("downtrodden").addGiven("cinderella"))
                .setBirthDate(toDate("1989/05/27"))
    }

    static Practitioner defaultPractitioner() {
        Practitioner practitioner = new Practitioner().setId(createIdURI())
        return practitioner.addName(defaultHumanName()).addIdentifier(defaultPractitionerIdentifier())
    }

    static Map<String,Practitioner> practitionerMap(){
        Map<String,Practitioner> map=new HashMap<>();
        map.put("981232",defaultPractitioner())
        return map;
    }

    static defaultPractitionerRole() {
        PractitionerRole practitionerRole = new PractitionerRole().setId(createIdURI())
        return practitionerRole.addCode(new CodeableConcept().setText("Medical Director"))
                .addIdentifier(defaultPractitionerIdentifier())
    }

    static RelatedPerson defaultRelatedPerson() {
        RelatedPerson relatedPerson = new RelatedPerson().setId(createIdURI())
        return relatedPerson.addName(defaultHumanName()).addRelationship(defaultRelationship())
    }

    static Map<String, RelatedPerson> relatedPersonMap() {
        Map<String, RelatedPerson> map = new HashMap<>();
        RelatedPerson relatedPerson = new RelatedPerson().setId(createIdURI());
        map.put("HEALTH_CARE_PROXY", defaultRelatedPerson());
        return map;
    }

    static Map<String, PractitionerRole> practitionerRoleMap() {
        Map<String, PractitionerRole> map = new HashMap<>();
        PractitionerRole practitionerRole = new PractitionerRole().setId(createIdURI());
        map.put("FACILITY_STAFF", defaultPractitionerRole());
        return map;
    }

    static Organization defaultOrganization() {
        Organization organization = new Organization().setId(createIdURI())
        return organization.addIdentifier(defaultOrganizationIdentifier())
    }

    static Condition defaultCondition() {
        Condition condition = new Condition().setId(createIdURI())
        return condition.setCode(defautConditionCode())
    }

    static Observation defaultObservation() {
        Observation observation = new Observation().setId(createIdURI())
        return observation.setEffective(defaultDateTimeType())
                .setValue(defaultStringType())
    }

    static Location defaultLocation() {
        Location location = new Location().setId(createIdURI())
        return location.setName("Liberty Medical Supply")
                .addIdentifier(new Identifier()
                        .setValue("1950076532")
                        .setType(new CodeableConcept()
                                .addCoding(new Coding().setCode("NPI")
                                        .setDisplay("National Provider Identifier")
                                        .setSystem("http://hl7.org/fhir/sid/us-npi"))))
    }

    static Supplier defaultSupplier() {
        Supplier supplier = new Supplier()
        supplier.setName("Liberty Medical Supply")
        supplier.setNpinum("1950076532")
        return supplier
    }

    static Specimen defaultSpecimen() {
        Specimen specimen = new Specimen().setId(createIdURI())
        return specimen.setType(defautSpecimenCode())
    }

    static defaultIhrTerm() {
        IhrTerm ihrTerm = new IhrTerm()
        ihrTerm.setIhrTerm("Blood")
        ihrTerm.setIhrLaymanTerm("Blood")
        ihrTerm.setSourceVocabulary("SNOMEDCT Specimen")
        ihrTerm.setSourceVocabularyCode("119297000")
        return ihrTerm
    }

    static DateTimeType defaultDateTimeType() {
        return new DateTimeType("2019-07-20T00:00:00Z")
    }

    static StringType defaultStringType() {
        return new StringType("7.3")
    }

    static Bundle defaultBundle() {
        return new Bundle().setType(Bundle.BundleType.SEARCHSET)
    }

    static FhirResource defaultFhirResource() {
        return buildFhirResource(defaultBundle(), defaultPatient())
    }
}