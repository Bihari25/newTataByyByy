package com.uhg.ihr.centrihealth.api.exception

import io.micronaut.http.HttpRequest
import spock.lang.Specification

import java.util.concurrent.TimeoutException

class TimeoutExceptionHandlerSpec extends Specification {
    HttpRequest mockHttpRequest = Mock(HttpRequest)
    TimeoutExceptionHandler timeoutExceptionHandler = new TimeoutExceptionHandler()

    def "it handles the exception"() {
        when:
        def result = timeoutExceptionHandler.handle(mockHttpRequest, new TimeoutException())

        then:
        500 == result.status().code
        '{"errors":"Request timed out after 8500ms"}' == result.getBody().get().toString()
    }
}