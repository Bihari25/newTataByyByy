package com.uhg.ihr.centrihealth.api

import com.fasterxml.jackson.databind.ObjectMapper
import com.github.tomakehurst.wiremock.junit.WireMockRule
import com.uhg.ihr.centrihealth.api.model.Big5
import com.uhg.ihr.centrihealth.api.service.fhir.BaseFhirSpecification
import com.uhg.ihr.centrihealth.api.util.AppUtils
import com.uhg.ihr.centrihealth.senzing.model.SenzingRequest
import io.micronaut.context.annotation.Property
import io.micronaut.http.client.RxHttpClient
import io.micronaut.http.client.annotation.Client
import io.micronaut.test.annotation.MicronautTest
import javax.inject.Inject
import org.junit.ClassRule
import spock.lang.Shared

import static com.github.tomakehurst.wiremock.client.WireMock.aResponse
import static com.github.tomakehurst.wiremock.client.WireMock.equalToJson
import static com.github.tomakehurst.wiremock.client.WireMock.post
import static com.github.tomakehurst.wiremock.client.WireMock.serverError
import static com.github.tomakehurst.wiremock.client.WireMock.urlEqualTo

@MicronautTest
@Property(name = "micronaut.security.stargate.enabled", value = "false")
@Property(name = "senzing.secretKey", value = "55555555555555555555555555555555555555555555555555555555555555555555555555555555")
@Property(name = "mongo.mongo-txn", value = "false")
//FIXME: will need to enable mongo testing
class WireMockBaseTest extends BaseFhirSpecification {

    static String PAYLOAD_BASE = "{\"ihrIdentifier\":\"%s\",\"language\":\"EN\",\"taxonomy\":null,\"payload\":\"%s\"}"
    static String SENZING_BASE = "{\"data\":{\"searchResults\":%s}}"
    static ObjectMapper MAPPER = new ObjectMapper()

    @Inject
    @Client(id = '/', configuration = WireMockHttpClientConfiguration.class)
    RxHttpClient httpClient

    @ClassRule
    @Shared
    WireMockRule wireMockRule = new WireMockRule(8089)

    def cleanup() {
        clearMatches()
    }

    static String buildResponse(String chid, String payload) {
        return String.format(PAYLOAD_BASE, chid, payload)
    }

    def matchSenzingToChid(Big5 big5, String chid) {
        matchSenzing(big5, AppUtils.readResource("senzing-base-response.json").replace("#CHID#", chid))
    }

    def matchSenzing(Big5 big5, String response) {
        def request = MAPPER.writeValueAsString(SenzingRequest.buildSenzingRequest(big5))

        wireMockRule.stubFor(post(urlEqualTo("/entities/"))
                .withRequestBody(equalToJson(request))
                .willReturn(aResponse()
                        .withHeader("Content-Type", "application/json")
                        .withBody(response)))
    }

    def notMatchSenzing(Big5 big5) {
        def request = MAPPER.writeValueAsString(SenzingRequest.buildSenzingRequest(big5))

        wireMockRule.stubFor(post(urlEqualTo("/entities/"))
                .withRequestBody(equalToJson(request))
                .willReturn(aResponse()
                        .withStatus(200)
                        .withHeader("Content-Type", "application/json")
                        .withBody(String.format(SENZING_BASE, "[]"))))
    }

    def senzingTimeout() {
        wireMockRule.stubFor(post(urlEqualTo("/entities/"))
                .willReturn(aResponse()
                        .withStatus(200)
                        .withFixedDelay(9000)
                        .withHeader("Content-Type", "application/json")
                        .withBody(String.format(SENZING_BASE, "[]"))))
    }

    def errorSenzing(Big5 big5) {
        def request = MAPPER.writeValueAsString(SenzingRequest.buildSenzingRequest(big5))

        wireMockRule.stubFor(post(urlEqualTo("/entities/"))
                .withRequestBody(equalToJson(request))
                .willReturn(serverError()))
    }

    def clearMatches() {
        wireMockRule.resetAll()
    }

}

