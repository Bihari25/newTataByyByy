package com.uhg.ihr.centrihealth.api.service.fhir

import com.fasterxml.jackson.databind.JsonNode
import com.fasterxml.jackson.databind.node.ArrayNode
import com.uhg.ihr.centrihealth.api.model.Payload
import com.uhg.ihr.centrihealth.api.model.dataclass.Constants
import com.uhg.ihr.centrihealth.api.service.FhirService
import com.uhg.ihr.centrihealth.util.TestData
import org.hl7.fhir.r4.model.Annotation
import org.hl7.fhir.r4.model.Bundle
import org.hl7.fhir.r4.model.CodeableConcept
import org.hl7.fhir.r4.model.Coding
import org.hl7.fhir.r4.model.Extension
import org.hl7.fhir.r4.model.Goal
import org.hl7.fhir.r4.model.Identifier
import org.hl7.fhir.r4.model.Observation
import org.hl7.fhir.r4.model.ResourceType

class GoalFhirMapperSpec extends BaseFhirSpecification {


    def "goal mapper happy path "() {

        given:
        Payload samplePayload = TestData.buildSamplePayload("goal.json")
        JsonNode dataNode = samplePayload.payloadJson['dataClasses'] as JsonNode
        Bundle bundle = FhirService.fhirConvert(getApiResponse(dataNode))
        Goal goal = getFirstBundleResource(bundle, ResourceType.Goal)

        String lastUpdated = getLastUpdateDate(goal.getMeta())
        Identifier identifier = getIdentifierFromList(goal.getIdentifier(), Constants.INSTANCE_ID)
        Identifier identifier1 = getIdentifierFromList(goal.getIdentifier(), Constants.RELATED_CONDITION_INSTANCE_IDS)
        ArrayNode relatedConditionInstanceIds = MAPPER.readTree(identifier1.getValue()) as ArrayNode

        Extension extension = getExtensionFromList(goal.getExtension(), GoalFhirMapper.EXPECTED_ACHIEVEMENT_URL)
        Extension presenceState = getExtensionFromList(goal.getExtension(), Constants.PRESENCE_STATE_TERM_URL)
        CodeableConcept presenceStateConcept = presenceState.castToCodeableConcept(presenceState.getValue())
        Coding presenceStateCode = getCodingFromList(presenceStateConcept.getCoding(), "Present")
        Extension clinicallyRelevantDate = getExtensionFromList(goal.getExtension(), Constants.CLINICALLY_RELEVANT_DATE_URL)
        String clinicallyRelevantDateValue = clinicallyRelevantDate.castToDateTime(clinicallyRelevantDate.getValue()).getValueAsString()
        Coding achievementStatus = getCodingFromList(goal.getAchievementStatus().getCoding(), "Not Met")
        Coding description = getCodingFromList(goal.getDescription().getCoding(), "Body Mass Index (BMI) Monitoring Goal")
        Coding category = getCodingFromList(goal.getCategoryFirstRep().getCoding(), "Nursing Outcome")
        def target = goal.getTarget().get(1).getDetail().toString()
        Annotation annotation = getNoteFromList(goal.getNote(), "The patient is making progress")

        Observation observation = (Observation) goal.getOutcomeReferenceFirstRep().getResource()
        def valueString = observation.getValue().toString()

        Identifier referenceIds = getIdentifierFromList(goal.getIdentifier(), Constants.REFERENCE_IDS)
        Extension extensionSen = getExtensionFromList(goal.getExtension(), Constants.SENSITIVITY_CLASSES_URL)
        Extension extensionDat = getExtensionFromList(goal.getExtension(), Constants.DATA_SOURCE_URL)

        expect:
        identifier.getValue() == "19931012001356"
        relatedConditionInstanceIds.size() == 2
        relatedConditionInstanceIds.get(0).asInt() == 123456
        extension.getUrl().toString() == GoalFhirMapper.EXPECTED_ACHIEVEMENT_URL
        clinicallyRelevantDateValue == "2019-06-19T21:09:29Z"
        achievementStatus.getDisplay().toString() == "Not Met"
        category.getDisplay().toString() == "Nursing Outcome"
        target == "*Screening BMI Annual"
        annotation.getText().toString() == "The patient is making progress"
        description.getDisplay().toString() == "Body Mass Index (BMI) Monitoring Goal"
        lastUpdated.substring(0, 10) == "2019-03-13"
        presenceStateCode.getDisplay().toString() == "Present"
        valueString == "126"

        referenceIds.getValue().toString() == "[\"1234463535\"]"
        extensionSen.getValue().toString() == "[\"Body Image\"]"
        extensionDat.getValue().toString() == "[\"Repurposed Data Method\"]"
    }
}
