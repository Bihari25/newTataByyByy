package com.ihr.oea.comparator.fdb

import org.apache.log4j.Logger
import org.apache.spark.sql.SparkSession
import org.apache.spark.sql.functions.col
import org.apache.spark.sql.functions.lit
import org.apache.spark.sql.functions.count
import org.apache.spark.sql.functions.concat_ws
import org.apache.spark.sql.functions._
import org.apache.spark.sql.types.StructField
import org.apache.spark.sql.types.StructType
import com.ihr.oea.common.GlobalConstants
import com.ihr.oea.common.OESConfiguration
import com.ihr.oea.common.SparkSQLConstants
import com.ihr.oea.dao.MongoDAO
import com.ihr.oea.util.ComparatorUtil
import org.apache.spark.sql.types.StringType

class FdbEditMapWorklist {

  val log = Logger.getLogger(getClass.getName)
  
   def buildEditCodesSchema(): StructType = {
    val schema = StructType(
      Array(
         StructField(SparkSQLConstants.RELEASE_ID, StringType, true),  
        StructField(SparkSQLConstants.TAXONOMY_FSN, StringType, true),
        StructField(SparkSQLConstants.CONCEPT_ID, StringType, true),
        StructField(SparkSQLConstants.PREFERRED_TERM, StringType, true),
        StructField(SparkSQLConstants.TYPE, StringType, true),
        StructField(SparkSQLConstants.STATUS, StringType, true),
        StructField(SparkSQLConstants.GEN_MED_ID, StringType, true),
        StructField(SparkSQLConstants.REL_PREFERRED_TERM, StringType, true),
        StructField(SparkSQLConstants.REL_TYPE, StringType, true),
        StructField(SparkSQLConstants.REL_STATUS, StringType, true),
        StructField(SparkSQLConstants.REL_GEN_MEDID, StringType, true),
 	StructField(SparkSQLConstants.CHANGECODE_FLAG, StringType, true),
        StructField(SparkSQLConstants.WORKLIST_TYPE, StringType, true),
        StructField(SparkSQLConstants.WORKLIST_ID, StringType, true)))
    schema
  }
  
  def generateFdbEditMapWorklist(spark: SparkSession, oesConfiguration: OESConfiguration, releaseID: String) {
    try {

      log.info("Running data comparator for Edit Map worklist for Fdb releaseId : " + releaseID)
      log.info("loading edit codes for Fdb releaseId : " + releaseID)

      val mongoDAO = new MongoDAO
      log.info("Finding  distinct taxonomies in release data for Fdb releaseId : " + releaseID)      
  

       val ihrOntologyFile = GlobalConstants.fdbIHRAnnotationMap    

        
      val editWorkListData = spark.read.format(GlobalConstants.SPARK_DEFAULT_MONGO_DATASOURCE)
        .option(GlobalConstants.DATABASE,  oesConfiguration.DATABASE_NAME)
        .option(GlobalConstants.COLLECTION, GlobalConstants.WORKLIST_ITEMS)
        .schema(buildEditCodesSchema())
        .load().filter(col(SparkSQLConstants.RELEASE_ID) === releaseID && col(SparkSQLConstants.WORKLIST_TYPE) === GlobalConstants.EDIT_CODES)
       
      // Find the distinct taxonomies in the release from the MongoDB
      val util = new ComparatorUtil
      val fdbCorputil = new FdbCompareUtil
      var taxonomyStack = util.findDistinctTaxonomy(editWorkListData)
      var count = 1
      var worklistId = GlobalConstants.EMPTY_STRING
      var currentTime = GlobalConstants.EMPTY_STRING

      while (taxonomyStack.nonEmpty) {
        val taxonomyName = taxonomyStack.pop
        try {
          val workListID = fdbCorputil.getWorklistID(editWorkListData, taxonomyName)
          
          
         var sourceEditCodesDF = spark.read.format(GlobalConstants.SPARK_DEFAULT_MONGO_DATASOURCE)
        .option(GlobalConstants.DATABASE,  oesConfiguration.DATABASE_NAME)
        .option(GlobalConstants.COLLECTION, GlobalConstants.WORKLIST_ITEMS)
        .schema(buildEditCodesSchema())
        .load().filter(col(SparkSQLConstants.WORKLIST_ID) === workListID)
          
            
           sourceEditCodesDF = sourceEditCodesDF.select(GlobalConstants.STAR)
                               .withColumn(SparkSQLConstants.PREFERRED_TERM_EN, col(SparkSQLConstants.REL_PREFERRED_TERM))
                               .withColumn(SparkSQLConstants.PREFERRED_TERM, col(SparkSQLConstants.REL_PREFERRED_TERM))
                               .withColumn(SparkSQLConstants.GEN_MED_ID, when(col(SparkSQLConstants.REL_GEN_MEDID) === null, null)
                                                                        .otherwise(col(SparkSQLConstants.REL_GEN_MEDID)))
                               .withColumn(SparkSQLConstants.STATUS, col(SparkSQLConstants.REL_STATUS))
                               .withColumn(SparkSQLConstants.TYPE, when(col(SparkSQLConstants.REL_TYPE) === null, null)
                                                                  .otherwise(col(SparkSQLConstants.REL_TYPE)))
                               
                                           
          var sourceCodesExt =   sourceEditCodesDF.select(GlobalConstants.STAR)
                               .withColumn(SparkSQLConstants.PREFERRED_TERM_EN, fdbCorputil.replaceString(col(SparkSQLConstants.PREFERRED_TERM)))     
                         

         sourceCodesExt =   sourceCodesExt.select(GlobalConstants.STAR)
                               .filter(col(SparkSQLConstants.PREFERRED_TERM_EN).isNotNull)                               
                        
          var sourceCodes = sourceEditCodesDF.union(sourceCodesExt)
      
          log.info("generating edit direct map worklist data for taxonomy " + taxonomyName + " for Fdb releaseId : " + releaseID)
          // edit  Map codes
          worklistId = releaseID + GlobalConstants.W + count + GlobalConstants.UNDER_SCORE + GlobalConstants.WORKLIST_EDIT_UNMATCHED_DIRECT_MAP
          
          var sourceSCCodes = fdbCorputil.generateFdbSCEditMapData(taxonomyName,  sourceCodes, GlobalConstants.EDIT_CODES, spark, oesConfiguration, releaseID)
       
          val editIhrDirectCodes = fdbCorputil.generateFdbIhrMapData(taxonomyName, sourceSCCodes, GlobalConstants.EDIT_CODES, spark, oesConfiguration, releaseID)
          
          var editUnmatchedCodes = fdbCorputil.generateFdbSCMapData(taxonomyName, editIhrDirectCodes, sourceSCCodes, GlobalConstants.EDIT_CODES, spark, oesConfiguration, releaseID)
         
          editUnmatchedCodes = editUnmatchedCodes.union(editIhrDirectCodes).dropDuplicates(SparkSQLConstants.CONCEPT_ID, SparkSQLConstants.IHR_MAP)
             .select(
              SparkSQLConstants.TAXONOMY_FSN,
              SparkSQLConstants.CONCEPT_ID,
              SparkSQLConstants.TYPE,
              SparkSQLConstants.PREFERRED_TERM,
              SparkSQLConstants.STATUS,
              SparkSQLConstants.GEN_MED_ID,
              SparkSQLConstants.IHR_MAP,
              SparkSQLConstants.MATCH_TYPE,
              SparkSQLConstants.MATCH_VALUE,
              SparkSQLConstants.MSP_DDID,SparkSQLConstants.MSP_PNID,SparkSQLConstants.MSP_RPID,
              SparkSQLConstants.CHANGECODE_FLAG,
              SparkSQLConstants.SUPER_CLASS_STATUS)
              .withColumnRenamed(SparkSQLConstants.MSP_DDID, SparkSQLConstants.mspDdId)
              .withColumnRenamed(SparkSQLConstants.MSP_PNID, SparkSQLConstants.mspPnId)
              .withColumn(SparkSQLConstants.SUPERCLASS_LABEL, lit(GlobalConstants.DEFAULT_NO_MAP))
              .withColumn(SparkSQLConstants.ACTION_STATUS, lit(GlobalConstants.REVIEW_PENDING))
              .withColumn(SparkSQLConstants.WORKLIST_ID, lit(worklistId))
              .withColumn(SparkSQLConstants.RELEASE_ID, lit(releaseID))
              .withColumn(SparkSQLConstants.WORKLIST_TYPE, lit(GlobalConstants.EDIT_UNMATCHED_DIRECT_MAP))
              .cache()
          //writing edit data into mongo
          log.info("saving  edit direct map worklist data for taxonomy " + taxonomyName + " for Fdb releaseId : " + releaseID)
          mongoDAO.writeDataFrameToMongo(GlobalConstants.WORKLIST_ITEMS, editUnmatchedCodes)
          log.info("saved successfully edit direct map worklist data for taxonomy " + taxonomyName + " for Fdb releaseId : " + releaseID)

          // edit Unmatched Map codes
          log.info("generating edit Unmatched map worklist data for taxonomy " + taxonomyName + " for Fdb releaseId : " + releaseID)
          worklistId = releaseID + GlobalConstants.W + count + GlobalConstants.UNDER_SCORE + GlobalConstants.WORKLIST_EDIT_UNMATCHED
          var editNoMachedCodes = sourceSCCodes.join(editUnmatchedCodes, editUnmatchedCodes(SparkSQLConstants.CONCEPT_ID) === sourceSCCodes(SparkSQLConstants.CONCEPT_ID),
            SparkSQLConstants.ANTI_LEFT_JOIN)
          editNoMachedCodes = editNoMachedCodes.select(
                SparkSQLConstants.TAXONOMY_FSN,
                SparkSQLConstants.CONCEPT_ID,
                SparkSQLConstants.TYPE,
                SparkSQLConstants.PREFERRED_TERM,
                SparkSQLConstants.STATUS,
                SparkSQLConstants.CHANGECODE_FLAG,
                SparkSQLConstants.GEN_MED_ID)
              .withColumn(SparkSQLConstants.IHR_MAP, lit(GlobalConstants.DEFAULT_NO_MAP))
              .withColumn(SparkSQLConstants.SUPERCLASS_LABEL, lit(GlobalConstants.DEFAULT_NO_MAP))
              .withColumn(SparkSQLConstants.ACTION_STATUS, lit(GlobalConstants.MANUALLY_PROCESSED))
              .withColumn(SparkSQLConstants.WORKLIST_ID, lit(worklistId))
              .withColumn(SparkSQLConstants.RELEASE_ID, lit(releaseID))
              .withColumn(SparkSQLConstants.WORKLIST_TYPE, lit(GlobalConstants.EDIT_UNMATCHED))
              .cache().dropDuplicates(SparkSQLConstants.CONCEPT_ID, SparkSQLConstants.PREFERRED_TERM)

          //writing edit data into mongo
          log.info("saving  edit Unmatched map worklist data for taxonomy " + taxonomyName + " for Fdb releaseId : " + releaseID)
          mongoDAO.writeDataFrameToMongo(GlobalConstants.WORKLIST_ITEMS, editNoMachedCodes)
          log.info("saved successfully edit Unmatched map worklist data for taxonomy " + taxonomyName + " for Fdb releaseId : " + releaseID)
          count += 1
        } catch {
          case e: Exception =>
            log.error(s"Exception while running data comparator taxonomy " + taxonomyName + " for edit Map Worklist for Fdb releaseId : " + releaseID+e.printStackTrace())
            log.error(e.printStackTrace())
        }
      }
      log.info("Completed data comparator for edit Map Worklists for Fdb releaseId : " + releaseID)
    } catch {
      case e: Exception =>
        log.error(s"Exception while running data comparator for edit Map Worklists for Fdb releaseId : " + releaseID)
        log.error(e.printStackTrace())
      //throw e
    }
  }
}
