package com.ihr.oea.worklist

import org.apache.spark.sql.SparkSession

import com.ihr.oea.common.OESConfiguration
import org.apache.log4j.Logger
import com.ihr.oea.comparator.quest.QuestAddEditWorklist
import com.ihr.oea.comparator.quest.QuestAddMapWorklist
import com.ihr.oea.comparator.quest.QuestEditMapWorklist


class QuestWorklistFactory {
  val log = Logger.getLogger(getClass.getName)

  @throws(classOf[Exception])
  def generateQuestWorklist(spark: SparkSession, oesConfiguration: OESConfiguration, releaseId: String) {
    log.info("Running  data comparator for quest releaseId : " + releaseId)

    val addEditWorklist = new QuestAddEditWorklist
    addEditWorklist.generateQuestAddEditWorklist(spark, oesConfiguration, releaseId)
    
    val addMapWorklist = new QuestAddMapWorklist
   addMapWorklist.generateQuestAddMapWorklist(spark, oesConfiguration, releaseId)
   
    val editMapWorklist = new QuestEditMapWorklist
    editMapWorklist.generateQuestEditMapWorklist(spark, oesConfiguration, releaseId)
    
    val workBenchData = new WorkBenchData
    workBenchData.generateWorkBenchData(spark, oesConfiguration, releaseId);

    log.info("Completed  data comparator for loinc releaseId : " + releaseId)
  }
}