package com.ihr.oea.util

import org.apache.spark.sql.DataFrame
import com.ihr.oea.common.SparkSQLConstants
import scala.collection.mutable.Stack
import org.apache.spark.sql.functions.col
import org.apache.log4j.Logger
import scala.collection.mutable.WrappedArray
import org.apache.spark.sql.functions.udf
import org.apache.spark.sql.functions.split
import com.ihr.oea.common.GlobalConstants
import org.apache.spark.sql.functions.when
import org.apache.spark.sql.functions.concat_ws

class ComparatorUtil {
 // val log = Logger.getLogger(getClass.getName)
  
  @throws(classOf[Exception])
  def findDistinctTaxonomy(dataframe: DataFrame): Stack[String] = {
      // Create a stack to process the taxonomy data
      var taxonomyStack = Stack[String]()
      // Populate the stack for FIFO processing
      val taxonomyList = dataframe.select(col(SparkSQLConstants.TAXONOMY_FSN)).distinct
      taxonomyList.collect().foreach {
        taxRow =>
          taxRow.toSeq.foreach {
            taxonomy => taxonomyStack.push(taxonomy.asInstanceOf[String])
          }
      }
    taxonomyStack
  }
  
  
  def jumbledDataframes(df1: DataFrame, df2: DataFrame, codeType: String): DataFrame = {
   
     
     var sourceAddCodesData = df1.sort(SparkSQLConstants.PREFERRED_TERM)
    var ihrOntologyData = df2.sort(SparkSQLConstants.PREFERRED_TERM_EN, SparkSQLConstants.LABEL1, SparkSQLConstants.ALIAS_TERM_EN)

      var addDirectMapCodesData = sourceAddCodesData.join(
      ihrOntologyData,
       same_array(split(sourceAddCodesData(SparkSQLConstants.PREFERRED_TERM),GlobalConstants.SPACE), split(ihrOntologyData(SparkSQLConstants.PREFERRED_TERM_EN),GlobalConstants.SPACE)) ||
        same_pt_label(sourceAddCodesData(SparkSQLConstants.PREFERRED_TERM), ihrOntologyData(SparkSQLConstants.LABEL1)) ||
        pt_in_alias(split(sourceAddCodesData(SparkSQLConstants.PREFERRED_TERM),GlobalConstants.SPACE), ihrOntologyData(SparkSQLConstants.ALIAS_TERM_EN)))
      .withColumn(SparkSQLConstants.ALIAS_TERM, ihrOntologyData(SparkSQLConstants.ALIAS_TERM_EN))
      .withColumn(SparkSQLConstants.IHR_MAP, ihrOntologyData(SparkSQLConstants.LABEL1))
      .withColumn(
        SparkSQLConstants.MATCH_RANK,
        when(same_array(split(sourceAddCodesData(SparkSQLConstants.PREFERRED_TERM),GlobalConstants.SPACE), split(ihrOntologyData(SparkSQLConstants.PREFERRED_TERM_EN),GlobalConstants.SPACE)), 9)
          .when(same_pt_label(sourceAddCodesData(SparkSQLConstants.PREFERRED_TERM), ihrOntologyData(SparkSQLConstants.LABEL1)), 8)
         .when(pt_in_alias(split(sourceAddCodesData(SparkSQLConstants.PREFERRED_TERM),GlobalConstants.SPACE), ihrOntologyData(SparkSQLConstants.ALIAS_TERM_EN)), 7))
          .withColumn(SparkSQLConstants.MATCH_VALUE, concat_ws(
        GlobalConstants.COMMA,
        ihrOntologyData(SparkSQLConstants.LABEL1), ihrOntologyData(SparkSQLConstants.PREFERRED_TERM_EN),
        concat_ws(GlobalConstants.PIPE, ihrOntologyData(SparkSQLConstants.ALIAS_TERM_EN))))
    addDirectMapCodesData
  }
  
   //pt-label
    val same_pt_label = udf((t: String, t2: String) => {
      if (t != null && t2 != null  && t2.length() > 0) {
        var label = GlobalConstants.EMPTY_STRING
        if (t2.contains(GlobalConstants.SQUARE_BRACKET))
          label = t2.substring(0, t2.lastIndexOf(GlobalConstants.SQUARE_BRACKET))
        else
          label = t2
          
          var arrLabel = label.split(GlobalConstants.SPACE)
          var t1 = t.split(GlobalConstants.SPACE)
      
            if (t1 != null && arrLabel != null && t1.length == arrLabel.length &&
          (t1.map(_.trim().toLowerCase()).intersect(arrLabel.map(_.trim().toLowerCase())).length == arrLabel.length))
          { true }  
        else if (t1 == null && arrLabel == null) { true }
        else if ((t1 == null && arrLabel != null) || (arrLabel == null && t1 != null)) { false }        
        else { false }

      
      } else false
    })
//pt-alias
    def pt_in_alias = udf((pt: WrappedArray[String], alias: WrappedArray[String]) => { 
        var result :Boolean = false
         if(null==pt || pt.equals(GlobalConstants.EMPTY_STRING) || null==alias ||  alias.equals(GlobalConstants.EMPTY_STRING)){
                                 false
                } else{
                    for (aliasVal <- alias) {
                      var t2 :WrappedArray[String] = aliasVal.split(GlobalConstants.SPACE)
                       if (pt != null && t2 != null && pt.length == t2.length && (pt.map(_.trim().toLowerCase()).intersect(t2.map(_.trim().toLowerCase())).length == t2.length)){
                         result = true                         
                       }
                }
                 result
             }
      })
              
  val same_fsn_pten = udf((t1: String, t2: String) => {
      if (t1 != null && t2 != null && t1.length() > 0 && t2.length() > 0) {
        var fsn = GlobalConstants.EMPTY_STRING
        if (t1.contains(GlobalConstants.ROUND_BRACKET))
          fsn = t1.substring(0, t1.lastIndexOf(GlobalConstants.ROUND_BRACKET))
        else
          fsn = t1        
        var arrFsn = fsn.split(GlobalConstants.SPACE)
          var pt = t2.split(GlobalConstants.SPACE)      
            if (pt != null && arrFsn != null && pt.length == arrFsn.length &&
          (arrFsn.map(_.trim().toLowerCase()).intersect(pt.map(_.trim().toLowerCase())).length == pt.length))
          { true }  
        else if (pt == null && arrFsn == null) { true }
        else if ((pt == null && arrFsn != null) || (arrFsn == null && pt != null)) { false }        
        else { false }
      } else false
    })

 val same_fsn_label = udf((t1: String, t2: String) => {
      if (t1 != null && t2 != null && t1.length() > 0 && t2.length() > 0) {
        var fsn = GlobalConstants.EMPTY_STRING
        var label = GlobalConstants.EMPTY_STRING
        if (t1.contains(GlobalConstants.ROUND_BRACKET))
          fsn = t1.substring(0, t1.lastIndexOf(GlobalConstants.ROUND_BRACKET))
        else
          fsn = t1          
        if (t2.contains(GlobalConstants.SQUARE_BRACKET))
          label = t2.substring(0, t2.lastIndexOf(GlobalConstants.SQUARE_BRACKET))
        else
          label = t2
        var arrFsn = fsn.split(GlobalConstants.SPACE)
        var arrlabel = label.split(GlobalConstants.SPACE)
        if (arrlabel != null && arrFsn != null && arrlabel.length == arrFsn.length &&
          (arrFsn.map(_.trim().toLowerCase()).intersect(arrlabel.map(_.trim().toLowerCase())).length == arrlabel.length))
          { true }  
        else if (arrlabel == null && arrFsn == null) { true }
        else if ((arrlabel == null && arrFsn != null) || (arrFsn == null && arrlabel != null)) { false }        
        else { false }
      } else false
    })
    
    
     def fsn_in_alias = udf((fsnVal: String, alias: WrappedArray[String]) => { 
        var result :Boolean = false
         if(null==fsnVal || fsnVal.equals(GlobalConstants.EMPTY_STRING) || null==alias ||  alias.equals(GlobalConstants.EMPTY_STRING)){
                                 false
                } else{
                   var fsn = GlobalConstants.EMPTY_STRING
                      if (fsnVal.contains(GlobalConstants.ROUND_BRACKET))
                        fsn = fsnVal.substring(0, fsnVal.lastIndexOf(GlobalConstants.ROUND_BRACKET))
                      else
                        fsn = fsnVal
                   
                         var arrVal :WrappedArray[String] = fsn.split(GlobalConstants.SPACE)
                        
                    for (aliasVal <- alias) {
                      var t2 :WrappedArray[String] = aliasVal.split(GlobalConstants.SPACE)
                       if (arrVal != null && t2 != null && arrVal.length == t2.length && (arrVal.map(_.trim().toLowerCase()).intersect(t2.map(_.trim().toLowerCase())).length == t2.length)){
                         result = true                         
                       }
                }
                 result
             }
         })
         
     val syn_in_pten = udf(( alias: WrappedArray[String], pt: WrappedArray[String]) => { 
        var result :Boolean = false
         if(null==pt || pt.equals(GlobalConstants.EMPTY_STRING) || null==alias ||  alias.equals(GlobalConstants.EMPTY_STRING)){
                                 false
                } else{
                    for (aliasVal <- alias) {
                      var syn :WrappedArray[String] = aliasVal.split(GlobalConstants.SPACE)
                       if (syn != null && pt != null && syn.length == pt.length && (syn.map(_.trim().toLowerCase()).intersect(pt.map(_.trim().toLowerCase())).length == pt.length)){
                         result = true                         
                       }
                }
                 result
             }
      })
    
     val syn_in_label = udf((alias: WrappedArray[String], label : String)=>{
       var t2 = GlobalConstants.EMPTY_STRING
       var result :Boolean = false
         if(null == label || label.equals(GlobalConstants.EMPTY_STRING) || null == alias || alias.equals(GlobalConstants.EMPTY_STRING)){
           false
         }
         else{
           if (label.contains(GlobalConstants.SQUARE_BRACKET))
            t2 = label.substring(0, label.lastIndexOf(GlobalConstants.SQUARE_BRACKET))
          else
            t2 = label
            var arrlabel = t2.split(GlobalConstants.SPACE)
           for(aliasVal <- alias){
               var syn :WrappedArray[String] = aliasVal.split(GlobalConstants.SPACE)
               if (syn != null && arrlabel != null && syn.length == arrlabel.length && (syn.map(_.trim().toLowerCase()).intersect(arrlabel.map(_.trim().toLowerCase())).length == arrlabel.length)){
                         result = true                         
                 }
           }
           result
         }
     })
     val syn_in_alias = udf((syn: WrappedArray[String], alias: WrappedArray[String])=>{
        var result :Boolean = false
         if(null==syn || syn.equals(GlobalConstants.EMPTY_STRING) || null==alias ||  alias.equals(GlobalConstants.EMPTY_STRING)){
                false
         } else{
             for(synVal <- syn){
               var syn_data : WrappedArray[String] = synVal.split(GlobalConstants.SPACE)
                 for(aliasVal <- alias ){
                    var alias_data : WrappedArray[String] = aliasVal.split(GlobalConstants.SPACE)
                      if(alias_data !=null && syn_data != null && alias_data.length == syn_data.length && (alias_data.map(_.trim().toLowerCase()).intersect(syn_data.map(_.trim().toLowerCase())).length == syn_data.length)){
                        result = true
                      }
                 }
             }
             result
         }
     })
   val same_array = udf { (t1: WrappedArray[String], t2: WrappedArray[String]) =>
		     if (t1 != null && t2 != null && t1.length == t2.length &&
          (t1.map(_.trim().toLowerCase()).intersect(t2.map(_.trim().toLowerCase())).length == t2.length))
          { true }  
        else if (t1 == null && t2 == null) { true }
        else if ((t1 == null && t2 != null) || (t2 == null && t1 != null)) { false }        
        else { false }
   }
}