package com.ihr.oea.worklist

import org.apache.spark.sql.SparkSession

import com.ihr.oea.common.OESConfiguration
import com.ihr.oea.comparator.loinc.LoincAddEditWorklist
import org.apache.log4j.Logger
import com.ihr.oea.comparator.snomed.SnomedEditMapWorklist
import com.ihr.oea.comparator.loinc.LoincAddMapWorklist
import com.ihr.oea.comparator.loinc.LoincEditMapWorklist

class LoincWorklistFactory {
  val log = Logger.getLogger(getClass.getName)

  @throws(classOf[Exception])
  def generateLoincWorklist(spark: SparkSession, oesConfiguration: OESConfiguration, releaseId: String) {
    log.info("Running  data comparator for loinc releaseId : " + releaseId)

    val addEditWorklist = new LoincAddEditWorklist
    addEditWorklist.generateLoincAddEditWorklist(spark, oesConfiguration, releaseId)

    val addMapWorklist = new LoincAddMapWorklist
    addMapWorklist.generateLoincAddMapWorklist(spark, oesConfiguration, releaseId)

    val editMapWorklist = new LoincEditMapWorklist
    editMapWorklist.generateLoincEditMapWorklist(spark, oesConfiguration, releaseId)

    val workBenchData = new WorkBenchData
    workBenchData.generateWorkBenchData(spark, oesConfiguration, releaseId);

    log.info("Completed  data comparator for loinc releaseId : " + releaseId)
  }
}