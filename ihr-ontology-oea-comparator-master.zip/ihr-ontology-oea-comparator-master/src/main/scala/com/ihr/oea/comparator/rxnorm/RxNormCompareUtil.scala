package com.ihr.oea.comparator.rxnorm

import scala.collection.mutable.WrappedArray
import scala.util.control.Breaks

import org.apache.log4j.Logger
import org.apache.spark.sql.DataFrame
import org.apache.spark.sql.functions._
import org.apache.spark.sql.SparkSession
import org.apache.spark.sql.functions.col
import org.apache.spark.sql.functions.lit
import org.apache.spark.sql.functions.max
import org.apache.spark.sql.functions.split
import org.apache.spark.sql.functions.udf
import org.apache.spark.sql.functions.when
import java.util.ArrayList
import com.ihr.oea.common.GlobalConstants
import com.ihr.oea.common.OESConfiguration
import com.ihr.oea.common.SparkSQLConstants
import org.apache.spark.sql.types.StringType
import org.apache.spark.sql.types.StructField
import org.apache.spark.sql.types.StructType
import org.apache.spark.sql.types.ArrayType
import org.apache.spark.sql.Row
import scala.util.control._
@throws(classOf[Exception])
class RxNormCompareUtil extends Serializable {
  @transient lazy val log = Logger.getLogger(getClass.getName)
  
  def buildSchema(): StructType = {
    val schema = StructType(
      Array(
        StructField(SparkSQLConstants.TAXONOMY_FSN, StringType, true),
        StructField(SparkSQLConstants.CONCEPT_ID, StringType, true),
        StructField(SparkSQLConstants.RXCUI, StringType, true),
        StructField(SparkSQLConstants.STR, StringType, true),       
        StructField(SparkSQLConstants.UNIICODE, StringType, true),
        StructField(SparkSQLConstants.IHR_MAP, StringType, true),       
        StructField(SparkSQLConstants.MATCH_TYPE, StringType, true),
        StructField(SparkSQLConstants.MATCH_VALUE, StringType, true),
        StructField(SparkSQLConstants.MSP_DDID, StringType, true),
        StructField(SparkSQLConstants.MSP_PNID, StringType, true),
        StructField(SparkSQLConstants.MSP_RPID, StringType, true),
        StructField(SparkSQLConstants.MSP_GPI, StringType, true),
        StructField(SparkSQLConstants.GENERICNAME, StringType, true),
        StructField(SparkSQLConstants.CHANGECODE_FLAG, StringType, true),
        StructField(SparkSQLConstants.SUPER_CLASS_STATUS, StringType, true)
        ))
    schema
  }
  
    def buildscCodesSchema(): StructType = {
    val schema = StructType(
      Array(
        StructField(SparkSQLConstants.TAXONOMY_FSN, StringType, true),
        StructField(SparkSQLConstants.CONCEPT_ID, StringType, true),
        StructField(SparkSQLConstants.RXCUI, StringType, true),
        StructField(SparkSQLConstants.STR, StringType, true),       
        StructField(SparkSQLConstants.UNIICODE, StringType, true),
        StructField(SparkSQLConstants.IHR_MAP, StringType, true),       
        StructField(SparkSQLConstants.MATCH_TYPE, StringType, true),
        StructField(SparkSQLConstants.MATCH_VALUE, StringType, true),
        StructField(SparkSQLConstants.MSP_DDID, StringType, true),
        StructField(SparkSQLConstants.MSP_PNID, StringType, true),
        StructField(SparkSQLConstants.MSP_RPID, StringType, true),
        StructField(SparkSQLConstants.MSP_GPI, StringType, true),
        StructField(SparkSQLConstants.GENERICNAME, StringType, true),
        StructField(SparkSQLConstants.IHR_MAP, StringType, true),
        StructField(SparkSQLConstants.SUPERCLASS_LABEL, StringType, true),
        StructField(SparkSQLConstants.SUPER_CLASS_STATUS, StringType, true)
        ))
    schema
  }


    val same_array = udf { (t1: WrappedArray[String], t2: WrappedArray[String]) =>
		     if (t1 != null && t2 != null && t1.length == t2.length &&
          (t1.map(_.trim().toLowerCase()).intersect(t2.map(_.trim().toLowerCase())).length == t2.length) && t2.length!=0)
          {
		       true }  
        else if (t1 == null && t2 == null) { 
          false }
        else if ((t1 == null && t2 != null) || (t2 == null && t1 != null)) {
          false }        
        else { 
          false }
   }
    

  def generateRxNormIhrMapData(taxonomyName: String, sourceCodes: DataFrame, codeType: String, spark: SparkSession, oesConfiguration: OESConfiguration, releaseID: String): DataFrame = {
  
    log.info("generating annotations files path taxonomy " + taxonomyName + " for RxNorm releaseId : " + releaseID)   
    var ihrAnnotationBasePath = oesConfiguration.BASE_PATH + releaseID + GlobalConstants.FORWARD_SLASH + oesConfiguration.IHR_ANNOTATION_PATH + GlobalConstants.FORWARD_SLASH
    if (!oesConfiguration.PROFILE.equalsIgnoreCase(GlobalConstants.LOCAL_PROFILE)) {
      ihrAnnotationBasePath = ihrAnnotationBasePath.substring(5)
    }
    var sourceCodesDF = sourceCodes 
    var directCodes =  SparkSession.builder().getOrCreate().emptyDataFrame
    var mapKey = taxonomyName

     var ihrDirectCodes = spark.createDataFrame(spark.sparkContext.emptyRDD[Row], buildSchema())
     
     val ihrFileName = GlobalConstants.rxnormIHRAnnotationMap
     var ihrOntologyData = SparkSession.builder().getOrCreate().emptyDataFrame
     var ihrProductDeviceData = SparkSession.builder().getOrCreate().emptyDataFrame
     var ihrProductMedicationData = SparkSession.builder().getOrCreate().emptyDataFrame
     for(ihrOntologyFile <- ihrFileName ) {
     log.info("ihrFileName..."+ihrOntologyFile);
     if (null != ihrOntologyFile) {
          log.info("Loading IHR annotation data for taxonomy " + taxonomyName + " for RxNorm releaseId : " + releaseID)        
          ihrOntologyData = loadIHRDumpData(spark, ihrAnnotationBasePath ,ihrOntologyFile)
                               .cache()
    
      log.info("comparing data and IHR annotation data for taxonomy " + taxonomyName + " for RxNorm releaseId : " + releaseID)     
      ihrOntologyData = compareDataframes(sourceCodesDF, ihrOntologyData, codeType,SparkSQLConstants.ASIS,false) 
         
      ihrOntologyData = getIHRMatchType(ihrOntologyData,ihrOntologyFile)
        .select(
          SparkSQLConstants.TAXONOMY_FSN,
          SparkSQLConstants.CONCEPT_ID,
          SparkSQLConstants.RXCUI,
          SparkSQLConstants.STR,
          SparkSQLConstants.UNIICODE,
          SparkSQLConstants.IHR_MAP,
          SparkSQLConstants.MATCH_TYPE,
          SparkSQLConstants.MATCH_VALUE,
          SparkSQLConstants.MSP_DDID,
          SparkSQLConstants.MSP_PNID,
          SparkSQLConstants.MSP_RPID,
          SparkSQLConstants.MSP_GPI,
          SparkSQLConstants.GENERICNAME,        
          SparkSQLConstants.SUPER_CLASS_STATUS,
          SparkSQLConstants.CHANGECODE_FLAG)
        .cache() 
        

      sourceCodesDF = sourceCodesDF.join(ihrOntologyData, ihrOntologyData(SparkSQLConstants.CONCEPT_ID) === sourceCodesDF(SparkSQLConstants.CONCEPT_ID),SparkSQLConstants.ANTI_LEFT_JOIN)
      directCodes = ihrOntologyData.dropDuplicates(SparkSQLConstants.CONCEPT_ID, SparkSQLConstants.IHR_MAP)
     }
    }

    directCodes    
}
  
def generateRxNormIhrMapDataReplacement(taxonomyName: String, sourceCodes: DataFrame, codeType: String, spark: SparkSession, oesConfiguration: OESConfiguration, releaseID: String,replaceFlag:Boolean): DataFrame = {

log.info("generating annotations files path taxonomy " + taxonomyName + " for RxNorm releaseId : " + releaseID)

 
    var ihrAnnotationBasePath = oesConfiguration.BASE_PATH + releaseID + GlobalConstants.FORWARD_SLASH + oesConfiguration.IHR_ANNOTATION_PATH + GlobalConstants.FORWARD_SLASH
    if (!oesConfiguration.PROFILE.equalsIgnoreCase(GlobalConstants.LOCAL_PROFILE)) {
      ihrAnnotationBasePath = ihrAnnotationBasePath.substring(5)
    }
    var sourceCodesDF = sourceCodes 
    var directCodes =  SparkSession.builder().getOrCreate().emptyDataFrame
    var mapKey = taxonomyName
  
     var ihrDirectCodes = spark.createDataFrame(spark.sparkContext.emptyRDD[Row], buildSchema())
     
     val ihrFileName = GlobalConstants.rxnormIHRAnnotationMap1
     var ihrOntologyData = SparkSession.builder().getOrCreate().emptyDataFrame
     
     var ihrProductMedicationData = SparkSession.builder().getOrCreate().emptyDataFrame
     for(ihrOntologyFile <- ihrFileName ) {
     log.info("ihrFileName..."+ihrOntologyFile);
      if (null != ihrOntologyFile) {
        log.info("Loading IHR annotation data for taxonomy " + taxonomyName + " for RxNorm releaseId : " + releaseID)        
        ihrOntologyData = loadIHRDumpData(spark, ihrAnnotationBasePath ,ihrOntologyFile)
                             .cache()
                             

      val rxnormCorputil = new RxNormCompareUtil
     ihrOntologyData=ihrOntologyData.withColumn(SparkSQLConstants.PREFERRED_TERM_EN1,  rxnormCorputil.replaceString(col(SparkSQLConstants.PREFERRED_TERM_EN))).cache()         
     ihrOntologyData=ihrOntologyData.withColumn(SparkSQLConstants.LABEL11,  rxnormCorputil.replaceString(col(SparkSQLConstants.LABEL1))).cache()
     ihrOntologyData=ihrOntologyData.withColumn(SparkSQLConstants.ALIAS_TERM_EN1,  rxnormCorputil.replaceString(col(SparkSQLConstants.ALIAS_TERM_EN))).cache()
  
     log.info("comparing data and IHR annotation data for taxonomy " + taxonomyName + " for RxNorm releaseId : " + releaseID)     
     ihrOntologyData = compareDataframes(sourceCodesDF, ihrOntologyData, codeType,SparkSQLConstants.REPLACEMENT,true) 

      ihrOntologyData = getIHRMatchType(ihrOntologyData,ihrOntologyFile)
        .select(
          SparkSQLConstants.TAXONOMY_FSN,
          SparkSQLConstants.CONCEPT_ID,
          SparkSQLConstants.RXCUI,
          SparkSQLConstants.STR,
          SparkSQLConstants.UNIICODE,
          SparkSQLConstants.IHR_MAP,
          SparkSQLConstants.MATCH_TYPE,
          SparkSQLConstants.MATCH_VALUE,
          SparkSQLConstants.MSP_DDID,
          SparkSQLConstants.MSP_PNID,
          SparkSQLConstants.MSP_RPID,
          SparkSQLConstants.MSP_GPI,
          SparkSQLConstants.GENERICNAME,        
          SparkSQLConstants.SUPER_CLASS_STATUS,
          SparkSQLConstants.CHANGECODE_FLAG)
        .cache()     

      sourceCodesDF = sourceCodesDF.join(ihrOntologyData, ihrOntologyData(SparkSQLConstants.CONCEPT_ID) === sourceCodesDF(SparkSQLConstants.CONCEPT_ID),SparkSQLConstants.ANTI_LEFT_JOIN) 
      directCodes = ihrOntologyData.dropDuplicates(SparkSQLConstants.CONCEPT_ID, SparkSQLConstants.IHR_MAP)
     }
    }

    directCodes    
}

 def generateRxNormSCMapData(taxonomyName: String,  sourceCodes: DataFrame, ihrCodes: DataFrame,codeType: String, spark: SparkSession, oesConfiguration: OESConfiguration, releaseID: String): DataFrame = {
    
        var superClassBasePath = oesConfiguration.BASE_PATH + releaseID + GlobalConstants.FORWARD_SLASH + oesConfiguration.SUPERCLASS_DUMP_PATH + GlobalConstants.FORWARD_SLASH
    if (!oesConfiguration.PROFILE.equalsIgnoreCase(GlobalConstants.LOCAL_PROFILE)) {
      superClassBasePath = superClassBasePath.substring(5)
    }
    
         var scCodes = spark.createDataFrame(spark.sparkContext.emptyRDD[Row], buildSchema())    
     var rxnormSCDump = GlobalConstants.RXNORMSCDUMP
       var sourceDF = sourceCodes
       var rxnormSuperClassData = loadSuperClassData(spark, superClassBasePath , rxnormSCDump)
       var taxonomyId = GlobalConstants.RXNORMTAXONOMYID
     
   val  sourceRxNormCodesDF = rxnormSuperClassData.join(ihrCodes,ihrCodes(SparkSQLConstants.CONCEPT_ID) === rxnormSuperClassData(SparkSQLConstants.SUPERCLASS_CONCEPT_ID), SparkSQLConstants.ANTI_LEFT_JOIN)
                                    
   val editSrcSupMapCodes = sourceRxNormCodesDF.join(sourceCodes, sourceCodes(SparkSQLConstants.CONCEPT_ID) === sourceRxNormCodesDF(SparkSQLConstants.SUPERCLASS_CONCEPT_ID)) 
                                 .withColumn(SparkSQLConstants.MATCH_TYPE, lit(GlobalConstants.EMPTY_STRING))
                   .withColumn(SparkSQLConstants.IHR_MAP, col(SparkSQLConstants.SUPERCLASS_LABEL))
                   .withColumn(SparkSQLConstants.MATCH_VALUE, lit(GlobalConstants.EMPTY_STRING))
                   .withColumn(SparkSQLConstants.SUPER_CLASS_STATUS, lit(GlobalConstants.EMPTY_STRING))
              .select(
               SparkSQLConstants.TAXONOMY_FSN,
                SparkSQLConstants.CONCEPT_ID,
                SparkSQLConstants.EFFECTIVE_TIME,
                sourceRxNormCodesDF.col(SparkSQLConstants.SUPERCLASS_LABEL).toString(),
                SparkSQLConstants.IHR_MAP,
                SparkSQLConstants.MATCH_TYPE,
                SparkSQLConstants.MATCH_VALUE,SparkSQLConstants.SUPER_CLASS_STATUS,sourceCodes.col(SparkSQLConstants.CHANGECODE_FLAG).toString())               
    editSrcSupMapCodes
   }

def generateRxNormSCEditMapData(taxonomyName: String,  sourceCodes: DataFrame,codeType: String, spark: SparkSession, oesConfiguration: OESConfiguration, releaseID: String): DataFrame = {
     
    var superClassBasePath = oesConfiguration.BASE_PATH + releaseID + GlobalConstants.FORWARD_SLASH + oesConfiguration.SUPERCLASS_DUMP_PATH + GlobalConstants.FORWARD_SLASH
    if (!oesConfiguration.PROFILE.equalsIgnoreCase(GlobalConstants.LOCAL_PROFILE)) {
      superClassBasePath = superClassBasePath.substring(5)
    }
     
     var scCodes = spark.createDataFrame(spark.sparkContext.emptyRDD[Row], buildSchema())    
     var rxnormSCDump = GlobalConstants.RXNORMSCDUMP
       var sourceDF = sourceCodes
       var rxnormSuperClassData = loadSuperClassData(spark, superClassBasePath , rxnormSCDump)
       var taxonomyId = GlobalConstants.RXNORMTAXONOMYID
       var rxnormtaxonomyId:String = taxonomyId+GlobalConstants.UNDER_SCORE

       sourceDF = sourceDF.select(GlobalConstants.STAR)
                .withColumn(SparkSQLConstants.RXNORM_TAXONOMYID,concat(lit(rxnormtaxonomyId),sourceDF.col(SparkSQLConstants.CONCEPT_ID)))

      
                 scCodes = sourceDF.join(rxnormSuperClassData, rxnormSuperClassData(SparkSQLConstants.CLASS_ID) === sourceDF(SparkSQLConstants.RXNORM_TAXONOMYID))
                   .select(GlobalConstants.STAR)
       scCodes
   }
  
 
  def compareDataframes(df1: DataFrame, df2: DataFrame, codeType: String,mappingType: String,replaceFlag: Boolean): DataFrame = {
    
    if(mappingType.equals(SparkSQLConstants.ASIS))
    {
      var sourceAddCodesData = df1.sort(SparkSQLConstants.STR)
    var ihrOntologyData = df2.sort(SparkSQLConstants.PREFERRED_TERM_EN, SparkSQLConstants.LABEL1, SparkSQLConstants.ALIAS_TERM_EN)
     var directMapCodesData = sourceAddCodesData.join(
      ihrOntologyData,
      same_array(split(sourceAddCodesData(SparkSQLConstants.STR),GlobalConstants.SPACE), split(ihrOntologyData(SparkSQLConstants.PREFERRED_TERM_EN),GlobalConstants.SPACE)) ||
      same_str_label(sourceAddCodesData(SparkSQLConstants.STR), ihrOntologyData(SparkSQLConstants.LABEL1)) ||
      str_in_alias(sourceAddCodesData(SparkSQLConstants.STR), ihrOntologyData(SparkSQLConstants.ALIAS_TERM_EN))    )
      .withColumn(SparkSQLConstants.ALIAS_TERM, ihrOntologyData(SparkSQLConstants.ALIAS_TERM_EN))
      .withColumn(SparkSQLConstants.IHR_MAP, ihrOntologyData(SparkSQLConstants.LABEL1))
      .withColumn(
        SparkSQLConstants.MATCH_RANK,
        when(same_array(split(sourceAddCodesData(SparkSQLConstants.STR),GlobalConstants.SPACE), split(ihrOntologyData(SparkSQLConstants.PREFERRED_TERM_EN),GlobalConstants.SPACE)), 9)
        .when(same_str_label(sourceAddCodesData(SparkSQLConstants.STR), ihrOntologyData(SparkSQLConstants.LABEL1)), 8)
        .when(str_in_alias(sourceAddCodesData(SparkSQLConstants.STR), ihrOntologyData(SparkSQLConstants.ALIAS_TERM_EN)), 7))
      .withColumn(SparkSQLConstants.MATCH_VALUE, concat_ws(
        GlobalConstants.COMMA,
        ihrOntologyData(SparkSQLConstants.PREFERRED_TERM_EN), ihrOntologyData(SparkSQLConstants.LABEL1),
        concat_ws(GlobalConstants.PIPE, ihrOntologyData(SparkSQLConstants.ALIAS_TERM_EN))))
        .withColumn(SparkSQLConstants.RXCUI, df1(SparkSQLConstants.RXCUI))
        .withColumn(SparkSQLConstants.UNIICODE, df1(SparkSQLConstants.UNIICODE))
        .withColumn(SparkSQLConstants.CHANGECODE_FLAG, df1(SparkSQLConstants.CHANGECODE_FLAG))
        .cache()
        
    directMapCodesData
    }
    else
        {
      var sourceAddCodesData = df1.sort(SparkSQLConstants.STR1)
      var ihrOntologyData = df2.sort(SparkSQLConstants.PREFERRED_TERM_EN1, SparkSQLConstants.LABEL11, SparkSQLConstants.ALIAS_TERM_EN1)
         var directMapCodesData = sourceAddCodesData.join(
      ihrOntologyData,
      same_array(split(sourceAddCodesData(SparkSQLConstants.STR1),GlobalConstants.SPACE), split(ihrOntologyData(SparkSQLConstants.PREFERRED_TERM_EN1),GlobalConstants.SPACE)) ||
      same_str_label(sourceAddCodesData(SparkSQLConstants.STR1), ihrOntologyData(SparkSQLConstants.LABEL11)) ||
      str_in_alias(sourceAddCodesData(SparkSQLConstants.STR1), ihrOntologyData(SparkSQLConstants.ALIAS_TERM_EN1))    )
      .withColumn(SparkSQLConstants.ALIAS_TERM, ihrOntologyData(SparkSQLConstants.ALIAS_TERM_EN))
      .withColumn(SparkSQLConstants.IHR_MAP, df2(SparkSQLConstants.LABEL1))
      .withColumn(
        SparkSQLConstants.MATCH_RANK,
        when(same_array(split(sourceAddCodesData(SparkSQLConstants.STR1),GlobalConstants.SPACE), split(ihrOntologyData(SparkSQLConstants.PREFERRED_TERM_EN1),GlobalConstants.SPACE)), 9)
          .when(same_str_label(sourceAddCodesData(SparkSQLConstants.STR1), ihrOntologyData(SparkSQLConstants.LABEL11)), 8)
           .when(str_in_alias(sourceAddCodesData(SparkSQLConstants.STR1), ihrOntologyData(SparkSQLConstants.ALIAS_TERM_EN1)), 7))
      .withColumn(SparkSQLConstants.MATCH_VALUE, concat_ws(
        GlobalConstants.COMMA,
        ihrOntologyData(SparkSQLConstants.PREFERRED_TERM_EN), ihrOntologyData(SparkSQLConstants.LABEL1),
        concat_ws(GlobalConstants.PIPE, ihrOntologyData(SparkSQLConstants.ALIAS_TERM_EN))))
        .withColumn(SparkSQLConstants.RXCUI, df1(SparkSQLConstants.RXCUI))
        .withColumn(SparkSQLConstants.UNIICODE, df1(SparkSQLConstants.UNIICODE))
        .withColumn(SparkSQLConstants.CHANGECODE_FLAG, df1(SparkSQLConstants.CHANGECODE_FLAG))
        .cache()
        
    directMapCodesData
        }

  }

  def getWorklistID(workBenchData: DataFrame, taxonomyName: String): String = {
    val workListIdDF = workBenchData.filter(col(SparkSQLConstants.TAXONOMY_FSN) === taxonomyName)
      .select(SparkSQLConstants.WORKLIST_ID)

    var workListID = GlobalConstants.EMPTY_STRING
    var loop = new Breaks
    loop.breakable(
      workListIdDF.collect().foreach(row => {
        workListID = row.getAs[String](0).trim()
        loop.break()
      }))
    workListID
  }
  
    def loadSuperClassData(spark: SparkSession, filePath: String, file: String): DataFrame = {
    var superClassData = spark.read
      .format(GlobalConstants.CSV_FORMAT)
      .option(GlobalConstants.HEADER, true)
      .option(GlobalConstants.DELIMITER, GlobalConstants.TAB)
      .load(filePath+file)
      .withColumn(SparkSQLConstants.SUPERCLASS_CONCEPT_ID, split(col(SparkSQLConstants.CLASS_ID), GlobalConstants.ESCAPE_UNDERSCORE).getItem(1))      
      .withColumnRenamed(SparkSQLConstants.MAPPED_CLASS_LABEL, SparkSQLConstants.SUPERCLASS_LABEL)
      .withColumn(SparkSQLConstants.EXISTING_LABEL, split(col(SparkSQLConstants.LABEL), GlobalConstants.ESCAPE_UNDERSCORE).getItem(2))
    
    superClassData = superClassData.select(SparkSQLConstants.SUPERCLASS_CONCEPT_ID, SparkSQLConstants.SUPERCLASS_LABEL, SparkSQLConstants.MAPPED_CLASS_ID, SparkSQLConstants.EXISTING_LABEL,SparkSQLConstants.CLASS_ID)

    superClassData
  }
    
     val validLabel = udf((t: String) => {
              var result: String = null
              if (null != t && !(t.isEmpty())) {
                if (t.contains(GlobalConstants.ROUND_BRACKET)){
                    result = t.substring(0, t.lastIndexOf(GlobalConstants.ROUND_BRACKET)).trim()
                }else{
                  result = t.trim()
                }
              }
              result
     })
  def loadIHRDumpData(spark: SparkSession, filePath: String, file: String): DataFrame = {
    var ihrData =  spark.read .format(GlobalConstants.CSV_FORMAT)
        .option(GlobalConstants.HEADER, true)
        .option(GlobalConstants.DELIMITER, GlobalConstants.TAB)    
        .load(filePath+file)
        .withColumn(SparkSQLConstants.LABEL1, col(SparkSQLConstants.LABEL))
        .withColumnRenamed(SparkSQLConstants.CLASS_ID, SparkSQLConstants.MAPPED_CLASS_ID)

        if(file.equals(GlobalConstants.PRODUCT_DEVICE_ONT)){
         ihrData = ihrData.withColumn(SparkSQLConstants.MSP_RPID, lit(GlobalConstants.EMPTY_STRING))
                           .withColumn(SparkSQLConstants.GENERICNAME, lit(GlobalConstants.EMPTY_STRING))
        }
       ihrData =ihrData .select(
          SparkSQLConstants.MAPPED_CLASS_ID,
          SparkSQLConstants.LABEL1,SparkSQLConstants.IDENTIFIER,
          SparkSQLConstants.PREFERRED_TERM_EN,SparkSQLConstants.GENERICNAME,           
          SparkSQLConstants.ALIAS_TERM_EN,SparkSQLConstants.MSP_DDID,SparkSQLConstants.MSP_PNID,SparkSQLConstants.MSP_RPID,SparkSQLConstants.MSP_GPI)
 
    ihrData
  }
  

   def getIHRMatchType(ihrCompData: DataFrame, file: String): DataFrame = {
      var ihrData = ihrCompData
      
        val ihrRankData = ihrData
        .groupBy(col(SparkSQLConstants.CONCEPT_ID) as SparkSQLConstants.GROUP_CONCEPT_ID)
        .agg(max(col(SparkSQLConstants.MATCH_RANK)) as SparkSQLConstants.MAX_RANK)
      
      ihrData = ihrData.join(ihrRankData,  ihrRankData(SparkSQLConstants.GROUP_CONCEPT_ID) === ihrData(SparkSQLConstants.CONCEPT_ID) &&
                            ihrRankData(SparkSQLConstants.MAX_RANK) === ihrData(SparkSQLConstants.MATCH_RANK))
                            .withColumn(SparkSQLConstants.SUPER_CLASS_STATUS, lit(GlobalConstants.QUEST_AP))
       if(file == GlobalConstants.PRODUCT_MEDICATION_ONT)
             ihrData=ihrData  .withColumn(
          SparkSQLConstants.MATCH_TYPE,
          when(col(SparkSQLConstants.MAX_RANK) === 9, GlobalConstants.RXNORM_PT_MED_IHR_DUMP)
            .when(col(SparkSQLConstants.MAX_RANK) === 8, GlobalConstants.RXNORM_LABELMED_IHR_DUMP)
            .when(col(SparkSQLConstants.MAX_RANK) === 7, GlobalConstants.RXNORM_ALIAS_MED_IHR_DUMP))
            else
            ihrData=ihrData  .withColumn(
          SparkSQLConstants.MATCH_TYPE,
          when(col(SparkSQLConstants.MAX_RANK) === 9, GlobalConstants.RXNORM_PT_DEV_IHR_DUMP)
            .when(col(SparkSQLConstants.MAX_RANK) === 8, GlobalConstants.RXNORM_LABEL_DEV_IHR_DUMP)
            .when(col(SparkSQLConstants.MAX_RANK) === 7, GlobalConstants.RXNORM_ALIAS_DEV_IHR_DUMP))
      ihrData
  }

     //str-label
    val same_str_label = udf((t: String, t2: String) => {

      if (t != null && t2 != null  && t2.length() > 0) {
        t.trim()
        var label = GlobalConstants.EMPTY_STRING
        if (t2.contains(GlobalConstants.SQUARE_BRACKET))
       
          label = t2.substring(0, t2.lastIndexOf(GlobalConstants.SQUARE_BRACKET)).trim()
        else
          label = t2.trim()
          
          var arrLabel = label.split(GlobalConstants.SPACE)
          var t1 = t.split(GlobalConstants.SPACE)
      
            if (t1 != null && arrLabel != null && t1.length == arrLabel.length &&
          (t1.map(_.trim().toLowerCase()).intersect(arrLabel.map(_.trim().toLowerCase())).length == arrLabel.length))
          { if(arrLabel.length!=1 ||arrLabel(0).equals(GlobalConstants.EMPTY_STRING) ){true} else false}  
        else if (t1 == null && arrLabel == null) { false }
        else if ((t1 == null && arrLabel != null) || (arrLabel == null && t1 != null)) { false }        
        else { false }  
      } else false
    })

 //str-alias
       val str_in_alias = udf((t: String, t2: String) => {
      if (t != null && t2 != null  && t2.length() > 0) {
        t.trim()
        var label = t2         
          var arrLabel = label.split(GlobalConstants.SPACE)
          var t1 = t.split(GlobalConstants.SPACE)
      
            if (t1 != null && arrLabel != null && t1.length == arrLabel.length &&
          (t1.map(_.trim().toLowerCase()).intersect(arrLabel.map(_.trim().toLowerCase())).length == arrLabel.length))
          { if(arrLabel.length!=1 ||arrLabel(0).equals(GlobalConstants.EMPTY_STRING) ){true} else false}  
        else if (t1 == null && arrLabel == null) { false }
        else if ((t1 == null && arrLabel != null) || (arrLabel == null && t1 != null)) { false }        
        else { false }

      
      } else false
    })
    
     def containsReplacementValue(str: String):String ={ 
       var result :String = null
        var flag=false
       var keyset=(GlobalConstants.rxnormReplacementValues).keySet
       for (key <- keyset)
       {
         if(str.contains(key+" "+"mcg")) 
             {
             flag=true
             result = str.replaceAll(key+" "+"mcg",((GlobalConstants.rxnormReplacementValues)(key)+" "+"mg"))
            
             }
       }
       if(flag.equals(false)) str;
       
       else result
               
        }

    def replaceString = udf((st: String) => { 

        var flag=false
        var flag1=false

         if(null==st || st.equals(GlobalConstants.EMPTY_STRING) || st.isEmpty()){
					null}  
         else{
          var str=st.toLowerCase()
        var result :String = str

         if(str.contains("mcg"))
  		     {             
  		       result=containsReplacementValue(str)
  		       flag=true
  		     }
          
           if((if(flag)result else str).contains("oral solution"))
          {
            result=(if(flag)result else str).replaceAll("oral solution", "oral liquid")
            flag=true            
          }
          if((if(flag)result else str).contains("liquid soap"))
          {
            result=(if(flag)result else str).replaceAll("liquid soap", "external emulsion")
            flag=true            
          }
          if((if(flag)result else str).contains("in 5 % dextrose"))
          {
            result=(if(flag)result else str).replaceAll("in 5 % dextrose", "in d5w")
            flag=true            
          }
          if((if(flag)result else str).contains("in 5% dextrose"))
          {
            result=(if(flag)result else str).replaceAll("in 5% dextrose", "in d5w")
            flag=true            
          }

        
         var s=(if(flag)result else str).split(" ")         
         var keyset=(GlobalConstants.rxnormReplacementValuesAdditional).keySet

         for (i <- s)
         {
         if(keyset.contains(i)) 
             {
              flag1=true
              result = (if(flag)result else str).replaceAll(i,(GlobalConstants.rxnormReplacementValuesAdditional)(i))              
             }
          }
         
          if((if(flag|| flag1)result else str).contains("%"))
          {
            result=(if(flag|| flag)result else str).replaceAll("%", " ")
            flag1=true            
          }
          if((if(flag|| flag1)result else str).contains("-"))
          {
            result=(if(flag|| flag1)result else str).replaceAll("-", " ")
            flag1=true            
          }
          if((if(flag|| flag1)result else str).contains("/"))
          {
            result=(if(flag|| flag1)result else str).replaceAll("/", " ")
            flag1=true            
          }
          if((if(flag|| flag1)result else str).contains("__"))
          {
            result=(if(flag|| flag1)result else str).replaceAll("__", "_")
            flag1=true            
          }
          if(flag || flag1){
            result
          }
          else {
            str }      
         }
		  })
    
    
    

}