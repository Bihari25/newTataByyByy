package com.ihr.oea.worklist

import java.time.LocalDateTime
import java.time.format.DateTimeFormatter

import org.apache.spark.sql.SparkSession
import org.apache.spark.sql.functions.col
import org.apache.spark.sql.functions.count
import org.apache.spark.sql.functions.lit
import org.apache.spark.sql.functions.when
import com.ihr.oea.common.GlobalConstants
import com.ihr.oea.common.OESConfiguration
import com.ihr.oea.common.SparkSQLConstants
import com.ihr.oea.dao.MongoDAO
import org.apache.log4j.Logger
import org.apache.log4j.Level

class WorkBenchData {
  val log = Logger.getLogger(getClass.getName)
  Logger.getLogger("org").setLevel(Level.OFF)
  Logger.getLogger("akka").setLevel(Level.OFF)
  Logger.getLogger("INFO").setLevel(Level.OFF)
  def generateWorkBenchData(spark: SparkSession, oesConfiguration: OESConfiguration, releaseId: String) {
    log.info("processing workbench data for releaseId : " + releaseId)
    try {
      val currentTime = DateTimeFormatter.ofPattern(GlobalConstants.TIME_FORMAT).format(LocalDateTime.now)
      val mongoDAO = new MongoDAO
      log.info("reading worklist data from DB for workbench for releaseId : " + releaseId)
      val workListDF = mongoDAO.readDataFrameFromMongo(spark, oesConfiguration.DATABASE_NAME,
        GlobalConstants.WORKLIST_ITEMS)
        .filter(col(SparkSQLConstants.RELEASE_ID) === releaseId)

      val worklistItemsByTaxDF = workListDF.groupBy(
        col(SparkSQLConstants.RELEASE_ID),
        col(SparkSQLConstants.WORKLIST_ID),
        col(SparkSQLConstants.TAXONOMY_FSN),
        col(SparkSQLConstants.WORKLIST_TYPE))
        .agg(count(col(SparkSQLConstants.CONCEPT_ID)) as SparkSQLConstants.ITEM_COUNT)
      log.info("generating workbench data for releaseId : " + releaseId)
     val workBenchDF = worklistItemsByTaxDF
        .withColumn(SparkSQLConstants.ONTOLOGY_TYPE, lit(GlobalConstants.SOURCE_ONTOLOGY))
        .withColumn(SparkSQLConstants.WORKLIST_CREATION_STATUS, lit(GlobalConstants.INPROGRESS))
        .withColumn(SparkSQLConstants.WORKLIST_CREATION_TIME, lit(currentTime))
        .withColumn(SparkSQLConstants.USERID, lit(GlobalConstants.DEFAULT_USER))
        .withColumn(SparkSQLConstants.PUBLISH_STATUS, when(col(SparkSQLConstants.WORKLIST_TYPE)===GlobalConstants.ADD_UNMATCHED ||
            col(SparkSQLConstants.WORKLIST_TYPE)===GlobalConstants.EDIT_UNMATCHED,GlobalConstants.MANUALLY_PROCESSED).otherwise(GlobalConstants.PENDING))
        .withColumn(SparkSQLConstants.PUBLISH_COUNT, lit(0))
        .withColumn(SparkSQLConstants.JIRA_ID, lit(GlobalConstants.EMPTY_STRING))
      log.info("generated workbench data for releaseId : " + releaseId)
      log.info("saving workbench data into DB for releaseId : " + releaseId)
      mongoDAO.writeDataFrameToMongo(GlobalConstants.WORKBENCH_COLLECTION, workBenchDF)
      log.info("successfully saved workbench data into DB for releaseId : " + releaseId)
    } catch {
      case e: Exception =>
        log.error(s"Exception while saving workbench data into DB for releaseId : " + releaseId)
        log.error(e)
        throw e
    }
  }
}