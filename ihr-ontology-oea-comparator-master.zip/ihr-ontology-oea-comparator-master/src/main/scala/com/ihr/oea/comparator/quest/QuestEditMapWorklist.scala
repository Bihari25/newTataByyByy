package com.ihr.oea.comparator.quest

import java.time.LocalDateTime
import java.time.format.DateTimeFormatter
import java.util.ArrayList
import scala.collection.mutable.Stack
import scala.util.control.Breaks
import scala.collection.mutable.ArrayBuffer
import scala.collection.mutable.Stack
import scala.collection.mutable.WrappedArray
import org.apache.spark.sql.Row
import org.apache.spark.sql.SparkSession
import org.apache.spark.sql.functions.col
import org.apache.spark.sql.functions.lit
import org.apache.spark.sql.functions.split
import org.apache.spark.sql.types.StringType
import org.apache.spark.sql.types.StructField
import org.apache.spark.sql.types.StructType
import org.apache.spark.sql.functions.udf
import org.apache.spark.sql.functions.when

import com.ihr.oea.common.GlobalConstants
import com.ihr.oea.common.OESConfiguration
import com.ihr.oea.common.SparkSQLConstants
import com.ihr.oea.dao.MongoDAO
import org.apache.log4j.Logger
import com.ihr.oea.comparator.snomed.SnomedCompareUtil
import com.ihr.oea.util.ComparatorUtil
import org.apache.spark.sql.sources.IsNull

class QuestEditMapWorklist {
  val log = Logger.getLogger(getClass.getName)
  def buildEditCodesSchema(): StructType = {
    val schema = StructType(
      Array(
        StructField(SparkSQLConstants.RELEASE_ID, StringType, true),
        StructField(SparkSQLConstants.TAXONOMY_FSN, StringType, true),
        StructField(SparkSQLConstants.CONCEPT_ID, StringType, true),
        StructField(SparkSQLConstants.PREFERRED_TERM, StringType, true),
        StructField(SparkSQLConstants.TYPE, StringType, true),
        StructField(SparkSQLConstants.CPT_CODE, StringType, true),
        StructField(SparkSQLConstants.LOINC_CODE, StringType, true),
        StructField(SparkSQLConstants.EFFECTIVE_TIME, StringType, true),
        StructField(SparkSQLConstants.LANGUAGE_CODE, StringType, true),
        StructField(SparkSQLConstants.REL_PREFERRED_TERM, StringType, true),
        StructField(SparkSQLConstants.REL_TYPE, StringType, true),
        StructField(SparkSQLConstants.REL_CPT_CODE, StringType, true),
        StructField(SparkSQLConstants.REL_LOINC_CODE, StringType, true),
 	      StructField(SparkSQLConstants.CHANGECODE_FLAG, StringType, true),
        StructField(SparkSQLConstants.WORKLIST_TYPE, StringType, true),
        StructField(SparkSQLConstants.WORKLIST_ID, StringType, true)))
    schema
  }

   var editHCPCSCPCBetterMapCodes = SparkSession.builder().getOrCreate().emptyDataFrame
   var ihrWithEditCodes = SparkSession.builder().getOrCreate().emptyDataFrame
  
  def generateQuestEditMapWorklist(spark: SparkSession, oesConfiguration: OESConfiguration, releaseID: String) {
    try {
      log.info("Running data comparator for Edit Map worklist for Quest releaseId : " + releaseID)
      log.info("loading edit codes from db for Quest releaseId : " + releaseID)

      val mongoDAO = new MongoDAO
      log.info("Finding  distinct taxonomies in release data for Quest releaseId : " + releaseID)
      
     val editWorkListData = spark.read.format(GlobalConstants.SPARK_DEFAULT_MONGO_DATASOURCE)
        .option(GlobalConstants.DATABASE,  oesConfiguration.DATABASE_NAME)
        .option(GlobalConstants.COLLECTION, GlobalConstants.WORKLIST_ITEMS)
        .schema(buildEditCodesSchema())
        .load().filter(col(SparkSQLConstants.RELEASE_ID) === releaseID && col(SparkSQLConstants.WORKLIST_TYPE) === GlobalConstants.EDIT_CODES)

      // Find the distinct taxonomies in the release from the MongoDB
      val util = new ComparatorUtil
      val questComp = new QuestCompareUtil
      val questUtil = new QuestEditMapCompareUtil
      var taxonomyStack = util.findDistinctTaxonomy(editWorkListData)
        
      var count = 1
      var worklistId = GlobalConstants.EMPTY_STRING
      var currentTime = GlobalConstants.EMPTY_STRING
      while (taxonomyStack.nonEmpty) {
        var taxonomyName = taxonomyStack.pop
        try {
          log.info("Loading the IHR annoataion mapping for taxonomy " + taxonomyName + " for Quest releaseId : " + releaseID)
          var superClassOntologyFiles = GlobalConstants.questSourceAnnotationMap.apply(taxonomyName)
          if (null != superClassOntologyFiles) {
            val workListID = questUtil.getWorklistID(editWorkListData, taxonomyName)
            log.info("generating edit direct map worklist data for taxonomy " + taxonomyName + " for Quest workListID : " + workListID )
             var sourceCodes = spark.read.format(GlobalConstants.SPARK_DEFAULT_MONGO_DATASOURCE)
                  .option(GlobalConstants.DATABASE,  oesConfiguration.DATABASE_NAME)
                  .option(GlobalConstants.COLLECTION, GlobalConstants.WORKLIST_ITEMS)
                  .schema(buildEditCodesSchema())
                  .load().filter(col(SparkSQLConstants.WORKLIST_ID) === workListID)
                  
            sourceCodes = sourceCodes.select(GlobalConstants.STAR)
                               .withColumn(SparkSQLConstants.PREFERRED_TERM, col(SparkSQLConstants.REL_PREFERRED_TERM))
                               .withColumn(SparkSQLConstants.LOINC_CODE, col(SparkSQLConstants.REL_LOINC_CODE))   
                               .withColumn(SparkSQLConstants.CPT_CODE, col(SparkSQLConstants.REL_CPT_CODE))   
                               .withColumn(SparkSQLConstants.TYPE, col(SparkSQLConstants.REL_TYPE))   
        
            log.info("generating edit direct map worklist data for taxonomy " + taxonomyName + " for Quest releaseId : " + releaseID)
            log.info("generating superclass annotation path for lonic releaseId : " + releaseID)
            var ihrWithEditCodes = SparkSession.builder().getOrCreate().emptyDataFrame
            
            var sourceLoincCodes = questUtil.generateLoincSCMapData(taxonomyName,  sourceCodes, GlobalConstants.EDIT_CODES, spark, oesConfiguration, releaseID)
            
            var directHCPCodes = SparkSession.builder().getOrCreate().emptyDataFrame
            var sourceEditCodesDF = SparkSession.builder().getOrCreate().emptyDataFrame
                              sourceLoincCodes.createOrReplaceTempView(SparkSQLConstants.DF);   
            
           
              sourceLoincCodes = spark.sql(SparkSQLConstants.LOINC_QUEST_EDIT__MATCHVALUE  +  taxonomyName +GlobalConstants.SINGLE_QUOTE)
              sourceEditCodesDF = sourceCodes.join(sourceLoincCodes, sourceLoincCodes(SparkSQLConstants.CONCEPT_ID) === sourceCodes(SparkSQLConstants.CONCEPT_ID), SparkSQLConstants.ANTI_LEFT_JOIN)
                .filter(sourceCodes.col(SparkSQLConstants.TAXONOMY_FSN) === taxonomyName)
         
            var sourceLoincNoMaps =   sourceEditCodesDF.join(sourceLoincCodes, sourceEditCodesDF(SparkSQLConstants.CONCEPT_ID) === sourceLoincCodes(SparkSQLConstants.CONCEPT_ID),   SparkSQLConstants.ANTI_LEFT_JOIN)
                .select(
                SparkSQLConstants.TAXONOMY_FSN,
                SparkSQLConstants.CONCEPT_ID,
                SparkSQLConstants.PREFERRED_TERM,
                SparkSQLConstants.EFFECTIVE_TIME,
                SparkSQLConstants.LANGUAGE_CODE,
                SparkSQLConstants.LOINC_CODE,
                SparkSQLConstants.CPT_CODE,
                SparkSQLConstants.TYPE, SparkSQLConstants.CHANGECODE_FLAG)

           var ihrMatchEditCodes = questUtil.generateQuestIHRMapData(taxonomyName, sourceLoincNoMaps, GlobalConstants.EDIT_CODES, spark, oesConfiguration, releaseID)
                               .select(SparkSQLConstants.TAXONOMY_FSN,
                                  SparkSQLConstants.CONCEPT_ID,
                                  SparkSQLConstants.PREFERRED_TERM,
                                  SparkSQLConstants.EFFECTIVE_TIME,
                                  SparkSQLConstants.LANGUAGE_CODE,
                                  SparkSQLConstants.IHR_MAP,
                                  SparkSQLConstants.LOINC_CODE,
                                  SparkSQLConstants.CPT_CODE,
                                  SparkSQLConstants.TYPE,
                                  SparkSQLConstants.MATCH_TYPE,
                                  SparkSQLConstants.MATCH_VALUE,
                                  SparkSQLConstants.SUPER_CLASS_STATUS,
                                  SparkSQLConstants.CHANGECODE_FLAG)
                                  
                                  
             if (taxonomyName == GlobalConstants.OBSERVATION) {
                   ihrWithEditCodes = ihrMatchEditCodes.union(sourceLoincCodes)
             }else{
               var hcpcscDF = questUtil.generateHCPCSCPTMapData(taxonomyName, sourceLoincNoMaps, ihrMatchEditCodes, GlobalConstants.EDIT_CODES, spark, oesConfiguration, releaseID)
                hcpcscDF.createOrReplaceTempView(SparkSQLConstants.CPT_DF);   
                var cptDirectCodes = spark.sql(SparkSQLConstants.CPT_QUEST_EDIT_MATCHVALUE +  taxonomyName +GlobalConstants.SINGLE_QUOTE)
                cptDirectCodes = cptDirectCodes.union(sourceLoincCodes)
                ihrWithEditCodes = ihrMatchEditCodes.union(cptDirectCodes)
             }
              var editMapNoCodes = questUtil.generateQuestSCMapData(taxonomyName,  sourceEditCodesDF,ihrWithEditCodes,  GlobalConstants.EDIT_CODES, spark, oesConfiguration, releaseID) 
              
              var mappingCodeDF = questUtil.generateMappedData(taxonomyName, ihrWithEditCodes,  GlobalConstants.EDIT_CODES, spark, oesConfiguration, releaseID)
              var notMappingCodeDF = questUtil.generateNotMappedData(taxonomyName, ihrWithEditCodes,  GlobalConstants.EDIT_CODES, spark, oesConfiguration, releaseID)
            
             
              //Edit Map - Better Match
                worklistId = releaseID + GlobalConstants.W + count + GlobalConstants.UNDER_SCORE + GlobalConstants.WORKLIST_EDIT_BETTER_MATCHED
              var editMapCodes =   mappingCodeDF.join(notMappingCodeDF, notMappingCodeDF(SparkSQLConstants.CONCEPT_ID) === mappingCodeDF(SparkSQLConstants.CONCEPT_ID), SparkSQLConstants.ANTI_LEFT_JOIN)
                                  .select(SparkSQLConstants.TAXONOMY_FSN,
                                  SparkSQLConstants.CONCEPT_ID,
                                  SparkSQLConstants.PREFERRED_TERM,
                                  SparkSQLConstants.IHR_MAP,
                                  SparkSQLConstants.SUPERCLASS_LABEL,
                                  SparkSQLConstants.LOINC_CODE,
                                  SparkSQLConstants.CPT_CODE,
                                  SparkSQLConstants.TYPE,
                                   SparkSQLConstants.CHANGECODE_FLAG,
                                  SparkSQLConstants.MATCH_TYPE,
                                  SparkSQLConstants.MATCH_VALUE,
                                  SparkSQLConstants.SUPER_CLASS_STATUS)
                                .withColumn(SparkSQLConstants.ACTION_STATUS, lit(GlobalConstants.REVIEW_PENDING))
                                .withColumn(SparkSQLConstants.WORKLIST_ID, lit(worklistId))
                                .withColumn(SparkSQLConstants.RELEASE_ID, lit(releaseID))
                                .withColumn(SparkSQLConstants.WORKLIST_TYPE, lit(GlobalConstants.EDIT_BETTER_MATCHED))
              editMapCodes = editMapCodes.dropDuplicates(SparkSQLConstants.CONCEPT_ID,SparkSQLConstants.IHR_MAP)
              
                
              mongoDAO.writeDataFrameToMongo(GlobalConstants.WORKLIST_ITEMS, editMapCodes.distinct())
              log.info("generating Edit Map - Better Match worklist data for taxonomy " + taxonomyName + " for loinc releaseId : " + releaseID) 
              
               //Edit Map - NoMap found     
                worklistId = releaseID + GlobalConstants.W + count + GlobalConstants.UNDER_SCORE + GlobalConstants.WORKLIST_EDIT_NO_MAPFOUND 
               editMapNoCodes = editMapNoCodes .select(
                SparkSQLConstants.TAXONOMY_FSN,
                SparkSQLConstants.CONCEPT_ID,
                SparkSQLConstants.TYPE,
                 SparkSQLConstants.CHANGECODE_FLAG,
                SparkSQLConstants.PREFERRED_TERM,
                SparkSQLConstants.LOINC_CODE,
                SparkSQLConstants.CPT_CODE,
                SparkSQLConstants.SUPERCLASS_LABEL,
                SparkSQLConstants.MATCH_TYPE,
                SparkSQLConstants.MATCH_VALUE)
              .withColumn(SparkSQLConstants.SUPER_CLASS_STATUS, lit(GlobalConstants.EMPTY_STRING))
              .withColumn(SparkSQLConstants.IHR_MAP, lit(GlobalConstants.DEFAULT_NO_MAP))
              .withColumn(SparkSQLConstants.ACTION_STATUS, lit(GlobalConstants.REVIEW_PENDING))
              .withColumn(SparkSQLConstants.WORKLIST_ID, lit(worklistId))
              .withColumn(SparkSQLConstants.RELEASE_ID, lit(releaseID))
              .withColumn(SparkSQLConstants.WORKLIST_TYPE, lit(GlobalConstants.EDIT_NO_MAPFOUND))
              .cache().dropDuplicates(SparkSQLConstants.CONCEPT_ID, SparkSQLConstants.SUPERCLASS_LABEL)
              
                mongoDAO.writeDataFrameToMongo(GlobalConstants.WORKLIST_ITEMS, editMapNoCodes.distinct())          
                  log.info("generating Edit Map - NoMap found  worklist data for taxonomy " + taxonomyName + " for loinc releaseId : " + releaseID)                
                
                 //Edit  Unmapped - Direct Map
            log.info("generating Edit  Unmapped – Direct Map worklist data for taxonomy " + taxonomyName + " for loinc releaseId : " + releaseID)
            worklistId = releaseID + GlobalConstants.W + count + GlobalConstants.UNDER_SCORE + GlobalConstants.WORKLIST_EDIT_UNMATCHED_DIRECT_MAP
            val editUnmappedDirectMapCodes = questUtil.generateUnmappedDirecMapData(taxonomyName, ihrWithEditCodes,  GlobalConstants.EDIT_CODES, spark, oesConfiguration, releaseID)
              .select(SparkSQLConstants.TAXONOMY_FSN,
                      SparkSQLConstants.CONCEPT_ID,
                      SparkSQLConstants.PREFERRED_TERM,
                      SparkSQLConstants.IHR_MAP,
                      SparkSQLConstants.LOINC_CODE,
                      SparkSQLConstants.CPT_CODE,
                      SparkSQLConstants.TYPE,
                       SparkSQLConstants.CHANGECODE_FLAG,
                      SparkSQLConstants.MATCH_TYPE,
                      SparkSQLConstants.MATCH_VALUE)
              .withColumn(SparkSQLConstants.SUPERCLASS_LABEL, lit(GlobalConstants.DEFAULT_NO_MAP))
              .withColumn(SparkSQLConstants.ACTION_STATUS, lit(GlobalConstants.REVIEW_PENDING))
              .withColumn(SparkSQLConstants.WORKLIST_ID, lit(worklistId))
              .withColumn(SparkSQLConstants.RELEASE_ID, lit(releaseID))
              .withColumn(SparkSQLConstants.WORKLIST_TYPE, lit(GlobalConstants.EDIT_UNMATCHED_DIRECT_MAP)) .cache().dropDuplicates(SparkSQLConstants.CONCEPT_ID, SparkSQLConstants.IHR_MAP)
              

             mongoDAO.writeDataFrameToMongo(GlobalConstants.WORKLIST_ITEMS, editUnmappedDirectMapCodes.distinct())
            log.info("generating Edit Unmapped - NoMap found worklist data for taxonomy " + taxonomyName + " for loinc releaseId : " + releaseID)
            worklistId = releaseID + GlobalConstants.W + count + GlobalConstants.UNDER_SCORE + GlobalConstants.WORKLIST_EDIT_UNMATCHED
            
            //Edit  Unmapped - No Map
            val editUnmappedNoMapIHRCodes = sourceEditCodesDF.join( ihrWithEditCodes,
              ihrWithEditCodes(SparkSQLConstants.CONCEPT_ID) === sourceEditCodesDF(SparkSQLConstants.CONCEPT_ID), SparkSQLConstants.ANTI_LEFT_JOIN).distinct()

            val editUnmappedNoMapCodes = questUtil.generateUnmappedDirecMapData(taxonomyName, editUnmappedNoMapIHRCodes,  GlobalConstants.EDIT_CODES, spark, oesConfiguration, releaseID)
               .select(
                SparkSQLConstants.TAXONOMY_FSN,
                SparkSQLConstants.CONCEPT_ID,
                SparkSQLConstants.TYPE,
                SparkSQLConstants.CHANGECODE_FLAG,
                SparkSQLConstants.PREFERRED_TERM,
                SparkSQLConstants.LOINC_CODE, SparkSQLConstants.CPT_CODE)
              .withColumn(SparkSQLConstants.IHR_MAP, lit(GlobalConstants.DEFAULT_NO_MAP))
              .withColumn(SparkSQLConstants.SUPERCLASS_LABEL, lit(GlobalConstants.DEFAULT_NO_MAP))
              .withColumn(SparkSQLConstants.ACTION_STATUS, lit(GlobalConstants.MANUALLY_PROCESSED))
              .withColumn(SparkSQLConstants.WORKLIST_ID, lit(worklistId))
              .withColumn(SparkSQLConstants.RELEASE_ID, lit(releaseID))
              .withColumn(SparkSQLConstants.WORKLIST_TYPE, lit(GlobalConstants.EDIT_UNMATCHED))
            mongoDAO.writeDataFrameToMongo(GlobalConstants.WORKLIST_ITEMS, editUnmappedNoMapCodes.distinct())
              
              count += 1
          } else {
            log.info("No Source ontology file found for taxonomy : " + taxonomyName)
          }
        } catch {
          case e: Exception =>
            log.error(s"Exception while running data comparator for taxonomy : " + taxonomyName + " for Edit Map Worklist for quest releaseId : " + releaseID+e.printStackTrace())
            log.error(e.printStackTrace())
        }
      }
    
      log.info("Completed data comparator for Edit Map Worklist for quest releaseId : " + releaseID)
    } catch {
      case e: Exception =>
        log.error(s"Exception while running data comparator for Edit Map Worklist for quest releaseId : " + releaseID)
        log.error(e.printStackTrace())
      //throw e
    }
  }
}