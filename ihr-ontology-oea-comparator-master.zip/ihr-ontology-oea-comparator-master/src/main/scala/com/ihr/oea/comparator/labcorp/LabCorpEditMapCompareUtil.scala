package com.ihr.oea.comparator.labcorp

import scala.collection.mutable.WrappedArray
import scala.util.control.Breaks
import com.ihr.oea.dao.MongoDAO
import org.apache.log4j.Logger
import org.apache.spark.sql.DataFrame
import org.apache.spark.sql.SparkSession
import org.apache.spark.sql.functions.col
import org.apache.spark.sql.functions.concat_ws
import org.apache.spark.sql.functions.lit
import org.apache.spark.sql.functions.max
import org.apache.spark.sql.functions.split
import org.apache.spark.sql.functions.udf
import org.apache.spark.sql.functions.when
import com.ihr.oea.common.GlobalConstants
import com.ihr.oea.common.OESConfiguration
import com.ihr.oea.common.SparkSQLConstants

@throws(classOf[Exception])
class LabCorpEditMapCompareUtil {

          val log = Logger.getLogger(getClass.getName)
        
          def generateLabCorpMapData(taxonomyName: String, sourceCodesDF: DataFrame, codeType: String, spark: SparkSession, oesConfiguration: OESConfiguration, releaseID: String, count:Int, mongoDAO: MongoDAO) {
        
            val labCorputil = new LabCorpCompareUtil
            var worklistId = labCorputil.getWorklistID(sourceCodesDF, taxonomyName)
            var currentTime = GlobalConstants.EMPTY_STRING
        
            var superClassBasePath = oesConfiguration.BASE_PATH + releaseID + GlobalConstants.FORWARD_SLASH + oesConfiguration.SUPERCLASS_DUMP_PATH + GlobalConstants.FORWARD_SLASH
        
            if (!oesConfiguration.PROFILE.equalsIgnoreCase(GlobalConstants.LOCAL_PROFILE)) {
              superClassBasePath = superClassBasePath.substring(5)
            }
            var ihrAnnotationBasePath = oesConfiguration.BASE_PATH + releaseID + GlobalConstants.FORWARD_SLASH + oesConfiguration.IHR_ANNOTATION_PATH + GlobalConstants.FORWARD_SLASH
            if (!oesConfiguration.PROFILE.equalsIgnoreCase(GlobalConstants.LOCAL_PROFILE)) {
              ihrAnnotationBasePath = ihrAnnotationBasePath.substring(5)
            }
            
            var mapKey = taxonomyName
        
            log.info("loading loinc superclass data for taxonomy " + taxonomyName + " for LabCorp releaseId : " + releaseID)
            var superClassOntologyFile = GlobalConstants.labCorpSourceAnnotationMap.apply(mapKey)
            val fullSuperClassData = loadSuperClassData(spark, superClassBasePath + superClassOntologyFile)
        
        
            var superClassDirectCodes = sourceCodesDF.join(fullSuperClassData, fullSuperClassData(SparkSQLConstants.SUPERCLASS_CONCEPT_ID) === sourceCodesDF(SparkSQLConstants.CONCEPT_ID))
              .select(
                SparkSQLConstants.TAXONOMY_FSN,
                SparkSQLConstants.CONCEPT_ID,
                SparkSQLConstants.TYPE,
                SparkSQLConstants.PREFERRED_TERM,
                SparkSQLConstants.LOINC_CODE,
                fullSuperClassData.col(SparkSQLConstants.SUPERCLASS_LABEL).toString(),
                SparkSQLConstants.CHANGECODE_FLAG)
              .withColumn(SparkSQLConstants.MATCH_TYPE, lit(GlobalConstants.EMPTY_STRING))
              .withColumn(SparkSQLConstants.MATCH_VALUE, lit(GlobalConstants.EMPTY_STRING))
              .withColumn(SparkSQLConstants.SUPER_CLASS_STATUS, lit(GlobalConstants.EMPTY_STRING))
           
              var superClassUmmap = sourceCodesDF.join(superClassDirectCodes, superClassDirectCodes(SparkSQLConstants.CONCEPT_ID) === sourceCodesDF(SparkSQLConstants.CONCEPT_ID), SparkSQLConstants.ANTI_LEFT_JOIN)
        
            log.info("loading loinc superclass data for taxonomy " + taxonomyName + " for LabCorp releaseId : " + releaseID)
            var loincSuperClassOntologyFile = GlobalConstants.questLoincSuperClassMap.apply(mapKey)
            val loincSuperClassData = loadSuperClassData(spark, superClassBasePath + loincSuperClassOntologyFile)
            log.info("comparaing loinc superclass data and add code for taxonomy " + taxonomyName + " for LabCorp releaseId : " + releaseID)
            var loincDirectCodes = loadLoincDataFrameData(spark, sourceCodesDF, loincSuperClassData, taxonomyName)
            var loincUnMappedDF = loadLoincDataFrameData(spark, superClassUmmap, loincSuperClassData, taxonomyName)
             
            var directCodes = superClassDirectCodes.join(loincDirectCodes, loincDirectCodes(SparkSQLConstants.CONCEPT_ID) === superClassDirectCodes(SparkSQLConstants.CONCEPT_ID), SparkSQLConstants.ANTI_LEFT_JOIN)
        
            
             var  loincUnMappedOBSDF = superClassUmmap.join(loincUnMappedDF, loincUnMappedDF(SparkSQLConstants.CONCEPT_ID) === superClassUmmap(SparkSQLConstants.CONCEPT_ID), SparkSQLConstants.ANTI_LEFT_JOIN)
               .select(
                SparkSQLConstants.TAXONOMY_FSN,
                SparkSQLConstants.CONCEPT_ID,
                SparkSQLConstants.TYPE,
                SparkSQLConstants.PREFERRED_TERM,
                SparkSQLConstants.LOINC_CODE,               
                SparkSQLConstants.CHANGECODE_FLAG)
              
            var ihrOntologyFile = GlobalConstants.questIHRAnnotationMap.apply(taxonomyName)
            var ihrDirectCodes = SparkSession.builder().getOrCreate().emptyDataFrame
            var ihrDirectUnMapCodes = SparkSession.builder().getOrCreate().emptyDataFrame
            if (null != ihrOntologyFile) {
              log.info("Loading IHR annotation data for taxonomy " + taxonomyName + " for LabCorp releaseId : " + releaseID)
              val ihrOntologyData = spark.read
                .format(GlobalConstants.CSV_FORMAT)
                .option(GlobalConstants.HEADER, true)
                .option(GlobalConstants.DELIMITER, GlobalConstants.TAB)
                .load(ihrAnnotationBasePath + ihrOntologyFile)
                .withColumn(SparkSQLConstants.LABEL1, col(SparkSQLConstants.LABEL))
                .withColumnRenamed(SparkSQLConstants.CLASS_ID, SparkSQLConstants.MAPPED_CLASS_ID)
                .withColumn(SparkSQLConstants.ALIAS_TERM_EN, split(col(SparkSQLConstants.ALIAS_TERM_EN), GlobalConstants.SQUARE_PIPE)).select(
                  SparkSQLConstants.MAPPED_CLASS_ID,
                  SparkSQLConstants.LABEL1,
                  SparkSQLConstants.PREFERRED_TERM_EN,
                  SparkSQLConstants.ALIAS_TERM_EN)
        
              log.info("comparing add data and IHR annotation data for taxonomy " + taxonomyName + " for LabCorp releaseId : " + releaseID)
        
              ihrDirectCodes = loadIhrDataFrameData(spark, ihrOntologyData, directCodes, codeType)
              if (taxonomyName == GlobalConstants.OBSERVATION) {
                ihrDirectUnMapCodes = loadIhrDataFrameData(spark, ihrOntologyData, loincUnMappedOBSDF, codeType)
              } else {
                ihrDirectUnMapCodes = loadIhrDataFrameData(spark, ihrOntologyData, superClassUmmap, codeType)
              }
        
            }
            
            var ihrLoincCode = loincDirectCodes.union(ihrDirectCodes)
              .withColumnRenamed(SparkSQLConstants.TAXONOMY_FSN, GlobalConstants.TAXONOMY)
              .withColumnRenamed(SparkSQLConstants.CONCEPT_ID, SparkSQLConstants.IDENTIFIER)
              .withColumnRenamed(SparkSQLConstants.PREFERRED_TERM, GlobalConstants.PT)
              .withColumnRenamed(SparkSQLConstants.IHR_MAP, SparkSQLConstants.IHR_MAP)
              .withColumnRenamed(SparkSQLConstants.LOINC_CODE, GlobalConstants.LOINCODE)
              .withColumnRenamed(SparkSQLConstants.CHANGECODE_FLAG, GlobalConstants.CHANGE_FLAG)
              .withColumnRenamed(SparkSQLConstants.TYPE, GlobalConstants.IHR_TYPE)
              .withColumnRenamed(SparkSQLConstants.MATCH_TYPE, GlobalConstants.IHR_MATCHTYPE)
              .withColumnRenamed(SparkSQLConstants.MATCH_VALUE, GlobalConstants.VALUE)
              .withColumnRenamed(SparkSQLConstants.SUPER_CLASS_STATUS, GlobalConstants.STATUS)
              
        
            val exitIhrMapCodes = superClassDirectCodes.join(ihrLoincCode, ihrLoincCode(SparkSQLConstants.IDENTIFIER) === superClassDirectCodes(SparkSQLConstants.CONCEPT_ID))
              .filter(same_string(superClassDirectCodes(SparkSQLConstants.SUPERCLASS_LABEL), ihrLoincCode(SparkSQLConstants.IHR_MAP)) === 1)
              .select(
                SparkSQLConstants.TAXONOMY_FSN,
                SparkSQLConstants.CONCEPT_ID,
                SparkSQLConstants.TYPE,
                SparkSQLConstants.PREFERRED_TERM,
                SparkSQLConstants.LOINC_CODE,
                SparkSQLConstants.CHANGECODE_FLAG,
                SparkSQLConstants.IHR_MAP,
                SparkSQLConstants.SUPERCLASS_LABEL,
               ihrLoincCode.col(GlobalConstants.IHR_MATCHTYPE).toString(),
               ihrLoincCode.col(GlobalConstants.VALUE).toString(),
               ihrLoincCode.col(GlobalConstants.STATUS).toString())
              .withColumnRenamed(GlobalConstants.IHR_MATCHTYPE, SparkSQLConstants.MATCH_TYPE)
               .withColumnRenamed(GlobalConstants.VALUE, SparkSQLConstants.MATCH_VALUE)
              .withColumnRenamed(GlobalConstants.STATUS, SparkSQLConstants.SUPER_CLASS_STATUS)
              .cache()
        
            val exitIhrNotMapCodes = superClassDirectCodes.join(ihrLoincCode, ihrLoincCode(SparkSQLConstants.IDENTIFIER) === superClassDirectCodes(SparkSQLConstants.CONCEPT_ID))
              .where(same_string(superClassDirectCodes(SparkSQLConstants.SUPERCLASS_LABEL), ihrLoincCode(SparkSQLConstants.IHR_MAP)) === 0)
              .select(
                SparkSQLConstants.TAXONOMY_FSN,
                SparkSQLConstants.CONCEPT_ID,
                SparkSQLConstants.TYPE,
                SparkSQLConstants.PREFERRED_TERM,
                SparkSQLConstants.LOINC_CODE,
                SparkSQLConstants.CHANGECODE_FLAG,
                SparkSQLConstants.IHR_MAP,
                SparkSQLConstants.SUPERCLASS_LABEL,
               ihrLoincCode.col(GlobalConstants.IHR_MATCHTYPE).toString(),
               ihrLoincCode.col(GlobalConstants.VALUE).toString(),
               ihrLoincCode.col(GlobalConstants.STATUS).toString())
               .withColumnRenamed(GlobalConstants.IHR_MATCHTYPE, SparkSQLConstants.MATCH_TYPE)
              .withColumnRenamed(GlobalConstants.VALUE, SparkSQLConstants.MATCH_VALUE)
              .withColumnRenamed(GlobalConstants.STATUS, SparkSQLConstants.SUPER_CLASS_STATUS)
              .cache()
            worklistId = releaseID + GlobalConstants.W + count + GlobalConstants.UNDER_SCORE + GlobalConstants.WORKLIST_EDIT_BETTER_MATCHED
           
            val editMapBetterCodes = exitIhrNotMapCodes.join(exitIhrMapCodes, exitIhrMapCodes(SparkSQLConstants.CONCEPT_ID) === exitIhrNotMapCodes(SparkSQLConstants.CONCEPT_ID),
              SparkSQLConstants.ANTI_LEFT_JOIN)
              .select(
                SparkSQLConstants.TAXONOMY_FSN,
                SparkSQLConstants.CONCEPT_ID,
                SparkSQLConstants.TYPE,
                SparkSQLConstants.PREFERRED_TERM,
                SparkSQLConstants.LOINC_CODE,
                SparkSQLConstants.CHANGECODE_FLAG,
                SparkSQLConstants.IHR_MAP,
                SparkSQLConstants.SUPERCLASS_LABEL,
                SparkSQLConstants.MATCH_TYPE,
                SparkSQLConstants.MATCH_VALUE)
              .withColumn(SparkSQLConstants.SUPER_CLASS_STATUS,  lit(GlobalConstants.QUEST_AP))
              .withColumn(SparkSQLConstants.ACTION_STATUS, lit(GlobalConstants.REVIEW_PENDING))
              .withColumn(SparkSQLConstants.WORKLIST_ID, lit(worklistId))
              .withColumn(SparkSQLConstants.RELEASE_ID, lit(releaseID))
              .withColumn(SparkSQLConstants.WORKLIST_TYPE, lit(GlobalConstants.EDIT_BETTER_MATCHED))
              .cache().dropDuplicates(SparkSQLConstants.CONCEPT_ID, SparkSQLConstants.IHR_MAP)
        
            log.info("saving  add direct map worklist data for taxonomy " + taxonomyName + " for quest releaseId : " + releaseID)
            mongoDAO.writeDataFrameToMongo(GlobalConstants.WORKLIST_ITEMS, editMapBetterCodes.distinct())
            log.info("saved successfully add direct map worklist data for taxonomy " + taxonomyName + " for quest releaseId : " + releaseID)
            
            worklistId = releaseID + GlobalConstants.W + count + GlobalConstants.UNDER_SCORE + GlobalConstants.WORKLIST_EDIT_NO_MAPFOUND
              
            val editMapNoFoundCodes = superClassDirectCodes.join(ihrLoincCode, ihrLoincCode(SparkSQLConstants.IDENTIFIER) === superClassDirectCodes(SparkSQLConstants.CONCEPT_ID),
              SparkSQLConstants.ANTI_LEFT_JOIN)
              .select(
                SparkSQLConstants.TAXONOMY_FSN,
                SparkSQLConstants.CONCEPT_ID,
                SparkSQLConstants.TYPE,
                SparkSQLConstants.PREFERRED_TERM,
                SparkSQLConstants.LOINC_CODE,
                SparkSQLConstants.CHANGECODE_FLAG,
                SparkSQLConstants.SUPERCLASS_LABEL,
                SparkSQLConstants.MATCH_TYPE,
                SparkSQLConstants.MATCH_VALUE)
              .withColumn(SparkSQLConstants.SUPER_CLASS_STATUS, lit(GlobalConstants.EMPTY_STRING))
              .withColumn(SparkSQLConstants.IHR_MAP, lit(GlobalConstants.DEFAULT_NO_MAP))
              .withColumn(SparkSQLConstants.ACTION_STATUS, lit(GlobalConstants.REVIEW_PENDING))
              .withColumn(SparkSQLConstants.WORKLIST_ID, lit(worklistId))
              .withColumn(SparkSQLConstants.RELEASE_ID, lit(releaseID))
              .withColumn(SparkSQLConstants.WORKLIST_TYPE, lit(GlobalConstants.EDIT_NO_MAPFOUND))
              .cache().dropDuplicates(SparkSQLConstants.CONCEPT_ID, SparkSQLConstants.SUPERCLASS_LABEL)
            //writing edit data into mongo
            log.info("saving  add direct map worklist data for taxonomy " + taxonomyName + " for quest releaseId : " + releaseID)
            mongoDAO.writeDataFrameToMongo(GlobalConstants.WORKLIST_ITEMS, editMapNoFoundCodes.distinct())
            log.info("saved successfully add direct map worklist data for taxonomy " + taxonomyName + " for quest releaseId : " + releaseID)
        
            var editUnmapDirectMap = SparkSession.builder().getOrCreate().emptyDataFrame
        
            if (taxonomyName == GlobalConstants.OBSERVATION) {
              editUnmapDirectMap = loincUnMappedDF.union(ihrDirectUnMapCodes);
            } else {
             editUnmapDirectMap = loincUnMappedDF.union(ihrDirectUnMapCodes.join(loincUnMappedDF, loincUnMappedDF(SparkSQLConstants.CONCEPT_ID) === ihrDirectUnMapCodes(SparkSQLConstants.CONCEPT_ID)
               &&  same_string(loincUnMappedDF(SparkSQLConstants.IHR_MAP), ihrDirectUnMapCodes(SparkSQLConstants.IHR_MAP)) === 1, SparkSQLConstants.ANTI_LEFT_JOIN))
            }
            
            worklistId = releaseID + GlobalConstants.W + count + GlobalConstants.UNDER_SCORE + GlobalConstants.WORKLIST_EDIT_UNMATCHED_DIRECT_MAP
            
            editUnmapDirectMap = editUnmapDirectMap.
              select(
                SparkSQLConstants.TAXONOMY_FSN,
                SparkSQLConstants.CONCEPT_ID,
                SparkSQLConstants.TYPE,
                SparkSQLConstants.PREFERRED_TERM,
                SparkSQLConstants.LOINC_CODE,
                SparkSQLConstants.CHANGECODE_FLAG,
                SparkSQLConstants.IHR_MAP,
                SparkSQLConstants.MATCH_TYPE,
                SparkSQLConstants.MATCH_VALUE,
                SparkSQLConstants.SUPER_CLASS_STATUS)
              .withColumn(SparkSQLConstants.SUPERCLASS_LABEL, lit(GlobalConstants.DEFAULT_NO_MAP))
              .withColumn(SparkSQLConstants.ACTION_STATUS, lit(GlobalConstants.REVIEW_PENDING))
              .withColumn(SparkSQLConstants.WORKLIST_ID, lit(worklistId))
              .withColumn(SparkSQLConstants.RELEASE_ID, lit(releaseID))
              .withColumn(SparkSQLConstants.WORKLIST_TYPE, lit(GlobalConstants.EDIT_UNMATCHED_DIRECT_MAP))
              .cache().dropDuplicates(SparkSQLConstants.CONCEPT_ID, SparkSQLConstants.IHR_MAP)
            log.info("saving  add direct map worklist data for taxonomy " + taxonomyName + " for quest releaseId : " + releaseID)
            mongoDAO.writeDataFrameToMongo(GlobalConstants.WORKLIST_ITEMS, editUnmapDirectMap.distinct())
            log.info("saved successfully add direct map worklist data for taxonomy " + taxonomyName + " for quest releaseId : " + releaseID)
        
            worklistId = releaseID + GlobalConstants.W + count + GlobalConstants.UNDER_SCORE + GlobalConstants.WORKLIST_EDIT_UNMATCHED
            
            val editUmMapNoFoundCodes = superClassUmmap.join(editUnmapDirectMap, editUnmapDirectMap(SparkSQLConstants.CONCEPT_ID) === superClassUmmap(SparkSQLConstants.CONCEPT_ID),
              SparkSQLConstants.ANTI_LEFT_JOIN)
              .select(
                SparkSQLConstants.TAXONOMY_FSN,
                SparkSQLConstants.CONCEPT_ID,
                SparkSQLConstants.TYPE,
                SparkSQLConstants.PREFERRED_TERM,
                SparkSQLConstants.LOINC_CODE)
              .withColumn(SparkSQLConstants.IHR_MAP, lit(GlobalConstants.DEFAULT_NO_MAP))
              .withColumn(SparkSQLConstants.SUPERCLASS_LABEL, lit(GlobalConstants.DEFAULT_NO_MAP))
              .withColumn(SparkSQLConstants.ACTION_STATUS, lit(GlobalConstants.MANUALLY_PROCESSED))
              .withColumn(SparkSQLConstants.WORKLIST_ID, lit(worklistId))
              .withColumn(SparkSQLConstants.RELEASE_ID, lit(releaseID))
              .withColumn(SparkSQLConstants.WORKLIST_TYPE, lit(GlobalConstants.EDIT_UNMATCHED))
              .cache()
        
            log.info("saving  add direct map worklist data for taxonomy " + taxonomyName + " for quest releaseId : " + releaseID)
            mongoDAO.writeDataFrameToMongo(GlobalConstants.WORKLIST_ITEMS, editUmMapNoFoundCodes.distinct())
            log.info("saved successfully add direct map worklist data for taxonomy " + taxonomyName + " for quest releaseId : " + releaseID)
        
            
        
          }
        
          val same_string = udf { (t1: String, t2: String) =>
            if (t1 != null && t2 != null && t1.length() > 0 && t2.length() > 0 &&
              t1.trim().toLowerCase() == t2.trim().toLowerCase()) { 1 }
            else if (t1 == null && t2 != null && t2.length() >= 0) { 0 }
            else if (t1 == null && t2 == null) { 1 }
            else { 0 }
          }
        
          val string_in_array = udf((t1: String, t2: String) => {
            if (t1 != null && t2 != null && t1.length() > 0 && t2.length > 0) {
              if (t2.contains(GlobalConstants.PIPE)) {
                var array = t2.split(GlobalConstants.QUOTE_PIPE)
                array = array.map(x => x.toLowerCase().trim()).array
                if (array.contains(t1.toLowerCase().trim()))
                  true
                else
                  false
              } else {
                if (t1.trim().equalsIgnoreCase(t2.trim()))
                  true
                else
                  false
              }
            } else false
          })
        
          //pt-label
          val same_pt_label = udf((t1: String, t2: String) => {
            if (t1 != null && t2 != null && t1.length() > 0 && t2.length() > 0) {
              var label = GlobalConstants.EMPTY_STRING
              if (t2.contains(GlobalConstants.SQUARE_BRACKET))
                label = t2.substring(0, t2.lastIndexOf(GlobalConstants.SQUARE_BRACKET))
              else
                label = t2
        
              if (t1.trim().equalsIgnoreCase(label.trim()))
                true
              else
                false
            } else false
          })
        
          def compareDataframes(df1: DataFrame, df2: DataFrame, codeType: String): DataFrame = {
            var sourceEditCodesData = df1.sort(SparkSQLConstants.PREFERRED_TERM)
        
            var ihrOntologyData = df2.sort(SparkSQLConstants.PREFERRED_TERM_EN, SparkSQLConstants.LABEL1, SparkSQLConstants.ALIAS_TERM_EN)
        
            //pt-pten
            val same_pt_pten = udf((t1: String, t2: String) => {
              if (t1 != null && t2 != null && t1.length() > 0 && t2.length() > 0 && t1.trim().equalsIgnoreCase(t2.trim()))
                true
              else
                false
            })
            //pt-label
            val same_pt_label = udf((t1: String, t2: String) => {
              if (t1 != null && t2 != null && t1.length() > 0 && t2.length() > 0) {
                var label = GlobalConstants.EMPTY_STRING
                if (t2.contains(GlobalConstants.SQUARE_BRACKET))
                  label = t2.substring(0, t2.lastIndexOf(GlobalConstants.SQUARE_BRACKET))
                else
                  label = t2
        
                if (t1.trim().equalsIgnoreCase(label.trim()))
                  true
                else
                  false
              } else false
            })
            //pt-alias
            val pt_in_alias = udf((t1: String, t2: WrappedArray[String]) => {
              if (t1 != null && t2 != null && t1.length() > 0 && t2.length > 0) {
                var new_t2 = t2.map(x => x.toLowerCase().trim()).array
                if (new_t2.contains(t1.toLowerCase().trim()))
                  true
                else
                  false
              } else false
        
            })
        
            var addDirectMapCodesData = sourceEditCodesData.join(
              ihrOntologyData,
              same_pt_pten(sourceEditCodesData(SparkSQLConstants.PREFERRED_TERM), ihrOntologyData(SparkSQLConstants.PREFERRED_TERM_EN)) ||
                same_pt_label(sourceEditCodesData(SparkSQLConstants.PREFERRED_TERM), ihrOntologyData(SparkSQLConstants.LABEL1)) ||
                pt_in_alias(sourceEditCodesData(SparkSQLConstants.PREFERRED_TERM), ihrOntologyData(SparkSQLConstants.ALIAS_TERM_EN)))
              .withColumn(SparkSQLConstants.ALIAS_TERM, ihrOntologyData(SparkSQLConstants.ALIAS_TERM_EN))
              .withColumn(SparkSQLConstants.IHR_MAP, ihrOntologyData(SparkSQLConstants.LABEL1))
              .withColumn(
                SparkSQLConstants.MATCH_RANK,
                when(same_pt_pten(sourceEditCodesData(SparkSQLConstants.PREFERRED_TERM), ihrOntologyData(SparkSQLConstants.PREFERRED_TERM_EN)), 9)
                  .when(same_pt_label(sourceEditCodesData(SparkSQLConstants.PREFERRED_TERM), ihrOntologyData(SparkSQLConstants.LABEL1)), 8)
                  .when(pt_in_alias(sourceEditCodesData(SparkSQLConstants.PREFERRED_TERM), ihrOntologyData(SparkSQLConstants.ALIAS_TERM_EN)), 7))
              .withColumn(SparkSQLConstants.MATCH_VALUE, concat_ws(
                GlobalConstants.COMMA,
                ihrOntologyData(SparkSQLConstants.LABEL1), ihrOntologyData(SparkSQLConstants.PREFERRED_TERM_EN),
                concat_ws(GlobalConstants.PIPE, ihrOntologyData(SparkSQLConstants.ALIAS_TERM_EN))))
        
            addDirectMapCodesData
          }
        
          def getWorklistID(workBenchData: DataFrame, taxonomyName: String): String = {
            val workListIdDF = workBenchData.filter(col(SparkSQLConstants.TAXONOMY_FSN) === taxonomyName)
              .select(SparkSQLConstants.WORKLIST_ID)
        
            var workListID = GlobalConstants.EMPTY_STRING
            var loop = new Breaks
            loop.breakable(
              workListIdDF.collect().foreach(row => {
                workListID = row.getAs[String](0).trim()
                loop.break()
              }))
            workListID
          }
        
          def loadSuperClassData(spark: SparkSession, file: String): DataFrame = {
            val superClassData = spark.read
              .format(GlobalConstants.CSV_FORMAT)
              .option(GlobalConstants.HEADER, true)
              .option(GlobalConstants.DELIMITER, GlobalConstants.TAB)
              .load(file)
              .withColumn(SparkSQLConstants.SUPERCLASS_CONCEPT_ID, split(col(SparkSQLConstants.LABEL), GlobalConstants.ESCAPE_UNDERSCORE).getItem(1))
              .withColumn(SparkSQLConstants.EXISTING_LABEL, split(col(SparkSQLConstants.LABEL), GlobalConstants.ESCAPE_UNDERSCORE).getItem(2))
              .withColumnRenamed(SparkSQLConstants.MAPPED_CLASS_LABEL, SparkSQLConstants.SUPERCLASS_LABEL)
              .select(SparkSQLConstants.SUPERCLASS_CONCEPT_ID, SparkSQLConstants.SUPERCLASS_LABEL, SparkSQLConstants.MAPPED_CLASS_ID, SparkSQLConstants.EXISTING_LABEL)
            superClassData
          }
        
          def loadLoincDataFrameData(spark: SparkSession, sourceCodesDF: DataFrame, loincSuperClassData: DataFrame, taxonomyName: String): DataFrame = {
        
            var loadLoincDf = sourceCodesDF.join(loincSuperClassData, string_in_array(
              loincSuperClassData(SparkSQLConstants.SUPERCLASS_CONCEPT_ID), sourceCodesDF(SparkSQLConstants.LOINC_CODE)))
              .withColumn(SparkSQLConstants.IHR_MAP, loincSuperClassData(SparkSQLConstants.SUPERCLASS_LABEL))
              .withColumn(SparkSQLConstants.MATCH_TYPE, lit(GlobalConstants.LOINC_NUMBER))
              .withColumn(SparkSQLConstants.MATCH_VALUE, loincSuperClassData(SparkSQLConstants.SUPERCLASS_CONCEPT_ID))
              .withColumn(SparkSQLConstants.SUPER_CLASS_STATUS, lit(GlobalConstants.QUEST_AP))
              .select(
                SparkSQLConstants.TAXONOMY_FSN,
                SparkSQLConstants.CONCEPT_ID,
                SparkSQLConstants.TYPE,
                SparkSQLConstants.PREFERRED_TERM,
                SparkSQLConstants.LOINC_CODE,
                SparkSQLConstants.CHANGECODE_FLAG,
                SparkSQLConstants.IHR_MAP,
                SparkSQLConstants.MATCH_TYPE,
                SparkSQLConstants.MATCH_VALUE,
                SparkSQLConstants.SUPER_CLASS_STATUS)
              .cache()
            loadLoincDf.createOrReplaceTempView(SparkSQLConstants.DF);
            loadLoincDf = spark.sql(SparkSQLConstants.LOINC_MATCHVALUE + taxonomyName + GlobalConstants.SINGLE_QUOTE)
            loadLoincDf
          }
        
          def loadIhrDataFrameData(spark: SparkSession, ihrOntologyData: DataFrame, directCodes: DataFrame, codeType: String): DataFrame = {
        
            val ihrDirectCodes = compareDataframes(directCodes, ihrOntologyData, codeType)
        
            val groupedDirectMapCodes = ihrDirectCodes
              .groupBy(col(SparkSQLConstants.CONCEPT_ID) as SparkSQLConstants.GROUP_CONCEPT_ID)
              .agg(max(col(SparkSQLConstants.MATCH_RANK)) as SparkSQLConstants.MAX_RANK)
        
            val ihrDirectDf = ihrDirectCodes.join(
              groupedDirectMapCodes,
              groupedDirectMapCodes(SparkSQLConstants.GROUP_CONCEPT_ID) === ihrDirectCodes(SparkSQLConstants.CONCEPT_ID) &&
                groupedDirectMapCodes(SparkSQLConstants.MAX_RANK) === ihrDirectCodes(SparkSQLConstants.MATCH_RANK))
              .withColumn(
                SparkSQLConstants.MATCH_TYPE,
                when(col(SparkSQLConstants.MAX_RANK) === 9, GlobalConstants.CODE_PT)
                  .when(col(SparkSQLConstants.MAX_RANK) === 8, GlobalConstants.CODE_LABEL)
                  .when(col(SparkSQLConstants.MAX_RANK) === 7, GlobalConstants.CODE_ALIAS))
              .withColumn(SparkSQLConstants.SUPER_CLASS_STATUS, lit(GlobalConstants.QUEST_AP))
              .select(
                SparkSQLConstants.TAXONOMY_FSN,
                SparkSQLConstants.CONCEPT_ID,
                SparkSQLConstants.TYPE,
                SparkSQLConstants.PREFERRED_TERM,
                SparkSQLConstants.LOINC_CODE,
                SparkSQLConstants.CHANGECODE_FLAG,
                SparkSQLConstants.IHR_MAP,
                SparkSQLConstants.MATCH_TYPE,
                SparkSQLConstants.MATCH_VALUE,
                SparkSQLConstants.SUPER_CLASS_STATUS)
              .cache()
            ihrDirectDf
          }
        
}