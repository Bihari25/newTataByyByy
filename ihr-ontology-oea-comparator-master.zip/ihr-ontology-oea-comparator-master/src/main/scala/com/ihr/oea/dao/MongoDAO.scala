package com.ihr.oea.dao

import java.util.ArrayList

import org.apache.spark.sql.DataFrame
import org.apache.spark.sql.Row
import org.apache.spark.sql.SparkSession
import org.apache.spark.sql.types.LongType
import org.apache.spark.sql.types.StringType
import org.apache.spark.sql.types.StructField
import org.apache.spark.sql.types.StructType

import com.ihr.oea.common.GlobalConstants
import com.ihr.oea.common.SparkSQLConstants
import com.mongodb.spark.MongoSpark

class MongoDAO extends Serializable{
  @throws(classOf[Exception])
  def readDataFrameFromMongo(spark: SparkSession, databaseName: String, collectionName: String): DataFrame = {
    val dataframe = spark.read.format(GlobalConstants.SPARK_DEFAULT_MONGO_DATASOURCE)
      .option(GlobalConstants.DATABASE, databaseName)
      .option(GlobalConstants.COLLECTION, collectionName)
      .load()

    dataframe
  }

  @throws(classOf[Exception])
  def writeDataFrameToMongo(collectionName: String, dataFrame: DataFrame): Unit = {
    MongoSpark.save(dataFrame.write.option(GlobalConstants.COLLECTION, collectionName)
      .mode(GlobalConstants.APPENED_MODE))
  }
}