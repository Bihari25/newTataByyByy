package com.ihr.oea.comparator.snomed

import scala.collection.mutable.Stack
import org.apache.log4j.Level
import org.apache.log4j.Logger
import org.apache.spark.sql.SparkSession
import org.apache.spark.sql.functions.col
import org.apache.spark.sql.functions.lit
import org.apache.spark.sql.functions.when
import org.apache.spark.sql.functions.lower
import org.apache.spark.sql.functions.trim
import com.ihr.oea.common.GlobalConstants
import com.ihr.oea.common.OESConfiguration
import com.ihr.oea.common.SparkSQLConstants
import com.ihr.oea.dao.MongoDAO
import com.ihr.oea.util.ComparatorUtil
import org.apache.spark.sql.types.StructField
import org.apache.spark.sql.types.StructType
import org.apache.spark.sql.types.StringType
import org.apache.spark.sql.types.ArrayType
import org.apache.spark.SparkContext
import org.apache.spark.SparkConf

class SnomedAddMapWorklist{
   def buildReleaseConceptsSchema(): StructType = {
    val schema = StructType(
      Array(
        StructField(SparkSQLConstants.RELEASE_ID, StringType, true),
        StructField(SparkSQLConstants.TAXONOMY_FSN, StringType, true),
        StructField(SparkSQLConstants.CONCEPT_ID, StringType, true),
        StructField(SparkSQLConstants.PREFERRED_TERM, StringType, true),
        StructField(SparkSQLConstants.SYNONYM, ArrayType(StringType), true),
        StructField(SparkSQLConstants.WORKLIST_TYPE, StringType, true),
        StructField(SparkSQLConstants.WORKLIST_ID, StringType, true),
        StructField(SparkSQLConstants.FSN, StringType, true),
        StructField(SparkSQLConstants.EFFECTIVE_TIME, StringType, true),
        StructField(SparkSQLConstants.LANGUAGE_CODE, StringType, true)  
      ))
    schema
  }
  val log = Logger.getLogger(getClass.getName)
    Logger.getLogger("org").setLevel(Level.OFF)
  Logger.getLogger("akka").setLevel(Level.OFF)
  Logger.getLogger("INFO").setLevel(Level.OFF)
  def generateSnomedAddMapWorklist(spark: SparkSession, oesConfiguration: OESConfiguration, releaseID: String) {
   
    try {
      log.info("Running data comparator for ADD Map worklist for snomed releaseId : " + releaseID)
      log.info("loading add codes from db for snomed releaseId : " + releaseID)
      val mongoDAO = new MongoDAO
      // Find the distinct taxonomies in the release from the MongoDB
      val addWorkListData = mongoDAO.readDataFrameFromMongo(spark, oesConfiguration.DATABASE_NAME, GlobalConstants.WORKLIST_ITEMS)
        .filter(col(SparkSQLConstants.RELEASE_ID) === releaseID && col(SparkSQLConstants.WORKLIST_TYPE) === GlobalConstants.ADD_CODES)
        
         
      log.info("Finding  distinct taxonomies in release data for snomed releaseId : " + releaseID)
      // Create a stack to process the taxonomy data
      val util = new ComparatorUtil
      var taxonomyStack = util.findDistinctTaxonomy(addWorkListData)
      
      var count = 1
      var worklistId = GlobalConstants.EMPTY_STRING
      var currentTime = GlobalConstants.EMPTY_STRING
      
       // fetching prepositions , conjunctions and terms data from mongodb
             var propConjDF = mongoDAO.readDataFrameFromMongo(spark, oesConfiguration.DATABASE_NAME, GlobalConstants.SPARK_CONFIG)
              .filter(col(SparkSQLConstants.TYPE) === GlobalConstants.PREPOSITIONS).select(GlobalConstants.VALUE)
              
             val conjDF = mongoDAO.readDataFrameFromMongo(spark, oesConfiguration.DATABASE_NAME, GlobalConstants.SPARK_CONFIG)
              .filter(col(SparkSQLConstants.TYPE) === GlobalConstants.CONJUNCTIONS).select(GlobalConstants.VALUE)
              
              
             var termRermsDF = mongoDAO.readDataFrameFromMongo(spark, oesConfiguration.DATABASE_NAME, GlobalConstants.SPARK_CONFIG)
              .filter(col(SparkSQLConstants.TYPE) === GlobalConstants.REMOVE_TERMS).select(GlobalConstants.VALUE)
              
              propConjDF = propConjDF.union(conjDF).withColumn(GlobalConstants.SPACE, lit(GlobalConstants.EMPTY_STRING))
              termRermsDF = termRermsDF.select(lower(col(GlobalConstants.VALUE))).withColumn(GlobalConstants.SPACE, lit(GlobalConstants.EMPTY_STRING))
            log.info("fetching prepositions , conjunctions and terms data from mongodb  for snomed releaseId : " + releaseID)
        
                 
     while (taxonomyStack.nonEmpty) {       
        val taxonomyName = taxonomyStack.pop
        try {
          var ihrOntologyFiles = GlobalConstants.snomedIHRAnnotationMap.apply(taxonomyName)
          if (null != ihrOntologyFiles) {
            val workListID = SnomedCompareUtil.getWorklistID(addWorkListData, taxonomyName)
        var sourceAddCodesDF =   spark.read.format(GlobalConstants.SPARK_DEFAULT_MONGO_DATASOURCE)
        .option(GlobalConstants.DATABASE,  oesConfiguration.DATABASE_NAME)
        .option(GlobalConstants.COLLECTION, GlobalConstants.WORKLIST_ITEMS)
        .schema(buildReleaseConceptsSchema()).load()
            .filter(col(SparkSQLConstants.WORKLIST_ID) === workListID).withColumn(SparkSQLConstants.CHANGECODE_FLAG, lit(GlobalConstants.EMPTY_STRING))
           .cache()
            
              // src data comparing with ihr data
            log.info("generating add direct map worklist data for taxonomy " + taxonomyName + " for snomed releaseId : " + releaseID)
            var ihrMatchCodes = SnomedCompareUtil.generateSnomedWorklistData(taxonomyName, sourceAddCodesDF, GlobalConstants.ADD_CODES, spark, oesConfiguration, releaseID)
                              . select(
                                        SparkSQLConstants.TAXONOMY_FSN,
                                        SparkSQLConstants.CONCEPT_ID,
                                        SparkSQLConstants.PREFERRED_TERM,
                                        SparkSQLConstants.FSN,
                                        SparkSQLConstants.SYNONYM,
                                        SparkSQLConstants.EFFECTIVE_TIME,
                                        SparkSQLConstants.LANGUAGE_CODE,
                                        SparkSQLConstants.IHR_MAP,
                                        SparkSQLConstants.MATCH_TYPE,
                                        SparkSQLConstants.MATCH_VALUE).withColumn(SparkSQLConstants.SUPER_CLASS_STATUS, lit(GlobalConstants.QUEST_AP))
                                        .cache()
                                        
             log.info("src data comparing with ihr data & jumbled  for snomed releaseId : " + releaseID)   
             

            val ihrjumbSRCodes = sourceAddCodesDF.join(ihrMatchCodes, ihrMatchCodes(SparkSQLConstants.CONCEPT_ID) === sourceAddCodesDF(SparkSQLConstants.CONCEPT_ID), SparkSQLConstants.ANTI_LEFT_JOIN)
                                 .cache()
            //Source data comparator with prepositions , conjunctions and removing
            
            val propConjSrcRem = SnomedCompareUtil.compareSRCPrepoConjDF(propConjDF, ihrjumbSRCodes, spark)
                              .cache()
            
            log.info("Source data comparator with prepositions , conjunctions and removing for snomed releaseId : " + releaseID)   
            
             //IHR data comparator with prepositions , conjunctions and removing

            val propConjIhrRem = SnomedCompareUtil.compareIHRPrepoConjDF(taxonomyName, propConjDF, spark, oesConfiguration, releaseID)
                                  .cache()
            log.info("IHR data comparator with prepositions , conjunctions and removing for snomed releaseId : " + releaseID)  
            
             // src data comparing with ihr data with jumbled after removing comparator & prepositions

            var propConjMapDf = SnomedCompareUtil.generatePropconjDF(propConjSrcRem, propConjIhrRem, GlobalConstants.ADD_CODES)  . select(
                                        SparkSQLConstants.TAXONOMY_FSN,
                                        SparkSQLConstants.CONCEPT_ID,
                                        SparkSQLConstants.PREFERRED_TERM,
                                        SparkSQLConstants.FSN,
                                        SparkSQLConstants.SYNONYM,
                                        SparkSQLConstants.EFFECTIVE_TIME,
                                        SparkSQLConstants.LANGUAGE_CODE,
                                        SparkSQLConstants.IHR_MAP,
                                        SparkSQLConstants.MATCH_TYPE,
                                        SparkSQLConstants.MATCH_VALUE).withColumn(SparkSQLConstants.SUPER_CLASS_STATUS, lit(GlobalConstants.QUEST_AP))
                                        .cache()
             
              propConjMapDf =propConjMapDf.union( ihrMatchCodes)
              log.info("src data comparing with ihr data with jumbled after removing comparator & prepositions for snomed releaseId : " + releaseID)  
            
            val propConjSRCodes = sourceAddCodesDF.join(propConjMapDf, propConjMapDf(SparkSQLConstants.CONCEPT_ID) === sourceAddCodesDF(SparkSQLConstants.CONCEPT_ID), SparkSQLConstants.ANTI_LEFT_JOIN)
                                  .cache()
             //Source data comparator with term removing
            
            var termRemDf = SnomedCompareUtil.compareRemoveTermstDF(termRermsDF, propConjSRCodes, spark).withColumn(SparkSQLConstants.CHANGECODE_FLAG, lit(GlobalConstants.EMPTY_STRING))
                             .cache()
             log.info("Source data comparator with term removing for snomed releaseId : " + releaseID)  
             //Source data comparator with term  and ihr jumbled
             
            var termRemMapDf = SnomedCompareUtil.generateSnomedWorklistData(taxonomyName, termRemDf, GlobalConstants.ADD_CODES, spark, oesConfiguration, releaseID)
                              . withColumn(SparkSQLConstants.SUPER_CLASS_STATUS, lit(GlobalConstants.SV))
                                .withColumnRenamed(SparkSQLConstants.TAXONOMY_FSN,SparkSQLConstants.TAXONOMY)     
                                .withColumnRenamed(SparkSQLConstants.CONCEPT_ID,SparkSQLConstants.ID)
                                .withColumnRenamed(SparkSQLConstants.EFFECTIVE_TIME,SparkSQLConstants.HCP_EFFECTIVE_TIME)   
                                .withColumnRenamed(SparkSQLConstants.LANGUAGE_CODE,SparkSQLConstants.HCP_LANGUAGE_CODE)   
                                    .select(SparkSQLConstants.TAXONOMY,
                                            SparkSQLConstants.ID,     
                                            SparkSQLConstants.PREFERRED_TERM,
                                            SparkSQLConstants.FSN,
                                            SparkSQLConstants.SYNONYM,
                                            SparkSQLConstants.HCP_EFFECTIVE_TIME,
                                            SparkSQLConstants.HCP_LANGUAGE_CODE,
                                            SparkSQLConstants.IHR_MAP,
                                            SparkSQLConstants.MATCH_TYPE,
                                            SparkSQLConstants.MATCH_VALUE)
                                            .cache()
            
            termRemMapDf =  termRemMapDf.join(termRemDf,termRemDf(SparkSQLConstants.CONCEPT_ID) === termRemMapDf(SparkSQLConstants.ID))
                                 .withColumnRenamed(SparkSQLConstants.PREFERRED_TERM,GlobalConstants.TEMP_PT)
                                .withColumnRenamed(SparkSQLConstants.FSN,GlobalConstants.TEMPFSN )
                                .withColumnRenamed(SparkSQLConstants.SYNONYM,GlobalConstants.TEMPSYN)
                                .withColumnRenamed(GlobalConstants.PREFERRED_TERM_SRC,SparkSQLConstants.PREFERRED_TERM)
                                .withColumnRenamed(GlobalConstants.FSN_SRC,SparkSQLConstants.FSN )
                                .withColumnRenamed(GlobalConstants.SYS_SRC,SparkSQLConstants.SYNONYM)
                                .select(SparkSQLConstants.TAXONOMY_FSN,
                                SparkSQLConstants.CONCEPT_ID,    
                                SparkSQLConstants.PREFERRED_TERM,
                                SparkSQLConstants.FSN,
                                SparkSQLConstants.SYNONYM,
                                SparkSQLConstants.EFFECTIVE_TIME,
                                SparkSQLConstants.LANGUAGE_CODE,
                                SparkSQLConstants.IHR_MAP,
                                SparkSQLConstants.MATCH_TYPE,
                                SparkSQLConstants.MATCH_VALUE).withColumn(SparkSQLConstants.SUPER_CLASS_STATUS, lit(GlobalConstants.SV))
                               .cache()
           
            val finalAddMapDF = termRemMapDf.union(propConjMapDf)  
              log.info("Source data comparator with term  and ihr jumbled for snomed releaseId : " + releaseID)  
              
              
            // ADD Direct Map codes
            worklistId = releaseID + GlobalConstants.W + count + GlobalConstants.UNDER_SCORE + GlobalConstants.WORKLIST_ADD_DIRECT_MAP
            val addDirectCodes = finalAddMapDF.select(SparkSQLConstants.TAXONOMY_FSN,
                SparkSQLConstants.CONCEPT_ID,
                SparkSQLConstants.PREFERRED_TERM,
                 SparkSQLConstants.FSN,
                SparkSQLConstants.SYNONYM,
                SparkSQLConstants.EFFECTIVE_TIME,
                SparkSQLConstants.LANGUAGE_CODE,
                SparkSQLConstants.SUPER_CLASS_STATUS,
                SparkSQLConstants.IHR_MAP,
                SparkSQLConstants.MATCH_TYPE,
                SparkSQLConstants.MATCH_VALUE)              
              .withColumn(SparkSQLConstants.ACTION_STATUS, lit(GlobalConstants.REVIEW_PENDING))
              .withColumn(SparkSQLConstants.WORKLIST_ID, lit(worklistId))
              .withColumn(SparkSQLConstants.RELEASE_ID, lit(releaseID))
              .withColumn(SparkSQLConstants.WORKLIST_TYPE, lit(GlobalConstants.ADD_DIRECT_MAP)).dropDuplicates(SparkSQLConstants.CONCEPT_ID, SparkSQLConstants.IHR_MAP)
               .cache()
              
            //writing add data into mongo
            log.info("saving  add direct map worklist data for taxonomy " + taxonomyName + " for snomed releaseId : " + releaseID)
            mongoDAO.writeDataFrameToMongo(GlobalConstants.WORKLIST_ITEMS, addDirectCodes)
            log.info("saved successfully add direct map worklist data for taxonomy " + taxonomyName + " for snomed releaseId : " + releaseID)
            // ADD Unmatched Map codes
            log.info("generating add Unmatched map worklist data for taxonomy " + taxonomyName + " for snomed releaseId : " + releaseID)
            worklistId = releaseID + GlobalConstants.W + count + GlobalConstants.UNDER_SCORE + GlobalConstants.WORKLIST_ADD_UNMATCHED
            val addUnmachedCodes = sourceAddCodesDF.join(addDirectCodes, addDirectCodes(SparkSQLConstants.CONCEPT_ID) === sourceAddCodesDF(SparkSQLConstants.CONCEPT_ID),
              SparkSQLConstants.ANTI_LEFT_JOIN).select(
                SparkSQLConstants.TAXONOMY_FSN,
                SparkSQLConstants.CONCEPT_ID,
                SparkSQLConstants.PREFERRED_TERM,
                 SparkSQLConstants.FSN,
                SparkSQLConstants.SYNONYM,
                SparkSQLConstants.EFFECTIVE_TIME,
                SparkSQLConstants.LANGUAGE_CODE)
              .withColumn(SparkSQLConstants.IHR_MAP, lit(GlobalConstants.DEFAULT_NO_MAP))
              .withColumn(SparkSQLConstants.ACTION_STATUS, lit(GlobalConstants.MANUALLY_PROCESSED))
              .withColumn(SparkSQLConstants.WORKLIST_ID, lit(worklistId))
              .withColumn(SparkSQLConstants.RELEASE_ID, lit(releaseID))
              .withColumn(SparkSQLConstants.WORKLIST_TYPE, lit(GlobalConstants.ADD_UNMATCHED))
              .cache()
              
             
            //writing add data into mongo
            log.info("saving  add Unmatched map worklist data for taxonomy " + taxonomyName + " for snomed releaseId : " + releaseID)
            mongoDAO.writeDataFrameToMongo(GlobalConstants.WORKLIST_ITEMS, addUnmachedCodes)
            log.info("saved successfully add Unmatched map worklist data for taxonomy " + taxonomyName + " for snomed releaseId : " + releaseID)
            count += 1
          } else {
            log.info("No IHR mapping ontology found for taxonomy : " + taxonomyName + " snomed for releaseId : " + releaseID)
          }
        } catch {
          case e: Exception =>
            log.error(s"Exception while running data comparator for Add Map Worklist for taxonomy : " + taxonomyName + " for snomed releaseId : " + releaseID)
            log.error(e.printStackTrace())
        }
     }
      log.info("Completed data comparator for Add Map Worklist for snomed releaseId : " + releaseID)
    } catch {
      case e: Exception =>
        log.error(s"Exception while running data comparator for Add Map Worklist for snomed releaseId : " + releaseID)
        log.error(e.printStackTrace())
      //	throw e
    }
  }
}