package com.ihr.oea.comparator.labcorp

import scala.collection.mutable.WrappedArray
import scala.util.control.Breaks

import org.apache.log4j.Logger
import org.apache.spark.sql.DataFrame
import org.apache.spark.sql.SparkSession
import org.apache.spark.sql.functions.col
import org.apache.spark.sql.functions.concat_ws
import org.apache.spark.sql.functions.lit
import org.apache.spark.sql.functions.max
import org.apache.spark.sql.functions.split
import org.apache.spark.sql.functions.udf
import org.apache.spark.sql.functions.when

import com.ihr.oea.common.GlobalConstants
import com.ihr.oea.common.OESConfiguration
import com.ihr.oea.common.SparkSQLConstants

@throws(classOf[Exception])
class LabCorpCompareUtil {
  val log = Logger.getLogger(getClass.getName)
  def generateLabCorpMapData(taxonomyName: String, sourceCodes: DataFrame, codeType: String, spark: SparkSession, oesConfiguration: OESConfiguration, releaseID: String): DataFrame = {
    
    val same_string = udf { (t1: String, t2: String) =>
              if (t1 != null && t2 != null && t1.length() > 0 && t2.length() > 0 &&
                t1.trim().toLowerCase() == t2.trim().toLowerCase()) { 1 }
              else if (t1 == null && t2 != null && t2.length() >= 0) { 0 }
              else if (t1 == null && t2 == null) { 1 }
              else { 0 }
    }

    val string_in_array = udf((t1: String, t2: String) => {
      if (t1 != null && t2 != null && t1.length() > 0 && t2.length > 0) {
        if (t2.contains(GlobalConstants.PIPE)) {
          var array = t2.split(GlobalConstants.QUOTE_PIPE)
          array = array.map(x => x.toLowerCase().trim()).array
          if (array.contains(t1.toLowerCase().trim()))
            true
          else
            false
        } else {
          if (t1.trim().equalsIgnoreCase(t2.trim()))
            true
          else
            false
        }
      } else false
    })

    //pt-label
    val same_pt_label = udf((t1: String, t2: String) => {
      if (t1 != null && t2 != null && t1.length() > 0 && t2.length() > 0) {
        var label = GlobalConstants.EMPTY_STRING
        if (t2.contains(GlobalConstants.SQUARE_BRACKET))
          label = t2.substring(0, t2.lastIndexOf(GlobalConstants.SQUARE_BRACKET))
        else
          label = t2

        if (t1.trim().equalsIgnoreCase(label.trim()))
          true
        else
          false
      } else false
    })

    log.info("generating annotations files path taxonomy " + taxonomyName + " for LabCorp releaseId : " + releaseID)
  
    var superClassBasePath = oesConfiguration.BASE_PATH + releaseID + GlobalConstants.FORWARD_SLASH + oesConfiguration.SUPERCLASS_DUMP_PATH + GlobalConstants.FORWARD_SLASH
    if (!oesConfiguration.PROFILE.equalsIgnoreCase(GlobalConstants.LOCAL_PROFILE)) {
      superClassBasePath = superClassBasePath.substring(5)
    }
    var ihrAnnotationBasePath = oesConfiguration.BASE_PATH + releaseID + GlobalConstants.FORWARD_SLASH + oesConfiguration.IHR_ANNOTATION_PATH + GlobalConstants.FORWARD_SLASH
    if (!oesConfiguration.PROFILE.equalsIgnoreCase(GlobalConstants.LOCAL_PROFILE)) {
      ihrAnnotationBasePath = ihrAnnotationBasePath.substring(5)
    }
   
    var mapKey = taxonomyName
    if (taxonomyName == GlobalConstants.PROCEDURE)
      mapKey = GlobalConstants.ORDER

    log.info("loading loinc superclass data for taxonomy " + taxonomyName + " for LabCorp releaseId : " + releaseID)
    var loincSuperClassOntologyFile = GlobalConstants.loincSourceAnnotationMap.apply(mapKey)
    val loincSuperClassData = loadSuperClassData(spark, superClassBasePath + loincSuperClassOntologyFile)
    log.info("comparaing loinc superclass data and add code for taxonomy " + taxonomyName + " for LabCorp releaseId : " + releaseID)
    var directCodes = sourceCodes.join(loincSuperClassData, string_in_array(
      loincSuperClassData(SparkSQLConstants.SUPERCLASS_CONCEPT_ID), sourceCodes(SparkSQLConstants.LOINC_CODE)))
      .withColumn(SparkSQLConstants.IHR_MAP, loincSuperClassData(SparkSQLConstants.SUPERCLASS_LABEL))
      .withColumn(SparkSQLConstants.MATCH_TYPE, lit(GlobalConstants.LOINC_NUMBER))
      .withColumn(SparkSQLConstants.MATCH_VALUE, loincSuperClassData(SparkSQLConstants.SUPERCLASS_CONCEPT_ID))
      .withColumn(SparkSQLConstants.SUPER_CLASS_STATUS, lit(GlobalConstants.QUEST_AP))
      .select(
        SparkSQLConstants.TAXONOMY_FSN,
        SparkSQLConstants.CONCEPT_ID,
        SparkSQLConstants.TYPE,
        SparkSQLConstants.PREFERRED_TERM,
        SparkSQLConstants.LOINC_CODE,
        SparkSQLConstants.EFFECTIVE_TIME,
        SparkSQLConstants.IHR_MAP,
        SparkSQLConstants.MATCH_TYPE,
        SparkSQLConstants.MATCH_VALUE,
        SparkSQLConstants.SUPER_CLASS_STATUS,
        SparkSQLConstants.MAPPED_CLASS_ID)
      .cache()

    var sourceCodesDF = SparkSession.builder().getOrCreate().emptyDataFrame
    directCodes.createOrReplaceTempView(SparkSQLConstants.DF);
    
         if (taxonomyName == GlobalConstants.PROCEDURE && codeType == GlobalConstants.ADD_CODES) {
          directCodes = spark.sql(SparkSQLConstants.LOINC_ADDMAP_MATCHVALUE +  taxonomyName +GlobalConstants.SINGLE_QUOTE)
          sourceCodesDF = sourceCodes
        } else {
          directCodes = spark.sql(SparkSQLConstants.LOINC_ADDMAP_MATCHVALUE  +  taxonomyName +GlobalConstants.SINGLE_QUOTE)
          sourceCodesDF = sourceCodes.join(directCodes, directCodes(SparkSQLConstants.CONCEPT_ID) === sourceCodes(SparkSQLConstants.CONCEPT_ID), SparkSQLConstants.ANTI_LEFT_JOIN)
            .filter(sourceCodes.col(SparkSQLConstants.TAXONOMY_FSN) === taxonomyName)
        }
    var ihrOntologyFile = GlobalConstants.questIHRAnnotationMap.apply(taxonomyName)
    if (null != ihrOntologyFile) {
      log.info("Loading IHR annotation data for taxonomy " + taxonomyName + " for LabCorp releaseId : " + releaseID)
      val ihrOntologyData = spark.read
        .format(GlobalConstants.CSV_FORMAT)
        .option(GlobalConstants.HEADER, true)
        .option(GlobalConstants.DELIMITER, GlobalConstants.TAB)
        .load(ihrAnnotationBasePath + ihrOntologyFile)
        .withColumn(SparkSQLConstants.LABEL1, col(SparkSQLConstants.LABEL))
        .withColumnRenamed(SparkSQLConstants.CLASS_ID, SparkSQLConstants.MAPPED_CLASS_ID)
        .withColumn(SparkSQLConstants.ALIAS_TERM_EN, split(col(SparkSQLConstants.ALIAS_TERM_EN), GlobalConstants.SQUARE_PIPE)).select(
          SparkSQLConstants.MAPPED_CLASS_ID,
          SparkSQLConstants.LABEL1,
          SparkSQLConstants.PREFERRED_TERM_EN,
          SparkSQLConstants.ALIAS_TERM_EN)

      log.info("comparing add data and IHR annotation data for taxonomy " + taxonomyName + " for LabCorp releaseId : " + releaseID)
      var ihrDirectCodes = compareDataframes(sourceCodesDF, ihrOntologyData, codeType)
      
      val groupedDirectMapCodes = ihrDirectCodes
        .groupBy(col(SparkSQLConstants.CONCEPT_ID) as SparkSQLConstants.GROUP_CONCEPT_ID)
        .agg(max(col(SparkSQLConstants.MATCH_RANK)) as SparkSQLConstants.MAX_RANK)

      ihrDirectCodes = ihrDirectCodes.join(
        groupedDirectMapCodes,
        groupedDirectMapCodes(SparkSQLConstants.GROUP_CONCEPT_ID) === ihrDirectCodes(SparkSQLConstants.CONCEPT_ID) &&
          groupedDirectMapCodes(SparkSQLConstants.MAX_RANK) === ihrDirectCodes(SparkSQLConstants.MATCH_RANK))
        .withColumn(
          SparkSQLConstants.MATCH_TYPE,
          when(col(SparkSQLConstants.MAX_RANK) === 9, GlobalConstants.CODE_PT)
            .when(col(SparkSQLConstants.MAX_RANK) === 8, GlobalConstants.CODE_LABEL)
            .when(col(SparkSQLConstants.MAX_RANK) === 7, GlobalConstants.CODE_ALIAS))
        .withColumn(SparkSQLConstants.SUPER_CLASS_STATUS, lit(GlobalConstants.QUEST_AP))
        .select(
          SparkSQLConstants.TAXONOMY_FSN,
          SparkSQLConstants.CONCEPT_ID,
          SparkSQLConstants.TYPE,
          SparkSQLConstants.PREFERRED_TERM,
          SparkSQLConstants.LOINC_CODE,
          SparkSQLConstants.EFFECTIVE_TIME,
          SparkSQLConstants.IHR_MAP,
          SparkSQLConstants.MATCH_TYPE,
          SparkSQLConstants.MATCH_VALUE,
          SparkSQLConstants.SUPER_CLASS_STATUS)
        .cache()
        
     ihrDirectCodes = ihrDirectCodes.join(directCodes, directCodes(SparkSQLConstants.CONCEPT_ID) === ihrDirectCodes(SparkSQLConstants.CONCEPT_ID)
           &&  same_string(directCodes(SparkSQLConstants.IHR_MAP), ihrDirectCodes(SparkSQLConstants.IHR_MAP)) === 1, SparkSQLConstants.ANTI_LEFT_JOIN)
           
         directCodes =    directCodes.union(ihrDirectCodes).dropDuplicates(SparkSQLConstants.CONCEPT_ID, SparkSQLConstants.IHR_MAP)
           
    }

    sourceCodesDF = sourceCodesDF.join(directCodes, directCodes(SparkSQLConstants.CONCEPT_ID) === sourceCodesDF(SparkSQLConstants.CONCEPT_ID), SparkSQLConstants.ANTI_LEFT_JOIN)
    log.info("Loading LabCorp superclass data for taxonomy " + taxonomyName + " for LabCorp releaseId : " + releaseID)
    var labCorpSuperClassOntologyFile = GlobalConstants.labCorpSourceAnnotationMap.apply(taxonomyName)
    val fullSuperClassData = loadSuperClassData(spark, superClassBasePath + labCorpSuperClassOntologyFile)
    log.info("comparing add data and labCorp superclass data for taxonomy " + taxonomyName + " for labCorp releaseId : " + releaseID)
    val superClassDirectCodes = sourceCodesDF.join(
      fullSuperClassData,
      same_pt_label(sourceCodesDF(SparkSQLConstants.PREFERRED_TERM), fullSuperClassData(SparkSQLConstants.EXISTING_LABEL)))
      .withColumn(SparkSQLConstants.IHR_MAP, fullSuperClassData(SparkSQLConstants.SUPERCLASS_LABEL))
      .withColumn(SparkSQLConstants.MATCH_TYPE, lit(GlobalConstants.LABCORP_SC))
      .withColumn(SparkSQLConstants.MATCH_VALUE, fullSuperClassData(SparkSQLConstants.EXISTING_LABEL))
       .withColumn(SparkSQLConstants.SUPER_CLASS_STATUS, when(col(SparkSQLConstants.TAXONOMY_FSN) === GlobalConstants.PROCEDURE, GlobalConstants.EMPTY_STRING).otherwise(GlobalConstants.QUEST_AP))
      .select(
        SparkSQLConstants.TAXONOMY_FSN,
        SparkSQLConstants.CONCEPT_ID,
        SparkSQLConstants.TYPE,
        SparkSQLConstants.PREFERRED_TERM,
        SparkSQLConstants.LOINC_CODE,
        SparkSQLConstants.EFFECTIVE_TIME,
        SparkSQLConstants.IHR_MAP,
        SparkSQLConstants.MATCH_TYPE,
        SparkSQLConstants.MATCH_VALUE,
        SparkSQLConstants.SUPER_CLASS_STATUS)
    log.info("genrating direct map data for taxonomy " + taxonomyName + " for labCorp releaseId : " + releaseID)
    directCodes = directCodes.union(superClassDirectCodes).dropDuplicates(SparkSQLConstants.CONCEPT_ID, SparkSQLConstants.IHR_MAP)

    directCodes
  }

  def compareDataframes(df1: DataFrame, df2: DataFrame, codeType: String): DataFrame = {
    var sourceAddCodesData = df1.sort(SparkSQLConstants.PREFERRED_TERM)
    var ihrOntologyData = df2.sort(SparkSQLConstants.PREFERRED_TERM_EN, SparkSQLConstants.LABEL1, SparkSQLConstants.ALIAS_TERM_EN)

    //pt-pten
    val same_pt_pten = udf((t1: String, t2: String) => {
      if (t1 != null && t2 != null && t1.length() > 0 && t2.length() > 0 && t1.trim().equalsIgnoreCase(t2.trim()))
        true
      else
        false
    })
    //pt-label
    val same_pt_label = udf((t1: String, t2: String) => {
      if (t1 != null && t2 != null && t1.length() > 0 && t2.length() > 0) {
        var label = GlobalConstants.EMPTY_STRING
        if (t2.contains(GlobalConstants.SQUARE_BRACKET))
          label = t2.substring(0, t2.lastIndexOf(GlobalConstants.SQUARE_BRACKET))
        else
          label = t2

        if (t1.trim().equalsIgnoreCase(label.trim()))
          true
        else
          false
      } else false
    })
    //pt-alias
    val pt_in_alias = udf((t1: String, t2: WrappedArray[String]) => {
      if (t1 != null && t2 != null && t1.length() > 0 && t2.length > 0) {
        var new_t2 = t2.map(x => x.toLowerCase().trim()).array
        if (new_t2.contains(t1.toLowerCase().trim()))
          true
        else
          false
      } else false

    })

    var addDirectMapCodesData = sourceAddCodesData.join(
      ihrOntologyData,
      same_pt_pten(sourceAddCodesData(SparkSQLConstants.PREFERRED_TERM), ihrOntologyData(SparkSQLConstants.PREFERRED_TERM_EN)) ||
        same_pt_label(sourceAddCodesData(SparkSQLConstants.PREFERRED_TERM), ihrOntologyData(SparkSQLConstants.LABEL1)) ||
        pt_in_alias(sourceAddCodesData(SparkSQLConstants.PREFERRED_TERM), ihrOntologyData(SparkSQLConstants.ALIAS_TERM_EN)))
      .withColumn(SparkSQLConstants.ALIAS_TERM, ihrOntologyData(SparkSQLConstants.ALIAS_TERM_EN))
      .withColumn(SparkSQLConstants.IHR_MAP, ihrOntologyData(SparkSQLConstants.LABEL1))
      .withColumn(
        SparkSQLConstants.MATCH_RANK,
        when(same_pt_pten(sourceAddCodesData(SparkSQLConstants.PREFERRED_TERM), ihrOntologyData(SparkSQLConstants.PREFERRED_TERM_EN)), 9)
          .when(same_pt_label(sourceAddCodesData(SparkSQLConstants.PREFERRED_TERM), ihrOntologyData(SparkSQLConstants.LABEL1)), 8)
          .when(pt_in_alias(sourceAddCodesData(SparkSQLConstants.PREFERRED_TERM), ihrOntologyData(SparkSQLConstants.ALIAS_TERM_EN)), 7))
      .withColumn(SparkSQLConstants.MATCH_VALUE, concat_ws(
        GlobalConstants.COMMA,
        ihrOntologyData(SparkSQLConstants.LABEL1), ihrOntologyData(SparkSQLConstants.PREFERRED_TERM_EN),
        concat_ws(GlobalConstants.PIPE, ihrOntologyData(SparkSQLConstants.ALIAS_TERM_EN))))

    addDirectMapCodesData
  }
  

  def getWorklistID(workBenchData: DataFrame, taxonomyName: String): String = {
    val workListIdDF = workBenchData.filter(col(SparkSQLConstants.TAXONOMY_FSN) === taxonomyName)
      .select(SparkSQLConstants.WORKLIST_ID)

    var workListID = GlobalConstants.EMPTY_STRING
    var loop = new Breaks
    loop.breakable(
      workListIdDF.collect().foreach(row => {
        workListID = row.getAs[String](0).trim()
        loop.break()
      }))
    workListID
  }

  def loadSuperClassData(spark: SparkSession, file: String): DataFrame = {
    val superClassData = spark.read
      .format(GlobalConstants.CSV_FORMAT)
      .option(GlobalConstants.HEADER, true)
      .option(GlobalConstants.DELIMITER, GlobalConstants.TAB)
      .load(file)
      .withColumn(SparkSQLConstants.SUPERCLASS_CONCEPT_ID, split(col(SparkSQLConstants.LABEL), GlobalConstants.ESCAPE_UNDERSCORE).getItem(1))
      .withColumn(SparkSQLConstants.EXISTING_LABEL, split(col(SparkSQLConstants.LABEL), GlobalConstants.ESCAPE_UNDERSCORE).getItem(2))
      .withColumnRenamed(SparkSQLConstants.MAPPED_CLASS_LABEL, SparkSQLConstants.SUPERCLASS_LABEL)
      .select(SparkSQLConstants.SUPERCLASS_CONCEPT_ID, SparkSQLConstants.SUPERCLASS_LABEL, SparkSQLConstants.MAPPED_CLASS_ID, SparkSQLConstants.EXISTING_LABEL)
    superClassData
  }
  
  

}