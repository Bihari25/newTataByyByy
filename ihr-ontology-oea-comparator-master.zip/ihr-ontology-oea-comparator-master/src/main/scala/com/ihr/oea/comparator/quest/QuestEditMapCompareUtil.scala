package com.ihr.oea.comparator.quest

import scala.collection.mutable.WrappedArray
import scala.util.control.Breaks
import com.ihr.oea.util.ComparatorUtil
import org.apache.log4j.Logger
import org.apache.spark.sql.DataFrame
import org.apache.spark.sql.SparkSession
import org.apache.spark.sql.functions.col
import org.apache.spark.sql.functions.max
import org.apache.spark.sql.functions.split
import org.apache.spark.sql.functions.udf
import org.apache.spark.sql.functions.when
import org.apache.spark.sql.functions.concat_ws
import com.ihr.oea.common.GlobalConstants
import com.ihr.oea.common.OESConfiguration
import com.ihr.oea.common.SparkSQLConstants
import org.apache.spark.sql.Row
import org.apache.spark.sql.functions.lit

@throws(classOf[Exception])
class QuestEditMapCompareUtil {
  val log = Logger.getLogger(getClass.getName)
  def generateQuestIHRMapData(taxonomyName: String, sourceCodes: DataFrame, codeType: String, spark: SparkSession, oesConfiguration: OESConfiguration, releaseID: String): DataFrame = {
     val util = new ComparatorUtil
    log.info("generating the IHR annotation path for lonic releaseId : " + releaseID)
    var ihrAnnotationBasePath = oesConfiguration.BASE_PATH + releaseID + GlobalConstants.FORWARD_SLASH + oesConfiguration.IHR_ANNOTATION_PATH + GlobalConstants.FORWARD_SLASH
    if (!oesConfiguration.PROFILE.equalsIgnoreCase(GlobalConstants.LOCAL_PROFILE)) {
      ihrAnnotationBasePath = ihrAnnotationBasePath.substring(5)
    }
    var ihrOntologyFile = GlobalConstants.questIHRAnnotationMap.apply(taxonomyName)
    var addDirectMapCodesData = sourceCodes
    if (null != ihrOntologyFile) {
      log.info("Loading IHR annotation data for taxonomy " + taxonomyName + " for quest releaseId : " + releaseID)
      val fullIHROntologyData = spark.read
        .format(GlobalConstants.CSV_FORMAT)
        .option(GlobalConstants.HEADER, true)
        .option(GlobalConstants.DELIMITER, GlobalConstants.TAB)
        .load(ihrAnnotationBasePath + ihrOntologyFile)
        .withColumn(SparkSQLConstants.FILTER_TYPE, col(SparkSQLConstants.FILTER_TYPE))
        .withColumn(SparkSQLConstants.ALIAS_TERM_EN, split(col(SparkSQLConstants.ALIAS_TERM_EN), GlobalConstants.SQUARE_PIPE))
        .withColumnRenamed(SparkSQLConstants.REVISED_DATE, SparkSQLConstants.ANNOTATION_REVISED_DATE)
      var ihrOntologyData = fullIHROntologyData.select(
        SparkSQLConstants.CLASS_ID,
        SparkSQLConstants.LABEL,
        SparkSQLConstants.PREFERRED_TERM_EN,
        SparkSQLConstants.FILTER_TYPE,
        SparkSQLConstants.ALIAS_TERM_EN)
      log.info("comparing release data and IHR annotation data for taxonomy " + taxonomyName + " for quest releaseId : " + releaseID)
      
      addDirectMapCodesData = util.jumbledDataframes(sourceCodes, ihrOntologyData, codeType)
      log.info("generated directMap data for taxonomy " + taxonomyName + " for quest releaseId : " + releaseID)
    }

    val groupedDirectMapCodes = addDirectMapCodesData
      .groupBy(col(SparkSQLConstants.CONCEPT_ID) as SparkSQLConstants.GROUP_CONCEPT_ID)
      .agg(max(col(SparkSQLConstants.MATCH_RANK)) as SparkSQLConstants.MAX_RANK)

    addDirectMapCodesData = addDirectMapCodesData.join(
      groupedDirectMapCodes,
      groupedDirectMapCodes(SparkSQLConstants.GROUP_CONCEPT_ID) === addDirectMapCodesData(SparkSQLConstants.CONCEPT_ID) &&
        groupedDirectMapCodes(SparkSQLConstants.MAX_RANK) === addDirectMapCodesData(SparkSQLConstants.MATCH_RANK)
        )
		.withColumn(
          SparkSQLConstants.MATCH_TYPE,
          when(col(SparkSQLConstants.MAX_RANK) === 9, GlobalConstants.CODE_PT)
            .when(col(SparkSQLConstants.MAX_RANK) === 8, GlobalConstants.CODE_LABEL)
            .when(col(SparkSQLConstants.MAX_RANK) === 7, GlobalConstants.CODE_ALIAS))
        .withColumn(SparkSQLConstants.SUPER_CLASS_STATUS, lit(GlobalConstants.QUEST_AP))
    addDirectMapCodesData.select(
      SparkSQLConstants.TAXONOMY_FSN,
      SparkSQLConstants.CONCEPT_ID,
      SparkSQLConstants.PREFERRED_TERM,
      SparkSQLConstants.EFFECTIVE_TIME,
      SparkSQLConstants.LANGUAGE_CODE,
      SparkSQLConstants.IHR_MAP,
      SparkSQLConstants.LOINC_CODE,
      SparkSQLConstants.CPT_CODE,
      SparkSQLConstants.TYPE,
      SparkSQLConstants.MATCH_TYPE,
      SparkSQLConstants.MATCH_VALUE,
       SparkSQLConstants.SUPER_CLASS_STATUS,
        SparkSQLConstants.CHANGECODE_FLAG)
  }

   def getWorklistID(workBenchData: DataFrame, taxonomyName: String): String = {
    val workListIdDF = workBenchData.filter(col(SparkSQLConstants.TAXONOMY_FSN) === taxonomyName)
      .select(SparkSQLConstants.WORKLIST_ID)

    var workListID = GlobalConstants.EMPTY_STRING
    var loop = new Breaks
    loop.breakable(
      workListIdDF.collect().foreach(row => {
        workListID = row.getAs[String](0).trim()
        loop.break()
      }))
    workListID
  }

  val same_string = udf { (t1: String, t2: String) =>
    if (t1 != null && t2 != null && t1.length() > 0 && t2.length() > 0 &&
      t1.trim().toLowerCase() == t2.trim().toLowerCase()) { 1 }
    else if (t1 == null && t2 != null && t2.length() >= 0) { 0 }
    else if (t1 == null && t2 == null) { 1 }
    else { 0 }
  }

  val same_array = udf { (t1: WrappedArray[String], t2: WrappedArray[String]) =>
    if (t1 != null && t2 != null && t1.length == t2.length &&
      (t1.map(_.trim().toLowerCase()).intersect(t2.map(_.trim().toLowerCase())).length == t2.length)) { 1 }
    else if (t1 == null && t2 == null) { 0 }
    else if ((t1 == null && t2 != null) || (t2 == null && t1 != null)) { 0 }
    else { 0 }
  }
   
  
   def loadSuperClassData(spark: SparkSession, file: String): DataFrame = {
     var superClassData =   spark.read
      .format(GlobalConstants.CSV_FORMAT)
      .option(GlobalConstants.HEADER, true)
      .option(GlobalConstants.DELIMITER, GlobalConstants.TAB)
      .load(file)
      .withColumn(SparkSQLConstants.SUPERCLASS_CONCEPT_ID, split(col(SparkSQLConstants.LABEL), GlobalConstants.ESCAPE_UNDERSCORE).getItem(1))
      .withColumnRenamed(SparkSQLConstants.MAPPED_CLASS_LABEL, SparkSQLConstants.SUPERCLASS_LABEL)
      .select(SparkSQLConstants.SUPERCLASS_CONCEPT_ID, SparkSQLConstants.SUPERCLASS_LABEL)
    superClassData
  }
    val questUtil = new QuestCompareUtil
    var superClassBasePath : String = GlobalConstants.EMPTY_STRING
    def generateLoincSCMapData(taxonomyName: String,  sourceCodes: DataFrame,codeType: String, spark: SparkSession, oesConfiguration: OESConfiguration, releaseID: String): DataFrame = {
     
     superClassBasePath = oesConfiguration.BASE_PATH + releaseID + GlobalConstants.FORWARD_SLASH + oesConfiguration.SUPERCLASS_DUMP_PATH + GlobalConstants.FORWARD_SLASH
    if (!oesConfiguration.PROFILE.equalsIgnoreCase(GlobalConstants.LOCAL_PROFILE)) {
      superClassBasePath = superClassBasePath.substring(5)
    }
     
    var superClassOntologyFiles = GlobalConstants.questLoincSuperClassMap.apply(taxonomyName)
    val superclassLoinc = questUtil.loadSuperClassData(spark, superClassBasePath + superClassOntologyFiles)
    var  sourceLoincCodesDF = sourceCodes.join(superclassLoinc,
                  (questUtil.string_in_array(superclassLoinc(SparkSQLConstants.SUPERCLASS_CONCEPT_ID) , sourceCodes(SparkSQLConstants.LOINC_CODE))))
                   .withColumn(SparkSQLConstants.MATCH_TYPE, lit(GlobalConstants.LOINC_NUMBER))
                   .withColumn(SparkSQLConstants.IHR_MAP, col(SparkSQLConstants.SUPERCLASS_LABEL))
                   .withColumn(SparkSQLConstants.MATCH_VALUE, superclassLoinc(SparkSQLConstants.SUPERCLASS_CONCEPT_ID))
                   .withColumn(SparkSQLConstants.SUPER_CLASS_STATUS, lit(GlobalConstants.QUEST_AP))
                        .select(SparkSQLConstants.TAXONOMY_FSN,
                              SparkSQLConstants.CONCEPT_ID,
                              SparkSQLConstants.PREFERRED_TERM,
                              SparkSQLConstants.EFFECTIVE_TIME,
                              SparkSQLConstants.LANGUAGE_CODE, 
                              SparkSQLConstants.IHR_MAP,
                              SparkSQLConstants.LOINC_CODE,
                              SparkSQLConstants.CPT_CODE,
                              SparkSQLConstants.TYPE,
                              SparkSQLConstants.MATCH_TYPE,
                              SparkSQLConstants.MATCH_VALUE,
                              SparkSQLConstants.SUPER_CLASS_STATUS,
                              SparkSQLConstants.CHANGECODE_FLAG)
    sourceLoincCodesDF
   }
   def generateQuestSCMapData(taxonomyName: String,  sourceCodes: DataFrame, ihrCodes: DataFrame,codeType: String, spark: SparkSession, oesConfiguration: OESConfiguration, releaseID: String): DataFrame = {
    
    var superClassOntologyFiles = GlobalConstants.questSourceAnnotationMap.apply(taxonomyName)
    val superclassQuest = questUtil.loadSuperClassData(spark, superClassBasePath + superClassOntologyFiles)
     
   val  sourceQuestCodesDF = superclassQuest.join(ihrCodes,ihrCodes(SparkSQLConstants.CONCEPT_ID) === superclassQuest(SparkSQLConstants.SUPERCLASS_CONCEPT_ID), SparkSQLConstants.ANTI_LEFT_JOIN)
                  
                   
   val editSrcSupMapCodes = sourceQuestCodesDF.join(sourceCodes, sourceCodes(SparkSQLConstants.CONCEPT_ID) === sourceQuestCodesDF(SparkSQLConstants.SUPERCLASS_CONCEPT_ID)) 
                                 .withColumn(SparkSQLConstants.MATCH_TYPE, lit(GlobalConstants.EMPTY_STRING))
                   .withColumn(SparkSQLConstants.IHR_MAP, col(SparkSQLConstants.SUPERCLASS_LABEL))
                   .withColumn(SparkSQLConstants.MATCH_VALUE, lit(GlobalConstants.EMPTY_STRING))
                   .withColumn(SparkSQLConstants.SUPER_CLASS_STATUS, lit(GlobalConstants.EMPTY_STRING))
              .select(
               SparkSQLConstants.TAXONOMY_FSN,
                SparkSQLConstants.CONCEPT_ID,
                SparkSQLConstants.PREFERRED_TERM,
                SparkSQLConstants.EFFECTIVE_TIME,
                SparkSQLConstants.LANGUAGE_CODE,
                sourceQuestCodesDF.col(SparkSQLConstants.SUPERCLASS_LABEL).toString(),
                SparkSQLConstants.IHR_MAP,
                SparkSQLConstants.LOINC_CODE,
                SparkSQLConstants.CPT_CODE,
                SparkSQLConstants.TYPE,
                SparkSQLConstants.MATCH_TYPE,
                SparkSQLConstants.MATCH_VALUE,SparkSQLConstants.SUPER_CLASS_STATUS,sourceCodes.col(SparkSQLConstants.CHANGECODE_FLAG).toString())               
    editSrcSupMapCodes
   }

   
   def generateHCPCSCPTMapData(taxonomyName: String,  sourceCodes: DataFrame, ihrMapCodes: DataFrame,codeType: String, spark: SparkSession, oesConfiguration: OESConfiguration, releaseID: String): DataFrame = {
  
    val hcpcscptDF = loadSuperClassData(spark, superClassBasePath + GlobalConstants.HCPCSCPTOntologyFile)
    var  sourceHcpcscptDF = sourceCodes.join(hcpcscptDF,(questUtil.string_in_array(hcpcscptDF(SparkSQLConstants.SUPERCLASS_CONCEPT_ID), sourceCodes(SparkSQLConstants.CPT_CODE))))
                          .withColumn(SparkSQLConstants.MATCH_TYPE, lit(GlobalConstants.CPT))
                          .withColumn(SparkSQLConstants.MATCH_VALUE, hcpcscptDF(SparkSQLConstants.SUPERCLASS_CONCEPT_ID))
                          .withColumn(SparkSQLConstants.SUPER_CLASS_STATUS, lit(GlobalConstants.EMPTY_STRING))
                          .withColumn(SparkSQLConstants.IHR_MAP, col(SparkSQLConstants.SUPERCLASS_LABEL))
                          .select(SparkSQLConstants.TAXONOMY_FSN,
                              SparkSQLConstants.CONCEPT_ID,
                              SparkSQLConstants.PREFERRED_TERM,
                              SparkSQLConstants.EFFECTIVE_TIME,
                              SparkSQLConstants.LANGUAGE_CODE,               
                              SparkSQLConstants.SUPERCLASS_LABEL,
                              SparkSQLConstants.LOINC_CODE,
                              SparkSQLConstants.CPT_CODE,
                              SparkSQLConstants.TYPE,
                              SparkSQLConstants.MATCH_TYPE,
                              SparkSQLConstants.MATCH_VALUE,
                             SparkSQLConstants.SUPER_CLASS_STATUS,
                             SparkSQLConstants.CHANGECODE_FLAG)
                 .withColumnRenamed( SparkSQLConstants.TAXONOMY_FSN , SparkSQLConstants.HCP_TAXONOMY_FSN)
                .withColumnRenamed( SparkSQLConstants.CONCEPT_ID , SparkSQLConstants.HCP_CONCEPT_ID)
                .withColumnRenamed( SparkSQLConstants.PREFERRED_TERM , SparkSQLConstants.HCP_PREFERRED_TERM)
                .withColumnRenamed( SparkSQLConstants.EFFECTIVE_TIME , SparkSQLConstants.HCP_EFFECTIVE_TIME)
                .withColumnRenamed( SparkSQLConstants.LANGUAGE_CODE , SparkSQLConstants.HCP_LANGUAGE_CODE)
                .withColumnRenamed( SparkSQLConstants.SUPERCLASS_LABEL , SparkSQLConstants.HCP_SUPERCLASS_LABEL)
                .withColumnRenamed( SparkSQLConstants.LOINC_CODE , SparkSQLConstants.HCP_LOINC_CODE)
                .withColumnRenamed( SparkSQLConstants.CPT_CODE , SparkSQLConstants.HCP_CPT_CODE)
                .withColumnRenamed( SparkSQLConstants.TYPE , SparkSQLConstants.HCP_TYPE)
                .withColumnRenamed( SparkSQLConstants.MATCH_TYPE , SparkSQLConstants.HCP_MATCH_TYPE)
                .withColumnRenamed( SparkSQLConstants.MATCH_VALUE , SparkSQLConstants.HCP_MATCH_VALUE)
                .withColumnRenamed( SparkSQLConstants.SUPER_CLASS_STATUS , SparkSQLConstants.HCP_SUPER_CLASS_STATUS)
                .withColumnRenamed( SparkSQLConstants.CHANGECODE_FLAG , SparkSQLConstants.HCP_CHANGECODE_FLAG)
 
     var editHCPIhrMapCodes = ihrMapCodes.join(sourceHcpcscptDF, sourceHcpcscptDF(SparkSQLConstants.HCP_CONCEPT_ID) === ihrMapCodes(SparkSQLConstants.CONCEPT_ID), GlobalConstants.LEFT)
                .where(same_string(sourceHcpcscptDF(SparkSQLConstants.HCP_SUPERCLASS_LABEL), ihrMapCodes(SparkSQLConstants.IHR_MAP)) === 1)  
                
    var editHCPIhrMapCodesTemp = editHCPIhrMapCodes.select(SparkSQLConstants.HCP_TAXONOMY_FSN, SparkSQLConstants.HCP_CONCEPT_ID, SparkSQLConstants.HCP_PREFERRED_TERM,
                SparkSQLConstants.HCP_EFFECTIVE_TIME, SparkSQLConstants.HCP_LANGUAGE_CODE, SparkSQLConstants.HCP_SUPERCLASS_LABEL, SparkSQLConstants.HCP_LOINC_CODE, SparkSQLConstants.HCP_CPT_CODE, SparkSQLConstants.HCP_TYPE,
                SparkSQLConstants.HCP_MATCH_TYPE, SparkSQLConstants.HCP_MATCH_VALUE, SparkSQLConstants.HCP_SUPER_CLASS_STATUS,SparkSQLConstants.HCP_CHANGECODE_FLAG)
                .withColumnRenamed(SparkSQLConstants.HCP_TAXONOMY_FSN, SparkSQLConstants.TAXONOMY_FSN)
                .withColumnRenamed(SparkSQLConstants.HCP_CONCEPT_ID, SparkSQLConstants.CONCEPT_ID)
                .withColumnRenamed(SparkSQLConstants.HCP_PREFERRED_TERM, SparkSQLConstants.PREFERRED_TERM)
                .withColumnRenamed(SparkSQLConstants.HCP_EFFECTIVE_TIME, SparkSQLConstants.EFFECTIVE_TIME)
                .withColumnRenamed(SparkSQLConstants.HCP_LANGUAGE_CODE, SparkSQLConstants.LANGUAGE_CODE)
                .withColumnRenamed(SparkSQLConstants.HCP_SUPERCLASS_LABEL, SparkSQLConstants.IHR_MAP)
                .withColumnRenamed(SparkSQLConstants.HCP_LOINC_CODE, SparkSQLConstants.LOINC_CODE)
                .withColumnRenamed(SparkSQLConstants.HCP_CPT_CODE, SparkSQLConstants.CPT_CODE)
                .withColumnRenamed(SparkSQLConstants.HCP_TYPE, SparkSQLConstants.TYPE) 
                .withColumnRenamed(SparkSQLConstants.HCP_CHANGECODE_FLAG, SparkSQLConstants.CHANGECODE_FLAG)
 
     val editNotHCPIhrMapCodes = ihrMapCodes.join(sourceHcpcscptDF,sourceHcpcscptDF(SparkSQLConstants.HCP_CONCEPT_ID) === ihrMapCodes(SparkSQLConstants.CONCEPT_ID), GlobalConstants.FULL_OUTER)
                .where(same_string(sourceHcpcscptDF(SparkSQLConstants.HCP_SUPERCLASS_LABEL), ihrMapCodes(SparkSQLConstants.IHR_MAP)) === 0)
                
     val editHCPCTIhrMapCodes = editNotHCPIhrMapCodes.select(
                SparkSQLConstants.TAXONOMY_FSN,
                SparkSQLConstants.CONCEPT_ID,
                SparkSQLConstants.PREFERRED_TERM,
                SparkSQLConstants.EFFECTIVE_TIME,
                SparkSQLConstants.LANGUAGE_CODE,
                SparkSQLConstants.IHR_MAP,
                SparkSQLConstants.LOINC_CODE,
                SparkSQLConstants.CPT_CODE,
                SparkSQLConstants.TYPE,
                SparkSQLConstants.MATCH_TYPE,
               SparkSQLConstants.MATCH_VALUE,
               SparkSQLConstants.SUPER_CLASS_STATUS,SparkSQLConstants.CHANGECODE_FLAG)    
               
       val editHCPCTSrcMapCodes = editNotHCPIhrMapCodes.select(SparkSQLConstants.HCP_TAXONOMY_FSN, SparkSQLConstants.HCP_CONCEPT_ID, SparkSQLConstants.HCP_PREFERRED_TERM,
                SparkSQLConstants.HCP_EFFECTIVE_TIME, SparkSQLConstants.HCP_LANGUAGE_CODE, SparkSQLConstants.HCP_SUPERCLASS_LABEL, SparkSQLConstants.HCP_LOINC_CODE, SparkSQLConstants.HCP_CPT_CODE, SparkSQLConstants.HCP_TYPE,
                SparkSQLConstants.HCP_MATCH_TYPE, SparkSQLConstants.HCP_MATCH_VALUE, SparkSQLConstants.HCP_SUPER_CLASS_STATUS, SparkSQLConstants.HCP_CHANGECODE_FLAG)
                .withColumnRenamed(SparkSQLConstants.HCP_TAXONOMY_FSN, SparkSQLConstants.TAXONOMY_FSN)
                .withColumnRenamed(SparkSQLConstants.HCP_CONCEPT_ID, SparkSQLConstants.CONCEPT_ID)
                .withColumnRenamed(SparkSQLConstants.HCP_PREFERRED_TERM, SparkSQLConstants.PREFERRED_TERM)
                .withColumnRenamed(SparkSQLConstants.HCP_EFFECTIVE_TIME, SparkSQLConstants.EFFECTIVE_TIME)
                .withColumnRenamed(SparkSQLConstants.HCP_LANGUAGE_CODE, SparkSQLConstants.LANGUAGE_CODE)
                .withColumnRenamed(SparkSQLConstants.HCP_SUPERCLASS_LABEL, SparkSQLConstants.IHR_MAP)
                .withColumnRenamed(SparkSQLConstants.HCP_LOINC_CODE, SparkSQLConstants.LOINC_CODE)
                .withColumnRenamed(SparkSQLConstants.HCP_CPT_CODE, SparkSQLConstants.CPT_CODE)
                .withColumnRenamed(SparkSQLConstants.HCP_TYPE, SparkSQLConstants.TYPE)
                .withColumnRenamed(SparkSQLConstants.HCP_MATCH_TYPE, SparkSQLConstants.MATCH_TYPE)
                .withColumnRenamed(SparkSQLConstants.HCP_MATCH_VALUE, SparkSQLConstants.MATCH_VALUE)
                .withColumnRenamed(SparkSQLConstants.HCP_SUPER_CLASS_STATUS, SparkSQLConstants.SUPER_CLASS_STATUS)
                 .withColumnRenamed(SparkSQLConstants.HCP_CHANGECODE_FLAG, SparkSQLConstants.CHANGECODE_FLAG)
                
                
         val editHCPCIHRCodes = editHCPCTIhrMapCodes.union(editHCPCTSrcMapCodes).filter(col(SparkSQLConstants.CONCEPT_ID).isNotNull)

        editHCPIhrMapCodesTemp = editHCPIhrMapCodesTemp.select(GlobalConstants.STAR)
              .filter(col(SparkSQLConstants.CONCEPT_ID).isNotNull)
                .withColumnRenamed(SparkSQLConstants.HCP_MATCH_TYPE, SparkSQLConstants.MATCH_TYPE)
                .withColumnRenamed(SparkSQLConstants.HCP_MATCH_VALUE, SparkSQLConstants.MATCH_VALUE)
                .withColumnRenamed(SparkSQLConstants.HCP_SUPER_CLASS_STATUS, SparkSQLConstants.SUPER_CLASS_STATUS)  
                
      val editHCPCCodeTemp = editHCPIhrMapCodesTemp.union(editHCPCIHRCodes)
      
      
    editHCPCCodeTemp
   }
   
    def generateMappedData(taxonomyName: String,  ihrCodes: DataFrame,codeType: String, spark: SparkSession, oesConfiguration: OESConfiguration, releaseID: String): DataFrame = {
   
    var superClassOntologyFiles = GlobalConstants.questSourceAnnotationMap.apply(taxonomyName)
    val superclassQuest = questUtil.loadSuperClassData(spark, superClassBasePath + superClassOntologyFiles)
    val mapData = ihrCodes.join( superclassQuest, superclassQuest(SparkSQLConstants.SUPERCLASS_CONCEPT_ID) === ihrCodes(SparkSQLConstants.CONCEPT_ID))  
               .where(same_string(superclassQuest(SparkSQLConstants.SUPERCLASS_LABEL), ihrCodes(SparkSQLConstants.IHR_MAP)) === 0)
              .select(
                SparkSQLConstants.TAXONOMY_FSN,
                SparkSQLConstants.CONCEPT_ID,
                SparkSQLConstants.PREFERRED_TERM,
                SparkSQLConstants.EFFECTIVE_TIME,
                SparkSQLConstants.LANGUAGE_CODE, 
                SparkSQLConstants.SUPERCLASS_LABEL,
                SparkSQLConstants.IHR_MAP,               
                SparkSQLConstants.LOINC_CODE,
                SparkSQLConstants.CPT_CODE,
                SparkSQLConstants.TYPE,
                SparkSQLConstants.MATCH_TYPE,
                SparkSQLConstants.MATCH_VALUE,
                SparkSQLConstants.SUPER_CLASS_STATUS,
                SparkSQLConstants.CHANGECODE_FLAG
                )
    mapData
    }
    
     def generateNotMappedData(taxonomyName: String,  ihrCodes: DataFrame,codeType: String, spark: SparkSession, oesConfiguration: OESConfiguration, releaseID: String): DataFrame = {
     
        var superClassOntologyFiles = GlobalConstants.questSourceAnnotationMap.apply(taxonomyName)
        val superclassQuest = questUtil.loadSuperClassData(spark, superClassBasePath + superClassOntologyFiles)
        
         val noMapData = ihrCodes.join( superclassQuest, superclassQuest(SparkSQLConstants.SUPERCLASS_CONCEPT_ID) === ihrCodes(SparkSQLConstants.CONCEPT_ID))  
                   .where(same_string(superclassQuest(SparkSQLConstants.SUPERCLASS_LABEL), ihrCodes(SparkSQLConstants.IHR_MAP)) === 1)
                  .select(
                    SparkSQLConstants.TAXONOMY_FSN,
                    SparkSQLConstants.CONCEPT_ID,
                    SparkSQLConstants.PREFERRED_TERM,
                    SparkSQLConstants.EFFECTIVE_TIME,
                    SparkSQLConstants.LANGUAGE_CODE, 
                     SparkSQLConstants.SUPERCLASS_LABEL,
                    SparkSQLConstants.IHR_MAP,
                    SparkSQLConstants.LOINC_CODE,
                    SparkSQLConstants.CPT_CODE,
                    SparkSQLConstants.TYPE,
                    SparkSQLConstants.MATCH_TYPE,
                    SparkSQLConstants.MATCH_VALUE,
                    SparkSQLConstants.SUPER_CLASS_STATUS,SparkSQLConstants.CHANGECODE_FLAG )
    noMapData
    
    }
     
     def generateUnmappedDirecMapData(taxonomyName: String,  ihrCodes: DataFrame,codeType: String, spark: SparkSession, oesConfiguration: OESConfiguration, releaseID: String): DataFrame = {
     
          var superClassOntologyFiles = GlobalConstants.questSourceAnnotationMap.apply(taxonomyName)
          val superclassQuest = questUtil.loadSuperClassData(spark, superClassBasePath + superClassOntologyFiles)
         val  editUnmappedDirectMapCodes =  ihrCodes.join(superclassQuest,superclassQuest(SparkSQLConstants.SUPERCLASS_CONCEPT_ID) === ihrCodes(SparkSQLConstants.CONCEPT_ID), SparkSQLConstants.ANTI_LEFT_JOIN)
               .filter(col(SparkSQLConstants.CONCEPT_ID).isNotNull)                
                                          
    editUnmappedDirectMapCodes
   }


}