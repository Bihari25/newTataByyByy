package com.ihr.oea.comparator.fdb

import scala.collection.mutable.ArrayBuffer
import scala.collection.mutable.Stack
import scala.collection.mutable.WrappedArray
import org.apache.log4j.Logger
import org.apache.spark.sql.functions.concat_ws
import org.apache.spark.sql.SparkSession
import org.apache.spark.sql.functions.udf
import org.apache.spark.sql.types.StringType
import org.apache.spark.sql.types.StructField
import org.apache.spark.sql.types.StructType
import org.apache.spark.sql.functions._
import org.apache.spark.sql.functions.udf
import com.ihr.oea.common.GlobalConstants
import com.ihr.oea.common.OESConfiguration
import com.ihr.oea.common.SparkSQLConstants
import com.ihr.oea.dao.MongoDAO
import com.ihr.oea.util.ComparatorUtil
import java.util.ArrayList

class FDBAddEditWorklist {
  val log = Logger.getLogger(getClass.getName)

  def buildReleaseConceptsSchema(): StructType = {
    val schema = StructType(
      Array(
        StructField(SparkSQLConstants.RELEASE_ID, StringType, true),
        StructField(SparkSQLConstants.TAXONOMY_FSN, StringType, true),
        StructField(SparkSQLConstants.CONCEPT_ID, StringType, true),
        StructField(SparkSQLConstants.PREFERRED_TERM, StringType, true),
        StructField(SparkSQLConstants.TYPE, StringType, true),
        StructField(SparkSQLConstants.STATUS, StringType, true),
        StructField(SparkSQLConstants.GEN_MED_ID, StringType, true),
        StructField(SparkSQLConstants.FDB_TAXONOMYID, StringType, true),
        StructField(SparkSQLConstants.PROCESS_STATUS, StringType, true),
        StructField(SparkSQLConstants.REL_PREFERRED_TERM, StringType, true),
        StructField(SparkSQLConstants.REL_TYPE, StringType, true),
        StructField(SparkSQLConstants.REL_STATUS, StringType, true),
        StructField(SparkSQLConstants.REL_GEN_MEDID, StringType, true),
        StructField(SparkSQLConstants.EFFECTIVE_TIME, StringType, true)))
    schema
  }

  def generateFDBAddEditWorklist(spark: SparkSession, oesConfiguration: OESConfiguration, releaseID: String) {
    try {
      log.info("Running data comparator for ADD worklist for FDB releaseId : " + releaseID)
      log.info("loading release concepts from db for FDB releaseId : " + releaseID)
      val mongoDAO = new MongoDAO
      
          
      val fdbConcepts = spark.read.format(GlobalConstants.SPARK_DEFAULT_MONGO_DATASOURCE)
        .option(GlobalConstants.DATABASE,  oesConfiguration.DATABASE_NAME)
        .option(GlobalConstants.COLLECTION, GlobalConstants.RELEASE_CONCEPTS)
        .schema(buildReleaseConceptsSchema())
        .load().filter(col(SparkSQLConstants.RELEASE_ID) === releaseID && col(SparkSQLConstants.PROCESS_STATUS) === GlobalConstants.PROCESSED)
        
        
      val catalogDF = mongoDAO.readDataFrameFromMongo(spark, oesConfiguration.DATABASE_NAME, GlobalConstants.CATALOG).filter(col(SparkSQLConstants.RELEASE_ID) === releaseID)
      val  revisedDate = catalogDF.select(GlobalConstants.RELEASE_DATE).first().getString(0)
      
      log.info("revisedDate::"+ revisedDate)      
      log.info("Finding  distinct taxonomies in release data for FDB releaseId : " + releaseID)
      val util = new ComparatorUtil
      var taxonomyStack = util.findDistinctTaxonomy(fdbConcepts)
      
        val same_string = udf { (t1: String, t2: String) =>
        if (t1 != null && t2 != null && t1.length() > 0 && t2.length() > 0 &&
          t1.trim().toLowerCase() == t2.trim().toLowerCase()) { 1 }
        else if (t1 == null && t2 != null && t2.length() >= 0) { 0 }
        else if (t1 == null && t2 == null ) { 1 }
        else { 0 }
      }
		  
		   val same_array = udf { (t1: WrappedArray[String], t2: WrappedArray[String]) =>
		     if (t1 != null && t2 != null && t1.length == t2.length &&
          (t1.map(_.trim().toLowerCase()).intersect(t2.map(_.trim().toLowerCase())).length == t2.length))
          { 1 }  
        else if (t1 == null && t2 == null) { 1 }
        else if ((t1 == null && t2 != null) || (t2 == null && t1 != null)) { 0 }        
        else { 0 }
      }

      log.info("generating the source annotation path for lonic releaseId : " + releaseID)
     
      var sourceAnnotationBasePath = oesConfiguration.BASE_PATH + releaseID + GlobalConstants.FORWARD_SLASH + oesConfiguration.SOURCE_ANNOTATION_PATH + GlobalConstants.FORWARD_SLASH
      if (!oesConfiguration.PROFILE.equalsIgnoreCase(GlobalConstants.LOCAL_PROFILE))
        sourceAnnotationBasePath = sourceAnnotationBasePath.substring(5)
      
      var count = 1
      var worklistId = GlobalConstants.EMPTY_STRING
      var currentTime = GlobalConstants.EMPTY_STRING
      while (taxonomyStack.nonEmpty) {
        val taxonomyName = taxonomyStack.pop
        try {
          var taxonomyOntologyFileName = GlobalConstants.fdbSourceAnnotationMap
          if (null != taxonomyOntologyFileName) {
            log.info("Loading the source annoataion data for taxonomy " + taxonomyName + " for FDB releaseId : " + releaseID)
            val sourceDataDF = spark.read
              .format(GlobalConstants.CSV_FORMAT)
              .option(GlobalConstants.HEADER, true)
              .option(GlobalConstants.DELIMITER, GlobalConstants.TAB)
              .load(sourceAnnotationBasePath + taxonomyOntologyFileName)
              
            var releaseData = fdbConcepts.filter(col(SparkSQLConstants.TAXONOMY_FSN) === taxonomyName)
            
            log.info("Loading the source annoataion data for taxonomy " + taxonomyName + " for FDB  " )
            var taxonomyId = GlobalConstants.fdbTaxonomyIds.apply(taxonomyName)
            log.info("Loading the source annoataion data for taxonomy " + taxonomyName + " for FDB taxonomyId : "+taxonomyId )
            var fdbtaxonomyId:String = taxonomyId+GlobalConstants.UNDER_SCORE
            releaseData = releaseData.select(GlobalConstants.STAR).withColumn(SparkSQLConstants.FDB_TAXONOMYID,concat(lit(fdbtaxonomyId),releaseData.col(SparkSQLConstants.CONCEPT_ID)));

            // ADD codes
            worklistId = releaseID + GlobalConstants.W + count + GlobalConstants.UNDER_SCORE + GlobalConstants.WORKLIST_ADD_CODES
           val addCodesData = releaseData.join(sourceDataDF, lower(sourceDataDF(SparkSQLConstants.CLASS_ID)) === lower(releaseData(SparkSQLConstants.FDB_TAXONOMYID)), SparkSQLConstants.ANTI_LEFT_JOIN)
            log.info("generating add code work list data for taxonomy : " + taxonomyName + " for FDB releaseId : " + releaseID)
            val addCodesWorklistData = addCodesData
              .select(
                SparkSQLConstants.TAXONOMY_FSN,
                SparkSQLConstants.CONCEPT_ID,
                SparkSQLConstants.TYPE,
                SparkSQLConstants.PREFERRED_TERM,
                SparkSQLConstants.STATUS,
                SparkSQLConstants.GEN_MED_ID,                
                SparkSQLConstants.EFFECTIVE_TIME)
              .withColumn(SparkSQLConstants.ACTION_STATUS, lit(GlobalConstants.REVIEW_PENDING))
              .withColumn(SparkSQLConstants.WORKLIST_ID, lit(worklistId))
              .withColumn(SparkSQLConstants.RELEASE_ID, lit(releaseID))
              .withColumn(SparkSQLConstants.WORKLIST_TYPE, lit(GlobalConstants.ADD_CODES))
              
            //writing add data into mongo
            log.info("saving  add code work list data for taxonomy " + taxonomyName + " for FDB releaseId : " + releaseID)
            mongoDAO.writeDataFrameToMongo(GlobalConstants.WORKLIST_ITEMS, addCodesWorklistData)
            log.info("saved successfully add code work list data for taxonomy " + taxonomyName + " for FDB releaseId : " + releaseID)
            
              // EDIT codes
            var relTypeData = releaseData.select(GlobalConstants.STAR)
                              .withColumnRenamed(SparkSQLConstants.TYPE, SparkSQLConstants.RELEASE_TYPE)
                              .withColumnRenamed(SparkSQLConstants.STATUS, SparkSQLConstants.RELEASE_STATUS)
             var  sourceData = sourceDataDF.select(GlobalConstants.STAR)
                              .withColumn(SparkSQLConstants.PREFERRED_TERM_EN, split(col(SparkSQLConstants.LABEL), GlobalConstants.ESCAPE_UNDERSCORE).getItem(2))
                              
           worklistId = releaseID + GlobalConstants.W + count + GlobalConstants.UNDER_SCORE + GlobalConstants.WORKLIST_EDIT_CODES
           
            val editCodesData = relTypeData.join(sourceData, relTypeData(SparkSQLConstants.FDB_TAXONOMYID) === sourceData(SparkSQLConstants.CLASS_ID))
                  .where(same_array(split(relTypeData.col(SparkSQLConstants.PREFERRED_TERM),GlobalConstants.SPACE), split(sourceData.col(SparkSQLConstants.PREFERRED_TERM_EN),GlobalConstants.SPACE)) === 0 || 
                  same_string(relTypeData(SparkSQLConstants.RELEASE_TYPE), sourceData(SparkSQLConstants.TYPE)) === 0 ||
                   same_string(relTypeData(SparkSQLConstants.RELEASE_STATUS), sourceData(SparkSQLConstants.STATUS)) === 0 ||
                    same_string(relTypeData(SparkSQLConstants.GEN_MED_ID), sourceData(SparkSQLConstants.FDB_GEN_MED_ID)) === 0
                )
                .withColumn(SparkSQLConstants.REL_PREFERRED_TERM, relTypeData(SparkSQLConstants.PREFERRED_TERM)) 
                .withColumn(SparkSQLConstants.REL_TYPE, relTypeData(SparkSQLConstants.RELEASE_TYPE))
                .withColumn(SparkSQLConstants.REL_STATUS, relTypeData(SparkSQLConstants.RELEASE_STATUS))
                .withColumn(SparkSQLConstants.REL_GEN_MEDID, relTypeData(SparkSQLConstants.GEN_MED_ID))
                .withColumn(SparkSQLConstants.PREFERRED_TERM, when(same_array(split(relTypeData.col(SparkSQLConstants.PREFERRED_TERM),GlobalConstants.SPACE), split(sourceData.col(SparkSQLConstants.PREFERRED_TERM_EN),GlobalConstants.SPACE)) === 0,
                 relTypeData(SparkSQLConstants.PREFERRED_TERM)).otherwise(null)) 
                .withColumn(SparkSQLConstants.TYPE, when( same_string(relTypeData(SparkSQLConstants.RELEASE_TYPE), sourceData(SparkSQLConstants.TYPE)) === 0,
                 relTypeData(SparkSQLConstants.RELEASE_TYPE)).otherwise(null))
                 .withColumn(SparkSQLConstants.STATUS, when( same_string(relTypeData(SparkSQLConstants.RELEASE_STATUS), sourceData(SparkSQLConstants.STATUS)) === 0,
                 relTypeData(SparkSQLConstants.RELEASE_STATUS)).otherwise(null))
                 .withColumn(SparkSQLConstants.GEN_MED_ID, when( same_string(relTypeData(SparkSQLConstants.GEN_MED_ID), sourceData(SparkSQLConstants.FDB_GEN_MED_ID)) === 0,
                 relTypeData(SparkSQLConstants.GEN_MED_ID)).otherwise(null))
                .withColumn(SparkSQLConstants.CHANGECODE_FLAG, when(col(SparkSQLConstants.PREFERRED_TERM).isNotNull,GlobalConstants.TRUE).otherwise(GlobalConstants.FALSE))
                
               
            val columnNames = editCodesData.distinct().columns.toArray
            val requiredColumns = ArrayBuffer[String](
              SparkSQLConstants.TAXONOMY_FSN,
              SparkSQLConstants.CONCEPT_ID,
              SparkSQLConstants.PREFERRED_TERM,             
              SparkSQLConstants.TYPE,
              SparkSQLConstants.STATUS,
              SparkSQLConstants.GEN_MED_ID,
              SparkSQLConstants.REL_PREFERRED_TERM,
              SparkSQLConstants.REL_TYPE,
              SparkSQLConstants.REL_STATUS,
              SparkSQLConstants.REL_GEN_MEDID,
              SparkSQLConstants.CHANGECODE_FLAG
               )
              
            val selectedColumns = requiredColumns.intersect(columnNames)
            val colNames = selectedColumns.map(name => col(name))
            log.info("generating edit code work list data for taxonomy " + taxonomyName + " for FDB releaseId : " + releaseID  + "colNames"+ colNames)
            var editCodesWorklistData = editCodesData.distinct().select(colNames: _*)
              .withColumn(SparkSQLConstants.ACTION_STATUS, lit(GlobalConstants.REVIEW_PENDING))
              .withColumn(SparkSQLConstants.WORKLIST_ID, lit(worklistId))
              .withColumn(SparkSQLConstants.RELEASE_ID, lit(releaseID))
              .withColumn(SparkSQLConstants.WORKLIST_TYPE, lit(GlobalConstants.EDIT_CODES))
              .withColumn(SparkSQLConstants.REVISED_DATE, lit(revisedDate))
           log.info("saving edit code work list data for taxonomy " + taxonomyName + " for FDB releaseId : " + releaseID)
            //writing edit data into mongo
           
            mongoDAO.writeDataFrameToMongo(GlobalConstants.WORKLIST_ITEMS, editCodesWorklistData.distinct())
            log.info("saved edit code work list data for taxonomy " + taxonomyName + " for FDB releaseId : " + releaseID)
            count += 1
          } else {
            log.info("No Source ontology file found for taxonomy : " + taxonomyName)
          }
        } catch {
          case e: Exception =>
            log.error(s"Exception while running data comparator for taxonomy " + taxonomyName + " for ADD worklist for FDB releaseId : " + releaseID)
            log.error(e.printStackTrace())
        }
      }
      log.info("Completed data comparator for ADD worklist for FDB releaseId : " + releaseID)
    } catch {
      case e: Exception =>
        log.error(s"Exception while running data comparator for ADD worklist for FDB releaseId : " + releaseID)
        log.error(e.printStackTrace())
      //	throw e
    }
  }
}
