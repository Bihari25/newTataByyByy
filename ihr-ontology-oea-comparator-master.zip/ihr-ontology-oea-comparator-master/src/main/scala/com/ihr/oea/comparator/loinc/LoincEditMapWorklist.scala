package com.ihr.oea.comparator.loinc

import java.time.LocalDateTime
import java.time.format.DateTimeFormatter
import java.util.ArrayList

import scala.collection.mutable.Stack
import scala.util.control.Breaks

import org.apache.spark.sql.Row
import org.apache.spark.sql.SparkSession
import org.apache.spark.sql.functions.col
import org.apache.spark.sql.functions.lit
import org.apache.spark.sql.functions.split
import org.apache.spark.sql.types.StringType
import org.apache.spark.sql.types.StructField
import org.apache.spark.sql.types.StructType
import org.apache.spark.sql.functions.udf
import org.apache.spark.sql.functions.when

import com.ihr.oea.common.GlobalConstants
import com.ihr.oea.common.OESConfiguration
import com.ihr.oea.common.SparkSQLConstants
import com.ihr.oea.dao.MongoDAO
import org.apache.log4j.Logger
import com.ihr.oea.comparator.snomed.SnomedCompareUtil
import com.ihr.oea.util.ComparatorUtil

class LoincEditMapWorklist {
  val log = Logger.getLogger(getClass.getName)
  def generateLoincEditMapWorklist(spark: SparkSession, oesConfiguration: OESConfiguration, releaseID: String) {
    try {
      log.info("Running data comparator for Edit Map worklist for loinc releaseId : " + releaseID)
      log.info("loading edit codes from db for loinc releaseId : " + releaseID)

      val mongoDAO = new MongoDAO
      log.info("Finding  distinct taxonomies in release data for loinc releaseId : " + releaseID)
      val editWorkListData = mongoDAO.readDataFrameFromMongo(spark, oesConfiguration.DATABASE_NAME, GlobalConstants.WORKLIST_ITEMS)
        .filter(col(SparkSQLConstants.RELEASE_ID) === releaseID && col(SparkSQLConstants.WORKLIST_TYPE) === GlobalConstants.EDIT_CODES)

      // Find the distinct taxonomies in the release from the MongoDB
      val util = new ComparatorUtil
      var taxonomyStack = util.findDistinctTaxonomy(editWorkListData)

     val superClassSchema = StructType(Array(
        StructField(SparkSQLConstants.SUPERCLASS_ID, StringType, true),
         StructField(SparkSQLConstants.LABEL, StringType, true),
         StructField(SparkSQLConstants.MAPPED_CLASS_ID, StringType, true),
        StructField(SparkSQLConstants.SUPERCLASS_LABEL, StringType, true)))

      var count = 1
      var worklistId = GlobalConstants.EMPTY_STRING
      var currentTime = GlobalConstants.EMPTY_STRING
      while (taxonomyStack.nonEmpty) {
        val taxonomyName = taxonomyStack.pop
        try {
          log.info("Loading the IHR annoataion mapping for taxonomy " + taxonomyName + " for loinc releaseId : " + releaseID)
          var ihrOntologyFiles = GlobalConstants.loincIHRAnnotationMap.apply(taxonomyName)
          if (null != ihrOntologyFiles) {
            val workListID = LoincCompareUtil.getWorklistID(editWorkListData, taxonomyName)
            val sourceEditCodesDF = mongoDAO.readDataFrameFromMongo(spark, oesConfiguration.DATABASE_NAME, GlobalConstants.WORKLIST_ITEMS)
              .filter(col(SparkSQLConstants.WORKLIST_ID) === workListID)
              .withColumn(SparkSQLConstants.PREFERRED_TERM, col(SparkSQLConstants.REL_PREFERRED_TERM))
            log.info("generating edit direct map worklist data for taxonomy " + taxonomyName + " for loinc releaseId : " + releaseID)
            val ihrMatchCodes = LoincCompareUtil.generateLoincIHRMapData(taxonomyName, sourceEditCodesDF, GlobalConstants.EDIT_CODES, spark, oesConfiguration, releaseID)
           .select(
                SparkSQLConstants.TAXONOMY_FSN,
                SparkSQLConstants.CONCEPT_ID,
                SparkSQLConstants.PREFERRED_TERM,
                SparkSQLConstants.EFFECTIVE_TIME,
                SparkSQLConstants.LANGUAGE_CODE,
                SparkSQLConstants.ALIAS_TERM,
                SparkSQLConstants.IHR_MAP,
                 SparkSQLConstants.MATCH_TYPE,
                SparkSQLConstants.MATCH_VALUE,
                SparkSQLConstants.CHANGECODE_FLAG)            
            log.info("generating superclass annotation path for lonic releaseId : " + releaseID)
            var superClassBasePath = oesConfiguration.BASE_PATH + releaseID + GlobalConstants.FORWARD_SLASH + oesConfiguration.SUPERCLASS_DUMP_PATH + GlobalConstants.FORWARD_SLASH
            if (!oesConfiguration.PROFILE.equalsIgnoreCase(GlobalConstants.LOCAL_PROFILE)) {
              superClassBasePath = superClassBasePath.substring(5)
            }
            
            log.info("Loading superclass annotation data for taxonomy " + taxonomyName + " for loinc releaseId : " + releaseID)
            var superClassOntologyFile = GlobalConstants.loincSourceAnnotationMap.apply(taxonomyName)
            val superclass_ontology_df = spark.read
              .format(GlobalConstants.CSV_FORMAT)
              .option(GlobalConstants.HEADER, true)
              .option(GlobalConstants.DELIMITER, GlobalConstants.TAB)
              .load(superClassBasePath + superClassOntologyFile)
              .withColumnRenamed(SparkSQLConstants.CLASS_ID, SparkSQLConstants.SUPERCLASS_ID)
              .withColumnRenamed(SparkSQLConstants.MAPPED_CLASS_LABEL, SparkSQLConstants.SUPERCLASS_LABEL)
              .withColumn(SparkSQLConstants.SUPERCLASS_CONCEPT_ID, split(col(SparkSQLConstants.SUPERCLASS_ID), GlobalConstants.ESCAPE_UNDERSCORE).getItem(1))

            val same_string = udf { (t1: String, t2: String) =>
              if (t1 != null && t2 != null && t1.length() > 0 && t2.length() > 0 &&
                t1.trim().toLowerCase() == t2.trim().toLowerCase()) { 1 }
              else if (t1 == null && t2 != null && t2.length() >= 0) { 0 }
              else if (t1 == null && t2 == null) { 1 }
              else { 0 }
            }

            //Edit Map - Better Match
            log.info("generating Edit Map - Better Match worklist data for taxonomy " + taxonomyName + " for loinc releaseId : " + releaseID)
            worklistId = releaseID + GlobalConstants.W + count + GlobalConstants.UNDER_SCORE + GlobalConstants.WORKLIST_EDIT_BETTER_MATCHED
            val editBetterMapCodes = ihrMatchCodes.join(
              superclass_ontology_df,
              superclass_ontology_df(SparkSQLConstants.SUPERCLASS_CONCEPT_ID) === ihrMatchCodes(SparkSQLConstants.CONCEPT_ID))
              .where(same_string(superclass_ontology_df(SparkSQLConstants.SUPERCLASS_LABEL), ihrMatchCodes(SparkSQLConstants.IHR_MAP)) === 0)
              .select(
                SparkSQLConstants.TAXONOMY_FSN,
                SparkSQLConstants.CONCEPT_ID,
                SparkSQLConstants.PREFERRED_TERM,
                SparkSQLConstants.EFFECTIVE_TIME,
                SparkSQLConstants.LANGUAGE_CODE,
                SparkSQLConstants.ALIAS_TERM,
                SparkSQLConstants.IHR_MAP,
                SparkSQLConstants.SUPERCLASS_LABEL,
                 SparkSQLConstants.MATCH_TYPE,
                SparkSQLConstants.MATCH_VALUE,
                SparkSQLConstants.CHANGECODE_FLAG)
              .withColumn(SparkSQLConstants.ACTION_STATUS, lit(GlobalConstants.REVIEW_PENDING))
              .withColumn(SparkSQLConstants.WORKLIST_ID, lit(worklistId))
              .withColumn(SparkSQLConstants.RELEASE_ID, lit(releaseID))
              .withColumn(SparkSQLConstants.WORKLIST_TYPE, lit(GlobalConstants.EDIT_BETTER_MATCHED))
              
            //writing add data into mongo
            log.info("saving  Edit Map - Better Match worklist data for taxonomy " + taxonomyName + " for loinc releaseId : " + releaseID)
            mongoDAO.writeDataFrameToMongo(GlobalConstants.WORKLIST_ITEMS, editBetterMapCodes)
            log.info("saved successfully Edit Map - Better Match worklist data for taxonomy " + taxonomyName + " for loinc releaseId : " + releaseID)
            //Edit  Unmapped – Direct Map
            log.info("generating Edit  Unmapped – Direct Map worklist data for taxonomy " + taxonomyName + " for loinc releaseId : " + releaseID)
            worklistId = releaseID + GlobalConstants.W + count + GlobalConstants.UNDER_SCORE + GlobalConstants.WORKLIST_EDIT_UNMATCHED_DIRECT_MAP
            val editUnmappedDirectMapCodes = ihrMatchCodes.join(
              superclass_ontology_df,
              superclass_ontology_df(SparkSQLConstants.SUPERCLASS_CONCEPT_ID) === ihrMatchCodes(SparkSQLConstants.CONCEPT_ID), SparkSQLConstants.ANTI_LEFT_JOIN)
              .select(
                SparkSQLConstants.TAXONOMY_FSN,
                SparkSQLConstants.CONCEPT_ID,
                SparkSQLConstants.PREFERRED_TERM,
                SparkSQLConstants.EFFECTIVE_TIME,
                SparkSQLConstants.LANGUAGE_CODE,
                SparkSQLConstants.ALIAS_TERM,
                SparkSQLConstants.IHR_MAP,
                SparkSQLConstants.MATCH_TYPE,
                SparkSQLConstants.MATCH_VALUE,
                SparkSQLConstants.CHANGECODE_FLAG)
              .withColumn(SparkSQLConstants.SUPERCLASS_LABEL, lit(GlobalConstants.DEFAULT_NO_MAP))
              .withColumn(SparkSQLConstants.ACTION_STATUS, lit(GlobalConstants.REVIEW_PENDING))
              .withColumn(SparkSQLConstants.WORKLIST_ID, lit(worklistId))
              .withColumn(SparkSQLConstants.RELEASE_ID, lit(releaseID))
              .withColumn(SparkSQLConstants.WORKLIST_TYPE, lit(GlobalConstants.EDIT_UNMATCHED_DIRECT_MAP))
              
            //writing add data into mongo
            log.info("saving Edit  Unmapped – Direct Map worklist data for taxonomy " + taxonomyName + " for loinc releaseId : " + releaseID)
            mongoDAO.writeDataFrameToMongo(GlobalConstants.WORKLIST_ITEMS, editUnmappedDirectMapCodes)
            log.info("saved successfully Edit  Unmapped – Direct Map worklist data for taxonomy " + taxonomyName + " for loinc releaseId : " + releaseID)
            //Edit Unmapped - NoMap found
            log.info("generating Edit Unmapped - NoMap found worklist data for taxonomy " + taxonomyName + " for loinc releaseId : " + releaseID)
            worklistId = releaseID + GlobalConstants.W + count + GlobalConstants.UNDER_SCORE + GlobalConstants.WORKLIST_EDIT_UNMATCHED
            val editUnmappedNoMapIHRCodes = sourceEditCodesDF.join(
              ihrMatchCodes,
              ihrMatchCodes(SparkSQLConstants.CONCEPT_ID) === sourceEditCodesDF(SparkSQLConstants.CONCEPT_ID), SparkSQLConstants.ANTI_LEFT_JOIN)

            val editUnmappedNoMapCodes = editUnmappedNoMapIHRCodes.join(
              superclass_ontology_df,
              editUnmappedNoMapIHRCodes(SparkSQLConstants.CONCEPT_ID) === superclass_ontology_df(SparkSQLConstants.SUPERCLASS_CONCEPT_ID), SparkSQLConstants.ANTI_LEFT_JOIN)
              .select(
                SparkSQLConstants.TAXONOMY_FSN,
                SparkSQLConstants.CONCEPT_ID,
                SparkSQLConstants.PREFERRED_TERM,
                SparkSQLConstants.EFFECTIVE_TIME,
                SparkSQLConstants.LANGUAGE_CODE,
                SparkSQLConstants.CHANGECODE_FLAG)
              .withColumn(SparkSQLConstants.IHR_MAP, lit(GlobalConstants.DEFAULT_NO_MAP))
              .withColumn(SparkSQLConstants.SUPERCLASS_LABEL, lit(GlobalConstants.DEFAULT_NO_MAP))
              .withColumn(SparkSQLConstants.ACTION_STATUS, lit(GlobalConstants.MANUALLY_PROCESSED))
              .withColumn(SparkSQLConstants.WORKLIST_ID, lit(worklistId))
              .withColumn(SparkSQLConstants.RELEASE_ID, lit(releaseID))
              .withColumn(SparkSQLConstants.WORKLIST_TYPE, lit(GlobalConstants.EDIT_UNMATCHED))

            //writing add data into mongo
            log.info("saving Edit Unmapped - NoMap found worklist data for taxonomy " + taxonomyName + " for loinc releaseId : " + releaseID)
            mongoDAO.writeDataFrameToMongo(GlobalConstants.WORKLIST_ITEMS, editUnmappedNoMapCodes)
            log.info("saved successfully Edit Unmapped - NoMap found worklist data for taxonomy " + taxonomyName + " for loinc releaseId : " + releaseID)
            count += 1
          } else {
            log.info("No Source ontology file found for taxonomy : " + taxonomyName)
          }
        } catch {
          case e: Exception =>
            log.error(s"Exception while running data comparator for taxonomy : " + taxonomyName + " for Edit Map Worklist for loinc releaseId : " + releaseID)
            log.error(e.printStackTrace())
        }
      }
      log.info("Completed data comparator for Edit Map Worklist for loinc releaseId : " + releaseID)
    } catch {
      case e: Exception =>
        log.error(s"Exception while running data comparator for Edit Map Worklist for loinc releaseId : " + releaseID)
        log.error(e.printStackTrace())
      //throw e
    }
  }
}