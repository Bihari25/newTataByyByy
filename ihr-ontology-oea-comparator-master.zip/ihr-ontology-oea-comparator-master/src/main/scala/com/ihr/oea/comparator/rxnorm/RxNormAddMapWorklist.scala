package com.ihr.oea.comparator.rxnorm

import org.apache.log4j.Logger
import org.apache.spark.sql.SparkSession
import org.apache.spark.sql.functions.col
import org.apache.spark.sql.functions.lit
import org.apache.spark.sql.functions.count
import org.apache.spark.sql.functions.concat_ws
import org.apache.spark.sql.functions._
import org.apache.spark.sql.types.StructField
import org.apache.spark.sql.types.StructType
import com.ihr.oea.common.GlobalConstants
import com.ihr.oea.common.OESConfiguration
import com.ihr.oea.common.SparkSQLConstants
import com.ihr.oea.dao.MongoDAO
import com.ihr.oea.util.ComparatorUtil
import org.apache.spark.sql.types.StringType

class RxNormAddMapWorklist extends Serializable {
 @transient lazy val log = Logger.getLogger(getClass.getName)
 def buildAddCodesSchema(): StructType = {
    val schema = StructType(
      Array(
         StructField(SparkSQLConstants.RELEASE_ID, StringType, true),  
        StructField(SparkSQLConstants.TAXONOMY_FSN, StringType, true),
        StructField(SparkSQLConstants.CONCEPT_ID, StringType, true),
        StructField(SparkSQLConstants.RXCUI, StringType, true),
        StructField(SparkSQLConstants.STR, StringType, true),
        StructField(SparkSQLConstants.NDCCODE, StringType, true),
        StructField(SparkSQLConstants.UNIICODE, StringType, true),       
        StructField(SparkSQLConstants.WORKLIST_TYPE, StringType, true),
        StructField(SparkSQLConstants.EFFECTIVE_TIME, StringType, true),
        StructField(SparkSQLConstants.WORKLIST_ID, StringType, true)))
    schema
  }


  def generateRxNormAddMapWorklist(spark: SparkSession, oesConfiguration: OESConfiguration, releaseID: String) {
    try {
        
      log.info("Running data comparator for ADD Map worklist for RxNorm releaseId : " + releaseID)
      log.info("loading add codes for  releaseId : " + releaseID)

      val mongoDAO = new MongoDAO
      log.info("Finding  distinct taxonomies in release data for RxNorm releaseId : " + releaseID)      
               
      val addWorkListData = mongoDAO.readDataFrameFromMongo(spark, oesConfiguration.DATABASE_NAME, GlobalConstants.WORKLIST_ITEMS)
        .filter(col(SparkSQLConstants.RELEASE_ID) === releaseID && col(SparkSQLConstants.WORKLIST_TYPE) === GlobalConstants.ADD_CODES)
        
        
      // Find the distinct taxonomies in the release from the MongoDB
      val util = new ComparatorUtil
      var rxnormCorputil = new RxNormCompareUtil
      var taxonomyStack = util.findDistinctTaxonomy(addWorkListData)
      var count = 1
      var worklistId = GlobalConstants.EMPTY_STRING
      var currentTime = GlobalConstants.EMPTY_STRING
      val taxonomyName = taxonomyStack.pop

      
       try {
       val workListID = rxnormCorputil.getWorklistID(addWorkListData, taxonomyName)
          
       var sourceCodes = spark.read.format(GlobalConstants.SPARK_DEFAULT_MONGO_DATASOURCE)
        .option(GlobalConstants.DATABASE,  oesConfiguration.DATABASE_NAME)
        .option(GlobalConstants.COLLECTION, GlobalConstants.WORKLIST_ITEMS)
        .schema(buildAddCodesSchema()).load()
            .filter(col(SparkSQLConstants.WORKLIST_ID) === workListID)
            .cache()
            
            sourceCodes=sourceCodes.withColumn(SparkSQLConstants.CHANGECODE_FLAG, lit(GlobalConstants.EMPTY_STRING))
                       
          log.info("generating add direct map worklist data for taxonomy " + taxonomyName + " for RxNorm releaseId : " + releaseID)
         
        // ADD Direct Map codes
           worklistId = releaseID + GlobalConstants.W + count + GlobalConstants.UNDER_SCORE + GlobalConstants.WORKLIST_ADD_DIRECT_MAP
           var addDirectCodes = rxnormCorputil.generateRxNormIhrMapData(taxonomyName, sourceCodes, GlobalConstants.ADD_CODES, spark, oesConfiguration, releaseID)
                             .cache()
            
                             
           addDirectCodes = addDirectCodes
              .withColumnRenamed(SparkSQLConstants.MSP_GPI,SparkSQLConstants.mspGpi)
              .withColumnRenamed(SparkSQLConstants.MSP_DDID,SparkSQLConstants.mspDdId)
              .withColumnRenamed(SparkSQLConstants.MSP_PNID,SparkSQLConstants.mspPnId)
              .withColumnRenamed(SparkSQLConstants.MSP_RPID,SparkSQLConstants.mspRpId)  
              
            addDirectCodes = addDirectCodes.select(
            SparkSQLConstants.TAXONOMY_FSN,
            SparkSQLConstants.CONCEPT_ID,
            SparkSQLConstants.RXCUI,
            SparkSQLConstants.STR,
            SparkSQLConstants.UNIICODE,
            SparkSQLConstants.mspGpi,
            SparkSQLConstants.IHR_MAP,
            SparkSQLConstants.MATCH_TYPE,
            SparkSQLConstants.MATCH_VALUE,
            SparkSQLConstants.mspDdId,SparkSQLConstants.mspPnId,SparkSQLConstants.mspRpId,
            SparkSQLConstants.GENERICNAME,SparkSQLConstants.SUPER_CLASS_STATUS)
          .withColumn(SparkSQLConstants.ACTION_STATUS, lit(GlobalConstants.REVIEW_PENDING))
          .withColumn(SparkSQLConstants.WORKLIST_ID, lit(worklistId))
          .withColumn(SparkSQLConstants.RELEASE_ID, lit(releaseID))
          .withColumn(SparkSQLConstants.WORKLIST_TYPE, lit(GlobalConstants.ADD_DIRECT_MAP))
          .cache()
          
          var ihrreplacementCodes = sourceCodes.join(addDirectCodes, addDirectCodes(SparkSQLConstants.RXCUI) === sourceCodes(SparkSQLConstants.RXCUI), SparkSQLConstants.ANTI_LEFT_JOIN)
                                 .cache() 
               
           ihrreplacementCodes= ihrreplacementCodes.select(GlobalConstants.STAR)
                                 .withColumn(SparkSQLConstants.STR1, rxnormCorputil.replaceString(col(SparkSQLConstants.STR)))
                                 .cache()
  
           var addDirectCodes1 = rxnormCorputil.generateRxNormIhrMapDataReplacement(taxonomyName, ihrreplacementCodes, GlobalConstants.ADD_CODES, spark, oesConfiguration, releaseID,false)
                               .cache()       
              
           addDirectCodes1 = addDirectCodes1
              .withColumnRenamed(SparkSQLConstants.MSP_GPI,SparkSQLConstants.mspGpi)
              .withColumnRenamed(SparkSQLConstants.MSP_DDID,SparkSQLConstants.mspDdId)
              .withColumnRenamed(SparkSQLConstants.MSP_PNID,SparkSQLConstants.mspPnId)
              .withColumnRenamed(SparkSQLConstants.MSP_RPID,SparkSQLConstants.mspRpId)                
                               
              addDirectCodes1 = addDirectCodes1.select(
              SparkSQLConstants.TAXONOMY_FSN,
              SparkSQLConstants.CONCEPT_ID,
              SparkSQLConstants.RXCUI,
              SparkSQLConstants.STR,
              SparkSQLConstants.UNIICODE,
              SparkSQLConstants.mspGpi,
              SparkSQLConstants.IHR_MAP,
              SparkSQLConstants.MATCH_TYPE,
              SparkSQLConstants.MATCH_VALUE,
              SparkSQLConstants.mspDdId,SparkSQLConstants.mspPnId,SparkSQLConstants.mspRpId,
              SparkSQLConstants.GENERICNAME,SparkSQLConstants.SUPER_CLASS_STATUS)
            .withColumn(SparkSQLConstants.ACTION_STATUS, lit(GlobalConstants.REVIEW_PENDING))
            .withColumn(SparkSQLConstants.WORKLIST_ID, lit(worklistId))
            .withColumn(SparkSQLConstants.RELEASE_ID, lit(releaseID))
            .withColumn(SparkSQLConstants.WORKLIST_TYPE, lit(GlobalConstants.ADD_DIRECT_MAP))
            .cache()
                   
           var addDirectCodes4=(addDirectCodes.distinct()).union(addDirectCodes1.distinct())
           addDirectCodes4=addDirectCodes4.distinct()
                      
          log.info("saving add direct map worklist data for taxonomy " + taxonomyName + " for RxNorm releaseId : " + releaseID)
          mongoDAO.writeDataFrameToMongo(GlobalConstants.WORKLIST_ITEMS, addDirectCodes4)
          log.info("saved successfully add direct map worklist data for taxonomy  " + taxonomyName + " for RxNorm releaseId : " + releaseID)
    
          // ADD Unmatched Map codes
          log.info("generating add Unmatched map worklist data for taxonomy " + taxonomyName + " for RxNorm releaseId : " + releaseID)
          worklistId = releaseID + GlobalConstants.W + count + GlobalConstants.UNDER_SCORE + GlobalConstants.WORKLIST_ADD_UNMATCHED
          val addUnmatchedCodes = sourceCodes.join(addDirectCodes4, addDirectCodes4(SparkSQLConstants.RXCUI) ===  sourceCodes(SparkSQLConstants.RXCUI),SparkSQLConstants.ANTI_LEFT_JOIN
            ).select(
              SparkSQLConstants.RXCUI,
              SparkSQLConstants.STR,SparkSQLConstants.TAXONOMY_FSN,SparkSQLConstants.CONCEPT_ID)
            .withColumn(SparkSQLConstants.IHR_MAP, lit(GlobalConstants.DEFAULT_NO_MAP))
            .withColumn(SparkSQLConstants.ACTION_STATUS, lit(GlobalConstants.MANUALLY_PROCESSED))
            .withColumn(SparkSQLConstants.WORKLIST_ID, lit(worklistId))
            .withColumn(SparkSQLConstants.RELEASE_ID, lit(releaseID))
            .withColumn(SparkSQLConstants.WORKLIST_TYPE, lit(GlobalConstants.ADD_UNMATCHED))
            
          //writing add data into mongo
          log.info("saving  add Unmatched map worklist data for taxonomy " + taxonomyName + " for RxNorm releaseId : " + releaseID)
          mongoDAO.writeDataFrameToMongo(GlobalConstants.WORKLIST_ITEMS, addUnmatchedCodes.distinct())
          log.info("saved successfully add Unmatched map worklist data for taxonomy " + taxonomyName + " for  releaseId : " + releaseID)

          count += 1
        } catch {
          case e: Exception =>
            log.error(s"Exception while running data comparator taxonomy " + taxonomyName + " for Add Map Worklist for  releaseId : " + releaseID+e.printStackTrace())
            log.error(e.printStackTrace())
        }

      log.info("Completed data comparator for Add Map Worklists for  releaseId : " + releaseID)
    } catch {
      case e: Exception =>
        log.error(s"Exception while running data comparator for Add Map Worklists for  releaseId : " + releaseID)
        log.error(e.printStackTrace())
      //throw e
    }
  }
}