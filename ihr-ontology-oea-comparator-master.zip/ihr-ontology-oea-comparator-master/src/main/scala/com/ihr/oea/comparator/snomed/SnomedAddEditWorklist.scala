package com.ihr.oea.comparator.snomed

import scala.collection.mutable.Stack
import scala.collection.mutable.WrappedArray

import org.apache.log4j.Logger
import org.apache.log4j.Level
import org.apache.spark.sql.SparkSession
import org.apache.spark.sql.functions.col
import org.apache.spark.sql.functions.lit
import org.apache.spark.sql.functions.split
import org.apache.spark.sql.functions.udf
import org.apache.spark.sql.functions.when

import com.ihr.oea.common.GlobalConstants
import com.ihr.oea.common.OESConfiguration
import com.ihr.oea.common.SparkSQLConstants
import com.ihr.oea.dao.MongoDAO
import com.ihr.oea.util.ComparatorUtil

import org.apache.spark.sql.types.StringType
import org.apache.spark.sql.types.ArrayType
import org.apache.spark.sql.types.StructField
import org.apache.spark.sql.types.StructType
import scala.collection.mutable.ArrayBuffer

class SnomedAddEditWorklist extends Serializable {
  val log = Logger.getLogger(getClass.getName)
  Logger.getLogger("org").setLevel(Level.OFF)
  Logger.getLogger("akka").setLevel(Level.OFF)
  Logger.getLogger("INFO").setLevel(Level.OFF)
  def generateSnomedAddEditWorklist(spark: SparkSession, oesConfiguration: OESConfiguration, releaseID: String) {
    try {
      log.info("Running data comparator for ADD/EDIT worklist for snomed releaseId : " + releaseID)
      // Load the release concepts from MongoDB
      log.info("loading release concepts from db for snomed releaseId : " + releaseID)
      val mongoDAO = new MongoDAO
def buildReleaseConceptsSchema(): StructType = {
    val schema = StructType(
      Array(
        StructField(SparkSQLConstants.RELEASE_ID, StringType, true),
        StructField(SparkSQLConstants.TAXONOMY_FSN, StringType, true),
        StructField(SparkSQLConstants.CONCEPT_ID, StringType, true),
        StructField(SparkSQLConstants.PREFERRED_TERM, StringType, true),
        StructField(SparkSQLConstants.FSN, StringType, true),
        StructField(SparkSQLConstants.SYNONYM, ArrayType(StringType), true),
        StructField(SparkSQLConstants.EFFECTIVE_TIME, StringType, true),
        StructField(SparkSQLConstants.LANGUAGE_CODE, StringType, true)))
      
    schema
  }
      val releaseConcepts = spark.read.format(GlobalConstants.SPARK_DEFAULT_MONGO_DATASOURCE)
        .option(GlobalConstants.DATABASE,  oesConfiguration.DATABASE_NAME)
        .option(GlobalConstants.COLLECTION, GlobalConstants.RELEASE_CONCEPTS)
        .schema(buildReleaseConceptsSchema())
        .load().filter(col(SparkSQLConstants.RELEASE_ID) === releaseID )
       
      // Find the distinct taxonomies in the release from the MongoDB
      log.info("Finding  distinct taxonomies in release data for snomed releaseId : " + releaseID)
      // Create a stack to process the taxonomy data
      val util =  new ComparatorUtil
      var taxonomyStack = util.findDistinctTaxonomy(releaseConcepts)

      val same_array = udf { (t1: WrappedArray[String], t2: WrappedArray[String]) =>
        if (t1 != null && t2 != null &&
          (t1.map(_.trim().toLowerCase()).intersect(t2.map(_.trim().toLowerCase())).length == t2.length)) { 1 }
        else if (t1 == null && t2 == null) { 1 }
        else if ((t1 == null && t2 != null) || (t2 == null && t1 != null)) { 0 }
        else { 0 }
      }

      val same_string = udf { (t1: String, t2: String) =>
        if (t1 != null && t2 != null && t1.length() > 0 && t2.length() > 0 &&
          t1.trim().toLowerCase() == t2.trim().toLowerCase()) { 1 }
        else if (t1 == null && t2 != null && t2.length() >= 0) { 0 }
        else if (t1 == null && t2 == null) { 1 }
        else { 0 }
      }

      val array_length = udf { (t1: WrappedArray[String]) =>
        if (t1 != null) { t1.length }
        else { 0 }
      }

      log.info("generating the source path for snomed releaseId : " + releaseID)
      var sourceAnnotationBasePath = oesConfiguration.BASE_PATH + releaseID + GlobalConstants.FORWARD_SLASH + oesConfiguration.SOURCE_ANNOTATION_PATH + GlobalConstants.FORWARD_SLASH
      if (!oesConfiguration.PROFILE.equalsIgnoreCase(GlobalConstants.LOCAL_PROFILE))
        sourceAnnotationBasePath = sourceAnnotationBasePath.substring(5)

      
      var count = 1
      var worklistId = GlobalConstants.EMPTY_STRING
      var currentTime = GlobalConstants.EMPTY_STRING
      while (taxonomyStack.nonEmpty) {
        val taxonomyName = taxonomyStack.pop
        try {
          var taxonomyOntologyFileName = GlobalConstants.snomedSourceAnnotationMap.apply(taxonomyName)
          if (null != taxonomyOntologyFileName) {
            log.info("Loading source annotation data for taxonomy " + taxonomyName + " for snomed releaseId : " + releaseID)
            var sourceData = spark.read
              .format(GlobalConstants.CSV_FORMAT)
              .option(GlobalConstants.HEADER, true)
              .option(GlobalConstants.DELIMITER, GlobalConstants.TAB)
              .load(sourceAnnotationBasePath + taxonomyOntologyFileName)            
              .withColumn(SparkSQLConstants.ALIAS_TERM_EN, split(col(SparkSQLConstants.ALIAS_TERM_EN), GlobalConstants.SQUARE_PIPE))
              .withColumn(SparkSQLConstants.LABEL1, split(col(SparkSQLConstants.LABEL1), GlobalConstants.ESCAPE_UNDERSCORE).getItem(2))
              //.withColumn(SparkSQLConstants.LABEL1, split(col("Label"), GlobalConstants.ESCAPE_UNDERSCORE).getItem(2))

            val releaseData = releaseConcepts.filter(col(SparkSQLConstants.TAXONOMY_FSN) === taxonomyName)
            // ADD codes
            log.info("generating add code work list data for taxonomy " + taxonomyName + " for snomed releaseId : " + releaseID)
            worklistId = releaseID + GlobalConstants.W + count + GlobalConstants.UNDER_SCORE + GlobalConstants.WORKLIST_ADD_CODES
            val addCodes = releaseData.join(sourceData, sourceData(SparkSQLConstants.IDENTIFIER) === releaseData(SparkSQLConstants.CONCEPT_ID), SparkSQLConstants.ANTI_LEFT_JOIN)
            val addCodesWorklist = addCodes.select(SparkSQLConstants.TAXONOMY_FSN, SparkSQLConstants.CONCEPT_ID,
              SparkSQLConstants.FSN, SparkSQLConstants.PREFERRED_TERM, SparkSQLConstants.SYNONYM, SparkSQLConstants.EFFECTIVE_TIME, SparkSQLConstants.LANGUAGE_CODE)
              .withColumn(SparkSQLConstants.ACTION_STATUS, lit(GlobalConstants.REVIEW_PENDING))
              .withColumn(SparkSQLConstants.WORKLIST_ID, lit(worklistId))
              .withColumn(SparkSQLConstants.RELEASE_ID, lit(releaseID))
              .withColumn(SparkSQLConstants.WORKLIST_TYPE, lit(GlobalConstants.ADD_CODES))
              
            //writing add data into mongo
            log.info("saving  add code work list data for taxonomy " + taxonomyName + " for snomed releaseId : " + releaseID)
            mongoDAO.writeDataFrameToMongo(GlobalConstants.WORKLIST_ITEMS, addCodesWorklist)
            log.info("saved successfully add code work list data for taxonomy " + taxonomyName + " for snomed releaseId : " + releaseID)

            // EDIT codes
            worklistId = releaseID + GlobalConstants.W + count + GlobalConstants.UNDER_SCORE + GlobalConstants.WORKLIST_EDIT_CODES
            val editCodes = releaseData.join(sourceData, releaseData(SparkSQLConstants.CONCEPT_ID) === sourceData(SparkSQLConstants.IDENTIFIER))
              .where(same_string(releaseData(SparkSQLConstants.FSN), sourceData(SparkSQLConstants.LABEL1)) === 0 ||
                same_string(releaseData(SparkSQLConstants.PREFERRED_TERM), sourceData(SparkSQLConstants.PREFERRED_TERM_EN)) === 0 ||
                same_array(releaseData(SparkSQLConstants.SYNONYM), sourceData(SparkSQLConstants.ALIAS_TERM_EN)) === 0)
              .withColumn(SparkSQLConstants.REL_FSN, releaseData(SparkSQLConstants.FSN))
              .withColumn(SparkSQLConstants.REL_PREFERRED_TERM, releaseData(SparkSQLConstants.PREFERRED_TERM))
              .withColumn(SparkSQLConstants.REL_SYNONYM, releaseData(SparkSQLConstants.SYNONYM))
              .withColumn(SparkSQLConstants.FSN, when(same_string(releaseData(SparkSQLConstants.FSN), sourceData(SparkSQLConstants.LABEL1)) === 0, releaseData(SparkSQLConstants.FSN)).otherwise(null))
              .withColumn(SparkSQLConstants.PREFERRED_TERM, when(same_string(releaseData(SparkSQLConstants.PREFERRED_TERM), sourceData(SparkSQLConstants.PREFERRED_TERM_EN)) === 0, releaseData(SparkSQLConstants.PREFERRED_TERM)).otherwise(null))
              .withColumn(SparkSQLConstants.SYNONYM, when(same_array(releaseData(SparkSQLConstants.SYNONYM), sourceData(SparkSQLConstants.ALIAS_TERM_EN)) === 0, releaseData(SparkSQLConstants.SYNONYM)).otherwise(null))
              .withColumn(SparkSQLConstants.ALIAS_TERM_COUNT, array_length(sourceData(SparkSQLConstants.ALIAS_TERM_EN)))
              .withColumn(SparkSQLConstants.CHANGECODE_FLAG, when(col(SparkSQLConstants.FSN).isNotNull,GlobalConstants.TRUE).otherwise(GlobalConstants.FALSE))
              
            log.info("generating edit code work list data for taxonomy " + taxonomyName + " for snomed releaseId : " + releaseID)
            /*val editCodesWorklist = editCodes.select(SparkSQLConstants.TAXONOMY_FSN, SparkSQLConstants.CONCEPT_ID, SparkSQLConstants.FSN,
              SparkSQLConstants.PREFERRED_TERM, SparkSQLConstants.SYNONYM, SparkSQLConstants.EFFECTIVE_TIME, SparkSQLConstants.LANGUAGE_CODE,
              SparkSQLConstants.REL_FSN, SparkSQLConstants.REL_PREFERRED_TERM, SparkSQLConstants.REL_SYNONYM, SparkSQLConstants.ALIAS_TERM_COUNT,SparkSQLConstants.CHANGECODE_FLAG)
              .withColumn(SparkSQLConstants.ACTION_STATUS, lit(GlobalConstants.REVIEW_PENDING))
              .withColumn(SparkSQLConstants.WORKLIST_ID, lit(worklistId))
              .withColumn(SparkSQLConstants.RELEASE_ID, lit(releaseID))
              .withColumn(SparkSQLConstants.WORKLIST_TYPE, lit(GlobalConstants.EDIT_CODES))
              */
            val columnNames = editCodes.distinct().columns.toArray
            val requiredColumns = ArrayBuffer[String](
              SparkSQLConstants.TAXONOMY_FSN, SparkSQLConstants.CONCEPT_ID, SparkSQLConstants.FSN,
              SparkSQLConstants.PREFERRED_TERM, SparkSQLConstants.SYNONYM, SparkSQLConstants.EFFECTIVE_TIME, SparkSQLConstants.LANGUAGE_CODE,
              SparkSQLConstants.REL_FSN, SparkSQLConstants.REL_PREFERRED_TERM, SparkSQLConstants.REL_SYNONYM, SparkSQLConstants.ALIAS_TERM_COUNT,SparkSQLConstants.CHANGECODE_FLAG
               )
              
            val selectedColumns = requiredColumns.intersect(columnNames)
            val colNames = selectedColumns.map(name => col(name))
            log.info("generating edit code work list data for taxonomy " + taxonomyName + " for SNOMEd releaseId : " + releaseID  + "colNames"+ colNames)
            var editCodesWorklist = editCodes.distinct().select(colNames: _*)
             .withColumn(SparkSQLConstants.ACTION_STATUS, lit(GlobalConstants.REVIEW_PENDING))
              .withColumn(SparkSQLConstants.WORKLIST_ID, lit(worklistId))
              .withColumn(SparkSQLConstants.RELEASE_ID, lit(releaseID))
              .withColumn(SparkSQLConstants.WORKLIST_TYPE, lit(GlobalConstants.EDIT_CODES))
              
            //writing edit data into mongo
            log.info("saving edit code work list data for taxonomy " + taxonomyName + " for snomed releaseId : " + releaseID)
            mongoDAO.writeDataFrameToMongo(GlobalConstants.WORKLIST_ITEMS, editCodesWorklist)
            log.info("saved edit code work list data for taxonomy " + taxonomyName + " for snomed releaseId : " + releaseID)
            count += 1
          } else {
            log.info("No source ontology mapping is found for taxonomy : " + taxonomyName)
          }
        } catch {
          case e: Exception =>
            log.error(s"Exception while running data comparator for ADD/EDIT worklist for taxonomy : " + taxonomyName + " for snomed releaseId : " + releaseID)
             log.error(e.printStackTrace())
        }
      }
      log.info("Completed data comparator for ADD/EDIT Worklist for snomed releaseId : " + releaseID)
    } catch {
      case e: Exception =>
        log.error(s"Exception while running data comparator for ADD/EDIT worklist for snomed releaseId : " + releaseID)
         log.error(e.printStackTrace())
      //throw e
    }
  }
}
