package com.ihr.oea.comparator.rxnorm

import org.apache.log4j.Logger
import org.apache.spark.sql.SparkSession
import org.apache.spark.sql.functions.col
import org.apache.spark.sql.functions.lit
import org.apache.spark.sql.functions.count
import org.apache.spark.sql.functions.concat_ws
import org.apache.spark.sql.functions._
import org.apache.spark.sql.types.StructField
import org.apache.spark.sql.types.StructType
import com.ihr.oea.common.GlobalConstants
import com.ihr.oea.common.OESConfiguration
import com.ihr.oea.common.SparkSQLConstants
import com.ihr.oea.dao.MongoDAO
import com.ihr.oea.util.ComparatorUtil
import org.apache.spark.sql.types.StringType
import org.apache.spark.sql.types._
  
class RxNormEditMapWorklist {

 @transient lazy val log = Logger.getLogger(getClass.getName)
  
  def buildEditCodesSchema(): StructType = {
      val schema = StructType(
      Array(
         StructField(SparkSQLConstants.RELEASE_ID, StringType, true),  
        StructField(SparkSQLConstants.TAXONOMY_FSN, StringType, true),
        StructField(SparkSQLConstants.CONCEPT_ID, StringType, true),
        StructField(SparkSQLConstants.RXCUI, StringType, true),
        StructField(SparkSQLConstants.STR, StringType, true),
        StructField(SparkSQLConstants.REL_STR, StringType, true),
        StructField(SparkSQLConstants.NDCCODE, StringType, true),
        StructField(SparkSQLConstants.SYNONYM,ArrayType(StringType),true),
        StructField(SparkSQLConstants.UNIICODE, StringType, true),
        StructField(SparkSQLConstants.CHANGECODE_FLAG, StringType, true),
        StructField(SparkSQLConstants.WORKLIST_TYPE, StringType, true),
        StructField(SparkSQLConstants.EFFECTIVE_TIME, StringType, true),
        StructField(SparkSQLConstants.ACTION_STATUS, StringType, true),
        StructField(SparkSQLConstants.WORKLIST_ID, StringType, true)))
    schema
  }
  
  def generateRxNormEditMapWorklist(spark: SparkSession, oesConfiguration: OESConfiguration, releaseID: String) {
    try {

      log.info("Running data comparator for Edit Map worklist for RxNorm releaseId : " + releaseID)
      log.info("loading edit codes for RxNorm releaseId : " + releaseID)

      val mongoDAO = new MongoDAO
      log.info("Finding  distinct taxonomies in release data for RxNorm releaseId : " + releaseID)      
  
      val ihrOntologyFile = GlobalConstants.rxnormIHRAnnotationMap    
        
      val editWorkListData = spark.read.format(GlobalConstants.SPARK_DEFAULT_MONGO_DATASOURCE)
        .option(GlobalConstants.DATABASE,  oesConfiguration.DATABASE_NAME)
        .option(GlobalConstants.COLLECTION, GlobalConstants.WORKLIST_ITEMS)
        .schema(buildEditCodesSchema())
        .load().filter(col(SparkSQLConstants.RELEASE_ID) === releaseID && col(SparkSQLConstants.WORKLIST_TYPE) === GlobalConstants.EDIT_CODES)
       
      // Find the distinct taxonomies in the release from the MongoDB
      val util = new ComparatorUtil
      val rxnormCorputil = new RxNormCompareUtil
      var taxonomyStack = util.findDistinctTaxonomy(editWorkListData)
      var count = 1
      var worklistId = GlobalConstants.EMPTY_STRING
      var currentTime = GlobalConstants.EMPTY_STRING
      val taxonomyName = taxonomyStack.pop

        try {          
         val workListID = rxnormCorputil.getWorklistID(editWorkListData, taxonomyName)                  
         var sourceEditCodesDF = spark.read.format(GlobalConstants.SPARK_DEFAULT_MONGO_DATASOURCE)
        .option(GlobalConstants.DATABASE,  oesConfiguration.DATABASE_NAME)
        .option(GlobalConstants.COLLECTION, GlobalConstants.WORKLIST_ITEMS)
        .schema(buildEditCodesSchema())
        .load().filter(col(SparkSQLConstants.WORKLIST_ID) === workListID)
          
            
         sourceEditCodesDF = sourceEditCodesDF.select(GlobalConstants.STAR)
                               .withColumn(SparkSQLConstants.STR, col(SparkSQLConstants.REL_STR))
                             
                        
          var sourceCodes = sourceEditCodesDF
          
          log.info("generating edit direct map worklist data for taxonomy " + taxonomyName + " for RxNorm releaseId : " + releaseID)
         
          // edit  Map codes
          worklistId = releaseID + GlobalConstants.W + count + GlobalConstants.UNDER_SCORE + GlobalConstants.WORKLIST_EDIT_UNMATCHED_DIRECT_MAP
          
          var sourceSCCodes = rxnormCorputil.generateRxNormSCEditMapData(taxonomyName,  sourceCodes, GlobalConstants.EDIT_CODES, spark, oesConfiguration, releaseID)
                             .cache()
          
          var editIhrDirectCodes1 = rxnormCorputil.generateRxNormIhrMapData(taxonomyName, sourceSCCodes, GlobalConstants.EDIT_CODES, spark, oesConfiguration, releaseID)
                                    .cache()
          
          var ihrreplacementCodes = sourceSCCodes.join(editIhrDirectCodes1, editIhrDirectCodes1(SparkSQLConstants.RXCUI) === sourceSCCodes(SparkSQLConstants.RXCUI), SparkSQLConstants.ANTI_LEFT_JOIN)
                                 .cache() 
               
          ihrreplacementCodes= ihrreplacementCodes.select(GlobalConstants.STAR)
                                 .withColumn(SparkSQLConstants.STR1, rxnormCorputil.replaceString(col(SparkSQLConstants.STR)))
                                 .cache()
  
          var editIhrDirectCodes2 = rxnormCorputil.generateRxNormIhrMapDataReplacement(taxonomyName, ihrreplacementCodes, GlobalConstants.ADD_CODES, spark, oesConfiguration, releaseID,false)
                               .cache()
                               
                               
          var ihrreplacementCodes1 = ihrreplacementCodes.join(editIhrDirectCodes2, editIhrDirectCodes2(SparkSQLConstants.RXCUI) === ihrreplacementCodes(SparkSQLConstants.RXCUI), SparkSQLConstants.ANTI_LEFT_JOIN)
                                 .cache() 
                    
          var editIhrDirectCodes=(editIhrDirectCodes1.distinct()).union(editIhrDirectCodes2.distinct())
           editIhrDirectCodes=editIhrDirectCodes.distinct()

         
    val same_string = udf { (t3: String, t4: String) =>
      
      var t1 = t3.substring(0, t3.lastIndexOf(GlobalConstants.SQUARE_BRACKET)).trim()
     var  t2 = t4.substring(0, t4.lastIndexOf(GlobalConstants.SQUARE_BRACKET)).trim()
    if (t1 != null && t2 != null && t1.length() > 0 && t2.length() > 0 &&
      t1.trim().toLowerCase() == t2.trim().toLowerCase()) { 1 }
    else if (t1 == null && t2 != null && t2.length() >= 0) { 0 }
    else if (t1 == null && t2 == null) { 0 }
    else { 0 }
    }

          //Edit Map - Better Match
            log.info("generating Edit Map - Better Match worklist data for taxonomy " + taxonomyName + " for RxNorm releaseId : " + releaseID)
            worklistId = releaseID + GlobalConstants.W + count + GlobalConstants.UNDER_SCORE + GlobalConstants.WORKLIST_EDIT_BETTER_MATCHED


           var superClassBasePath = oesConfiguration.BASE_PATH + releaseID + GlobalConstants.FORWARD_SLASH + oesConfiguration.SUPERCLASS_DUMP_PATH + GlobalConstants.FORWARD_SLASH
          if (!oesConfiguration.PROFILE.equalsIgnoreCase(GlobalConstants.LOCAL_PROFILE)) {
            superClassBasePath = superClassBasePath.substring(5)
          }
            var rxnormSCDump = GlobalConstants.RXNORMSCDUMP
            var taxonomyId = GlobalConstants.RXNORMTAXONOMYID
            var rxnormtaxonomyId:String = taxonomyId+GlobalConstants.UNDER_SCORE
            var SCMapData=rxnormCorputil.loadSuperClassData(spark, superClassBasePath , rxnormSCDump)
            SCMapData=SCMapData.withColumn(SparkSQLConstants.CLASS_ID,split(col(SparkSQLConstants.CLASS_ID), GlobalConstants.ESCAPE_UNDERSCORE).getItem(1))
            SCMapData=SCMapData.select(SparkSQLConstants.SUPERCLASS_LABEL,SparkSQLConstants.CLASS_ID).cache()
        
            var editBetterMapCodes = editIhrDirectCodes.join(SCMapData,SCMapData(SparkSQLConstants.CLASS_ID)===editIhrDirectCodes(SparkSQLConstants.CONCEPT_ID))
                .where(same_string(SCMapData(SparkSQLConstants.SUPERCLASS_LABEL), editIhrDirectCodes(SparkSQLConstants.IHR_MAP)) === 0)     
                .cache()
                
            editBetterMapCodes=editBetterMapCodes
            .withColumn(SparkSQLConstants.WORKLIST_ID, lit(worklistId))
              .withColumn(SparkSQLConstants.TAXONOMY_FSN, lit(SparkSQLConstants.RXNORM))
              .withColumn(SparkSQLConstants.ACTION_STATUS, lit(GlobalConstants.REVIEW_PENDING))
              .withColumn(SparkSQLConstants.RELEASE_ID, lit(releaseID))
              .withColumn(SparkSQLConstants.WORKLIST_TYPE, lit(GlobalConstants.EDIT_BETTER_MATCHED))
              .withColumnRenamed(SparkSQLConstants.MSP_GPI,SparkSQLConstants.mspGpi)
              .withColumnRenamed(SparkSQLConstants.MSP_DDID,SparkSQLConstants.mspDdId)
              .withColumnRenamed(SparkSQLConstants.MSP_PNID,SparkSQLConstants.mspPnId)
              .withColumnRenamed(SparkSQLConstants.MSP_RPID,SparkSQLConstants.mspRpId)
              .dropDuplicates()
              .cache()
              
              editBetterMapCodes=editBetterMapCodes.select(
              SparkSQLConstants.CONCEPT_ID,
              SparkSQLConstants.RXCUI,
              SparkSQLConstants.STR,
              SparkSQLConstants.mspGpi,
              SparkSQLConstants.IHR_MAP,
              SparkSQLConstants.MATCH_TYPE,
              SparkSQLConstants.MATCH_VALUE,
              SparkSQLConstants.CHANGECODE_FLAG,
              SparkSQLConstants.mspDdId,SparkSQLConstants.mspPnId,SparkSQLConstants.mspRpId,
              SparkSQLConstants.GENERICNAME,SparkSQLConstants.SUPER_CLASS_STATUS,
              SparkSQLConstants.SUPERCLASS_LABEL,SparkSQLConstants.WORKLIST_ID,
              SparkSQLConstants.RELEASE_ID,SparkSQLConstants.TAXONOMY_FSN,
              SparkSQLConstants.ACTION_STATUS,SparkSQLConstants.WORKLIST_TYPE     
              ).cache()
              
             //writing add data into mongo
            log.info("saving  Edit Map - Better Match worklist data for taxonomy " + taxonomyName + " for RxNorm releaseId : " + releaseID)

            mongoDAO.writeDataFrameToMongo(GlobalConstants.WORKLIST_ITEMS, editBetterMapCodes.distinct())

            log.info("saved successfully Edit Map - Better Match worklist data for taxonomy " + taxonomyName + " for RxNorm releaseId : " + releaseID)
   
            //edit-map No map found
            log.info("generating Edit Map - NoMap found  worklist data for taxonomy " + taxonomyName + " for RxNorm releaseId : " + releaseID)
            //var editMapNoCodes=rxnormCorputil.generateRxNormSCMapData(taxonomyName,sourceCodes,editIhrDirectCodes,  GlobalConstants.EDIT_CODES, spark, oesConfiguration, releaseID)            
            
            var editMapNoCodes=ihrreplacementCodes1
                .withColumn(SparkSQLConstants.MATCH_TYPE, lit(GlobalConstants.EMPTY_STRING))
                   .withColumn(SparkSQLConstants.IHR_MAP, col(SparkSQLConstants.SUPERCLASS_LABEL))
                   .withColumn(SparkSQLConstants.MATCH_VALUE, lit(GlobalConstants.EMPTY_STRING))
                   .withColumn(SparkSQLConstants.SUPER_CLASS_STATUS, lit(GlobalConstants.EMPTY_STRING))
            
               worklistId = releaseID + GlobalConstants.W + count + GlobalConstants.UNDER_SCORE + GlobalConstants.WORKLIST_EDIT_NO_MAPFOUND 
               editMapNoCodes = editMapNoCodes .select(
                SparkSQLConstants.RXCUI,
                SparkSQLConstants.STR,
                SparkSQLConstants.TAXONOMY_FSN,
                SparkSQLConstants.CONCEPT_ID,
                 SparkSQLConstants.CHANGECODE_FLAG,
                SparkSQLConstants.SUPERCLASS_LABEL,
                SparkSQLConstants.MATCH_TYPE,
                SparkSQLConstants.MATCH_VALUE)
              .withColumn(SparkSQLConstants.SUPER_CLASS_STATUS, lit(GlobalConstants.EMPTY_STRING))
              .withColumn(SparkSQLConstants.IHR_MAP, lit(GlobalConstants.DEFAULT_NO_MAP))
              .withColumn(SparkSQLConstants.ACTION_STATUS, lit(GlobalConstants.REVIEW_PENDING))
              .withColumn(SparkSQLConstants.WORKLIST_ID, lit(worklistId))
              .withColumn(SparkSQLConstants.RELEASE_ID, lit(releaseID))
              .withColumn(SparkSQLConstants.WORKLIST_TYPE, lit(GlobalConstants.EDIT_NO_MAPFOUND))
              .cache().dropDuplicates(SparkSQLConstants.CONCEPT_ID, SparkSQLConstants.SUPERCLASS_LABEL)
              
              log.info("saving  Edit Map - No Map worklist data for taxonomy " + taxonomyName + " for RxNorm releaseId : " + releaseID)
               
              mongoDAO.writeDataFrameToMongo(GlobalConstants.WORKLIST_ITEMS, editMapNoCodes.distinct())          
              
              log.info("saved  Edit Map - No Map worklist data for taxonomy " + taxonomyName + " for RxNorm releaseId : " + releaseID)

        } catch {
          case e: Exception =>
            log.error(s"Exception while running data comparator taxonomy " + taxonomyName + " for edit Map Worklist for RxNorm releaseId : " + releaseID+e.printStackTrace())
            log.error(e.printStackTrace())
        }

      log.info("Completed data comparator for edit Map Worklists for RxNorm releaseId : " + releaseID)
    } catch {
      case e: Exception =>
        log.error(s"Exception while running data comparator for edit Map Worklists for RxNorm releaseId : " + releaseID)
        log.error(e.printStackTrace())
      //throw e
    }
  }
}
