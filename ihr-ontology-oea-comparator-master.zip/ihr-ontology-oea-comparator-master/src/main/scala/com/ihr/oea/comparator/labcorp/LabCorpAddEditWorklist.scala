package com.ihr.oea.comparator.labcorp

import scala.collection.mutable.ArrayBuffer
import scala.collection.mutable.Stack
import scala.collection.mutable.WrappedArray
import org.apache.log4j.Logger

import org.apache.spark.sql.SparkSession
import org.apache.spark.sql.functions.udf
import org.apache.spark.sql.types.StringType
import org.apache.spark.sql.types.StructField
import org.apache.spark.sql.types.StructType
import org.apache.spark.sql.functions._
import org.apache.spark.sql.functions.udf
import com.ihr.oea.common.GlobalConstants
import com.ihr.oea.common.OESConfiguration
import com.ihr.oea.common.SparkSQLConstants
import com.ihr.oea.dao.MongoDAO
import com.ihr.oea.util.ComparatorUtil
import java.util.ArrayList

class LabCorpAddEditWorklist {
  val log = Logger.getLogger(getClass.getName)

  def buildReleaseConceptsSchema(): StructType = {
    val schema = StructType(
      Array(
        StructField(SparkSQLConstants.RELEASE_ID, StringType, true),
        StructField(SparkSQLConstants.TAXONOMY_FSN, StringType, true),
        StructField(SparkSQLConstants.TYPE, StringType, true),
        StructField(SparkSQLConstants.CONCEPT_ID, StringType, true),
        StructField(SparkSQLConstants.PREFERRED_TERM, StringType, true),
        StructField(SparkSQLConstants.LOINC_CODE, StringType, true),
        StructField(SparkSQLConstants.CLASS_NAME, StringType, true),
        StructField(SparkSQLConstants.RESULTTYPE, StringType, true),
        StructField(SparkSQLConstants.PROCESS_STATUS, StringType, true),
        StructField(SparkSQLConstants.REL_PREFERRED_TERM, StringType, true),
        StructField(SparkSQLConstants.REL_TYPE, StringType, true), 
        StructField(SparkSQLConstants.EDITCODE_FLAG, StringType, true),
        StructField(SparkSQLConstants.EFFECTIVE_TIME, StringType, true)))
    schema
  }

  def generateLabCorpAddEditWorklist(spark: SparkSession, oesConfiguration: OESConfiguration, releaseID: String) {
    try {
      log.info("Running data comparator for ADD worklist for LabCorp releaseId : " + releaseID)
      log.info("loading release concepts from db for LabCorp releaseId : " + releaseID)
      val mongoDAO = new MongoDAO
      
          
      val labCorpConcepts = spark.read.format(GlobalConstants.SPARK_DEFAULT_MONGO_DATASOURCE)
        .option(GlobalConstants.DATABASE,  oesConfiguration.DATABASE_NAME)
        .option(GlobalConstants.COLLECTION, GlobalConstants.RELEASE_CONCEPTS)
        .schema(buildReleaseConceptsSchema())
        .load().filter(col(SparkSQLConstants.RELEASE_ID) === releaseID && col(SparkSQLConstants.PROCESS_STATUS) === GlobalConstants.PROCESSED)
        
      val catalogDF = mongoDAO.readDataFrameFromMongo(spark, oesConfiguration.DATABASE_NAME, GlobalConstants.CATALOG).filter(col(SparkSQLConstants.RELEASE_ID) === releaseID)
      val  revisedDate = catalogDF.select(GlobalConstants.RELEASE_DATE).first().getString(0)
      
      log.info("revisedDate::"+ revisedDate)      
      log.info("Finding  distinct taxonomies in release data for LabCorp releaseId : " + releaseID)
      val util = new ComparatorUtil
      var taxonomyStack = util.findDistinctTaxonomy(labCorpConcepts)
       val same_string = udf { (t1: String, t2: String) =>
        if (t1 != null && t2 != null && t1.length() > 0 && t2.length() > 0 &&
          t1.trim().toLowerCase() == t2.trim().toLowerCase()) { 1 }
        else if (t1 == null && t2 != null && t2.length() >= 0) { 0 }
        else if (t1 == null && t2 == null) { 1 }
        else { 0 }
      }
      
     val same_array = udf { (t1: WrappedArray[String], t2: WrappedArray[String]) =>
        if (t1 != null && t2 != null && t1.length == t2.length &&
          (t1.map(_.trim().toLowerCase()).intersect(t2.map(_.trim().toLowerCase())).length == t2.length)) { 1 }  
        else if (t1 == null && t2 == null) { 1 }
        else if ((t1 == null && t2 != null) || (t2 == null && t1 != null)) { 0 }        
        else { 0 }
      }
    
     def normalizeCodes = udf((loincCode: String) => { 
         if(null==loincCode || loincCode.equals(GlobalConstants.EMPTY_STRING) || loincCode.isEmpty()){
					null
    		}
    		else if(loincCode.startsWith(GlobalConstants.PIPE)){
				loincCode.substring(1).split(GlobalConstants.PIPE)
    		} else{
    		   loincCode.split(GlobalConstants.PIPE)
    		   Array(loincCode)
    		}
		  })
		  
		  
      log.info("generating the source annotation path for lonic releaseId : " + releaseID)
     
      var sourceAnnotationBasePath = oesConfiguration.BASE_PATH + releaseID + GlobalConstants.FORWARD_SLASH + oesConfiguration.SOURCE_ANNOTATION_PATH + GlobalConstants.FORWARD_SLASH
      if (!oesConfiguration.PROFILE.equalsIgnoreCase(GlobalConstants.LOCAL_PROFILE))
        sourceAnnotationBasePath = sourceAnnotationBasePath.substring(5)
      
      var count = 1
      var worklistId = GlobalConstants.EMPTY_STRING
      var currentTime = GlobalConstants.EMPTY_STRING
      while (taxonomyStack.nonEmpty) {
        val taxonomyName = taxonomyStack.pop
        try {
          var taxonomyOntologyFileName = GlobalConstants.labCorpSourceAnnotationMap.apply(taxonomyName)
          if (null != taxonomyOntologyFileName) {
            log.info("Loading the source annoataion data for taxonomy " + taxonomyName + " for LabCorp releaseId : " + releaseID)
            val sourceData = spark.read
              .format(GlobalConstants.CSV_FORMAT)
              .option(GlobalConstants.HEADER, true)
              .option(GlobalConstants.DELIMITER, GlobalConstants.TAB)
              .load(sourceAnnotationBasePath + taxonomyOntologyFileName)

            val releaseData = labCorpConcepts.filter(col(SparkSQLConstants.TAXONOMY_FSN) === taxonomyName)
            // ADD codes
            worklistId = releaseID + GlobalConstants.W + count + GlobalConstants.UNDER_SCORE + GlobalConstants.WORKLIST_ADD_CODES
           val addCodesData = releaseData.join(sourceData, lower(sourceData(SparkSQLConstants.IDENTIFIER)) === lower(releaseData(SparkSQLConstants.CONCEPT_ID)), SparkSQLConstants.ANTI_LEFT_JOIN)
            log.info("generating add code work list data for taxonomy : " + taxonomyName + " for LabCorp releaseId : " + releaseID)
            val addCodesWorklistData = addCodesData
              .select(
                SparkSQLConstants.TAXONOMY_FSN,
                SparkSQLConstants.CONCEPT_ID,
                SparkSQLConstants.TYPE,
                SparkSQLConstants.PREFERRED_TERM,
                SparkSQLConstants.LOINC_CODE,
                 SparkSQLConstants.CLASS_NAME,
                SparkSQLConstants.RESULTTYPE,
                SparkSQLConstants.EFFECTIVE_TIME)
              .withColumn(SparkSQLConstants.ACTION_STATUS, lit(GlobalConstants.REVIEW_PENDING))
              .withColumn(SparkSQLConstants.WORKLIST_ID, lit(worklistId))
              .withColumn(SparkSQLConstants.RELEASE_ID, lit(releaseID))
              .withColumn(SparkSQLConstants.WORKLIST_TYPE, lit(GlobalConstants.ADD_CODES))
            //writing add data into mongo
            log.info("saving  add code work list data for taxonomy " + taxonomyName + " for LabCorp releaseId : " + releaseID)
            mongoDAO.writeDataFrameToMongo(GlobalConstants.WORKLIST_ITEMS, addCodesWorklistData)
            log.info("saved successfully add code work list data for taxonomy " + taxonomyName + " for LabCorp releaseId : " + releaseID)
            
              // EDIT codes
            var srcWithLoincData = sourceData.select(GlobalConstants.STAR) 
            var relWithLoincData = releaseData.select(GlobalConstants.STAR)
             if(taxonomyName == GlobalConstants.OBSERVATION){
                srcWithLoincData = srcWithLoincData.withColumn(SparkSQLConstants.TYPE,lit(GlobalConstants.T))
                relWithLoincData = relWithLoincData.withColumn(SparkSQLConstants.TYPE,lit(GlobalConstants.T))
           }
          val relTypeDf =  relWithLoincData.withColumnRenamed(SparkSQLConstants.TYPE, SparkSQLConstants.RELEASE_TYPE)
          . select(
              SparkSQLConstants.RELEASE_ID,
              SparkSQLConstants.TAXONOMY_FSN,
              SparkSQLConstants.CONCEPT_ID,
              SparkSQLConstants.PREFERRED_TERM,             
              SparkSQLConstants.LOINC_CODE,
              SparkSQLConstants.RELEASE_TYPE,
              SparkSQLConstants.CLASS_NAME,
              SparkSQLConstants.RESULTTYPE,
              SparkSQLConstants.PROCESS_STATUS
             )
        
          val loincDeletedData = relTypeDf.join(srcWithLoincData, relTypeDf(SparkSQLConstants.CONCEPT_ID) === srcWithLoincData(SparkSQLConstants.IDENTIFIER))             
               .filter(col(SparkSQLConstants.LOINC_CODE) === "")
               .where(relTypeDf(SparkSQLConstants.LOINC_CODE) !== srcWithLoincData(SparkSQLConstants.LOINC_ID))
                .withColumn(SparkSQLConstants.EDITCODE_FLAG, array(lit(SparkSQLConstants.LOINC_CODE)))
               .withColumnRenamed( relTypeDf.col(SparkSQLConstants.RELEASE_ID).toString(),  SparkSQLConstants.LOINC_RELEASE_ID)
               .withColumnRenamed( relTypeDf.col(SparkSQLConstants.TAXONOMY_FSN).toString(), SparkSQLConstants.LOINC_TAXONOMY_FSN)
                .withColumnRenamed( relTypeDf.col(SparkSQLConstants.CONCEPT_ID).toString(), SparkSQLConstants.LOINC_CONCEPT_ID)
                .withColumnRenamed( relTypeDf.col( SparkSQLConstants.PREFERRED_TERM).toString(), SparkSQLConstants.LOINC_PREFERRED_TERM)
                .withColumnRenamed(relTypeDf.col(SparkSQLConstants.PROCESS_STATUS).toString(), SparkSQLConstants.LOINCL_PROCESS_STATUS)
                .withColumnRenamed(relTypeDf.col(SparkSQLConstants.CLASS_NAME).toString(), SparkSQLConstants.LOINC_PROCEDURECLASS)
                .withColumnRenamed(relTypeDf.col(SparkSQLConstants.LOINC_CODE).toString(), SparkSQLConstants.LOINC_LOINC_CODE)
                .withColumnRenamed(relTypeDf.col(SparkSQLConstants.RESULTTYPE).toString(), SparkSQLConstants.LOINC_RESULTTYPE)
                .withColumnRenamed(relTypeDf.col(SparkSQLConstants.RELEASE_TYPE).toString(), SparkSQLConstants.LOINC_RELEASE_TYPE)
                
             var loincDF = relTypeDf.join(loincDeletedData,
             loincDeletedData(SparkSQLConstants.LOINC_CONCEPT_ID) === relTypeDf(SparkSQLConstants.CONCEPT_ID), GlobalConstants.FULL_OUTER)
             .select(
                relTypeDf.col(SparkSQLConstants.RELEASE_ID).toString(),               
                relTypeDf.col(SparkSQLConstants.TAXONOMY_FSN).toString(),
                relTypeDf.col(SparkSQLConstants.CONCEPT_ID).toString(),
                relTypeDf.col( SparkSQLConstants.PREFERRED_TERM).toString(),
                relTypeDf.col(SparkSQLConstants.PROCESS_STATUS).toString(),
                relTypeDf.col( SparkSQLConstants.CLASS_NAME).toString(),
                relTypeDf.col( SparkSQLConstants.LOINC_CODE).toString(), 
                loincDeletedData.col(SparkSQLConstants.LOINC_LOINC_CODE).toString(), 
                relTypeDf.col(SparkSQLConstants.RESULTTYPE).toString(),
                relTypeDf.col(SparkSQLConstants.RELEASE_TYPE).toString(),
                loincDeletedData.col(SparkSQLConstants.EDITCODE_FLAG).toString()
              )  
              
             loincDF.createOrReplaceTempView(SparkSQLConstants.LOINC_TEMP_DF);
          
             val relLoincData = spark.sql(SparkSQLConstants.LOINC_DALETED_DATA) 
             
             
           worklistId = releaseID + GlobalConstants.W + count + GlobalConstants.UNDER_SCORE + GlobalConstants.WORKLIST_EDIT_CODES
             val editCodesData = relLoincData.join(srcWithLoincData, relLoincData(SparkSQLConstants.CONCEPT_ID) === srcWithLoincData(SparkSQLConstants.IDENTIFIER))
                .where(same_string(relLoincData(SparkSQLConstants.PREFERRED_TERM), srcWithLoincData(SparkSQLConstants.PREFERRED_TERM_EN)) === 0 ||              
                  same_array(normalizeCodes(relLoincData((SparkSQLConstants.LOINC_CODE))), normalizeCodes(srcWithLoincData(SparkSQLConstants.LOINC_ID))) === 0 ||
                  same_string(relLoincData(SparkSQLConstants.RELEASE_TYPE), srcWithLoincData(SparkSQLConstants.TYPE)) === 0 
                )
                .withColumn(SparkSQLConstants.REL_PREFERRED_TERM, relLoincData(SparkSQLConstants.PREFERRED_TERM)) 
                .withColumn(SparkSQLConstants.REL_LOINC_CODE, relLoincData(SparkSQLConstants.LOINC_CODE))
                .withColumn(SparkSQLConstants.REL_TYPE, relLoincData(SparkSQLConstants.RELEASE_TYPE))
                .withColumn(SparkSQLConstants.PREFERRED_TERM, when(same_string(relLoincData(SparkSQLConstants.PREFERRED_TERM), srcWithLoincData(SparkSQLConstants.PREFERRED_TERM_EN)) === 0,
                 relLoincData(SparkSQLConstants.PREFERRED_TERM)).otherwise(null))
                .withColumn(SparkSQLConstants.LOINC_CODE, when( same_array(normalizeCodes(relLoincData(SparkSQLConstants.LOINC_CODE)), normalizeCodes(srcWithLoincData(SparkSQLConstants.LOINC_ID))) === 0,
                 relLoincData(SparkSQLConstants.LOINC_CODE)).otherwise(null))
                .withColumn(SparkSQLConstants.TYPE, when( same_string(relLoincData(SparkSQLConstants.RELEASE_TYPE), srcWithLoincData(SparkSQLConstants.TYPE)) === 0,
                 relLoincData(SparkSQLConstants.RELEASE_TYPE)).otherwise(null))
                 .withColumn(SparkSQLConstants.CHANGECODE_FLAG, when(col(SparkSQLConstants.PREFERRED_TERM).isNotNull,GlobalConstants.TRUE).otherwise(GlobalConstants.FALSE))
                 
               
            val columnNames = editCodesData.distinct().columns.toArray
            val requiredColumns = ArrayBuffer[String](
              SparkSQLConstants.TAXONOMY_FSN,
              SparkSQLConstants.CONCEPT_ID,
              SparkSQLConstants.PREFERRED_TERM,             
              SparkSQLConstants.LOINC_CODE,
              SparkSQLConstants.TYPE,
              SparkSQLConstants.CLASS_NAME,
              SparkSQLConstants.RESULTTYPE,
              SparkSQLConstants.REL_PREFERRED_TERM,
              SparkSQLConstants.REL_LOINC_CODE,
              SparkSQLConstants.REL_TYPE,
              SparkSQLConstants.CHANGECODE_FLAG,
              SparkSQLConstants.EDITCODE_FLAG
               )
              
            val selectedColumns = requiredColumns.intersect(columnNames)
            val colNames = selectedColumns.map(name => col(name))
            log.info("generating edit code work list data for taxonomy " + taxonomyName + " for LabCorp releaseId : " + releaseID  + "colNames"+ colNames)
            var editCodesWorklistData = editCodesData.distinct().select(colNames: _*)
              .withColumn(SparkSQLConstants.ACTION_STATUS, lit(GlobalConstants.REVIEW_PENDING))
              .withColumn(SparkSQLConstants.WORKLIST_ID, lit(worklistId))
              .withColumn(SparkSQLConstants.RELEASE_ID, lit(releaseID))
              .withColumn(SparkSQLConstants.WORKLIST_TYPE, lit(GlobalConstants.EDIT_CODES))
                .withColumn(SparkSQLConstants.EDITCODE_FLAG, when(col(SparkSQLConstants.EDITCODE_FLAG) ===  array(lit(GlobalConstants.EMPTY_STRING)), lit(Array.empty[String])).otherwise(col(SparkSQLConstants.EDITCODE_FLAG)))
              .withColumn(SparkSQLConstants.REVISED_DATE, lit(revisedDate))
           log.info("saving edit code work list data for taxonomy " + taxonomyName + " for loinc releaseId : " + releaseID)
            //writing edit data into mongo
            mongoDAO.writeDataFrameToMongo(GlobalConstants.WORKLIST_ITEMS, editCodesWorklistData.distinct())
            log.info("saved edit code work list data for taxonomy " + taxonomyName + " for loinc releaseId : " + releaseID)
            count += 1
          } else {
            log.info("No Source ontology file found for taxonomy : " + taxonomyName)
          }
        } catch {
          case e: Exception =>
            log.error(s"Exception while running data comparator for taxonomy " + taxonomyName + " for ADD worklist for LabCorp releaseId : " + releaseID)
            log.error(e.printStackTrace())
        }
      }
      log.info("Completed data comparator for ADD worklist for LabCorp releaseId : " + releaseID)
    } catch {
      case e: Exception =>
        log.error(s"Exception while running data comparator for ADD worklist for LabCorp releaseId : " + releaseID)
        log.error(e.printStackTrace())
      //	throw e
    }
  }
}
