# OEA Comparator
Spark Job to process release concepts and generates worklists' data.
