create table {schemaname}.L5_PAT_ASSESS_NUM (
    CLIENT_ID VARCHAR(16) not null encode zstd,
    MPI VARCHAR(32) not null encode zstd,
    ASSESSMENT_DTM TIMESTAMP not null encode zstd,
    ASSESSMENT_CUI VARCHAR(8) not null,
    NUMERIC_VALUE FLOAT not null encode zstd,
    CDS_GRP VARCHAR(4000) encode zstd,
    CLINICAL_EVENT_ID BIGINT encode zstd,
    HOSP_IND SMALLINT not null encode zstd,
    INFERRED_IND SMALLINT not null encode zstd,
    NLP_IND SMALLINT encode zstd,
    SENSITIVE_IND SMALLINT not null encode zstd,
    ROLLING_TIMEFRAME_ID INTEGER encode zstd,
    YEAR_TO_DATE_ID INTEGER encode zstd) distkey(MPI) sortkey(assessment_cui);
