create table {schemaname}.L5_PAT_ASSESS_NUM_MOST_REC_YR (
    MPI VARCHAR(32) not null encode zstd,
    ASSESSMENT_CUI VARCHAR(8) not null,
    CDS_GRP VARCHAR(4000) encode zstd,
    LAST_ASSESS_DATE DATE encode zstd,
    NUMERIC_VALUE FLOAT encode zstd,
    ROLLING_TIMEFRAME_ID SMALLINT encode zstd,
    YEAR_TO_DATE_ID SMALLINT encode zstd,
    SENSITIVE_IND SMALLINT encode zstd) distkey(MPI) sortkey(ASSESSMENT_CUI);
