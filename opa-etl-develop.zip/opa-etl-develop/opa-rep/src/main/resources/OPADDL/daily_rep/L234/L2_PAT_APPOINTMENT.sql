-- updated manually
-- CREATE VIEW IF NOT EXISTS {{db_name}}.l2_pat_appointment
-- AS
-- SELECT client_id, mpi, cds_flg, appointment_dtm, prov_id, appointment_location
-- FROM {{db_name}}.t_l2_pat_appointment;

CREATE TABLE {schemaname}.L2_PAT_APPOINTMENT (
	appointment_dtm TIMESTAMP,
	appointment_location VARCHAR (100) encode zstd,
	cds_grp VARCHAR (4000) encode zstd,
	client_ID VARCHAR (16) encode zstd,
	mpi VARCHAR (32) encode zstd,
	prov_id VARCHAR(20) encode zstd,
	appointment_reason VARCHAR(249) encode zstd
) distkey(MPI) sortkey(appointment_dtm);