create table {schemaname}.L5_PAT_CONDITION_INFERRED (
    CLIENT_ID VARCHAR(16) encode zstd,
    MPI VARCHAR(32) encode zstd,
    CONDITION_ID INTEGER,
    YR_MONTH INTEGER encode zstd,
    PRECURSOR_CDS_GRP VARCHAR(4000) encode zstd,
    SENSITIVE_IND SMALLINT encode zstd,
    INFERRED_PRECURSOR_CDS_GRP VARCHAR(4000) encode zstd,
    ROLLING_TIMEFRAME_ID SMALLINT encode zstd,
    YEAR_TO_DATE_ID SMALLINT encode zstd
) distkey(MPI) sortkey(condition_id);