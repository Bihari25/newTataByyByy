create table {schemaname}.L5_MAP_PATIENT_UPLOAD_RULES (
    CLIENT_ID VARCHAR(20) not null encode zstd,
    CLIENT_DS_ID INTEGER not null encode zstd,
    ID_TYPE VARCHAR(255) encode zstd,
    ID_SUBTYPE VARCHAR(255) encode zstd,
    DS_DISPLAY_NAME VARCHAR(255) encode zstd,
    ID_VALUE VARCHAR(50) encode zstd,
    MPI VARCHAR(32),
    DUMMY_EMAIL VARCHAR(1) DEFAULT 'Y' encode zstd) distkey(mpi) sortkey(mpi);