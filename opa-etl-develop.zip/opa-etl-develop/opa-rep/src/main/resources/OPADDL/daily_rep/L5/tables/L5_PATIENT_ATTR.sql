CREATE TABLE {schemaname}.L5_PATIENT_ATTR (
 MPI VARCHAR (32),
 ATTR1 VARCHAR (255) encode zstd,
 ATTR2 VARCHAR (255) encode zstd,
 ATTR3 VARCHAR (255) encode zstd,
 ATTR4 VARCHAR (255) encode zstd,
 ATTR5 VARCHAR (255) encode zstd,
 ATTR6 VARCHAR (255) encode zstd
)distkey(MPI) sortkey(MPI);