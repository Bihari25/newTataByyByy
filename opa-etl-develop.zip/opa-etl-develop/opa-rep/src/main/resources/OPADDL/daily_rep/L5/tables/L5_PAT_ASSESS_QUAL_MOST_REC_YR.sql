create table {schemaname}.L5_PAT_ASSESS_QUAL_MOST_REC_YR (
    MPI VARCHAR(32) not null,
    ASSESSMENT_CUI VARCHAR(8) not null encode zstd,
    CDS_GRP VARCHAR(4000) encode zstd,
    LAST_ASSESS_DATE DATE encode zstd,
    VALUE_CUI VARCHAR(8) encode zstd,
    ROLLING_TIMEFRAME_ID SMALLINT encode zstd,
    YEAR_TO_DATE_ID SMALLINT encode zstd,
    SENSITIVE_IND SMALLINT encode zstd) distkey(MPI) sortkey(MPI);
