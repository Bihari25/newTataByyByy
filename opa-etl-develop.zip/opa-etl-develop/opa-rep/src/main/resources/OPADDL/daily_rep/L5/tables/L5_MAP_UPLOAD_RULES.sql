create table {schemaname}.L5_MAP_UPLOAD_RULES (
    CLIENT_DS_ID INTEGER not null,
    ID_TYPE VARCHAR(255),
    ID_SUBTYPE VARCHAR(255),
    DS_DISPLAY_NAME VARCHAR(255) encode zstd) diststyle all sortkey(client_ds_id, id_type, id_subtype);