CREATE TABLE {schemaname}.L5_PAT_CLINICAL_EVENT_COND (
    CLIENT_ID VARCHAR (16) encode zstd,
    MPI VARCHAR (32),
    CLINICAL_EVENT_ID BIGINT encode az64,
    CONDITION_ID INTEGER,
    PRINCIPAL_DX_IND VARCHAR (1) encode zstd,
    HOSP_DX_IND VARCHAR (1) encode zstd,
    ETG_QUAL_EVT_IND VARCHAR (1) encode zstd,
    EM_NARROW_IND VARCHAR (1) encode zstd,
    EM_WIDE_IND VARCHAR (1) encode zstd,
    BILL_CLAIM_IND VARCHAR (1) encode zstd,
    SENSITIVE_IND SMALLINT encode zstd,
    EM_IND VARCHAR (1) encode zstd
) distkey(mpi) sortkey(mpi, clinical_event_id, condition_id);