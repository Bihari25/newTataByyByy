CREATE OR REPLACE VIEW {schemaname}.L5_PAT_NEXT_APPOINTMENT AS (
    SELECT DISTINCT
      pa.mpi,
      trunc(pa.APPOINTMENT_DTM) AS next_appointment_date,
      pi.PROVIDER_NAME,
      ds.SP4,
      mcg.client_ds_name,
      coalesce(pa.appointment_reason,'Unspecified') as appointment_reason
    FROM
      (
        SELECT
          *,
          ROW_NUMBER() OVER(
            partition BY mpi
            ORDER BY
              APPOINTMENT_DTM ASC
          ) appointment_order
        FROM
          L5_PAT_APPOINTMENT
      ) pa
      JOIN L5_MAP_ALL_CDS_GRP mcg ON pa.CDS_GRP = mcg.CDS_GRP
      JOIN L5_PROVIDER_INFO pi ON (pa.PROV_ID = pi.PROV_ID)
      JOIN L2_DICT_SPEC ds ON (ds.prv_sp_4 = CAST(pi.SPECIALTY_ID AS VARCHAR(20)))
    WHERE appointment_order = 1
)