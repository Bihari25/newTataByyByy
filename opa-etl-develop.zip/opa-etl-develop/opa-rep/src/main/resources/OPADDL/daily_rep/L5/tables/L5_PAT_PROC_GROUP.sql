CREATE TABLE {schemaname}.L5_PAT_PROC_GROUP (
  client_id             VARCHAR(16)     ENCODE zstd,
  prov_id               VARCHAR(22)     ENCODE zstd,
  mpi                   VARCHAR(32),
  proc_group_id         INTEGER         ENCODE zstd,
  cds_grp               VARCHAR(4000)   ENCODE zstd,
  principal_ind         SMALLINT        ENCODE zstd,
  proc_dtm              TIMESTAMP       ENCODE zstd,
  rolling_timeframe_id  SMALLINT        ENCODE zstd,
  year_to_date_id       SMALLINT        ENCODE zstd,
  sensitive_ind         SMALLINT        ENCODE zstd
)distkey(mpi) sortkey(mpi);