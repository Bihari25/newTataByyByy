CREATE TABLE {SCHEMANAME}.L4_DICT_ORG_HIER(
     client_id VARCHAR (16) ENCODE zstd,
     org_cd VARCHAR (150),
     org_desc VARCHAR (150) ENCODE zstd,
     org_lv1_cd VARCHAR (150),
     org_lv1_desc VARCHAR (150) ENCODE zstd,
     org_lv2_cd VARCHAR (150),
     org_lv2_desc VARCHAR (150) ENCODE zstd
) diststyle all sortkey (org_lv1_cd, org_lv2_cd, org_cd);