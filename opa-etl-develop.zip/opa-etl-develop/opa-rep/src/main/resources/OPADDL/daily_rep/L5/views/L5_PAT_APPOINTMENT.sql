CREATE OR REPLACE VIEW {schemaname}.L5_PAT_APPOINTMENT AS(
        SELECT client_id,
               mpi,
               cds_grp,
               appointment_dtm,
               prov_id,
               appointment_location,
               coalesce(appointment_reason,'Unspecified') as appointment_reason
        FROM L2_PAT_APPOINTMENT
        WHERE appointment_dtm >= SYSDATE);
