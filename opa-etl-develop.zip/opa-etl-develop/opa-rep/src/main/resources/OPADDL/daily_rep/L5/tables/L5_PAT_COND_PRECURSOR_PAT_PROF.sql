create table {schemaname}.L5_PAT_COND_PRECURSOR_PAT_PROF (
    CLIENT_ID VARCHAR(16) not null encode zstd,
    MPI VARCHAR(32) not null,
    PRECURSOR_CDS_GRP VARCHAR(4000) encode lzo,
    CONDITION_ID INTEGER encode az64,
    PRECURSOR_ID INTEGER encode az64,
    PRECURSOR_MODIFIER_FLG INTEGER encode zstd,
    PRECURSOR_DT TIMESTAMP encode zstd,
    PRECURSOR_DOMAIN VARCHAR(16) encode zstd,
    PRECURSOR_TYPE VARCHAR(20) encode zstd,
    PRECURSOR_VALUE VARCHAR(50) encode zstd,
    SENSITIVE_IND SMALLINT encode zstd,
    YR_MONTH INTEGER encode zstd,
    EVIDENCE_DOMAIN VARCHAR(10) encode zstd,
    EVIDENCE_TYPE VARCHAR(150) encode zstd,
    EVIDENCE_VALUE VARCHAR(150) encode zstd,
    ROLLING_TIMEFRAME_ID SMALLINT encode zstd,
    YEAR_TO_DATE_ID SMALLINT encode zstd
) distkey(mpi) sortkey(mpi, condition_id, precursor_id, precursor_cds_grp);