CREATE TABLE {schemaname}.L2_MAP_HOSP_SITE (
	client_id VARCHAR (16) encode zstd,
	hosp_site_cd VARCHAR (400) encode zstd,
	hosp_site_desc VARCHAR (400) encode zstd,
	hosp_site_id BIGINT,
	hosp_site_zip VARCHAR (20) encode zstd
) diststyle all sortkey(hosp_site_id);
