CREATE TABLE {schemaname}.L2_PAT_ID (
	client_ds_id INTEGER,
	client_id VARCHAR (16) encode zstd,
	id_subtype VARCHAR (50) encode zstd,
	-- id_subtype_ind INTEGER, -- manually omitted not part of view
	id_type VARCHAR (20) encode lzo,
	id_value VARCHAR (50) encode zstd,
	mpi VARCHAR (32) encode lzo
) distkey(MPI) sortkey(client_ds_id, id_type, mpi);
