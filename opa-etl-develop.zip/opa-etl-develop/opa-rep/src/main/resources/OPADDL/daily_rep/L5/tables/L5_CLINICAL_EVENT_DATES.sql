CREATE TABLE {schemaname}.l5_clinical_event_dates
(
    CLIENT_ID VARCHAR(16) encode zstd,
    CLIENT_DS_ID BIGINT,
    CLINICAL_EVT_MIN_DT TIMESTAMP encode zstd,
    CLINICAL_EVT_MAX_DT TIMESTAMP encode zstd) diststyle all sortkey(client_ds_id);