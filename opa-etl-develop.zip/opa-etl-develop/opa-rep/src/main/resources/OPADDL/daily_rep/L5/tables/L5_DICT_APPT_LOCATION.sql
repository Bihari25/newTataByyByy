CREATE TABLE {schemaname}.L5_DICT_APPT_LOCATION (
	appointment_location VARCHAR (100)
) diststyle all sortkey(appointment_location);