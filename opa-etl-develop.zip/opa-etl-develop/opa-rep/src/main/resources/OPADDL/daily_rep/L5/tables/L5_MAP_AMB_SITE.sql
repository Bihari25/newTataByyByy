create table {schemaname}.L5_MAP_AMB_SITE (    
AMB_SITE_ID BIGINT,
AMB_SITE_DESC VARCHAR(400) encode zstd
) diststyle all sortkey (AMB_SITE_ID);
