CREATE TABLE {schemaname}.L5_PATIENT_CONDITION (
	client_id VARCHAR (16) encode zstd,
	condition_id INTEGER,
	mpi VARCHAR (32) encode zstd,
	precursor_cds_grp VARCHAR(4000) encode zstd,
	sensitive_ind SMALLINT encode zstd,
	yr_month INTEGER encode zstd,
	rolling_timeframe_id SMALLINT encode zstd,
    year_to_date_id SMALLINT encode zstd
) distkey(MPI) sortkey(condition_id);
