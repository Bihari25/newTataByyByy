CREATE TABLE {SCHEMANAME}.L4_PAT_ORG_HIER (
  client_id VARCHAR (16) ENCODE zstd,
  mpi VARCHAR (32),
  org_cd VARCHAR (150),
  most_recent_ind INTEGER ENCODE zstd
) distkey (mpi) sortkey(mpi, org_cd);