CREATE TABLE {schemaname}.L5_PAT_ASSESS_QUAL(
    client_id varchar(16) encode zstd,
    cds_grp varchar(4000) encode zstd,
    mpi varchar(32),
    assessment_dtm timestamp encode zstd,
    assessment_cui varchar(8) encode zstd,
    value_cui varchar(8) encode zstd,
    clinical_event_id bigint encode zstd,
    nlp_ind integer encode zstd,
    sensitive_ind integer encode zstd,
    inferred_ind integer encode zstd,
    hosp_ind integer encode zstd,
    rolling_timeframe_id integer encode zstd,
    year_to_date_id integer encode zstd
)distkey(mpi) sortkey(mpi);