create table {schemaname}.L5_DICT_ROLLING_TIMEFRAME (
    ROLLING_TIMEFRAME_ID SMALLINT,
    ROLLING_TIMEFRAME_DESC VARCHAR(30) encode zstd
) diststyle all sortkey(rolling_timeframe_id);