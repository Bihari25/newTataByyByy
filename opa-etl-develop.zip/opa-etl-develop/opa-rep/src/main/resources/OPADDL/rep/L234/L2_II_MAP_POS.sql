CREATE TABLE {schemaname}.L2_II_MAP_POS (
	POS_DESC VARCHAR (150) encode zstd,
	POS_I INTEGER
) diststyle all sortkey(POS_I);