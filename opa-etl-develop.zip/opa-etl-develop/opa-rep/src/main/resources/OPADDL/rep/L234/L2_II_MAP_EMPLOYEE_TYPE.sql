CREATE TABLE {schemaname}.L2_II_MAP_EMPLOYEE_TYPE (
	employee_status BOOLEAN encode zstd,
	employee_type VARCHAR (30) encode zstd,
	employee_type_desc VARCHAR (150) encode zstd,
	employee_type_id VARCHAR (40),
	map_srce_e VARCHAR (6) encode zstd,
	riflag INT encode zstd
) diststyle all sortkey(employee_type_id);
