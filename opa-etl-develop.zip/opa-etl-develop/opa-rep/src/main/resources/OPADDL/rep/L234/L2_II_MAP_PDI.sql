CREATE TABLE {schemaname}.L2_II_MAP_PDI (
	PDI INTEGER,
	PDI_DESC VARCHAR (100) encode zstd
) diststyle all sortkey(PDI);
