create table {schemaname}.L5_DICT_TOS4 (
    TOS_I_4 INTEGER not null,
    TOS4 VARCHAR(255) not null encode zstd
) diststyle all sortkey (TOS_I_4);