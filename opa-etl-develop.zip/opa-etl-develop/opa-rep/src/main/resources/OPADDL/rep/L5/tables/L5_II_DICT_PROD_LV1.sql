create table {schemaname}.L5_II_DICT_PROD_LV1 (
    PRODUCT_LV1_ID VARCHAR(100),
    PRODUCT_LV1_DESC VARCHAR(150) encode zstd
) diststyle all sortkey(product_lv1_id);