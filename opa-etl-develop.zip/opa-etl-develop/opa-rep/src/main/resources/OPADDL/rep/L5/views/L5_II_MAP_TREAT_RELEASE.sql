CREATE OR REPLACE VIEW {schemaname}.L5_II_MAP_TREAT_RELEASE AS
  (SELECT 1 AS treat_release,
          'Yes' AS Description
   UNION SELECT 0 AS treat_release,
                'No' AS Description);