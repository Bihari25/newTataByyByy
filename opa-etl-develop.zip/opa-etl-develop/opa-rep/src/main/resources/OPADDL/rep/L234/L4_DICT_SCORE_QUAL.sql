CREATE TABLE {schemaname}.l4_dict_score_qual (
    score_qual_id     INTEGER          ,
    score_qual_name   VARCHAR(200)     ENCODE zstd,
    score_qual_desc   VARCHAR(400)     ENCODE zstd
)
diststyle all
SORTKEY (score_qual_id);
