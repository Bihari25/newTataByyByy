CREATE TABLE {schemaname}.l5_dynamic_time_range (
    year_mth_id                 INTEGER,
    yr_month                    INTEGER     ENCODE az64,
    rolling_12_months_flg       SMALLINT    ENCODE az64,
    rolling_15_months_flg       SMALLINT    ENCODE az64,
    rolling_18_months_flg       SMALLINT    ENCODE az64,
    rolling_27_months_flg       SMALLINT    ENCODE az64,
    cytd_flg                    SMALLINT    ENCODE az64,
    cytd_desc                   VARCHAR(13) ENCODE zstd
)
DISTSTYLE ALL
SORTKEY (year_mth_id);