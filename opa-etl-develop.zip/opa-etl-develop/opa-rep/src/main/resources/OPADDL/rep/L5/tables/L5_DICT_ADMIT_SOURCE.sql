CREATE TABLE {schemaname}.l5_dict_admit_source
(
	admit_source SMALLINT,
	admit_source_desc VARCHAR(20)  encode zstd
)
DISTSTYLE ALL SORTKEY (admit_source);