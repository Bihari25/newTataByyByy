CREATE OR REPLACE VIEW {schemaname}.L5_OPA_USER_ROLES AS (
    SELECT 0 AS user_role_id, 'OPA User Role - Consumer' AS user_role_desc
    UNION
    SELECT 1 AS user_role_id, 'OPA User Role - Executive' AS user_role_desc
    UNION
    SELECT 2 AS user_role_id, 'OPA User Role - Analyst' AS user_role_desc
    UNION
    SELECT 3 AS user_role_id, 'OPA User Role - Client Administrator' AS user_role_desc
);