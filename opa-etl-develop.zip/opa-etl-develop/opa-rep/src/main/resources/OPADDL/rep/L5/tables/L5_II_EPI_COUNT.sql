CREATE TABLE {schemaname}.L5_II_EPI_COUNT (
    PROVIDER_ID VARCHAR (20) encode zstd ,
	PRODUCT_ID VARCHAR (40) encode zstd,
	PEER_DEF_ID INTEGER encode zstd,
	CAT_MEMBER INTEGER encode zstd,	
	ETG_ID INTEGER encode zstd,
	ETG_UNIT_ID INTEGER encode zstd,
	IA_TIME INTEGER ,
	IA_TIME_ADJ INTEGER encode zstd,	
	PHM_QUAL SMALLINT encode zstd,
	SEV_LEVEL SMALLINT encode zstd,
	RRISK_EPI_W DECIMAL (28, 6) encode zstd,
	EPI_QTY DECIMAL (28, 6) encode zstd
) sortkey(IA_TIME);
	
	