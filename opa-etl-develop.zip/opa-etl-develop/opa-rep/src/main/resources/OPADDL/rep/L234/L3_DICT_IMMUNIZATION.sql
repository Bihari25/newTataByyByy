CREATE TABLE {schemaname}.l3_dict_immunization (
     IMMUNIZATION_ID    INTEGER,
     IMMUNIZATION_DESC  VARCHAR (255) encode zstd,
     SENSITIVE_IND      INTEGER encode zstd,
     SENSITIVE_CAT_ID   INTEGER encode zstd
) diststyle all sortkey (IMMUNIZATION_ID);
