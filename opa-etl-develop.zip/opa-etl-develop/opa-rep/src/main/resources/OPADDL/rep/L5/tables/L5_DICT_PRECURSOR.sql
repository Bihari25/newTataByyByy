CREATE TABLE {schemaname}.L5_DICT_PRECURSOR (
	precursor_id INTEGER,
	precursor_name VARCHAR (100) encode zstd,
	precursor_desc VARCHAR (400) encode zstd,
	sensitive_ind INTEGER encode zstd,	
	active_ind INTEGER encode zstd,
	precursor_domain_cd VARCHAR (16) encode zstd,
	chronic_ind SMALLINT encode zstd
) diststyle all sortkey (precursor_id);
