create table {schemaname}.L5_II_DICT_BIZ_SEGMENT_LV1 (    BIZ_SEGMENT_LV1_ID VARCHAR(100),
    BIZ_SEGMENT_LV1_DESC VARCHAR(150) encode zstd
) diststyle all sortkey(BIZ_SEGMENT_LV1_ID);