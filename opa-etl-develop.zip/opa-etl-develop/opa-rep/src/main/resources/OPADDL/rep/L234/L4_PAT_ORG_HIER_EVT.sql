CREATE TABLE {schemaname}.L4_PAT_ORG_HIER_EVT (
	client_id varchar(16) encode zstd,
    mpi varchar(32),
    org_cd VARCHAR(150)
) distkey (mpi) sortkey(mpi, org_cd);