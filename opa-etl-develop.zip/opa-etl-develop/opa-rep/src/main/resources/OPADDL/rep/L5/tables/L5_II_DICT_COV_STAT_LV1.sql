create table {schemaname}.L5_II_DICT_COV_STAT_LV1 (    COVERAGE_STATUS_LV1_ID VARCHAR(100),
    COVERAGE_STATUS_LV1_DESC VARCHAR(150) encode zstd
) diststyle all sortkey(COVERAGE_STATUS_LV1_ID);