create table {schemaname}.L5_DICT_IND_EXT (
    IND_ID SMALLINT,
    IND_DESC VARCHAR (15) encode zstd
) diststyle all sortkey(IND_ID);