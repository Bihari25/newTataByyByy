create table {schemaname}.L5_DICT_IA_TIME (    IA_TIME INTEGER,
    IA_TIME_CODE VARCHAR(1020) encode zstd,
    IA_TIME_DESC VARCHAR(1020) encode zstd,
    IA_TIME_DATE_DESC VARCHAR(1020) encode zstd,
    IA_TIME_FULL_DESC VARCHAR(1020) encode zstd,
    IA_TIME_START_DATE TIMESTAMP encode zstd,
    IA_TIME_END_DATE TIMESTAMP encode zstd,
    IA_START_MTH_YEAR_DESC VARCHAR(17) encode zstd,
    IA_END_MTH_YEAR_DESC VARCHAR(17) encode zstd
) diststyle all sortkey(IA_TIME);