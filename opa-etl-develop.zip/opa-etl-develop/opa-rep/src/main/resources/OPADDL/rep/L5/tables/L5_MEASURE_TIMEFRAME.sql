create table {schemaname}.L5_MEASURE_TIMEFRAME (
    MEASURE_SET_ID INTEGER,
    MEASURE_SET VARCHAR(20) encode zstd,
    MEASURE_VERS VARCHAR(20) encode zstd,
    TIMEFRAME_ID INTEGER encode zstd,
    MEASURE_SET_TIMEFRAME VARCHAR(93) encode zstd
) diststyle all sortkey (MEASURE_SET_ID);

