create table {schemaname}.L5_II_DICT_NTWK_PD_STAT_LV1 (
    NETWORK_PAID_STATUS_LV1_ID VARCHAR(100),
    NETWORK_PAID_STATUS_LV1_DESC VARCHAR(150) encode zstd
) diststyle all sortkey(network_paid_status_lv1_id);