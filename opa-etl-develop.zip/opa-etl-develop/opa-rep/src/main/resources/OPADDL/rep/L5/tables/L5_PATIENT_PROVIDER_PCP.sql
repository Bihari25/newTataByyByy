CREATE TABLE {schemaname}.L5_PATIENT_PROVIDER_PCP (
    CLIENT_ID VARCHAR(16) not null encode zstd,
    MPI VARCHAR (32),
    PROV_ATTRIB_ID SMALLINT encode zstd,
    MOST_RECENT_IND SMALLINT encode zstd,
    PROV_ID VARCHAR(20),
    YR_MONTH INTEGER
)distkey(MPI) sortkey (MPI, PROV_ID, YR_MONTH);