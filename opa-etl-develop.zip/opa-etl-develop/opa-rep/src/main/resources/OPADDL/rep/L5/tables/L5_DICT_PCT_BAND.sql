create table {schemaname}.L5_DICT_PCT_BAND (
    PCT_BAND_ID SMALLINT,
    PCT_BAND_DESC VARCHAR(25) encode zstd,
    PCT_BAND_MIN SMALLINT encode zstd,
    PCT_BAND_MAX SMALLINT encode zstd
) diststyle all sortkey(pct_band_id);