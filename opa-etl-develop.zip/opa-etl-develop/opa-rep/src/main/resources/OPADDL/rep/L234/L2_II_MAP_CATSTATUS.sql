CREATE TABLE {schemaname}.L2_II_MAP_CATSTATUS (
	CAT100K BOOLEAN encode zstd,
	CAT200K BOOLEAN encode zstd,
	CAT25K BOOLEAN encode zstd,
	CAT50K BOOLEAN encode zstd,
	CAT_STATUS INTEGER encode az64,
	CAT_STATUS_DESC VARCHAR (22) encode zstd,
	CAT_STATUS_LV2 INTEGER,
	CAT_STATUS_LV2_DESC VARCHAR (22) encode zstd,
	THRESHOLD DECIMAL (19, 2) encode az64
) diststyle all sortkey (CAT_STATUS_LV2);
