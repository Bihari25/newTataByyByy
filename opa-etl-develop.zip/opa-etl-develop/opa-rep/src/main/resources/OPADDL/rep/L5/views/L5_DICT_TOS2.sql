CREATE OR REPLACE VIEW {schemaname}.L5_DICT_TOS2 AS
  (SELECT DISTINCT tos2_id,
                   tos2
   FROM l2_ii_map_tos);