CREATE TABLE {schemaname}.L2_II_MAP_MPG_DEF (
	MPG_DEF_DESC VARCHAR (60) encode zstd,
	MPG_DEF_ID INTEGER,
	MPG_OTHER_FLAG INTEGER encode zstd,
	MPG_SEG_LVL INTEGER encode zstd,
	PARENT_MPG_DEF_ID INTEGER encode zstd
) diststyle all sortkey(MPG_DEF_ID);
