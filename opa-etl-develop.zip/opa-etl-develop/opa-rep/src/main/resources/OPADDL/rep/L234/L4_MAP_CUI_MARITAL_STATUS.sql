CREATE TABLE {schemaname}.L4_MAP_CUI_MARITAL_STATUS (
cui VARCHAR(50),
cui_name VARCHAR(100) encode zstd
) diststyle all sortkey(cui);