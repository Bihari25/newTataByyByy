CREATE TABLE {schemaname}.L4_PAT_SCORE (
	client_id VARCHAR (16) encode zstd,
	elig_cds_id INTEGER encode zstd,
	mpi VARCHAR (32) encode zstd,
	score double precision encode zstd,
	score_default_flg INTEGER encode zstd,
	score_id INTEGER encode zstd,
	timeframe_id INTEGER
) distkey(MPI) sortkey(timeframe_id);
