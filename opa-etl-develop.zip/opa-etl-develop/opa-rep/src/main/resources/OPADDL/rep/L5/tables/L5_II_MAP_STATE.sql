CREATE TABLE {schemaname}.L5_II_MAP_STATE (
    state INTEGER,
    state_desc VARCHAR(3) encode zstd,
    state_name VARCHAR(64) encode zstd
) diststyle all sortkey(state);
