create table {schemaname}.L5_DICT_ASSESSMENT (
	assessment_cui VARCHAR (8),
	assessment_name VARCHAR (150) encode zstd,
	assessment_units VARCHAR (50) encode zstd,
	lab_ind SMALLINT encode zstd,
	lab_ind_desc VARCHAR (12) encode zstd,
	qualitative_ind SMALLINT encode zstd,
	quantitative_ind SMALLINT encode zstd,
	sensitive_ind SMALLINT encode zstd
) diststyle all sortkey(assessment_cui);