CREATE TABLE {schemaname}.L5_II_MAP_CATSTATUS (
    cat_status           SMALLINT,
    cat_status_desc      VARCHAR (22)    encode zstd
) diststyle all sortkey(cat_status);