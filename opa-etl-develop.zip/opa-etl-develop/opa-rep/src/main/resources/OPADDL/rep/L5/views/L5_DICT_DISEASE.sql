CREATE OR REPLACE VIEW {schemaname}.L5_DICT_DISEASE AS
  (SELECT disease_id,
          disease_desc,
          disease_desc_mask
   FROM l2_ii_map_disease
   UNION SELECT 0,
                'Unknown',
                NULL);