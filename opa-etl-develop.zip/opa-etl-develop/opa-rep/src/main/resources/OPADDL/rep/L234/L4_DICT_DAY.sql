CREATE TABLE {schemaname}.L4_DICT_DAY (
	day_dt TIMESTAMP,
	month_id INTEGER,
	prev_day_dt TIMESTAMP encode zstd,
	prev_month_day_dt TIMESTAMP encode zstd,
	prev_quarter_day_dt TIMESTAMP encode zstd,
	prev_year_day_dt TIMESTAMP encode zstd,
	quarter_id INTEGER encode zstd,
	weekday_name VARCHAR (20) encode zstd,
	weekday_short_name VARCHAR (10) encode zstd,
	year_id INTEGER 
) diststyle all sortkey(year_id, month_id, day_dt);
