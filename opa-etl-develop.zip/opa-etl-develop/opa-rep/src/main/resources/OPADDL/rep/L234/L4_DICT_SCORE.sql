CREATE TABLE {schemaname}.L4_DICT_SCORE (
	active_ind          INTEGER         encode zstd,
	precalc_ind         INTEGER         encode zstd,
	qualitative_ind     INTEGER         encode zstd,
	quantitative_ind    INTEGER         encode zstd,
	score_desc          VARCHAR(400)    encode zstd,
	score_display_name  VARCHAR(255)    encode zstd,  --added manually from oadw_schema_manual.hql
	score_family_id     INTEGER         encode zstd,
	score_id            INTEGER,
	score_name          VARCHAR(50)     encode zstd,
	score_population_id INTEGER         encode zstd,
	score_type_id       INTEGER         encode zstd
) diststyle all sortkey(score_id);
