CREATE TABLE {schemaname}.L5_II_MAP_DRG_TYPE (
	DRG_ADMITTYP VARCHAR (3),
	DRG_TYPE_DESC VARCHAR (79) encode zstd
) diststyle all sortkey(DRG_ADMITTYP);