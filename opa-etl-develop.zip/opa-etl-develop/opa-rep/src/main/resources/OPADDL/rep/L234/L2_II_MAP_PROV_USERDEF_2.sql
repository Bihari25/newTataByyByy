CREATE TABLE {schemaname}.L2_II_MAP_PROV_USERDEF_2 (
	MAP_SRCE_P VARCHAR(6) encode zstd,
	PROV_USERDEF_2 VARCHAR(30) encode zstd,
	PROV_USERDEF_2_DESC VARCHAR(150) encode zstd,
	PROV_USERDEF_2_ID VARCHAR (40),
	RIFLAG INT encode zstd
) diststyle all sortkey(PROV_USERDEF_2_ID);