CREATE TABLE {schemaname}.L2_II_MAP_CLM_EXCLUDE (
	CLM_EXCLUDE INTEGER,
	CLM_EXCLUDE_DESC VARCHAR (40) encode zstd
) diststyle all sortkey(CLM_EXCLUDE);
