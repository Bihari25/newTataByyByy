CREATE TABLE {schemaname}.L5_DICT_MEASURE_PRECUR (
    MEASURE_ID INTEGER,
	PRECURSOR_ID INTEGER,
	MEASURE_PRECURSOR_DESC VARCHAR (400) encode zstd
)  diststyle all sortkey(measure_id,precursor_id);

