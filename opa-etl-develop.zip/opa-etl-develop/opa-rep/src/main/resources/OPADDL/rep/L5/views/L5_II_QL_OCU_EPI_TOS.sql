CREATE OR REPLACE VIEW {schemaname}.L5_II_QL_OCU_EPI_TOS AS
  (SELECT tos_level,
          tos1_id,
          tos2_id,
          tos3_id,
          mem_attr_id,
          etg_id,
          CASE
              WHEN sev_level IS NULL THEN 0
              ELSE sev_level
          END AS sev_level,
          ia_time,
          outlier,
          COMPLETE,
          epi_qty,
          rrisk,
          cost1,
          cost2,
          cost3,
          cost4,
          cost5,
          cost6,
          encounter,
          amt_pay_adj,
          amt_eqv_adj
   FROM l2_ii_ql_ocu_epi_tos);