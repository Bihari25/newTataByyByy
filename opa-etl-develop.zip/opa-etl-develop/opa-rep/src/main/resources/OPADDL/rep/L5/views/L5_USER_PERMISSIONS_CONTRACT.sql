CREATE OR REPLACE VIEW {schemaname}.L5_USER_PERMISSIONS_CONTRACT AS
(SELECT perm.user_login_id,
        cont.contract_id,
        cont.contract_lv2_id,
        cont.contract_lv1_id
FROM user_permissions perm
JOIN l5_ii_map_contract cont
ON CASE WHEN UPPER(perm.attribute_name) = 'CONTRACT_LV1_ID'
THEN CAST(perm.attribute_id AS VARCHAR(100)) = cont.contract_lv1_id
WHEN UPPER(perm.attribute_name) = 'CONTRACT_LV2_ID'
THEN CAST(perm.attribute_id AS VARCHAR(100)) = cont.contract_lv2_id
WHEN UPPER(perm.attribute_name) = 'CONTRACT_ID'
THEN CAST(perm.attribute_id AS VARCHAR(100)) = cont.contract_id END);