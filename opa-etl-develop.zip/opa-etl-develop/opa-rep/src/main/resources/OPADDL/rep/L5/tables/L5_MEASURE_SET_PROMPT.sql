create table {schemaname}.L5_MEASURE_SET_PROMPT (    MEASURE_SET VARCHAR(41) encode zstd,
    TIMEFRAME_ID INTEGER,
    TIMEFRAME_DESC VARCHAR(57) encode zstd,
    DATA_END_DT TIMESTAMP encode zstd,
    MEASURE_TYPE VARCHAR(14) encode zstd,
    MEASURE_ID INTEGER not null encode zstd,
    MEASURE_DESC VARCHAR(400) encode zstd,
    SURR_ID INTEGER not null encode zstd) diststyle all sortkey(timeframe_id);