CREATE TABLE {schemaname}.L5_II_MAP_REGION (
    cens_reg INTEGER,
    cens_reg_desc VARCHAR (30) ENCODE ZSTD
) diststyle all sortkey(cens_reg);