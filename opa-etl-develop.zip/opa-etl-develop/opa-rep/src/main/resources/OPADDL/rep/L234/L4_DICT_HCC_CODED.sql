CREATE TABLE {schemaname}.L4_DICT_HCC_CODED (
	hcc_coded_desc VARCHAR (50) encode zstd,
	hcc_coded_id INTEGER
) diststyle all sortkey(hcc_coded_id);
