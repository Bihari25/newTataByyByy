CREATE TABLE {schemaname}.L3_DICT_PROV_ATTRIB_PRECUR (
    ACTIVE_IND INTEGER encode zstd,
    ELIG_PROV_ID INTEGER encode zstd,
    ELIG_SOURCE_TYPE_FLG INTEGER encode zstd,
    LOOKBACK_MONTHS INTEGER encode zstd,
    NUM_YR_MONTHS INTEGER encode zstd,
    PROC_GROUP_ID INTEGER encode zstd,
    PROV_ATTRIB_PRECURSOR_DESC VARCHAR (400) encode zstd,
    PROV_ATTRIB_PRECURSOR_ID INTEGER,
    PROV_ATTRIB_PRECURSOR_NAME VARCHAR (100) encode zstd,
    PROV_ATTRIB_PRECUR_TYPE_ID INTEGER encode zstd
) diststyle all sortkey(prov_attrib_precursor_id);
