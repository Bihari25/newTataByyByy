CREATE TABLE {schemaname}.L4_PAT_HCC_OPPORTUNITY (
	client_id VARCHAR (16) encode zstd,
	elig_cds_id INTEGER encode zstd,
	mpi VARCHAR (32),
	py_coef_sum double precision encode zstd,
	py_fully_coded_yrmonth INTEGER encode zstd,
	pytd_coded_id INTEGER encode zstd,
	pytd_coef_sum double precision encode zstd,
	score_id INTEGER encode zstd,
	ty_fully_coded_yrmonth INTEGER encode zstd,
	tytd_coded_id INTEGER encode zstd,
	tytd_coef_sum double precision encode zstd
) distkey(mpi) sortkey(mpi);
