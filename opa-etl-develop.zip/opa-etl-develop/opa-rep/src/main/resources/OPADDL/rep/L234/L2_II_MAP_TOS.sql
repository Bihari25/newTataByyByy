CREATE TABLE {schemaname}.L2_II_MAP_TOS (
	TOS1 VARCHAR (100) encode zstd,
	TOS1_ID INTEGER encode az64,
	TOS2 VARCHAR (100) encode zstd,
	TOS2_ID INTEGER,
	TOS3 VARCHAR (120) encode zstd,
	TOS3_ID INTEGER,
	TOS4 VARCHAR (255) encode zstd,
	TOS5 VARCHAR (255) encode zstd,
	TOS_I VARCHAR (255) encode zstd,
	TOS_I_4 INTEGER,
	TOS_I_5 INTEGER,
	TOS_I_SHORT VARCHAR (255) encode zstd,
	UTIL_SPEC_CAT_CD INTEGER encode az64
) diststyle all sortkey(TOS_I_5, TOS2_ID, TOS3_ID, TOS_I_4);
