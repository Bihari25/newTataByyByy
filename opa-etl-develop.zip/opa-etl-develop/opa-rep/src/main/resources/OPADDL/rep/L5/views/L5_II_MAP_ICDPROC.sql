CREATE OR REPLACE VIEW {schemaname}.L5_II_MAP_ICDPROC AS
  (SELECT icdproc,
          icdproc_desc,
          icd_version
   FROM l2_ii_map_icdproc
   UNION SELECT '0',
                'Not Supported Procedure Code'||' 0',
                9
   UNION SELECT '0',
                'Not Supported Procedure Code'||' 0',
                0
   UNION SELECT DISTINCT iproc1,
                'Not Supported Procedure Code'||' '||iproc1,
                icd_version
   FROM l5_ii_ql_conf
   WHERE iproc1||icd_version NOT IN
       (SELECT DISTINCT icdproc||icd_version
        FROM l2_ii_map_icdproc));
