CREATE TABLE {schemaname}.L2_SYSTEM_CONTRACT_DATES (
	CONTRACT_ID VARCHAR (40),
	MAX_PD_DT_INP TIMESTAMP encode zstd,
	MAX_PD_DT_MED TIMESTAMP encode zstd,
	MAX_PD_DT_RX TIMESTAMP encode zstd,
	MAX_SVC_DT_INP TIMESTAMP encode zstd,
	MAX_SVC_DT_MED TIMESTAMP encode zstd,
	MAX_SVC_DT_RX TIMESTAMP encode zstd,
	MIN_PD_DT_INP TIMESTAMP encode zstd,
	MIN_PD_DT_MED TIMESTAMP encode zstd,
	MIN_PD_DT_RX TIMESTAMP encode zstd,
	MIN_SVC_DT_INP TIMESTAMP encode zstd,
	MIN_SVC_DT_MED TIMESTAMP encode zstd,
	MIN_SVC_DT_RX TIMESTAMP encode zstd
) diststyle all sortkey(contract_id);
