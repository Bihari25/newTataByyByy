CREATE OR REPLACE VIEW {schemaname}.L5_DAYOFWEEK AS
  (SELECT 1 AS dayofweek,
          'Sunday' AS dayofweek_desc
   UNION SELECT 2 AS dayofweek,
                'Monday' AS dayofweek_desc
   UNION SELECT 3 AS dayofweek,
                'Tuesday' AS dayofweek_desc
   UNION SELECT 4 AS dayofweek,
                'Wednesday' AS dayofweek_desc
   UNION SELECT 5 AS dayofweek,
                'Thursday' AS dayofweek_desc
   UNION SELECT 6 AS dayofweek,
                'Friday' AS dayofweek_desc
   UNION SELECT 7 AS dayofweek,
                'Saturday' AS dayofweek_desc);