create table {schemaname}.L5_PATIENT_EVENT_MEASURE_HCI (    MPI VARCHAR(32),
    SURR_ID INTEGER encode zstd,
    MEASURE_ID INTEGER encode zstd,
    TIMEFRAME_ID INTEGER encode zstd,
    SENSITIVE_IND SMALLINT encode zstd,
    DENOMINATOR SMALLINT encode zstd,
    NUMERATOR SMALLINT encode zstd,
    EVENT_DT TIMESTAMP encode zstd,
    CLINICAL_EVENT_ID BIGINT encode zstd) distkey(MPI) sortkey(MPI);