create table {schemaname}.L5_DICT_PROC(
    code_type VARCHAR (10) encode zstd,
    proc_cd VARCHAR (20),
    code_name VARCHAR (100) encode zstd,
    code_desc VARCHAR (500) encode zstd,
    proc_desc VARCHAR (521) encode zstd,
    sensitive_ind SMALLINT encode zstd
) sortkey(proc_cd);
