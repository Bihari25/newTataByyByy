CREATE OR REPLACE VIEW {schemaname}.L5_MAP_SCORE_INTN_COEF AS
  (SELECT DISTINCT a12.grp_id,
                   a11.score_id,
                   a11.interaction_id,
                   a11.coef
   FROM L3_MAP_SCORE_INTN_COEF a11
   JOIN L3_MAP_SCORE_GRP a12 ON a11.score_id = a12.score_id);