CREATE OR REPLACE VIEW {schemaname}.L5_MAP_HCC_FULLYCODED_MONTH AS
  (SELECT DISTINCT month_short_name,
                   py,
                   ty
   FROM
     (SELECT DISTINCT year_id,
                      month_short_name,
                      MIN(prev_year_month_id) py,
                      MIN(month_id) ty
      FROM l5_dict_month
      GROUP BY year_id,
               month_short_name
      ORDER BY year_id));