CREATE TABLE {schemaname}.L5_II_EPI_COSTS_INDEX (
    peer_def_id         INTEGER         ENCODE ZSTD,
    provider_id         VARCHAR (20)    ENCODE ZSTD,
    ia_time             INTEGER,
    overall_cost_index  DECIMAL(38, 18) ENCODE ZSTD
)
DISTKEY(provider_id)
SORTKEY(ia_time);