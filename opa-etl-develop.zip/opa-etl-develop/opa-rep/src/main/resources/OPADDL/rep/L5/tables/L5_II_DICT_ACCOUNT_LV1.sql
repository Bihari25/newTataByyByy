create table {schemaname}.L5_II_DICT_ACCOUNT_LV1 (    ACCOUNT_LV1_ID VARCHAR(100),
    ACCOUNT_LV1_DESC VARCHAR(150) encode zstd) diststyle all sortkey(ACCOUNT_LV1_ID);
