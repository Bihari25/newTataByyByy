CREATE TABLE {schemaname}.L2_II_MAP_EBM_RULES (
	AUTHOR VARCHAR (25) encode zstd,
	ENABLED BOOLEAN encode zstd,
	EXT_FLAG INTEGER encode zstd,
	LABDATA_REQ BOOLEAN encode zstd,
	LABRESULTS_REQ BOOLEAN encode zstd,
	NQF_ENDORSED BOOLEAN encode zstd,
	NQF_SIMILAR BOOLEAN encode zstd,
	RPT_CASE_ID INTEGER,
	RPT_RULE_ID INTEGER,
	RULE_DESC VARCHAR (212) encode zstd,
	RULE_TYPE_ID INTEGER encode zstd,
	RX_REQ BOOLEAN encode zstd
) diststyle all sortkey(RPT_CASE_ID, RPT_RULE_ID);
