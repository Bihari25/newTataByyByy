CREATE OR REPLACE VIEW {schemaname}.l5_assess_timeframe AS
SELECT YEAR AS YEAR,
               (CASE
                    WHEN YEAR = 1 THEN '1 year ago'
                    WHEN YEAR = 2 THEN '1 to 2 years ago'
                    ELSE '2 to 3 years ago'
                END) AS Description
FROM
  (WITH digits as
     (SELECT 1 AS d
      UNION ALL SELECT 2 AS d
      UNION ALL SELECT 3 AS d
      UNION ALL SELECT 4 AS d
      UNION ALL SELECT 5 AS d
      UNION ALL SELECT 6 AS d
      UNION ALL SELECT 7 AS d
      UNION ALL SELECT 8 AS d
      UNION ALL SELECT 9 AS d
      UNION ALL SELECT 0 AS d),
               nums AS
     (SELECT x.d + xx.d * 10 + xxx.d * 100 + xxxx.d * 1000 + xxxxx.d * 10000 n
      FROM digits x
      CROSS JOIN digits xx
      CROSS JOIN digits xxx
      CROSS JOIN digits xxxx
      CROSS JOIN digits xxxxx) SELECT n AS YEAR
   FROM nums
   WHERE n > 0
     AND n <= 3
   ORDER BY n);