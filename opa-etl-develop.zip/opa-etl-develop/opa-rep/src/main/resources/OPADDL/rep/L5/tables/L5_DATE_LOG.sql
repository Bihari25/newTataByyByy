create table {schemaname}.L5_DATE_LOG (    DATA_THRU DATE not null encode zstd,
    CUTOFF_DATE DATE not null encode zstd,
    CUTOFF_YEAR_MTH INTEGER not null encode zstd,
    DATA_LOAD_DATE DATE not null encode zstd);