CREATE TABLE {schemaname}.L2_II_MAP_EPI_TYPE (
	COMPLETE BOOLEAN encode zstd,
	EPI_TYPE INTEGER,
	EPI_TYPE_DESC VARCHAR (40) encode zstd
) diststyle all sortkey(EPI_TYPE);