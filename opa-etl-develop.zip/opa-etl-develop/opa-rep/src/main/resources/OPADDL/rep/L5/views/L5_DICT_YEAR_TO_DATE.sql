CREATE OR REPLACE VIEW {schemaname}.L5_DICT_YEAR_TO_DATE AS
  (SELECT 1 AS year_to_date_id,
          'Yes' AS year_to_date_desc
   UNION ALL SELECT 0 AS year_to_date_id,
                    'No' AS year_to_date_desc);