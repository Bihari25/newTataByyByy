-- Created manually

--CREATE VIEW IF NOT EXISTS {{db_name}}.l4_dict_year
--AS SELECT year_id, year_id - 1 AS prev_year_id FROM {{db_name}}.t_l4_dict_day WHERE DAY( day_dt) = 1 AND MONTH( day_dt) = 1;

CREATE TABLE {schemaname}.L4_DICT_YEAR (
		year_id INTEGER,
		prev_year_id INTEGER encode zstd
) diststyle all sortkey(year_id);