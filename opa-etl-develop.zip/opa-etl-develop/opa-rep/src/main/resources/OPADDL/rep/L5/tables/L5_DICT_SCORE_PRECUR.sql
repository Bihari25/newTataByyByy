CREATE TABLE {schemaname}.L5_DICT_SCORE_PRECUR(
    grp_id INTEGER encode zstd,
    precursor_id INTEGER,
    score_id INTEGER,
    grp_precursor_desc VARCHAR(100) encode zstd
) diststyle all sortkey(score_id, precursor_id);
