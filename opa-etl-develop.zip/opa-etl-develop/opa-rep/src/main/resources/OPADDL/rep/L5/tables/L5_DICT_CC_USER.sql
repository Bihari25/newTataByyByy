create table {schemaname}.L5_DICT_CC_USER (
	USER_ID VARCHAR(255),
	USER_NM VARCHAR(200) encode zstd
) distkey(USER_ID) sortkey(USER_ID);