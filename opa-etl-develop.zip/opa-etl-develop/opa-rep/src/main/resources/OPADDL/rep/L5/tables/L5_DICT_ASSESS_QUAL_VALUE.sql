create table {schemaname}.L5_DICT_ASSESS_QUAL_VALUE (
    value_cui VARCHAR(8) encode zstd,
    value_name VARCHAR(150) encode zstd,
    assessment_cui VARCHAR(8),
    assessment_name VARCHAR(150) encode zstd,
    description VARCHAR(301) encode zstd,
    sensitive_ind SMALLINT encode zstd
) diststyle all sortkey(assessment_cui);