CREATE TABLE {schemaname}.L2_II_MAP_GBO (
	GBO INTEGER,
	GBO_DESC VARCHAR (50) encode zstd
) diststyle all sortkey(GBO);