CREATE TABLE {schemaname}.L2_II_MAP_EBM_CASES (
	EBM_COND_1 VARCHAR (50) encode zstd,
	EBM_COND_1_ID INTEGER encode zstd,
	EBM_COND_2 VARCHAR (50) encode zstd,
	EBM_COND_2_MASK VARCHAR (50) encode zstd,
	ENABLED BOOLEAN encode zstd,
	EXT_FLAG INTEGER encode zstd,
	RPT_CASE_ID INTEGER
) diststyle all sortkey(RPT_CASE_ID);
