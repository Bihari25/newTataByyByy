create table {schemaname}.L4_MAP_CUI_ETHNICITY (
		cui varchar(50),
		cui_name varchar(100) encode zstd
) diststyle all sortkey(cui);