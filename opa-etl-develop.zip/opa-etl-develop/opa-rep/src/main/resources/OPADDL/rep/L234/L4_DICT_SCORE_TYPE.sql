CREATE TABLE {schemaname}.L4_DICT_SCORE_TYPE (
	score_type_desc VARCHAR (500) encode zstd,
	score_type_display_name VARCHAR (50) encode zstd,
	score_type_id INTEGER,
	score_type_model_name VARCHAR (50) encode zstd
) diststyle all sortkey(score_type_id);
