CREATE TABLE {schemaname}.L3_MAP_SCORE_GRP (
	grp_id INTEGER,
	score_id INTEGER
) diststyle all sortkey(grp_id, score_id);
