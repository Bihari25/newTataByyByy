CREATE TABLE {schemaname}.L5_II_MAP_ETG (
  ETG_ID integer,
  ETG_IMPACT varchar(8) encode zstd,
  ETG_IMPACT_DESC varchar(150) encode zstd,
  FAMILY integer encode zstd,
  MPC integer encode zstd,
  CHRONIC smallint encode zstd,
  TX_IND smallint encode zstd
) DISTSTYLE ALL SORTKEY(ETG_ID);