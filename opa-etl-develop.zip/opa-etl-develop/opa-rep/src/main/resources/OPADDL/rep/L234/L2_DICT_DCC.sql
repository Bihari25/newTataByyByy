CREATE TABLE {schemaname}.L2_DICT_DCC (
	dcc VARCHAR (5),
	dcc_name VARCHAR (150) encode zstd,
	pcc VARCHAR (3),
	pcc_name VARCHAR (150) encode zstd,
	sensitive_ind INTEGER encode zstd,
	specialty_ind INTEGER encode zstd,
	tcc VARCHAR (2),
	tcc_name VARCHAR (150) encode zstd,
	vaccine_ind INTEGER encode zstd,
	harmful_geriatric_med INTEGER encode zstd -- added manually from oadw_schema_manual
) diststyle all sortkey(dcc, pcc, tcc);