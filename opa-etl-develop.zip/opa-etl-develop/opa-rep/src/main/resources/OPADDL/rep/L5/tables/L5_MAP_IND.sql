create table {schemaname}.L5_MAP_IND (
    IND_ID SMALLINT,
    IND_CD VARCHAR (1) encode zstd,
    IND_DESC VARCHAR (3) encode zstd
) diststyle all sortkey(IND_ID);