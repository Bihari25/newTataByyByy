CREATE TABLE {schemaname}.L2_II_MAP_DRG_TYPE (
	DRG_ADMITTYP VARCHAR (3),
	DRG_ADMIT_LV1 VARCHAR (9) encode zstd,
	DRG_TYPE_DESC VARCHAR (79) encode zstd
) diststyle all sortkey(DRG_ADMITTYP);