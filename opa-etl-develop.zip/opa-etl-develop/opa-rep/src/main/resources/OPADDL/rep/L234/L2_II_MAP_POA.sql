CREATE TABLE {schemaname}.L2_II_MAP_POA (
	POA VARCHAR (1),
	POA_DESC VARCHAR (25) encode zstd
) diststyle all sortkey(POA);
