create table {schemaname}.L5_II_MAP_NDC (
    NDC VARCHAR(11),
    NDC_DESC VARCHAR(50) encode zstd,
    BRAND_NAME VARCHAR(50),
    BRAND_NAME_MASK VARCHAR(50) encode zstd,
    DCC VARCHAR(5),
    SENSITIVE_IND SMALLINT encode zstd
) distkey(NDC) sortkey(DCC, BRAND_NAME, NDC);
