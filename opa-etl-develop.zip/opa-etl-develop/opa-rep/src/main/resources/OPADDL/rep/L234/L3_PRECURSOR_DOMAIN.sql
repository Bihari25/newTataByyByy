CREATE TABLE {schemaname}.L3_PRECURSOR_DOMAIN (
	precursor_domain_cd VARCHAR (16),
	precursor_domain_desc VARCHAR (100) encode zstd,
	precursor_domain_flg INTEGER encode zstd
) diststyle all sortkey(precursor_domain_cd);
