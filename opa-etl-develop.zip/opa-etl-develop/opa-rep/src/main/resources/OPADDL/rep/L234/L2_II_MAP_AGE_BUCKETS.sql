-- Created manually
--
-- CREATE VIEW IF NOT EXISTS {{db_name}}.l2_ii_map_age_buckets AS
-- SELECT DISTINCT age_cat2, age_lab2 FROM {{db_name}}.t_l2_ii_map_age;

CREATE TABLE {schemaname}.l2_ii_map_age_buckets (
  age_cat2 INTEGER,
  age_lab2 varchar(5) encode zstd
) diststyle all sortkey(age_cat2);
