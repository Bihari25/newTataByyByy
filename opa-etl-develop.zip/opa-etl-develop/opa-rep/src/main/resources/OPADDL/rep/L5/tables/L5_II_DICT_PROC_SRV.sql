create table {schemaname}.L5_II_DICT_PROC_SRV (
    PROC_SRV VARCHAR(15),
    PROC_SRV_DESC VARCHAR(200) encode zstd
) diststyle all sortkey(proc_srv);