CREATE TABLE {schemaname}.L2_PAT_ACTIVITY_SUMMARY (
    all_act_type_flg INTEGER encode zstd,
	cds_grp VARCHAR (4000) encode zstd,
	class_1_ind INTEGER encode zstd,
	class_2_ind INTEGER encode zstd,
	class_3_ind INTEGER,
	client_id VARCHAR (16) encode zstd,
	mpi VARCHAR (32)
) distkey(MPI) sortkey(mpi,class_3_ind);
