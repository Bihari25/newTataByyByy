CREATE TABLE {schemaname}.L2_II_MAP_INDUSTRY (
	INDUSTRY INTEGER,
	INDUSTRY_DESC VARCHAR (50) encode zstd
) diststyle all sortkey(INDUSTRY);