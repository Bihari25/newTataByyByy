CREATE TABLE {schemaname}.L2_II_MAP_CHANNEL (
	CHANNEL INTEGER,
	CHANNEL_DESC VARCHAR (25) encode zstd
) diststyle all sortkey(CHANNEL);