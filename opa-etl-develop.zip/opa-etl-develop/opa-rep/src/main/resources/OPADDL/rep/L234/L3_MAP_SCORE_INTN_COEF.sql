CREATE TABLE {schemaname}.L3_MAP_SCORE_INTN_COEF (
	coef double precision encode zstd,
	interaction_id INTEGER,
	score_id INTEGER
) diststyle all sortkey(score_id, interaction_id);
