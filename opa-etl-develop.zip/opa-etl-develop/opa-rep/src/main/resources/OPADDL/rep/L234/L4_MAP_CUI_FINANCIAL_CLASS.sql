create table {schemaname}.L4_MAP_CUI_FINANCIAL_CLASS (
		cui varchar(50),
		cui_name varchar(100) encode zstd
) diststyle all sortkey(cui);