create table {schemaname}.L5_DICT_TOS1 (    SORT_ORDER SMALLINT not null encode az64,
    TOS1_ID INTEGER not null,
    TOS1 VARCHAR(255) not null encode zstd,
    TOS1_IMAGE VARCHAR(100) not null encode zstd
) diststyle all sortkey(TOS1_ID);