create table {schemaname}.L5_REL_READMIT_CONF (
    CONF_NUM BIGINT,
    READMIT_CONF_NUM BIGINT encode zstd,
    READMISSION_TYPE SMALLINT encode zstd
) DISTKEY (conf_num) SORTKEY(readmission_type, conf_num);