CREATE TABLE {schemaname}.l5_pat_score_sre (
    client_id           VARCHAR(16)      ENCODE zstd,
    mpi                 VARCHAR(32)      ENCODE zstd,
    score_id            INTEGER,
    timeframe_id        INTEGER,
    elig_cds_id         INTEGER          ENCODE zstd,
    score               DOUBLE PRECISION ENCODE zstd,
    score_default_flg   INTEGER          ENCODE zstd,
    surr_id             INTEGER          ENCODE zstd,
    score_qual_id       INTEGER          ENCODE zstd
)
DISTKEY (mpi)
SORTKEY (score_id, timeframe_id);
