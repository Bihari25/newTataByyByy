CREATE TABLE {schemaname}.L2_II_MAP_MEM_USERDEF_2 (
	MAP_SRCE_E VARCHAR (6) encode zstd,
	MEM_USERDEF_2 VARCHAR (30) encode zstd,
	MEM_USERDEF_2_DESC VARCHAR (150) encode zstd,
	MEM_USERDEF_2_ID VARCHAR (40),
	RIFLAG INTEGER encode zstd
) diststyle all sortkey(MEM_USERDEF_2_ID);