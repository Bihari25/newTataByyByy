CREATE TABLE {schemaname}.L5_DICT_MEASURE (
    MEASURE_ID INTEGER,
    MEASURE_SET VARCHAR (20) encode zstd,
    MEASURE_TYPE VARCHAR (14) encode zstd,
    MEASURE_CD VARCHAR (20) encode zstd,
    MEASURE_VERS VARCHAR (20) encode zstd,
    MEASURE_STEWARD VARCHAR (100) encode zstd,
    MEASURE_DESC VARCHAR (400) encode zstd,
    MEASURE_RANK INTEGER encode zstd,
    SENSITIVE_IND INTEGER encode zstd,
    ACTIVE_IND INTEGER encode zstd,
    TYPICAL_IND INTEGER encode zstd
) diststyle all sortkey(MEASURE_ID);