CREATE TABLE {schemaname}.L2_OCU_MEMBER (
	NEW_MEM_ATTR_ID INTEGER encode zstd,
	age_cat2 INTEGER encode zstd,
	cat_status_cost3 INTEGER encode zstd,
	contract_id VARCHAR (40) encode zstd,
	ia_time INTEGER encode zstd,
	mem_userdef_1_id VARCHAR (40) encode zstd,
	at_risk_status_id VARCHAR(255), --added manually from oadw_schema_manual.hql
	mm DECIMAL (38, 10) encode zstd,
	mm_rx DECIMAL (38, 10) encode zstd,
	pcp_assign VARCHAR (20) encode zstd,
	product_id VARCHAR (40) encode zstd,
	retrorisk DECIMAL (34, 4) encode zstd,
	sex INTEGER encode zstd,
	year_mth_id INTEGER,
	zip VARCHAR (5) encode zstd) sortkey(year_mth_id, at_risk_status_id);
