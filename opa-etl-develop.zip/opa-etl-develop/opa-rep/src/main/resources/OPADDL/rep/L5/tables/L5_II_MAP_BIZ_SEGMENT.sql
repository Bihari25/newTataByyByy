create table {schemaname}.L5_II_MAP_BIZ_SEGMENT (    BIZ_SEGMENT_ID VARCHAR(40) not null ,
    BIZ_SEGMENT VARCHAR(30) not null encode zstd,
    BIZ_SEGMENT_DESC VARCHAR(150) not null encode zstd,
    BIZ_SEGMENT_LV2_ID VARCHAR(100),
    BIZ_SEGMENT_LV2 VARCHAR(30) encode zstd,
    BIZ_SEGMENT_LV2_DESC VARCHAR(150) encode zstd,
    BIZ_SEGMENT_LV1_ID VARCHAR(100),
    BIZ_SEGMENT_LV1 VARCHAR(30) encode zstd,
    BIZ_SEGMENT_LV1_DESC VARCHAR(150) encode zstd,
    MAP_SRCE_E VARCHAR(6) encode zstd,
    RIFLAG SMALLINT encode zstd,
    BIZ_SEGMENT_NUM_ID INTEGER not null encode zstd
) diststyle all sortkey(BIZ_SEGMENT_ID,BIZ_SEGMENT_LV2_ID,BIZ_SEGMENT_LV1_ID);