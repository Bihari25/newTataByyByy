create table {schemaname}.L5_DICT_INCOME_BAND (
    INC_BAND_ID SMALLINT,
    INC_BAND_DESC VARCHAR(25) encode zstd,
    INC_BAND_MIN INTEGER encode zstd,
    INC_BAND_MAX INTEGER encode zstd
) diststyle all sortkey(inc_band_id);