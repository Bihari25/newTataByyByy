CREATE TABLE {schemaname}.L3_PAT_TIMEFRAME_AGE (
	born_during_ind INTEGER encode zstd,
	client_id VARCHAR (16) encode zstd,
	died_during_ind INTEGER encode zstd,
	end_age INTEGER encode zstd,
	mpi VARCHAR (32),
	start_age INTEGER encode zstd,
	timeframe_id INTEGER encode zstd
) distkey(MPI) sortkey(MPI);
