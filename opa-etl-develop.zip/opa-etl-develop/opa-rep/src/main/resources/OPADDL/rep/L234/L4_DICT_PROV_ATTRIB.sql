CREATE TABLE {schemaname}.L4_DICT_PROV_ATTRIB (
    ACTIVE_IND INTEGER encode zstd,
    FOR_EACH_CDS_IND INTEGER encode zstd,
    NUM_YR_MONTHS INTEGER encode zstd,
    PRECALC_IND INTEGER encode zstd,
    PROV_ATTRIB_DESC VARCHAR (400) encode zstd,
    PROV_ATTRIB_FAMILY_ID INTEGER encode zstd,
    PROV_ATTRIB_ID INTEGER,
    PROV_ATTRIB_NAME VARCHAR (100) encode zstd
) diststyle all sortkey(prov_attrib_id);
