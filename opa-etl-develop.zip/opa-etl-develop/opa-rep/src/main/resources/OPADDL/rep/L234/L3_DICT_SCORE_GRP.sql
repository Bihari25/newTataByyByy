CREATE TABLE {schemaname}.L3_DICT_SCORE_GRP (
	diag_timeframe_restriction_ind INTEGER encode zstd,
	grp_id INTEGER,
	grp_name VARCHAR (50) encode zstd
) diststyle all sortkey(grp_id);
