create table {schemaname}.L5_DICT_HCC_STATUS (
	tytd_coded_id INTEGER,
	hcc_coded_desc VARCHAR (50) encode zstd
) diststyle all sortkey(tytd_coded_id);