CREATE TABLE {schemaname}.L2_II_MAP_PCC (
	PCC VARCHAR (3),
	PCC_DESC VARCHAR (120) encode zstd,
	TCC VARCHAR (2)
) diststyle all sortkey(TCC, PCC);
