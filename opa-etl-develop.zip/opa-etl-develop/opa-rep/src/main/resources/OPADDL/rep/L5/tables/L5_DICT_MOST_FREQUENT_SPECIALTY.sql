create table {schemaname}.L5_DICT_MOST_FREQUENT_SPECIALTY (
	PROV_ATTRIB_ID BIGINT,
	SPECIALTY_ID varchar(3),
	SP4 varchar(255) ENCODE zstd
) diststyle all sortkey(PROV_ATTRIB_ID, SPECIALTY_ID);