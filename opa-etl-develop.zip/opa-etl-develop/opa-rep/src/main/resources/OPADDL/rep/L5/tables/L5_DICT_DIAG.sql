CREATE TABLE {schemaname}.L5_DICT_DIAG (
	code_desc VARCHAR (500) encode zstd,
	code_name VARCHAR (100) encode zstd,
	code_type VARCHAR (10) encode zstd,
	diag_cd VARCHAR (20),
	sensitive_ind SMALLINT encode zstd
) diststyle all sortkey(diag_cd);
