CREATE TABLE {schemaname}.L5_DICT_MONTH (
    year_mth_id SMALLINT encode zstd,
	month_id INTEGER,
	month_name VARCHAR(9) encode zstd,
	month_short_name VARCHAR(3) encode zstd,
	month_year_name VARCHAR(14) encode zstd,
	month_year_short_name VARCHAR(8) encode zstd,
	quarter_id INTEGER encode zstd,
	year_id SMALLINT encode zstd,
	prev_month_id INTEGER encode zstd,
	prev_quarter_month_id INTEGER encode zstd,
	prev_year_month_id INTEGER encode zstd,
	prior_year_mth_id SMALLINT encode zstd
) diststyle all sortkey(month_id);
