CREATE TABLE {schemaname}.L2_II_MAP_PQI (
	PQI INTEGER,
	PQI_DESC VARCHAR (100) encode zstd
) diststyle all sortkey(PQI);
