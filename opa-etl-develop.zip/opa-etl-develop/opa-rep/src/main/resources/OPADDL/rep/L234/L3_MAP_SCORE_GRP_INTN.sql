CREATE TABLE {schemaname}.L3_MAP_SCORE_GRP_INTN (
	age_interaction_ind INTEGER encode zstd,
	age_range_max INTEGER encode zstd,
	age_range_min INTEGER encode zstd,
	grp_id INTEGER,
	grp_interaction_desc VARCHAR (200) encode zstd,
	grp_interaction_name VARCHAR (50) encode zstd,
	interaction_id INTEGER
) diststyle all sortkey(grp_id, interaction_id);
