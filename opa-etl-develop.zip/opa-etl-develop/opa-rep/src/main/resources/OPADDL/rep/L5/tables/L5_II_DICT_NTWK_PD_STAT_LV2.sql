create table {schemaname}.L5_II_DICT_NTWK_PD_STAT_LV2 (
    NETWORK_PAID_STATUS_LV2_ID VARCHAR(100),
    NETWORK_PAID_STATUS_LV2_DESC VARCHAR(150) encode zstd,
    NETWORK_PAID_STATUS_LV1_ID VARCHAR(100) encode zstd
) diststyle all sortkey(network_paid_status_lv2_id);