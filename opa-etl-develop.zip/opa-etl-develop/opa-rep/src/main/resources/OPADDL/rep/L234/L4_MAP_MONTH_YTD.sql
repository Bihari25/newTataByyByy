-- Created manually
-- CREATE VIEW IF NOT EXISTS {{db_name}}.l4_map_month_ytd
-- AS SELECT cur.month_id, ytd.month_id AS ytd_month_id FROM {{db_name}}.l4_dict_month cur JOIN {{db_name}}.l4_dict_month ytd WHERE ytd.month_id <= cur.month_id AND ytd.year_id = cur.year_id;;

CREATE TABLE {schemaname}.L4_MAP_MONTH_YTD (
  month_id INTEGER,
  ytd_month_id INTEGER encode zstd
) diststyle all sortkey(month_id);
