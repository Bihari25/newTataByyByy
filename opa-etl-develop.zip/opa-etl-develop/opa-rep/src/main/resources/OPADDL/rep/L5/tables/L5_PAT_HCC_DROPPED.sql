CREATE TABLE {schemaname}.L5_PAT_HCC_DROPPED (
	client_id VARCHAR (16) encode zstd,
	mpi VARCHAR (32),
	score_id INTEGER encode zstd,
	source_timeframe_id INTEGER encode zstd,
	destination_timeframe_id INTEGER encode zstd,
	elig_cds_id INTEGER encode zstd,
	dropped_precursor_id INTEGER encode zstd,
	max_dt TIMESTAMP encode zstd,
	latest_type VARCHAR (20) encode zstd,
	latest_value VARCHAR (50) encode zstd,
	cds_grp VARCHAR (4000) encode zstd,
	sensitive_ind SMALLINT encode zstd
) distkey(MPI) sortkey(MPI);
