create table {schemaname}.L5_BENCHMK_POP_DENOM_DTL (    YEAR SMALLINT,
    CENS_REG SMALLINT encode zstd,
    AGE_CAT2 SMALLINT encode zstd,
    SEX SMALLINT encode zstd,
    MM DECIMAL(19, 2) encode zstd,
    MM_RX DECIMAL(19, 2) encode zstd,
    RRISK DECIMAL(12, 4) encode zstd,
    TOT_AGE INTEGER encode zstd,
    DUMMY_EMAIL VARCHAR(1) encode zstd
) diststyle all sortkey(YEAR);