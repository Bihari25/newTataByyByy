CREATE TABLE {schemaname}.L2_II_MAP_DAW (
	daw INT,
	daw_desc VARCHAR (75) encode zstd
) diststyle all sortkey(daw);
