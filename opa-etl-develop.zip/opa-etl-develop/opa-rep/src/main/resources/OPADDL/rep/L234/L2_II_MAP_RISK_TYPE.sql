CREATE TABLE {schemaname}.L2_II_MAP_RISK_TYPE (
	map_srce_e VARCHAR (6) encode zstd,
	riflag INT encode zstd,
	risk_type VARCHAR (30) encode zstd,
	risk_type_desc VARCHAR (150) encode zstd,
	risk_type_id VARCHAR (40),
	risk_type_lv1 VARCHAR (30) encode zstd,
	risk_type_lv1_desc VARCHAR (150) encode zstd,
	risk_type_lv1_id VARCHAR (100),
	risk_type_lv2 VARCHAR (30) encode zstd,
	risk_type_lv2_desc VARCHAR (150) encode zstd,
	risk_type_lv2_id VARCHAR (100)
) diststyle all sortkey(risk_type_id, risk_type_lv2_id, risk_type_lv1_id);
