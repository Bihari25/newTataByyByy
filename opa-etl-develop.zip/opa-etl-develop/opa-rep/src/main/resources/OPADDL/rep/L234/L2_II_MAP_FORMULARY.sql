CREATE TABLE {schemaname}.L2_II_MAP_FORMULARY (
	FORMULARY INTEGER,
	FORMULARY_DESC VARCHAR (25) encode zstd
) diststyle all sortkey(FORMULARY);
