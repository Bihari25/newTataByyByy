CREATE TABLE {schemaname}.L5_MAP_SCORE_PRECUR(
    grp_id INTEGER ENCODE ZSTD,
    score_family_id INTEGER ENCODE ZSTD,
    score_id INTEGER,
    grp_precursor_desc VARCHAR(100) ENCODE ZSTD,
    precursor_id INTEGER,
    coef DOUBLE PRECISION ENCODE ZSTD,
    coef_mult_is_1_ind INTEGER ENCODE ZSTD,
    sensitive_ind SMALLINT ENCODE ZSTD
) sortkey(score_id, precursor_id);
