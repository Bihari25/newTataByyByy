CREATE TABLE {schemaname}.L3_MAP_SCORE_AGEGENDER_COEF (
	age_range_max INTEGER encode zstd,
	age_range_min INTEGER encode zstd,
	coef double precision encode zstd,
	coef_multiplier double precision encode zstd,
	gender VARCHAR (8),
	score_id INTEGER
) diststyle all sortkey (score_id, gender);
