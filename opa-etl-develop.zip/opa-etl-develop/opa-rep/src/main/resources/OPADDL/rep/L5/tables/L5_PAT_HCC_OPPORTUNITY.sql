CREATE TABLE {schemaname}.L5_PAT_HCC_OPPORTUNITY (
	mpi VARCHAR (32) encode zstd,
	elig_cds_id INTEGER,
	py_coef_sum DOUBLE PRECISION encode zstd,
	tytd_coef_sum DOUBLE PRECISION encode zstd,
	coef_opportunity DOUBLE PRECISION encode zstd,
	tytd_coded_id INTEGER,
	hcc_coded_desc VARCHAR (50) encode zstd,
	patient_dropped_flag VARCHAR (1),
	ty_fully_coded_yrmonth INTEGER
) distkey(MPI) sortkey(patient_dropped_flag, elig_cds_id, tytd_coded_id, ty_fully_coded_yrmonth);