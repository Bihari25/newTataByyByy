create table {schemaname}.L5_DICT_MOST_FREQUENT_PROVIDER (
	PROV_ATTRIB_ID BIGINT,
    PROV_ID VARCHAR(20) not null,
    PROVIDER_NAME VARCHAR(255) encode zstd
) diststyle all sortkey(PROV_ATTRIB_ID, PROV_ID);