CREATE OR REPLACE VIEW {schemaname}.L5_DICT_TOS3 AS
  (SELECT DISTINCT tos3_id,
                   tos3
   FROM l2_ii_map_tos);