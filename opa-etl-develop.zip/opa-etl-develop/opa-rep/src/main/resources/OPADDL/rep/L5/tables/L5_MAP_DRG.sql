CREATE TABLE {schemaname}.L5_MAP_DRG (
    drg_id INTEGER,
    drg_type_cui VARCHAR (8) encode zstd,
    drg_cd VARCHAR (4) encode zstd,
    drg_description VARCHAR (249) encode zstd,
    drg_long_desc VARCHAR (254),
	drg_weight double precision encode zstd,
	drg_gelos double precision encode zstd,
	drg_alos double precision encode zstd,
	sensitive_ind SMALLINT encode zstd
) diststyle all sortkey(drg_id);
