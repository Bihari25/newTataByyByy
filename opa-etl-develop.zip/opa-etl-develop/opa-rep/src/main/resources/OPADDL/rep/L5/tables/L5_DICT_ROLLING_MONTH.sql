CREATE TABLE {schemaname}.L5_DICT_ROLLING_MONTH (
month_id INTEGER,
roll_month_id INTEGER encode zstd,
year_mth_id SMALLINT encode zstd,
roll_year_mth_id SMALLINT encode zstd
) diststyle all sortkey(month_id);