CREATE TABLE {schemaname}.L5_II_MAP_ETG_FAMILY (
	FAMILY INTEGER,
	FAMILY_DESC VARCHAR (80) encode zstd,
	FAMILY_DESC_MASK VARCHAR (80) encode zstd
) diststyle all sortkey(FAMILY);