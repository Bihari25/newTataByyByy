CREATE TABLE {schemaname}.l5_dict_facility_type
(
	facility_type_id INTEGER,
	facility_type_name VARCHAR(40) encode zstd
)
DISTSTYLE ALL
SORTKEY (facility_type_id);