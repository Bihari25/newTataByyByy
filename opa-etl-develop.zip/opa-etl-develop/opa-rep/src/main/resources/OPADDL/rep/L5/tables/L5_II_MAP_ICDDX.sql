create table {schemaname}.L5_II_MAP_ICDDX (    ICDDX VARCHAR(1020),
    ICDDX_DESC VARCHAR(1108) encode zstd,
    ICD_VERSION INTEGER
) diststyle all sortkey (ICDDX, ICD_VERSION);