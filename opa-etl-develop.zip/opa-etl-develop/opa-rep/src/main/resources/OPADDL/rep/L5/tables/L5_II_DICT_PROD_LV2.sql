create table {schemaname}.L5_II_DICT_PROD_LV2 (
    PRODUCT_LV2_ID VARCHAR(100),
    PRODUCT_LV2_DESC VARCHAR(150) encode zstd
) diststyle all sortkey(product_lv2_id);