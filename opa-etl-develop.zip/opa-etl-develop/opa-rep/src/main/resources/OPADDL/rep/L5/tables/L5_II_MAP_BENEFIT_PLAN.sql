create table {schemaname}.L5_II_MAP_BENEFIT_PLAN (    BENEFIT_PLAN_ID VARCHAR(40) not null ,
    BENEFIT_PLAN VARCHAR(30) not null encode zstd,
    BENEFIT_PLAN_DESC VARCHAR(150) not null encode zstd,
    BENEFIT_PLAN_LV2_ID VARCHAR(100),
    BENEFIT_PLAN_LV2 VARCHAR(30) encode zstd,
    BENEFIT_PLAN_LV2_DESC VARCHAR(150) encode zstd,
    BENEFIT_PLAN_LV1_ID VARCHAR(100),
    BENEFIT_PLAN_LV1 VARCHAR(30) encode zstd,
    BENEFIT_PLAN_LV1_DESC VARCHAR(150) encode zstd,
    MAP_SRCE_E VARCHAR(6) encode zstd,
    RIFLAG SMALLINT encode zstd
) diststyle all sortkey(BENEFIT_PLAN_ID,BENEFIT_PLAN_LV2_ID,BENEFIT_PLAN_LV1_ID);