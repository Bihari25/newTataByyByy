CREATE TABLE {schemaname}.L4_MAP_CUI_LANGUAGE (
cui VARCHAR(50),
cui_name VARCHAR(100) encode zstd
) diststyle all sortkey(cui);