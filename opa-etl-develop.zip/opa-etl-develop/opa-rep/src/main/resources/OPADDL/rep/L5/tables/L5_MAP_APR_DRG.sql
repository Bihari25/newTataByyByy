create table {schemaname}.L5_MAP_APR_DRG (
    apr_drg_id INTEGER,
    apr_drg_cd VARCHAR (4)   encode zstd,
    apr_drg_description VARCHAR (249) encode zstd,
    apr_drg_long_desc VARCHAR (254) encode zstd,
    apr_drg_sev INTEGER encode zstd,
    apr_drg_risk INTEGER encode zstd,
    sensitive_ind SMALLINT encode zstd
) diststyle all sortkey(apr_drg_id);