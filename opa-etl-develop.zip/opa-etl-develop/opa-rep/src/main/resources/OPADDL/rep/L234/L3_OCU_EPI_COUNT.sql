CREATE TABLE {schemaname}.L3_OCU_EPI_COUNT (
	NEW_MEM_ATTR_ID BIGINT encode zstd,
	complete INTEGER encode zstd,
	epi_qty DECIMAL (38, 10) encode zstd,
	etg_id BIGINT encode zstd,
	ia_time INTEGER encode zstd,
	outlier INTEGER encode zstd,
	sev_level INTEGER encode zstd,
	tx_ind INTEGER encode zstd,
	year_mth_id INTEGER
) sortkey(year_mth_id);
