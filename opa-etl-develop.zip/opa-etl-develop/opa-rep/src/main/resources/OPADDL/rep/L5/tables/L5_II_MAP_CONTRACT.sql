create table {schemaname}.L5_II_MAP_CONTRACT (    
    CONTRACT_ID VARCHAR(40) not null,
    CONTRACT VARCHAR(30) not null encode zstd,
    CONTRACT_DESC VARCHAR(150) encode zstd,
    CONTRACT_LV2_ID VARCHAR(100),
    CONTRACT_LV2 VARCHAR(30) encode zstd,
    CONTRACT_LV2_DESC VARCHAR(150) encode zstd,
    CONTRACT_LV1_ID VARCHAR(100),
    CONTRACT_LV1 VARCHAR(30) encode zstd,
    CONTRACT_LV1_DESC VARCHAR(150) encode zstd,
    CONTRACT_HIER SMALLINT not null encode az64,
    MAP_SRCE_E VARCHAR(6) encode zstd,
    RIFLAG SMALLINT encode az64,
    CLIENT_DS_ID INTEGER encode az64
) diststyle all sortkey (CONTRACT_LV1_ID,CONTRACT_LV2_ID,CONTRACT_ID);
