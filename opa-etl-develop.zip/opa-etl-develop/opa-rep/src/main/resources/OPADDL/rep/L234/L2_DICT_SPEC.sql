CREATE TABLE {schemaname}.L2_DICT_SPEC (
    PRV_SP_4 integer,
    SP1 varchar(255) ENCODE zstd,
    SP1_ID integer ENCODE az64,
    SP2 varchar(255) ENCODE zstd,
    SP2_ID integer ENCODE az64,
    SP3 varchar(255) ENCODE zstd,
    SP3_ID integer,
    SP4 varchar(255) ENCODE zstd,
    SPECIALTY_ID varchar(3) ENCODE zstd
)  diststyle all sortkey(SP3_ID, PRV_SP_4);
