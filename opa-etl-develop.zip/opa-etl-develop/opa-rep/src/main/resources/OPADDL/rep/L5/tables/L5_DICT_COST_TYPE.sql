CREATE TABLE {schemaname}.l5_dict_cost_type (
	cost_type_id SMALLINT,
	cost_type VARCHAR(17)  encode zstd,
	cost_type_desc VARCHAR(14)  encode zstd
) DISTSTYLE ALL SORTKEY (cost_type_id);
