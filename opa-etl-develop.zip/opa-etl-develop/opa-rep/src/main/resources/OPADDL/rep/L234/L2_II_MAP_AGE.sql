CREATE TABLE {schemaname}.L2_II_MAP_AGE (
	AGE INTEGER,
	AGE_CAT1 INTEGER encode zstd,
	AGE_CAT2 INTEGER encode zstd,
	AGE_LAB1 VARCHAR (5) encode zstd,
	AGE_LAB2 VARCHAR (5) encode zstd
) diststyle all sortkey(age);
