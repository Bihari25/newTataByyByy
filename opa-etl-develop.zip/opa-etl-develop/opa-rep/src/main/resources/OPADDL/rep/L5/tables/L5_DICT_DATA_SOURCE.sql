create table {schemaname}.L5_DICT_DATA_SOURCE (
    client_ds_id BIGINT,
    client_ds_name VARCHAR(100) encode zstd
) diststyle all sortkey(client_ds_id);