create table {schemaname}.L5_MAP_ALL_CDS_GRP (
    cds_grp VARCHAR(4000) encode zstd,
    cds_grp_desc VARCHAR(4000) encode zstd,
    client_ds_id BIGINT,
    client_ds_name VARCHAR(100) encode zstd
) sortkey(client_ds_id);