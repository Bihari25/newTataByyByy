create table {schemaname}.L5_II_MAP_AT_RISK_STATUS (    MAP_SRCE_E VARCHAR(6) encode zstd,
    AT_RISK_STATUS_ID VARCHAR(40) not null,
    AT_RISK_STATUS VARCHAR(30) not null encode zstd,
    AT_RISK_STATUS_DESC VARCHAR(150) not null encode zstd,
    AT_RISK_STATUS_LV1_ID VARCHAR(100),
    AT_RISK_STATUS_LV1 VARCHAR(30) encode zstd,
    AT_RISK_STATUS_LV1_DESC VARCHAR(150) encode zstd,
    AT_RISK_STATUS_LV2_ID VARCHAR(100),
    AT_RISK_STATUS_LV2 VARCHAR(30) encode zstd,
    AT_RISK_STATUS_LV2_DESC VARCHAR(150) encode zstd,
    RIFLAG SMALLINT encode az64
) diststyle all sortkey (AT_RISK_STATUS_ID, AT_RISK_STATUS_LV2_ID, AT_RISK_STATUS_LV1_ID);