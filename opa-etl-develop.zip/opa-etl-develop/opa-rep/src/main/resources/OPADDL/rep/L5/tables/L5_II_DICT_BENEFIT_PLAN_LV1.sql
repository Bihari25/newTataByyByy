create table {schemaname}.L5_II_DICT_BENEFIT_PLAN_LV1 (    BENEFIT_PLAN_LV1_ID VARCHAR(100),
    BENEFIT_PLAN_LV1_DESC VARCHAR(200) encode zstd
) diststyle all sortkey(BENEFIT_PLAN_LV1_ID);