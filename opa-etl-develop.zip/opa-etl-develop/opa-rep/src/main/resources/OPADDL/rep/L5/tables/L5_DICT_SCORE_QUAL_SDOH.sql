CREATE TABLE {schemaname}.l5_dict_score_qual_sdoh (
    score_qual_id     INTEGER          ,
    score_qual_name   VARCHAR(200)     ENCODE zstd,
    score_qual_desc   VARCHAR(400)     ENCODE zstd
)
diststyle all
SORTKEY (score_qual_id);
