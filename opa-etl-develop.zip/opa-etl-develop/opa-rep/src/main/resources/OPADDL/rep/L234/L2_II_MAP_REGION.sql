CREATE TABLE {schemaname}.L2_II_MAP_REGION (
	CENS_REG INTEGER,
	CENS_REG_DESC VARCHAR (30) encode zstd,
	COUNTY_DESC VARCHAR (40) encode zstd,
	COUNTY_ID INTEGER encode zstd,
	STATE INTEGER encode zstd,
	STATE_DESC VARCHAR (2) encode zstd,
	ZIP VARCHAR (5) encode zstd,
	MSA VARCHAR (35) encode zstd
) sortkey(CENS_REG);
