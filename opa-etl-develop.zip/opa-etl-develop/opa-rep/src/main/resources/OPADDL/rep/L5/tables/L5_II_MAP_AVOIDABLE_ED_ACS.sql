CREATE TABLE {schemaname}.L5_II_MAP_AVOIDABLE_ED_ACS (
	AVOIDABLE_ED_ACS_ID     SMALLINT,
	AVOIDABLE_ED_ACS_DESC   VARCHAR (30)   encode zstd
)diststyle all sortkey(avoidable_ed_acs_id);
