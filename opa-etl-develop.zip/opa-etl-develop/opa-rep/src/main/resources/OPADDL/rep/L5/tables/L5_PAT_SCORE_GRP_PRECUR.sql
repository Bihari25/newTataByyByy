CREATE TABLE {schemaname}.L5_PAT_SCORE_GRP_PRECUR (
	client_id VARCHAR (16) encode zstd,
	mpi VARCHAR (32) encode zstd,
	grp_id INTEGER encode zstd,
	timeframe_id INTEGER,
	elig_cds_id INTEGER encode zstd,
	precursor_id INTEGER encode zstd,
	precursor_min_dt TIMESTAMP encode zstd,
	precursor_max_dt TIMESTAMP encode zstd,
	precursor_domain VARCHAR (16) encode zstd,
	precursor_type VARCHAR (20) encode zstd,
	precursor_value VARCHAR (50) encode zstd,
	precursor_cds_grp VARCHAR (4000) encode zstd,
	sensitive_ind SMALLINT encode zstd
) distkey(MPI) sortkey(timeframe_id);
