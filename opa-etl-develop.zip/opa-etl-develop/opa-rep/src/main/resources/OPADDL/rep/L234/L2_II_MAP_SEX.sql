CREATE TABLE {schemaname}.L2_II_MAP_SEX (
	SEX BOOLEAN,
	SEX_DESC VARCHAR (1) encode zstd
) diststyle all sortkey(SEX);