CREATE TABLE {schemaname}.L2_II_MAP_PEER_CAT1 (
	PEER_CAT1_DESC VARCHAR (50) encode zstd,
	PEER_CAT1_ID INTEGER
) diststyle all sortkey(PEER_CAT1_ID);
