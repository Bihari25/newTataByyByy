create table {schemaname}.L5_II_MAP_PEG_LATERALITY (
    LATERALITY VARCHAR(1),
    LATERALITY_DESC VARCHAR(100) encode zstd,
    PEG_UNIT_LATERALITY VARCHAR(1) encode zstd
) diststyle all sortkey (LATERALITY);
