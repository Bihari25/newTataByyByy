create table {schemaname}.L5_II_MAP_MEM_USERDEF_4 (
    MAP_SRCE_E	            VARCHAR (6)	    encode zstd,
    MEM_USERDEF_4           VARCHAR (30)    encode zstd,
    MEM_USERDEF_4_DESC      VARCHAR (150)	encode zstd,
    MEM_USERDEF_4_ID	    VARCHAR (40),
    MEM_USERDEF_4_LV1	    VARCHAR (30)	encode zstd,
    MEM_USERDEF_4_LV1_DESC	VARCHAR (150)	encode zstd,
    MEM_USERDEF_4_LV1_ID	VARCHAR (100),
    MEM_USERDEF_4_LV2	    VARCHAR (30)	encode zstd,
    MEM_USERDEF_4_LV2_DESC	VARCHAR (150)	encode zstd,
    MEM_USERDEF_4_LV2_ID	VARCHAR (100),
    RIFLAG                  SMALLINT         encode zstd
) diststyle all sortkey (MEM_USERDEF_4_ID,MEM_USERDEF_4_LV2_ID,MEM_USERDEF_4_LV1_ID);