create table {schemaname}.L5_II_DICT_ACCOUNT_LV2 (    ACCOUNT_LV2_ID VARCHAR(100),
    ACCOUNT_LV2_DESC VARCHAR(150) encode zstd,
    ACCOUNT_LV1_ID VARCHAR(100)) diststyle all sortkey(ACCOUNT_LV2_ID,ACCOUNT_LV1_ID);
