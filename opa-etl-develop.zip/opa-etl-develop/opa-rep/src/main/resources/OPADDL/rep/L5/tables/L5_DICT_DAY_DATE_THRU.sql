create table {schemaname}.L5_DICT_DAY_DATE_THRU (    DATE_ID DATE not null encode zstd,
    YR_MONTH INTEGER not null encode zstd,
    YEAR_MTH_ID SMALLINT encode zstd,
    ROLLING_TIMEFRAME_ID SMALLINT not null encode zstd,
    YEAR_TO_DATE_ID SMALLINT not null encode zstd) diststyle all;