CREATE TABLE {schemaname}.L4_DICT_ELIG_CDS (
	client_id VARCHAR (16) encode zstd,
	elig_cds_desc VARCHAR (200) encode zstd,
	elig_cds_grp VARCHAR (4000) encode zstd,
	elig_cds_id INTEGER,
	elig_source_type_flg INTEGER encode zstd,
	for_each_cds_ind INTEGER encode zstd,
	require_billing_ind INTEGER encode zstd
) diststyle all sortkey(elig_cds_id);
