CREATE TABLE {schemaname}.l5_dict_proc_group (
     PROC_GROUP_ID INTEGER,
     PROC_GROUP_SET VARCHAR (1020) encode zstd,
     EXTERNAL_CODE VARCHAR (1020) encode zstd,
     DESCRIPTION VARCHAR (1020) encode zstd,
     SENSITIVE_IND SMALLINT encode zstd,
     SENSITIVE_CAT_ID SMALLINT encode zstd
) diststyle all sortkey (PROC_GROUP_ID);
