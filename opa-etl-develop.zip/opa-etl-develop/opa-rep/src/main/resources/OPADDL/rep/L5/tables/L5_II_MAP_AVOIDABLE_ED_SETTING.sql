CREATE TABLE {schemaname}.L5_II_MAP_AVOIDABLE_ED_SETTING (
	AVOIDABLE_ED_SETTING_ID     SMALLINT,
	AVOIDABLE_ED_SETTING_DESC   VARCHAR (30)   encode zstd
)diststyle all sortkey(avoidable_ed_setting_id);
