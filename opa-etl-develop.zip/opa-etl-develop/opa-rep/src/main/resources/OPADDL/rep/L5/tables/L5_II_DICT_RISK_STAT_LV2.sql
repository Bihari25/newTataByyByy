create table {schemaname}.L5_II_DICT_RISK_STAT_LV2 (
    AT_RISK_STATUS_LV2_ID VARCHAR(100),
    AT_RISK_STATUS_LV2_DESC VARCHAR(150) encode zstd,
    AT_RISK_STATUS_LV1_ID VARCHAR(100) encode zstd
) diststyle all sortkey(at_risk_status_lv2_id);