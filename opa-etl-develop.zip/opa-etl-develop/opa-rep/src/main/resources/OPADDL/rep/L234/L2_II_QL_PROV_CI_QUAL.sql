CREATE TABLE {schemaname}.L2_II_QL_PROV_CI_QUAL (
	CI_HI_QUAL DECIMAL (7, 2) encode zstd,
	CI_LO_QUAL DECIMAL (7, 2) encode zstd,
	EBM_DEN INTEGER encode zstd,
	EBM_NUM INTEGER encode zstd,
	PEER_DEF_ID INTEGER,
	PEER_EBM_NUM DECIMAL (28, 6) encode zstd,
	PROVIDER_ID VARCHAR (20) encode zstd,
	SIGNIF_QUAL VARCHAR (2) encode zstd,
	SUM_ODD DECIMAL (28, 6) encode zstd,
	VAR_ODD DECIMAL (28, 6) encode zstd,
	WGT_VAR_ODD DECIMAL (28, 6) encode zstd
) sortkey(peer_def_id);
