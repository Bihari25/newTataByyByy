CREATE TABLE  {schemaname}.L5_II_POP_COUNT (
	PROVIDER_ID VARCHAR (20) encode zstd,
	PEER_DEF_ID INTEGER encode zstd,
	PRODUCT_ID VARCHAR (40) encode zstd,
	PCP_IMP_FLAG INTEGER encode zstd,
	AGE_CAT2 INTEGER encode zstd,	
	SEX SMALLINT encode zstd,
	IA_TIME INTEGER ,
	IA_TIME_ADJ INTEGER encode zstd,	
	RRISK_CAT INTEGER encode zstd,
	PHM_QUAL SMALLINT encode zstd,
	PCP_MMOS DECIMAL (28, 6) encode zstd,
	RRISK_W DECIMAL (28, 6) encode zstd) sortkey(IA_TIME);