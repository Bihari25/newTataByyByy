create table {schemaname}.L5_BENCHMK_EPI_NUMER_DTL (
    YEAR        SMALLINT,
    AGE_CAT2    SMALLINT        encode zstd,
    SEX         SMALLINT        encode zstd,
    CENS_REG    SMALLINT        encode zstd,
    ETG_ID      INTEGER         encode zstd,
    ETG_FAMILY  INTEGER         encode zstd,
    ETG_MPC     INTEGER         encode zstd,
    SEV_LEVEL   INTEGER         encode zstd,
    TOS1_ID     INTEGER         encode zstd,
    AMT_NP      DECIMAL(19, 2)  encode zstd,
    ENCOUNTERS  DECIMAL(19, 2)  encode zstd,
    DUMMY_EMAIL VARCHAR(1)      encode zstd
) sortkey(YEAR);