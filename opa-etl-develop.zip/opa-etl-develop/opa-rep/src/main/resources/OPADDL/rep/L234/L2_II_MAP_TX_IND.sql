CREATE TABLE {schemaname}.L2_II_MAP_TX_IND (
	TX_IND INTEGER,
	TX_IND_DESC VARCHAR (20) encode zstd,
	TX_IND_FLAG INTEGER encode zstd
) diststyle all sortkey(TX_IND);
