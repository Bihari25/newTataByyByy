CREATE TABLE {schemaname}.L2_II_MAP_SPEC_RX_N (
	map_srce_n VARCHAR (6) encode zstd,
	riflag INT encode zstd,
	spec_rx_n VARCHAR (30) encode zstd,
	spec_rx_n_desc VARCHAR (150) encode zstd,
	spec_rx_n_id VARCHAR (40),
	spec_rx_n_lv1 VARCHAR (20) encode zstd,
	spec_rx_n_lv1_desc VARCHAR (150) encode zstd,
	spec_rx_n_lv1_id VARCHAR (100),
	spec_rx_n_lv2 VARCHAR (20) encode zstd,
	spec_rx_n_lv2_desc VARCHAR (150) encode zstd,
	spec_rx_n_lv2_id VARCHAR (100)
) diststyle all sortkey(spec_rx_n_id, spec_rx_n_lv2_id, spec_rx_n_lv1_id);
