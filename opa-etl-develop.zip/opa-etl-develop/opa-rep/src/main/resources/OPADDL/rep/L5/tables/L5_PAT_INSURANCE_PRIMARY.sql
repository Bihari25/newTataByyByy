CREATE TABLE {schemaname}.l5_pat_insurance_primary (
    client_id VARCHAR(16) ENCODE ZSTD,
    cds_grp VARCHAR(4000) ENCODE ZSTD,
    mpi VARCHAR(32) ENCODE ZSTD,
    lob_cui VARCHAR(8),
    payer_cui VARCHAR(8) ENCODE ZSTD,
    yr_month INTEGER ENCODE ZSTD,
    last_ind VARCHAR(1)    ENCODE ZSTD,
    clinic_event_ind VARCHAR(1) ENCODE ZSTD,
    no_enc_ind SMALLINT ENCODE ZSTD,
    rolling_timeframe_id SMALLINT ENCODE ZSTD,
    year_to_date_id SMALLINT ENCODE ZSTD,
    plancode VARCHAR(255) ENCODE ZSTD,
    planname VARCHAR(255) ENCODE ZSTD
)
DISTKEY(mpi)
SORTKEY(lob_cui);
