create table {schemaname}.L5_II_MAP_PROCCODE (    PROCCODE VARCHAR(255) ,
    PROCCODE_DESC VARCHAR(255) encode zstd
) diststyle all sortkey(PROCCODE);