CREATE TABLE {schemaname}.L5_DICT_FACILITY (
    FACILITY_ID varchar(20),
    FACILITY_NAME varchar(50) ENCODE zstd,
    FACILITY_TYPE_ID integer ENCODE az64
)  diststyle all sortkey(FACILITY_ID);