CREATE TABLE {schemaname}.L2_II_MAP_DCC (
	DCC VARCHAR (5),
	GEN_NAME VARCHAR (255) encode zstd,
	PCC VARCHAR (3),
	TOS_I_5 INTEGER
) diststyle all sortkey(pcc, dcc, tos_i_5);
