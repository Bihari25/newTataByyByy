create table {schemaname}.L5_DICT_CONDITION_PRECURSOR (
    CONDITION_ID INTEGER,
    PRECURSOR_ID INTEGER,
    CONDITION_PRECURSOR_DESC VARCHAR(100) encode zstd,
    SENSITIVE_IND SMALLINT encode zstd,
    SENSITIVE_CAT_ID INTEGER encode zstd
) diststyle all sortkey(condition_id, precursor_id);