CREATE OR REPLACE VIEW {schemaname}.L5_II_CONTRACT_SERVICES AS
  (SELECT contract_id,
          min_svc_dt_inp AS min_svc_dt,
          max_svc_dt_inp AS max_svc_dt,
          min_pd_dt_inp AS min_pd_dt,
          max_pd_dt_inp AS max_pd_dt,
          'Inpatient' AS service_ind
   FROM l2_system_contract_dates
   UNION SELECT contract_id,
                min_svc_dt_med,
                max_svc_dt_med,
                min_pd_dt_med,
                max_pd_dt_med,
                'Medical' AS service_ind
   FROM l2_system_contract_dates
   UNION SELECT contract_id,
                min_svc_dt_rx,
                max_svc_dt_rx,
                min_pd_dt_rx,
                max_pd_dt_rx,
                'Pharmacy' AS service_ind
   FROM l2_system_contract_dates);