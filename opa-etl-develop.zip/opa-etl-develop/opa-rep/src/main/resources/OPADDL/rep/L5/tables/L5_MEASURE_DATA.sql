create table {schemaname}.L5_MEASURE_DATA (
    MEASURE_SET_ID INTEGER encode zstd,
    TIMEFRAME_ID INTEGER encode zstd,
    MEASURE_TYPE VARCHAR(14) not null encode zstd,
    MEASURE_DESC VARCHAR(405) encode zstd,
    MEASURE_RANK INTEGER encode zstd,
    TYPICAL_IND SMALLINT not null encode zstd,
    SENSITIVE_IND SMALLINT not null encode zstd,
    MPI VARCHAR(32),
    COMPLIANT VARCHAR(3) encode zstd,
    CARE_GAP VARCHAR(3) encode zstd,
    EVENT_DT TIMESTAMP encode zstd,
    CONTRACT_ID VARCHAR(1020) encode zstd,
    PRODUCT_ID VARCHAR(1020) encode zstd,
    PROV_ID VARCHAR(20) encode zstd,
    AMB_SITE_ID BIGINT encode zstd,
    NEXT_APPOINTMENT_DTM TIMESTAMP encode zstd,
    NEXT_APPOINTMENT_PROVIDER VARCHAR(255) encode zstd,
    NEXT_APPOINTMENT_LOCATION VARCHAR(100) encode zstd,
    NUMERATOR SMALLINT encode zstd,
    DENOMINATOR SMALLINT encode zstd
) distkey(MPI) SORTKEY (MPI);

