CREATE TABLE {schemaname}.l5_dict_score_sre (
    score_id          INTEGER          ENCODE zstd,
    score_name        VARCHAR(50)      ENCODE zstd,
    score_desc        VARCHAR(400)     ENCODE zstd,
    timeframe_id      SMALLINT,
    score_family_id   INTEGER          ENCODE zstd,
    surr_id           INTEGER,
    score_time_name   VARCHAR(104)     ENCODE zstd
)
DISTSTYLE ALL
SORTKEY (surr_id, timeframe_id);