CREATE TABLE {schemaname}.l5_member_cost (
    member               VARCHAR(32)       ENCODE zstd,
    new_mem_attr_id      INTEGER           ENCODE zstd,
    year_mth_id          INTEGER,
    amt_pay_anc          DOUBLE PRECISION  ENCODE zstd,
    amt_pay_ip           DOUBLE PRECISION  ENCODE zstd,
    amt_pay_op           DOUBLE PRECISION  ENCODE zstd,
    amt_pay_prf          DOUBLE PRECISION  ENCODE zstd,
    amt_pay_rx           DOUBLE PRECISION  ENCODE zstd,
    amt_pay_tot          DOUBLE PRECISION  ENCODE zstd,
    amt_eqv_anc          DOUBLE PRECISION  ENCODE zstd,
    amt_eqv_ip           DOUBLE PRECISION  ENCODE zstd,
    amt_eqv_op           DOUBLE PRECISION  ENCODE zstd,
    amt_eqv_prf          DOUBLE PRECISION  ENCODE zstd,
    amt_eqv_rx           DOUBLE PRECISION  ENCODE zstd,
    amt_eqv_tot          DOUBLE PRECISION  ENCODE zstd,
    amt_np_anc           DOUBLE PRECISION  ENCODE zstd,
    amt_np_ip            DOUBLE PRECISION  ENCODE zstd,
    amt_np_op            DOUBLE PRECISION  ENCODE zstd,
    amt_np_prf           DOUBLE PRECISION  ENCODE zstd,
    amt_np_rx            DOUBLE PRECISION  ENCODE zstd,
    amt_np_tot           DOUBLE PRECISION  ENCODE zstd,
    rolling_timeframe_id SMALLINT NOT NULL ENCODE zstd,
    year_to_date_id      SMALLINT NOT NULL ENCODE zstd
)
DISTKEY (member)
SORTKEY (year_mth_id);
