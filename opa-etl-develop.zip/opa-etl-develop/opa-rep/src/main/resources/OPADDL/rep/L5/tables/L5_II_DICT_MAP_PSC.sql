CREATE TABLE {schemaname}.l5_ii_dict_map_psc (
    psc_cat1_id INTEGER NOT NULL,
    psc_cat1    VARCHAR(100)        ENCODE zstd
)
DISTSTYLE ALL
SORTKEY (psc_cat1_id);
