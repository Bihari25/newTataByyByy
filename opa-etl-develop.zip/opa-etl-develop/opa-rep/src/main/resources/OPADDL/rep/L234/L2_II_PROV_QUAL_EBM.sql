CREATE TABLE {schemaname}.L2_II_PROV_QUAL_EBM (
	EBM_100 BOOLEAN encode zstd,
	EBM_200 BOOLEAN encode zstd,
	EBM_300 BOOLEAN encode zstd,
	EBM_400 BOOLEAN encode zstd,
	PEER_DEF_ID INTEGER,
	PROVIDER_ID VARCHAR (20),
	QUAL_EBM_DEN INTEGER encode zstd,
	QUAL_EBM_NUM INTEGER encode zstd,
	QUAL_ELIG BOOLEAN encode zstd,
	QUAL_OVR_IND DECIMAL (28, 6) encode zstd,
	QUAL_PEER_EBM_NUM DECIMAL (28, 6) encode zstd,
	RANK_DEC_QUAL INTEGER encode zstd
) sortkey(PEER_DEF_ID, PROVIDER_ID);
