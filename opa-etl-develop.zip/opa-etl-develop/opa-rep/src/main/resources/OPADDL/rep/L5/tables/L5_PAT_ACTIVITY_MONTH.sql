CREATE TABLE {schemaname}.l5_pat_activity_month (
    client_id            VARCHAR(16) ENCODE zstd,
    mpi                  VARCHAR(32) ENCODE zstd,
    cds_grp              VARCHAR(4000) encode zstd,
    activity_yr_month    INTEGER,
    activity_type_cd     VARCHAR(8) ENCODE lzo,
    activity_count       INTEGER     ENCODE zstd,
    rolling_timeframe_id SMALLINT    ENCODE zstd,
    year_to_date_id      SMALLINT    ENCODE zstd
)
DISTKEY (mpi)
SORTKEY (activity_yr_month, activity_type_cd);
