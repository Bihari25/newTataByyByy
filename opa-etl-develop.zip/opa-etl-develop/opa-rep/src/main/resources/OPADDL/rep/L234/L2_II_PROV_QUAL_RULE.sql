CREATE TABLE {schemaname}.L2_II_PROV_QUAL_RULE (
	EBM_DEN INTEGER encode zstd,
	EBM_NUM INTEGER encode zstd,
	EVENT_ID INTEGER encode zstd,
	MEMBER VARCHAR (32) encode zstd,
	MEM_CASE_RULE VARCHAR (100) encode zstd,
	PCP_IMP_FLAG BOOLEAN encode zstd,
	PEER_DEF_ID INTEGER,
	PROVIDER_ID VARCHAR (20),
	RESULT_FLAG INTEGER encode zstd,
	RPT_CASE_ID INTEGER encode zstd,
	RPT_RULE_ID INTEGER encode zstd
) distkey(MEMBER) sortkey(provider_id, peer_def_id);
