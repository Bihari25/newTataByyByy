CREATE TABLE {schemaname}.l5_map_tos1_custom_tos
(
	tos1_id INTEGER,
	custom_tos BIGINT
)
DISTSTYLE ALL
SORTKEY (tos1_id, custom_tos);