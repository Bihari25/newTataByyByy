CREATE TABLE {schemaname}.MD_OADW_INSTANCE (
	attribute_name VARCHAR (20),
	attribute_value VARCHAR (100) encode zstd
) sortkey(attribute_name);
