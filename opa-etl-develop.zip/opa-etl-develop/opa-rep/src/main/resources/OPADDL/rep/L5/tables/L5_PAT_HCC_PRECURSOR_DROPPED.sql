CREATE TABLE {schemaname}.L5_PAT_HCC_PRECURSOR_DROPPED (
    mpi VARCHAR (32) encode zstd,
    grp_precursor_desc VARCHAR (100) encode zstd,
    chronic_ind SMALLINT,
    dropped_flag VARCHAR (1),
    precursor_max_dt TIMESTAMP encode zstd,
    precursor_value VARCHAR (50),
    precursor_type VARCHAR (20) encode zstd,
    coef DOUBLE PRECISION encode zstd,
    timeframe_id SMALLINT,
    timeframe_desc VARCHAR (50) encode zstd,
    elig_cds_id INTEGER,
    elig_cds_desc VARCHAR (200) encode zstd,
    precursor_cds_grp VARCHAR(4000),
    sensitive_ind SMALLINT encode zstd
) distkey(MPI) sortkey(dropped_flag, chronic_ind, elig_cds_id, timeframe_id, precursor_cds_grp, precursor_value);