CREATE TABLE {schemaname}.L5_TIMEFRAME (
	data_end_dt TIMESTAMP encode zstd,
	end_dt TIMESTAMP encode zstd,
	start_dt TIMESTAMP encode zstd,
	timeframe_desc VARCHAR (50) encode zstd,
	timeframe_type VARCHAR (20) encode zstd,
	timeframe_id SMALLINT,
	year_month_range VARCHAR (20) encode zstd
) diststyle all sortkey(timeframe_id);