CREATE TABLE {schemaname}.L2_II_MAP_CLM_TYPE (
	CLM_TYPE VARCHAR (1),
	CLM_TYPE_DESC VARCHAR (12) encode zstd
) diststyle all sortkey(CLM_TYPE);
