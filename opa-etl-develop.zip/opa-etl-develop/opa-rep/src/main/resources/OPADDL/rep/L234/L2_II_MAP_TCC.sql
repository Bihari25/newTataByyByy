CREATE TABLE {schemaname}.L2_II_MAP_TCC (
	TCC VARCHAR (2),
	TCC_DESC VARCHAR (100) encode zstd
) diststyle all sortkey(TCC);
