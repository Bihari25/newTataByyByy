create table {schemaname}.L5_II_MAP_PEG_TARGET (
    PEG_TARGET INTEGER,
    PEG_TARGET_DESC VARCHAR(150) encode zstd,
    SENSITIVE_CAT_ID SMALLINT encode zstd,
    SENSITIVE_IND SMALLINT encode zstd
) diststyle all sortkey (PEG_TARGET);
