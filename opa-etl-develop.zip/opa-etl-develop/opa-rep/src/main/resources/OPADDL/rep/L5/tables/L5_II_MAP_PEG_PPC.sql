create table {schemaname}.L5_II_MAP_PEG_PPC (
    PEG_PPC SMALLINT,
    PEG_PPC_DESC VARCHAR(150) encode zstd
) diststyle all sortkey (PEG_PPC);
