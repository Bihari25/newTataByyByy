CREATE TABLE {schemaname}.L2_DICT_ACTIVITY_TYPE (
	activity_type_cd VARCHAR (8),
	activity_type_desc VARCHAR (1000) encode zstd,
	activity_type_flg INTEGER encode zstd,
	activity_type_name VARCHAR (50) encode zstd
)  diststyle all sortkey(activity_type_cd);
