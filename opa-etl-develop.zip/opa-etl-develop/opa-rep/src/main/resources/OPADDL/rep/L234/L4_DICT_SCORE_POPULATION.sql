CREATE TABLE {schemaname}.L4_DICT_SCORE_POPULATION (
	score_population_desc VARCHAR (400) encode zstd,
	score_population_id INTEGER,
	score_population_name VARCHAR (50) encode zstd
) diststyle all sortkey(score_population_id);
