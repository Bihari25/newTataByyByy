CREATE TABLE {schemaname}.L4_DICT_SCORE_FAMILY (
	protected_ind INTEGER encode zstd,
	score_family_id INTEGER,
	score_family_name VARCHAR (50) encode zstd
) diststyle all sortkey(score_family_id);
