CREATE TABLE {schemaname}.L2_II_MAP_INP_ADMIT_TYPE (
inp_admit_type          VARCHAR (2),
inp_admit_type_desc     VARCHAR (255)   encode zstd
) diststyle all sortkey(inp_admit_type);