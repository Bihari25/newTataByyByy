create table {schemaname}.L5_II_MAP_AVOIDABLE_ED (
    AVOIDABLE_ER_ID     SMALLINT,
    AVOIDABLE_ER_DESC   VARCHAR(40) encode  zstd
) diststyle all sortkey(avoidable_er_id);