CREATE TABLE {schemaname}.L5_DICT_CONDITION (
    condition_id            INTEGER,
    condition_set_name      VARCHAR (40)    encode zstd,
    condition_desc          VARCHAR (100)   encode zstd,
    chronic_ind             SMALLINT         encode zstd,
    sensitive_ind           SMALLINT         encode zstd,
    active_ind              SMALLINT        encode zstd,
    inferred_months         INTEGER         encode zstd
) diststyle all sortkey(condition_id);