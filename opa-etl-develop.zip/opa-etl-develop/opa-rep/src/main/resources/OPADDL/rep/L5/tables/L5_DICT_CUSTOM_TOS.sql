CREATE TABLE {schemaname}.l5_dict_custom_tos (
    tos_custom_id               INTEGER,
    tos_custom_desc             VARCHAR (255)   ENCODE zstd
) DISTSTYLE ALL SORTKEY (tos_custom_id);