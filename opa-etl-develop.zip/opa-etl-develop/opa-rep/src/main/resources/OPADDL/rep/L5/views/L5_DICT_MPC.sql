CREATE OR REPLACE VIEW {schemaname}.L5_DICT_MPC AS
  (SELECT DISTINCT a11.mpc,
                   a11.mpc_desc,
                   CASE
                       WHEN mpc=0 THEN 'images/Optum/mpc_Ungrp.png'
                       WHEN mpc=1 THEN 'images/Optum/mpc_InfDisease.png'
                       WHEN mpc=2 THEN 'images/Optum/mpc_Endo.png'
                       WHEN mpc=3 THEN 'images/Optum/mpc_Hema.png'
                       WHEN mpc=4 THEN 'images/Optum/mpc_Psyc.png'
                       WHEN mpc=5 THEN 'images/Optum/mpc_CheDep.png'
                       WHEN mpc=6 THEN 'images/Optum/mpc_Neur.png'
                       WHEN mpc=7 THEN 'images/Optum/mpc_Opht.png'
                       WHEN mpc=8 THEN 'images/Optum/mpc_Card.png'
                       WHEN mpc=9 THEN 'images/Optum/mpc_Otol.png'
                       WHEN mpc=10 THEN 'images/Optum/mpc_Pulm.png'
                       WHEN mpc=11 THEN 'images/Optum/mpc_Gastro.png'
                       WHEN mpc=12 THEN 'images/Optum/mpc_Hepa.png'
                       WHEN mpc=13 THEN 'images/Optum/mpc_Neph.png'
                       WHEN mpc=14 THEN 'images/Optum/mpc_Urol.png'
                       WHEN mpc=15 THEN 'images/Optum/mpc_Obst.png'
                       WHEN mpc=16 THEN 'images/Optum/mpc_Gyne.png'
                       WHEN mpc=17 THEN 'images/Optum/mpc_Derm.png'
                       WHEN mpc=18 THEN 'images/Optum/mpc_OrthRheu.png'
                       WHEN mpc=19 THEN 'images/Optum/mpc_Neon.png'
                       WHEN mpc=20 THEN 'images/Optum/mpc_PrevAdmin.png'
                       WHEN mpc=21 THEN 'images/Optum/mpc_LateEffect.png'
                       WHEN mpc=22 THEN 'images/Optum/mpc_IsoSignSymptom.png'
                       ELSE NULL
                   END AS mpc_image
   FROM L2_II_MAP_MPC a11);