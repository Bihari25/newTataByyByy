CREATE TABLE {schemaname}.l5_pat_score_sdoh (
    client_id         VARCHAR(16)      ENCODE zstd,
    mpi               VARCHAR(32),
    score_id          INTEGER          ENCODE zstd,
    timeframe_id      INTEGER          ENCODE zstd,
    elig_cds_id       INTEGER          ENCODE zstd,
    score             DOUBLE PRECISION ENCODE zstd,
    score_default_flg INTEGER          ENCODE zstd,
    surr_id           INTEGER,
    score_qual_id     INTEGER          ENCODE zstd
)
DISTKEY (mpi)
SORTKEY (mpi, surr_id);
