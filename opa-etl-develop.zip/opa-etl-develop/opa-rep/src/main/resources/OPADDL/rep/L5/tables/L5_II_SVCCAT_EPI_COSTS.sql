CREATE TABLE {schemaname}.l5_ii_svccat_epi_costs (
    ia_time             INTEGER,
    provider_id         VARCHAR(20)     ENCODE zstd,
    etg_id              INTEGER         ENCODE zstd,
    sev_level           SMALLINT        ENCODE zstd,
    family              INTEGER         ENCODE zstd,
    mpc                 INTEGER         ENCODE zstd,
    peer_def_id         INTEGER         ENCODE zstd,
    psc_cat1_id         INTEGER         ENCODE zstd,
    util_spec_cat_cd    INTEGER         ENCODE zstd,
    cost_act_tot        DECIMAL(38,18)  ENCODE zstd,
    cost2_act_tot       DECIMAL(38,18)  ENCODE zstd,
    cost3_act_tot       DECIMAL(38,18)  ENCODE zstd,
    enc_act_tot         DECIMAL(38,18)  ENCODE zstd,
    cost_peer_tot       DECIMAL(38,18)  ENCODE zstd,
    cost2_peer_tot      DECIMAL(38,18)  ENCODE zstd,
    cost3_peer_tot      DECIMAL(38,18)  ENCODE zstd,
    enc_peer_tot        DECIMAL(38,18)  ENCODE zstd
)
DISTSTYLE even
SORTKEY(ia_time);