create table {schemaname}.L5_II_MAP_PEG (
    PEG_CAT_DESC VARCHAR(150) encode zstd,
    PEG_CAT_ID INTEGER,
    PEG_PPC SMALLINT,
    SENSITIVE_CAT_ID SMALLINT encode zstd,
    SENSITIVE_IND SMALLINT encode zstd
) diststyle all sortkey (PEG_CAT_ID,PEG_PPC);
