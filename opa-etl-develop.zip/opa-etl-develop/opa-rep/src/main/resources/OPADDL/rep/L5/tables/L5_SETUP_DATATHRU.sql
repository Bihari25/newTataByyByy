create table {schemaname}.L5_SETUP_DATATHRU (    DATA_THRU DATE encode zstd,
    SETUP_DTM DATE encode zstd);