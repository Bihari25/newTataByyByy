CREATE TABLE {schemaname}.L5_DICT_MEASURE_SET (
    MEASURE_SET VARCHAR (41)
) diststyle all sortkey(MEASURE_SET);