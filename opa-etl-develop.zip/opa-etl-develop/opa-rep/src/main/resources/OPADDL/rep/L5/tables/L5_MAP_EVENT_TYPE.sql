create table {schemaname}.L5_MAP_EVENT_TYPE (
		event_type_cui          VARCHAR(50),
		event_type_description  VARCHAR(100)    encode zstd,
		sensitive_ind           SMALLINT        encode zstd
) diststyle all sortkey(event_type_cui);