CREATE OR REPLACE VIEW {schemaname}.L5_II_MAP_OUTLIER AS
  (SELECT 0 AS outlier,
          'Non Outlier' AS outlier_desc
   UNION SELECT 1 AS outlier,
                'Low Outlier' AS outlier_desc
   UNION SELECT 2 AS outlier,
                'High Outlier' AS outlier_desc);