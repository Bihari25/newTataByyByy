CREATE TABLE {schemaname}.l5_pat_score_grp_intn (
    client_id       VARCHAR(16)      ENCODE zstd,
    mpi             VARCHAR(32)      ENCODE zstd,
    grp_id          INTEGER          ENCODE zstd,
    timeframe_id    INTEGER,
    elig_cds_id     INTEGER          ENCODE zstd,
    interaction_id  INTEGER          ENCODE zstd,
    coef_multiplier DOUBLE PRECISION ENCODE zstd,
    sensitive_ind   INTEGER          ENCODE zstd
)
DISTKEY (mpi)
SORTKEY (timeframe_id);
