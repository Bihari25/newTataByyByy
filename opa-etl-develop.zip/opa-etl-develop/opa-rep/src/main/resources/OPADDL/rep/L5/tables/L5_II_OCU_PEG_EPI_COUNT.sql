create table {schemaname}.L5_II_OCU_PEG_EPI_COUNT (
    COMPLETE SMALLINT encode zstd,
    DISQUALIFIED_FLAG SMALLINT encode zstd,
    LATERALITY VARCHAR(1) encode zstd,
    MEM_ATTR_ID INTEGER encode zstd,
    OUTLIER SMALLINT encode zstd,
    PCP_AFFIL_ID VARCHAR(40) encode zstd,
    PCP_ASSIGN VARCHAR(20) encode zstd,
    PCP_IMP VARCHAR(20) encode zstd,
    PEG_CAT_ID INTEGER,
    PEG_EPI_QTY DECIMAL(28, 6) encode zstd,
    PEG_SCORE DECIMAL(10, 4)  encode zstd,
    PEG_SEV_LEVEL SMALLINT,
    RRISK DECIMAL(10, 4)  encode zstd,
    YEAR_MTH_ID SMALLINT
) distkey(MEM_ATTR_ID) sortkey (YEAR_MTH_ID,PEG_CAT_ID,PEG_SEV_LEVEL);
