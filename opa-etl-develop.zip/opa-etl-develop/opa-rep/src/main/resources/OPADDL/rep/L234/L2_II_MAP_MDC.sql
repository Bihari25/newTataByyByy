CREATE TABLE {schemaname}.L2_II_MAP_MDC (
	MDC INTEGER,
	MDC_DESC VARCHAR (150) encode zstd
) diststyle all sortkey(MDC);
