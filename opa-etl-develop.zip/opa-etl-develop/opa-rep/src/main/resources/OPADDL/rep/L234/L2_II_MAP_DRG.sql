CREATE TABLE {schemaname}.L2_II_MAP_DRG (
	DRG_ADMITTYP VARCHAR (3) encode zstd,
	DRG_CODE VARCHAR (4) encode zstd,
	DRG_DESC VARCHAR (200) encode zstd,
	DRG_ID VARCHAR (12),
	DRG_LEVEL VARCHAR (2) encode zstd,
	DRG_VERSION VARCHAR (3) encode zstd,
	MDC INTEGER encode az64,
	RIFLAG INTEGER encode az64,
	DRG_WGT DECIMAL(10, 4) encode zstd
) diststyle all sortkey(DRG_ID);