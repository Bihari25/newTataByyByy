CREATE TABLE {schemaname}.L2_II_MAP_UTIL_SPEC_CAT (
    DEF_UTIL_SPEC_CAT INTEGER encode zstd ,
	UTIL_SPEC1 VARCHAR (90) encode zstd,
	UTIL_SPEC2 VARCHAR (90) encode zstd,
	UTIL_SPEC_CAT_CD INTEGER,
	UTIL_SPEC_CAT_DESC VARCHAR (90) encode zstd,
	UTIL_SPEC_ID1 INTEGER encode zstd,
	UTIL_SPEC_ID2 INTEGER encode zstd
) diststyle all sortkey(UTIL_SPEC_CAT_CD);
	