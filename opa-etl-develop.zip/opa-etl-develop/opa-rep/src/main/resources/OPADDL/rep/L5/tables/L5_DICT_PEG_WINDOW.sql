create table {schemaname}.L5_DICT_PEG_WINDOW (
    PEG_WINDOW SMALLINT,
    PEG_WINDOW_DESC VARCHAR(50) encode zstd
) diststyle all sortkey (PEG_WINDOW);
