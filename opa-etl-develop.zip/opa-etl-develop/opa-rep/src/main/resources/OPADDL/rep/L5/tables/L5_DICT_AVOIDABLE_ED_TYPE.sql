CREATE TABLE {schemaname}.l5_dict_avoidable_ed_type (
	avoidable_type_id SMALLINT,
	avoidable_type_desc VARCHAR(51)  encode zstd,
	avoidable_type_metric VARCHAR(49)  encode zstd
) DISTSTYLE ALL SORTKEY (avoidable_type_id);