### Ticket Number : [OAP-xxxx](https://workflow.advisory.com/browse/OAP-xxxx)

### Description
A few sentences describing the overall goals of the pull request's commits.

### Dev testing details
Quick summary of dev testing details, with YARN link for ETL changes.

### Checklist
- [ ] etl changes includes additional unit test cases
- [ ] specify distribution style/key on every new table
- [ ] not defined encoding/compression on sortkey column
- [ ] no boolean column added, instead used smallint for aggregations to work fine in MSTR
- [ ] L5 scala related L2-L4 dependent tables have been added to L5Dependencies.scala
- [ ] added appropriate labels, after creating PR

(add 'x' to verified items, and remove NA items)
