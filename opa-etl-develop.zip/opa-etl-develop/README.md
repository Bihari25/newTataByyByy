opa-etl (BIG OPA)
==========
### OPA report generation in Apache Spark!

This repository contains the opa-etl spark application stack. OPA generates a reporting schema from an OADW source HIVE DB.

This stack handles the tasks of processing the transformation from OADW into the "L5" layer, OPA's reporting
schema.

This schema and content is consumed into a MicroStrategy instance for end-user display.

| Branch | Status |
|--------|--------|
|master|[![Build Status](https://jenkins-opa-jenkins.ocp-elr-core-nonprod.optum.com/job/OPA/job/opa-etl/job/master/badge/icon)](https://jenkins-opa-jenkins.ocp-elr-core-nonprod.optum.com/job/OPA/job/opa-etl/job/master/)|
|develop|[![Build Status](https://jenkins-opa-jenkins.ocp-elr-core-nonprod.optum.com/job/OPA/job/opa-etl/job/develop/badge/icon)](https://jenkins-opa-jenkins.ocp-elr-core-nonprod.optum.com/job/OPA/job/opa-etl/job/develop/)|


Components/Modules
==========
#### opa_etls
All transformation code and the task runner for the ETL Loader.

Uses dfutils' data-loader to build the DAG and execute
each ETL.

#### opa_models
Contains the case classes used in ETL transformation code.

#### opa_util
Utility code to facilitate common operations across multiple modules and avoid circular dependencies

#### opa_redshift_export
Application for exporting content to REDSHIFT database.

Also contains all the DDLs for REDSHIFT in the resources folder.

Build
==========
Use mvn 3.5[.4] to build.

Development Deployment
==========
If you are already configured to work in the cluster, try running:
```sh
./scripts/dev-deploy.sh -u <humedica user> --package
```

Otherwise:

* do yourself a favor and make this !/.ssh/config entry:
```10:36 $ cat ~/.ssh/config
 Host edgenode
      HostName som-horton-p1-e1-pub.humedica.net
      User <humedica user>
```
* generate yourself an ssh key if you don't have one already with ```ssh-keygen```
* ```cat ~/.ssh/id_rsa.pub``` (if you made default ssh key, whatever you called it otherwise), and copy it EXACTLY
* paste it into the EDGENODE's ~/.ssh/authorized_keys file (not your local machine where you ssh-keygen'ed)

(at some point we'll write a script that automates the build process for devs in /scripts/...)
1. note the path to the /target folder of the module you wish to execute on the cluster the .jar file.
2. note the path to the /target/bin/*.sh spark-submit'ter file associated with the jar you want to run.
3. ssh into edgenode and run ```mkdir /opt/bigoadw/<humedica-username>```
4. scp both files to ```edgenode:/opt/bigoadw/<humedica username>/```
5. ssh into edgenode and execute the bash script you uploaded with the appropriate parameters for the job.

```mvn package``` and scp the jar file in the /target/ folder of the project you want to run in the cluster to the edgenode.
It likely has a bash script wrapper as well, so scp that out there too.

MVN Config / Troubleshooting - Global settings
==========
### mvn client settings
~/.m2/settings.xml:

```xml
<settings xmlns="http://maven.apache.org/SETTINGS/1.0.0"
      xmlns:xsi="http://www.w3.org/2001/XMLSchema-instance"
      xsi:schemaLocation="http://maven.apache.org/SETTINGS/1.0.0
                          https://maven.apache.org/xsd/settings-1.0.0.xsd">
  <profiles>
    <profile>
      <id>remove-defaults</id>
      <repositories>
        <repository>
          <id>central</id>
          <url>http://central</url>
          <releases><enabled>true</enabled></releases>
          <snapshots><enabled>true</enabled></snapshots>
        </repository>
      </repositories>
      <pluginRepositories>
        <pluginRepository>
          <id>central</id>
          <url>http://central</url>
          <releases><enabled>true</enabled></releases>
          <snapshots><enabled>true</enabled></snapshots>
        </pluginRepository>
      </pluginRepositories>
    </profile>
    <profile>
        <id>optum-artifactory</id>
        <repositories>
            <repository>
                <id>uhc-maven</id>
                <url>https://repo1.uhc.com/artifactory/maven-repo</url>
                <releases><enabled>true</enabled></releases>
                <snapshots><enabled>true</enabled></snapshots>
            </repository>
            <repository>
                <id>uhc-snapshots</id>
                <url>https://repo1.uhc.com/artifactory/list/UHG-Snapshots</url>
                <releases><enabled>true</enabled></releases>
                <snapshots><enabled>true</enabled></snapshots>
            </repository>
        </repositories>
    </profile>
    <profile>
        <id>humedica-artifactory</id>
        <repositories>
            <repository>
                <id>humedica-repo</id>
                <url> http://maven.humedica.net/nexus/content/groups/hit-combined</url>
                <releases><enabled>true</enabled></releases>
                <snapshots><enabled>true</enabled></snapshots>
            </repository>
        </repositories>
    </profile>
  </profiles>
  <activeProfiles>
    <activeProfile>optum-artifactory</activeProfile>
  </activeProfiles>
</settings>
```
Then you can run:
```sh
mvn clean install
```
and downloads will come from artifactory.

### Stuff's weird between IntelliJ and mvn CLI
If the project builds in mvn CLI successfully but not in intelliJ with missing dependencies that also light up just fine in "intelliSense", then run:
```sh
mvn idea:idea
```
This has _generally_ fixed issues like this...

### Sonar Local Debugging
To detect and fix quality issues while you write code,
Configure [SonarLint](https://www.optumdeveloper.com/content/odv-optumdev/optum-developer/en/getting-started/getting-started-wtih-sonarqube/step-3--configure-sonarlint.html) in the IDE

To view code coverage report in IntelliJ IDE,
Choose option `Run -> Show Code Coverage Data` and select `jacaco.exec`

### Building with Windows

If sh.exe is not present as part of the environment variables in windows machine, maven build will throw an error like below,

`Create $1 is not a valid windows application`

To overcome this issue, please run the maven build using git bash or set sh.exe as part of the environment variables.
