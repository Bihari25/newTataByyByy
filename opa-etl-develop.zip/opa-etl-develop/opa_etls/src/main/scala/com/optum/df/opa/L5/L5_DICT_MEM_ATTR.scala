package com.optum.df.opa.L5

import com.optum.df.opa.models.L5.l5_dict_mem_attr
import com.optum.oap.sparkdataloader.{RuntimeVariables, UserDefinedFunctionForDataLoader}
import org.apache.spark.sql.functions.{coalesce, lit, when}
import org.apache.spark.sql.types.ShortType
import org.apache.spark.sql.{DataFrame, SparkSession}

/**
  * Source query:
  * https://som-bb.humedica.net/projects/OAP/repos/oap-mstr-db-interface/browse/src/main/resources/src/build/L5/etl/OPA/L5_dict_mem_attr_insert.sql
  *
  * Redshift Schema: opa_util/src/main/resources/OPADDL/L5/tables/L5_DICT_MEM_ATTR.sql
  */

object L5_DICT_MEM_ATTR extends L5TableInfo[l5_dict_mem_attr] {
  override def name: String = "L5_DICT_MEM_ATTR"
  override def dependsOn: Set[String] = Set("L2_II_MEM_ATTR_EXT")

  def createDataFrameWithoutDDL(sparkSession: SparkSession, loadedDependencies: Map[String, DataFrame], udfMap: Map[String, UserDefinedFunctionForDataLoader], runtimeVariables: RuntimeVariables): DataFrame = {
    import sparkSession.implicits._

    val l2iimemattrext = loadedDependencies("L2_II_MEM_ATTR_EXT")

    l2iimemattrext.select(
      $"new_mem_attr_id",
        $"account_id",
        $"cat_status_cost3".cast(ShortType).as("cat_status_cost3"),
        $"age_cat2".cast(ShortType).as("age_cat2"),
        coalesce($"contract_id", lit("Unspecified$UNK")).as("contract_id"),
        $"mem_userdef_1_id",
        coalesce($"mem_userdef_4_id", lit("Unspecified$UNK")).as("mem_userdef_4_id"),
        coalesce($"at_risk_status_id",lit("Unspecified$UNK")).as("at_risk_status_id"),
        when($"pcp_assign".isNull, lit("0")).otherwise($"pcp_assign").alias("pcp_assign"),
        coalesce($"product_id", lit("Unspecified$UNK")).as("product_id"),
        $"sex".cast(ShortType),
        $"zip"
      ).distinct()
  }
}
