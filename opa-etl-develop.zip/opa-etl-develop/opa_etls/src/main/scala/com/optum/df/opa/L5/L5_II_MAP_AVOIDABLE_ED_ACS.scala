package com.optum.df.opa.L5

import com.optum.df.opa.models.L5.l5_ii_map_avoidable_ed_acs
import com.optum.oap.sparkdataloader.{RuntimeVariables, UserDefinedFunctionForDataLoader}
import org.apache.spark.sql.{DataFrame, SparkSession}
import org.apache.spark.sql.types.ShortType


object L5_II_MAP_AVOIDABLE_ED_ACS extends L5TableInfo[l5_ii_map_avoidable_ed_acs] {
  override def name: String = "L5_II_MAP_AVOIDABLE_ED_ACS"

  override def dependsOn: Set[String] = Set("L2_II_MAP_ED_AMB_SENS")

  def createDataFrameWithoutDDL(sparkSession: SparkSession, loadedDependencies: Map[String, DataFrame], udfMap: Map[String, UserDefinedFunctionForDataLoader], runtimeVariables: RuntimeVariables): DataFrame = {
    import sparkSession.implicits._

    val l2IiMapEdAmbSens = loadedDependencies("L2_II_MAP_ED_AMB_SENS")

    l2IiMapEdAmbSens.select(
      $"amb_sens".cast(ShortType).as("avoidable_ed_acs_id"),
      $"amb_sens_desc".as("avoidable_ed_acs_desc")
    )

  }
}
