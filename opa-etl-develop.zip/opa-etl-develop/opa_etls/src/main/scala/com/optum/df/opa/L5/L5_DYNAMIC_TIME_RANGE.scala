package com.optum.df.opa.L5

import com.optum.df.opa.models.L5.l5_dynamic_time_range
import com.optum.oap.sparkdataloader.{RuntimeVariables, UserDefinedFunctionForDataLoader}
import org.apache.spark.sql.functions._
import org.apache.spark.sql.types.ShortType
import org.apache.spark.sql.{DataFrame, SparkSession}

object L5_DYNAMIC_TIME_RANGE extends L5TableInfo[l5_dynamic_time_range] {
  override def name: String = "L5_DYNAMIC_TIME_RANGE"
  override def dependsOn: Set[String] = Set("L2_II_MAP_DATE_RANGE")

  def createDataFrameWithoutDDL(sparkSession: SparkSession, loadedDependencies: Map[String, DataFrame], udfMap: Map[String, UserDefinedFunctionForDataLoader], runtimeVariables: RuntimeVariables): DataFrame = {
    import sparkSession.implicits._

    val l2IiMapDateRange = loadedDependencies("L2_II_MAP_DATE_RANGE")

    val maxYearMonth = l2IiMapDateRange.select(max($"year_mth_id")).na.fill(0).head().getInt(0)
    val maxYearValue = l2IiMapDateRange.select(max($"year_val")).na.fill(0).head().getInt(0)

    l2IiMapDateRange.select(
      $"year_mth_id",
      $"yr_month",
      when($"ia_time_desc" === lit("Current Period"), lit(1)).otherwise(lit(0)).cast(ShortType).as("rolling_12_months_flg"),
      when($"ia_time_desc" === lit("Current Period") || $"ia_time_desc" === lit("Lag Period"), lit(1)).otherwise(lit(0)).cast(ShortType).as("rolling_15_months_flg"),
      when($"year_mth_id" between (maxYearMonth - 17 , maxYearMonth), lit(1)).otherwise(lit(0)).cast(ShortType).as("rolling_18_months_flg"),
      when($"year_mth_id" between (maxYearMonth - 26 , maxYearMonth), lit(1)).otherwise(lit(0)).cast(ShortType).as("rolling_27_months_flg"),
      when($"year_val" === maxYearValue, lit(1)).
        when($"year_val" === maxYearValue - 1 && $"year_mth_id" <= maxYearMonth - 12, lit(-1)).
        otherwise(lit(0)).cast(ShortType).as("cytd_flg"),
      when($"year_val" === maxYearValue, lit("Current YTD")).
        when($"year_val" === maxYearValue - 1 && $"year_mth_id" <= maxYearMonth - 12, lit("Prior YTD")).
        otherwise(lit("Other Months")).as("cytd_desc")
    )
  }
}