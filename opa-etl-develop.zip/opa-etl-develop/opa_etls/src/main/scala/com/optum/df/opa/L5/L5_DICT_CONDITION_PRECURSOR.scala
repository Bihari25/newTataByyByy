package com.optum.df.opa.L5

import com.optum.df.opa.models.L5.l5_dict_condition_precursor
import com.optum.oap.sparkdataloader.{RuntimeVariables, UserDefinedFunctionForDataLoader}
import org.apache.spark.sql.types.ShortType
import org.apache.spark.sql.{DataFrame, SparkSession}


object L5_DICT_CONDITION_PRECURSOR extends L5TableInfo[l5_dict_condition_precursor] {
  override def name: String = "L5_DICT_CONDITION_PRECURSOR"

  override def dependsOn: Set[String] = Set("L3_DICT_CONDITION_PRECURSOR")
  def createDataFrameWithoutDDL(sparkSession: SparkSession, loadedDependencies: Map[String, DataFrame], udfMap: Map[String, UserDefinedFunctionForDataLoader], runtimeVariables: RuntimeVariables): DataFrame = {
    import sparkSession.implicits._

    val l3DictConditionPrecursor = loadedDependencies("L3_DICT_CONDITION_PRECURSOR")

    l3DictConditionPrecursor
      .select(
        $"condition_id",
        $"precursor_id",
        $"condition_precursor_desc",
        $"sensitive_ind".cast(ShortType),
        $"sensitive_cat_id"
    )
  }
}
