package com.optum.df.opa.L5

import com.optum.df.opa.models.L5.l5_ii_map_state
import org.apache.spark.sql.functions.{coalesce, lit}
import com.optum.oap.sparkdataloader.{RuntimeVariables, UserDefinedFunctionForDataLoader}
import org.apache.spark.sql.{DataFrame, SparkSession}


object L5_II_MAP_STATE extends L5TableInfo[l5_ii_map_state] {
  override def name: String = "L5_II_MAP_STATE"
  override def dependsOn: Set[String] = Set("L2_II_MAP_COUNTY", "L1_REF_COMMERCIAL_ZIPCODES")

  def createDataFrameWithoutDDL(sparkSession: SparkSession, loadedDependencies: Map[String, DataFrame], udfMap: Map[String, UserDefinedFunctionForDataLoader], runtimeVariables: RuntimeVariables): DataFrame = {
    import sparkSession.implicits._

    val l2IiMapCounty = loadedDependencies("L2_II_MAP_COUNTY")
    val l1RefCommercialZipcodes = loadedDependencies("L1_REF_COMMERCIAL_ZIPCODES")
    val defaults = Seq((0, "UNK", "Unknown")).toDF()

    val distinctStates = l1RefCommercialZipcodes.select(
      $"stateabbr",
      $"statename"
    ).distinct()

    l2IiMapCounty.as("c")
      .join(distinctStates.as("s"),$"c.state_desc" === $"s.stateabbr", "left_outer")
      .select(
      $"c.state",
      $"c.state_desc",
      coalesce($"s.statename", lit("Unknown")).as("state_name")
    ).distinct().union(defaults)
  }
}
