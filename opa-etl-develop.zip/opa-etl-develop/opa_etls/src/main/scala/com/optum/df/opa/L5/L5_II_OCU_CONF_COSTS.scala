package com.optum.df.opa.L5

import com.optum.df.opa.models.L5.l5_ii_ocu_conf_costs
import com.optum.oap.sparkdataloader.{RuntimeVariables, UserDefinedFunctionForDataLoader}
import com.optum.oadw.oadwModels.{l2_ii_map_account, l2_ii_map_tos, l2_ii_mem_attr}
import com.optum.oadw.oadw_ref.models.l4_map_tos5_custom
import org.apache.spark.sql.functions._
import org.apache.spark.sql.types.ShortType
import org.apache.spark.sql.{DataFrame, SparkSession}

object L5_II_OCU_CONF_COSTS extends L5TableInfo[l5_ii_ocu_conf_costs] {
  override def name: String = "L5_II_OCU_CONF_COSTS"
  override def dependsOn: Set[String] = Set("L2_II_MAP_TOS", "L4_MAP_TOS5_CUSTOM", "L2_II_OCU_CONF_COSTS", "L2_II_MEM_ATTR", "L2_II_MAP_ACCOUNT")

  def createDataFrameWithoutDDL(sparkSession: SparkSession, loadedDependencies: Map[String, DataFrame], udfMap: Map[String, UserDefinedFunctionForDataLoader], runtimeVariables: RuntimeVariables): DataFrame = {
    import sparkSession.implicits._
    val l2IIMapTos = loadedDependencies("L2_II_MAP_TOS")
    val l4MapTos5Custom = loadedDependencies("L4_MAP_TOS5_CUSTOM")
    val l2IIOcuConfCosts = loadedDependencies("L2_II_OCU_CONF_COSTS")
    val l2IIMemAttr = loadedDependencies("L2_II_MEM_ATTR")
    val l2IIMapAccount = loadedDependencies("L2_II_MAP_ACCOUNT")

    l2IIOcuConfCosts.as("cc")
      .join(l2IIMapTos.as("tos"), $"cc.tos_i_5" === $"tos.tos_i_5", "left")
      .join(l4MapTos5Custom.as("cus"), $"tos.tos_i_5" === $"cus.tos_i_5", "left")
      .join(l2IIMemAttr.as("ma"), $"cc.mem_attr_id" === $"ma.member_attr_id")
      .join(l2IIMapAccount.as("mac"), $"ma.account_id" === $"mac.account_id")
      .select(
        $"cc.year_mth_id".cast(ShortType),
        $"cc.year_mth_pd".cast(ShortType),
        $"cc.mem_attr_id",
        coalesce($"cc.provider_id", lit("0")).as("provider_id"),
        coalesce($"cc.etg_id", lit(0)).as("etg_id"),
        coalesce($"cc.sev_level", lit(0)).cast(ShortType).as("sev_level"),
        coalesce($"cc.pcp_assign", lit("0")).as("pcp_assign"),
        coalesce($"cc.pcp_imp", lit("0")).as("pcp_imp"),
        coalesce($"cc.drg_id", lit("unsp$unk")).as("drg_id"),
        coalesce($"cc.drg_admittyp", lit("unk")).as("drg_admittyp"),
        when($"cc.lag_ind" === lit(true), 1).otherwise(lit(0)).cast(ShortType).as("lag_ind"),
        $"cc.lag_months",
        $"cc.prv_sp_4",
        $"cc.tos_i_5",
        coalesce($"cus.tos_custom_id", lit(3399999)).as("tos_custom_id"),
        $"tos.tos1_id",
        $"cc.facip_flag".cast(ShortType),
        when($"cc.network_status" === lit(true), 1).otherwise(lit(0)).cast(ShortType).as("network_status"),
        $"cc.poa1".as("poa"),
        $"cc.cost1",
        $"cc.cost2",
        $"cc.cost3",
        $"cc.cost4",
        $"cc.cost5",
        $"cc.cost6",
        $"cc.encounter",
        $"cc.amt_pay_adj",
        $"cc.amt_eqv_adj",
        coalesce($"mac.account_lv1_id", $"mac.account_lv2_id", $"mac.account_id").as("account_lv1_id"),
        coalesce($"mac.account_lv2_id", $"mac.account_id").as("account_lv2_id"),
        $"mac.account_id"
      )
  }
}
