package com.optum.df.opa.L5

import com.optum.df.opa.models.L5.l5_ii_pop_costs
import com.optum.oap.sparkdataloader.{RuntimeVariables, TableInfo, UserDefinedFunctionForDataLoader}
import org.apache.spark.sql.functions._
import org.apache.spark.sql.types.ShortType
import org.apache.spark.sql.{DataFrame, SparkSession}

object L5_II_POP_COSTS extends L5TableInfo[l5_ii_pop_costs] {
  override def name: String = "L5_II_POP_COSTS"
  override def dependsOn: Set[String] = Set("L2_II_POP_COSTS")

  def createDataFrameWithoutDDL(sparkSession: SparkSession, loadedDependencies: Map[String, DataFrame], udfMap: Map[String, UserDefinedFunctionForDataLoader], runtimeVariables: RuntimeVariables): DataFrame = {
    import sparkSession.implicits._

    val l2IiPopCosts = loadedDependencies("L2_II_POP_COSTS")

    l2IiPopCosts.as("pc")
      .select(
        coalesce($"pc.PROVIDER_ID", lit("0")).as("PROVIDER_ID"),
        $"pc.PEER_DEF_ID",
        coalesce($"pc.PRODUCT_ID", lit("Unspecified$UNK")).as("PRODUCT_ID"),
        $"pc.PCP_IMP_FLAG" ,
        $"pc.PSC_CAT1_ID" ,
        $"pc.AGE_CAT2" ,
        when($"pc.SEX"  === lit(true), 1).otherwise(lit(0)).cast(ShortType).as("SEX"),
        $"pc.IA_TIME" ,
        $"pc.IA_TIME_ADJ" ,
        $"pc.RRISK_CAT" ,
        $"pc.UTIL_SPEC_CAT_CD",
        when($"pc.PHM_QUAL" === lit(true), 1).otherwise(lit(0)).cast(ShortType).as("PHM_QUAL"),
        $"pc.ADMIT_ACT_TOT" ,
        $"pc.ADMIT_PEER_TOT" ,
        $"pc.COST2_ACT_TOT" ,
        $"pc.COST2_PEER_TOT" ,
        $"pc.COST3_ACT_TOT" ,
        $"pc.COST3_PEER_TOT" ,
        $"pc.COST_ACT_TOT" ,
        $"pc.COST_PEER_TOT" ,
        $"pc.DAYS_ACT_TOT" ,
        $"pc.DAYS_PEER_TOT" ,
        $"pc.ENC_ACT_TOT" ,
        $"pc.ENC_PEER_TOT" ,
        $"pc.ER_ACT_TOT" ,
        $"pc.ER_PEER_TOT" ,
        $"pc.GEN_ACT_TOT" ,
        $"pc.GEN_PEER_TOT" ,
        $"pc.LAB_ACT_TOT" ,
        $"pc.LAB_PEER_TOT" ,
        $"pc.MRI_ACT_TOT" ,
        $"pc.MRI_PEER_TOT" ,
        $"pc.PCPVIS_ACT_TOT" ,
        $"pc.PCPVIS_PEER_TOT" ,
        $"pc.RAD_ACT_TOT" ,
        $"pc.RAD_PEER_TOT" ,
        $"pc.REFVIS_ACT_TOT" ,
        $"pc.REFVIS_PEER_TOT" ,
        $"pc.REF_ACT_TOT" ,
        $"pc.REF_PEER_TOT" ,
        $"pc.SCRIPT_ACT_TOT" ,
        $"pc.SCRIPT_GEN_ACT_TOT" ,
        $"pc.SCRIPT_PEER_TOT"

      )
  }
}

