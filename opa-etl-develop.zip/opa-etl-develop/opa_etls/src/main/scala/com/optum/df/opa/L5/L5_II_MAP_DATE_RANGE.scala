package com.optum.df.opa.L5

import com.optum.df.opa.models.L5.l5_ii_map_date_range
import com.optum.oap.sparkdataloader.{RuntimeVariables, UserDefinedFunctionForDataLoader}
import com.optum.oadw.oadwModels.l2_ii_map_date_range
import org.apache.spark.sql.functions.{concat, lit}
import org.apache.spark.sql.types.ShortType
import org.apache.spark.sql.{DataFrame, SparkSession}

object L5_II_MAP_DATE_RANGE extends L5TableInfo[l5_ii_map_date_range]{
  override def name: String = "L5_II_MAP_DATE_RANGE"

  override def dependsOn: Set[String] = Set("L2_II_MAP_DATE_RANGE")

  def createDataFrameWithoutDDL(sparkSession: SparkSession, loadedDependencies: Map[String, DataFrame], udfMap: Map[String, UserDefinedFunctionForDataLoader], runtimeVariables: RuntimeVariables): DataFrame = {
    import sparkSession.implicits._

    val l2IIMapDateRance = loadedDependencies("L2_II_MAP_DATE_RANGE")

    l2IIMapDateRance.select(
      $"YEAR_MTH_ID".cast(ShortType),
      $"YR_MONTH",
      $"YEAR_VAL",
      $"YEAR_LABEL",
      $"QTR_ID",
      $"QTR_VAL",
      $"QTR_CODE",
      $"QTR_LABEL1",
      $"QTR_LABEL2",
      $"QTR_DATE_DESC",
      $"QTR_FULL_DESC",
      $"MONTH_VAL",
      $"MONTH_LABEL1",
      $"MONTH_LABEL2",
      $"MONTH_LABEL3",
      $"MONTH_DATE",
      $"MONTH_END_DATE",
      $"MONTH_CODE",
      $"MONTH_FULL_DESC",
      $"IA_TIME",
      $"IA_TIME_CODE",
      $"IA_TIME_DESC",
      $"IA_TIME_DATE_DESC",
      $"IA_TIME_FULL_DESC",
      $"IA_TIME_START_DATE",
      $"IA_TIME_END_DATE",
      concat($"MONTH_LABEL2", lit(" "), $"YEAR_VAL"-1).as("PRIOR_MTH_YEAR_DESC"),
      concat($"MONTH_LABEL1", lit(" "), $"YEAR_VAL"-1).as("PRIOR_MTH_YEAR_FULL_DESC"),
      concat($"MONTH_LABEL1", lit(" "), $"YEAR_LABEL").as("MTH_YEAR_LABEL1"),
      concat($"MONTH_LABEL2", lit(" "), $"YEAR_LABEL").as("MTH_YEAR_LABEL2")
    )
  }
}
