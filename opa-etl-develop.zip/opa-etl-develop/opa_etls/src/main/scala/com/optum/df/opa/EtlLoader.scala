package com.optum.df.opa

import com.optum.df.opa.util.OADefinedFunctionsRegistry
import com.optum.oap.sparkdataloader.{DataLoader, TableInfo}
import com.optum.oap.sparklib.SparkUtils
import org.apache.spark.sql.SparkSession
import org.rogach.scallop.{ScallopConf, ScallopOption}
import org.slf4j.LoggerFactory

import java.util.concurrent.Executors
import scala.concurrent.{ExecutionContext, ExecutionContextExecutorService}

/**
Do not delete!
    Notes -
    1. For REFERENCE_SCHEMA, the convention we are following is - in queries, we rename the &REFERENCE_SCHEMA..<tableName> to REFERENCE_SCHEMA_<tableName> and have dependsOn(REFERENCE_SCHEMA_<tableName>) as well.
    For REFERENCE_SCHEMA_<tableName> to be available at runtime, we set LoadFromHive(tableName = <tableName>, referenceName = Some(REFERENCE_SCHEMA_<tableName>), hiveDatabase = "nameOf_REFERENCE_SCHEMA_hive_db") -> this will cause
    nameOf_REFERENCE_SCHEMA_hive_db.<tableName> to be loaded by the name of REFERENCE_SCHEMA_<tableName>, which is then available as a dependency to queries. Why the change? No way for runtime to figure out whether the table name mentioned in
    dependsOn belongs to REFERENCE_SCHEMA or main hive db.

    2. In cases where an ETL has a dependency on a view and that view in turn is populated from a table that is an ETL itself, the runtime has no way to trigger the ETL that populates the view. In such cases, we have two options - either change the
    original ETL to not depend on view but on underlying table itself OR have an ETL scala file by the name of that view and drop the hive view from ddl as a manual change. Prefer former option in case original ETL is complex or in manual section and
    latter when original ETL is simple or autoconverted successfully - to prevent moving the auto converted query to manual section.
 **/

object EtlLoader {

  private val logger = LoggerFactory.getLogger(this.getClass)

  val dailyL5Tables: Set[String] = OpaTableRegistry.getDailyRepL5Tables

  def main(args: Array[String]): Unit = {
    import com.optum.oap.utils.CliUtils._

    val conf = new Conf(args)
    logger.warn(conf.toString)
    val executionThreads = conf.executorThreads()

    implicit val executionContext: ExecutionContextExecutorService = ExecutionContext.fromExecutorService(Executors.newFixedThreadPool(executionThreads))
    val sparkSession: SparkSession = SparkUtils.createSparkSession("oadw-loader", verboseLogging = false, logWarnings = true)

    val runtimeVariables = getRunTimeVariables(conf)
    val targetTables = getOptionalSeq(conf.targetTables.map(table => table.toUpperCase()))
    val l234TargetTables = if (targetTables.isDefined) Option(targetTables.get.filterNot(table => table.contains("L5"))) else None
    val l5TargetTables = if (targetTables.isDefined) Option(targetTables.get.filter(table => table.contains("L5"))) else None
    val baseOutputPath = conf.baseFilePath.getOrElse(getBaseOutputPath(runtimeVariables))
    val loader = new DataLoader(baseOutputPath)
    val oadwSourceDB = runtimeVariables.oadwHiveDb
    val partitionMultiplier = conf.partitionMultiplier()

    conf.loadDate.toOption match {
      case Some(s: String) => System.setProperty("loadDate", s)
      case _ => None
    }

    val initialData = L5Dependencies.get(oadwSourceDB, runtimeVariables.epsilonOadwHiveDb.getOrElse(oadwSourceDB))
    // The if condition should execute when target tables is empty or target tables contain any L5 tables.
    // It should not execute when target tables contain only L234 tables.
    if (!runtimeVariables.l234Only && (targetTables.isEmpty || l5TargetTables.get.nonEmpty)) {
      logger.warn(" == Starting ETL Tree Processing")
      loadData(loader, sparkSession, initialData, runtimeVariables, l5TargetTables, partitionMultiplier)
      logger.warn(" == Finished ETL Tree Processing")
    }

    if (targetTables.isEmpty || runtimeVariables.l234Only || l234TargetTables.get.nonEmpty) {
      logger.warn(" == Starting L234 Column ordering")
      L234Loader.loader(runtimeVariables, baseOutputPath, sparkSession, partitionMultiplier, l234TargetTables)
      logger.warn(" == Finished L234 Column ordering")
    }
  }

  def loadData(dataLoader: DataLoader[Nothing], session: SparkSession,
               initialData: Seq[TableInfo[_ <: Product with Serializable]],
               runtimeVariables: OPAEtlRuntimeVariables,
               targetTables: Option[Seq[String]] = None,
               partitionMultiplier: Double = DataLoader.DEFAULT_PARTITION_MULTIPLIER,
               allTables: Seq[TableInfo[_ <: Product with Serializable]] = OpaTableRegistry.getAllL5Classes)(implicit ec: ExecutionContext): Seq[String] = {
    val udfs = OADefinedFunctionsRegistry.ALL_UDFS

    val mappedUDFs = udfs.map(oa => {
      logger.info(s"Registering UDF: ${oa.name}")
      oa.registerMe(session)
      oa
    }).toSeq

    val tableMap = DataLoader.tableInfoSeqToMap(allTables).values.toSeq ++ initialData

    val defaultSet: Set[String] = if (runtimeVariables.epsilonOnly && targetTables.isEmpty) {
      dailyL5Tables
    } else {
      Set.empty
    }

    val filteredTables = DataLoader.filterAllTablesByTarget(tableMap, targetTables.map(_.toSet).getOrElse(defaultSet))
    dataLoader.loadData(filteredTables, session, mappedUDFs, runtimeVariables, partitionMultiplier)
    filteredTables.map(table => table.name)
  }

  private def getRunTimeVariables(inputArgsConf: Conf): OPAEtlRuntimeVariables = {
    OPAEtlRuntimeVariables(
      baseFilePath = inputArgsConf.baseFilePath.getOrElse(s"/optum/data-factory/${inputArgsConf.clientId()}/${inputArgsConf.environment()}/opa/${inputArgsConf.oadwHiveDb()}/${inputArgsConf.dateTimeStamp()}/default"),
      oadwHiveDb = inputArgsConf.oadwHiveDb(),
      epsilonOadwHiveDb = inputArgsConf.epsilonOadwHiveDb.toOption,
      epsilonOnly = inputArgsConf.epsilonOnly(),
      clientId = inputArgsConf.clientId(),
      environment = inputArgsConf.environment(),
      dateTimeStamp = inputArgsConf.dateTimeStamp(),
      l234Only = inputArgsConf.l234Only(),
      partitionMultiplier = inputArgsConf.partitionMultiplier(),
      executorThreads = inputArgsConf.executorThreads(),
      s3Bucket = inputArgsConf.s3Bucket.toOption
    )
  }

  private def getBaseOutputPath(runtimeVariables: OPAEtlRuntimeVariables): String = {
    if (runtimeVariables.s3Bucket.isEmpty)
      s"/optum/data_factory/${runtimeVariables.clientId}/${runtimeVariables.environment}/opa/${runtimeVariables.oadwHiveDb}/${runtimeVariables.dateTimeStamp}/default"
    else
      s"s3://${runtimeVariables.s3Bucket.get}/${runtimeVariables.clientId}/${runtimeVariables.clientId}_${runtimeVariables.dateTimeStamp}"
  }
}

class Conf(arguments: Seq[String]) extends ScallopConf(arguments) {
  banner(
    """
      |Usage: ./oadw-loader.sh --clientId [clientId] --environment [env] [--oadwHiveDb oadw_db] [--epsilonOadwHiveDb] [--epsilonOnly] [--targetTables <tables,comma,separated>] [--baseFilePath <path starting at /optum/data-factory, ending at slash before model name>]"
      |Options:
    """.stripMargin)
  val baseFilePath: ScallopOption[String] = opt[String](required = false, name = "baseFilePath", argName = "baseFilePath", descr = "(optional) specifcy a specific base path for parquet file destination. default is the path generated by the rest of the config")
  val oadwHiveDb: ScallopOption[String] = opt[String](required = true, name = "oadwHiveDb", argName = "oadwHiveDb", descr = "(required) Source Hive DB of the OADW instance from which to build OPA Reporting Schema")
  val epsilonOadwHiveDb: ScallopOption[String] = opt[String](required = false, name = "epsilonOadwHiveDb", argName = "epsilonOadwHiveDb", descr = "(optional) EOADW Hive DB name")
  val epsilonOnly: ScallopOption[Boolean] = opt[Boolean](required = false, name = "epsilonOnly", argName = "epsilonOnly", descr = "(optional) run for EOADW only (implies l234Only)", default = Some(false))
  val l234Only: ScallopOption[Boolean] = opt[Boolean](required = false, name = "l234Only", argName = "l234Only", descr = "(optional) don't run L5, only the L234 import", default = Some(false))
  val clientId: ScallopOption[String] = opt[String](required = true, name = "clientId", argName = "clientId", descr = "(required) OADW ClientId e.g. H704847")
  val environment: ScallopOption[String] = opt[String](required = true, name = "environment", argName = "environment", descr = "(required) Environment (dev|prod|qa|stg)")
  val targetTables: ScallopOption[String] = opt[String](required = false, name = "targetTables", argName = "targetTables", descr = "(optional) Comma delimited list of OADW tables. When specified, oadw-loader will trigger the etl(s) related to the provided table(s) only.")
  val dateTimeStamp: ScallopOption[String] = opt[String](required = true, name = "dateTimeStamp", argName = "dateTimeStamp", descr = "(required) Date timestamp for output file path")
  val executorThreads: ScallopOption[Int] = opt[Int](required = false, name = "executorThreads", argName = "executorThreads", descr = "(optional) Number of threads for ETL futures (default: 5)", default = Some(5))
  val partitionMultiplier: ScallopOption[Double] = opt[Double](required = false, name = "partitionMultiplier", argName = "partitionMultiplier", default = Some(DataLoader.DEFAULT_PARTITION_MULTIPLIER), descr = "Multiplies the number of partitions used for each table. Use to increase parallelism for very large clients.")
  val loadDate: ScallopOption[String] = opt[String](required = false, name = "loadDate", argName = "loadDate", descr = "date to override current date in ETL logic")
  val s3Bucket:ScallopOption[String] = opt[String](required = false, name = "s3Bucket", argName = "s3Bucket", descr= "(optional) s3Bucket to store output parquet files")
  dependsOnAll(epsilonOnly, List(epsilonOadwHiveDb)) // If epsilonOnly is true, epsilonOadwHiveDb should be passed
  verify()
}
