package com.optum.df.opa.L5

import com.optum.df.opa.models.L5.l5_dict_day_date_thru
import com.optum.oap.sparkdataloader.{RuntimeVariables, UserDefinedFunctionForDataLoader}
import com.optum.oadw.oadwModels.{l2_ii_map_date_range, md_oadw_instance}
import org.apache.spark.sql.functions._
import org.apache.spark.sql.types.{IntegerType, ShortType}
import org.apache.spark.sql.{DataFrame, SparkSession}

import java.sql.Date

/*
The L5_DICT_DAY_DATE_THRU takes input md_oadw_instance and l2_ii_map_date_range table.
The transformation generates a date range of 428 days,
having the end window as 2 months plus the date from the md_oadw_instance table having attribute_name as "datethru" .
The generated date_range is then joined with the l2_ii_map_date_range on yrmonth to calculate the rolling_timeframe_id and the year_to_date_id metrics.

Source query:
  https://som-bb.humedica.net/projects/OAP/repos/oap-mstr-db-interface/browse/src/main/resources/src/build/L5/pre/l5_dict_day_date_thru_insert.sql

Redshift Schema:
  opa_util/src/main/resources/OPADDL/L5/tables/L5_DICT_DAY_DATE_THRU.sql
 */

object L5_DICT_DAY_DATE_THRU extends L5TableInfo[l5_dict_day_date_thru] {

  override def name: String = "L5_DICT_DAY_DATE_THRU"

  override def dependsOn: Set[String] = Set("MD_OADW_INSTANCE", "L2_II_MAP_DATE_RANGE")

  def createDataFrameWithoutDDL(sparkSession: SparkSession, loadedDependencies: Map[String, DataFrame], udfMap: Map[String, UserDefinedFunctionForDataLoader], runtimeVariables: RuntimeVariables): DataFrame = {

    import sparkSession.implicits._

    val md_oadw_instance = loadedDependencies("MD_OADW_INSTANCE")
    val l2_ii_map_date_range = loadedDependencies("L2_II_MAP_DATE_RANGE")

    /*
    Rolling month includes 3 month from date_thru ( which is data_thru + 2 months )
     */
    val date_thru = md_oadw_instance
      .where(lower($"attribute_name") ===  lit("data_thru"))
      .select(add_months(to_date($"attribute_value","yyyyMMdd"),2)
      .as("datethru"))

    val date_thru_value =
      if (date_thru.head(1).nonEmpty)
        date_thru.first().getAs[Date]("datethru")
      else {
        throw new IllegalStateException("L5_DICT_DAY_DATE_THRU: MD_OADW_INSTANCE MUST have a DATA_THRU row. Job cannot complete")
      }

    /*
     Transformation for creating date range from the previous output for 428 days
     */

    val all_dates = sparkSession.range(428).toDF("row_num")
      .withColumn("datethru", lit(date_thru_value))
      .withColumn("date_id", to_date(expr("date_add(datethru, -row_num)")))
      .withColumn("yr_month", concat(year($"date_id"), lpad(month($"date_id"), 2, "0")))

    /*
     Calculation for rolling_timeframe_id and year_to_date_id
     */
    all_dates.as("allDates")
      .join(l2_ii_map_date_range.as("mdr"),$"mdr.yr_month" === $"allDates.yr_month".cast("Integer"),"left")
      .select($"date_id",
        $"allDates.yr_month".cast(IntegerType),
        $"year_mth_id".cast(ShortType),
        when($"date_id" > add_months($"datethru", -3), lit(1))
          .when($"date_id" > add_months($"datethru", -5), lit(2))
          .when($"date_id" > add_months($"datethru", -8), lit(3))
          .when($"date_id" > add_months($"datethru", -14), lit(4))
          .otherwise(lit(0))
          .cast(ShortType)
          .as("rolling_timeframe_id"),
        when(year($"date_id") === year($"datethru") || year($"date_id") === year(add_months($"datethru", -2)), lit(1))
          .otherwise(lit(0)
          )
          .cast(ShortType)
          .as("year_to_date_id")
      )
  }


}
