package com.optum.df.opa.L5

import com.optum.df.opa.models.L5.l5_ii_dict_contract_lv1
import com.optum.oap.sparkdataloader.{RuntimeVariables, UserDefinedFunctionForDataLoader}
import com.optum.oadw.oadwModels.l2_ii_map_contract
import org.apache.spark.sql.functions._
import org.apache.spark.sql.{DataFrame, SparkSession}

object L5_II_DICT_CONTRACT_LV1 extends L5TableInfo[l5_ii_dict_contract_lv1] {
  override def name: String = "L5_II_DICT_CONTRACT_LV1"

  override def dependsOn: Set[String] = Set("L2_II_MAP_CONTRACT")


  def createDataFrameWithoutDDL(sparkSession: SparkSession, loadedDependencies: Map[String, DataFrame], udfMap: Map[String, UserDefinedFunctionForDataLoader], runtimeVariables: RuntimeVariables): DataFrame = {
    import sparkSession.implicits._

    val l2IIMapContract = loadedDependencies("L2_II_MAP_CONTRACT")

    l2IIMapContract.select(
      coalesce($"contract_lv1_id", $"contract_lv2_id", $"contract_id").as("contract_lv1_id"),
      coalesce($"contract_lv1_desc", $"contract_lv2_desc", $"contract_desc").as("contract_lv1_desc")
    ).distinct()
  }
}
