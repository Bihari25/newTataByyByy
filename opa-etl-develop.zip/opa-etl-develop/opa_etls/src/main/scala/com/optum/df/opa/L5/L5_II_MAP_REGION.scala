package com.optum.df.opa.L5

import com.optum.df.opa.models.L5.l5_ii_map_region
import com.optum.oap.sparkdataloader.{RuntimeVariables, UserDefinedFunctionForDataLoader}
import org.apache.spark.sql.functions.lit
import org.apache.spark.sql.{DataFrame, SparkSession}

object L5_II_MAP_REGION extends L5TableInfo[l5_ii_map_region] {
  override def name: String = "L5_II_MAP_REGION"
  override def dependsOn: Set[String] = Set("L2_DICT_ZIP")

  def createDataFrameWithoutDDL(sparkSession: SparkSession, loadedDependencies: Map[String, DataFrame], udfMap: Map[String, UserDefinedFunctionForDataLoader], runtimeVariables: RuntimeVariables): DataFrame = {
    import sparkSession.implicits._

    val l2DictZip = loadedDependencies("L2_DICT_ZIP")

    val tempL5IiMapRegion = l2DictZip.select(
      $"cens_reg_id".as("cens_reg"),
      $"cens_reg_desc"
    ).distinct()

    val zeroIdExists: Boolean = tempL5IiMapRegion.where($"cens_reg_id" === lit(-1)).count > 0

    val l5IiMapRegion = if (zeroIdExists) tempL5IiMapRegion else tempL5IiMapRegion.union(Seq((-1, "Unknown")).toDF())

    l5IiMapRegion

  }
}
