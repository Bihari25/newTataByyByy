package com.optum.df.opa.L5

import com.optum.df.opa.models.L5.l5_dict_assessment
import com.optum.oap.sparkdataloader.{RuntimeVariables, UserDefinedFunctionForDataLoader}
import org.apache.spark.sql.types.ShortType
import org.apache.spark.sql.{DataFrame, SparkSession}
import org.apache.spark.sql.functions.when


object L5_DICT_ASSESSMENT extends L5TableInfo[l5_dict_assessment] {
  override def name: String = "L5_DICT_ASSESSMENT"

  override def dependsOn: Set[String] = Set("L2_DICT_ASSESSMENT")
  def createDataFrameWithoutDDL(sparkSession: SparkSession, loadedDependencies: Map[String, DataFrame], udfMap: Map[String, UserDefinedFunctionForDataLoader], runtimeVariables: RuntimeVariables): DataFrame = {
    import sparkSession.implicits._

    val l2DictAssessment = loadedDependencies("L2_DICT_ASSESSMENT")

    l2DictAssessment
      .select(
        $"assessment_cui",
        $"assessment_name",
        $"assessment_units",
        $"lab_ind".cast(ShortType),
        when($"lab_ind" === 1, "Labs")
          .otherwise("Observations").as("lab_ind_desc"),
        $"qualitative_ind".cast(ShortType),
        $"quantitative_ind".cast(ShortType),
        $"sensitive_ind".cast(ShortType)
      )
  }
}