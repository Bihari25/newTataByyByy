package com.optum.df.opa.L5

import com.optum.df.opa.models.L5.l5_dict_assess_qual_value
import com.optum.oap.sparkdataloader.{RuntimeVariables, UserDefinedFunctionForDataLoader}
import org.apache.spark.sql.{DataFrame, SparkSession}
import org.apache.spark.sql.functions.{concat, lit}
import org.apache.spark.sql.types.ShortType


object L5_DICT_ASSESS_QUAL_VALUE extends L5TableInfo[l5_dict_assess_qual_value] {
  override def name: String = "L5_DICT_ASSESS_QUAL_VALUE"

  override def dependsOn: Set[String] = Set("L2_DICT_ASSESSMENT", "L2_DICT_ASSESS_QUAL_VALUE")
  def createDataFrameWithoutDDL(sparkSession: SparkSession, loadedDependencies: Map[String, DataFrame], udfMap: Map[String, UserDefinedFunctionForDataLoader], runtimeVariables: RuntimeVariables): DataFrame = {
    import sparkSession.implicits._

    val l2DictAssessment = loadedDependencies("L2_DICT_ASSESSMENT")
    val l2DictAssessQualValue = loadedDependencies("L2_DICT_ASSESS_QUAL_VALUE")

    l2DictAssessment.as("da")
      .join(l2DictAssessQualValue.as("daqv"), $"da.assessment_cui" === $"daqv.assessment_cui")
      .select(
        $"daqv.value_cui",
        $"daqv.value_name",
        $"daqv.assessment_cui",
        $"da.assessment_name",
        concat($"da.assessment_name", lit(" "), $"daqv.value_name").as("description"),
        $"da.sensitive_ind".cast(ShortType)
      )
  }
}