package com.optum.df.opa.L5

import com.optum.df.opa.models.L5.l5_date_log
import com.optum.oap.sparkdataloader.{RuntimeVariables, UserDefinedFunctionForDataLoader}
import com.optum.oadw.oadwModels.md_oadw_instance
import org.apache.spark.sql.functions.{add_months, date_format, to_date}
import org.apache.spark.sql.{DataFrame, SparkSession}
import org.apache.spark.sql.functions._

object L5_DATE_LOG extends L5TableInfo[l5_date_log] {
  override def name: String = "L5_DATE_LOG"

  override def dependsOn: Set[String] = Set("MD_OADW_INSTANCE")

  def createDataFrameWithoutDDL(sparkSession: SparkSession, loadedDependencies: Map[String, DataFrame], udfMap: Map[String, UserDefinedFunctionForDataLoader], runtimeVariables: RuntimeVariables): DataFrame = {

    import sparkSession.implicits._

    val mdOADWInstance = loadedDependencies("MD_OADW_INSTANCE")

    mdOADWInstance.select(
        to_date($"attribute_value", "yyyyMMdd").as("data_thru"),
        add_months(to_date($"attribute_value", "yyyyMMdd"), -39).as("cutoff_date"),
        date_format(add_months(to_date($"attribute_value", "yyyyMMdd"), -39), "yyyyMM").cast("Int").as("cutoff_year_mth"),
        current_date().as("data_load_date"))
      .where(lower($"attribute_name")===lit("data_thru"))
  }
}
