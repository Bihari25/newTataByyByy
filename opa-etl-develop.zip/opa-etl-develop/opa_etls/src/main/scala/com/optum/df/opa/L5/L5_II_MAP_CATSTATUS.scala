package com.optum.df.opa.L5

import com.optum.df.opa.models.L5.l5_ii_map_catstatus
import com.optum.oap.sparkdataloader.{RuntimeVariables, UserDefinedFunctionForDataLoader}
import org.apache.spark.sql.types.ShortType
import org.apache.spark.sql.{DataFrame, SparkSession}


object L5_II_MAP_CATSTATUS extends L5TableInfo[l5_ii_map_catstatus] {
  override def name: String = "L5_II_MAP_CATSTATUS"

  override def dependsOn: Set[String] = Set("L2_II_MAP_CATSTATUS")
  def createDataFrameWithoutDDL(sparkSession: SparkSession, loadedDependencies: Map[String, DataFrame], udfMap: Map[String, UserDefinedFunctionForDataLoader], runtimeVariables: RuntimeVariables): DataFrame = {
    import sparkSession.implicits._

    val l2IiMapCatstatus = loadedDependencies("L2_II_MAP_CATSTATUS")

    l2IiMapCatstatus
      .select(
        $"cat_status".cast(ShortType),
        $"cat_status_desc"
    ).distinct()
  }
}