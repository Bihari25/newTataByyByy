package com.optum.df.opa.L5

import com.optum.df.opa.models.L5.l5_ii_dict_prod_lv2
import com.optum.oap.sparkdataloader.{RuntimeVariables, UserDefinedFunctionForDataLoader}
import com.optum.oadw.oadwModels.l2_ii_map_product
import org.apache.spark.sql.functions._
import org.apache.spark.sql.{DataFrame, SparkSession}

object L5_II_DICT_PROD_LV2 extends L5TableInfo[l5_ii_dict_prod_lv2]{
  override def name:String = "L5_II_DICT_PROD_LV2"

  override def dependsOn: Set[String] = Set("L2_II_MAP_PRODUCT")

  def createDataFrameWithoutDDL(sparkSession: SparkSession, loadedDependencies: Map[String, DataFrame], udfMap: Map[String, UserDefinedFunctionForDataLoader], runtimeVariables: RuntimeVariables): DataFrame = {
    import sparkSession.implicits._

    val l2IIMapProduct = loadedDependencies("L2_II_MAP_PRODUCT")

    l2IIMapProduct.select(
      coalesce($"product_lv2_id", $"product_id").as("product_lv2_id"),
      coalesce($"product_lv2_desc", $"product_desc").as("product_lv2_desc")
    ).distinct()
  }
}
