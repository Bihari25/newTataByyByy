package com.optum.df.opa.L5

import com.optum.df.opa.models.L5.l5_ii_ocu_conf_count
import com.optum.oap.sparkdataloader.{RuntimeVariables, UserDefinedFunctionForDataLoader}
import com.optum.oadw.oadwModels.{l2_ii_map_account, l2_ii_mem_attr}
import org.apache.spark.sql.functions._
import org.apache.spark.sql.types.ShortType
import org.apache.spark.sql.{DataFrame, SparkSession}

object L5_II_OCU_CONF_COUNT extends L5TableInfo[l5_ii_ocu_conf_count]{
  override def name: String = "L5_II_OCU_CONF_COUNT"

  override def dependsOn: Set[String] = Set("L2_II_OCU_CONF_COUNT", "L2_II_MEM_ATTR", "L2_II_MAP_ACCOUNT")

  def createDataFrameWithoutDDL(sparkSession: SparkSession, loadedDependencies: Map[String, DataFrame], udfMap: Map[String, UserDefinedFunctionForDataLoader], runtimeVariables: RuntimeVariables): DataFrame = {
    import sparkSession.implicits._

    val l2IIOcuConfCount = loadedDependencies("L2_II_OCU_CONF_COUNT")
    val l2IIMemAttr = loadedDependencies("L2_II_MEM_ATTR")
    val l2IIMapAccount = loadedDependencies("L2_II_MAP_ACCOUNT")

    l2IIOcuConfCount.as("cc")
      .join(l2IIMemAttr.as("ma"),$"cc.mem_attr_id" === $"ma.member_attr_id", "inner")
      .join(l2IIMapAccount.as("mac"), $"ma.account_id" === $"mac.account_id", "inner")
      .select(
        $"year_mth_id".cast(ShortType),
        $"year_mth_pd".cast(ShortType),
        $"mem_attr_id",
        when($"provider_id".isNull, "0")
          .otherwise($"provider_id").as("provider_id"),
        when($"pcp_assign".isNull, "0")
          .otherwise($"pcp_assign").as("pcp_assign"),
        when($"pcp_imp".isNull, "0")
          .otherwise($"pcp_imp").as("pcp_imp"),
        when($"drg_id".isNull, "Unsp$UNK")
          .otherwise($"drg_id").as("drg_id"),
        when($"drg_admittyp".isNull, "UNK")
          .otherwise($"drg_admittyp").as("drg_admittyp"),
        when($"POA1".isNull, "U")
            .otherwise($"POA1").as("POA"),
        when($"lag_ind" === lit(true), 1).otherwise(lit(0)).cast(ShortType).as("lag_ind"),
        $"lag_months",
        $"admit",
        $"los",
        $"readmit_07",
        $"readmit_30",
        $"readmit_60",
        $"readmit_90",
        $"readmit_index_07",
        $"readmit_index_30",
        $"readmit_index_60",
        $"readmit_index_90",
        $"rrisk",
        coalesce($"mac.account_lv1_id", $"mac.account_lv2_id", $"mac.account_id").as("account_lv1_id"),
        coalesce($"mac.account_lv2_id", $"mac.account_id").as("account_lv2_id"),
        $"mac.account_id".as("account_id")
      )
  }
}
