package com.optum.df.opa.L5

import com.optum.df.opa.models.L5.l5_event_readmission_cms
import com.optum.oap.sparkdataloader.{RuntimeVariables, UserDefinedFunctionForDataLoader}
import org.apache.spark.sql.functions._
import org.apache.spark.sql.types.{DateType, IntegerType, LongType, ShortType}
import org.apache.spark.sql.{DataFrame, SparkSession}

/**
  * Source query:
  * https://som-bb.humedica.net/projects/OAP/repos/oap-mstr-db-interface/browse/src/main/resources/src/build/L5/etl/OPA/L5_EVENT_READMISSION_CMS.sql
  *
  * Redshift Schema: opa_util/src/main/resources/OPADDL/L5/tables/L5_EVENT_READMISSION_CMS.sql
  */

object L5_EVENT_READMISSION_CMS extends L5TableInfo[l5_event_readmission_cms] {
  override def name: String = "L5_EVENT_READMISSION_CMS"

  override def dependsOn: Set[String] = Set("L3_EVENT_READMISSION", "L5_DICT_DAY_DATE_THRU", "L5_DATE_LOG")

  def createDataFrameWithoutDDL(sparkSession: SparkSession, loadedDependencies: Map[String, DataFrame], udfMap: Map[String, UserDefinedFunctionForDataLoader], runtimeVariables: RuntimeVariables): DataFrame = {
    import sparkSession.implicits._

    val l3EventReadmission = loadedDependencies("L3_EVENT_READMISSION")
    val l5DictDayDateThru = loadedDependencies("L5_DICT_DAY_DATE_THRU")
    val cutoff_date = loadedDependencies("L5_DATE_LOG").select($"cutoff_date").head.get(0)

    if (cutoff_date == null) {
      throw new IllegalStateException("L5_EVENT_READMISSION_CMS: L5_DATE_LOG MUST have atleast one row with cutoff_date. Job cannot complete")
    }

    val l5DictDayDateThru_cpy = l5DictDayDateThru.select($"date_id".as("date_id1"),
      $"rolling_timeframe_id".as("rolling_timeframe_id1"),
      $"year_to_date_id".as("year_to_date_id1"))

    l3EventReadmission.as("er")
      .join(l5DictDayDateThru.as("dt"), $"er.idx_end_dtm".cast(DateType) === $"dt.date_id", "left_outer")
      .join(l5DictDayDateThru_cpy.as("rt"), $"er.readm_start_dtm".cast(DateType) === $"rt.date_id1", "left_outer")
      .where($"readmission_type_cui" === lit("CH001654") and $"idx_end_dtm".cast(DateType) > cutoff_date)
      .select($"er.client_id",
        $"er.mpi",
        $"er.event_set_cd",
        $"er.idx_event_id",
        $"er.readmission_type_cui",
        $"er.days_to_readmit".cast(ShortType),
        $"er.idx_end_dtm",
        year($"er.idx_end_dtm").cast(ShortType).as("idx_end_year"),
        date_format($"er.idx_end_dtm", "yyyyMM").cast(IntegerType).as("idx_end_yearmonth"),
        coalesce($"er.idx_hosp_site_id", lit(-1)).cast(LongType).as("idx_hosp_site_id"),
        coalesce($"er.idx_prov_id", lit(0)).as("idx_prov_id"),
        coalesce($"er.idx_drg_id", lit(0)).as("idx_drg_id"),
        coalesce($"er.idx_apr_drg_id", lit(0)).as("idx_apr_drg_id"),
        coalesce($"er.idx_prindx_codetype", lit("0")).as("idx_prindx_codetype"),
        coalesce($"er.idx_prindx", lit("0")).as("idx_prindx"),
        coalesce($"er.idx_prindx_sensitive_ind", lit(0)).cast(ShortType).as("idx_prindx_sensitive_ind"),
        coalesce($"er.idx_prinpx_codetype", lit("0")).as("idx_prinpx_codetype"),
        coalesce($"er.idx_prinpx", lit("0")).as("idx_prinpx"),
        coalesce($"er.idx_prinpx_sensitive_ind", lit(0)).cast(ShortType).as("idx_prinpx_sensitive_ind"),
        coalesce($"er.idx_disch_prov_id", lit("0")).as("idx_disch_prov_id"),
        $"er.idx_cds_grp",
        $"er.elig_days".cast(ShortType),
        $"er.elig_30_ind".cast(ShortType),
        $"er.readm_30_ind".cast(ShortType),
        $"er.elig_60_ind".cast(ShortType),
        $"er.readm_60_ind".cast(ShortType),
        $"er.elig_90_ind".cast(ShortType),
        $"er.readm_90_ind".cast(ShortType),
        $"er.readm_event_id",
        $"er.readm_start_dtm",
        year($"er.readm_start_dtm").cast(ShortType).alias("readm_start_year"),
        date_format($"er.readm_start_dtm", "yyyyMM").cast(IntegerType).as("readm_start_yearmonth"),
        coalesce($"er.readm_hosp_site_id", lit(-1)).cast(LongType).as("readm_hosp_site_id"),
        coalesce($"er.readm_prov_id", lit("0")).as("readm_prov_id"),
        coalesce($"er.readm_drg_id", lit(0)).as("readm_drg_id"),
        coalesce($"er.readm_apr_drg_id", lit(0)).as("readm_apr_drg_id"),
        coalesce($"er.readm_prindx_codetype", lit(0)).as("readm_prindx_codetype"),
        coalesce($"er.readm_prindx", lit(0)).as("readm_prindx"),
        coalesce($"er.readm_prindx_sensitive_ind", lit(0)).cast(ShortType).as("readm_prindx_sensitive_ind"),
        $"er.readm_cds_grp",
        coalesce($"dt.rolling_timeframe_id", lit(0)).cast(ShortType).as("disch_rolling_timeframe_id"),
        coalesce($"dt.year_to_date_id", lit(0)).cast(ShortType).as("disch_year_to_date_id"),
        coalesce($"rt.rolling_timeframe_id1", lit(0)).cast(ShortType).as("readm_rolling_timeframe_id"),
        coalesce($"rt.year_to_date_id1", lit(0)).cast(ShortType).as("readm_year_to_date_id")
      )
  }
}
