package com.optum.df.opa.L5

import com.optum.df.opa.models.L5.l5_ii_ocu_epi_costs
import com.optum.oap.sparkdataloader.{RuntimeVariables, UserDefinedFunctionForDataLoader}
import org.apache.spark.sql.functions.{coalesce, lit, when}
import org.apache.spark.sql.types.ShortType
import org.apache.spark.sql.{DataFrame, SparkSession}

/**
  * Source query:
  * https://som-bb.humedica.net/projects/OAP/repos/oap-mstr-db-interface/browse/src/main/resources/src/build/L5/etl/OPA/L5_ii_ocu_epi_costs_insert.sql
  *
  * Redshift Schema: opa_util/src/main/resources/OPADDL/L5/tables/L5_II_OCU_EPI_COSTS.sql
  */


object L5_II_OCU_EPI_COSTS extends L5TableInfo[l5_ii_ocu_epi_costs] {


  override def name: String = "L5_II_OCU_EPI_COSTS"

  override def dependsOn: Set[String] = Set("L2_II_MAP_TOS", "L2_II_OCU_EPI_COSTS", "L2_II_MEM_ATTR", "L2_II_MAP_ACCOUNT", "L4_MAP_TOS5_CUSTOM")

  def createDataFrameWithoutDDL(sparkSession: SparkSession, loadedDependencies: Map[String, DataFrame], udfMap: Map[String, UserDefinedFunctionForDataLoader], runtimeVariables: RuntimeVariables): DataFrame = {
    import sparkSession.implicits._

    val l2IiMapTos = loadedDependencies("L2_II_MAP_TOS")
    val l2IiOcuEpiCosts = loadedDependencies("L2_II_OCU_EPI_COSTS")
    val l2IiMemAttr = loadedDependencies("L2_II_MEM_ATTR")
    val l2IiMapAccount = loadedDependencies("L2_II_MAP_ACCOUNT")
    val l4MapTos5Custom = loadedDependencies("L4_MAP_TOS5_CUSTOM")

    val tos =
      l2IiMapTos.as("tos")
      .join(l4MapTos5Custom.as("cus"), $"tos.tos_i_5" === $"cus.tos_i_5", "left_outer")
      .select(
            $"tos.tos_i_5",
            $"tos.tos1_id",
            coalesce($"cus.tos_custom_id", lit(3399999)).as("tos_custom_id")
      )

      l2IiOcuEpiCosts.as("ec")
      .join(tos.as("tos"), $"ec.tos_i_5" === $"tos.tos_i_5", "left_outer")
      .join(l2IiMemAttr .as("ma"), $"ec.mem_attr_id" === $"ma.member_attr_id")
      .join(l2IiMapAccount.as("mac"), $"ma.account_id" === $"mac.account_id")
      .select(
      $"ec.year_mth_id".cast(ShortType),
      $"ec.mem_attr_id",
      coalesce($"ec.provider_id", lit("0")).as("provider_id"),
      coalesce($"ec.etg_id", lit(0)).as("etg_id"),
      coalesce($"ec.etg_resp_prov",lit("0")).as("etg_resp_prov"),
      coalesce($"ec.sev_level", lit(0)).cast(ShortType).as("sev_level"),
      $"ec.tx_ind".cast(ShortType),
      coalesce($"ec.pcp_assign", lit("0")).as("pcp_assign"),
      coalesce($"ec.pcp_imp", lit("0")).as("pcp_imp"),
      coalesce($"ec.drg_id",lit("Unsp$UNK")).as("drg_id"),
      coalesce($"ec.pos_i", lit(0)).cast(ShortType).as("pos_i"),
      coalesce($"ec.prv_sp_4", lit(999)).as("prv_sp_4"),
      $"ec.tos_i_5",
      $"tos.tos_custom_id",
      $"tos.tos1_id",
      $"ec.outlier".cast(ShortType),
        when($"ec.complete" === lit(true), 1).otherwise(lit(0)).cast(ShortType).as("complete"),
        when($"ec.network_status" === lit(true), 1).otherwise(lit(0)).cast(ShortType).as("network_status"),
      $"ec.cost1",
      $"ec.cost2",
      $"ec.cost3",
      $"ec.cost4",
      $"ec.cost5",
      $"ec.cost6",
      $"ec.encounter",
      $"ec.em_svc_flag",
      $"ec.rad_util",
      $"ec.lab_util",
      $"ec.mri_util",
      $"ec.er_util",
      $"ec.los",
      $"ec.admit",
      $"ec.script",
      $"ec.amt_pay_adj",
      $"ec.amt_eqv_adj",
        when($"ec.lag_ind" === lit(true), 1).otherwise(lit(0)).cast(ShortType).as("lag_ind"),
      $"ec.lag_months",
      coalesce($"ec.proccode",lit("UNK")).as("proccode"),
      coalesce($"mac.account_lv1_id", $"mac.account_lv2_id", $"mac.account_id").as("account_lv1_id"),
      coalesce($"mac.account_lv2_id", $"mac.account_id").as("account_lv2_id"),
      $"mac.account_id",
      $"ec.network_paid_status_id",
      $"ec.provider_status_id",
      $"ec.script_adj",
      $"ec.th_flag".cast(ShortType).as("th_flag"),
      $"ec.covid_flag".cast(ShortType).as("covid_flag")
    )
  }
}
