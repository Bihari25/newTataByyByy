package com.optum.df.opa

import org.apache.spark.sql.Column
import org.apache.spark.sql.DataFrame
import org.apache.spark.sql.functions.{from_utc_timestamp,to_utc_timestamp,expr}
import org.slf4j.LoggerFactory
import java.util.regex.{Pattern, Matcher}

object DataFrameExtensions {
  private val logger = LoggerFactory.getLogger(this.getClass)

  implicit class RichDataFrame(val dataframe: DataFrame) {
    import org.apache.spark.sql.types._

    def castToBigDecimal(columns: String*): DataFrame = {
      castHelper(columns.toSet, "decimal", DecimalType(38, 18))
    }

    def castToDouble(columns: String*): DataFrame = {
      castHelper(columns.toSet, "decimal", DoubleType)
    }

    def castToLong(columns: String*): DataFrame = {
      castHelper(columns.toSet, "decimal", LongType)
    }

    def castToBigDecimal(columns: Set[String]): DataFrame = {
      castHelper(columns, "decimal", DecimalType(38, 18))
    }

    def castToDouble(columns: Set[String]): DataFrame = {
      castHelper(columns, "decimal", DoubleType)
    }

    def castToLong(columns: Set[String]): DataFrame = {
      castHelper(columns, "decimal", LongType)
    }

    private def castHelper(columns: Set[String], sourceType: String, targetType: DataType): DataFrame = {
      if (columns.isEmpty) {
        dataframe
      } else {
        val lowercaseColumns = columns.map(_.toLowerCase)
        val updatedColumns = dataframe.schema.map(field => {
          if (field.dataType.typeName.toLowerCase.startsWith(sourceType.toLowerCase) && lowercaseColumns.contains(field.name.toLowerCase)) {
            dataframe.col(field.name).cast(targetType)
          } else {
            dataframe.col(field.name)
          }
        })

        dataframe.select(updatedColumns: _*)
      }
    }
    
    def checkTypes(types: Seq[String]) {
     dataframe.schema.fields.zip(types).foreach(tup => {
       val dfType = tup._1.dataType
       val columnName = tup._1.name
       val redshiftType = tup._2.replace(" ", "").toLowerCase()
       val ok = dfType match {
         case s: StringType => redshiftType.startsWith("varchar") || redshiftType.startsWith("char")
         case d: DecimalType => {
           val replaceDecimal = redshiftType.replace("decimal", "DecimalType") 
           val dfTypeStr = dfType.toString()
          
           replaceDecimal == dfTypeStr || replaceDecimal.replace(")", ",0)") == dfTypeStr
         }
         case i: IntegerType => redshiftType == "integer"
         case s: ShortType => redshiftType == "smallint"
         case b: LongType => redshiftType == "bigint"
         case _ => true
       }
       if (!ok) {
         logger.warn(s"Type mismatch for column ${columnName} dataframe type = ${dfType} Redshift type = ${redshiftType}")
       }
     })
   }
    
    // workaround for redshift COPY to Timestamp column 
    // if you want to COPY a time like "12:34" into TIMESTAMP from Parquet, the Parquet
    // field must be "12:34 *UTC*" to behave like inserting '12:34'::timestamp or copying from CSV. 
    // our de facto standard, though, is that logical time 12:34 is stored in OADW as 12:34 *EDT* 
    //  thus to get correct results from Redshift we have to convert 12:34 EDT to 12:34 UTC
    def adjustTimestampForRedshift() : DataFrame = {
      fixDatesHelper(from_utc_timestamp)
    }

    def revertRedshiftAdjustment() : DataFrame = {
      fixDatesHelper(to_utc_timestamp)
    }

    private def fixDatesHelper(func: (Column, String) => Column) : DataFrame = {
      dataframe.schema.fields.foldLeft(dataframe)((df, field) =>
        field.dataType match {
          case t: TimestampType => {
            val timezone = dataframe.sparkSession.conf.get("spark.sql.session.timeZone")
            df.withColumn(field.name, func(df.col(field.name), timezone))
          }
          case _ => df
        }
      )
    }

    //(octet_length($columnName) > length($columnName)) is used to check if a string has a multibyte character.
    //(octet_length($columnName) > $redshiftLength) is used to check if there is a overflow.
    def truncateVarcharColumns(columnsMap: Map[String, String]): DataFrame = {
      dataframe.schema.fields.foldLeft(dataframe)((df, field) =>
        field.dataType match {
          case s: StringType => {
            val columnName = field.name.toLowerCase
            val redshiftColumnType = columnsMap(columnName).replace(" ", "").toLowerCase

            if (redshiftColumnType.startsWith("varchar")) {
              val m = Pattern.compile("\\((.*?)\\)").matcher(redshiftColumnType)
              val redshiftLength = if (m.find) m.group(1).toInt else 256

              logger.warn(s"processing varchar column - $columnName")
              df.withColumn(columnName,
                expr(s"case when (octet_length($columnName) > length($columnName) and octet_length($columnName) > $redshiftLength) " +
                  s"then substring($columnName, 0, length($columnName) - (octet_length($columnName) - $redshiftLength)) " +
                  s"else $columnName " +
                  s"end"))
            }
            else df
          }
          case _ => df
        }
      )
    }
  }
}
