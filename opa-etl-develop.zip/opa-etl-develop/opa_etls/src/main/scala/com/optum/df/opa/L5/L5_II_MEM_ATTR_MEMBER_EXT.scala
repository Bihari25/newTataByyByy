package com.optum.df.opa.L5

import com.optum.df.opa.models.L5.l5_ii_mem_attr_member_ext
import com.optum.oap.sparkdataloader.{RuntimeVariables, UserDefinedFunctionForDataLoader}
import org.apache.spark.sql.functions._
import org.apache.spark.sql.types.ShortType
import org.apache.spark.sql.{DataFrame, SparkSession}


object L5_II_MEM_ATTR_MEMBER_EXT extends L5TableInfo[l5_ii_mem_attr_member_ext] {

  override def name: String = "L5_II_MEM_ATTR_MEMBER_EXT"

  override def dependsOn: Set[String] = Set("L2_II_MEM_ATTR_MEMBER_EXT", "L5_DICT_DAY_DATE_THRU")

  def createDataFrameWithoutDDL(sparkSession: SparkSession, loadedDependencies: Map[String, DataFrame],
                                udfMap: Map[String, UserDefinedFunctionForDataLoader],
                                mapRuntimeVariables: RuntimeVariables): DataFrame = {

    import sparkSession.implicits._

    val l2IiMemAttrMemberAttrExt = loadedDependencies("L2_II_MEM_ATTR_MEMBER_EXT")
    val l5DictDayDateThru = loadedDependencies("L5_DICT_DAY_DATE_THRU")
    val l5DictMonthDateThru = l5DictDayDateThru.select($"yr_month", $"year_mth_id", $"rolling_timeframe_id", $"year_to_date_id").distinct()

    l2IiMemAttrMemberAttrExt.as("ma")
      .join(l5DictMonthDateThru.as("dt"), $"ma.year_mth_id" === $"dt.year_mth_id", "left")
      .select($"ma.member",
        $"ma.year_mth_id",
        $"ma.member_attr_id",
        $"ma.mpg_def_id",
        coalesce($"ma.pcp_assign", lit("0")).as("pcp_assign"),
        $"ma.rx",
        $"ma.med",
        $"ma.sex",
        $"ma.zip",
        $"ma.county_id",
        $"ma.age",
        $"ma.mem_eff_dt",
        $"ma.mem_end_dt",
        $"ma.subscriber_id",
        $"ma.ia_time",
        $"ma.account_id",
        $"ma.age_cat2",
        $"ma.biz_segment_id",
        $"ma.benefit_plan_id",
        $"ma.cat_status_cost3",
        $"ma.cat_status",
        $"ma.contract_type_id",
        $"ma.coverage_status_id",
        $"ma.coverage_class",
        $"ma.industry",
        $"ma.iatime_lag",
        coalesce($"ma.product_id", lit("Unspecified$UNK")).as("product_id"),
        $"ma.mem_userdef_1_id",
        $"ma.mem_userdef_2_id",
        $"ma.mem_userdef_3_id",
        $"ma.mem_userdef_4_id",
        coalesce($"ma.pcp_imp", lit("0")).as("pcp_imp"),
        $"ma.sub_eff_dt",
        $"ma.sub_end_dt",
        $"ma.last_enroll",
        $"ma.med_qual",
        $"ma.phm_qual",
        $"ma.mm",
        $"ma.mm_rx",
        $"ma.subscr_months",
        $"ma.premium_tot",
        $"ma.prisk",
        $"ma.rrisk",
        coalesce($"ma.contract_id", lit("Unspecified$UNK")).as("contract_id"),
        $"ma.new_mem_attr_id",
        coalesce($"dt.rolling_timeframe_id", lit(0)).cast(ShortType).as("rolling_timeframe_id"),
        coalesce($"dt.year_to_date_id", lit(0)).cast(ShortType).as("year_to_date_id"))
  }
}
