package com.optum.df.opa.L5

import com.optum.df.opa.models.L5.l5_ii_map_prov_affil
import com.optum.oap.sparkdataloader.{RuntimeVariables, UserDefinedFunctionForDataLoader}
import org.apache.spark.sql.types.ShortType
import org.apache.spark.sql.functions._
import org.apache.spark.sql.{DataFrame, SparkSession}

object L5_II_MAP_PROV_AFFIL extends L5TableInfo[l5_ii_map_prov_affil] {
  override def name: String = "L5_II_MAP_PROV_AFFIL"
  override def dependsOn: Set[String] = Set("L2_II_MAP_PROV_AFFIL")

  def createDataFrameWithoutDDL(sparkSession: SparkSession, loadedDependencies: Map[String, DataFrame], udfMap: Map[String, UserDefinedFunctionForDataLoader], runtimeVariables: RuntimeVariables): DataFrame = {
    import sparkSession.implicits._

    val l2IiMapProvAffil = loadedDependencies("L2_II_MAP_PROV_AFFIL")
    val defaultRow = Seq(("Unspecified$UNK", "UNK", "Unspecified", "Unspecified", "Unspecified LV1", "Unspecified", "Unspecified LV1", "Unspecified LV2", "Unspecified", "Unspecified LV1#Unspecified LV2", 1.toShort)).toDF()

    val tempL5IiMapProvAffil = l2IiMapProvAffil.select(
      coalesce($"affil_id", lit("Unspecified$UNK")).as("affil_id"),
      $"map_srce_p",
      coalesce($"prov_affil", lit("Unspecified")).as("prov_affil"),
      $"prov_affil_desc",
      coalesce($"prov_affil_lv1", lit("Unspecified LV1")).as("prov_affil_lv1"),
      $"prov_affil_lv1_desc",
      $"prov_affil_lv1_id",
      coalesce($"prov_affil_lv2", lit("Unspecified LV2")).as("prov_affil_lv2"),
      $"prov_affil_lv2_desc",
      $"prov_affil_lv2_id",
      $"riflag".cast(ShortType)
    ).distinct()

    val unspecifiedIdExists: Boolean = tempL5IiMapProvAffil.where($"affil_id" === lit("Unspecified$UNK")).count > 0

    val l5IiMapProvAffil = if (unspecifiedIdExists) tempL5IiMapProvAffil else tempL5IiMapProvAffil.union(defaultRow)

    l5IiMapProvAffil
  }
}