package com.optum.df.opa.L5

import com.optum.df.opa.models.L5.l5_benchmk_phrmcy_numer_dtl
import com.optum.oap.sparkdataloader.{RuntimeVariables, UserDefinedFunctionForDataLoader}
import org.apache.spark.sql.types.{DecimalType, IntegerType, ShortType}
import org.apache.spark.sql.{DataFrame, SparkSession}


/**
  * Source query:
  * https://som-bb.humedica.net/projects/OAP/repos/oap-mstr-db-interface/browse/src/main/resources/src/build/L5/etl/OPA/L5_benchmk_phrmcy_numer_dtl_insert.sql
  *
  * Redshift Schema: opa_util/src/main/resources/OPADDL/L5/tables/L5_BENCHMK_PHRMCY_NUMER_DTL.sql
  */
object L5_BENCHMK_PHRMCY_NUMER_DTL extends L5TableInfo[l5_benchmk_phrmcy_numer_dtl] {
  override def name: String = "L5_BENCHMK_PHRMCY_NUMER_DTL"

  override def dependsOn: Set[String] = Set("L2_BMK_PHM_NUM_DETAIL", "L2_II_MAP_TOS")

  def createDataFrameWithoutDDL(sparkSession: SparkSession, loadedDependencies: Map[String, DataFrame], udfMap: Map[String, UserDefinedFunctionForDataLoader], runtimeVariables: RuntimeVariables): DataFrame = {
    import org.apache.spark.sql.functions._
    import sparkSession.implicits._

    val l2BenchmkPhrmcyNumerDtl = loadedDependencies("L2_BMK_PHM_NUM_DETAIL")
    val l2IiMapTos = loadedDependencies("L2_II_MAP_TOS")

    l2BenchmkPhrmcyNumerDtl.as("pn")
      .join(l2IiMapTos.as("mt"), Seq("tos_i_5"))
      .groupBy($"year", $"age_cat2", $"sex", $"cens_reg", $"tos1_id", $"tos2_id", $"tos3_id", $"tos_i_5", $"gbo", $"channel")
      .agg(
        round(sum($"amt_np"),2).as("amt_np"),
        sum($"script").as("script"),
        sum($"generic").as("generic"),
        sum($"script_gen").as("script_gen"),
        sum($"days_sup").as("days_sup"),
        lit("Y").as("dummy_email")
      )
      .select(
        $"age_cat2".cast(ShortType).as("age_cat2"),
        $"year".cast(ShortType),
        $"sex".cast(ShortType),
        $"cens_reg".cast(ShortType),
        $"tos1_id",
        $"tos2_id",
        $"tos3_id",
        $"tos_i_5",
        $"gbo".cast(ShortType),
        $"channel",
        $"amt_np".cast(DecimalType(19, 2)),
        $"script".cast(IntegerType),
        $"generic".cast(IntegerType),
        $"script_gen".cast(IntegerType),
        $"days_sup".cast(IntegerType),
        $"dummy_email"
      )
    }
}
