package com.optum.df.opa.L5

import com.optum.df.opa.models.L5.l5_ii_severity_level
import com.optum.oap.sparkdataloader.{RuntimeVariables, UserDefinedFunctionForDataLoader}
import org.apache.spark.sql.functions._
import org.apache.spark.sql.types.ShortType
import org.apache.spark.sql.{DataFrame, SparkSession}

object L5_II_SEVERITY_LEVEL extends L5TableInfo[l5_ii_severity_level] {
  override def name: String = "L5_II_SEVERITY_LEVEL"

  override def dependsOn: Set[String] = Set("L2_II_MAP_ETG_SEV","L2_II_OCU_PEG_EPI_COUNT","L2_II_OCU_PEG_EPI_COSTS")
  def createDataFrameWithoutDDL (sparkSession:SparkSession,loadedDependencies:Map[String,DataFrame],udfMap:Map[String,UserDefinedFunctionForDataLoader],runtimeVariables:RuntimeVariables):DataFrame={
    import sparkSession.implicits._

    val l2IiMapEtgSev = loadedDependencies("L2_II_MAP_ETG_SEV")
    val l2IiOcuPegEpiCount = loadedDependencies("L2_II_OCU_PEG_EPI_COUNT")
    val l2IiOcuPegEpiCosts = loadedDependencies("L2_II_OCU_PEG_EPI_COSTS")

    val distinctMapEtgSevLevel = l2IiMapEtgSev.select(
      $"sev_level"
    ).distinct()

    val distinctPegEpiCountSevLevel = l2IiOcuPegEpiCount.select(
      $"peg_sev_level".as("sev_level")
    ).distinct()

    val distinctPegEpiCostsSevLevel = l2IiOcuPegEpiCosts.select(
      $"peg_sev_level".as("sev_level")
    ).distinct()

    val defaultRow = Seq((0.toShort, "Unknown Severity")).toDF()

    val distinctSevLevel = distinctMapEtgSevLevel.union(distinctPegEpiCountSevLevel).union(distinctPegEpiCostsSevLevel).distinct.where($"sev_level".isNotNull)

    distinctSevLevel.select(
      $"sev_level".cast(ShortType),
      concat(lit("Severity Level "), $"sev_level").as("sev_level_desc")
    ).union(defaultRow)
  }
}