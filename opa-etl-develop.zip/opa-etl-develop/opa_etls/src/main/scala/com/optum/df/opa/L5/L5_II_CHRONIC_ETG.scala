package com.optum.df.opa.L5

import com.optum.df.opa.models.L5.l5_ii_chronic_etg
import com.optum.oap.sparkdataloader.{RuntimeVariables, UserDefinedFunctionForDataLoader}
import org.apache.spark.sql.{DataFrame, SparkSession}


object L5_II_CHRONIC_ETG extends L5TableInfo[l5_ii_chronic_etg] {
  override def name: String = "L5_II_CHRONIC_ETG"

  override def dependsOn: Set[String] = Set.empty

  def createDataFrameWithoutDDL(sparkSession: SparkSession, loadedDependencies: Map[String, DataFrame], udfMap: Map[String, UserDefinedFunctionForDataLoader], runtimeVariables: RuntimeVariables): DataFrame = {
    import sparkSession.implicits._

    Seq((0.toShort, "Not Chronic"),
      (1.toShort, "Chronic"),
      (-1.toShort, "Unknown"))
      .toDF("chronic","chronic_desc")
  }
}