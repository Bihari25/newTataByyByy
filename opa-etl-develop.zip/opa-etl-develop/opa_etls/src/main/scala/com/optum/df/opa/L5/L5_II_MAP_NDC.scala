package com.optum.df.opa.L5

import com.optum.df.opa.models.L5.l5_ii_map_ndc
import com.optum.oap.sparkdataloader.{RuntimeVariables, UserDefinedFunctionForDataLoader}
import org.apache.spark.sql.types.ShortType
import org.apache.spark.sql.{DataFrame, SparkSession}
import org.apache.spark.sql.functions.lit

object L5_II_MAP_NDC extends L5TableInfo[l5_ii_map_ndc] {
  override def name: String = "L5_II_MAP_NDC"

  override def dependsOn: Set[String] = Set("L2_II_MAP_NDC", "L3_OCU_POP_PHM_COSTS")
  def createDataFrameWithoutDDL (sparkSession:SparkSession,loadedDependencies:Map[String,DataFrame],udfMap:Map[String,UserDefinedFunctionForDataLoader],runtimeVariables:RuntimeVariables):DataFrame={
    import sparkSession.implicits._

    val l2IiMapNdc = loadedDependencies("L2_II_MAP_NDC")
    val l3OcuPopPhmCosts = loadedDependencies("L3_OCU_POP_PHM_COSTS")
    val defaults = Seq((0, "Unknown NDC", null, null, null, 0.toShort)).toDF()

    val tempL2IiMapNdc = l2IiMapNdc
      .where($"ndc" =!= "0")
      .select(
        $"ndc",
        $"ndc_desc",
        $"brand_name",
        $"brand_name_mask",
        $"dcc",
        $"sensitive_ind".cast(ShortType)
      )

    val tempL3OcuPopPhmCosts = l3OcuPopPhmCosts.as("o")
      .join(tempL2IiMapNdc.as("m"), $"o.ndc" === $"m.ndc", "left_anti")
      .where($"o.ndc" =!= "0" && $"o.ndc".isNotNull)
      .select(
        $"o.ndc",
        $"o.ndc".as("ndc_desc"),
        lit(null),
        lit(null),
        lit(null),
        lit(0).cast(ShortType)
      ).distinct()

    tempL2IiMapNdc
      .union(tempL3OcuPopPhmCosts)
      .union(defaults)
  }
}