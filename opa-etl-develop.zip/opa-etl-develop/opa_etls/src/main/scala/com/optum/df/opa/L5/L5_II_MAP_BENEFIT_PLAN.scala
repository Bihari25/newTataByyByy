package com.optum.df.opa.L5

import com.optum.df.opa.models.L5.l5_ii_map_benefit_plan
import com.optum.oap.sparkdataloader.{RuntimeVariables, UserDefinedFunctionForDataLoader}
import com.optum.oadw.oadwModels.l2_ii_map_benefit_plan
import org.apache.spark.sql.functions.{coalesce, when}
import org.apache.spark.sql.types.ShortType
import org.apache.spark.sql.{DataFrame, SparkSession}

object L5_II_MAP_BENEFIT_PLAN extends L5TableInfo[l5_ii_map_benefit_plan]{
  override def name: String = "L5_II_MAP_BENEFIT_PLAN"

  override def dependsOn: Set[String] = Set("L2_II_MAP_BENEFIT_PLAN")

  def createDataFrameWithoutDDL(sparkSession: SparkSession, loadedDependencies: Map[String, DataFrame], udfMap: Map[String, UserDefinedFunctionForDataLoader], runtimeVariables: RuntimeVariables): DataFrame = {
    import sparkSession.implicits._

    val l2IIMapBenefitPlan = loadedDependencies("L2_II_MAP_BENEFIT_PLAN")

    l2IIMapBenefitPlan.select(
      $"benefit_plan_id",
      $"benefit_plan",
      $"benefit_plan_desc",
      when($"benefit_plan_lv2_id".isNull, $"benefit_plan_id").otherwise($"benefit_plan_lv2_id").as("benefit_plan_lv2_id"),
      coalesce($"benefit_plan_lv2", $"benefit_plan").as("benefit_plan_lv2"),
      when($"benefit_plan_lv2_desc".isNull, $"benefit_plan_desc").otherwise($"benefit_plan_lv2_desc").as("benefit_plan_lv2_desc"),
      coalesce($"benefit_plan_lv1_id", $"benefit_plan_lv2_id", $"benefit_plan_id").as("benefit_plan_lv1_id"),
      coalesce($"benefit_plan_lv1", $"benefit_plan_lv2", $"benefit_plan").as("benefit_plan_lv1"),
      coalesce($"benefit_plan_lv1_desc", $"benefit_plan_lv2_desc", $"benefit_plan_desc").as("benefit_plan_lv1_desc"),
      $"map_srce_e",
      $"riflag".cast(ShortType)
    )
  }
}
