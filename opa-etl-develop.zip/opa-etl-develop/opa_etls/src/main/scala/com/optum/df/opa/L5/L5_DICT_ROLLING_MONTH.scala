package com.optum.df.opa.L5

import com.optum.df.opa.models.L5.l5_dict_rolling_month
import org.apache.spark.sql.functions.date_format
import com.optum.oap.sparkdataloader.{RuntimeVariables, UserDefinedFunctionForDataLoader}
import org.apache.spark.sql.{DataFrame, SparkSession}


object L5_DICT_ROLLING_MONTH extends L5TableInfo[l5_dict_rolling_month] {

  override def name: String = "L5_DICT_ROLLING_MONTH"

  override def dependsOn: Set[String] = Set("L5_DATE_LOG", "L5_II_MAP_DATE_RANGE")


  override def createDataFrameWithoutDDL(sparkSession: SparkSession, loadedDependencies: Map[String, DataFrame], udfMap: Map[String, UserDefinedFunctionForDataLoader], runtimeVariables: RuntimeVariables): DataFrame = {
    import sparkSession.implicits._

    val l5DateLog = loadedDependencies("L5_DATE_LOG")
    val l5IiMapDateRange = loadedDependencies("L5_II_MAP_DATE_RANGE")
    val cutoff_year_mth = l5DateLog.select($"cutoff_year_mth").head.get(0)
    val data_thru_year_mth = l5DateLog.select(date_format($"data_thru","yyyyMM").cast("Int")).head.get(0)

    l5IiMapDateRange.as("mda")
      .join(l5IiMapDateRange.as("mdb"),$"mdb.yr_month" > ($"mda.yr_month" - 100) && $"mdb.yr_month" <= $"mda.yr_month")
      .where($"mda.yr_month".between(cutoff_year_mth, data_thru_year_mth))
      .select($"mda.yr_month".as("month_id"),
        $"mdb.yr_month".as("roll_month_id"),
        $"mda.year_mth_id",
        $"mdb.year_mth_id".as("roll_year_mth_id")
      )
  }
}