package com.optum.df.opa.L5


import com.optum.df.opa.models.L5.{l5_dict_facility}
import com.optum.oap.sparkdataloader.{RuntimeVariables, TableInfo, UserDefinedFunctionForDataLoader}
import org.apache.spark.sql.functions._
import org.apache.spark.sql.{DataFrame, SparkSession}

object L5_DICT_FACILITY extends L5TableInfo[l5_dict_facility] {

  override def name: String = "L5_DICT_FACILITY"

  override def dependsOn: Set[String] = Set("L2_II_PROVINFO", "L2_DICT_SPEC", "L3_OCU_POP_COSTS")

  def createDataFrameWithoutDDL(sparkSession: SparkSession, loadedDependencies: Map[String, DataFrame], udfMap: Map[String, UserDefinedFunctionForDataLoader], runtimeVariables: RuntimeVariables): DataFrame = {
    import sparkSession.implicits._

    val l2_ii_provinfo = loadedDependencies("L2_II_PROVINFO")
    val l2_dict_spec = loadedDependencies("L2_DICT_SPEC")
    val l3_ocu_pop_cost = loadedDependencies("L3_OCU_POP_COSTS")

    val facilityProvInfo = l2_ii_provinfo.as("provinfo")
      .join(l2_dict_spec.as("ds"),
        $"provinfo.prv_sp_4" === $"ds.prv_sp_4" && $"ds.sp1_id" === lit(1),
        "inner")
      .select(
        $"provinfo.provider_id".as("facility_id"),
        $"provinfo.provider_name".as("facility_name"),
        $"ds.sp3_id".as("facility_type_id")
      )

    val unknownFacility = Seq(("0", "Non-Facility", 0)).toDF()

    l3_ocu_pop_cost.as("popcost")
      .join(l2_dict_spec.as("ds"),
        $"popcost.prv_sp_4" === $"ds.prv_sp_4" && $"ds.sp1_id" === lit(1),
        "inner")
      .join(facilityProvInfo.as("fpi"),
        $"popcost.provider_id" === $"fpi.facility_id",
        "leftanti")
      .select($"popcost.provider_id".as("facility_id"),
        concat(lit("Facility:"), $"popcost.provider_id").as("facility_name"),
        lit(0).as("facility_type_id"))
      .distinct()
      .union(facilityProvInfo)
      .union(unknownFacility)
  }
}