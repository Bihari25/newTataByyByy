package com.optum.df.opa.L5

import com.optum.df.opa.models.L5.l5_ii_ocu_peg_epi_count
import com.optum.oap.sparkdataloader.{RuntimeVariables, UserDefinedFunctionForDataLoader}
import org.apache.spark.sql.functions.{coalesce, lit, when}
import org.apache.spark.sql.types.ShortType
import org.apache.spark.sql.{DataFrame, SparkSession}

object L5_II_OCU_PEG_EPI_COUNT extends L5TableInfo[l5_ii_ocu_peg_epi_count] {
  override def name: String = "L5_II_OCU_PEG_EPI_COUNT"
  override def dependsOn: Set[String] = Set("L2_II_OCU_PEG_EPI_COUNT")

  def createDataFrameWithoutDDL(sparkSession: SparkSession, loadedDependencies: Map[String, DataFrame], udfMap: Map[String, UserDefinedFunctionForDataLoader], runtimeVariables: RuntimeVariables): DataFrame = {
    import sparkSession.implicits._

    val l2IiOcuPegEpiCount = loadedDependencies("L2_II_OCU_PEG_EPI_COUNT")

      l2IiOcuPegEpiCount
      .select($"complete".cast(ShortType),
        when($"disqualified_flag" === lit(true), 1).otherwise(lit(0)).cast(ShortType).as("disqualified_flag"),
        $"laterality",
        $"mem_attr_id",
        $"outlier".cast(ShortType),
        coalesce($"pcp_affil_id", lit("Unspecified$UNK")).as("pcp_affil_id"),
        coalesce($"pcp_assign", lit("0")).as("pcp_assign"),
        coalesce($"pcp_imp", lit("0")).as("pcp_imp"),
        $"peg_cat_id",
        $"peg_epi_qty",
        $"peg_score",
        coalesce($"peg_sev_level", lit(0)).cast(ShortType).as("peg_sev_level"),
        $"rrisk",
        $"year_mth_id".cast(ShortType)
      )
  }
}
