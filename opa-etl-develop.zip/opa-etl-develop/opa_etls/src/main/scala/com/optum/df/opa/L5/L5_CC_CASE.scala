package com.optum.df.opa.L5

import com.optum.df.opa.models.L5._
import com.optum.oap.sparkdataloader.{RuntimeVariables, UserDefinedFunctionForDataLoader}
import org.apache.spark.sql.functions._
import org.apache.spark.sql.types.{DateType, LongType, ShortType}
import org.apache.spark.sql.{DataFrame, SparkSession}

object L5_CC_CASE extends L5TableInfo[l5_cc_case] {
  override def name: String = "L5_CC_CASE"
  override def dependsOn: Set[String] = Set("L1_CC_CASE", "L5_DICT_DAY_DATE_THRU", "L5_DATE_LOG")

  def createDataFrameWithoutDDL(sparkSession: SparkSession, loadedDependencies: Map[String, DataFrame], udfMap: Map[String, UserDefinedFunctionForDataLoader], runtimeVariables: RuntimeVariables): DataFrame = {
    import sparkSession.implicits._

    val l1CcCase = loadedDependencies("L1_CC_CASE")
    val l5DictDayDateThru = loadedDependencies("L5_DICT_DAY_DATE_THRU")
    val cutOffDate = loadedDependencies("L5_DATE_LOG").select($"cutoff_date").head.get(0)

    l1CcCase.as("cc")
      .join(l5DictDayDateThru.as("d"), $"cc.patient_enrolled_dt".cast(DateType) === $"d.date_id", "left")
      .where(to_date($"cc.case_created_dt") > cutOffDate && $"cc.mpi".isNotNull)
      .select(
        $"cc.care_coord_assgnd_dt",
        $"cc.care_coord_start_dt",
        coalesce($"cc.care_plan_subtype", lit("Unspecified$UNK")).as("care_plan_subtype"),
        coalesce($"cc.care_plan_type", lit("Unspecified$UNK")).as("care_plan_type"),
        $"cc.care_plan_type_opt_out_dt",
        $"cc.care_plan_type_opt_out_ind",
        $"cc.care_tier",
        $"cc.case_billing_diag_cd",
        $"cc.case_close_rsn",
        $"cc.case_closed_by_id",
        $"cc.case_closed_dt",
        $"cc.case_closed_sys_dtm",
        $"cc.case_created_by_id",
        $"cc.case_created_dt",
        $"cc.case_desc",
        $"cc.case_last_mod_dtm",
        $"cc.case_last_task_edit_dt",
        $"cc.case_nbr",
        $"cc.case_origin_cat",
        $"cc.case_origin_dtl",
        coalesce($"cc.case_owner_id", lit("Unspecified")).as("case_owner_id"),
        $"cc.case_priority",
        $"cc.case_rsn",
        coalesce($"cc.case_status", lit("Unspecified$UNK")).as("case_status"),
        $"cc.case_status_before_closed",
        $"cc.case_subject",
        $"cc.cc_case_id",
        $"cc.client_ds_id",
        $"cc.client_id",
        $"cc.consent_given_dt",
        $"cc.consent_mode",
        $"cc.consent_notes",
        coalesce($"cc.consent_status", lit("Unspecified")).as("consent_status"),
        $"cc.datasrc",
        $"cc.hgpid".cast(LongType),
        $"cc.mpi",
        $"cc.patient_enrolled_dt",
        $"cc.patient_enrolled_ind",
        $"cc.patientid",
        $"cc.record_type_id",
        coalesce($"d.rolling_timeframe_id", lit(0)).cast(ShortType).as("rolling_timeframe_id"),
        coalesce($"d.year_to_date_id", lit(0)).cast(ShortType).as("year_to_date_id")
      )
  }
}
