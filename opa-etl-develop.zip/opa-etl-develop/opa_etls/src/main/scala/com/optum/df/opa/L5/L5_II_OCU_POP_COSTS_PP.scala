package com.optum.df.opa.L5

import com.optum.df.opa.models.L5.l5_ii_ocu_pop_costs_pp
import com.optum.oap.sparkdataloader.{RuntimeVariables, UserDefinedFunctionForDataLoader}
import org.apache.spark.sql.functions._
import org.apache.spark.sql.types.ShortType
import org.apache.spark.sql.{DataFrame, SparkSession}

object L5_II_OCU_POP_COSTS_PP extends L5TableInfo[l5_ii_ocu_pop_costs_pp] {
  override def name: String = "L5_II_OCU_POP_COSTS_PP"
  override def dependsOn: Set[String] = Set("L2_II_OCU_POP_COSTS","L2_II_MEM_ATTR","L2_II_MAP_ACCOUNT","L2_II_MAP_TOS","L4_MAP_TOS5_CUSTOM","L2_II_MAP_PRODUCT","L2_II_MAP_DATE_RANGE","L2_II_MAP_CONTRACT","L2_II_MAP_AT_RISK_STATUS","L2_II_MAP_COUNTY","L2_DICT_SPEC","L2_II_MAP_ETG")

  def createDataFrameWithoutDDL(sparkSession: SparkSession, loadedDependencies: Map[String, DataFrame], udfMap: Map[String, UserDefinedFunctionForDataLoader], runtimeVariables: RuntimeVariables): DataFrame = {
    import sparkSession.implicits._

    val l2IiOcuPopCosts = loadedDependencies("L2_II_OCU_POP_COSTS")
    val l2IiMemAttr = loadedDependencies("L2_II_MEM_ATTR")
    val l2IiMapAccount = loadedDependencies("L2_II_MAP_ACCOUNT")
    val l2IiMapTos = loadedDependencies("L2_II_MAP_TOS")
    val l4MapTos5Custom = loadedDependencies("L4_MAP_TOS5_CUSTOM")
    val l2IiMapProduct = loadedDependencies("L2_II_MAP_PRODUCT")
    val l2iimapdaterange = loadedDependencies("L2_II_MAP_DATE_RANGE")
    val l2IIMapContract = loadedDependencies("L2_II_MAP_CONTRACT")
    val l2IIMapAtRiskStatus = loadedDependencies("L2_II_MAP_AT_RISK_STATUS")
    val l2IIMapCounty = loadedDependencies("L2_II_MAP_COUNTY")
    val l2DictSpec = loadedDependencies("L2_DICT_SPEC")
    val l2iimapetg =  loadedDependencies("L2_II_MAP_ETG")

    val dictSpec = l2DictSpec
      .select(
        $"sp1_id",
        $"prv_sp_4"
      ).distinct()

      l2IiOcuPopCosts.as("pc")
      .join(broadcast(l2IiMapTos).as("tos"), $"pc.tos_i_5" === $"tos.tos_i_5","left")
      .join(broadcast(l4MapTos5Custom).as("cus"), $"tos.tos_i_5" === $"cus.tos_i_5","left")
      .join(l2IiMemAttr.as("ma"), $"pc.mem_attr_id" === $"ma.member_attr_id","inner")
      .join(l2IiMapAccount.as("mac"),$"ma.account_id" === $"mac.account_id","left")
      .join(broadcast(l2IIMapCounty).as("mco"), $"ma.county_id" === $"mco.county_id","left")
      .join(broadcast(l2IIMapContract).as("mc"), $"ma.contract_id" === $"mc.contract_id","left")
      .join(broadcast(l2IIMapAtRiskStatus).as("mr"), $"ma.at_risk_status_id" === $"mr.at_risk_status_id","left")
      .join(broadcast(l2IiMapProduct).as("mp"), $"ma.product_id" === $"mp.product_id","left")
      .join(broadcast(l2iimapdaterange).as("md"), $"pc.year_mth_id" === $"md.year_mth_id","left")
      .join(broadcast(dictSpec).as("spc"), $"pc.prv_sp_4" === $"spc.prv_sp_4","inner")
      .join(broadcast(l2iimapetg).as("me"), $"pc.etg_id" === $"me.etg_id","left")
      .select(
$"md.ia_time",
      $"pc.year_mth_id",
      $"pc.mem_attr_id",
      coalesce($"pc.provider_id", lit("0")).as("provider_id"),
      coalesce($"pc.serv_prov_affil_id", lit("Unspecified$UNK")).as("serv_prov_affil_id"),
      when($"spc.sp1_id" === lit(1), $"pc.provider_id").otherwise(lit("0")).as("facility_id"),
      coalesce($"ma.employee_type_id", lit("Unspecified$UNK")).as("employee_type_id"),
      coalesce($"ma.risk_type_id", lit("Unspecified$UNK")).as("risk_type_id"),
      when($"ma.den" === lit(true), 1).otherwise(lit(0)).cast(ShortType).as("den"),
      coalesce($"pc.sev_level",lit(0)).as("sev_level"),
      coalesce($"pc.pcp_affil_id", lit("Unspecified$UNK")).as("pcp_affil_id"),
      coalesce($"pc.pcp_assign", lit("0")).as("pcp_assign"),
      coalesce($"pc.pcp_imp", lit("0")).as("pcp_imp"),
      coalesce($"pc.drg_id", lit("Unsp$UNK")).as("drg_id"),
      coalesce($"pc.pos_i", lit(0)).cast(ShortType).as("pos_i"),
      coalesce($"pc.prv_sp_4", lit(999)).as("prv_sp_4"),
      $"tos.tos1_id",
      $"tos.tos2_id",
      $"tos.tos3_id",
      $"tos.tos_i_4",
      $"tos.tos_i_5",
      coalesce($"cus.tos_custom_id", lit(3399999)).as("tos_custom_id"),
      $"pc.iatime_lag",
      $"pc.year_mth_pd",
      $"pc.network_status".cast(ShortType).as("network_status"),
      $"pc.network_paid_status_id",
      $"pc.cost1",
      $"pc.cost2",
      $"pc.cost3",
      $"pc.cost4",
      $"pc.cost5",
      $"pc.cost6",
      $"pc.encounter",
      $"pc.em_svc_flag",
      $"pc.rad_util",
      $"pc.lab_util",
      $"pc.mri_util",
      $"pc.er_util",
      $"pc.los",
      $"pc.admit",
      $"pc.script",
      $"pc.amt_req",
      $"pc.amt_eqv",
      $"pc.amt_ded",
      $"pc.amt_coin",
      $"pc.amt_cop",
      $"pc.amt_liab",
      $"pc.amt_cap_pay",
      $"pc.amt_pay_adj",
      $"pc.amt_eqv_adj",
      $"pc.amt_not_covered",
      $"pc.amt_other_carrier_pay",
      $"pc.amt_admin_fee",
      when($"pc.lag_ind" === lit(true), 1).otherwise(lit(0)).cast(ShortType).as("lag_ind"),
      $"pc.lag_months",
      coalesce($"pc.proccode", lit("UNK")).as("proccode"),
      $"ma.age_cat2",
      $"ma.cat_status_cost3",
      $"ma.cat_status",
      $"ma.contract_id",
      $"ma.contract_type_id",
      $"mc.contract_lv1_id",
      $"mc.contract_lv2_id",
      $"ma.county_id",
      $"mco.cens_reg",
      $"mco.state",
      $"ma.sex".cast(ShortType).as("sex"),
      $"mr.at_risk_status_lv1_id",
      $"mr.at_risk_status_lv2_id",
      $"ma.at_risk_status_id",
      $"ma.product_id",
      $"spc.sp1_id",
      coalesce($"pc.etg_id",lit(0)).as("etg_id"),
      coalesce($"me.family",lit(0)).as("family"),
      coalesce($"me.mpc",lit(0)).as("mpc"),
      $"ma.coverage_status_id",
      $"ma.mem_userdef_1_id",
      $"ma.mem_userdef_2_id",
      $"ma.mem_userdef_3_id",
      $"ma.mem_userdef_4_id",
      $"ma.benefit_plan_id",
      $"ma.biz_segment_id",
      $"ma.industry",
      $"ma.mpg_def_id",
      coalesce($"mac.account_lv1_id", $"mac.account_lv2_id", $"mac.account_id").as("account_lv1_id"),
      coalesce($"mac.account_lv2_id", $"mac.account_id").as("account_lv2_id"),
      $"mac.account_id",
      coalesce($"pc.th_flag".cast(ShortType),lit(-1.toShort)).as("th_flag"),
      coalesce($"pc.covid_flag".cast(ShortType),lit(-1.toShort)).as("covid_flag"),
      $"pc.drg_wgt",
      $"pc.script_adj",
      $"pc.provider_status_id"
      )
  }
}
