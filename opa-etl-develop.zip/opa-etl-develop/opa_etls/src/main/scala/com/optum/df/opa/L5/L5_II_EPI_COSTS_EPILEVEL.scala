package com.optum.df.opa.L5

import com.optum.df.opa.models.L5.l5_ii_epi_costs_epilevel
import com.optum.oap.sparkdataloader.{RuntimeVariables, UserDefinedFunctionForDataLoader}
import org.apache.spark.sql.functions._
import org.apache.spark.sql.types.ShortType
import org.apache.spark.sql.{DataFrame, SparkSession}

object L5_II_EPI_COSTS_EPILEVEL extends L5TableInfo[l5_ii_epi_costs_epilevel] {
  override def name: String = "L5_II_EPI_COSTS_EPILEVEL"
  override def dependsOn: Set[String] = Set("L2_II_EPI_COSTS_EPILEVEL", "L2_II_EPISODES", "L5_II_MAP_ETG", "L2_PATIENT_INFO", "L2_II_MAP_PEER", "L2_II_PROVINFO",
      "L2_II_MAP_PROV_AFFIL", "L5_DICT_IA_TIME", "L5_II_SEVERITY_LEVEL", "L5_II_CHRONIC_ETG", "L5_II_MAP_ETG_FAMILY", "L4_MAP_CUI_GENDER")

  def createDataFrameWithoutDDL(sparkSession: SparkSession, loadedDependencies: Map[String, DataFrame], udfMap: Map[String, UserDefinedFunctionForDataLoader], runtimeVariables: RuntimeVariables): DataFrame = {
    import sparkSession.implicits._

    val l2IiEpiCostsEpilevel = loadedDependencies("L2_II_EPI_COSTS_EPILEVEL")
    val l2IiEpisodes = loadedDependencies("L2_II_EPISODES")
    val l5IiMapEtg = loadedDependencies("L5_II_MAP_ETG")
    val l2PatientInfo = loadedDependencies("L2_PATIENT_INFO")
    val l2IiMapPeer = loadedDependencies("L2_II_MAP_PEER")
    val l2IiProvinfo = loadedDependencies("L2_II_PROVINFO")
    val l2IiMapProvAffil = loadedDependencies("L2_II_MAP_PROV_AFFIL")
    val l5DictIaTime = loadedDependencies("L5_DICT_IA_TIME")
    val l5IiSeverityLevel = loadedDependencies("L5_II_SEVERITY_LEVEL")
    val l5IiChronicEtg = loadedDependencies("L5_II_CHRONIC_ETG")
    val l5IiMapEtgFamily = loadedDependencies("L5_II_MAP_ETG_FAMILY")
    val l4MapCuiGender = loadedDependencies("L4_MAP_CUI_GENDER")

    l2IiEpiCostsEpilevel.as("a11")
      .join(l2IiEpisodes.as("a12"), $"a11.episode_id" === $"a12.episode_id")
      .join(l5IiMapEtg.as("a13"), $"a12.etg_id" === $"a13.etg_id")
      .join(l2PatientInfo.as("a14"), $"a12.member" === $"a14.mpi")
      .join(l2IiMapPeer.as("a15"), $"a11.peer_def_id" === $"a15.peer_def_id")
      .join(l2IiProvinfo.as("a16"), $"a11.provider_id" === $"a16.provider_id")
      .join(l2IiMapProvAffil.as("a17"), $"a16.affil_id" === $"a17.affil_id")
      .join(l5DictIaTime.as("a18"), $"a11.ia_time" === $"a18.ia_time")
      .join(broadcast(l5IiSeverityLevel).as("a19"), $"a12.sev_level" === $"a19.sev_level")
      .join(broadcast(l5IiChronicEtg).as("a110"), $"a13.chronic" === $"a110.chronic")
      .join(l5IiMapEtgFamily.as("a111"), $"a13.family" === $"a111.family")
      .join(broadcast(l4MapCuiGender).as("a112"), $"a14.gender_cui" === $"a112.cui")
      .select(
          coalesce($"a11.provider_id", lit("0")).as("provider_id"),
          $"a11.ia_time",
          coalesce($"a11.etg_unit_id", lit(0)).as("etg_unit_id"),
          $"a11.episode_id",
          $"a11.peer_def_id",
          when($"a11.phm_qual" === lit(true), 1).otherwise(lit(0)).cast(ShortType).as("phm_qual"),
          coalesce($"a11.product_id", lit("Unspecified$UNK")).as("product_id"),
          $"a11.epi_qty",
          $"a11.cost_act_tot",
          $"a11.cost2_act_tot",
          $"a11.cost3_act_tot",
          $"a11.enc_act_tot",
          $"a11.pcc_cost_act_tot",
          $"a11.spec_cost_act_tot",
          $"a11.er_cost_act_tot",
          $"a11.rad_cost_act_tot",
          $"a11.rx_cost_act_tot",
          $"a11.lab_cost_act_tot",
          $"a11.hosp_cost_act_tot",
          $"a11.pcc_enc_act_tot",
          $"a11.spec_enc_act_tot",
          $"a11.er_enc_act_tot",
          $"a11.rad_enc_act_tot",
          $"a11.rx_enc_act_tot",
          $"a11.lab_enc_act_tot",
          $"a11.hosp_enc_act_tot",
          $"a11.cost_peer_tot",
          $"a11.cost2_peer_tot",
          $"a11.cost3_peer_tot",
          $"a11.enc_peer_tot",
          $"a11.pcc_cost_peer_tot",
          $"a11.spec_cost_peer_tot",
          $"a11.er_cost_peer_tot",
          $"a11.rad_cost_peer_tot",
          $"a11.rx_cost_peer_tot",
          $"a11.lab_cost_peer_tot",
          $"a11.hosp_cost_peer_tot",
          $"a11.pcc_enc_peer_tot",
          $"a11.spec_enc_peer_tot",
          $"a11.er_enc_peer_tot",
          $"a11.rad_enc_peer_tot",
          $"a11.rx_enc_peer_tot",
          $"a11.lab_enc_peer_tot",
          $"a11.hosp_enc_peer_tot",
          $"a11.spvis_act_tot",
          $"a11.ospvis_act_tot",
          $"a11.script_act_tot",
          $"a11.rad_act_tot",
          $"a11.lab_act_tot",
          $"a11.er_act_tot",
          $"a11.days_act_tot",
          $"a11.mri_act_tot",
          $"a11.gen_act_tot",
          $"a11.admit_act_tot",
          $"a11.script_gen_act_tot",
          $"a11.spvis_peer_tot",
          $"a11.ospvis_peer_tot",
          $"a11.script_peer_tot",
          $"a11.rad_peer_tot",
          $"a11.lab_peer_tot",
          $"a11.er_peer_tot",
          $"a11.days_peer_tot",
          $"a11.mri_peer_tot",
          $"a11.gen_peer_tot",
          $"a11.admit_peer_tot",
          $"a11.epi_pcc_pct",
          $"a11.epi_spec_pct",
          $"a11.epi_er_pct",
          $"a11.epi_rad_pct",
          $"a11.epi_lab_pct",
          $"a11.epi_hosp_pct",
          $"a11.epi_phm_pct",
          $"a11.epi_pcc_pct_adj",
          $"a11.epi_spec_pct_adj",
          $"a11.epi_er_pct_adj",
          $"a11.epi_rad_pct_adj",
          $"a11.epi_lab_pct_adj",
          $"a11.epi_hosp_pct_adj",
          $"a11.epi_phm_pct_adj",
          $"a12.member",
          coalesce($"a12.sev_level", lit(0)).cast(ShortType).as("sev_level"),
          coalesce($"a12.etg_id", lit(0)).as("etg_id"),
          $"a12.epi_to",
          $"a12.epi_from"
      )
  }
}


