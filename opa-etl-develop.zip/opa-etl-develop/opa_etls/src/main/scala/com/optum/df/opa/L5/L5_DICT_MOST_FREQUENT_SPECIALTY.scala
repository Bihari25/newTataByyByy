package com.optum.df.opa.L5

import com.optum.df.opa.models.L5.l5_dict_most_frequent_specialty
import com.optum.oap.sparkdataloader.{RuntimeVariables, UserDefinedFunctionForDataLoader}
import org.apache.spark.sql.functions._
import org.apache.spark.sql.{DataFrame, SparkSession}


object L5_DICT_MOST_FREQUENT_SPECIALTY extends L5TableInfo[l5_dict_most_frequent_specialty] {
  override def name: String = "L5_DICT_MOST_FREQUENT_SPECIALTY"

  override def dependsOn: Set[String] = Set("L5_PAT_PROV_ATTRIB", "L2_DICT_SPEC")
  def createDataFrameWithoutDDL(sparkSession: SparkSession, loadedDependencies: Map[String, DataFrame], udfMap: Map[String, UserDefinedFunctionForDataLoader], runtimeVariables: RuntimeVariables): DataFrame = {
    import sparkSession.implicits._

    val l5PatProvAttrib = loadedDependencies("L5_PAT_PROV_ATTRIB")
    val l2DictSpec = loadedDependencies("L2_DICT_SPEC")

    l5PatProvAttrib.as("ppa")
      .join(l2DictSpec.as("ds"), $"ds.specialty_id" === $"ppa.specialty_id")
      .select(
        $"ppa.prov_attrib_id",
        $"ppa.specialty_id",
        $"ds.sp4"
      ).distinct()
  }
}