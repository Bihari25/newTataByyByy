package com.optum.df.opa.L5

import com.optum.df.opa.models.L5.l5_ii_ocu_pop_costs_contract
import com.optum.oap.sparkdataloader.{RuntimeVariables, UserDefinedFunctionForDataLoader}
import org.apache.spark.sql.functions._
import org.apache.spark.sql.types.{DecimalType, IntegerType, ShortType}
import org.apache.spark.sql.{DataFrame, SparkSession}

object L5_II_OCU_POP_COSTS_CONTRACT extends L5TableInfo[l5_ii_ocu_pop_costs_contract] {
  override def name: String = "L5_II_OCU_POP_COSTS_CONTRACT"
  override def dependsOn: Set[String] = Set("L2_II_OCU_POP_COSTS_CONTRACT","L2_II_MAP_NTWRK_PAID_STATUS","L2_II_MEM_ATTR","L2_II_MAP_ACCOUNT","L2_II_MAP_TOS","L4_MAP_TOS5_CUSTOM")

  def createDataFrameWithoutDDL(sparkSession: SparkSession, loadedDependencies: Map[String, DataFrame], udfMap: Map[String, UserDefinedFunctionForDataLoader], runtimeVariables: RuntimeVariables): DataFrame = {
    import sparkSession.implicits._

    val l2IiOcuPopCostsContract = loadedDependencies("L2_II_OCU_POP_COSTS_CONTRACT")
    val l2MapNtwrkPaidStatus = loadedDependencies("L2_II_MAP_NTWRK_PAID_STATUS")
    val l2IiMemAttr = loadedDependencies("L2_II_MEM_ATTR")
    val l2IiMapAccount = loadedDependencies("L2_II_MAP_ACCOUNT")
    val l2IiMapTos = loadedDependencies("L2_II_MAP_TOS")
    val l4MapTos5Custom = loadedDependencies("L4_MAP_TOS5_CUSTOM")

    l2IiOcuPopCostsContract.as("pc")
      .join(broadcast(l2IiMapTos).as("tos"), $"pc.tos_i_5" === $"tos.tos_i_5", "left")
      .join(l4MapTos5Custom.as("cus"), $"tos.tos_i_5" === $"cus.tos_i_5", "left")
      .join(l2MapNtwrkPaidStatus.as("nps"), $"nps.network_paid_status_id" === $"pc.network_paid_status_id", "left")
      .join(l2IiMemAttr.as("ma"), $"pc.mem_attr_id" === $"ma.member_attr_id")
      .join(l2IiMapAccount.as("mac"), $"ma.account_id" === $"mac.account_id")
      .groupBy(
        $"pc.year_mth_id".cast(ShortType).as("year_mth_id"),
        $"pc.mem_attr_id".as("mem_attr_id"),
        coalesce($"pc.provider_id", lit("0")).as("provider_id"),
        coalesce($"pc.etg_id", lit(0)).as("etg_id"),
        coalesce($"pc.serv_prov_affil_id", lit("Unspecified$UNK")).as("serv_prov_affil_id"),
        coalesce($"pc.sev_level", lit(0)).cast(ShortType).as("sev_level"),
        coalesce($"pc.pcp_affil_id", lit("Unspecified$UNK")).as("pcp_affil_id"),
        coalesce($"pc.pcp_assign", lit("0")).as("pcp_assign"),
        coalesce($"pc.pcp_imp", lit("0")).as("pcp_imp"),
        coalesce($"pc.drg_id", lit("Unsp$UNK")).as("drg_id"),
        coalesce($"pc.pos_i", lit(0)).cast(ShortType).as("pos_i"),
        coalesce($"pc.prv_sp_4", lit(999)).as("prv_sp_4"),
        $"pc.tos_i_5".as("tos_i_5"),
        coalesce($"cus.tos_custom_id", lit(3399999)).as("tos_custom_id"),
        $"tos.tos1_id".as("tos1_id"),
        $"pc.iatime_lag".cast(ShortType).as("iatime_lag"),
        $"pc.year_mth_pd".cast(ShortType).as("year_mth_pd"),
        when($"nps.network_status" === lit(true), 1).otherwise(lit(0)).cast(ShortType).as("network_status"),
        $"pc.em_svc_flag".as("em_svc_flag"),
        $"pc.los".cast(IntegerType).as("los"),
        when($"pc.lag_ind" === lit(true), 1).otherwise(lit(0)).cast(ShortType).as("lag_ind"),
        $"pc.lag_months".as("lag_months"),
        coalesce($"pc.proccode", lit("UNK")).as("proccode"),
        coalesce($"mac.account_lv1_id", $"mac.account_lv2_id", $"mac.account_id").as("account_lv1_id"),
        coalesce($"mac.account_lv2_id", $"mac.account_id").as("account_lv2_id"),
        $"mac.account_id".as("account_id"),
        coalesce($"pc.th_flag".cast(ShortType),lit(-1.toShort)).as("th_flag"),
        coalesce($"pc.covid_flag".cast(ShortType),lit(-1.toShort)).as("covid_flag")
      )
      .agg(
        sum($"pc.encounter").cast(DecimalType(19, 2)).alias("encounter"),
        sum($"pc.rad_util").cast(DecimalType(19, 2)).alias("rad_util"),
        sum($"pc.lab_util").cast(DecimalType(19, 2)).alias("lab_util"),
        sum($"pc.mri_util").cast(DecimalType(19, 2)).alias("mri_util"),
        sum($"pc.er_util").cast(DecimalType(19, 2)).alias("er_util"),
        sum($"pc.amt_np").cast(DecimalType(19, 2)).as("amt_np"),
        sum($"pc.amt_pay").cast(DecimalType(19, 2)).as("amt_pay"),
        sum($"pc.amt_cob").cast(DecimalType(19, 2)).as("amt_cob"),
        sum($"pc.amt_oth1").cast(DecimalType(19, 2)).as("amt_oth1"),
        sum($"pc.amt_oth4").cast(DecimalType(19, 2)).as("amt_oth4"),
        sum($"pc.amt_req").cast(DecimalType(19, 2)).as("amt_req"),
        sum($"pc.amt_eqv").cast(DecimalType(19, 2)).as("amt_eqv"),
        sum($"pc.amt_ded").cast(DecimalType(19, 2)).as("amt_ded"),
        sum($"pc.amt_coin").cast(DecimalType(19, 2)).as("amt_coin"),
        sum($"pc.amt_cop").cast(DecimalType(19, 2)).as("amt_cop"),
        sum($"pc.amt_liab").cast(DecimalType(19, 2)).as("amt_liab"),
        sum($"pc.amt_not_covered").cast(DecimalType(19, 2)).as("amt_not_covered"),
        sum($"pc.amt_other_carrier_pay").cast(DecimalType(19, 2)).as("amt_other_carrier_pay"),
        sum($"pc.amt_admin_fee").cast(DecimalType(19, 2)).as("amt_admin_fee"),
        sum($"pc.amt_cap_pay").cast(DecimalType(19, 2)).as("amt_cap_pay"),
        sum($"pc.admit").cast(IntegerType).as("admit"),
        sum($"pc.script").cast(IntegerType).as("script")
      ).select(
      $"year_mth_id",
      $"mem_attr_id",
      $"provider_id",
      $"etg_id",
      $"serv_prov_affil_id",
      $"sev_level",
      $"pcp_affil_id",
      $"pcp_assign",
      $"pcp_imp",
      $"drg_id",
      $"pos_i",
      $"prv_sp_4",
      $"tos_i_5",
      $"tos_custom_id",
      $"tos1_id",
      $"iatime_lag",
      $"year_mth_pd",
      $"network_status",
      $"amt_np",
      $"amt_pay",
      $"amt_oth1",
      $"amt_cob",
      $"amt_oth4",
      $"encounter",
      $"em_svc_flag",
      $"rad_util",
      $"lab_util",
      $"mri_util",
      $"er_util",
      $"los",
      $"admit",
      $"script",
      $"amt_req",
      $"amt_eqv",
      $"amt_ded",
      $"amt_coin",
      $"amt_cop",
      $"amt_liab",
      $"amt_not_covered",
      $"amt_other_carrier_pay",
      $"amt_admin_fee",
      $"amt_cap_pay",
      $"lag_ind",
      $"lag_months",
      $"proccode",
      $"account_lv1_id",
      $"account_lv2_id",
      $"account_id",
      $"th_flag",
      $"covid_flag"
    )
  }
}
