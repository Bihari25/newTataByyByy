package com.optum.df.opa.L5

import com.optum.df.opa.models.L5.l5_dict_ia_time
import com.optum.oap.sparkdataloader.{RuntimeVariables, UserDefinedFunctionForDataLoader}
import com.optum.oadw.oadwModels.l2_ii_map_date_range
import org.apache.spark.sql.functions._
import org.apache.spark.sql.{DataFrame, SparkSession}

/**
  * Source query:
  * https://som-bb.humedica.net/projects/OAP/repos/oap-mstr-db-interface/browse/src/main/resources/src/build/L5/etl/OPA/L5_dict_ia_time_insert.sql
  *
  * Redshift Schema: opa_util/src/main/resources/OPADDL/L5/tables/L5_DICT_IA_TIME.sql
  */

object L5_DICT_IA_TIME extends L5TableInfo[l5_dict_ia_time] {

  override def name: String = "L5_DICT_IA_TIME"

  override def dependsOn: Set[String] = Set("L2_II_MAP_DATE_RANGE")

  override def createDataFrameWithoutDDL(sparkSession: SparkSession, loadedDependencies: Map[String, DataFrame], udfMap: Map[String, UserDefinedFunctionForDataLoader], runtimeVariables: RuntimeVariables): DataFrame = {

    import sparkSession.implicits._

    val l2iimapdaterange = loadedDependencies("L2_II_MAP_DATE_RANGE")


    l2iimapdaterange.select($"ia_time",
      $"ia_time_code",
      $"ia_time_desc",
      $"ia_time_date_desc",
      $"ia_time_full_desc",
      $"ia_time_start_date",
      $"ia_time_end_date",
      date_format($"ia_time_start_date", "MMM yyyy").as("ia_start_mth_year_desc"),
      date_format($"ia_time_end_date", "MMM yyyy").as("ia_end_mth_year_desc"))
      .distinct()
  }
}