package com.optum.df.opa.L5

import com.optum.df.opa.models.L5.l5_dict_income_band
import com.optum.oap.sparkdataloader.{RuntimeVariables, TableInfo, UserDefinedFunctionForDataLoader}
import org.apache.spark.sql.{DataFrame, SparkSession}

object L5_DICT_INCOME_BAND extends L5TableInfo[l5_dict_income_band]{
  override def name: String = "L5_DICT_INCOME_BAND"

  override def dependsOn: Set[String] = Set.empty

  def createDataFrameWithoutDDL(sparkSession: SparkSession, loadedDependencies: Map[String, DataFrame], udfMap: Map[String, UserDefinedFunctionForDataLoader], runtimeVariables: RuntimeVariables): DataFrame = {
    import sparkSession.implicits._

        Seq(l5_dict_income_band((-1).toShort, "Unknown", null, null),
          l5_dict_income_band(0.toShort, "Less than $10,000", 0, 9999),
          l5_dict_income_band(1.toShort, "$10,000 to $19,999", 10000, 19999),
          l5_dict_income_band(2.toShort, "$20,000 to $29,999", 20000, 29999),
          l5_dict_income_band(3.toShort, "$30,000 to $39,999", 30000, 39999),
          l5_dict_income_band(4.toShort, "$40,000 to $49,999", 40000, 49999),
          l5_dict_income_band(5.toShort, "$50,000 to $59,999", 50000, 59999),
          l5_dict_income_band(6.toShort, "$60,000 to $69,999", 60000, 69999),
          l5_dict_income_band(7.toShort, "$70,000 to $79,999", 70000, 79999),
          l5_dict_income_band(8.toShort, "$80,000 to $89,999", 80000, 89999),
          l5_dict_income_band(9.toShort, "$90,000 to $99,999", 90000, 99999),
          l5_dict_income_band(10.toShort, "$100,000 or more", 100000, 999999999))
          .toDF("inc_band_id","inc_band_desc","inc_band_min","inc_band_max")
  }
}
