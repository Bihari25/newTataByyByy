package com.optum.df.opa.L5

import com.optum.df.opa.models.L5.l5_ii_map_at_risk_status
import com.optum.oap.sparkdataloader.{RuntimeVariables, UserDefinedFunctionForDataLoader}
import org.apache.spark.sql.functions._
import org.apache.spark.sql.types.ShortType
import org.apache.spark.sql.{DataFrame, SparkSession}

object L5_II_MAP_AT_RISK_STATUS extends L5TableInfo[l5_ii_map_at_risk_status]{
  override def name:String = "L5_II_MAP_AT_RISK_STATUS"

  override def dependsOn: Set[String] = Set("L2_II_MAP_AT_RISK_STATUS")

  def createDataFrameWithoutDDL(sparkSession: SparkSession, loadedDependencies: Map[String, DataFrame], udfMap: Map[String, UserDefinedFunctionForDataLoader], runtimeVariables: RuntimeVariables): DataFrame = {
    import sparkSession.implicits._

    val l2IIMapAtRiskStatus = loadedDependencies("L2_II_MAP_AT_RISK_STATUS")
    val defaultRow = Seq(("UNK", "Unspecified$UNK", "Unspecified", "Unspecified", "Unspecified LV1", "Unspecified LV1", "Unspecified", "Unspecified LV1#Unspecified LV2", "Unspecified LV2", "Unspecified", 1.toShort)).toDF()

    val tempL5IiMapAtRiskStatus = l2IIMapAtRiskStatus.select(
      $"map_srce_e",
      $"at_risk_status_id",
      $"at_risk_status",
      $"at_risk_status_desc",
      coalesce($"at_risk_status_lv1_id", $"at_risk_status_lv2_id", $"at_risk_status_id").as("at_risk_status_lv1_id"),
      coalesce($"at_risk_status_lv1", $"at_risk_status_lv2", $"at_risk_status").as("at_risk_status_lv1"),
      coalesce($"at_risk_status_lv1_desc", $"at_risk_status_lv2_desc", $"at_risk_status_desc").as("at_risk_status_lv1_desc"),
      coalesce($"at_risk_status_lv2_id", $"at_risk_status_id").as("at_risk_status_lv2_id"),
      coalesce($"at_risk_status_lv2",$"at_risk_status").as("at_risk_status_lv2"),
      coalesce($"at_risk_status_lv2_desc", $"at_risk_status_desc").as("at_risk_status_lv2_desc"),
      $"riflag".cast(ShortType)
    )

    val unspecifiedIdExists: Boolean = tempL5IiMapAtRiskStatus.where($"at_risk_status_id" === lit("Unspecified$UNK")).count > 0

    val l5IiMapAtRiskStatus = if (unspecifiedIdExists) tempL5IiMapAtRiskStatus else tempL5IiMapAtRiskStatus.union(defaultRow)

    l5IiMapAtRiskStatus
  }
}