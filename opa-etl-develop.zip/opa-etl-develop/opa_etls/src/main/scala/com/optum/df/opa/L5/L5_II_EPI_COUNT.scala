package com.optum.df.opa.L5

import com.optum.df.opa.models.L5.l5_ii_epi_count
import com.optum.oap.sparkdataloader.{RuntimeVariables, UserDefinedFunctionForDataLoader}
import org.apache.spark.sql.functions._
import org.apache.spark.sql.types.ShortType
import org.apache.spark.sql.{DataFrame, SparkSession}

object L5_II_EPI_COUNT extends L5TableInfo[l5_ii_epi_count] {
  override def name: String = "L5_II_EPI_COUNT"
  override def dependsOn: Set[String] = Set("L2_II_EPI_COUNT")

  def createDataFrameWithoutDDL(sparkSession: SparkSession, loadedDependencies: Map[String, DataFrame], udfMap: Map[String, UserDefinedFunctionForDataLoader], runtimeVariables: RuntimeVariables): DataFrame = {
    import sparkSession.implicits._

    val l2IiEpiCount = loadedDependencies("L2_II_EPI_COUNT")

    l2IiEpiCount.as("pc")

      .select(
        coalesce($"pc.provider_id", lit("0")).as("provider_id"),
        coalesce($"pc.PRODUCT_ID", lit("Unspecified$UNK")).as("PRODUCT_ID"),
        $"pc.PEER_DEF_ID",
        $"pc.CAT_MEMBER",
        $"pc.ETG_ID",
        $"pc.ETG_UNIT_ID",
        $"pc.IA_TIME",
        $"pc.IA_TIME_ADJ",
        when($"pc.PHM_QUAL" === lit(true), 1).otherwise(lit(0)).cast(ShortType).as("PHM_QUAL"),
        coalesce($"pc.SEV_LEVEL", lit(0)).cast(ShortType).as("SEV_LEVEL"),
        $"pc.RRISK_EPI_W",
        $"pc.EPI_QTY"
      )
  }
}
