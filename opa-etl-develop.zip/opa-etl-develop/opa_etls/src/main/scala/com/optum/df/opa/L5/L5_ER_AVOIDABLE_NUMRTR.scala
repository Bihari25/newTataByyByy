package com.optum.df.opa.L5

import com.optum.df.opa.models.L5.l5_er_avoidable_numrtr
import com.optum.oap.sparkdataloader.{RuntimeVariables, UserDefinedFunctionForDataLoader}
import org.apache.spark.sql.functions.{lit, _}
import org.apache.spark.sql.types.{IntegerType, ShortType}
import org.apache.spark.sql.{DataFrame, SparkSession}

/**
  * Source query:
  * https://som-bb.humedica.net/projects/OAP/repos/oap-mstr-db-interface/browse/src/main/resources/src/build/L5/etl/OPA/L5_ER_AVOIDABLE_NUMRTR.sql
  *
  * Redshift Schema: opa_util/src/main/resources/OPADDL/L5/tables/L5_ER_AVOIDABLE_NUMRTR.sql
  */
object L5_ER_AVOIDABLE_NUMRTR extends L5TableInfo[l5_er_avoidable_numrtr] {

  override def name: String = "L5_ER_AVOIDABLE_NUMRTR"

  override def dependsOn: Set[String] =
    Set(
      "L2_II_ED_AVOIDABLE",
      "L2_II_SERVICES_MED",
      "L4_MAP_TOS5_CUSTOM",
      "L2_II_MAP_TOS",
      "L2_II_MEM_ATTR_MEMBER",
      "L2_II_MAP_DATE_RANGE",
      "L2_II_MAP_ETG",
      "L2_II_MAP_ICDDX"
    )

  def createDataFrameWithoutDDL(sparkSession: SparkSession, loadedDependencies: Map[String, DataFrame], udfMap: Map[String, UserDefinedFunctionForDataLoader], runtimeVariables: RuntimeVariables): DataFrame = {
    import sparkSession.implicits._

    val l2IiEdAvoidable = loadedDependencies("L2_II_ED_AVOIDABLE")
    val l2IiServicesMed = loadedDependencies("L2_II_SERVICES_MED")
    val l4MapTos5Custom = loadedDependencies("L4_MAP_TOS5_CUSTOM")
    val l2IiMapTos = loadedDependencies("L2_II_MAP_TOS")
    val l2IiMapDateRange = loadedDependencies("L2_II_MAP_DATE_RANGE")
    val l2IiMemAttrMember = loadedDependencies("L2_II_MEM_ATTR_MEMBER")
    val l2IiMapEtg = loadedDependencies("L2_II_MAP_ETG")
    val l2IiMapIcddx = loadedDependencies("L2_II_MAP_ICDDX")

    val tosCustomTemp = l2IiMapTos.as("mp")
                        .join(broadcast(l4MapTos5Custom).as("ct"), $"ct.tos_i_5" === $"mp.tos_i_5", "left_outer")
                        .select(
                          $"mp.tos_i_5",
                          $"mp.tos1_id",
                          $"ct.tos_custom_id".as("tos_custom_id")
                        )

    l2IiServicesMed.as("smed")
      .join(l2IiEdAvoidable.as("edav"), $"smed.ed_enc_id" === $"edav.ed_enc_id" && $"smed.member" === $"edav.member", "inner")
      .join(tosCustomTemp.as("tos"), $"smed.tos_i_5" === $"tos.tos_i_5", "left_outer")
      .join(l2IiMapEtg.as("etg"), $"smed.etg_id" === $"etg.etg_id", "left_outer")
      .join(l2IiMapDateRange.as("mapdate"),
          $"mapdate.yr_month" === date_format($"smed.dos", "yyyyMM").cast(IntegerType),
        "inner"
      )
      .join(
        l2IiMemAttrMember.as("mam"),
        $"smed.member" === $"mam.member" && $"mam.year_mth_id" === $"mapdate.year_mth_id" &&
          $"smed.dos".between($"mam.mem_eff_dt", $"mam.mem_end_dt") &&
          $"smed.dos".between($"mam.sub_eff_dt", $"mam.sub_end_dt"),
        "inner"
      )
      .join(l2IiMapIcddx.as("icddx"), $"smed.diag1" === $"icddx.icddx" && $"smed.icd_version" === $"icddx.icd_version", "left_outer")
      .groupBy(
        $"mam.member_attr_id",
        $"tos.tos1_id",
        $"tos.tos_custom_id",
        $"mapdate.year_mth_id",
        $"smed.ia_time",
        $"smed.etg_id",
        $"smed.sev_level",
        $"etg.family",
        $"etg.tx_ind",
        $"etg.chronic",
        $"edav.mpc_dx",
        $"smed.tos_i_5",
        $"mam.pcp_assign",
        $"smed.er_conf",
        $"mam.contract_id",
        $"mam.product_id",
        $"mam.sex",
        $"mam.age_cat2",
        $"mam.cat_status_cost3",
        $"mam.mem_userdef_1_id",
        $"mam.at_risk_status_id",
        $"mam.zip",
        $"edav.county_id",
        $"smed.diag1",
        $"smed.icd_version",
        $"icddx.icddx_desc",
        $"smed.ed_enc_id",
        $"edav.unavoid_ed",
        $"edav.amb_sens",
        $"smed.dos"
      )
      .agg(
        sum($"smed.amt_pay").as("amt_pay"),
        sum($"smed.amt_eqv").as("amt_eqv"),
        sum($"smed.amt_np").as("amt_np"),
        sum(when($"edav.amb_sens" === lit(1) || $"edav.unavoid_ed" === lit(1), $"smed.amt_eqv").otherwise(lit(0))).as("amt_eqv_avoid"),
        sum(when($"edav.amb_sens" === lit(1) || $"edav.unavoid_ed" === lit(1), $"smed.amt_np").otherwise(lit(0))).as("amt_np_avoid"),
        sum(when($"edav.amb_sens" === lit(1) || $"edav.unavoid_ed" === lit(1), $"smed.amt_pay").otherwise(lit(0))).as("amt_pay_avoid"),
        sum(when($"edav.unavoid_ed" === lit(1), $"smed.amt_eqv").otherwise(lit(0))).as("amt_eqv_avoid_sett"),
        sum(when($"edav.unavoid_ed" === lit(1), $"smed.amt_np").otherwise(lit(0))).as("amt_np_avoid_sett"),
        sum(when($"edav.unavoid_ed" === lit(1), $"smed.amt_pay").otherwise(lit(0))).as("amt_pay_avoid_sett"),
        sum(when($"edav.amb_sens" === lit(1), $"smed.amt_eqv").otherwise(lit(0))).as("amt_eqv_avoid_acs"),
        sum(when($"edav.amb_sens" === lit(1), $"smed.amt_np").otherwise(lit(0))).as("amt_np_avoid_acs"),
        sum(when($"edav.amb_sens" === lit(1), $"smed.amt_pay").otherwise(lit(0))).as("amt_pay_avoid_acs")
      )
      .select(
        $"mam.member_attr_id",
        $"tos.tos1_id",
        coalesce($"tos.tos_custom_id", lit(3399999)).as("custom_tos"),
        $"mapdate.year_mth_id".cast(ShortType).as("year_mth_id"),
        when($"mapdate.year_mth_id" < 28, $"mapdate.year_mth_id" + 12).cast(ShortType).as("prior_year_mth_id"),
        $"smed.ia_time".cast(ShortType).as("ia_time"),
        coalesce($"edav.mpc_dx", lit(0)).as("mpc_dx"),
        coalesce($"smed.etg_id", lit(0)).as("etg_id"),
        coalesce($"smed.sev_level", lit(0)).cast(ShortType).as("sev_level"),
        coalesce($"etg.family", lit(0)).as("family"),
        coalesce($"etg.tx_ind", lit(0)).cast(ShortType).as("tx_ind"),
        coalesce($"etg.chronic", lit(-1)).cast(ShortType).as("chronic"),
        $"smed.tos_i_5",
        coalesce($"mam.pcp_assign", lit("0")).as("pcp_assign"),
        coalesce($"mam.contract_id", lit("Unspecified$UNK")).as("contract_id"),
        $"mam.product_id",
        when($"mam.sex" === lit(true), lit(1)).otherwise(lit(0)).cast(ShortType).as("sex"),
        when($"edav.amb_sens" === lit(1), $"smed.ed_enc_id").otherwise(lit(null)).as("ed_enc_id_acs"),
        when($"edav.unavoid_ed" === lit(1), $"smed.ed_enc_id").otherwise(lit(null)).as("ed_enc_id_sett"),
        when($"edav.amb_sens" === lit(1) || $"edav.unavoid_ed" === lit(1), $"smed.ed_enc_id").otherwise(lit(null)).as("ed_enc_id_avoid"),
        when($"tos.tos1_id" === lit(3) && ($"edav.amb_sens" === lit(1) || $"edav.unavoid_ed" === lit(1)), $"smed.ed_enc_id").otherwise(lit(null)).as("op_ed_enc_id_avoid"),
        when($"tos.tos1_id" === lit(4) && ($"edav.amb_sens" === lit(1) || $"edav.unavoid_ed" === lit(1)), $"smed.ed_enc_id").otherwise(lit(null)).as("prof_ed_enc_id_avoid"),
        $"mam.age_cat2".as("age_cat2"),
        $"mam.cat_status_cost3",
        coalesce($"mam.at_risk_status_id", lit("Unspecified$UNK")).as("at_risk_status_id"),
        $"mam.mem_userdef_1_id",
        $"mam.zip",
        coalesce($"edav.county_id", lit(0)).as("county_id"),
        coalesce($"smed.diag1", lit(0)).as("diag1"),
        coalesce($"smed.icd_version", lit(0)).as("icd_version"),
        $"icddx.icddx_desc",
        $"smed.ed_enc_id",
        $"edav.unavoid_ed".cast(ShortType).as("avoid_ed_setting_flag"),
        $"edav.amb_sens".cast(ShortType).as("avoid_ed_acs_flag"),
        date_format($"smed.dos", "u").cast(ShortType).as("dayofweek"),
        when($"edav.amb_sens" === lit(1) || $"edav.unavoid_ed" === lit(1), lit(1))
          .otherwise(when($"edav.amb_sens" === lit(2) || $"edav.unavoid_ed" === lit(2), lit(2)).otherwise(lit(0)))
          .cast(ShortType).as("avoidable_er_flag"),
        when($"smed.er_conf" === lit(false), lit(1)).otherwise(0).cast(ShortType).as("treat_release"),
        $"amt_eqv",
        $"amt_np",
        $"amt_pay",
        $"amt_eqv_avoid",
        $"amt_np_avoid",
        $"amt_pay_avoid",
        $"amt_eqv_avoid_sett",
        $"amt_np_avoid_sett",
        $"amt_pay_avoid_sett",
        $"amt_eqv_avoid_acs",
        $"amt_np_avoid_acs",
        $"amt_pay_avoid_acs"
      )
  }
}
