package com.optum.df.opa.L5

import com.optum.df.opa.models.L5.l5_dict_cost_type
import com.optum.oap.sparkdataloader.{RuntimeVariables, UserDefinedFunctionForDataLoader}
import org.apache.spark.sql.{DataFrame, SparkSession}

object L5_DICT_COST_TYPE extends L5TableInfo[l5_dict_cost_type]{

  override def name: String = "L5_DICT_COST_TYPE"
  override def dependsOn: Set[String] = Set.empty

  def createDataFrameWithoutDDL(sparkSession: SparkSession, loadedDependencies: Map[String, DataFrame], udfMap: Map[String, UserDefinedFunctionForDataLoader], runtimeVariables: RuntimeVariables): DataFrame = {
    import sparkSession.implicits._

        Seq((1.toShort, "Amount Allowed", "AMT ALLOWED"),
          (2.toShort, "Amount Paid", "AMT PAID"),
          (3.toShort, "Amount Normalized", "AMT NORMALIZED"))
          .toDF("cost_type_id", "cost_type", "cost_type_desc")
  }
}
