package com.optum.df.opa.L5

import com.optum.df.opa.models.L5.l5_ii_mem_attr
import com.optum.oap.sparkdataloader.{RuntimeVariables, UserDefinedFunctionForDataLoader}
import com.optum.oadw.oadwModels.{l2_ii_map_account, l2_ii_mem_attr}
import org.apache.spark.sql.functions._
import org.apache.spark.sql.types.ShortType
import org.apache.spark.sql.{DataFrame, SparkSession}


object L5_II_MEM_ATTR extends L5TableInfo[l5_ii_mem_attr] {

  override def name: String = "L5_II_MEM_ATTR"

  override def dependsOn: Set[String] = Set("L2_II_MEM_ATTR", "L2_II_MAP_ACCOUNT")

  def createDataFrameWithoutDDL(sparkSession: SparkSession, loadedDependencies: Map[String, DataFrame], udfMap: Map[String, UserDefinedFunctionForDataLoader], runtimeVariables: RuntimeVariables): DataFrame = {

    import sparkSession.implicits._

    val l2IIMemAttr = loadedDependencies("L2_II_MEM_ATTR")
    val L2IIMapAccount = loadedDependencies("L2_II_MAP_ACCOUNT")


    l2IIMemAttr.as("ima")
      .join(L2IIMapAccount.as("imac"), $"ima.ACCOUNT_ID" === $"imac.ACCOUNT_ID", "inner")
      .select($"member_attr_id",
        $"mpg_def_id",
        $"age_cat2".cast(ShortType).as("age_cat2"),
        when($"sex" === lit(true), 1).otherwise(lit(0)).cast(ShortType).as("sex"),
        $"county_id",
        $"ima.account_id",
        coalesce($"product_id", lit("Unspecified$UNK")).as("product_id"),
        coalesce($"employee_type_id", lit("Unspecified$UNK")).as("employee_type_id"),
        coalesce($"risk_type_id", lit("Unspecified$UNK")).as("risk_type_id"),
        when($"den" === lit(true), 1).otherwise(lit(0)).cast(ShortType).as("den"),
        when($"rx" === lit(true), 1).otherwise(lit(0)).cast(ShortType).as("rx"),
        when($"med" === lit(true), 1).otherwise(lit(0)).cast(ShortType).as("med"),
        $"contract_type_id",
        $"coverage_status_id",
        $"ima.biz_segment_id",
        $"ima.industry".cast(ShortType),
        $"benefit_plan_id",
        $"cat_status_cost3".cast(ShortType),
        $"cat_status".cast(ShortType),
        coalesce($"at_risk_status_id",lit("Unspecified$UNK")).as("at_risk_status_id"),
        $"mem_userdef_1_id",
        $"mem_userdef_2_id",
        $"mem_userdef_3_id",
        $"mem_userdef_4_id",
        coalesce($"contract_id", lit("Unspecified$UNK")).as("contract_id"),
        coalesce($"imac.account_lv1_id", $"imac.account_id").as("account_lv1_id"),
        coalesce($"imac.account_lv2_id", $"imac.account_id").as("account_lv2_id")
      )
  }
}

