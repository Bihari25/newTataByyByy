package com.optum.df.opa.L5

import com.optum.df.opa.models.L5.l5_dict_facility_type
import com.optum.oap.sparkdataloader.{RuntimeVariables, UserDefinedFunctionForDataLoader}
import org.apache.spark.sql.{DataFrame, SparkSession}
import org.apache.spark.sql.functions.{lit}

object L5_DICT_FACILITY_TYPE extends L5TableInfo[l5_dict_facility_type]{

  override def name: String = "L5_DICT_FACILITY_TYPE"
  override def dependsOn: Set[String] = Set("L2_DICT_SPEC")

  def createDataFrameWithoutDDL(sparkSession: SparkSession, loadedDependencies: Map[String, DataFrame], udfMap: Map[String, UserDefinedFunctionForDataLoader], runtimeVariables: RuntimeVariables): DataFrame = {
    import sparkSession.implicits._

    val l2DictSpec = loadedDependencies("L2_DICT_SPEC")
    val nonFacilityType = Seq((0, "Non-Facility Type")).toDF()

    l2DictSpec.as("ds")
      .where($"ds.sp1_id" === lit(1))
      .select($"ds.sp3_id".as("facility_type_id"),
        $"ds.sp3".as("facility_type_name")
      ).distinct()
      .union(nonFacilityType)

  }
}