package com.optum.df.opa

import com.optum.df.opa.DataFrameExtensions._
import com.optum.df.opa.util.parseSql
import com.optum.oap.sparklib.SparkUtils
import org.apache.spark.sql.functions.col
import org.apache.spark.sql.{SaveMode, SparkSession}
import org.slf4j.LoggerFactory

import java.util.concurrent.Executors
import scala.concurrent.duration.Duration
import scala.concurrent.{Await, ExecutionContext, Future}

object L234Loader {
  private val logger = LoggerFactory.getLogger(this.getClass)

  val partitions = 32

  private val l234Tables: Set[String] = OpaTableRegistry.getAllL234Tables

  private val dailyL234Tables: Set[String] = OpaTableRegistry.getDailyRepL234Tables

  def loader(runtimeVariables: OPAEtlRuntimeVariables, baseOutputPath:String, sparkSession: SparkSession, partitionMultiplier: Double, l234targetTables: Option[Seq[String]] = None): Unit = {
    implicit val executionContext: ExecutionContext = ExecutionContext.fromExecutorService(Executors.newFixedThreadPool(10))
    val tableList = l234targetTables.getOrElse(l234Tables)
    val tableColumnMap = generateMap(tableList)

    val result = Future.traverse(tableColumnMap.keys) {
      currentTable => Future {

        val (columnNames, columnTypes) = tableColumnMap(currentTable)
        // TODO make L234Loader an actual class so we don't have to push all these arguments from one method to another
        val hiveDbOption = getHiveDb(runtimeVariables, currentTable, sparkSession)
        hiveDbOption.foreach(dbName =>
          // not really a loop, just to skip table if getHiveDb returns None
          handleOneTable(sparkSession, baseOutputPath, dbName, currentTable, columnNames, columnTypes, partitionMultiplier)
        )
      }
    }

    Await.result(result, Duration.Inf)
  }

  def getHiveDb(runtimeVariables: OPAEtlRuntimeVariables, currentTable: String, sparkSession: SparkSession) : Option[String] = {
    val oadwHiveDb = runtimeVariables.oadwHiveDb
    val epsilonOadwHiveDb = runtimeVariables.epsilonOadwHiveDb

    // I would have preferred to use matching on Some(eoadw: String)
    // but the logic actually got more complicated trying to be more functional
    //
    // TODO: replace contains logic with sparkSession.catalog.exists test when it works (see above TODO)
    if (!epsilonOadwHiveDb.isEmpty && dailyL234Tables.contains(currentTable.toUpperCase)) {
      epsilonOadwHiveDb
    } else if (!runtimeVariables.epsilonOnly) {
      Some(oadwHiveDb)
    } else {
      None
    }
  }

  private def handleOneTable(sparkSession: SparkSession, baseOutputPath: String, hiveDb: String, currentTable: String, columns: Seq[String], columnTypes: Seq[String], partitionMultiplier: Double): Unit = {
    logger.warn(s" == Reordering columns in table: $hiveDb.$currentTable")

    sparkSession.catalog.setCurrentDatabase(hiveDb)
    val df = sparkSession.table(s"$hiveDb.$currentTable")
    val columnsLower = columns.map(_.toLowerCase)
    val df2 = df.adjustTimestampForRedshift()
    val orderedDf = df2.select(columnsLower.map(col):_*)
    orderedDf.checkTypes(columnTypes)
    val varcharTruncatedDf = orderedDf.truncateVarcharColumns(columnsLower.zip(columnTypes).toMap)

    SparkUtils.writeParquetToLocation(varcharTruncatedDf, baseOutputPath + "/" + currentTable.toUpperCase, SaveMode.Overwrite, (partitions * partitionMultiplier).toInt)
    logger.warn(s" ++ $hiveDb.$currentTable write completed")
  }

  private def generateMap(tableList: Iterable[String]): Map[String, (Array[String], Array[String])] = {

    tableList
      .map(file => getL234DDLPath(file))
      .flatMap(
        file => parseSql.parseColumns(file)
          .map(sql => sql._1 -> (sql._2, sql._3))
          .toMap
      ).toMap

  }

  def getL234DDLPath(filename : String) : String = {
    val tablename = filename.split('.')(0)
    val repFolder = if (dailyL234Tables.contains(tablename)) "daily_rep" else "rep"
    s"OPADDL/${repFolder}/L234/${tablename}.sql"
  }
}