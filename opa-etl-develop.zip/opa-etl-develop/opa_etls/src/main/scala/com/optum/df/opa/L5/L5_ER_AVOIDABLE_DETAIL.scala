package com.optum.df.opa.L5

import com.optum.df.opa.models.L5.l5_er_avoidable_detail
import com.optum.oap.sparkdataloader.{RuntimeVariables, UserDefinedFunctionForDataLoader}
import org.apache.spark.sql.{DataFrame, SparkSession}
import org.apache.spark.sql.functions.{broadcast, coalesce, date_format, lit, sum, when}
import org.apache.spark.sql.types.{IntegerType, ShortType}

object L5_ER_AVOIDABLE_DETAIL extends L5TableInfo[l5_er_avoidable_detail] {
  override def name: String = "L5_ER_AVOIDABLE_DETAIL"

  override def dependsOn: Set[String] =
    Set(
      "L2_II_ED_AVOIDABLE",
      "L2_II_MEM_ATTR_MEMBER",
      "L2_II_SERVICES_MED",
      "L2_II_MAP_TOS",
      "L2_II_MAP_DATE_RANGE",
      "L4_MAP_TOS5_CUSTOM",
      "L2_II_MAP_ETG",
      "L2_II_MAP_ICDDX"
    )

  def createDataFrameWithoutDDL(sparkSession: SparkSession, loadedDependencies: Map[String, DataFrame], udfMap: Map[String, UserDefinedFunctionForDataLoader], runtimeVariables: RuntimeVariables): DataFrame = {
    import sparkSession.implicits._

    val l2IiEdAvoidable = loadedDependencies("L2_II_ED_AVOIDABLE")
    val l2IiServicesMed = loadedDependencies("L2_II_SERVICES_MED")
    val l2IiMapTos = loadedDependencies("L2_II_MAP_TOS")
    val l2IiMapDateRange = loadedDependencies("L2_II_MAP_DATE_RANGE")
    val l4MapTos5Custom = loadedDependencies("L4_MAP_TOS5_CUSTOM")
    val l2IiMemAttrMember = loadedDependencies("L2_II_MEM_ATTR_MEMBER")
    val l2IiMapEtg = loadedDependencies("L2_II_MAP_ETG")
    val l2IiMapIcddx = loadedDependencies("L2_II_MAP_ICDDX")

    val tosCustomTemp = l2IiMapTos.as("mp")
                        .join(broadcast(l4MapTos5Custom).as("ct"), $"ct.tos_i_5" === $"mp.tos_i_5", "left_outer")
                        .select($"mp.tos_i_5",
                          $"mp.tos1_id",
                          $"ct.tos_custom_id".as("tos_custom_id")
                        )

    l2IiServicesMed
      .as("smed")
      .join(l2IiEdAvoidable.as("edav"), $"smed.ed_enc_id" === $"edav.ed_enc_id" && $"smed.member" === $"edav.member", "inner")
      .join(tosCustomTemp.as("tos"), $"tos.tos_i_5" === $"smed.tos_i_5", "left_outer")
      .join(l2IiMapDateRange.as("mapdate"),
          $"mapdate.yr_month" === date_format($"smed.dos", "yyyyMM").cast(IntegerType),
        "inner"
      )
      .join(
        l2IiMemAttrMember.as("mam"),
        $"smed.member" === $"mam.member" && $"mam.year_mth_id" === $"mapdate.year_mth_id" &&
          $"smed.dos".between($"mam.mem_eff_dt", $"mam.mem_end_dt") &&
          $"smed.dos".between($"mam.sub_eff_dt", $"mam.sub_end_dt"),
        "inner"
      )
      .join(l2IiMapEtg.as("etg"), $"smed.etg_id" === $"etg.etg_id", "left_outer")
      .join(l2IiMapIcddx.as("icddx"), $"smed.diag1" === $"icddx.icddx" && $"smed.icd_version" === $"icddx.icd_version", "left_outer")
      .groupBy(
        $"mam.member_attr_id",
        $"tos.tos1_id",
        $"tos.tos_custom_id",
        $"smed.claim_id",
        $"smed.clm_id_n",
        $"smed.ed_enc_id",
        $"smed.disrel",
        $"smed.er_flag",
        $"smed.er_conf",
        $"smed.er_util",
        $"smed.member",
        $"smed.dos",
        $"smed.pay_dt",
        $"smed.tos_i_5",
        $"smed.conf_num",
        $"smed.ia_time",
        $"mapdate.year_mth_id",
        $"smed.etg_id",
        $"etg.family",
        $"etg.tx_ind",
        $"etg.chronic",
        $"smed.sev_level",
        $"edav.mpc_dx",
        $"edav.unavoid_ed",
        $"edav.amb_sens",
        $"mam.pcp_assign",
        $"smed.provider_id",
        $"mam.contract_id",
        $"mam.product_id",
        $"mam.sex",
        $"mam.age_cat2",
        $"mam.cat_status_cost3",
        $"mam.mem_userdef_1_id",
        $"mam.mem_userdef_4_id",
        $"mam.at_risk_status_id",
        $"mam.zip",
        $"edav.county_id",
        $"smed.diag1",
        $"smed.icd_version",
        $"icddx.icddx_desc",
        $"smed.network_paid_status_id",
        $"smed.provider_status_id",
        $"smed.prv_sp_4",
        $"edav.account_lv1_id",
        $"edav.account_lv2_id",
        $"edav.account_id",
        $"smed.covid_flag"
      )
      .agg(
        sum($"smed.amt_pay").as("amt_pay"),
        sum($"smed.amt_eqv").as("amt_eqv"),
        sum($"smed.amt_np").as("amt_np"),
        sum(when($"edav.amb_sens" === lit(1) || $"edav.unavoid_ed" === lit(1), $"smed.amt_eqv").otherwise(lit(0))).as("amt_eqv_avoid"),
        sum(when($"edav.amb_sens" === lit(1) || $"edav.unavoid_ed" === lit(1), $"smed.amt_np").otherwise(lit(0))).as("amt_np_avoid"),
        sum(when($"edav.amb_sens" === lit(1) || $"edav.unavoid_ed" === lit(1), $"smed.amt_pay").otherwise(lit(0))).as("amt_pay_avoid"),
        sum(when($"edav.unavoid_ed" === lit(1), $"smed.amt_eqv").otherwise(lit(0))).as("amt_eqv_avoid_sett"),
        sum(when($"edav.unavoid_ed" === lit(1), $"smed.amt_np").otherwise(lit(0))).as("amt_np_avoid_sett"),
        sum(when($"edav.unavoid_ed" === lit(1), $"smed.amt_pay").otherwise(lit(0))).as("amt_pay_avoid_sett"),
        sum(when($"edav.amb_sens" === lit(1), $"smed.amt_eqv").otherwise(lit(0))).as("amt_eqv_avoid_acs"),
        sum(when($"edav.amb_sens" === lit(1), $"smed.amt_np").otherwise(lit(0))).as("amt_np_avoid_acs"),
        sum(when($"edav.amb_sens" === lit(1), $"smed.amt_pay").otherwise(lit(0))).as("amt_pay_avoid_acs")
      )
      .select(
        $"mam.member_attr_id",
        $"tos.tos1_id",
        $"tos.tos_custom_id",
        coalesce($"smed.claim_id", lit(0)).as("claim_id"),
        coalesce($"smed.clm_id_n", lit(0)).as("clm_id_n"),
        $"smed.ed_enc_id",
        $"smed.disrel",
        when($"smed.er_flag" === lit(true), lit(1)).otherwise(lit(0)).cast(ShortType).as("er_flag"),
        when($"smed.er_conf" === lit(true), lit(1)).otherwise(lit(0)).cast(ShortType).as("er_conf"),
        $"smed.er_util",
        $"smed.member",
        $"smed.dos",
        $"smed.pay_dt",
        $"mapdate.year_mth_id".cast(ShortType).as("year_mth_pd"),
        $"smed.tos_i_5",
        coalesce($"smed.conf_num", lit(0)).as("conf_num"),
        $"smed.ia_time".cast(ShortType),
        $"mapdate.year_mth_id".cast(ShortType),
        coalesce($"smed.etg_id", lit(0)).as("etg_id"),
        coalesce($"etg.family", lit(0)).as("family"),
        coalesce($"etg.tx_ind", lit(0)).cast(ShortType).as("tx_ind"),
        coalesce($"etg.chronic", lit(-1)).cast(ShortType).as("chronic"),
        when($"edav.amb_sens" === lit(1), $"smed.ed_enc_id").otherwise(lit(null)).as("ed_enc_id_acs"),
        when($"edav.unavoid_ed" === lit(1), $"smed.ed_enc_id").otherwise(lit(null)).as("ed_enc_id_sett"),
        when($"edav.amb_sens" === lit(1) || $"edav.unavoid_ed" === lit(1), $"smed.ed_enc_id").otherwise(lit(null)).as("ed_enc_id_avoid"),
        coalesce($"smed.sev_level", lit(0)).cast(ShortType).as("sev_level"),
        coalesce($"edav.mpc_dx", lit(0)).as("mpc_dx"),
        $"edav.unavoid_ed".cast(ShortType).as("avoid_ed_setting_flag"),
        $"edav.amb_sens".cast(ShortType).as("avoid_ed_acs_flag"),
        coalesce($"mam.pcp_assign", lit("0")).as("pcp_assign"),
        coalesce($"smed.provider_id", lit(0)).as("provider_id"),
        coalesce($"mam.contract_id", lit("Unspecified$UNK")).as("contract_id"),
        $"mam.product_id",
        when($"mam.sex" === lit(true), lit(1)).otherwise(lit(0)).cast(ShortType).as("sex"),
        $"mam.age_cat2",
        $"mam.cat_status_cost3",
        $"mam.mem_userdef_1_id",
        coalesce($"mam.mem_userdef_4_id", lit("Unspecified$UNK")).as("mem_userdef_4_id"),
        coalesce($"mam.at_risk_status_id", lit("Unspecified$UNK")).as("at_risk_status_id"),
        $"mam.zip",
        coalesce($"edav.county_id", lit(0)).as("county_id"),
        coalesce($"smed.diag1", lit(0)).as("diag1"),
        coalesce($"smed.icd_version", lit(0)).as("icd_version"),
        $"icddx.icddx_desc",
        $"smed.network_paid_status_id",
        $"smed.provider_status_id",
        coalesce($"smed.prv_sp_4", lit(999)).as("prv_sp_4"),
        when($"smed.er_conf" === lit(0), lit(1)).otherwise(lit(0)).cast(ShortType).as("treat_release"),
        date_format($"smed.dos", "u").cast(ShortType).as("dayofweek"),
        when($"edav.amb_sens" === lit(1) || $"edav.unavoid_ed" === lit(1), lit(1)).otherwise(
            when($"edav.amb_sens" === lit(2) || $"edav.unavoid_ed" === lit(2), lit(2)).otherwise(lit(0))
          ).cast(ShortType).as("avoidable_er_flag"),
        coalesce($"edav.account_lv1_id", $"edav.account_lv2_id", $"edav.account_id").as("account_lv1_id"),
        coalesce($"edav.account_lv2_id", $"edav.account_id").as("account_lv2_id"),
        $"edav.account_id".as("account_id"),
        $"amt_pay",
        $"amt_eqv",
        $"amt_np",
        $"amt_eqv_avoid",
        $"amt_np_avoid",
        $"amt_pay_avoid",
        $"amt_eqv_avoid_sett",
        $"amt_pay_avoid_sett",
        $"amt_np_avoid_sett",
        $"amt_eqv_avoid_acs",
        $"amt_pay_avoid_acs",
        $"amt_np_avoid_acs",
        coalesce($"smed.covid_flag".cast(ShortType), lit(-1.toShort)).as("covid_flag")
      )
  }

}
