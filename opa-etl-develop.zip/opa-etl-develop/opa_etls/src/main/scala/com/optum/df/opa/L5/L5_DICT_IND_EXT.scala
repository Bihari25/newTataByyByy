package com.optum.df.opa.L5

import com.optum.df.opa.models.L5.l5_dict_ind_ext
import com.optum.oap.sparkdataloader.{RuntimeVariables, UserDefinedFunctionForDataLoader}
import org.apache.spark.sql.{DataFrame, SparkSession}

object L5_DICT_IND_EXT extends L5TableInfo[l5_dict_ind_ext] {
  override def name: String = "L5_DICT_IND_EXT"

  override def dependsOn: Set[String] = Set.empty

  def createDataFrameWithoutDDL(sparkSession: SparkSession, loadedDependencies: Map[String, DataFrame], udfMap: Map[String, UserDefinedFunctionForDataLoader], runtimeVariables: RuntimeVariables): DataFrame = {


    import sparkSession.implicits._

    Seq((0.toShort, "No"),
      (1.toShort, "Yes"),
      (-1.toShort, "Unspecified"))
      .toDF("ind_id", "ind_desc")
  }
}
