package com.optum.df.opa.L5

import com.optum.df.opa.models.L5.l5_clinical_event
import com.optum.oap.sparkdataloader.{RuntimeVariables, UserDefinedFunctionForDataLoader}
import org.apache.spark.sql.functions._
import org.apache.spark.sql.types.{DateType, ShortType, LongType}
import org.apache.spark.sql.{DataFrame, SparkSession}

/**
  * Source query:
  * https://som-bb.humedica.net/projects/OAP/repos/oap-mstr-db-interface/browse/src/main/resources/src/build/L5/etl/OPA/L5_clinical_event_insert.sql
  *
  * Redshift Schema: opa_util/src/main/resources/OPADDL/L5/tables/L5_CLINICAL_EVENT.sql
  */

/**
  * @TODO: Clinical_event_hci table is created as part of the Hospital Care Insights (HCI) implementation.
  *        It was required to load Clinical Event as a monthly table, thus it is duplicated.
  *        There is a clinical event type filter being applied on the clinical_event_hci table. It includes only those clinical event types which make sense from an HCI reporting point of view.
  *        Should revisit if/after OADW moves Readmission tables to daily .
  */

class L5_CLINICAL_EVENT_TEMPLATE (val tableName: String, val clinicalEventTypes: List[String]) extends L5TableInfo[l5_clinical_event] {
  override def name: String = tableName

  override def dependsOn: Set[String] = Set("L2_PAT_CLINICAL_EVENT", "L5_DICT_DAY_DATE_THRU", "L5_DATE_LOG")

  def createDataFrameWithoutDDL(sparkSession: SparkSession, loadedDependencies: Map[String, DataFrame], udfMap: Map[String, UserDefinedFunctionForDataLoader], runtimeVariables: RuntimeVariables): DataFrame = {
    import sparkSession.implicits._

    val l2PatClinicalEvent = if (clinicalEventTypes == null) loadedDependencies("L2_PAT_CLINICAL_EVENT") else loadedDependencies("L2_PAT_CLINICAL_EVENT").where($"event_type_cui".isin(clinicalEventTypes:_*))
    val l5DictDayDateThru = loadedDependencies("L5_DICT_DAY_DATE_THRU")
    val cutoff_date = loadedDependencies("L5_DATE_LOG").select($"cutoff_date").head.get(0)

    l2PatClinicalEvent.alias("ce")
      .join(broadcast(l5DictDayDateThru).as("dt"), $"ce.evt_start_dtm".cast(DateType) === $"dt.date_id", "left_outer")
      .where($"ce.evt_start_dtm".cast(DateType) > cutoff_date)
      .select(
        $"ce.client_id",
        $"ce.clinical_event_id".cast(LongType).as("clinical_event_id"),
        coalesce($"ce.hosp_site_id", lit(-1)).cast(LongType).as("hosp_site_id"),
        coalesce($"ce.amb_site_id", lit(0)).cast(LongType).as("amb_site_id"),
        $"ce.cds_grp",
        $"ce.mpi",
        $"ce.evt_start_dtm",
        $"ce.evt_admit_dtm",
        $"ce.evt_end_dtm",
        $"ce.event_type_cui",
        $"ce.disposition_cui",
        $"ce.admitsource_cui",
        coalesce($"ce.drg_id", lit(0)).as("drg_id"),
        coalesce($"ce.apr_drg_id", lit(0)).as("apr_drg_id"),
        coalesce($"ce.prindx", lit(0)).as("prindx"),
        coalesce($"ce.prindx_codetype", lit(0)).as("prindx_codetype"),
        $"ce.prindx_sensitive_ind".cast(ShortType),
        coalesce($"ce.prinpx", lit(0)).as("prinpx"),
        coalesce($"ce.prinpx_codetype", lit(0)).as("prinpx_codetype"),
        $"ce.prinpx_sensitive_ind".cast(ShortType),
        $"ce.cms_planned_ind".cast(ShortType),
        $"ce.cms_include_ind".cast(ShortType),
        $"ce.convert_ip_ind".cast(ShortType),
        $"ce.admitted_er_ind".cast(ShortType),
        $"ce.hosp_service_cui",
        $"ce.pat_zip",
        coalesce($"ce.admit_prov_id", lit("-1")).as("admit_prov_id"),
        coalesce($"ce.disch_prov_id", lit("-1")).as("disch_prov_id"),
        $"ce.disch_team_prov_id",
        coalesce($"ce.prov_id", lit("-1")).as("prov_id"),
        $"ce.etg_qual_evt_ind".cast(ShortType),
        coalesce($"dt.rolling_timeframe_id", lit(0)).as("rolling_timeframe_id"),
        coalesce($"dt.year_to_date_id", lit(0)).as("year_to_date_id"),
        $"ce.display_ds_id",
        $"ce.display_encounterid",
        $"ce.sensitive_ind".cast(ShortType),
        $"ce.los"
      )
  }
}

object L5_CLINICAL_EVENT extends L5_CLINICAL_EVENT_TEMPLATE("L5_CLINICAL_EVENT", null)
object L5_CLINICAL_EVENT_HCI extends L5_CLINICAL_EVENT_TEMPLATE("L5_CLINICAL_EVENT_HCI", List("CH000113","CH003530","CH000109","CH003529","CH000106","CH003527","CH003032","CH003031","CH000107","CH003528","CH999999","CH000795","CH003030"))