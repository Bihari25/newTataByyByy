package com.optum.df.opa.L5

import com.optum.df.opa.models.L5.l5_ii_pop_count
import com.optum.oap.sparkdataloader.{RuntimeVariables,TableInfo, UserDefinedFunctionForDataLoader}
import org.apache.spark.sql.functions._
import org.apache.spark.sql.types.ShortType
import org.apache.spark.sql.{DataFrame, SparkSession}

object L5_II_POP_COUNT extends L5TableInfo[l5_ii_pop_count] {
  override def name: String = "L5_II_POP_COUNT"
  override def dependsOn: Set[String] = Set("L2_II_POP_COUNT")

  def createDataFrameWithoutDDL(sparkSession: SparkSession, loadedDependencies: Map[String, DataFrame], udfMap: Map[String, UserDefinedFunctionForDataLoader], runtimeVariables: RuntimeVariables): DataFrame = {
    import sparkSession.implicits._

    val l2IiPopCount = loadedDependencies("L2_II_POP_COUNT")

    l2IiPopCount.as("pc")
      .select(
        coalesce($"pc.PROVIDER_ID", lit("0")).as("PROVIDER_ID"),
        $"PEER_DEF_ID",
        coalesce($"PRODUCT_ID", lit("Unspecified$UNK")).as("PRODUCT_ID"),
        $"pc.PCP_IMP_FLAG" ,
        $"pc.AGE_CAT2" ,
        when($"pc.SEX" === lit(true), 1).otherwise(lit(0)).cast(ShortType).as("SEX"),
        $"pc.IA_TIME" ,
        $"pc.IA_TIME_ADJ" ,
        $"pc.RRISK_CAT" ,
        when($"pc.PHM_QUAL" === lit(true), 1).otherwise(lit(0)).cast(ShortType).as("PHM_QUAL"),
        $"pc.PCP_MMOS",
        $"pc.RRISK_W"
      )
  }
}

