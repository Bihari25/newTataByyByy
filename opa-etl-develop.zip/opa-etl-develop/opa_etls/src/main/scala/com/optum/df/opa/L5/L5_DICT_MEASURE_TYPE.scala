package com.optum.df.opa.L5

import com.optum.df.opa.models.L5.l5_dict_measure_type
import com.optum.oap.sparkdataloader.{RuntimeVariables, UserDefinedFunctionForDataLoader}
import org.apache.spark.sql.{DataFrame, SparkSession}

/**
New lookup table for Measure Type attribute.
  */

object L5_DICT_MEASURE_TYPE extends L5TableInfo[l5_dict_measure_type] {
  override def name: String = "L5_DICT_MEASURE_TYPE"
  override def dependsOn: Set[String] = Set("L5_MEASURE_SET_PROMPT")

  def createDataFrameWithoutDDL(sparkSession: SparkSession, loadedDependencies: Map[String, DataFrame], udfMap: Map[String, UserDefinedFunctionForDataLoader], runtimeVariables: RuntimeVariables): DataFrame = {
    import sparkSession.implicits._

    val l5MeasureSetPrompt = loadedDependencies("L5_MEASURE_SET_PROMPT")

    l5MeasureSetPrompt
      .select($"measure_type"
    ).distinct()
  }
}
