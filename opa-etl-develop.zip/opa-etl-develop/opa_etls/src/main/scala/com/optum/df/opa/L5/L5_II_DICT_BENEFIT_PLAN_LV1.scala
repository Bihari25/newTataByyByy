package com.optum.df.opa.L5

import com.optum.df.opa.models.L5.l5_ii_dict_benefit_plan_lv1
import com.optum.oap.sparkdataloader.{RuntimeVariables, UserDefinedFunctionForDataLoader}
import com.optum.oadw.oadwModels.l2_ii_map_benefit_plan
import org.apache.spark.sql.functions._
import org.apache.spark.sql.{DataFrame, SparkSession}


object L5_II_DICT_BENEFIT_PLAN_LV1  extends L5TableInfo[l5_ii_dict_benefit_plan_lv1] {

  override def name: String = "L5_II_DICT_BENEFIT_PLAN_LV1"

  override def dependsOn: Set[String] = Set("L2_II_MAP_BENEFIT_PLAN")

  def createDataFrameWithoutDDL(sparkSession: SparkSession, loadedDependencies: Map[String, DataFrame], udfMap: Map[String, UserDefinedFunctionForDataLoader], runtimeVariables: RuntimeVariables): DataFrame = {

    import sparkSession.implicits._

    val l2iiMapBenefitPlan = loadedDependencies("L2_II_MAP_BENEFIT_PLAN")

    l2iiMapBenefitPlan.select(
      coalesce($"benefit_plan_lv1_id", $"benefit_plan_lv2_id", $"benefit_plan_id").as("benefit_plan_lv1_id"),
      coalesce($"benefit_plan_lv1_desc", $"benefit_plan_lv2_desc", $"benefit_plan_desc").as("benefit_plan_lv1_desc")
    ).distinct()
  }
}
