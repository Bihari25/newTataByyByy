package com.optum.df.opa.L5

import com.optum.df.opa.models.L5.l5_dict_tos4
import com.optum.oap.sparkdataloader.{RuntimeVariables, UserDefinedFunctionForDataLoader}
import org.apache.spark.sql.{DataFrame, SparkSession}

/**
  * Source query:
  * https://som-bb.humedica.net/projects/OAP/repos/oap-mstr-db-interface/browse/src/main/resources/src/build/L5/etl/II/L5_dict_tos4_insert.sql
  *
  * Redshift Schema: opa_util/src/main/resources/OPADDL/L5/tables/L5_DICT_TOS4.sql
  */
object L5_DICT_TOS4 extends L5TableInfo[l5_dict_tos4] {
  override def name: String = "L5_DICT_TOS4"
  override def dependsOn: Set[String] = Set("L2_II_MAP_TOS")

  def createDataFrameWithoutDDL(sparkSession: SparkSession, loadedDependencies: Map[String, DataFrame], udfMap: Map[String, UserDefinedFunctionForDataLoader], runtimeVariables: RuntimeVariables): DataFrame = {
    import sparkSession.implicits._

    val l2IiMapTos = loadedDependencies("L2_II_MAP_TOS")

    l2IiMapTos.select(
      $"tos_i_4",
      $"tos4"
    ).distinct
  }
}
