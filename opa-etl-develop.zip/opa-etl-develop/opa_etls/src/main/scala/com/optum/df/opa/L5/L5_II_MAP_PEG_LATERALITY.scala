package com.optum.df.opa.L5

import com.optum.df.opa.models.L5.l5_ii_map_peg_laterality
import com.optum.oap.sparkdataloader.{RuntimeVariables, UserDefinedFunctionForDataLoader}
import org.apache.spark.sql.types.ShortType
import org.apache.spark.sql.{DataFrame, SparkSession}

object L5_II_MAP_PEG_LATERALITY extends L5TableInfo[l5_ii_map_peg_laterality] {
  override def name: String = "L5_II_MAP_PEG_LATERALITY"
  override def dependsOn: Set[String] = Set("L2_II_MAP_PEG_LATERALITY")

  def createDataFrameWithoutDDL(sparkSession: SparkSession, loadedDependencies: Map[String, DataFrame], udfMap: Map[String, UserDefinedFunctionForDataLoader], runtimeVariables: RuntimeVariables): DataFrame = {
    import sparkSession.implicits._

    val l2IiMapPegLaterality = loadedDependencies("L2_II_MAP_PEG_LATERALITY")

    l2IiMapPegLaterality
      .select($"laterality",
        $"laterality_desc",
        $"peg_unit_laterality"
      )
  }
}
