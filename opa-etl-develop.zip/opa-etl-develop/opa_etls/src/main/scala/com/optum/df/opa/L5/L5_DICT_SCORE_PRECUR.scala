package com.optum.df.opa.L5

import com.optum.df.opa.models.L5.l5_dict_score_precur
import com.optum.oap.sparkdataloader.{RuntimeVariables, UserDefinedFunctionForDataLoader}
import org.apache.spark.sql.{DataFrame, SparkSession}

object L5_DICT_SCORE_PRECUR extends L5TableInfo[l5_dict_score_precur]{
  override def name: String = "L5_DICT_SCORE_PRECUR"
  override def dependsOn: Set[String] = Set("L5_MAP_SCORE_PRECUR")

  override def createDataFrameWithoutDDL(sparkSession: SparkSession, loadedDependencies: Map[String, DataFrame], udfMap:  Map[String, UserDefinedFunctionForDataLoader], mapRuntimeVariables: RuntimeVariables): DataFrame = {

    import sparkSession.implicits._

    val l5MapScorePrecur = loadedDependencies("L5_MAP_SCORE_PRECUR")

    l5MapScorePrecur.as("msp")
      .select($"msp.grp_id",
        $"msp.precursor_id",
        $"msp.score_id",
        $"msp.grp_precursor_desc")
      .distinct()
  }
}
