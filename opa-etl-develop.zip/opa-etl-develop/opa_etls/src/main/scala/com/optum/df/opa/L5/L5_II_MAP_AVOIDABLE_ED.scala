package com.optum.df.opa.L5

import com.optum.df.opa.models.L5.l5_ii_map_avoidable_ed
import com.optum.oap.sparkdataloader.{RuntimeVariables, UserDefinedFunctionForDataLoader}
import org.apache.spark.sql.{DataFrame, SparkSession}


object L5_II_MAP_AVOIDABLE_ED extends L5TableInfo[l5_ii_map_avoidable_ed] {
  override def name: String = "L5_II_MAP_AVOIDABLE_ED"

  override def dependsOn: Set[String] = Set.empty

  def createDataFrameWithoutDDL(sparkSession: SparkSession, loadedDependencies: Map[String, DataFrame], udfMap: Map[String, UserDefinedFunctionForDataLoader], runtimeVariables: RuntimeVariables): DataFrame = {
    import sparkSession.implicits._

    Seq((0.toShort, "Likely Unavoidable"),
        (1.toShort, "Potentially Avoidable"),
        (2.toShort, "Undetermined"))
      .toDF("avoidable_er_id","avoidable_er_desc")
  }
}