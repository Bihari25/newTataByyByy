package com.optum.df.opa.L5

import com.optum.df.opa.models.L5.l5_dict_avoidable_ed_type
import com.optum.oap.sparkdataloader.{RuntimeVariables, UserDefinedFunctionForDataLoader}
import org.apache.spark.sql.{DataFrame, SparkSession}

object L5_DICT_AVOIDABLE_ED_TYPE extends L5TableInfo[l5_dict_avoidable_ed_type]{

  override def name: String = "L5_DICT_AVOIDABLE_ED_TYPE"
  override def dependsOn: Set[String] = Set.empty

  def createDataFrameWithoutDDL(sparkSession: SparkSession, loadedDependencies: Map[String, DataFrame], udfMap: Map[String, UserDefinedFunctionForDataLoader], runtimeVariables: RuntimeVariables): DataFrame = {
    import sparkSession.implicits._

        Seq((1.toShort, "All Avoidable Visits", "% Avoidable ED Visits"),
          (2.toShort, "Avoidable with Better Ambulatory Care (Potentially)", "% Avoidable ED Visits with Better Ambulatory Care"),
          (3.toShort, "Avoidable with Lower Setting of Care (Potentially)", "% Avoidable ED Visits with Lower Setting of Care"))
          .toDF("avoidable_type_id", "avoidable_type_desc", "avoidable_type_metric")
  }
}