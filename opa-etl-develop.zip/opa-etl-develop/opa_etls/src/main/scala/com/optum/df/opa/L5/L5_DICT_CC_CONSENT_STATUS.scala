package com.optum.df.opa.L5

import com.optum.df.opa.models.L5.l5_dict_cc_consent_status
import com.optum.oap.sparkdataloader.{RuntimeVariables, UserDefinedFunctionForDataLoader}
import org.apache.spark.sql.{DataFrame, SparkSession}

object L5_DICT_CC_CONSENT_STATUS extends L5TableInfo[l5_dict_cc_consent_status] {
  override def name: String = "L5_DICT_CC_CONSENT_STATUS"
  override def dependsOn: Set[String] = Set("L5_CC_CASE")

  def createDataFrameWithoutDDL(sparkSession: SparkSession, loadedDependencies: Map[String, DataFrame], udfMap: Map[String, UserDefinedFunctionForDataLoader], runtimeVariables: RuntimeVariables): DataFrame = {
    import sparkSession.implicits._

    val l1CcCase = loadedDependencies("L5_CC_CASE")

      l1CcCase.select(
        $"consent_status"
      ).distinct()
  }
}
