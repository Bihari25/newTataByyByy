package com.optum.df.opa.L5

import com.optum.df.opa.models.L5.l5_ii_ocu_member_pp
import com.optum.oap.sparkdataloader.{RuntimeVariables, UserDefinedFunctionForDataLoader}
import org.apache.spark.sql.functions._
import org.apache.spark.sql.types.{IntegerType, ShortType}
import org.apache.spark.sql.{DataFrame, SparkSession}


object L5_II_OCU_MEMBER_PP extends L5TableInfo[l5_ii_ocu_member_pp]{
  override def name: String = "L5_II_OCU_MEMBER_PP"
    override def dependsOn: Set[String] = Set("L2_II_OCU_MEMBER","L2_II_MEM_ATTR","L2_II_MAP_ACCOUNT","L2_II_MAP_CONTRACT","L2_II_MAP_COUNTY","L2_II_MAP_AT_RISK_STATUS","L2_II_MAP_DATE_RANGE")
  def createDataFrameWithoutDDL(sparkSession: SparkSession, loadedDependencies: Map[String, DataFrame], udfMap: Map[String, UserDefinedFunctionForDataLoader], runtimeVariables: RuntimeVariables): DataFrame = {

    import sparkSession.implicits._

    val l2IIOcuMember = loadedDependencies("L2_II_OCU_MEMBER")
    val l2IIMemAttr = loadedDependencies("L2_II_MEM_ATTR")
    val l2IIMapAccount = loadedDependencies("L2_II_MAP_ACCOUNT")
    val l2IIMapContract = loadedDependencies("L2_II_MAP_CONTRACT")
    val l2IIMapCounty = loadedDependencies("L2_II_MAP_COUNTY")
    val l2IIMapAtRiskStatus = loadedDependencies("L2_II_MAP_AT_RISK_STATUS")
    val l2iimapdaterange = loadedDependencies("L2_II_MAP_DATE_RANGE")

      l2IIOcuMember.as("om")
      .join(l2IIMemAttr.as("ma"),$"om.mem_attr_id" === $"ma.member_attr_id", "left_outer")
      .join(l2IIMapAccount.as("mac"),$"ma.account_id" === $"mac.account_id", "left_outer")
      .join(l2IIMapCounty.as("mco"), $"ma.county_id" === $"mco.county_id", "left_outer")
      .join(l2IIMapContract.as("mc"), $"ma.contract_id" === $"mc.contract_id", "left_outer")
      .join(l2IIMapAtRiskStatus.as("mr"), $"ma.at_risk_status_id" === $"mr.at_risk_status_id", "left_outer")
      .join(l2iimapdaterange.as("md"), $"om.year_mth_id" === $"md.year_mth_id", "left_outer")
      .select(
        coalesce($"mac.account_lv1_id", $"mac.account_lv2_id", $"mac.account_id").as("account_lv1_id"),
        coalesce($"mac.account_lv2_id", $"mac.account_id").as("account_lv2_id"),
        $"ma.account_id".as("account_id"),
        $"om.mem_attr_id",
        $"ma.age_cat2".as("age_cat2"),
        $"ma.sex".cast(ShortType).as("sex"),
        $"mco.cens_reg".as("cens_reg"),
        $"mco.state".as("state"),
        $"ma.county_id".as("county_id"),
        $"ma.cat_status".as("cat_status"),
        $"ma.cat_status_cost3".as("cat_status_cost3"),
        coalesce($"om.pcp_affil_id", lit("Unspecified$UNK")).as("pcp_affil_id"),
        coalesce($"om.pcp_assign", lit("0")).as("pcp_assign"),
        coalesce($"om.pcp_imp", lit("0")).as("pcp_imp"),
        coalesce($"mc.contract_lv1_id", $"mc.contract_lv2_id", $"mc.contract_id").as("contract_lv1_id"),
        coalesce($"mc.contract_lv2_id", $"mc.contract_id").as("contract_lv2_id"),
        $"ma.contract_id".as("contract_id"),
        $"ma.contract_type_id".as("contract_type_id"),
        when($"ma.den" === lit(true), 1).otherwise(lit(0)).cast(ShortType).as("den"),
        coalesce($"ma.employee_type_id", lit("Unspecified$UNK")).as("employee_type_id"),
        coalesce($"ma.risk_type_id", lit("Unspecified$UNK")).as("risk_type_id"),
        $"ma.at_risk_status_id".as("at_risk_status_id"),
        coalesce($"mr.at_risk_status_lv1_id", $"mr.at_risk_status_lv2_id", $"mr.at_risk_status_id").as("at_risk_status_lv1_id"),
        coalesce($"mr.at_risk_status_lv2_id", $"mr.at_risk_status_id").as("at_risk_status_lv2_id"),
        $"ma.product_id".as("product_id"),
        $"om.year_mth_id".as("year_mth_id"),
        $"om.iatime_lag".as("iatime_lag"),
        $"md.ia_time".as("ia_time"),
        $"ma.coverage_status_id".as("coverage_status_id"),
        $"ma.mem_userdef_1_id".as("mem_userdef_1_id"),
        $"ma.mem_userdef_2_id".as("mem_userdef_2_id"),
        $"ma.mem_userdef_3_id".as("mem_userdef_3_id"),
        $"ma.mem_userdef_4_id".as("mem_userdef_4_id"),
        $"ma.benefit_plan_id".as("benefit_plan_id"),
        $"ma.biz_segment_id".as("biz_segment_id"),
        $"ma.industry".as("industry"),
        $"ma.mpg_def_id".as("mpg_def_id"),
        $"om.age_tot",
        $"om.mm",
        $"om.mm_den".cast(IntegerType),
        $"om.mm_rx",
        $"om.rrisk",
        $"om.prisk",
        $"om.premium_tot",
        $"om.subscr_months"
    )
  }
}