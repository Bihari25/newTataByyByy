package com.optum.df.opa.L5

import com.optum.df.opa.models.L5.l5_ii_map_etg
import com.optum.oap.sparkdataloader.{RuntimeVariables, UserDefinedFunctionForDataLoader}
import org.apache.spark.sql.types.ShortType
import org.apache.spark.sql.{DataFrame, SparkSession}

object L5_II_MAP_ETG extends L5TableInfo[l5_ii_map_etg] {
  override def name: String = "L5_II_MAP_ETG"

  override def dependsOn: Set[String] = Set("L2_II_MAP_ETG")
  def createDataFrameWithoutDDL (sparkSession:SparkSession,loadedDependencies:Map[String,DataFrame],udfMap:Map[String,UserDefinedFunctionForDataLoader],runtimeVariables:RuntimeVariables):DataFrame={
    import sparkSession.implicits._

    val l2IiMapEtg = loadedDependencies("L2_II_MAP_ETG")
    val defaultRecord = Seq((0,"Unknown","Unknown",0,0,(-1).toShort,0.toShort)).toDF()

    l2IiMapEtg.as("me")
      .select(
        $"me.etg_id",
        $"me.etg_impact",
        $"me.etg_impact_desc",
        $"me.family",
        $"me.mpc",
        $"me.chronic".cast(ShortType),
        $"me.tx_ind".cast(ShortType)
      )
      .union(defaultRecord)
  }
}