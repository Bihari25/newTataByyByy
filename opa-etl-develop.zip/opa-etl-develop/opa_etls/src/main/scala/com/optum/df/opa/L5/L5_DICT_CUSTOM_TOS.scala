package com.optum.df.opa.L5

import com.optum.df.opa.models.L5.l5_dict_custom_tos
import com.optum.oap.sparkdataloader.{RuntimeVariables, UserDefinedFunctionForDataLoader}
import org.apache.spark.sql.functions._
import org.apache.spark.sql.{DataFrame, SparkSession}

object L5_DICT_CUSTOM_TOS extends L5TableInfo[l5_dict_custom_tos] {
  override def name: String = "L5_DICT_CUSTOM_TOS"
  override def dependsOn: Set[String] = Set("L2_DICT_CUSTOM_TOS")

  def createDataFrameWithoutDDL(sparkSession: SparkSession, loadedDependencies: Map[String, DataFrame], udfMap: Map[String, UserDefinedFunctionForDataLoader], runtimeVariables: RuntimeVariables): DataFrame = {
    import sparkSession.implicits._

    val l2DictCustomTos = loadedDependencies("L2_DICT_CUSTOM_TOS")

    val select_condition_1 = l2DictCustomTos.as("dct")
      .select($"dct.tos_custom_id",
        $"dct.tos_custom_desc"
      ).distinct()

    val default_row1 = Seq((-1, "Unknown 1")).toDF()
    val default_row2 = Seq((-7, "Unknown 7")).toDF()

    select_condition_1
      .union(default_row1)
      .union(default_row2)
  }
}
