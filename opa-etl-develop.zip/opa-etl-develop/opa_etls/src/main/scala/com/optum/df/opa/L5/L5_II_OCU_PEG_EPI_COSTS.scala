package com.optum.df.opa.L5

import com.optum.df.opa.models.L5.l5_ii_ocu_peg_epi_costs
import com.optum.oap.sparkdataloader.{RuntimeVariables, UserDefinedFunctionForDataLoader}
import org.apache.spark.sql.functions.{coalesce, lit, when}
import org.apache.spark.sql.types.ShortType
import org.apache.spark.sql.{DataFrame, SparkSession}

object L5_II_OCU_PEG_EPI_COSTS extends L5TableInfo[l5_ii_ocu_peg_epi_costs] {
  override def name: String = "L5_II_OCU_PEG_EPI_COSTS"
  override def dependsOn: Set[String] = Set("L2_II_OCU_PEG_EPI_COSTS")

  def createDataFrameWithoutDDL(sparkSession: SparkSession, loadedDependencies: Map[String, DataFrame], udfMap: Map[String, UserDefinedFunctionForDataLoader], runtimeVariables: RuntimeVariables): DataFrame = {
    import sparkSession.implicits._

    val l2IiOcuPegEpiCosts = loadedDependencies("L2_II_OCU_PEG_EPI_COSTS")

    l2IiOcuPegEpiCosts
      .select($"admit",
        $"amt_admin_fee",
        $"amt_cap_pay",
        $"amt_cob",
        $"amt_coin",
        $"amt_cop",
        $"amt_ded",
        $"amt_eqv",
        $"amt_eqv_adj",
        $"amt_liab",
        $"amt_not_covered",
        $"amt_np",
        $"amt_oth1",
        $"amt_oth2",
        $"amt_oth3",
        $"amt_oth4",
        $"amt_other_carrier_pay",
        $"amt_pay",
        $"amt_pay_adj",
        $"amt_req",
        $"amt_wth",
        $"complete".cast(ShortType),
        $"cost1",
        $"cost2",
        $"cost3",
        $"cost4",
        $"cost5",
        $"cost6",
        when($"disqualified_flag" === lit(true), 1).otherwise(lit(0)).cast(ShortType).as("disqualified_flag"),
        coalesce($"drg_id", lit("Unsp$UNK")).as("drg_id"),
        $"em_svc_flag",
        $"encounter",
        $"er_util",
        coalesce($"etg_id", lit(0)).as("etg_id"),
        coalesce($"etg_sev_level", lit(0)).cast(ShortType).as("etg_sev_level"),
        $"lab_util",
        when($"lag_ind" === lit(true), 1).otherwise(lit(0)).cast(ShortType).as("lag_ind"),
        $"lag_months",
        $"laterality",
        $"los",
        $"mem_attr_id",
        $"mri_util",
        $"network_paid_status_id",
        when($"network_status" === lit(true), 1).otherwise(lit(0)).cast(ShortType).as("network_status"),
        $"outlier".cast(ShortType),
        coalesce($"pcp_affil_id", lit("Unspecified$UNK")).as("pcp_affil_id"),
        coalesce($"pcp_assign", lit("0")).as("pcp_assign"),
        coalesce($"pcp_imp", lit("0")).as("pcp_imp"),
        $"peg_cat_id",
        coalesce($"peg_sev_level", lit(0)).cast(ShortType).as("peg_sev_level"),
        coalesce($"peg_target", lit(-1)).as("peg_target"),
        $"peg_window".cast(ShortType),
        coalesce($"pos_i", lit(0)).cast(ShortType).as("pos_i"),
        coalesce($"proccode", lit("UNK")).as("proccode"),
        coalesce($"provider_id", lit("0")).as("provider_id"),
        $"provider_status_id",
        coalesce($"prv_sp_4", lit(999)).as("prv_sp_4"),
        $"rad_util",
        coalesce($"resp_prov", lit("0")).as("resp_prov"),
        $"script",
        coalesce($"serv_prov_affil_id", lit("Unspecified$UNK")).as("serv_prov_affil_id"),
        $"tos_i_5",
        $"year_mth_id".cast(ShortType)
      )
  }
}
