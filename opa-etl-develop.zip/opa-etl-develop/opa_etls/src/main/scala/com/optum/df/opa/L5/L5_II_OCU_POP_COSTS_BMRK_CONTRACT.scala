package com.optum.df.opa.L5

import com.optum.df.opa.models.L5.l5_ii_ocu_pop_costs_bmrk_contract
import com.optum.oap.sparkdataloader.{RuntimeVariables, UserDefinedFunctionForDataLoader}
import org.apache.spark.sql.functions.{broadcast, coalesce, lit, max, sum}
import org.apache.spark.sql.{DataFrame, SparkSession}
import org.apache.spark.sql.functions.when
import org.apache.spark.sql.types.{DecimalType, LongType, ShortType}

object L5_II_OCU_POP_COSTS_BMRK_CONTRACT extends L5TableInfo[l5_ii_ocu_pop_costs_bmrk_contract] {
  override def name: String = "L5_II_OCU_POP_COSTS_BMRK_CONTRACT"
  override def dependsOn: Set[String] = Set("L2_II_OCU_POP_COSTS_CONTRACT", "L2_II_MAP_NTWRK_PAID_STATUS", "L2_II_MAP_DATE_RANGE","L2_II_MEM_ATTR","L2_II_MAP_TOS","L2_II_MAP_ETG", "L2_II_MAP_DRG")

  def createDataFrameWithoutDDL(sparkSession: SparkSession, loadedDependencies: Map[String, DataFrame], udfMap: Map[String, UserDefinedFunctionForDataLoader], runtimeVariables: RuntimeVariables): DataFrame = {
    import sparkSession.implicits._

    val l2IiOcuPopCostsContract = loadedDependencies("L2_II_OCU_POP_COSTS_CONTRACT")
    val l2MapNtwrkPaidStatus = loadedDependencies("L2_II_MAP_NTWRK_PAID_STATUS")
    val l2IiMapDateRange = loadedDependencies("L2_II_MAP_DATE_RANGE")
    val l2IiMemAttr = loadedDependencies("L2_II_MEM_ATTR")
    val l2IiMapTos = loadedDependencies("L2_II_MAP_TOS")
    val l2IiMapEtg = loadedDependencies("L2_II_MAP_ETG")
    val l2IiMapDrg = loadedDependencies("L2_II_MAP_DRG")

    val max_date = l2IiMapDateRange.agg(max("ia_time").as("ia_time")).first().getAs[Integer]("ia_time")
    val time_frame =
      l2IiMapDateRange
      .where($"ia_time" === lit(max_date))
      .select(
        $"year_mth_id",
        $"ia_time"
      )

    l2IiOcuPopCostsContract.as("pc")
      .join(time_frame.as("tf"), $"pc.year_mth_id" === $"tf.year_mth_id")
      .join(l2MapNtwrkPaidStatus.as("nps"), $"nps.network_paid_status_id" === $"pc.network_paid_status_id", "left")
      .join(l2IiMemAttr.as("ma"), $"pc.mem_attr_id" === $"ma.member_attr_id")
      .join(broadcast(l2IiMapTos).as("mt"), $"pc.tos_i_5" === $"mt.tos_i_5", "left")
      .join(broadcast(l2IiMapEtg).as("me"), $"pc.etg_id" === $"me.etg_id", "left")
      .join(broadcast(l2IiMapDrg).as("md"), $"pc.drg_id" === $"md.drg_id", "left")
      .groupBy(
        $"ma.age_cat2".cast(ShortType).as("age_cat2"),
        when($"ma.sex" === lit(true), 1).otherwise(lit(0)).cast(ShortType).as("sex"),
        $"ma.mpg_def_id",
        $"ma.coverage_status_id",
        $"ma.industry",
        $"ma.cat_status_cost3",
        $"tf.ia_time",
        when($"nps.network_status" === lit(true), 1).otherwise(lit(0)).as("network_status"),
        coalesce($"me.family", lit(0)).as("etg_family"),
        coalesce($"me.mpc", lit(0)).as("etg_mpc"),
        coalesce($"pc.pos_i", lit(0)).as("pos_i"),
        coalesce($"md.mdc", lit(0)).as("mdc"),
        coalesce($"md.drg_id", lit("Unsp$UNK")).as("drg_id"),
        $"mt.tos1_id",
        $"mt.tos2_id",
        $"mt.tos3_id",
        coalesce($"pc.th_flag".cast(ShortType), lit(-1.toShort)).as("th_flag"),
        coalesce($"pc.covid_flag".cast(ShortType), lit(-1.toShort)).as("covid_flag")
      )
      .agg(
        sum($"amt_np").cast(DecimalType(19, 2)).as("amt_np"),
        sum($"amt_pay").cast(DecimalType(19, 2)).as("amt_pay"),
        sum($"amt_oth1").cast(DecimalType(19, 2)).as("amt_oth1"),
        sum($"amt_cob").cast(DecimalType(19, 2)).as("amt_cob"),
        sum($"amt_oth4").cast(DecimalType(19, 2)).as("amt_oth4"),
        sum($"encounter").cast(DecimalType(19, 2)).as("encounter"),
        sum($"em_svc_flag").as("em_svc_flag"),
        sum($"rad_util").cast(DecimalType(19, 2)).as("rad_util"),
        sum($"lab_util").cast(DecimalType(19, 2)).as("lab_util"),
        sum($"mri_util").cast(DecimalType(19, 2)).as("mri_util"),
        sum($"er_util").cast(DecimalType(19, 2)).as("er_util"),
        sum($"los").cast(LongType).as("los"),
        sum($"admit").as("admit"),
        sum($"script").as("script"),
        sum($"amt_req").cast(DecimalType(19, 2)).as("amt_req"),
        sum($"amt_eqv").cast(DecimalType(19, 2)).as("amt_eqv"),
        sum($"amt_ded").cast(DecimalType(19, 2)).as("amt_ded"),
        sum($"amt_coin").cast(DecimalType(19, 2)).as("amt_coin"),
        sum($"amt_cop").cast(DecimalType(19, 2)).as("amt_cop"),
        sum($"amt_liab").cast(DecimalType(19, 2)).as("amt_liab"),
        sum($"amt_cap_pay").cast(DecimalType(19, 2)).as("amt_cap_pay"),
        sum($"amt_not_covered").cast(DecimalType(19, 2)).as("amt_not_covered"),
        sum($"amt_other_carrier_pay").cast(DecimalType(19, 2)).as("amt_other_carrier_pay"),
        sum($"amt_admin_fee").cast(DecimalType(19, 2)).as("amt_admin_fee"),
        lit("Y").as("dummy_email")
      )
  }
}
