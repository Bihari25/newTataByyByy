package com.optum.df.opa.L5

import com.optum.df.opa.models.L5.l5_ii_ocu_epi_costs_bmrk
import com.optum.oap.sparkdataloader.{RuntimeVariables, UserDefinedFunctionForDataLoader}
import com.optum.oadw.oadwModels.{l2_ii_map_date_range, l2_ii_map_tos, l2_ii_mem_attr}
import org.apache.spark.sql.functions._
import org.apache.spark.sql.types.{DecimalType, ShortType}
import org.apache.spark.sql.{DataFrame, SparkSession}

/**
  * Source query:
  * https://som-bb.humedica.net/projects/OAP/repos/oap-mstr-db-interface/browse/src/main/resources/src/build/L5/etl/II/internal_benchmark/L5_ii_ocu_epi_costs_bmrk_insert.sql
  *
  * Redshift Schema: opa_util/src/main/resources/OPADDL/L5/tables/L5_II_OCU_EPI_COSTS_BMRK.sql
  */
object L5_II_OCU_EPI_COSTS_BMRK extends L5TableInfo[l5_ii_ocu_epi_costs_bmrk] {
  override def name: String = "L5_II_OCU_EPI_COSTS_BMRK"
  override def dependsOn: Set[String] = Set("L2_II_OCU_EPI_COSTS","L2_II_MAP_DATE_RANGE","L2_II_MEM_ATTR","L2_II_MAP_TOS")

  def createDataFrameWithoutDDL(sparkSession: SparkSession, loadedDependencies: Map[String, DataFrame], udfMap: Map[String, UserDefinedFunctionForDataLoader], runtimeVariables: RuntimeVariables): DataFrame = {
    import sparkSession.implicits._

    val l2IiOcuEpiCosts = loadedDependencies("L2_II_OCU_EPI_COSTS")
    val l2IiMapDateRange = loadedDependencies("L2_II_MAP_DATE_RANGE")
    val l2IiMemAttr = loadedDependencies("L2_II_MEM_ATTR")
    val l2IiMapTos = loadedDependencies("L2_II_MAP_TOS")

    val max_date = l2IiMapDateRange.agg(max("ia_time").as("ia_time")).first().getAs[Integer]("ia_time")
    val time_frame =
      l2IiMapDateRange
        .where($"ia_time" === lit(max_date))
        .select(
          $"year_mth_id",
          $"ia_time"
        )

    l2IiOcuEpiCosts.as("ec")
        .join(time_frame.as("tf"), $"ec.year_mth_id" === $"tf.year_mth_id")
        .join(l2IiMemAttr.as("ma"), $"ec.mem_attr_id" === $"ma.member_attr_id")
        .join(l2IiMapTos.as("mt"), $"ec.tos_i_5" === $"mt.tos_i_5")
        .where($"ec.outlier" === lit(0) and $"ec.complete" === lit(true))
        .groupBy(
          $"ma.age_cat2".cast(ShortType).as("age_cat2"),
          when($"ma.sex" === lit(true), 1).otherwise(lit(0)).cast(ShortType).as("sex"),
          $"ma.mpg_def_id",
          $"ma.coverage_status_id",
          $"ma.industry",
          $"ma.cat_status_cost3",
          $"tf.ia_time".as("bmrk_time"),
          coalesce($"ec.etg_id", lit(0)).as("etg_id"),
          coalesce($"ec.sev_level", lit(0)).as("sev_level"),
          $"ec.tx_ind",
          when($"ec.network_status" === lit(true), 1).otherwise(lit(0)).as("network_status"),
          $"mt.tos1_id",
          $"mt.tos2_id",
          $"mt.tos3_id"
        )
        .agg(
          sum($"ec.cost1").as("cost1"),
          sum($"ec.cost2").as("cost2"),
          sum($"ec.cost3").as("cost3"),
          sum($"ec.cost4").as("cost4"),
          sum($"ec.cost5").as("cost5"),
          sum($"ec.cost6").as("cost6"),
          sum($"ec.encounter").as("encounter"),
          sum($"ec.em_svc_flag").as("em_svc_flag"),
          sum($"ec.rad_util").as("rad_util"),
          sum($"ec.lab_util").as("lab_util"),
          sum($"ec.mri_util").as("mri_util"),
          sum($"ec.er_util").as("er_util"),
          sum($"ec.los").as("los"),
          sum($"ec.admit").as("admit"),
          sum($"ec.script").as("script"),
          lit("Y").as("dummy_email")
        ).
      select(
        $"age_cat2",
        $"sex",
        $"mpg_def_id",
        $"coverage_status_id",
        $"industry",
        $"cat_status_cost3",
        $"bmrk_time",
        $"etg_id",
        $"sev_level",
        $"tx_ind",
        $"network_status",
        $"tos1_id",
        $"tos2_id",
        $"tos3_id",
        $"cost1".cast(DecimalType(19, 2)),
        $"cost2".cast(DecimalType(19, 2)),
        $"cost3".cast(DecimalType(19, 2)),
        $"cost4".cast(DecimalType(19, 2)),
        $"cost5".cast(DecimalType(19, 2)),
        $"cost6".cast(DecimalType(19, 2)),
        $"encounter".cast(DecimalType(19, 2)),
        $"em_svc_flag",
        $"rad_util".cast(DecimalType(19, 2)),
        $"lab_util".cast(DecimalType(19, 2)),
        $"mri_util".cast(DecimalType(19, 2)),
        $"er_util".cast(DecimalType(19, 2)),
        $"los",
        $"admit",
        $"script",
        $"dummy_email"
      )
  }
}
