package com.optum.df.opa.L5

import com.optum.df.opa.models.L5.l5_dict_score
import com.optum.oap.sparkdataloader.{RuntimeVariables, UserDefinedFunctionForDataLoader}
import org.apache.spark.sql.functions.{concat, lit}
import org.apache.spark.sql.types.{IntegerType, ShortType}
import org.apache.spark.sql.{DataFrame, SparkSession}


class L5_DICT_SCORE(val tableName: String, val scoreFamilyName: String) extends L5TableInfo[l5_dict_score] {
  override def name: String = tableName

  override def dependsOn: Set[String] = Set("L5_PAT_SCORE", "L4_DICT_SCORE", "L4_DICT_SCORE_FAMILY", "L5_TIMEFRAME")

  def createDataFrameWithoutDDL(sparkSession: SparkSession, loadedDependencies: Map[String, DataFrame], udfMap: Map[String, UserDefinedFunctionForDataLoader], runtimeVariables: RuntimeVariables): DataFrame = {
    import sparkSession.implicits._

    val l5PatScore = loadedDependencies("L5_PAT_SCORE")
    val l4DictScore = loadedDependencies("L4_DICT_SCORE")
    val l4DictScoreFamily = loadedDependencies("L4_DICT_SCORE_FAMILY")
    val l5Timeframe = loadedDependencies("L5_TIMEFRAME")

    l5PatScore.as("ps")
      .join(l4DictScore.as("ds"), $"ps.score_id" === $"ds.score_id", "inner")
      .join(l4DictScoreFamily.as("dsf"), $"ds.score_family_id" === $"dsf.score_family_id", "inner")
      .join(l5Timeframe.as("tf"), $"tf.timeframe_id" === $"ps.timeframe_id", "inner")
      .where($"dsf.score_family_name" === lit(scoreFamilyName))
      .select(
        $"ps.score_id",
        $"ds.score_name",
        $"ds.score_desc",
        $"ps.timeframe_id".cast(ShortType).as("timeframe_id"),
        $"ds.score_family_id",
        concat($"ps.score_id", $"ps.timeframe_id").cast(IntegerType).as("surr_id"),
        concat($"ds.score_name", lit(" in "), $"tf.timeframe_desc").as("score_time_name")
      ).distinct()
  }
}

object L5_DICT_SCORE_SDOH extends L5_DICT_SCORE("L5_DICT_SCORE_SDOH", "SDOH")
object L5_DICT_SCORE_AFIB extends L5_DICT_SCORE("L5_DICT_SCORE_AFIB", "AFIB Scores")
object L5_DICT_SCORE_ASCVD extends L5_DICT_SCORE("L5_DICT_SCORE_ASCVD", "ASCVD")
object L5_DICT_SCORE_CHARLSON extends L5_DICT_SCORE("L5_DICT_SCORE_CHARLSON", "Charlson")
object L5_DICT_SCORE_CMS_HCC extends L5_DICT_SCORE("L5_DICT_SCORE_CMS_HCC", "CMS-HCC")
object L5_DICT_SCORE_PREDIC_MODELS extends L5_DICT_SCORE("L5_DICT_SCORE_PREDIC_MODELS", "OA Predictive Models")
object L5_DICT_SCORE_SRE extends L5_DICT_SCORE("L5_DICT_SCORE_SRE", "SRE")
object L5_DICT_SCORE_DCSI extends L5_DICT_SCORE("L5_DICT_SCORE_DCSI", "DCSI")