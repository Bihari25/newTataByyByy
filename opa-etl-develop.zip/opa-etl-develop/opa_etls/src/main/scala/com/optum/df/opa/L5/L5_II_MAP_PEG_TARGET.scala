package com.optum.df.opa.L5

import com.optum.df.opa.models.L5.l5_ii_map_peg_target
import com.optum.oap.sparkdataloader.{RuntimeVariables, UserDefinedFunctionForDataLoader}
import org.apache.spark.sql.types.ShortType
import org.apache.spark.sql.{DataFrame, SparkSession}

object L5_II_MAP_PEG_TARGET extends L5TableInfo[l5_ii_map_peg_target] {
  override def name: String = "L5_II_MAP_PEG_TARGET"
  override def dependsOn: Set[String] = Set("L2_II_MAP_PEG_TARGET")

  def createDataFrameWithoutDDL(sparkSession: SparkSession, loadedDependencies: Map[String, DataFrame], udfMap: Map[String, UserDefinedFunctionForDataLoader], runtimeVariables: RuntimeVariables): DataFrame = {
    import sparkSession.implicits._

    val l2IiMapPegTarget = loadedDependencies("L2_II_MAP_PEG_TARGET")

    val defaultRow = Seq(
      l5_ii_map_peg_target(
        peg_target = -1,
        peg_target_desc = "Unspecified$UNK",
        sensitive_cat_id = 1.toShort,
        sensitive_ind = 0.toShort
      )
    ).toDF()

    l2IiMapPegTarget
      .select($"peg_target",
        $"peg_target_desc",
        $"sensitive_cat_id".cast(ShortType),
        $"sensitive_ind".cast(ShortType)
      ).union(defaultRow)
  }
}