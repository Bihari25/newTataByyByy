package com.optum.df.opa.L5

import com.optum.df.opa.models.L5.l5_ii_services_rx
import com.optum.oap.sparkdataloader.{RuntimeVariables, UserDefinedFunctionForDataLoader}
import org.apache.spark.sql.functions._
import org.apache.spark.sql.types.{IntegerType, ShortType, LongType}
import org.apache.spark.sql.{DataFrame, SparkSession}

object L5_II_SERVICES_RX extends L5TableInfo[l5_ii_services_rx] {
  override def name: String = "L5_II_SERVICES_RX"
  override def dependsOn: Set[String] = Set("L2_II_SERVICES_RX", "L2_II_MAP_DENIED_IND", "L2_II_MAP_DATE_RANGE", "L2_II_MEM_ATTR_MEMBER","L2_II_MAP_ACCOUNT","L2_II_MAP_AT_RISK_STATUS","L2_II_MAP_BIZ_SEGMENT","L2_II_MAP_PRODUCT","L2_II_PROVINFO","L2_II_MAP_PROV_AFFIL")

  private val UNSPECIFIED_UNKNOWN = "Unspecified$UNK"

  def createDataFrameWithoutDDL(sparkSession: SparkSession, loadedDependencies: Map[String, DataFrame], udfMap: Map[String, UserDefinedFunctionForDataLoader], runtimeVariables: RuntimeVariables): DataFrame = {
  import sparkSession.implicits._
      val l2IiServicesRx = loadedDependencies("L2_II_SERVICES_RX")
      val l2IiMapDeniedInd = loadedDependencies("L2_II_MAP_DENIED_IND")
      val l2IiMapDateRange = loadedDependencies("L2_II_MAP_DATE_RANGE")
      val l2IiMemAttrMember = loadedDependencies("L2_II_MEM_ATTR_MEMBER")
      val l2IiMapAccount = loadedDependencies("L2_II_MAP_ACCOUNT")
      val l2IiMapAtRiskStatus = loadedDependencies("L2_II_MAP_AT_RISK_STATUS")
      val l2IiMapBizSegment = loadedDependencies("L2_II_MAP_BIZ_SEGMENT")
      val l2IiMapProduct = loadedDependencies("L2_II_MAP_PRODUCT")
      val l2IiMapProvAffil = loadedDependencies("L2_II_MAP_PROV_AFFIL")
      val l2IiProvInfo = loadedDependencies("L2_II_PROVINFO")

      l2IiServicesRx.as("sr")
        .join((l2IiMapDeniedInd).as("dnd"), $"sr.denied_ind_id" === $"dnd.denied_ind_id", "left")
        .join(l2IiMapDateRange.as("mapdate"),
          $"mapdate.yr_month" === date_format($"sr.dos", "yyyyMM").cast(IntegerType) ,"inner")
        .join(l2IiMemAttrMember.as("mam"),
          $"sr.member"=== $"mam.member" && $"mam.year_mth_id" === $"mapdate.year_mth_id" &&
          $"sr.dos".between($"mam.mem_eff_dt", $"mam.mem_end_dt") &&
          $"sr.dos".between($"mam.sub_eff_dt", $"mam.sub_end_dt"), "inner")
        .join(l2IiMapAccount.as("ma"), $"mam.account_id"=== $"ma.account_id", "left")
        .join(l2IiMapAtRiskStatus.as("mars"),$"mam.at_risk_status_id"=== $"mars.at_risk_status_id","left")
        .join(l2IiMapBizSegment.as("mbs"),$"mam.biz_segment_id"=== $"mbs.biz_segment_id","left")
        .join(l2IiMapProduct.as("mp"),$"mam.product_id"=== $"mp.product_id","left")
        .join(l2IiMapProvAffil.as("mpa"),$"mam.pcp_affil_id"=== $"mpa.affil_id","left")
        .join(l2IiProvInfo.as("pi"),$"mam.pcp_assign"=== $"pi.provider_id","left")
        .select(
           $"mam.account_id",
           coalesce($"ma.account_lv1_id", $"ma.account_lv2_id", $"mam.account_id").as("account_lv1_id"),
           coalesce($"ma.account_lv2_id", $"ma.account_id").as("account_lv2_id"),
           $"sr.acw_srv",
           coalesce($"mpa.affil_id",lit(UNSPECIFIED_UNKNOWN)).as("affil_id"),
           $"sr.amt_admin_fee",
           $"sr.amt_cap_pay",
           $"sr.amt_cap_pay_k",
           $"sr.amt_cob",
           $"sr.amt_cob_k",
           $"sr.amt_coin",
           $"sr.amt_coin_k",
           $"sr.amt_cop",
           $"sr.amt_cop_k",
           $"sr.amt_ded",
           $"sr.amt_ded_k",
           $"sr.amt_disp",
           $"sr.amt_eqv",
           $"sr.amt_eqv_cf",
           $"sr.amt_eqv_k",
           $"sr.amt_ingr",
           $"sr.amt_liab",
           $"sr.amt_liab_k",
           $"sr.amt_not_covered",
           $"sr.amt_np",
           $"sr.amt_np_k",
           $"sr.amt_oth1",
           $"sr.amt_oth1_k",
           $"sr.amt_oth2",
           $"sr.amt_oth2_k",
           $"sr.amt_oth3",
           $"sr.amt_oth3_k",
           $"sr.amt_oth4",
           $"sr.amt_oth4_k",
           $"sr.amt_other_carrier_pay",
           $"sr.amt_pay",
           $"sr.amt_pay_cf",
           $"sr.amt_pay_k",
           $"sr.amt_req",
           $"sr.amt_req_k",
           $"sr.amt_sales_tax",
           $"sr.amt_wth",
           $"sr.amt_wth_k",
           coalesce($"mam.at_risk_status_id", lit(UNSPECIFIED_UNKNOWN)).as("at_risk_status_id"),
           coalesce($"mars.at_risk_status_lv1_id", $"mars.at_risk_status_lv2_id", $"mars.at_risk_status_id").as("at_risk_status_lv1_id"),
           coalesce($"mars.at_risk_status_lv2_id", $"mars.at_risk_status_id").as("at_risk_status_lv2_id"),
           coalesce($"mam.biz_segment_id", lit(UNSPECIFIED_UNKNOWN)).as("biz_segment_id"),
           coalesce($"mbs.biz_segment_lv1_id", $"mbs.biz_segment_lv2_id", $"mam.biz_segment_id").as("biz_segment_lv1_id"),
           coalesce($"mbs.biz_segment_lv2_id", $"mam.biz_segment_id").as("biz_segment_lv2_id"),
           when($"sr.cap_flag" === lit(true), lit("Y")).otherwise(lit("N")).as("cap_flag"),
           $"sr.channel",
           coalesce($"sr.claim_id",lit("0")).as("claim_id"),
           coalesce($"sr.clm_id_n",lit("0")).as("clm_id_n"),
           $"sr.clm_type",
           when($"sr.noenr_dos" === lit(true), lit(1)).
             when($"sr.pseudo" === lit(true), lit(2)).
             when($"sr.ia_time" === lit(3), lit(3)).
             otherwise(lit(0)).cast(ShortType).as("clm_exclude"),
           coalesce($"sr.clus_prv",lit("0")).as("clus_prv"),
           coalesce($"sr.cluster",lit("0")).cast(IntegerType).as("cluster"),
           coalesce($"sr.contract_id",lit(UNSPECIFIED_UNKNOWN)).as("contract_id"),
           $"sr.cust_rx_10",
           $"sr.cust_rx_11",
           $"sr.cust_rx_12",
           $"sr.cust_rx_13",
           $"sr.cust_rx_14",
           $"sr.cust_rx_15",
           $"sr.cust_rx_16",
           $"sr.cust_rx_17",
           $"sr.cust_rx_18",
           $"sr.cust_rx_19",
           $"sr.cust_rx_1",
           $"sr.cust_rx_20",
           $"sr.cust_rx_2",
           $"sr.cust_rx_3",
           $"sr.cust_rx_4",
           $"sr.cust_rx_5",
           $"sr.cust_rx_6",
           $"sr.cust_rx_7",
           $"sr.cust_rx_8",
           $"sr.cust_rx_9",
           $"sr.daw",
           $"sr.days_sup",
           $"sr.days_sup_k",
           $"sr.dcc",
           coalesce($"sr.dea",lit("0")).as("dea"),
           coalesce($"dnd.denied_ind",lit("0")).as("denied_ind"),
           coalesce($"sr.disrel",lit("0")).cast(IntegerType).as("disrel"),
           $"sr.dos",
           $"sr.enc_k",
           $"sr.encounter",
           coalesce($"sr.episode_id",lit("0")).cast(LongType).as("episode_id"),
           coalesce($"sr.etg",lit(0)).as("etg"),
           coalesce($"sr.etg_id",lit(0)).as("etg_id"),
           $"sr.exclude".cast(ShortType),
           $"sr.formulary",
           $"sr.gbo",
           $"sr.generic".cast(ShortType),
           $"sr.generic_k".cast(ShortType),
           $"sr.ia_time",
           $"sr.lag_days",
           $"sr.lag_ind".cast(ShortType),
           $"sr.map_srce_e",
           $"sr.map_srce_n",
           $"sr.map_srce_p",
           $"sr.member",
           $"sr.met_qty",
           $"sr.met_qty_k",
           coalesce($"sr.ndc",lit(0)).as("ndc"),
           coalesce($"sr.network_paid_status_id",lit(UNSPECIFIED_UNKNOWN)).as("network_paid_status_id"),
           $"sr.network_status".cast(ShortType),
           $"sr.noenr_dos".cast(ShortType),
           $"sr.pay_dt",
           coalesce($"mam.pcp_assign", lit("0")).as("pcp_assign"),
           coalesce($"sr.pres_provider_id",lit(0)).as("pres_provider_id"),
           $"sr.pres_prv_i",
           $"sr.prfl_clm",
           coalesce($"mam.product_id", lit(UNSPECIFIED_UNKNOWN)).as("product_id"),
           coalesce($"mp.product_lv1_id", lit("Unspecified LV1")).as("product_lv1_id"),
           coalesce($"mp.product_lv2_id", lit("Unspecified LV1#Unspecified LV2")).as("product_lv2_id"),
           coalesce($"mpa.prov_affil_lv1",lit("Unspecified LV1")).as("prov_affil_lv1"),
           coalesce($"mpa.prov_affil_lv2_id",lit("Unspecified LV2")).as("prov_affil_lv2_id"),
           coalesce($"sr.provider_id",lit(0)).as("provider_id"),
           coalesce($"sr.provider_status_id",lit(0)).as("provider_status_id"),
           coalesce($"sr.prv_sp_4",lit(999)).as("prv_sp_4"),
           $"sr.psc_cat1_id",
           $"sr.psc_cat2_id",
           $"sr.pseudo".cast(ShortType),
           coalesce($"sr.rec_type",lit(0)).as("rec_type"),
           $"sr.refill_num",
           $"sr.script",
           $"sr.script_gen".cast(ShortType),
           $"sr.script_gen_k".cast(ShortType),
           $"sr.script_k",
           coalesce($"sr.sev_level",lit(0)).as("sev_level"),
           coalesce($"sr.spec_rx_n_id",lit(UNSPECIFIED_UNKNOWN)).as("spec_rx_n_id"),
           $"sr.svc_grp",
           $"sr.tos_i_4",
           $"sr.tos_i_5",
           $"sr.uniq_rec_id",
           coalesce($"sr.covid_flag".cast(ShortType), lit(-1.toShort)).as("covid_flag")
    )
  }
}