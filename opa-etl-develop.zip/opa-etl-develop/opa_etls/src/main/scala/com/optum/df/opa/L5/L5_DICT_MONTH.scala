package com.optum.df.opa.L5

import com.optum.df.opa.models.L5.l5_dict_month
import com.optum.oap.sparkdataloader.{RuntimeVariables, UserDefinedFunctionForDataLoader}
import org.apache.spark.sql.{DataFrame, SparkSession}
import org.apache.spark.sql.types.ShortType


object L5_DICT_MONTH extends L5TableInfo[l5_dict_month] {

  override def name: String = "L5_DICT_MONTH"

  override def dependsOn: Set[String] = Set("L4_DICT_MONTH", "L5_II_MAP_DATE_RANGE")


  override def createDataFrameWithoutDDL(sparkSession: SparkSession, loadedDependencies: Map[String, DataFrame], udfMap: Map[String, UserDefinedFunctionForDataLoader], runtimeVariables: RuntimeVariables): DataFrame = {
    import sparkSession.implicits._

    val l4DictMonth = loadedDependencies("L4_DICT_MONTH")
    val l5IiMapDateRange = loadedDependencies("L5_II_MAP_DATE_RANGE")

    l4DictMonth.as("dm")
      .join(l5IiMapDateRange.as("mda"),$"mda.yr_month" === $"dm.month_id", "left")
      .join(l5IiMapDateRange.as("mdb"),$"mdb.yr_month" === $"dm.prev_year_month_id", "left")
      .select($"mda.year_mth_id",
        $"dm.month_id",
        $"dm.month_name",
        $"dm.month_short_name",
        $"dm.month_year_name",
        $"dm.month_year_short_name",
        $"dm.quarter_id",
        $"dm.year_id".cast(ShortType),
        $"dm.prev_month_id",
        $"dm.prev_quarter_month_id",
        $"dm.prev_year_month_id",
        $"mdb.year_mth_id".as("prior_year_mth_id")
      )
  }
}