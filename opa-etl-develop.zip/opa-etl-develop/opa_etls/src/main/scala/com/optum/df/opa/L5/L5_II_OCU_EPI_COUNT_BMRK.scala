package com.optum.df.opa.L5

import com.optum.df.opa.models.L5.l5_ii_ocu_epi_count_bmrk
import com.optum.oap.sparkdataloader.{RuntimeVariables, UserDefinedFunctionForDataLoader}
import com.optum.oadw.oadwModels.{l2_ii_map_date_range, l2_ii_mem_attr}
import org.apache.spark.sql.functions._
import org.apache.spark.sql.types.{DecimalType, ShortType}
import org.apache.spark.sql.{DataFrame, SparkSession}

/**
  * Source query:
  * https://som-bb.humedica.net/projects/OAP/repos/oap-mstr-db-interface/browse/src/main/resources/src/build/L5/etl/II/internal_benchmark/L5_ii_ocu_epi_count_bmrk_insert.sql
  *
  * Redshift Schema: opa_util/src/main/resources/OPADDL/L5/tables/L5_II_OCU_EPI_COUNT_BMRK.sql
  */
object L5_II_OCU_EPI_COUNT_BMRK extends L5TableInfo[l5_ii_ocu_epi_count_bmrk] {
  override def name: String = "L5_II_OCU_EPI_COUNT_BMRK"
  override def dependsOn: Set[String] = Set("L2_II_OCU_EPI_COUNT","L2_II_MAP_DATE_RANGE","L2_II_MEM_ATTR")

  def createDataFrameWithoutDDL(sparkSession: SparkSession, loadedDependencies: Map[String, DataFrame], udfMap: Map[String, UserDefinedFunctionForDataLoader], runtimeVariables: RuntimeVariables): DataFrame = {
    import sparkSession.implicits._

    val l2IiOcuEpiCount = loadedDependencies("L2_II_OCU_EPI_COUNT")
    val l2IiMapDateRange = loadedDependencies("L2_II_MAP_DATE_RANGE")
    val l2IiMemAttr = loadedDependencies("L2_II_MEM_ATTR")

    val max_date = l2IiMapDateRange.agg(max("ia_time").as("ia_time")).first().getAs[Integer]("ia_time")
    val time_frame =
      l2IiMapDateRange
      .where($"ia_time" === lit(max_date))
      .select(
        $"year_mth_id",
        $"ia_time"
      )

    l2IiOcuEpiCount.as("ec")
      .join(time_frame.as("tf"), $"ec.year_mth_id" === $"tf.year_mth_id")
      .join(l2IiMemAttr.as("ma"), $"ec.mem_attr_id" === $"ma.member_attr_id")
      .where($"ec.outlier" === lit(0) and $"ec.complete" === lit(true))
      .groupBy(
        $"ma.age_cat2".cast(ShortType).as("age_cat2"),
        when($"ma.sex" === lit(true), 1).otherwise(lit(0)).cast(ShortType).as("sex"),
        $"ma.mpg_def_id",
        $"ma.coverage_status_id",
        $"ma.cat_status_cost3",
        $"ma.industry",
        $"tf.ia_time",
        coalesce($"ec.etg_id", lit(0)).as("etg_id"),
        coalesce($"ec.sev_level", lit(0)).as("sev_level"),
        $"ec.tx_ind"
      )
      .agg(
        sum($"ec.epi_qty").as("epi_qty"),
        sum($"ec.rrisk").as("rrisk"),
        lit("Y").as("dummy_email")
      ).select(
      $"age_cat2",
        $"sex",
        $"mpg_def_id",
        $"coverage_status_id",
        $"industry",
        $"ia_time",
        $"cat_status_cost3",
        $"etg_id",
        $"sev_level",
        $"tx_ind",
        $"epi_qty".cast(DecimalType(19, 2)),
        $"rrisk".cast(DecimalType(10, 4)),
        $"dummy_email"
      )
  }
}
