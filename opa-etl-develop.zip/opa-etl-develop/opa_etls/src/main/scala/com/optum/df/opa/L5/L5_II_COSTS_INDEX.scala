package com.optum.df.opa.L5

import com.optum.df.opa.models.L5.l5_ii_costs_index
import com.optum.oap.sparkdataloader.{RuntimeVariables, UserDefinedFunctionForDataLoader}
import org.apache.spark.sql.{DataFrame, SparkSession}
import org.apache.spark.sql.functions.{coalesce, lit, max, sum, when}
import org.apache.spark.sql.types.DecimalType

class L5_II_COSTS_INDEX(val tableName:String, val dependentCostTable:String, val dependentCountTable:String, val dependentTableType:String, val countCalculatorColumn:String) extends L5TableInfo[l5_ii_costs_index] {

  override def name: String = tableName
  override def dependsOn: Set[String] = Set(dependentCostTable, dependentCountTable, "L2_II_MAP_PEER")

  def createDataFrameWithoutDDL(sparkSession: SparkSession, loadedDependencies: Map[String, DataFrame], udfMap: Map[String, UserDefinedFunctionForDataLoader], runtimeVariables: RuntimeVariables): DataFrame = {
    import sparkSession.implicits._

    val l5IiCosts = loadedDependencies(dependentCostTable)
    val l5IiCount = loadedDependencies(dependentCountTable)
    val l2IiMapPeer = loadedDependencies("L2_II_MAP_PEER")

    val calculateCostIndex = l5IiCosts.as("ec").
      join(l2IiMapPeer.as("mp"), $"ec.peer_def_id" === $"mp.peer_def_id", "inner").
      groupBy($"mp.peer_def_id", $"ec.provider_id", $"ec.ia_time", $"ec.phm_qual", $"ec.psc_cat1_id").
      agg(
        max($"mp.${dependentTableType}_hosp_pct").as("hosp_pct"),
        max($"mp.${dependentTableType}_lab_pct").as("lab_pct"),
        max($"mp.${dependentTableType}_er_pct").as("er_pct"),
        max($"mp.${dependentTableType}_pcc_pct").as("pcc_pct"),
        max($"mp.${dependentTableType}_rad_pct").as("rad_pct"),
        max($"mp.${dependentTableType}_spec_pct").as("spec_pct"),
        max($"mp.${dependentTableType}_phm_pct").as("phm_pct"),
        when(sum($"ec.cost_peer_tot") === lit(0), 0).otherwise(sum($"ec.cost_act_tot") / sum($"ec.cost_peer_tot")).as("cost_ind")
      ).select(
      $"mp.peer_def_id",
      $"ec.provider_id",
      $"ec.ia_time",
      $"ec.phm_qual",
      $"ec.psc_cat1_id",
      when($"ec.phm_qual" === lit(0),
        when($"ec.psc_cat1_id" === lit(1),
          when($"phm_pct" === lit(1), lit(0)).otherwise($"er_pct" / (lit(1) - $"phm_pct"))).
        when($"ec.psc_cat1_id" === lit(2),
          when($"phm_pct" === lit(1), lit(0)).otherwise($"hosp_pct" / (lit(1) - $"phm_pct"))).
        when($"ec.psc_cat1_id" === lit(3),
          when($"phm_pct" === lit(1), lit(0)).otherwise($"lab_pct" / (lit(1) - $"phm_pct"))).
        when($"ec.psc_cat1_id" === lit(4),
          when($"phm_pct" === lit(1), lit(0)).otherwise($"pcc_pct" / (lit(1) - $"phm_pct"))).
        when($"ec.psc_cat1_id" === lit(5),
          when($"phm_pct" === lit(1), lit(0)).otherwise($"rad_pct" / (lit(1) - $"phm_pct"))).
        when($"ec.psc_cat1_id" === lit(6),
          when($"phm_pct" === lit(1), lit(0)).otherwise($"spec_pct" / (lit(1) - $"phm_pct"))).
        when($"ec.psc_cat1_id" === lit(7), lit(0))
      ).when($"ec.phm_qual" === lit(1),
          when($"ec.psc_cat1_id" === lit(1),$"er_pct").
          when($"ec.psc_cat1_id" === lit(2), $"hosp_pct").
          when($"ec.psc_cat1_id" === lit(3), $"lab_pct").
          when($"ec.psc_cat1_id" === lit(4),$"pcc_pct").
          when($"ec.psc_cat1_id" === lit(5),$"rad_pct").
          when($"ec.psc_cat1_id" === lit(6),$"spec_pct").
          when($"ec.psc_cat1_id" === lit(7), $"phm_pct")
        ).as("psc_pct"),
      $"cost_ind"
    )

    val overallCostIndex = calculateCostIndex.groupBy(
      $"peer_def_id", $"provider_id", $"ia_time"
    ).agg(
      sum(when($"phm_qual" === lit(0), $"cost_ind" * $"psc_pct").otherwise(lit(0))).as("cost_over_ind_0"),
      sum(when($"phm_qual" === lit(1), $"cost_ind" * $"psc_pct").otherwise(lit(0))).as("cost_over_ind_1")
    ).select(
      $"peer_def_id",
      $"provider_id",
      $"ia_time",
      $"cost_over_ind_0",
      $"cost_over_ind_1"
    )

    val overallCostQuantity = l5IiCount.
      groupBy($"peer_def_id", $"provider_id", $"ia_time").
      agg(
        sum(when($"phm_qual" === lit(0), $"$countCalculatorColumn").otherwise(lit(0))).as("quantity_over_ind_0"),
        sum(when($"phm_qual" === lit(1), $"$countCalculatorColumn").otherwise(lit(0))).as("quantity_over_ind_1")
      ).
      select(
      $"peer_def_id",
      $"provider_id",
      $"ia_time",
      $"quantity_over_ind_0",
      $"quantity_over_ind_1"
    )

    overallCostQuantity.as("ocq").
      join(overallCostIndex.as("oci"), $"ocq.peer_def_id" === $"oci.peer_def_id"
        and $"ocq.provider_id" === $"oci.provider_id"
        and $"ocq.ia_time" === $"oci.ia_time",
        "left_outer").
      select(
        $"oci.peer_def_id",
        $"oci.provider_id",
        $"oci.ia_time",
        when(coalesce($"ocq.quantity_over_ind_0", lit(0)) + coalesce($"ocq.quantity_over_ind_1", lit(0)) === lit(0), 0).
          otherwise(
            ((coalesce($"oci.cost_over_ind_0", lit(0)) * coalesce($"ocq.quantity_over_ind_0", lit(0))) +
            (coalesce($"oci.cost_over_ind_1", lit(0)) * coalesce($"ocq.quantity_over_ind_1", lit(0)))) /
            (coalesce($"ocq.quantity_over_ind_0", lit(0)) + coalesce($"ocq.quantity_over_ind_1", lit(0)))
          ).cast(DecimalType(38, 18)).as("overall_cost_index")
      )
  }
}

object L5_II_EPI_COSTS_INDEX extends L5_II_COSTS_INDEX("L5_II_EPI_COSTS_INDEX", "L5_II_EPI_COSTS", "L5_II_EPI_COUNT", "epi", "epi_qty")
object L5_II_POP_COSTS_INDEX extends L5_II_COSTS_INDEX("L5_II_POP_COSTS_INDEX", "L5_II_POP_COSTS", "L5_II_POP_COUNT", "pop", "pcp_mmos")
