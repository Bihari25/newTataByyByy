package com.optum.df.opa.L5

import com.optum.df.opa.models.L5.l5_dict_diag
import com.optum.oap.sparkdataloader.{RuntimeVariables, UserDefinedFunctionForDataLoader}
import org.apache.spark.sql.{DataFrame, SparkSession}
import org.apache.spark.sql.types.ShortType


object L5_DICT_DIAG extends L5TableInfo[l5_dict_diag] {
  override def name: String = "L5_DICT_DIAG"
  override def dependsOn: Set[String] = Set("L2_DICT_DIAG")

  def createDataFrameWithoutDDL(sparkSession: SparkSession, loadedDependencies: Map[String, DataFrame], udfMap: Map[String, UserDefinedFunctionForDataLoader], runtimeVariables: RuntimeVariables): DataFrame = {
    import sparkSession.implicits._

    val l2DictDiag = loadedDependencies("L2_DICT_DIAG")
    val defaults = Seq(("Unknown", "Unknown", "0", "0", 0.toShort)).toDF()

    l2DictDiag.select(
      $"code_desc",
      $"code_name",
      $"code_type",
      $"diag_cd",
      $"sensitive_ind".cast(ShortType)
    ).union(defaults)
  }
}
