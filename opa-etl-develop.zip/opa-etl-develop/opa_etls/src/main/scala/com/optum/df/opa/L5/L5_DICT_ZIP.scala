package com.optum.df.opa.L5

import com.optum.df.opa.models.L5.{l5_dict_income_band, l5_dict_pct_band, l5_dict_zip}
import com.optum.oap.sparkdataloader.{RuntimeVariables, UserDefinedFunctionForDataLoader}
import com.optum.oadw.oadwModels.l2_dict_zip
import org.apache.spark.sql.functions._
import org.apache.spark.sql.types.{DecimalType, ShortType}
import org.apache.spark.sql.{DataFrame, SparkSession}
import org.apache.spark.sql.functions.udf

import scala.math.{round => scalaRound}

/**
  * Original Query: https://som-bb.humedica.net/projects/OAP/repos/oap-mstr-db-interface/browse/src/main/resources/src/build/L5/etl/OPA/L5_dict_zip_insert.sql
  *
  * REDSHIFT SCHEMA:
  */
object L5_DICT_ZIP  extends L5TableInfo[l5_dict_zip]{
  override def name: String = "L5_DICT_ZIP"

  override def dependsOn: Set[String] = Set("L2_DICT_ZIP", "L5_DICT_INCOME_BAND", "L5_DICT_PCT_BAND")

  def createDataFrameWithoutDDL(sparkSession: SparkSession, loadedDependencies: Map[String, DataFrame], udfMap: Map[String, UserDefinedFunctionForDataLoader], runtimeVariables: RuntimeVariables): DataFrame = {
    import sparkSession.implicits._

    val l2DictZip = loadedDependencies("L2_DICT_ZIP")
    val l5DictIncomeBand = loadedDependencies("L5_DICT_INCOME_BAND").as[l5_dict_income_band]
    val l5DictPctBand = loadedDependencies("L5_DICT_PCT_BAND").as[l5_dict_pct_band]

    // get the bands into memory ONCE right quick. Joining 7 times would suck in spark.
    // ...so would a function that pulls the band for every row seven times ;)
    val pctBands: Seq[l5_dict_pct_band] = l5DictPctBand.collect()
    val incomeBands: Seq[l5_dict_income_band] = l5DictIncomeBand.collect()

    val defaultValue = (-1).toShort

    // ...and write a null-safe band mapping function for Pct Bands
    def getPctBandByValue(javaDecimal: java.math.BigDecimal): java.lang.Short = {
      if (javaDecimal != null) {
        val value = scala.math.BigDecimal(javaDecimal)
        val roundedValue = scalaRound(value.toDouble)
        val matchingBand = pctBands.filter(band => band.pct_band_id > -1 && roundedValue >= band.pct_band_min && roundedValue <= band.pct_band_max)
        return getPctBand(matchingBand)
      }
      return defaultValue
    }

    def getPctBand(matchingBand: Seq[l5_dict_pct_band]): java.lang.Short ={
      if (matchingBand.nonEmpty)
        return matchingBand.head.pct_band_id.toShort
      return defaultValue
    }

    // ...and write a null safe band mapping function for Income Bands
    def getIncBandByValue(value: Integer): java.lang.Short = {
      if (value != null) {
        val matchingBand = incomeBands.filter(band => band.inc_band_id > -1 && value >= band.inc_band_min && value <= band.inc_band_max)
        return getIncBand(matchingBand)
      }
      return defaultValue
    }

    def getIncBand(matchingBand: Seq[l5_dict_income_band]): java.lang.Short ={
      if (matchingBand.nonEmpty)
        return matchingBand.head.inc_band_id.toShort
      return defaultValue
    }

    // ...and write a null-safe rounding function
    def nullSafeRoundToDecimal(javaDecimal: java.math.BigDecimal): BigDecimal = {
      if (javaDecimal != null) {
        val value = scala.math.BigDecimal(javaDecimal)
        return (value / 100).setScale(2, BigDecimal.RoundingMode.HALF_UP)
      }
      return null
    }

    def nullSafeRoundOfInteger(value: Integer): java.lang.Short = {
      if (value != null)
        return scalaRound(value.toDouble).toShort
      return null
    }

    val getPctBandByValueUDF = udf(getPctBandByValue _)
    val getIncBandByValueUDF = udf(getIncBandByValue _)
    val nullSafeRoundToDecimalUDF = udf(nullSafeRoundToDecimal _)
    val nullSafeRoundOfIntegerUDF = udf(nullSafeRoundOfInteger _)

    l2DictZip.select(
      $"zip",
      $"longitude",
      $"latitude",
      coalesce($"county_id",lit(0)).as("county_id"),
      coalesce(nullSafeRoundOfIntegerUDF($"cens_reg_id"), lit(-1)).cast(ShortType).as("cens_reg_id"),
      $"median_hh_inc_numeric",
      $"per_capita_inc_numeric",
      nullSafeRoundToDecimalUDF($"pct_below_200pct_poverty").cast(DecimalType(19, 4)).as("pct_below_200pct_poverty"),
      nullSafeRoundToDecimalUDF($"pct_grade_sch_or_less").cast(DecimalType(19, 4)).as("pct_grade_sch_or_less"),
      nullSafeRoundToDecimalUDF($"pct_eight_grade_or_less").cast(DecimalType(19, 4)).as("pct_eight_grade_or_less"),
      nullSafeRoundToDecimalUDF($"pct_some_hs_or_more").cast(DecimalType(19, 4)).as("pct_some_hs_or_more"),
      nullSafeRoundToDecimalUDF($"pct_bachelors_deg_or_more").cast(DecimalType(19, 4)).as("pct_bachelors_deg_or_more"),
      getIncBandByValueUDF($"median_hh_inc_numeric").as("median_hh_inc_band"),
      getIncBandByValueUDF($"per_capita_inc_numeric").as("per_capita_inc_band"),
      getPctBandByValueUDF($"pct_grade_sch_or_less").as("pct_grade_sch_or_less_band"),
      getPctBandByValueUDF($"pct_eight_grade_or_less").as("pct_eight_grade_or_less_band"),
      getPctBandByValueUDF($"pct_below_200pct_poverty").as("pct_below_200pct_poverty_band"),
      getPctBandByValueUDF($"pct_some_hs_or_more").as("pct_some_hs_or_more_band"),
      getPctBandByValueUDF($"pct_bachelors_deg_or_more").as("pct_bachelors_deg_or_more_band")

    )
  }
}