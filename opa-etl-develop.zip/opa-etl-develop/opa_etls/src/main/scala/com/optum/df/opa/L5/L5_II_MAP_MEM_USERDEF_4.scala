package com.optum.df.opa.L5

import com.optum.df.opa.models.L5.l5_ii_map_mem_userdef_4
import com.optum.oap.sparkdataloader.{RuntimeVariables, UserDefinedFunctionForDataLoader}
import com.optum.oadw.oadwModels.l2_ii_map_mem_userdef_4
import org.apache.spark.sql.functions.{coalesce, lit}
import org.apache.spark.sql.types.ShortType
import org.apache.spark.sql.{DataFrame, SparkSession}

object L5_II_MAP_MEM_USERDEF_4 extends L5TableInfo[l5_ii_map_mem_userdef_4]{
  override def name: String = "L5_II_MAP_MEM_USERDEF_4"

  override def dependsOn: Set[String] = Set("L2_II_MAP_MEM_USERDEF_4")

  def createDataFrameWithoutDDL(sparkSession: SparkSession, loadedDependencies: Map[String, DataFrame], udfMap: Map[String, UserDefinedFunctionForDataLoader], runtimeVariables: RuntimeVariables): DataFrame = {
    import sparkSession.implicits._

    val l2IIMapMemUserdef4 = loadedDependencies("L2_II_MAP_MEM_USERDEF_4")

    l2IIMapMemUserdef4.select(
      coalesce($"map_srce_e", lit("UNK")).as("map_srce_e"),
      coalesce($"mem_userdef_4", lit("Unspecified")).as("mem_userdef_4"),
      coalesce($"mem_userdef_4_desc", lit("Unspecified")).as("mem_userdef_4_desc"),
      $"mem_userdef_4_id",
      coalesce($"mem_userdef_4_lv1", $"mem_userdef_4_lv2", $"mem_userdef_4", lit("Unspecified")).as("mem_userdef_4_lv1"),
      coalesce($"mem_userdef_4_lv1_desc", $"mem_userdef_4_lv2_desc", $"mem_userdef_4_desc", lit("Unspecified")).as("mem_userdef_4_lv1_desc"),
      coalesce($"mem_userdef_4_lv1_id", $"mem_userdef_4_lv2_id", $"mem_userdef_4_id").as("mem_userdef_4_lv1_id"),
      coalesce($"mem_userdef_4_lv2", $"mem_userdef_4", lit("Unspecified")).as("mem_userdef_4_lv2"),
      coalesce($"mem_userdef_4_lv2_desc", $"mem_userdef_4_desc", lit("Unspecified")).as("mem_userdef_4_lv2_desc"),
      coalesce($"mem_userdef_4_lv2_id", $"mem_userdef_4_id").as("mem_userdef_4_lv2_id"),
      $"riflag".cast(ShortType)
    )
  }
}