package com.optum.df.opa.L5

import com.optum.df.opa.models.L5.l5_dict_proc
import com.optum.oap.sparkdataloader.{RuntimeVariables, UserDefinedFunctionForDataLoader}
import org.apache.spark.sql.types.ShortType
import org.apache.spark.sql.functions.{concat, lit}
import org.apache.spark.sql.{DataFrame, SparkSession}


object L5_DICT_PROC extends L5TableInfo[l5_dict_proc] {
  override def name: String = "L5_DICT_PROC"

  override def dependsOn: Set[String] = Set("L2_DICT_PROC")
  def createDataFrameWithoutDDL(sparkSession: SparkSession, loadedDependencies: Map[String, DataFrame], udfMap: Map[String, UserDefinedFunctionForDataLoader], runtimeVariables: RuntimeVariables): DataFrame = {
    import sparkSession.implicits._

    val l2DictProc = loadedDependencies("L2_DICT_PROC")
    val defaultRow = Seq(("0", "0", "Unknown", "Unknown", "0 Unknown", 0.toShort)).toDF()

    l2DictProc
      .select(
        $"code_type",
        $"proc_cd",
        $"code_name",
        $"code_desc",
        concat($"proc_cd", lit(" "), $"code_desc").as("proc_desc"),
        $"sensitive_ind".cast(ShortType)
    ).union(defaultRow)
  }
}