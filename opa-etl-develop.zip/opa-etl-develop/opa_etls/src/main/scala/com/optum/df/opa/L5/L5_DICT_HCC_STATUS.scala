package com.optum.df.opa.L5

import com.optum.df.opa.models.L5.l5_dict_hcc_status
import com.optum.oap.sparkdataloader.{RuntimeVariables, UserDefinedFunctionForDataLoader}
import org.apache.spark.sql.functions._
import org.apache.spark.sql.{DataFrame, SparkSession}

object L5_DICT_HCC_STATUS extends L5TableInfo[l5_dict_hcc_status] {
  override def name: String = "L5_DICT_HCC_STATUS"

  override def dependsOn: Set[String] = Set("L5_PAT_HCC_OPPORTUNITY")
  def createDataFrameWithoutDDL(sparkSession: SparkSession, loadedDependencies: Map[String, DataFrame], udfMap: Map[String, UserDefinedFunctionForDataLoader], runtimeVariables: RuntimeVariables): DataFrame = {
    import sparkSession.implicits._

    val l5PatHccOpportunity = loadedDependencies("L5_PAT_HCC_OPPORTUNITY")

    l5PatHccOpportunity
      .select(
        $"tytd_coded_id",
        $"hcc_coded_desc"
      ).distinct()
  }
}