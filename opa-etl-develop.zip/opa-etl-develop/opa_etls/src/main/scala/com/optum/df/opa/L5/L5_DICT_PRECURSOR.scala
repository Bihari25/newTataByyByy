package com.optum.df.opa.L5

import com.optum.df.opa.models.L5.l5_dict_precursor
import com.optum.oap.sparkdataloader.{RuntimeVariables, UserDefinedFunctionForDataLoader}
import org.apache.spark.sql.functions.{lit, when}
import org.apache.spark.sql.types.ShortType
import org.apache.spark.sql.{DataFrame, SparkSession}

/**
  * Source query:
  * https://som-bb.humedica.net/projects/OAP/repos/oap-mstr-db-interface/browse/src/main/resources/src/build/L5/ddl/views/OPA/L5_dict_precursor.sql
  *
  * Redshift Schema: opa_util/src/main/resources/OPADDL/L5/tables/L5_DICT_PRECURSOR.sql
  */

object L5_DICT_PRECURSOR extends L5TableInfo[l5_dict_precursor] {
  override def name: String = "L5_DICT_PRECURSOR"
  override def dependsOn: Set[String] = Set("L3_DICT_PRECURSOR", "L3_MAP_SCORE_GRP_PRECUR")

  def createDataFrameWithoutDDL(sparkSession: SparkSession, loadedDependencies: Map[String, DataFrame], udfMap: Map[String, UserDefinedFunctionForDataLoader], runtimeVariables: RuntimeVariables): DataFrame = {
    import sparkSession.implicits._

    val l3_dictprecursor = loadedDependencies("L3_DICT_PRECURSOR")
    val l3_mapscore_grp_precur = loadedDependencies("L3_MAP_SCORE_GRP_PRECUR")
    val distinct_l3_mapscore_grp_precur = l3_mapscore_grp_precur.where($"grp_id" === lit(2)).select($"precursor_id").distinct

    l3_dictprecursor.as("dp")
      .join(distinct_l3_mapscore_grp_precur.as("ms"), $"dp.precursor_id" === $"ms.precursor_id", "left_outer")
      .select($"dp.precursor_id",
        $"dp.precursor_name",
        $"dp.precursor_desc",
        $"dp.sensitive_ind",
        $"dp.active_ind",
        $"dp.precursor_domain_cd",
        when($"ms.precursor_id".isNotNull, lit(1)).otherwise(lit(0)).cast(ShortType).as("chronic_ind")
      )
  }
}