package com.optum.df.opa.L5

import com.optum.df.opa.models.L5.l5_dict_peg_window
import com.optum.oap.sparkdataloader.{RuntimeVariables, UserDefinedFunctionForDataLoader}
import org.apache.spark.sql.{DataFrame, SparkSession}

object L5_DICT_PEG_WINDOW extends L5TableInfo[l5_dict_peg_window]{
  override def name: String = "L5_DICT_PEG_WINDOW"

  override def dependsOn: Set[String] = Set.empty

  def createDataFrameWithoutDDL(sparkSession: SparkSession, loadedDependencies: Map[String, DataFrame], udfMap: Map[String, UserDefinedFunctionForDataLoader], runtimeVariables: RuntimeVariables): DataFrame = {
    import sparkSession.implicits._

        Seq(l5_dict_peg_window(1.toShort, "Pre-anchor date or on the anchor date"),
          l5_dict_peg_window(2.toShort, "Post-anchor date"))
          .toDF("peg_window", "peg_window_desc")
  }
}
