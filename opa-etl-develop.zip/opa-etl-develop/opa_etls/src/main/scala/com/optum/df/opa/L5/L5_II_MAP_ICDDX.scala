package com.optum.df.opa.L5

import com.optum.df.opa.models.L5.l5_ii_map_icddx
import com.optum.oap.sparkdataloader.{RuntimeVariables, UserDefinedFunctionForDataLoader}
import org.apache.spark.sql.functions._
import org.apache.spark.sql.{DataFrame, SparkSession}

/**
  * Source query:
  * https://som-bb.humedica.net/projects/OAP/repos/oap-mstr-db-interface/browse/src/main/resources/src/build/L5/etl/II/L5_ii_map_icddx.sql
  *
  * Redshift Schema: opa_util/src/main/resources/OPADDL/L5/tables/L5_II_MAP_ICDDX.sql
  */
object L5_II_MAP_ICDDX extends L5TableInfo[l5_ii_map_icddx] {
  override def name: String = "L5_II_MAP_ICDDX"
  override def dependsOn: Set[String] = Set("L2_II_MAP_ICDDX","L2_II_QL_CONF","L2_II_QL_CLAIMS")

  def createDataFrameWithoutDDL(sparkSession: SparkSession, loadedDependencies: Map[String, DataFrame], udfMap: Map[String, UserDefinedFunctionForDataLoader], runtimeVariables: RuntimeVariables): DataFrame = {
    import sparkSession.implicits._

    val l2IiMapIcddx = loadedDependencies("L2_II_MAP_ICDDX")
    val l2IiQlConf = loadedDependencies("L2_II_QL_CONF")
    val l2IiQlClaims = loadedDependencies("L2_II_QL_CLAIMS")

    //The below Seq are arranged in the order "icddx", "icddx_desc", "icd_version"
    val defaultRows = Seq(("0", "Not Supported DX Code 0", 9),
                          ("0", "Not Supported DX Code 0", 0)).toDF()

    val icddx =
      l2IiMapIcddx.select(
        concat($"icddx", $"icd_version").as("icddx_id")
      ).distinct

    val notSupportedCodesFromL2IIQlConf =
      l2IiQlConf.as("qc")
        .join(icddx.as("ix"), concat($"qc.diag1", $"qc.icd_version") === $"ix.icddx_id", "left")
        .select(
          coalesce($"diag1", lit("0")).as("icddx"),
          concat(lit("Not Supported DX Code "), coalesce($"diag1", lit("0"))).as("icddx_desc"),
          $"icd_version"
        ).where(
          $"ix.icddx_id".isNull and concat($"qc.diag1", $"qc.icd_version").isNotNull
        )


    val notSupportedCodesFromQlClaims =
      l2IiQlClaims.as("qc")
        .join(icddx.as("ix"), concat($"qc.diag1", $"qc.icd_version") === $"ix.icddx_id", "left")
        .select(
          coalesce($"diag1", lit("0")).as("icddx"),
          concat(lit("Not Supported DX Code "), coalesce($"diag1", lit("0"))).as("icddx_desc"),
          $"icd_version"
        ).where(
          $"ix.icddx_id".isNull and concat($"qc.diag1", $"qc.icd_version").isNotNull
        )

    l2IiMapIcddx.select(
      $"icddx",
      $"icddx_desc",
      $"icd_version"
    ).union(
      defaultRows
    ).union(
      notSupportedCodesFromL2IIQlConf
    ).union(
      notSupportedCodesFromQlClaims
    ).distinct
  }
}
