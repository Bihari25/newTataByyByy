package com.optum.df.opa.L5

import com.optum.df.opa.models.L5.l5_ii_ocu_member_contract
import com.optum.oap.sparkdataloader.{RuntimeVariables, UserDefinedFunctionForDataLoader}
import org.apache.spark.sql.functions._
import org.apache.spark.sql.types.{IntegerType, ShortType}
import org.apache.spark.sql.{DataFrame, SparkSession}


object L5_II_OCU_MEMBER_CONTRACT extends L5TableInfo[l5_ii_ocu_member_contract]{
  override def name: String = "L5_II_OCU_MEMBER_CONTRACT"

  override def dependsOn: Set[String] = Set("L2_II_OCU_MEMBER_CONTRACT", "L2_II_MEM_ATTR", "L2_II_MAP_ACCOUNT")

  def createDataFrameWithoutDDL(sparkSession: SparkSession, loadedDependencies: Map[String, DataFrame], udfMap: Map[String, UserDefinedFunctionForDataLoader], runtimeVariables: RuntimeVariables): DataFrame = {

    import sparkSession.implicits._

    val l2IIOcuMemberContract = loadedDependencies("L2_II_OCU_MEMBER_CONTRACT")
    val l2IIMemAttr = loadedDependencies("L2_II_MEM_ATTR")
    val l2IIMapAccount = loadedDependencies("L2_II_MAP_ACCOUNT")

    l2IIOcuMemberContract.as("om")
      .join(l2IIMemAttr.as("ma"),$"om.mem_attr_id" === $"ma.member_attr_id", "inner")
      .join(l2IIMapAccount.as("mac"), $"ma.account_id" === $"mac.account_id", "inner")
      .select($"year_mth_id".cast(ShortType),
        $"mem_attr_id",
        when($"pcp_affil_id".isNull,"Unspecified$UNK")
          .otherwise($"pcp_affil_id").as("pcp_affil_id"),
        when($"pcp_assign".isNull,"0")
          .otherwise($"pcp_assign").as("pcp_assign"),
        when($"pcp_imp".isNull, "0")
          .otherwise($"pcp_imp").as("pcp_imp"),
        $"iatime_lag".cast(ShortType),
        $"mm".cast(IntegerType),
        $"mm_den".cast(IntegerType),
        $"mm_rx".cast(IntegerType),
        $"subscr_months",
        $"age_tot",
        $"rrisk",
        $"prisk",
        $"premium_tot",
        coalesce($"mac.account_lv1_id", $"mac.account_lv2_id", $"mac.account_id").as("account_lv1_id"),
        coalesce($"mac.account_lv2_id", $"mac.account_id").as("account_lv2_id"),
        $"mac.account_id".as("account_id"),
        $"om.contract_id",
        $"om.contract_prisk",
        $"om.contract_rrisk",
        $"om.primary_payer_ind".cast(ShortType)
      )
  }

}
