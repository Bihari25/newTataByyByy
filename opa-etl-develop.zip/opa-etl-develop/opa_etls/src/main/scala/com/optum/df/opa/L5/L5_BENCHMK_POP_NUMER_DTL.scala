package com.optum.df.opa.L5

import com.optum.df.opa.models.L5.l5_benchmk_pop_numer_dtl
import com.optum.oap.sparkdataloader.{RuntimeVariables, UserDefinedFunctionForDataLoader}
import org.apache.spark.sql.functions._
import org.apache.spark.sql.types.{DecimalType, IntegerType, ShortType}
import org.apache.spark.sql.{DataFrame, SparkSession}


/**
  * Source query:
  * https://som-bb.humedica.net/projects/OAP/repos/oap-mstr-db-interface/browse/src/main/resources/src/build/L5/etl/OPA/L5_benchmk_pop_numer_dtl_insert.sql
  *
  * Redshift Schema: opa_util/src/main/resources/OPADDL/L5/tables/L5_BENCHMK_POP_NUMER_DTL.sql
  */

object L5_BENCHMK_POP_NUMER_DTL extends L5TableInfo[l5_benchmk_pop_numer_dtl] {
  override def name: String = "L5_BENCHMK_POP_NUMER_DTL"
  override def dependsOn: Set[String] = Set("L2_BMK_POP_NUM_DETAIL","L2_II_MAP_TOS")

  def createDataFrameWithoutDDL(sparkSession: SparkSession, loadedDependencies: Map[String, DataFrame], udfMap: Map[String, UserDefinedFunctionForDataLoader], runtimeVariables: RuntimeVariables): DataFrame = {
    import sparkSession.implicits._

    val l2BenchmkPopNumerDtl = loadedDependencies("L2_BMK_POP_NUM_DETAIL")
    val l2IiMapTos = loadedDependencies("L2_II_MAP_TOS")

    l2BenchmkPopNumerDtl.as("pn")
        .join(l2IiMapTos.as("mt"), $"pn.tos_i_5" === $"mt.tos_i_5")
        .groupBy($"year", $"lag_months", $"cens_reg", $"age_cat2", $"sex", $"mt.tos1_id", $"mt.tos2_id", $"mt.tos3_id")
      .agg(round(sum($"pn.encounters"), 2).as("encounters"),
        round(sum($"pn.amt_np"), 2).as("amt_np"),
        sum($"pn.admit").alias("admit"),
        sum($"pn.los").alias("los"),
        sum($"script").alias("script"),
        round(sum($"rad_util"), 2).as("rad_util"),
        round(sum($"lab_util"), 2).as("lab_util"),
        round(sum($"mri_util"), 2).as("mri_util"),
        round(sum($"er_util"), 2).as("er_util")).
      select(
        $"pn.year".cast(ShortType),
        $"pn.lag_months",
        $"pn.cens_reg".cast(ShortType),
        $"pn.age_cat2".cast(ShortType).as("age_cat2"),
        $"pn.sex".cast(ShortType),
        $"mt.tos1_id",
        $"mt.tos2_id",
        $"mt.tos3_id",
        $"encounters".cast(DecimalType(19, 2)),
        $"amt_np".cast(DecimalType(19, 2)),
        $"admit".cast(IntegerType),
        $"los".cast(IntegerType),
        $"script".cast(IntegerType),
        $"rad_util".cast(DecimalType(19, 2)),
        $"lab_util".cast(DecimalType(19, 2)),
        $"mri_util".cast(DecimalType(19, 2)),
        $"er_util".cast(DecimalType(19, 2)),
        lit("Y").as("dummy_email")
      )
  }
}
