package com.optum.df.opa.L5

import com.optum.df.opa.models.L5.l5_ii_dict_cov_stat_lv1
import com.optum.oap.sparkdataloader.{RuntimeVariables, UserDefinedFunctionForDataLoader}
import com.optum.oadw.oadwModels.l2_ii_map_coverage_status
import org.apache.spark.sql.functions._
import org.apache.spark.sql.{DataFrame, SparkSession}

object L5_II_DICT_COV_STAT_LV1 extends L5TableInfo[l5_ii_dict_cov_stat_lv1] {
  override def name: String = "L5_II_DICT_COV_STAT_LV1"
  override def dependsOn: Set[String] = Set("L2_II_MAP_COVERAGE_STATUS")


def createDataFrameWithoutDDL(sparkSession: SparkSession, loadedDependencies: Map[String, DataFrame], udfMap: Map[String, UserDefinedFunctionForDataLoader], runtimeVariables: RuntimeVariables): DataFrame = {
    import sparkSession.implicits._

    val l2IIMapCoverageStatus = loadedDependencies("L2_II_MAP_COVERAGE_STATUS")

    l2IIMapCoverageStatus.select(
      coalesce($"coverage_status_lv1_id", $"coverage_status_lv2_id", $"coverage_status_id").as("coverage_status_lv1_id"),
      coalesce($"coverage_status_lv1_desc", $"coverage_status_lv2_desc", $"coverage_status_desc").as("coverage_status_lv1_desc")
    ).distinct()
  }
}

