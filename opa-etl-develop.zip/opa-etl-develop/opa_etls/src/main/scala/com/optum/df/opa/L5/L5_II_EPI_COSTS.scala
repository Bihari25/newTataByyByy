package com.optum.df.opa.L5

import com.optum.df.opa.models.L5.l5_ii_epi_costs
import com.optum.oap.sparkdataloader.{RuntimeVariables, TableInfo, UserDefinedFunctionForDataLoader}
import org.apache.spark.sql.functions._
import org.apache.spark.sql.types.ShortType
import org.apache.spark.sql.{DataFrame, SparkSession}

object L5_II_EPI_COSTS extends L5TableInfo[l5_ii_epi_costs] {
  override def name: String = "L5_II_EPI_COSTS"
  override def dependsOn: Set[String] = Set("L2_II_EPI_COSTS")

  def createDataFrameWithoutDDL(sparkSession: SparkSession, loadedDependencies: Map[String, DataFrame], udfMap: Map[String, UserDefinedFunctionForDataLoader], runtimeVariables: RuntimeVariables): DataFrame = {
    import sparkSession.implicits._

    val l2IiEpiCosts = loadedDependencies("L2_II_EPI_COSTS")

    l2IiEpiCosts.as("ec")

      .select(
        coalesce($"ec.PROVIDER_ID", lit("0")).as("PROVIDER_ID"),
        $"ec.PEER_DEF_ID",
        coalesce($"ec.PRODUCT_ID", lit("Unspecified$UNK")).as("PRODUCT_ID"),
        $"ec.PSC_CAT1_ID",
        $"ec.IA_TIME",
        $"ec.IA_TIME_ADJ",
        $"ec.UTIL_SPEC_CAT_CD",
        $"ec.CAT_MEMBER",
        when($"ec.SPECPRV" === lit(true), 1).otherwise(lit(0)).cast(ShortType).as("SPECPRV"),
        when($"ec.PHM_QUAL" === lit(true), 1).otherwise(lit(0)).cast(ShortType).as("PHM_QUAL"),
        $"ec.ETG_ID",
        $"ec.ETG_UNIT_ID",
        $"ec.SEV_LEVEL",
        $"ec.ADMIT_ACT_TOT",
        $"ec.ADMIT_PEER_TOT",
        $"ec.COST2_ACT_TOT",
        $"ec.COST2_PEER_TOT",
        $"ec.COST3_ACT_TOT",
        $"ec.COST3_PEER_TOT",
        $"ec.COST_ACT_TOT",
        $"ec.COST_PEER_TOT",
        $"ec.DAYS_ACT_TOT",
        $"ec.DAYS_PEER_TOT",
        $"ec.ENC_ACT_TOT",
        $"ec.ENC_PEER_TOT",
        $"ec.ER_ACT_TOT",
        $"ec.ER_PEER_TOT",
        $"ec.GEN_ACT_TOT",
        $"ec.GEN_PEER_TOT",
        $"ec.LAB_ACT_TOT",
        $"ec.LAB_PEER_TOT",
        $"ec.MRI_ACT_TOT",
        $"ec.MRI_PEER_TOT",
        $"ec.OSPVIS_ACT_TOT",
        $"ec.OSPVIS_PEER_TOT",
        $"ec.RAD_ACT_TOT",
        $"ec.RAD_PEER_TOT",
        $"ec.SPVIS_ACT_TOT",
        $"ec.SPVIS_PEER_TOT",
        $"ec.SCRIPT_ACT_TOT",
        $"ec.SCRIPT_GEN_ACT_TOT",
        $"ec.SCRIPT_PEER_TOT"

      )
  }
}