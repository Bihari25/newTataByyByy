package com.optum.df.opa.L5

import com.optum.df.opa.models.L5.l5_ii_dict_biz_segment_lv2
import com.optum.oap.sparkdataloader.{RuntimeVariables, UserDefinedFunctionForDataLoader}
import com.optum.oadw.oadwModels.l2_ii_map_biz_segment
import org.apache.spark.sql.functions._
import org.apache.spark.sql.{DataFrame, SparkSession}


object L5_II_DICT_BIZ_SEGMENT_LV2 extends L5TableInfo[l5_ii_dict_biz_segment_lv2] {
  override def name: String = "L5_II_DICT_BIZ_SEGMENT_LV2"

  override def dependsOn: Set[String] = Set("L2_II_MAP_BIZ_SEGMENT")


  def createDataFrameWithoutDDL(sparkSession: SparkSession, loadedDependencies: Map[String, DataFrame], udfMap: Map[String, UserDefinedFunctionForDataLoader], runtimeVariables: RuntimeVariables): DataFrame = {
    import sparkSession.implicits._

    val l2IIMapBizSegment = loadedDependencies("L2_II_MAP_BIZ_SEGMENT")

    l2IIMapBizSegment.select(
      coalesce($"biz_segment_lv2_id", $"biz_segment_id").as("biz_segment_lv2_id"),
      coalesce($"biz_segment_lv2_desc", $"biz_segment_desc").as("biz_segment_lv2_desc"),
      coalesce($"biz_segment_lv1_id", $"biz_segment_lv2_id", $"biz_segment_id").as("biz_segment_lv1_id")
    ).distinct()
  }
}
