package com.optum.df.opa.L5

import com.optum.df.opa.models.L5.l5_map_amb_site
import com.optum.oap.sparkdataloader.{RuntimeVariables, TableInfo, UserDefinedFunctionForDataLoader}
import com.optum.oadw.oadwModels.l2_map_amb_site
import org.apache.spark.sql.functions.regexp_replace
import org.apache.spark.sql.{DataFrame, SparkSession}


/**
  * Source query:
  * https://som-bb.humedica.net/projects/OAP/repos/oap-mstr-db-interface/browse/src/main/resources/src/build/L5/etl/OPA/L5_map_amb_site_insert.sql
  *
  * Redshift Schema: opa_util/src/main/resources/OPADDL/L5/tables/L5_MAP_AMB_SITE.sql
  */

object L5_MAP_AMB_SITE extends L5TableInfo[l5_map_amb_site] {
  override def name: String = "L5_MAP_AMB_SITE"

  override def dependsOn: Set[String] = Set("L2_MAP_AMB_SITE")

  def createDataFrameWithoutDDL(sparkSession: SparkSession, loadedDependencies: Map[String, DataFrame], udfMap: Map[String, UserDefinedFunctionForDataLoader], runtimeVariables: RuntimeVariables): DataFrame = {
    import sparkSession.implicits._

    val l2MapAmbSite = loadedDependencies("L2_MAP_AMB_SITE")

    l2MapAmbSite.as("mas").select(
      $"mas.amb_site_id",
      regexp_replace($"mas.amb_site_desc", "\\(.*", "").as("amb_site_desc")  //Removes all the content after first open bracket
    )
  }
}
