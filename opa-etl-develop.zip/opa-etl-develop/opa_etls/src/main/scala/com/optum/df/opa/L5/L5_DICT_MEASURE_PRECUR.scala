package com.optum.df.opa.L5

import com.optum.df.opa.models.L5.l5_dict_measure_precur
import com.optum.oap.sparkdataloader.{RuntimeVariables, UserDefinedFunctionForDataLoader}
import org.apache.spark.sql.{DataFrame, SparkSession}

object L5_DICT_MEASURE_PRECUR extends L5TableInfo[l5_dict_measure_precur] {
  override def name: String = "L5_DICT_MEASURE_PRECUR"
  override def dependsOn: Set[String] = Set("L5_MAP_MEASURE_PRECUR")

  def createDataFrameWithoutDDL(sparkSession: SparkSession, loadedDependencies: Map[String, DataFrame], udfMap: Map[String, UserDefinedFunctionForDataLoader], runtimeVariables: RuntimeVariables): DataFrame = {
    import sparkSession.implicits._

    val l5MapMeasurePrecur = loadedDependencies("L5_MAP_MEASURE_PRECUR")

    l5MapMeasurePrecur
      .select($"measure_id",
        $"precursor_id",
        $"measure_precursor_desc")
      .distinct()

  }
}
