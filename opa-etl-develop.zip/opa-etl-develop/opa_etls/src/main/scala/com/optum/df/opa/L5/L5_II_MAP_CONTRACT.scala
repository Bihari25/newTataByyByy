package com.optum.df.opa.L5

import com.optum.df.opa.models.L5.l5_ii_map_contract
import com.optum.oap.sparkdataloader.{RuntimeVariables, UserDefinedFunctionForDataLoader}
import org.apache.spark.sql.functions.{coalesce, when, lit}
import org.apache.spark.sql.types.{ShortType, IntegerType}
import org.apache.spark.sql.{DataFrame, SparkSession}

object L5_II_MAP_CONTRACT extends L5TableInfo[l5_ii_map_contract]{
  override def name: String = "L5_II_MAP_CONTRACT"

  override def dependsOn: Set[String] = Set("L2_II_MAP_CONTRACT")

  def createDataFrameWithoutDDL(sparkSession: SparkSession, loadedDependencies: Map[String, DataFrame], udfMap: Map[String, UserDefinedFunctionForDataLoader], runtimeVariables: RuntimeVariables): DataFrame = {
    import sparkSession.implicits._

    val l2IIMapContract = loadedDependencies("L2_II_MAP_CONTRACT")
    val defaultRow = Seq(("Unspecified$UNK", "Unspecified", "Unspecified", "Unspecified LV1#Unspecified LV2", "Unspecified LV2", "Unspecified", "Unspecified LV1", "Unspecified LV1", "Unspecified", 99.toShort, "UNK", 1.toShort, null)).toDF()

    val tempL5IiMapContract = l2IIMapContract.select(
      $"contract_id",
      $"contract",
      $"contract_desc",
      when($"contract_lv2_id".isNull, $"contract_id")
        .otherwise($"contract_lv2_id").as("contract_lv2_id"),
      coalesce($"contract_lv2", $"contract").as("contract_lv2"),
      when($"contract_lv2_desc".isNull, $"contract_desc")
        .otherwise($"contract_lv2_desc").as("contract_lv2_desc"),
      coalesce($"contract_lv1_id", $"contract_lv2_id", $"contract_id").as("contract_lv1_id"),
      coalesce($"contract_lv1", $"contract_lv2", $"contract").as("contract_lv1"),
      coalesce($"contract_lv1_desc", $"contract_lv2_desc", $"contract_desc").as("contract_lv1_desc"),
      $"contract_hier".cast(ShortType),
      $"map_srce_e",
      $"riflag".cast(ShortType),
      $"client_ds_id".cast(IntegerType))

    val unspecifiedIdExists: Boolean = tempL5IiMapContract.where($"contract_id" === lit("Unspecified$UNK")).count > 0

    val l5IiMapContract = if (unspecifiedIdExists) tempL5IiMapContract else tempL5IiMapContract.union(defaultRow)

    l5IiMapContract
  }
}
