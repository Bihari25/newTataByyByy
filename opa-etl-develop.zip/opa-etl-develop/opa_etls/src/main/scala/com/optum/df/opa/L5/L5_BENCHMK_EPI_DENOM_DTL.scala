package com.optum.df.opa.L5

import com.optum.df.opa.models.L5.l5_benchmk_epi_denom_dtl
import com.optum.oap.sparkdataloader.{RuntimeVariables, UserDefinedFunctionForDataLoader}
import org.apache.spark.sql.types.{DecimalType, ShortType}
import org.apache.spark.sql.{DataFrame, SparkSession}


/**
  * Source query:
  * https://som-bb.humedica.net/projects/OAP/repos/oap-mstr-db-interface/browse/src/main/resources/src/build/L5/etl/OPA/L5_benchmk_epi_denom_dtl_insert.sql
  *
  * Redshift Schema: opa_util/src/main/resources/OPADDL/L5/tables/L5_BENCHMK_EPI_DENOM_DTL.sql
  */
object L5_BENCHMK_EPI_DENOM_DTL extends L5TableInfo[l5_benchmk_epi_denom_dtl] {
  override def name: String = "L5_BENCHMK_EPI_DENOM_DTL"

  override def dependsOn: Set[String] = Set("L2_BMK_EPI_DEN_DETAIL", "L2_II_MAP_ETG")

  def createDataFrameWithoutDDL(sparkSession: SparkSession, loadedDependencies: Map[String, DataFrame], udfMap: Map[String, UserDefinedFunctionForDataLoader], runtimeVariables: RuntimeVariables): DataFrame = {
    import org.apache.spark.sql.functions._
    import sparkSession.implicits._

    val l2BmkEpiDenDetail = loadedDependencies("L2_BMK_EPI_DEN_DETAIL")
    val l2IiMapEtg = loadedDependencies("L2_II_MAP_ETG")

    l2BmkEpiDenDetail
      .join(l2IiMapEtg, Seq("etg_id"), "left")
      .groupBy($"year", $"age_cat2", $"sex", $"cens_reg", $"etg_id", $"family".as("etg_family"), $"mpc".as("etg_mpc"), $"sev_level")
      .agg(
        round(sum($"epi_qty"), 2).as("epi_qty"),
        lit("Y").as("dummy_email")
      )
      .select(
        $"year".cast(ShortType),
        $"age_cat2".cast(ShortType).as("age_cat2"),
        $"sex".cast(ShortType),
        $"cens_reg".cast(ShortType).as("cens_reg"),
        $"etg_id",
        $"etg_family",
        $"etg_mpc",
        $"sev_level",
        $"epi_qty".cast(DecimalType(19, 2)).as("epi_qty"),
        $"dummy_email"
      )
  }
}
