package com.optum.df.opa.L5

import com.optum.df.opa.models.L5.l5_dict_measure
import com.optum.oap.sparkdataloader.{RuntimeVariables, UserDefinedFunctionForDataLoader}
import org.apache.spark.sql.functions.{lit, when, row_number}
import org.apache.spark.sql.types.ShortType
import org.apache.spark.sql.{DataFrame, SparkSession}
import org.apache.spark.sql.expressions.Window

/**
  * Source query:
  *https://som-bb.humedica.net/projects/OAP/repos/oap-mstr-db-interface/browse/src/main/resources/src/build/L5/etl/OPA/L5_dict_measure.sql
  *
  * Redshift Schema: opa_util/src/main/resources/OPADDL/L5/tables/L5_DICT_MEASURE.sql
  */

object L5_DICT_MEASURE extends L5TableInfo[l5_dict_measure] {
  override def name: String = "L5_DICT_MEASURE"
  override def dependsOn: Set[String] = Set("L4_DICT_MEASURE")

  def createDataFrameWithoutDDL(sparkSession: SparkSession, loadedDependencies: Map[String, DataFrame], udfMap: Map[String, UserDefinedFunctionForDataLoader], runtimeVariables: RuntimeVariables): DataFrame = {
    import sparkSession.implicits._

    val l4DictMeasure = loadedDependencies("L4_DICT_MEASURE")

    l4DictMeasure
      .where($"active_ind" === 1)
      .select($"measure_id",
      $"measure_set",
      when($"measure_type" === lit("P"), lit("Patient"))
        .when($"measure_type" === lit("E"), lit("Event"))
        .when($"measure_type" === lit("C"), lit("Clinical Event"))
        .otherwise($"measure_type").as("measure_type"),
      $"measure_cd",
      $"measure_vers",
      $"measure_steward",
      $"measure_desc",
        row_number().over(
          Window.orderBy($"measure_set".asc, $"measure_vers".desc, $"measure_desc".asc)
        ).as("measure_rank"),
      $"sensitive_ind",
      $"active_ind",
      $"typical_ind".cast(ShortType)
    )


  }
}
