package com.optum.df.opa.L5

import com.optum.df.opa.models.L5.l5_ii_ql_conf
import com.optum.oap.sparkdataloader.{RuntimeVariables, UserDefinedFunctionForDataLoader}
import org.apache.spark.sql.{DataFrame, SparkSession}
import org.apache.spark.sql.functions.{coalesce, date_format, lit, max, when}
import org.apache.spark.sql.types.{DecimalType, ShortType}

object L5_II_QL_CONF extends L5TableInfo[l5_ii_ql_conf] {
  override def name: String = "L5_II_QL_CONF"
  override def dependsOn: Set[String] = Set("L2_II_QL_CONF", "L2_II_MAP_DATE_RANGE", "L2_II_MEM_ATTR_MEMBER_EXT", "L2_II_CONF_AVOIDABLE", "L5_II_SERVICES_MED", "L2_II_MAP_DRG", "L2_II_CONFINEMENTS")

  def createDataFrameWithoutDDL(sparkSession: SparkSession, loadedDependencies: Map[String, DataFrame], udfMap: Map[String, UserDefinedFunctionForDataLoader], runtimeVariables: RuntimeVariables): DataFrame = {
    import sparkSession.implicits._

    val l2IiQlConf = loadedDependencies("L2_II_QL_CONF")
    val l2IiMapDateRange = loadedDependencies("L2_II_MAP_DATE_RANGE")
    val l2IiMemAttrMemberExt = loadedDependencies("L2_II_MEM_ATTR_MEMBER_EXT")
    val l2IiConfAvoidable = loadedDependencies("L2_II_CONF_AVOIDABLE")
    val l5IiServicesMed =  loadedDependencies("L5_II_SERVICES_MED")
    val l2IiMapDrg = loadedDependencies("L2_II_MAP_DRG")
    val l2IiConfinements = loadedDependencies("L2_II_CONFINEMENTS")

    val tempReadmit07 = l2IiQlConf.as("qc")
      .select(
        $"qc.readmit_conf_07".as("readmit_conf"),
        lit(1).as("readmit_ind_07"),
        lit(0).as("readmit_ind_30"),
        lit(0).as("readmit_ind_60"),
        lit(0).as("readmit_ind_90")
      )

    val tempReadmit30 = l2IiQlConf.as("qc")
      .select(
        $"qc.readmit_conf_30".as("readmit_conf"),
        lit(0).as("readmit_ind_07"),
        lit(1).as("readmit_ind_30"),
        lit(0).as("readmit_ind_60"),
        lit(0).as("readmit_ind_90")
      )

    val tempReadmit60 = l2IiQlConf.as("qc")
      .select(
        $"qc.readmit_conf_60".as("readmit_conf"),
        lit(0).as("readmit_ind_07"),
        lit(0).as("readmit_ind_30"),
        lit(1).as("readmit_ind_60"),
        lit(0).as("readmit_ind_90")
      )

    val tempReadmit90 = l2IiQlConf.as("qc")
      .select(
        $"qc.readmit_conf_90".as("readmit_conf"),
        lit(0).as("readmit_ind_07"),
        lit(0).as("readmit_ind_30"),
        lit(0).as("readmit_ind_60"),
        lit(1).as("readmit_ind_90")
      )

    val tempReadmits = tempReadmit07
      .union(tempReadmit30)
      .union(tempReadmit60)
      .union(tempReadmit90)

    val readmits = tempReadmits.as("tr")
      .groupBy($"tr.readmit_conf")
      .agg(max($"tr.readmit_ind_07").as("readmit_ind_07"),
        max($"tr.readmit_ind_30").as("readmit_ind_30"),
        max($"tr.readmit_ind_60").as("readmit_ind_60"),
        max($"tr.readmit_ind_90").as("readmit_ind_90"))
      .select(
      $"tr.readmit_conf",
        $"readmit_ind_07",
        $"readmit_ind_30",
        $"readmit_ind_60",
        $"readmit_ind_90"
      )


    val tempReadmitConf = readmits.as("qc")
      .join(l5IiServicesMed.as("sm"), $"qc.readmit_conf" === $"sm.conf_num", "left")
      .join(l2IiConfAvoidable.as("cav"), $"qc.readmit_conf"  === $"cav.conf_num", "left")
      .groupBy(
        $"qc.readmit_conf".alias("readmit_conf_num"),
        $"qc.readmit_ind_07".cast(ShortType).as("readmit_ind_07"),
        $"qc.readmit_ind_30".cast(ShortType).as("readmit_ind_30"),
        $"qc.readmit_ind_60".cast(ShortType).as("readmit_ind_60"),
        $"qc.readmit_ind_90".cast(ShortType).as("readmit_ind_90"),
        $"cav.avoidable_admit_flag"
      )
      .agg(max(when($"sm.er_conf" === lit(1) && $"sm.ed_enc_id".isNotNull, lit(1))).as("is_readmit_ed_visit")
      )
      .select(
        $"readmit_conf_num",
        $"readmit_ind_07",
        $"readmit_ind_30",
        $"readmit_ind_60",
        $"readmit_ind_90",
        when($"avoidable_admit_flag" > lit(0), lit(1)).as("avoidable_admit_flag"),
        $"is_readmit_ed_visit"
      )

    val tempReadmitSnf = l2IiQlConf.as("qc")
      .join(l5IiServicesMed.as("sm"), $"qc.pac_rsnf_postconf" === $"sm.conf_num", "left")
      .join(l2IiConfAvoidable.as("cav"), $"qc.pac_rsnf_postconf" === $"cav.conf_num", "left")
      .groupBy(
        $"qc.pac_rsnf_postconf",
        $"qc.pac_rsnf_readmit".cast(ShortType).as("is_snf_readmit"),
        $"cav.avoidable_admit_flag"
      )
      .agg(
        max(when($"sm.er_conf" === lit(1) && $"sm.ed_enc_id".isNotNull, lit(1))).as("is_readmit_ed_visit")
      )
      .select(
        $"pac_rsnf_postconf",
        $"is_snf_readmit",
        when($"avoidable_admit_flag" > lit(0), lit(1)).as("avoidable_admit_flag"),
        $"is_readmit_ed_visit"
      )

    l2IiQlConf.as("qc")
      .join(l2IiConfAvoidable.as("cfav"), $"qc.conf_num" === $"cfav.conf_num", "left")
      .join(l2IiMapDateRange.as("mdr"), date_format($"qc.beg_dt", "yyyyMM") === $"mdr.yr_month".cast("String"), "inner")
      .join(l2IiMemAttrMemberExt.as("me"), $"qc.member" === $"me.member" && $"mdr.year_mth_id" === $"me.year_mth_id", "left")
      .join(tempReadmitConf.as("trc"), $"qc.conf_num" === $"trc.readmit_conf_num", "left" )
      .join(tempReadmitSnf.as("read"), $"qc.conf_num" === $"read.pac_rsnf_postconf", "left")
      .join(l2IiMapDrg.as("drg"), $"qc.drg_id" === $"drg.drg_id", "left")
      .join(l2IiConfinements.as("conf"), $"qc.conf_num" === $"conf.conf_num", "left")
      .select(
          coalesce($"qc.conf_num",lit(0)).alias("conf_num"),
          $"qc.member",
          $"qc.ia_time",
          $"qc.beg_dt",
          $"qc.end_dt",
          $"qc.los",
          coalesce($"qc.provider_id",lit(0)).alias("provider_id"),
          coalesce($"me.pcp_assign", lit("0")).as("pcp_assign"),
          coalesce($"qc.diag1",lit(0)).alias("diag1"),
          $"qc.diag2",
          $"qc.diag3",
          $"qc.diag4",
          $"qc.diag5",
          $"qc.diag6",
          $"qc.diag7",
          $"qc.diag8",
          $"qc.diag9",
          $"qc.diag10",
          coalesce($"qc.iproc1",lit(0)).alias("iproc1"),
          coalesce($"qc.poa1",lit("U")).as("poa"),
          $"qc.drg_admittyp",
          $"qc.pay_dt",
          $"qc.tos_i_5",
          coalesce($"qc.pos_i",lit(0)).alias("pos_i"),
          $"qc.prv_sp_4",
          $"qc.drg_id",
          $"qc.episode_id",
          coalesce($"qc.etg_id",lit(0)).alias("etg_id"),
          coalesce($"qc.sev_level",lit(0)).alias("sev_level"),
          $"qc.clm_exclude",
          $"qc.drg_desc",
          $"qc.product_id",
          $"qc.account_id",
          $"qc.cat_status",
          $"qc.cat_status_cost3",
          $"qc.sex".cast(ShortType),
          $"qc.age",
          $"qc.zip",
          $"qc.network_status".cast(ShortType),
          coalesce($"qc.disrel",lit(0)).alias("disrel"),
          $"qc.cost1",
          $"qc.cost2",
          $"qc.cost3",
          $"qc.cost4",
          $"qc.cost5",
          $"qc.cost6",
          $"qc.amt_req",
          $"qc.readmit_07".cast(ShortType),
          $"qc.readmit_30".cast(ShortType),
          $"qc.readmit_60".cast(ShortType),
          $"qc.readmit_90".cast(ShortType),
          $"qc.readmit_index_07".cast(ShortType),
          $"qc.readmit_index_30".cast(ShortType),
          $"qc.readmit_index_60".cast(ShortType),
          $"qc.readmit_index_90".cast(ShortType),
          $"qc.readmit_conf_07",
          $"qc.readmit_conf_30",
          $"qc.readmit_conf_60",
          $"qc.readmit_conf_90",
          coalesce($"qc.icd_version",lit(0)).as("icd_version"),
          $"qc.contract_id",
          $"qc.network_paid_status_id",
          $"qc.provider_status_id",
          coalesce($"cfav.avoidable_admit_flag",lit(0)).cast(ShortType).as("avoidable_admit_id"),
          coalesce($"qc.pqi",lit(0)).cast(ShortType).alias("pqi"),
          coalesce($"qc.pdi",lit(0)).cast(ShortType).alias("pdi"),
          coalesce($"me.at_risk_status_id",lit("Unspecified$UNK")).as("at_risk_status_id"),
          coalesce($"me.mem_userdef_4_id",lit("Unspecified$UNK")).as("mem_userdef_4_id"),
          coalesce($"trc.readmit_ind_07", lit(0)).cast(ShortType).as("readmit_ind_07"),
          coalesce($"trc.readmit_ind_30", lit(0)).cast(ShortType).as("readmit_ind_30"),
          coalesce($"trc.readmit_ind_60", lit(0)).cast(ShortType).as("readmit_ind_60"),
          coalesce($"trc.readmit_ind_90", lit(0)).cast(ShortType).as("readmit_ind_90"),
          $"me.rrisk",
          $"qc.pac_rsnf_index".cast(ShortType),
          $"qc.pac_rsnf_preconf",
          coalesce($"qc.pac_rsnf_readmit", lit(false)).cast(ShortType).as("pac_rsnf_readmit"),
          $"qc.pac_rsnf_postconf",
          $"qc.pac_rsnf_readm_days".cast(ShortType),
          coalesce($"trc.avoidable_admit_flag", $"read.avoidable_admit_flag", lit(0)).cast(ShortType).as("is_avoidable_readmit"),
          coalesce($"read.is_snf_readmit",lit(0)).cast(ShortType).as("is_snf_readmit"),
          coalesce($"trc.is_readmit_ed_visit", $"read.is_readmit_ed_visit", lit(0)).cast(ShortType).as("is_readmit_ed_visit"),
          coalesce($"drg.drg_wgt", lit(1)).cast(DecimalType(10, 4)).as("drg_wgt"), //DRG_WGT for 'unspecified_drg' is set as 1 in II engine so that drg_wgt*admits calculation is not computed to zero. Due to left join, added a fail-safe coalesce to convert nulls to 1.
          coalesce($"conf.admit", lit(false)).cast(ShortType).as("admit"),
          coalesce($"conf.bill_provider_id", lit("0")).as("bill_provider_id"),
          coalesce($"conf.inp_admit_type", lit("9")).as("inp_admit_type") //INP_ADMIT_TYPE for 'INFORMATION NOT AVAILABLE' is set as 9 in II engine. Map table for reference - L2_II_MAP_INP_ADMIT_TYPE
      )
  }
}
