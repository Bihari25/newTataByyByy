package com.optum.df.opa.L5

import com.optum.df.opa.models.L5.l5_dict_appt_location
import com.optum.oap.sparkdataloader.{RuntimeVariables, UserDefinedFunctionForDataLoader}
import org.apache.spark.sql.{DataFrame, SparkSession}

object L5_DICT_APPT_LOCATION extends L5TableInfo[l5_dict_appt_location] {
  override def name: String = "L5_DICT_APPT_LOCATION"

  override def dependsOn: Set[String] = Set("L2_PAT_APPOINTMENT")
  def createDataFrameWithoutDDL(sparkSession: SparkSession, loadedDependencies: Map[String, DataFrame], udfMap: Map[String, UserDefinedFunctionForDataLoader], runtimeVariables: RuntimeVariables): DataFrame = {
    import sparkSession.implicits._

    val l2PatAppointment = loadedDependencies("L2_PAT_APPOINTMENT")

    l2PatAppointment
      .select(
        $"appointment_location"
      ).distinct()
  }
}
