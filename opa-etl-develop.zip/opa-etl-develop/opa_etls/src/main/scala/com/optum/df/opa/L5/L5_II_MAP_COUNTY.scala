package com.optum.df.opa.L5

import com.optum.df.opa.models.L5.l5_ii_map_county
import com.optum.oap.sparkdataloader.{RuntimeVariables, UserDefinedFunctionForDataLoader}
import org.apache.spark.sql.functions.{lit, substring, initcap, coalesce}
import org.apache.spark.sql.{DataFrame, SparkSession}


object L5_II_MAP_COUNTY extends L5TableInfo[l5_ii_map_county] {

    override def name: String = "L5_II_MAP_COUNTY"

    override def dependsOn: Set[String] = Set("L2_DICT_ZIP", "L1_REF_COMMERCIAL_ZIPCODES")

    def createDataFrameWithoutDDL(sparkSession: SparkSession, loadedDependencies: Map[String, DataFrame],
                                  udfMap: Map[String, UserDefinedFunctionForDataLoader],
                                  mapRuntimeVariables: RuntimeVariables): DataFrame = {

        import sparkSession.implicits._

        val l2DictZip = loadedDependencies("L2_DICT_ZIP")
        val l1RefCommercialZipcodes = loadedDependencies("L1_REF_COMMERCIAL_ZIPCODES")

        val distinctStates = l1RefCommercialZipcodes.select(
            $"stateabbr",
            $"statename"
        ).distinct()

        val tempL5IiMapCounty = l2DictZip.as("z")
          .join(distinctStates.as("s"),$"z.state_cd" === $"s.stateabbr", "left_outer")
          .select(
            $"z.cens_reg_id".as("cens_reg"),
            $"z.cens_reg_desc",
            $"z.county_desc",
            initcap(substring($"z.county_desc", 5, 40)).as("county_name"),
            $"z.county_id",
            $"z.state_id".as("state"),
            $"z.state_cd".as("state_desc"),
            coalesce($"s.statename", lit("Unknown")).as("state_name")
        ).distinct()

        val default = Seq((-1, "Unknown", "Unknown", "Unknown", 0, 0, "UNK", "Unknown")).toDF()
        val zeroIdExists: Boolean = tempL5IiMapCounty.where($"county_id" === lit(0)).count > 0
        val l5IiMapCounty = if (zeroIdExists) tempL5IiMapCounty else tempL5IiMapCounty.union(default)

        l5IiMapCounty
    }
}
