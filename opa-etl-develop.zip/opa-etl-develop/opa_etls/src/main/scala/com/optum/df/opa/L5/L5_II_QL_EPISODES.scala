package com.optum.df.opa.L5

import com.optum.df.opa.models.L5.l5_ii_ql_episodes
import com.optum.oap.sparkdataloader.{RuntimeVariables, UserDefinedFunctionForDataLoader}
import org.apache.spark.sql.functions._
import org.apache.spark.sql.types.ShortType
import org.apache.spark.sql.{DataFrame, SparkSession}


object L5_II_QL_EPISODES extends L5TableInfo[l5_ii_ql_episodes]{
  override def name:String = "L5_II_QL_EPISODES"

  override def dependsOn: Set[String] = Set("L2_II_QL_EPISODES", "L2_II_EPISODES")

  def createDataFrameWithoutDDL(sparkSession: SparkSession, loadedDependencies: Map[String, DataFrame], udfMap: Map[String, UserDefinedFunctionForDataLoader], runtimeVariables: RuntimeVariables): DataFrame = {
    import sparkSession.implicits._

    val l2IIQlEpisodes = loadedDependencies("L2_II_QL_EPISODES")
    val l2IIEpisodes = loadedDependencies("L2_II_EPISODES")

    l2IIQlEpisodes.as("qe")
      .join(l2IIEpisodes.as("e"), $"qe.episode_id" === $"e.episode_id", "left")
      .select(
      $"qe.member",
        $"qe.episode_id",
        $"qe.etg_id",
        coalesce($"e.etg_resp_prov", lit(0)).as("etg_resp_prov"),
        coalesce($"qe.sev_level", lit(0)).cast(ShortType).as("sev_level"),
        $"qe.epi_from",
        $"qe.epi_to",
        $"qe.epi_duration",
        $"qe.epi_qty",
        $"qe.epi_type".cast(ShortType),
        $"qe.outlier".cast(ShortType),
        $"qe.phm_qual".cast(ShortType),
        $"qe.med_qual".cast(ShortType),
        $"qe.rrisk",
        $"qe.tx_ind".cast(ShortType),
        $"qe.cost1_tot",
        $"qe.cost2_tot",
        $"qe.cost3_tot",
        $"qe.los".cast(ShortType),
        $"qe.cost1_medtot",
        $"qe.cost1_ifac",
        $"qe.cost1_ofac",
        $"qe.cost1_prof",
        $"qe.cost1_phm",
        $"qe.cost1_anc",
        $"qe.ia_time".cast(ShortType),
        coalesce($"qe.pcp_imp", lit(0)).as("pcp_imp"),
        $"qe.cat_status".cast(ShortType),
        $"qe.cat_status_cost3".cast(ShortType),
        $"qe.sex".cast(ShortType),
        $"qe.age".cast(ShortType),
        $"qe.zip",
        $"qe.account_id",
        $"qe.product_id",
        coalesce($"qe.pcp_id", lit(0)).as("pcp_id"),
        $"qe.biz_segment_id",
        $"qe.coverage_status_id",
        $"qe.contract_type_id",
        $"qe.at_risk_status_id",
        $"qe.mem_userdef_1_id",
        $"qe.mem_userdef_2_id",
        $"qe.mem_userdef_3_id",
        $"qe.mem_userdef_4_id",
        $"qe.benefit_plan_id",
        $"qe.industry".cast(ShortType),
        $"qe.mpg_def_id",
        $"qe.contract_id"
    )
  }
}
