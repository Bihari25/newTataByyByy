package com.optum.df.opa.L5

import com.optum.df.opa.models.L5.l5_benchmk_pop_denom_dtl
import com.optum.oap.sparkdataloader.{RuntimeVariables, UserDefinedFunctionForDataLoader}
import org.apache.spark.sql.{DataFrame, SparkSession}
import org.apache.spark.sql.functions._
import org.apache.spark.sql.types.{DecimalType, IntegerType, ShortType}

object L5_BENCHMK_POP_DENOM_DTL extends L5TableInfo[l5_benchmk_pop_denom_dtl] {
  override def name: String = "L5_BENCHMK_POP_DENOM_DTL"

  override def dependsOn: Set[String] = Set("L2_BMK_POP_DEN_DETAIL", "L2_BMK_DEM_YR")

  def createDataFrameWithoutDDL(sparkSession: SparkSession, loadedDependencies: Map[String, DataFrame], udfMap: Map[String, UserDefinedFunctionForDataLoader], runtimeVariables: RuntimeVariables): DataFrame = {
    import sparkSession.implicits._

    val l2BenchmkPopDenomDtl = loadedDependencies("L2_BMK_POP_DEN_DETAIL")
    val l2BenchmkDemographicsYr = loadedDependencies("L2_BMK_DEM_YR")

    val pop_denom_dtl_yr =
      l2BenchmkPopDenomDtl
        .groupBy(
          $"year",
          $"cens_reg",
          $"age_cat2",
          $"sex"
        )
        .agg(
          sum($"mm").as("mm"),
          sum($"mm_rx").as("mm_rx"),
          round(sum($"rrisk"), 4).as("rrisk")
        )

    val demographics_yr =
      l2BenchmkDemographicsYr
        .groupBy(
          $"year",
          $"cens_reg",
          $"age_cat2",
          $"sex"
        )
        .agg(
          sum($"tot_age").as("tot_age")
        )

    pop_denom_dtl_yr.as("pop")
      .join(demographics_yr.as("dem")
        , $"dem.year" === $"pop.year"
          && $"dem.cens_reg" === $"pop.cens_reg"
          && $"dem.age_cat2" === $"pop.age_cat2"
          && $"dem.sex" === $"pop.sex"
        , "left_outer"
      )
      .select(
        $"pop.year".cast(ShortType),
        $"pop.cens_reg".cast(ShortType),
        $"pop.age_cat2".cast(ShortType).as("age_cat2"),
        $"pop.sex".cast(ShortType),
        $"pop.mm".cast(DecimalType(19, 2)),
        $"pop.mm_rx".cast(DecimalType(19, 2)),
        $"pop.rrisk".cast(DecimalType(12, 4)),
        $"dem.tot_age".cast(IntegerType),
        lit("Y").as("dummy_email")
      )
  }
}
