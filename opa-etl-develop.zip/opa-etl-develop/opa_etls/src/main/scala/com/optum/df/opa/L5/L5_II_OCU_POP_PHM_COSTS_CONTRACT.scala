package com.optum.df.opa.L5

import com.optum.df.opa.models.L5.l5_ii_ocu_pop_phm_costs_contract
import com.optum.oap.sparkdataloader.{RuntimeVariables, UserDefinedFunctionForDataLoader}
import org.apache.spark.sql.functions._
import org.apache.spark.sql.types.{DecimalType, IntegerType, ShortType}
import org.apache.spark.sql.{DataFrame, SparkSession}

object L5_II_OCU_POP_PHM_COSTS_CONTRACT extends L5TableInfo[l5_ii_ocu_pop_phm_costs_contract] {

  override def name: String = "L5_II_OCU_POP_PHM_COSTS_CONTRACT"

  override def dependsOn: Set[String] = Set("L2_II_OCU_POP_PHM_COSTS_CONTRACT", "L2_II_MAP_NTWRK_PAID_STATUS", "L2_II_MAP_TOS", "L4_MAP_TOS5_CUSTOM", "L2_II_MEM_ATTR", "L2_II_MAP_ACCOUNT")

  private val UNSPECIFIED_UNKNOWN = "Unspecified$UNK"

  def createDataFrameWithoutDDL(sparkSession: SparkSession, loadedDependencies: Map[String, DataFrame], udfMap: Map[String, UserDefinedFunctionForDataLoader], runtimeVariables: RuntimeVariables): DataFrame = {
    import sparkSession.implicits._

    val l2IiOcuPopPhmCostsContract = loadedDependencies("L2_II_OCU_POP_PHM_COSTS_CONTRACT")
    val l2MapNtwrkPaidStatus = loadedDependencies("L2_II_MAP_NTWRK_PAID_STATUS")
    val l2IiMapTos = loadedDependencies("L2_II_MAP_TOS")
    val l4MapTos5Custom = loadedDependencies("L4_MAP_TOS5_CUSTOM")
    val l2IiMemAttr = loadedDependencies("L2_II_MEM_ATTR")
    val l2IiMapAccount = loadedDependencies("L2_II_MAP_ACCOUNT")

    val tosCustomTemp = l2IiMapTos.as("mp")
        .join(l4MapTos5Custom.as("ct"), $"ct.tos_i_5" === $"mp.tos_i_5", "left_outer")
        .select(
          $"mp.tos_i_5",
          $"mp.tos1_id",
          $"mp.tos2_id",
          $"mp.tos3_id",
          $"ct.tos_custom_id"
        )

    l2IiOcuPopPhmCostsContract.as("pc")
      .join(tosCustomTemp.as("tc"), $"pc.tos_i_5" === $"tc.tos_i_5", "left")
      .join(l2MapNtwrkPaidStatus.as("nps"), $"nps.network_paid_status_id" === $"pc.network_paid_status_id", "left")
      .join(l2IiMemAttr.as("ma"), $"pc.mem_attr_id" === $"ma.member_attr_id", "inner")
      .join(l2IiMapAccount.as("mac"), Seq("account_id"), "inner")
      .groupBy(
        $"pc.year_mth_id".cast(ShortType).as("year_mth_id"),
        $"pc.mem_attr_id",
        $"pc.pres_prv_i",
        coalesce($"pc.etg_id", lit(0)).as("etg_id"),
        coalesce($"pc.sev_level", lit(0)).cast(ShortType).as("sev_level"),
        coalesce($"pc.pcp_assign", lit("0")).as("pcp_assign"),
        coalesce($"pc.pcp_imp", lit("0")).as("pcp_imp"),
        coalesce($"pc.ndc", lit("0")).as("ndc"),
        $"pc.brand_name",
        $"pc.formulary".cast(ShortType).as("formulary"),
        $"pc.channel",
        $"pc.gbo".cast(ShortType).as("gbo"),
        $"pc.tos_i_5",
        coalesce($"tc.tos_custom_id", lit(3399999)).as("tos_custom_id"),
        $"tc.tos1_id",
        $"tc.tos2_id",
        $"tc.tos3_id",
        $"pc.iatime_lag".cast(ShortType).as("iatime_lag"),
        $"pc.year_mth_pd".cast(ShortType).as("year_mth_pd"),
        when($"nps.network_status" === lit(true), 1).otherwise(lit(0)).cast(ShortType).as("network_status"),
        when($"pc.lag_ind" === lit(true), 1).otherwise(lit(0)).cast(ShortType).as("lag_ind"),
        $"pc.lag_months",
        coalesce($"mac.account_lv1_id", $"account_id").as("account_lv1_id"),
        coalesce($"mac.account_lv2_id", $"account_id").as("account_lv2_id"),
        $"account_id",
        coalesce($"pc.pcp_affil_id", lit(UNSPECIFIED_UNKNOWN)).as("pcp_affil_id"),
        coalesce($"pc.daw", lit("0")).cast(ShortType).as("daw"),
        coalesce($"pc.spec_rx_n_id", lit(UNSPECIFIED_UNKNOWN)).as("spec_rx_n_id"),
        coalesce($"pc.covid_flag".cast(ShortType), lit(-1.toShort)).as("covid_flag")
      )
      .agg(
        sum($"pc.amt_np").cast(DecimalType(19, 2)).as("amt_np"),
        sum($"pc.amt_eqv").cast(DecimalType(19, 2)).as("amt_eqv"),
        sum($"pc.amt_pay").cast(DecimalType(19, 2)).as("amt_pay"),
        sum($"pc.amt_oth1").cast(DecimalType(19, 2)).as("amt_oth1"),
        sum($"pc.amt_oth4").cast(DecimalType(19, 2)).as("amt_oth4"),
        sum($"pc.encounter").cast(DecimalType(19, 2)).as("encounter"),
        sum($"pc.generic").cast(IntegerType).as("generic"),
        sum($"pc.script").cast(IntegerType).as("script"),
        sum($"pc.script_gen").cast(IntegerType).as("script_gen"),
        sum($"pc.script_adj").cast(DecimalType(19, 2)).as("script_adj"),
        sum($"pc.days_sup").cast(IntegerType).as("days_sup"),
        sum($"pc.amt_req").cast(DecimalType(19, 2)).as("amt_req"),
        sum($"pc.amt_liab").cast(DecimalType(19, 2)).as("amt_liab"),
        sum($"pc.amt_cob").cast(DecimalType(19, 2)).as("amt_cob"),
        sum($"pc.amt_disp").cast(DecimalType(19, 2)).as("amt_disp"),
        sum($"pc.amt_ingr").cast(DecimalType(19, 2)).as("amt_ingr"),
        sum($"pc.amt_not_covered").cast(DecimalType(19, 2)).as("amt_not_covered"),
        sum($"pc.amt_other_carrier_pay").cast(DecimalType(19, 2)).as("amt_other_carrier_pay"),
        sum($"pc.amt_admin_fee").cast(DecimalType(19, 2)).as("amt_admin_fee"),
        sum($"pc.amt_sales_tax").cast(DecimalType(19, 2)).as("amt_sales_tax")
      )
      .select(
        $"year_mth_id",
        $"mem_attr_id",
        $"pres_prv_i",
        $"etg_id",
        $"sev_level",
        $"pcp_assign",
        $"pcp_imp",
        $"ndc",
        $"brand_name",
        $"formulary",
        $"channel",
        $"gbo",
        $"tos_i_5",
        $"tos_custom_id",
        $"tos1_id",
        $"tos2_id",
        $"tos3_id",
        $"iatime_lag",
        $"year_mth_pd",
        $"network_status",
        $"lag_ind",
        $"amt_np",
        $"amt_eqv",
        $"amt_pay",
        $"amt_oth1",
        $"amt_oth4",
        $"encounter",
        $"generic",
        $"script",
        $"script_gen",
        $"script_adj",
        $"days_sup",
        $"amt_req",
        $"amt_liab",
        $"lag_months",
        $"account_lv1_id",
        $"account_lv2_id",
        $"account_id",
        $"pcp_affil_id",
        $"daw",
        $"spec_rx_n_id",
        $"amt_cob",
        $"amt_disp",
        $"amt_ingr",
        $"amt_not_covered",
        $"amt_other_carrier_pay",
        $"amt_admin_fee",
        $"amt_sales_tax",
        $"covid_flag"
      )
  }
}

