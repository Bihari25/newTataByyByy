package com.optum.df.opa.L5

import com.optum.df.opa.models.L5.l5_ii_ocu_epi_count
import com.optum.oap.sparkdataloader.{RuntimeVariables, UserDefinedFunctionForDataLoader}
import com.optum.oadw.oadwModels.{l2_ii_map_account, l2_ii_mem_attr}
import org.apache.spark.sql.functions._
import org.apache.spark.sql.types.ShortType
import org.apache.spark.sql.{DataFrame, SparkSession}

object L5_II_OCU_EPI_COUNT extends L5TableInfo[l5_ii_ocu_epi_count] {
  override def name: String = "L5_II_OCU_EPI_COUNT"
  override def dependsOn: Set[String] = Set("L2_II_OCU_EPI_COUNT","L2_II_MEM_ATTR","L2_II_MAP_ACCOUNT")

  def createDataFrameWithoutDDL(sparkSession: SparkSession, loadedDependencies: Map[String, DataFrame], udfMap: Map[String, UserDefinedFunctionForDataLoader], runtimeVariables: RuntimeVariables): DataFrame = {
    import sparkSession.implicits._

    val l2IiOcuEpiCount = loadedDependencies("L2_II_OCU_EPI_COUNT")
    val l2IiMemAttr = loadedDependencies("L2_II_MEM_ATTR")
    val l2IiMapAccount = loadedDependencies("L2_II_MAP_ACCOUNT")

    l2IiOcuEpiCount.as("ec")
      .join(l2IiMemAttr.as("ma"), $"ec.mem_attr_id" === $"ma.member_attr_id")
      .join(l2IiMapAccount.as("mac"), $"ma.account_id" === $"mac.account_id")
      .select(
        $"ec.year_mth_id".cast(ShortType),
        $"ec.mem_attr_id",
        coalesce($"ec.pcp_assign", lit("0")).as("pcp_assign"),
        coalesce($"ec.pcp_imp", lit("0")).as("pcp_imp"),
        coalesce($"ec.etg_id", lit(0)).as("etg_id"),
        coalesce($"ec.sev_level", lit(0)).cast(ShortType).as("sev_level"),
        $"ec.tx_ind".cast(ShortType),
        $"ec.outlier".cast(ShortType),
        when($"ec.complete" === lit(true), 1).otherwise(lit(0)).cast(ShortType).as("complete"),
        $"ec.epi_qty",
        $"ec.rrisk",
        coalesce($"mac.account_lv1_id", $"mac.account_lv2_id", $"mac.account_id").as("account_lv1_id"),
        coalesce($"mac.account_lv2_id", $"mac.account_id").as("account_lv2_id"),
        $"mac.account_id"
      )
  }
}