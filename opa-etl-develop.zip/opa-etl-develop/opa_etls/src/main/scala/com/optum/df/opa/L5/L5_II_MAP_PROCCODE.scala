package com.optum.df.opa.L5

import com.optum.df.opa.models.L5.l5_ii_map_proccode
import com.optum.oap.sparkdataloader.{RuntimeVariables, UserDefinedFunctionForDataLoader}
import com.optum.oadw.oadwModels.l2_ii_map_proccode
import org.apache.spark.sql.{DataFrame, SparkSession}

object L5_II_MAP_PROCCODE extends L5TableInfo[l5_ii_map_proccode]{
  override def name: String = "L5_II_MAP_PROCCODE"
  override def dependsOn: Set[String] = Set("L2_II_MAP_PROCCODE")

  def createDataFrameWithoutDDL(sparkSession: SparkSession, loadedDependencies: Map[String, DataFrame], udfMap: Map[String, UserDefinedFunctionForDataLoader], runtimeVariables: RuntimeVariables): DataFrame = {
    import sparkSession.implicits._
    val l2MapNtwrkPaidStatus = loadedDependencies("L2_II_MAP_PROCCODE")

    //The below Seq are arranged in the order "proccode", "proccode_desc"
    val extraRow = Seq(("UNK", "Unknown Procedure")).toDF()

    l2MapNtwrkPaidStatus.select(
      $"proccode",
      $"proccode_desc"
    ).union(extraRow)
  }
}
