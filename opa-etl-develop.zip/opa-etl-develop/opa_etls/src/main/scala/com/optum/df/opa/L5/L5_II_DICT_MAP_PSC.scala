package com.optum.df.opa.L5

import com.optum.df.opa.models.L5.l5_ii_dict_map_psc
import com.optum.oap.sparkdataloader.{RuntimeVariables, UserDefinedFunctionForDataLoader}
import org.apache.spark.sql.functions._
import org.apache.spark.sql.{DataFrame, SparkSession}

object L5_II_DICT_MAP_PSC extends L5TableInfo[l5_ii_dict_map_psc] {
  override def name: String = "L5_II_DICT_MAP_PSC"
  override def dependsOn: Set[String] = Set("L2_II_MAP_PSC")


  def createDataFrameWithoutDDL(sparkSession: SparkSession, loadedDependencies: Map[String, DataFrame], udfMap: Map[String, UserDefinedFunctionForDataLoader], runtimeVariables: RuntimeVariables): DataFrame = {
    import sparkSession.implicits._

    val l2IiMapPsc = loadedDependencies("L2_II_MAP_PSC")

    l2IiMapPsc.select(
      $"psc_cat1_id".as("psc_cat1_id"),
      $"psc_cat1".as("psc_cat1")
      ).distinct()
  }
}
