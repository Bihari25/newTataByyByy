package com.optum.df.opa.L5

import com.optum.df.opa.models.L5.l5_ii_map_provider_status
import com.optum.oap.sparkdataloader.{RuntimeVariables, UserDefinedFunctionForDataLoader}
import org.apache.spark.sql.functions.{lit, when}
import org.apache.spark.sql.types.ShortType
import org.apache.spark.sql.{DataFrame, SparkSession}

object L5_II_MAP_PROVIDER_STATUS extends L5TableInfo[l5_ii_map_provider_status]{
  override def name: String = "L5_II_MAP_PROVIDER_STATUS"

  override def dependsOn: Set[String] = Set("L2_II_MAP_PROVIDER_STATUS")

  def createDataFrameWithoutDDL(sparkSession: SparkSession, loadedDependencies: Map[String, DataFrame], udfMap: Map[String, UserDefinedFunctionForDataLoader], runtimeVariables: RuntimeVariables): DataFrame = {
    import sparkSession.implicits._

    val l2IIMapProviderStatus = loadedDependencies("L2_II_MAP_PROVIDER_STATUS")
    val defaultRow = Seq(("UNK", 0.toShort, "Unspecified", "Unspecified", "Unspecified$UNK", "Unspecified LV1", "Unspecified", "Unspecified LV1", "Unspecified LV2", "Unspecified", "Unspecified LV1#Unspecified LV2", 1.toShort)).toDF()

    val tempL5IiMapProviderStatus = l2IIMapProviderStatus.select(
      $"map_srce_p",
      when($"par_status" === lit(true), 1).otherwise(lit(0)).cast(ShortType).as("par_status"),
      $"provider_status",
      $"provider_status_desc",
      $"provider_status_id",
      $"provider_status_lv1",
      $"provider_status_lv1_desc",
      $"provider_status_lv1_id",
      $"provider_status_lv2",
      $"provider_status_lv2_desc",
      $"provider_status_lv2_id",
      $"riflag".cast(ShortType))

    val unspecifiedIdExists: Boolean = tempL5IiMapProviderStatus.where($"provider_status_id" === lit("Unspecified$UNK")).count > 0

    val l5IiMapProviderStatus = if (unspecifiedIdExists) tempL5IiMapProviderStatus else tempL5IiMapProviderStatus.union(defaultRow)

    l5IiMapProviderStatus
  }
}
