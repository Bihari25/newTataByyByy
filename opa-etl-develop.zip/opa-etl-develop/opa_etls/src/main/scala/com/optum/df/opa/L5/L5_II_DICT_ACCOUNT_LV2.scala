package com.optum.df.opa.L5

import com.optum.df.opa.models.L5.l5_ii_dict_account_lv2
import com.optum.oap.sparkdataloader.{RuntimeVariables, UserDefinedFunctionForDataLoader}
import com.optum.oadw.oadwModels.l2_ii_map_account
import org.apache.spark.sql.functions._
import org.apache.spark.sql.{DataFrame, SparkSession}


object L5_II_DICT_ACCOUNT_LV2 extends L5TableInfo[l5_ii_dict_account_lv2] {

  override def name: String = "L5_II_DICT_ACCOUNT_LV2"

  override def dependsOn: Set[String] = Set("L2_II_MAP_ACCOUNT")

  def createDataFrameWithoutDDL(sparkSession: SparkSession, loadedDependencies: Map[String, DataFrame], udfMap: Map[String, UserDefinedFunctionForDataLoader], runtimeVariables: RuntimeVariables): DataFrame = {

    import sparkSession.implicits._

    val l2iiMapAccount = loadedDependencies("L2_II_MAP_ACCOUNT")

    l2iiMapAccount.select(
      coalesce($"account_lv2_id", $"account_id").as("account_lv2_id"),
      coalesce($"account_lv2_desc", $"account_lv2_desc", $"account_desc").as("account_lv2_desc"),
      coalesce($"account_lv1_id", $"account_lv2_id", $"account_id").as("account_lv1_id")
    ).distinct()


  }

}
