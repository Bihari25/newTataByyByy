package com.optum.df.opa.L5

import com.optum.df.opa.models.L5.l5_ii_map_coverage_status
import com.optum.oap.sparkdataloader.{RuntimeVariables, UserDefinedFunctionForDataLoader}
import com.optum.oadw.oadwModels.l2_ii_map_coverage_status
import org.apache.spark.sql.functions.{coalesce, when}
import org.apache.spark.sql.types.ShortType
import org.apache.spark.sql.{DataFrame, SparkSession}

object L5_II_MAP_COVERAGE_STATUS extends L5TableInfo[l5_ii_map_coverage_status]{
  override def name: String = "L5_II_MAP_COVERAGE_STATUS"

  override def dependsOn: Set[String] = Set("L2_II_MAP_COVERAGE_STATUS")

  def createDataFrameWithoutDDL(sparkSession: SparkSession, loadedDependencies: Map[String, DataFrame], udfMap: Map[String, UserDefinedFunctionForDataLoader], runtimeVariables: RuntimeVariables): DataFrame = {
    import sparkSession.implicits._

    val l2IIMapCoverageStatus = loadedDependencies("L2_II_MAP_COVERAGE_STATUS")

    l2IIMapCoverageStatus.select(
      $"coverage_status_id",
      $"coverage_status",
      $"coverage_status_desc",
      when($"coverage_status_lv2_id".isNull, $"coverage_status_id")
        .otherwise($"coverage_status_lv2_id").as("coverage_status_lv2_id"),
      coalesce($"coverage_status_lv2", $"coverage_status").as("coverage_status_lv2"),
      when($"coverage_status_lv2_desc".isNull, $"coverage_status_desc")
        .otherwise($"coverage_status_lv2_desc").as("coverage_status_lv2_desc"),
      coalesce($"coverage_status_lv1_id", $"coverage_status_lv2_id", $"coverage_status_id").as("coverage_status_lv1_id"),
      coalesce($"coverage_status_lv1", $"coverage_status_lv2", $"coverage_status").as("coverage_status_lv1"),
      coalesce($"coverage_status_lv1_desc", $"coverage_status_lv2_desc", $"coverage_status_desc").as("coverage_status_lv1_desc"),
      $"map_srce_e",
      $"riflag".cast(ShortType),
      $"coverage_class".cast(ShortType)
    )
  }
}
