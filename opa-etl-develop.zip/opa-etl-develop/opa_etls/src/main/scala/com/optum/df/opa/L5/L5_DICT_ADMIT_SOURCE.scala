package com.optum.df.opa.L5

import com.optum.df.opa.models.L5.{l5_dict_admit_source}
import com.optum.oap.sparkdataloader.{RuntimeVariables, UserDefinedFunctionForDataLoader}
import org.apache.spark.sql.{DataFrame, SparkSession}

object L5_DICT_ADMIT_SOURCE extends L5TableInfo[l5_dict_admit_source]{

  override def name: String = "L5_DICT_ADMIT_SOURCE"
  override def dependsOn: Set[String] = Set.empty

  def createDataFrameWithoutDDL(sparkSession: SparkSession, loadedDependencies: Map[String, DataFrame], udfMap: Map[String, UserDefinedFunctionForDataLoader], runtimeVariables: RuntimeVariables): DataFrame = {
    import sparkSession.implicits._

        Seq((1.toShort, "Admitted from ED"),
          (0.toShort, "Not Admitted from ED"),
          ((-1).toShort, "Unknown Admit Source"))
          .toDF("admit_source", "admit_source_desc")
  }
}