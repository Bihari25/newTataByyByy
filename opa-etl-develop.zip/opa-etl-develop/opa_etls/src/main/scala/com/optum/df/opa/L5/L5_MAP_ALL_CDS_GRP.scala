package com.optum.df.opa.L5

import com.optum.df.opa.models.L5.l5_map_all_cds_grp
import com.optum.oap.sparkdataloader.{RuntimeVariables, UserDefinedFunctionForDataLoader}
import org.apache.spark.sql.{DataFrame, SparkSession}

/*
 * Redshift Schema: opa_util/src/main/resources/OPADDL/L5/tables/L5_MAP_ALL_CDS_GRP.sql
 */

object L5_MAP_ALL_CDS_GRP extends L5TableInfo[l5_map_all_cds_grp] {
  override def name: String = "L5_MAP_ALL_CDS_GRP"

  override def dependsOn: Set[String] = Set("L4_DICT_CDS_GRP", "L4_MAP_CDS_GRP", "L2_MAP_CDS_FLG")

  def createDataFrameWithoutDDL(sparkSession: SparkSession, loadedDependencies: Map[String, DataFrame], udfMap: Map[String, UserDefinedFunctionForDataLoader], runtimeVariables: RuntimeVariables): DataFrame = {
    import sparkSession.implicits._

    val l4DictCdsgrp = loadedDependencies("L4_DICT_CDS_GRP")
    val l4MapCdsgrp = loadedDependencies("L4_MAP_CDS_GRP")
    val l2MapCdsFlg = loadedDependencies("L2_MAP_CDS_FLG")

    l4DictCdsgrp.as("dcg")
      .join(l4MapCdsgrp.as("mcg"), $"dcg.cds_grp" === $"mcg.cds_grp", "inner")
      .join(l2MapCdsFlg.as("mcf"), $"mcf.client_ds_id" === $"mcg.client_ds_id", "inner")
      .select(
          $"dcg.cds_grp",
          $"dcg.cds_grp_desc",
          $"mcf.client_ds_id",
          $"mcf.client_ds_name"
      ).distinct()
  }
}