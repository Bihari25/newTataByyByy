package com.optum.df.opa.L5

import com.optum.df.opa.models.L5.l5_dict_cc_case_status
import com.optum.oap.sparkdataloader.{RuntimeVariables, UserDefinedFunctionForDataLoader}
import org.apache.spark.sql.{DataFrame, SparkSession}

object L5_DICT_CC_CASE_STATUS extends L5TableInfo[l5_dict_cc_case_status] {
  override def name: String = "L5_DICT_CC_CASE_STATUS"
  override def dependsOn: Set[String] = Set("L1_DICT_CC_CASE_STATUS")

  def createDataFrameWithoutDDL(sparkSession: SparkSession, loadedDependencies: Map[String, DataFrame], udfMap: Map[String, UserDefinedFunctionForDataLoader], runtimeVariables: RuntimeVariables): DataFrame = {
    import sparkSession.implicits._

    val l1DictCcCaseStatus = loadedDependencies("L1_DICT_CC_CASE_STATUS")
    val defaults = Seq(("Unspecified$UNK", "Unspecified")).toDF()

    l1DictCcCaseStatus.select(
      $"case_status",
      $"case_status_nm"
      ).distinct().union(defaults)
  }
}
