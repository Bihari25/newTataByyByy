package com.optum.df.opa.L5

import com.optum.df.opa.models.L5.l5_dict_cc_care_plan_subtype
import com.optum.oap.sparkdataloader.{RuntimeVariables, UserDefinedFunctionForDataLoader}
import org.apache.spark.sql.{DataFrame, SparkSession}

object L5_DICT_CC_CARE_PLAN_SUBTYPE extends L5TableInfo[l5_dict_cc_care_plan_subtype] {
  override def name: String = "L5_DICT_CC_CARE_PLAN_SUBTYPE"
  override def dependsOn: Set[String] = Set("L1_DICT_CC_CARE_PLAN_SUBTYPE")

  def createDataFrameWithoutDDL(sparkSession: SparkSession, loadedDependencies: Map[String, DataFrame], udfMap: Map[String, UserDefinedFunctionForDataLoader], runtimeVariables: RuntimeVariables): DataFrame = {
    import sparkSession.implicits._

    val l1DictCcCarePlanSubtype = loadedDependencies("L1_DICT_CC_CARE_PLAN_SUBTYPE")
    val defaults = Seq(("Unspecified$UNK", "Unspecified")).toDF()

    l1DictCcCarePlanSubtype.select(
      $"care_plan_subtype",
      $"care_plan_subtype_nm"
      ).distinct().union(defaults)
  }
}
