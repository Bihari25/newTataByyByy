package com.optum.df.opa.L5


import com.optum.df.opa.models.L5.l5_admits_numrtr
import com.optum.oap.sparkdataloader.{RuntimeVariables, UserDefinedFunctionForDataLoader}
import org.apache.spark.sql.functions._
import org.apache.spark.sql.types.{DecimalType, LongType, ShortType}
import org.apache.spark.sql.{DataFrame, SparkSession}

object L5_ADMITS_NUMRTR extends L5TableInfo[l5_admits_numrtr] {
  override def name: String = "L5_ADMITS_NUMRTR"
  override def dependsOn: Set[String] = Set("L3_ADMITS","L4_MAP_TOS5_CUSTOM","L2_II_MAP_DRG","L2_II_MAP_TOS")

  def createDataFrameWithoutDDL(sparkSession: SparkSession, loadedDependencies: Map[String, DataFrame], udfMap: Map[String, UserDefinedFunctionForDataLoader], runtimeVariables: RuntimeVariables): DataFrame = {
    import sparkSession.implicits._
    val l3Admits = loadedDependencies("L3_ADMITS")
    val l4MapTos5Custom = loadedDependencies("L4_MAP_TOS5_CUSTOM")
    val l2IiMapDrg = loadedDependencies("L2_II_MAP_DRG")
    val l2IiMapTos = loadedDependencies("L2_II_MAP_TOS")

    l3Admits.as("adm")
      .join(l2IiMapDrg.as("imd"),$"imd.drg_id"===$"adm.drg_id","inner")
      .join(l4MapTos5Custom.as("mtc"),$"mtc.tos_i_5"===$"adm.tos_i_5","left_outer")
      .join(l2IiMapTos.as("imt"),$"imt.tos_i_5"===$"mtc.tos_i_5","inner")
      .groupBy(
        $"adm.new_mem_attr_id",
        $"imt.tos1_id",
        $"imt.tos1",
        coalesce($"mtc.tos_custom_id",lit(3399999)).as("custom_tos"),
        $"adm.ia_time".cast(ShortType).as("ia_time"),
        $"adm.year_mth_id".cast(ShortType).as("year_mth_id"),
        $"adm.end_year_mth_id".cast(ShortType).as("end_year_mth_id"),
        coalesce($"adm.pcp_assign",lit("0")).as("pcp_assign"),
        $"adm.product_id",
        $"adm.sex",
        $"adm.age_cat2".cast(ShortType).as("age_cat2"),
        $"adm.at_risk_status_id",
        $"adm.mem_userdef_1_id",
        $"adm.zip",
        $"adm.cat_status_cost3",
        $"adm.contract_id",
        coalesce($"adm.provider_id",lit("0")).as("provider_id"),
        $"adm.drg_id",
        $"adm.tos_i_5",
        $"adm.drg_admittyp",
        $"adm.poa",
        $"adm.network_paid_status_id",
        $"adm.provider_status_id",
        coalesce($"adm.avoidable_admit_flag",lit(0)).as("avoidable_admit_flag"),
        coalesce($"adm.etg_id",lit(0)).as("etg_id"),
        coalesce($"imd.drg_wgt", lit(1)).as("drg_wgt")
      )
      .agg(
        sum($"adm.pqi").as("pqi"),
        sum($"adm.admit").as("admit"),
        sum($"adm.los").as("los"),
        sum($"adm.amt_req").as("amt_req"),
        sum($"adm.amt_eqv").as("amt_eqv"),
        sum($"adm.amt_pay").as("amt_pay"),
        sum($"adm.amt_np").as("amt_np"),
        sum($"adm.readmit_index_07").as("readmit_index_07"),
        sum($"adm.readmit_index_30").as("readmit_index_30"),
        sum($"adm.readmit_index_60").as("readmit_index_60"),
        sum($"adm.readmit_index_90").as("readmit_index_90"),
        sum($"adm.readmit_07").as("readmit_07"),
        sum($"adm.readmit_30").as("readmit_30"),
        sum($"adm.readmit_60").as("readmit_60"),
        sum($"adm.readmit_90").as("readmit_90")
      )
      .select(
        $"new_mem_attr_id",
        $"tos1_id",
        $"tos1",
        $"custom_tos".cast(LongType),
        $"ia_time",
        $"year_mth_id".cast(ShortType),
        $"end_year_mth_id".cast(ShortType),
        $"pcp_assign",
        $"product_id",
        $"sex".cast(ShortType),
        $"age_cat2".cast(ShortType),
        $"at_risk_status_id",
        $"mem_userdef_1_id",
        $"zip",
        $"cat_status_cost3".cast(ShortType),
        $"contract_id",
        $"provider_id",
        $"drg_id",
        $"tos_i_5",
        $"drg_admittyp",
        $"poa",
        $"network_paid_status_id",
        $"provider_status_id",
        $"avoidable_admit_flag",
        $"pqi",
        $"admit",
        $"los",
        $"amt_req".cast(DecimalType(19,2)),
        $"amt_eqv".cast(DecimalType(19,2)),
        $"amt_pay".cast(DecimalType(19,2)),
        $"amt_np".cast(DecimalType(19,2)),
        $"readmit_index_07",
        $"readmit_index_30",
        $"readmit_index_60",
        $"readmit_index_90",
        $"readmit_07",
        $"readmit_30",
        $"readmit_60",
        $"readmit_90",
        $"etg_id",
        $"drg_wgt".cast(DecimalType(10, 4))
      )
  }
}
