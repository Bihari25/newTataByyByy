package com.optum.df.opa.L5

import com.optum.df.opa.util.parseSql
import com.optum.df.opa.DataFrameExtensions._
import com.optum.df.opa.EtlLoader

import com.optum.oap.sparkdataloader.{RuntimeVariables, TableInfo, UserDefinedFunctionForDataLoader}
import org.apache.spark.sql.functions.{col, current_date, lit}
import org.apache.spark.sql.{DataFrame, SparkSession}

import scala.reflect.runtime.universe.TypeTag
import org.apache.spark.sql.Column

abstract class L5TableInfo[A <: Product: TypeTag] extends TableInfo[A] {

  def current_date(): Column = {
    if (System.getProperty("loadDate") != null) {
      val loadDate = java.sql.Date.valueOf(System.getProperty("loadDate"))
      return lit(loadDate)
    }
    return org.apache.spark.sql.functions.current_date()
  }

  override def createDataFrame(sparkSession: SparkSession, loadedDependencies: Map[String, DataFrame], udfMap: Map[String, UserDefinedFunctionForDataLoader], runtimeVariables: RuntimeVariables): DataFrame = {

    /* Timestamp adjustment needs to be reverted only when L5 table dependent on another L5 table as the input L5 dataframe will have data in EDT format
    There are few L5 tables depends on other Temp_L5_* tables. So, instead of using startsWith, we need to check whether dependent table name contains "L5_"
      */
    val loadedDependenciesWithoutRedshiftAdjustment = loadedDependencies.map {
              case (tableName: String, df: DataFrame) =>
                val effectiveDf = tableName match {
                  case tableName if tableName.contains("L5_") => df.revertRedshiftAdjustment()
                  case _ => df
                }
              tableName -> effectiveDf
    }

    val df = createDataFrameWithoutDDL(sparkSession, loadedDependenciesWithoutRedshiftAdjustment, udfMap, runtimeVariables).adjustTimestampForRedshift()
    val sqlFileName = getL5DDLPath(name)

    if (this.getClass.getClassLoader.getResourceAsStream(sqlFileName) != null) {
      // TODO: This only works if there is exactly one table per SQL file, which is true for L5
      val (tableName, columns, columnTypes) = parseSql.parseColumns(sqlFileName).head
      val columnsLower = columns.map(_.toLowerCase)
      val orderedDf = df.select(columnsLower.map(col): _*)
      orderedDf.checkTypes(columnTypes)
      val varcharTruncatedDf = orderedDf.truncateVarcharColumns(columnsLower.zip(columnTypes).toMap)
      varcharTruncatedDf
    } else {
      logger.warn(s"REDSHIFT WARNING: No DDL file for L5 table $name (expected: $sqlFileName). Ordering defaulted to ETL outcome")
      df
    }
  }

  def createDataFrameWithoutDDL(session: SparkSession, stringToFrame: Map[String, DataFrame], stringToLoader: Map[String, UserDefinedFunctionForDataLoader], variables: RuntimeVariables): DataFrame

  def getL5DDLPath(name: String): String = {
    val repFolder = if (EtlLoader.dailyL5Tables.contains(name)) "daily_rep" else "rep"
    s"OPADDL/${repFolder}/L5/tables/${name}.sql"
  }
}