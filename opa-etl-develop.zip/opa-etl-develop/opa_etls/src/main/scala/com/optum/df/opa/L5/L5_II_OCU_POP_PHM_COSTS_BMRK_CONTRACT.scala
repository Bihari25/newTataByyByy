package com.optum.df.opa.L5

import com.optum.df.opa.models.L5.l5_ii_ocu_pop_phm_costs_bmrk_contract
import com.optum.oap.sparkdataloader.{RuntimeVariables, UserDefinedFunctionForDataLoader}
import org.apache.spark.sql.functions.{coalesce, _}
import org.apache.spark.sql.types.{DecimalType, ShortType}
import org.apache.spark.sql.{DataFrame, SparkSession}

object L5_II_OCU_POP_PHM_COSTS_BMRK_CONTRACT extends L5TableInfo[l5_ii_ocu_pop_phm_costs_bmrk_contract] {
  override def name: String = "L5_II_OCU_POP_PHM_COSTS_BMRK_CONTRACT"
  override def dependsOn: Set[String] = Set("L2_II_OCU_POP_PHM_COSTS_CONTRACT","L2_II_MAP_NTWRK_PAID_STATUS","L2_II_MAP_DATE_RANGE","L2_II_MEM_ATTR","L2_II_MAP_TOS","L2_II_MAP_ETG")

  def createDataFrameWithoutDDL(sparkSession: SparkSession, loadedDependencies: Map[String, DataFrame], udfMap: Map[String, UserDefinedFunctionForDataLoader], runtimeVariables: RuntimeVariables): DataFrame = {
    import sparkSession.implicits._

    val l2IiOcuPopPhmCostsContract = loadedDependencies("L2_II_OCU_POP_PHM_COSTS_CONTRACT")
    val l2MapNtwrkPaidStatus = loadedDependencies("L2_II_MAP_NTWRK_PAID_STATUS")
    val l2IiMapDateRange = loadedDependencies("L2_II_MAP_DATE_RANGE")
    val l2IiMemAttr = loadedDependencies("L2_II_MEM_ATTR")
    val l2IiMapTos = loadedDependencies("L2_II_MAP_TOS")
    val l2IiMapEtg = loadedDependencies("L2_II_MAP_ETG")

    val max_date = l2IiMapDateRange.agg(max("ia_time").as("ia_time")).first().getAs[Integer]("ia_time")
    val time_frame =
      l2IiMapDateRange
        .where($"ia_time" === lit(max_date))
        .select(
          $"year_mth_id",
          $"ia_time"
        )
    l2IiOcuPopPhmCostsContract.as("pc")
      .join(l2MapNtwrkPaidStatus.as("nps"), $"nps.network_paid_status_id" === $"pc.network_paid_status_id", "left")
      .join(time_frame.as("tf"), $"pc.year_mth_id" === $"tf.year_mth_id")
      .join(l2IiMemAttr.as("ma"), $"pc.mem_attr_id" === $"ma.member_attr_id")
      .join(l2IiMapTos.as("mt"), $"pc.tos_i_5" === $"mt.tos_i_5", "left")
      .join(l2IiMapEtg.as("me"), $"pc.etg_id" === $"me.etg_id", "left")
      .groupBy(
        $"ma.age_cat2".cast(ShortType).as("age_cat2"),
        when($"ma.sex" === lit(true), 1).otherwise(lit(0)).cast(ShortType).as("sex"),
        $"ma.mpg_def_id",
        $"ma.coverage_status_id",
        $"ma.industry",
        $"ma.cat_status_cost3",
        $"tf.ia_time",
        when($"nps.network_status" === lit(true), 1).otherwise(0).as("network_status"),
        coalesce($"me.family", lit(0)).as("etg_family"),
        coalesce($"me.mpc", lit(0)).as("etg_mpc"),
        $"pc.tos_i_5",
        $"mt.tos1_id",
        $"mt.tos2_id",
        $"mt.tos3_id",
        $"pc.formulary",
        $"pc.channel",
        $"pc.gbo",
        $"pc.spec_rx_n_id",
        coalesce($"pc.covid_flag".cast(ShortType), lit(-1.toShort)).as("covid_flag")
      )
      .agg(
        sum($"amt_np").cast(DecimalType(19, 2)).as("amt_np"),
        sum($"amt_eqv").cast(DecimalType(19, 2)).as("amt_eqv"),
        sum($"amt_pay").cast(DecimalType(19, 2)).as("amt_pay"),
        sum($"amt_oth1").cast(DecimalType(19, 2)).as("amt_oth1"),
        sum($"amt_oth4").cast(DecimalType(19, 2)).as("amt_oth4"),
        sum($"encounter").cast(DecimalType(19, 2)).as("encounter"),
        sum($"generic").as("generic"),
        sum($"script").as("script"),
        sum($"script_gen").as("script_gen"),
        sum($"pc.script_adj").cast(DecimalType(19, 2)).as("script_adj"),
        sum($"days_sup").as("days_sup"),
        sum($"amt_req").cast(DecimalType(19, 2)).as("amt_req"),
        sum($"amt_liab").cast(DecimalType(19, 2)).as("amt_liab"),
        sum($"amt_admin_fee").cast(DecimalType(19, 2)).as("amt_admin_fee"),
        sum($"amt_cob").cast(DecimalType(19, 2)).as("amt_cob"),
        sum($"amt_disp").cast(DecimalType(19, 2)).as("amt_disp"),
        sum($"amt_ingr").cast(DecimalType(19, 2)).as("amt_ingr"),
        sum($"amt_not_covered").cast(DecimalType(19, 2)).as("amt_not_covered"),
        sum($"amt_other_carrier_pay").cast(DecimalType(19, 2)).as("amt_other_carrier_pay"),
        lit("Y").as("dummy_email")
      )
  }
}
