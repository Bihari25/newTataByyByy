package com.optum.df.opa.L5

import com.optum.df.opa.models.L5.l5_dict_proc_group
import com.optum.oap.sparkdataloader.{RuntimeVariables, UserDefinedFunctionForDataLoader}
import org.apache.spark.sql.functions.initcap
import org.apache.spark.sql.types.ShortType
import org.apache.spark.sql.{DataFrame, SparkSession}


object L5_DICT_PROC_GROUP extends L5TableInfo[l5_dict_proc_group]{

  override def name: String = "L5_DICT_PROC_GROUP"

  override def dependsOn: Set[String] = Set("L3_DICT_PROC_GROUP")

  def createDataFrameWithoutDDL(sparkSession: SparkSession, loadedDependencies: Map[String, DataFrame], udfMap: Map[String, UserDefinedFunctionForDataLoader], runtimeVariables: RuntimeVariables): DataFrame = {

    import sparkSession.implicits._

    val l3DictProcGroup = loadedDependencies("L3_DICT_PROC_GROUP")

    l3DictProcGroup
      .select(
        $"proc_group_id",
        $"proc_group_set",
        $"external_code",
        initcap($"description").as("description"),
        $"sensitive_ind".cast(ShortType),
        $"sensitive_cat_id".cast(ShortType)
      )
  }
}