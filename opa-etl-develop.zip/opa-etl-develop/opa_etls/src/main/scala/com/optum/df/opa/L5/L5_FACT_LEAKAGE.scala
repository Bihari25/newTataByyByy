package com.optum.df.opa.L5

import com.optum.df.opa.models.L5.l5_fact_leakage
import com.optum.oap.sparkdataloader.{RuntimeVariables, UserDefinedFunctionForDataLoader}
import org.apache.spark.sql.functions._
import org.apache.spark.sql.types.LongType
import org.apache.spark.sql.{DataFrame, SparkSession}


object L5_FACT_LEAKAGE extends L5TableInfo[l5_fact_leakage] {
  override def name: String = "L5_FACT_LEAKAGE"

  override def dependsOn: Set[String] = Set("L5_OCU_POP_COSTS_NUMRTR", "L5_DYNAMIC_TIME_RANGE", "L5_DICT_MONTH",
    "L5_DICT_FACILITY", "L2_II_MAP_DRG", "ZZ_L5_II_PROVINFO", "L5_II_MAP_PROV_AFFIL", "L5_II_MAP_PROVIDER_STATUS", "L2_DICT_SPEC",
    "L5_MAP_TOS1_CUSTOM_TOS", "L5_DICT_ADMIT_SOURCE", "L5_II_MAP_CONTRACT", "L5_II_MAP_NTWRK_PAID_STATUS", "L5_II_MAP_AT_RISK_STATUS",
    "L5_DICT_CUSTOM_TOS", "L5_II_MAP_PRODUCT", "L5_II_MAP_DATE_RANGE", "L5_DICT_FACILITY_TYPE", "L2_II_MAP_MDC", "L5_DICT_TOS1")

  def createDataFrameWithoutDDL(sparkSession: SparkSession, loadedDependencies: Map[String, DataFrame], udfMap: Map[String, UserDefinedFunctionForDataLoader], runtimeVariables: RuntimeVariables): DataFrame = {
    import sparkSession.implicits._

    val l5OcuPopCostsNumrtr = loadedDependencies("L5_OCU_POP_COSTS_NUMRTR")
    val l5DynamicTimeRange = loadedDependencies("L5_DYNAMIC_TIME_RANGE")
    val l5DictMonth = loadedDependencies("L5_DICT_MONTH")
    val l5DictFacility = loadedDependencies("L5_DICT_FACILITY")
    val l2IiMapDrg = loadedDependencies("L2_II_MAP_DRG")
    val zzL5IiProvinfo = loadedDependencies("ZZ_L5_II_PROVINFO")
    val l5IiMapProvAffil = loadedDependencies("L5_II_MAP_PROV_AFFIL")
    val l5IiMapProviderStatus = loadedDependencies("L5_II_MAP_PROVIDER_STATUS")
    val l2DictSpec = loadedDependencies("L2_DICT_SPEC")
    val l5MapTos1CustomTos = loadedDependencies("L5_MAP_TOS1_CUSTOM_TOS")
    val l5DictAdmitSource = loadedDependencies("L5_DICT_ADMIT_SOURCE")
    val l5IiMapContract = loadedDependencies("L5_II_MAP_CONTRACT")
    val l5IiMapNtwrkPaidStatus = loadedDependencies("L5_II_MAP_NTWRK_PAID_STATUS")
    val l5IiMapAtRiskStatus = loadedDependencies("L5_II_MAP_AT_RISK_STATUS")
    val l5DictCustomTos = loadedDependencies("L5_DICT_CUSTOM_TOS")
    val l5IiMapProduct = loadedDependencies("L5_II_MAP_PRODUCT")
    val l5IiMapDateRange = loadedDependencies("L5_II_MAP_DATE_RANGE")
    val l5DictFacilityType = loadedDependencies("L5_DICT_FACILITY_TYPE")
    val l2IiMapMdc = loadedDependencies("L2_II_MAP_MDC")
    val l5DictTos1 = loadedDependencies("L5_DICT_TOS1")


    val tempVals = l5OcuPopCostsNumrtr.as("op")
      .join(l5DynamicTimeRange.as("dt"), $"op.year_mth_id" === $"dt.year_mth_id", "inner")
      .where($"op.tos1_id" =!= lit(7) && $"dt.rolling_18_months_flg" === lit(1))
      .groupBy($"op.year_mth_id",
        $"op.custom_tos",
        $"op.provider_id",
        $"op.provider_status_id",
        $"op.prv_sp_4",
        $"op.product_id",
        $"op.pcp_assign",
        $"op.at_risk_status_id",
        $"op.network_paid_status_id",
        $"op.facility_id",
        $"op.drg_id",
        $"op.contract_id",
        $"op.admit_source"
      )
      .agg(
        sum($"op.amt_pay").as("amt_paid"),
        sum($"op.enc").as("encounters"),
        sum($"op.admits").as("admits"),
        sum($"op.amt_eqv").as("amt_allowed"),
        sum($"op.amt_np").as("amt_normalized")
      )
      .select($"op.year_mth_id",
        $"op.custom_tos",
        $"op.provider_id",
        $"op.provider_status_id",
        $"op.prv_sp_4",
        $"op.product_id",
        $"op.pcp_assign",
        $"op.at_risk_status_id",
        $"op.network_paid_status_id",
        $"op.facility_id",
        $"op.drg_id",
        $"op.contract_id",
        $"op.admit_source",
        $"amt_paid",
        $"encounters",
        $"admits",
        $"amt_allowed",
        $"amt_normalized"
      )

    val tempValsLY = l5OcuPopCostsNumrtr.as("op")
      .join(l5DictMonth.as("dm"), $"op.year_mth_id" === $"dm.prior_year_mth_id", "inner")
      .join(l5DynamicTimeRange.as("dt"), $"dm.year_mth_id" === $"dt.year_mth_id", "inner")
      .where($"op.tos1_id" =!= lit(7) && $"dt.rolling_18_months_flg" === lit(1))
      .groupBy($"dm.year_mth_id",
        $"op.custom_tos",
        $"op.provider_id",
        $"op.provider_status_id",
        $"op.prv_sp_4",
        $"op.product_id",
        $"op.pcp_assign",
        $"op.at_risk_status_id",
        $"op.network_paid_status_id",
        $"op.facility_id",
        $"op.drg_id",
        $"op.contract_id",
        $"op.admit_source"
      )
      .agg(
        sum($"op.amt_pay").as("amt_paid_ly"),
        sum($"op.enc").as("encounters_ly"),
        sum($"op.admits").as("admits_ly"),
        sum($"op.amt_eqv").as("amt_allowed_ly"),
        sum($"op.amt_np").as("amt_normalized_ly")
      )
      .select($"dm.year_mth_id",
        $"op.custom_tos",
        $"op.provider_id",
        $"op.provider_status_id",
        $"op.prv_sp_4",
        $"op.product_id",
        $"op.pcp_assign",
        $"op.at_risk_status_id",
        $"op.network_paid_status_id",
        $"op.facility_id",
        $"op.drg_id",
        $"op.contract_id",
        $"op.admit_source",
        $"amt_paid_ly",
        $"encounters_ly",
        $"admits_ly",
        $"amt_allowed_ly",
        $"amt_normalized_ly"
      )

    val tempValsTot = tempVals
      .groupBy($"year_mth_id",
        $"custom_tos",
        $"provider_id",
        $"prv_sp_4",
        $"product_id",
        $"pcp_assign",
        $"at_risk_status_id",
        $"facility_id",
        $"drg_id",
        $"contract_id",
        $"admit_source"
      )
      .agg(
        sum($"amt_paid").as("amt_paid_tot"),
        sum($"encounters").as("encounters_tot"),
        sum($"admits").as("admits_tot"),
        sum($"amt_allowed").as("amt_allowed_tot"),
        sum($"amt_normalized").as("amt_normalized_tot")
      )
      .select($"year_mth_id",
        $"custom_tos",
        $"provider_id",
        $"prv_sp_4",
        $"product_id",
        $"pcp_assign",
        $"at_risk_status_id",
        $"facility_id",
        $"drg_id",
        $"contract_id",
        $"admit_source",
        $"amt_paid_tot",
        $"encounters_tot",
        $"admits_tot",
        $"amt_allowed_tot",
        $"amt_normalized_tot"
      )

    val tempValsTotLY = tempValsLY
      .groupBy($"year_mth_id",
        $"custom_tos",
        $"provider_id",
        $"prv_sp_4",
        $"product_id",
        $"pcp_assign",
        $"at_risk_status_id",
        $"facility_id",
        $"drg_id",
        $"contract_id",
        $"admit_source"
      )
      .agg(
        sum($"amt_paid_ly").as("amt_paid_tot_ly"),
        sum($"encounters_ly").as("encounters_tot_ly"),
        sum($"admits_ly").as("admits_tot_ly"),
        sum($"amt_allowed_ly").as("amt_allowed_tot_ly"),
        sum($"amt_normalized_ly").as("amt_normalized_tot_ly")
      )
      .select($"year_mth_id",
        $"custom_tos",
        $"provider_id",
        $"prv_sp_4",
        $"product_id",
        $"pcp_assign",
        $"at_risk_status_id",
        $"facility_id",
        $"drg_id",
        $"contract_id",
        $"admit_source",
        $"amt_paid_tot_ly",
        $"encounters_tot_ly",
        $"admits_tot_ly",
        $"amt_allowed_tot_ly",
        $"amt_normalized_tot_ly"
      )

    val l5FactLeakage = tempVals.as("t")
      .join(tempValsLY.as("tly"),
        $"t.contract_id" === $"tly.contract_id" &&
        $"t.facility_id" === $"tly.facility_id" &&
        $"t.product_id" === $"tly.product_id" &&
        $"t.prv_sp_4" === $"tly.prv_sp_4" &&
        $"t.drg_id" === $"tly.drg_id" &&
        $"t.network_paid_status_id" === $"tly.network_paid_status_id" &&
        $"t.provider_id" === $"tly.provider_id" &&
        $"t.custom_tos" === $"tly.custom_tos" &&
        $"t.admit_source" === $"tly.admit_source" &&
        $"t.pcp_assign" === $"tly.pcp_assign" &&
        $"t.provider_status_id" === $"tly.provider_status_id" &&
        $"t.year_mth_id" === $"tly.year_mth_id" &&
        $"t.at_risk_status_id" === $"tly.at_risk_status_id",
        "full_outer")
      .join(tempValsTot.as("tt"),
        coalesce($"t.contract_id", $"tly.contract_id") === $"tt.contract_id" &&
        coalesce($"t.facility_id", $"tly.facility_id") === $"tt.facility_id" &&
        coalesce($"t.product_id", $"tly.product_id") === $"tt.product_id" &&
        coalesce($"t.prv_sp_4", $"tly.prv_sp_4") === $"tt.prv_sp_4" &&
        coalesce($"t.drg_id", $"tly.drg_id") === $"tt.drg_id" &&
        coalesce($"t.provider_id", $"tly.provider_id") === $"tt.provider_id" &&
        coalesce($"t.custom_tos", $"tly.custom_tos") === $"tt.custom_tos" &&
        coalesce($"t.admit_source", $"tly.admit_source") === $"tt.admit_source" &&
        coalesce($"t.pcp_assign", $"tly.pcp_assign") === $"tt.pcp_assign" &&
        coalesce($"t.year_mth_id", $"tly.year_mth_id") === $"tt.year_mth_id" &&
        coalesce($"t.at_risk_status_id", $"tly.at_risk_status_id") === $"tt.at_risk_status_id",
        "full_outer")
      .join(tempValsTotLY.as("ttly"),
        coalesce($"t.contract_id", $"tly.contract_id") === $"ttly.contract_id" &&
        coalesce($"t.facility_id", $"tly.facility_id") === $"ttly.facility_id" &&
        coalesce($"t.product_id", $"tly.product_id") === $"ttly.product_id" &&
        coalesce($"t.prv_sp_4", $"tly.prv_sp_4") === $"ttly.prv_sp_4" &&
        coalesce($"t.drg_id", $"tly.drg_id") === $"ttly.drg_id" &&
        coalesce($"t.provider_id", $"tly.provider_id") === $"ttly.provider_id" &&
        coalesce($"t.custom_tos", $"tly.custom_tos") === $"ttly.custom_tos" &&
        coalesce($"t.admit_source", $"tly.admit_source") === $"ttly.admit_source" &&
        coalesce($"t.pcp_assign", $"tly.pcp_assign") === $"ttly.pcp_assign" &&
        coalesce($"t.year_mth_id", $"tly.year_mth_id") === $"ttly.year_mth_id" &&
        coalesce($"t.at_risk_status_id", $"tly.at_risk_status_id") === $"ttly.at_risk_status_id",
        "full_outer")
      .join(l5DictFacility.as("df"), coalesce($"t.facility_id", $"tly.facility_id") === $"df.facility_id", "inner")
      .join(l2IiMapDrg.as("mdrg"), coalesce($"t.drg_id", $"tly.drg_id") === $"mdrg.drg_id", "inner")
      .join(zzL5IiProvinfo.as("pcp"), coalesce($"t.pcp_assign", $"tly.pcp_assign") === $"pcp.provider_id", "inner")
      .join(l5IiMapProvAffil.as("mpa"), $"pcp.affil_id" === $"mpa.affil_id", "inner")
      .join(l5IiMapProviderStatus.as("mps"), coalesce($"t.provider_status_id", $"tly.provider_status_id") === $"mps.provider_status_id", "inner")
      .join(l2DictSpec.as("ds"), coalesce($"t.prv_sp_4", $"tly.prv_sp_4") === $"ds.prv_sp_4", "inner")
      .join(l5MapTos1CustomTos.as("tos"), coalesce($"t.custom_tos", $"tly.custom_tos") === $"tos.custom_tos", "inner")
      .join(l5DictAdmitSource.as("das"), coalesce($"t.admit_source", $"tly.admit_source") === $"das.admit_source", "inner")
      .join(l5IiMapContract.as("mc"), coalesce($"t.contract_id", $"tly.contract_id") === $"mc.contract_id", "inner")
      .join(l5IiMapNtwrkPaidStatus.as("nps"), coalesce($"t.network_paid_status_id", $"tly.network_paid_status_id") === $"nps.network_paid_status_id", "inner")
      .join(l5IiMapAtRiskStatus.as("ars"), coalesce($"t.at_risk_status_id", $"tly.at_risk_status_id") === $"ars.at_risk_status_id", "inner")
      .join(l5IiMapProduct.as("mp"), coalesce($"t.product_id", $"tly.product_id") === $"mp.product_id", "inner")
      .join(zzL5IiProvinfo.as("ser"), coalesce($"t.provider_id", $"tly.provider_id") === $"ser.provider_id", "inner")
      .join(l5DictCustomTos.as("dct"), coalesce($"t.custom_tos", $"tly.custom_tos") === $"dct.tos_custom_id", "inner")
      .join(l5IiMapDateRange.as("mdr"), coalesce($"t.year_mth_id", $"tly.year_mth_id") === $"mdr.year_mth_id", "inner")
      .join(l5DictFacilityType.as("dft"), $"df.facility_type_id" === $"dft.facility_type_id", "inner")
      .join(l2IiMapMdc.as("mdc"), $"mdrg.mdc" === $"mdc.mdc", "inner")
      .join(l5DictTos1.as("tos1"), $"tos.tos1_id" === $"tos1.tos1_id", "inner")
      .select(
        coalesce($"t.at_risk_status_id", $"tly.at_risk_status_id").as("at_risk_status_id"),
        $"ars.at_risk_status_desc",
        coalesce($"t.drg_id", $"tly.drg_id").as("drg_id"),
        $"mdrg.drg_code",
        $"mdrg.drg_desc",
        coalesce($"t.facility_id", $"tly.facility_id").as("facility_id"),
        $"df.facility_name",
        $"df.facility_type_id",
        $"dft.facility_type_name",
        coalesce($"t.pcp_assign", $"tly.pcp_assign").as("pcp_assign"),
        $"pcp.provider_name".as("pcp_assign_name"),
        $"pcp.prov_npi".as("pcp_assign_npi"),
        $"pcp.affil_id".as("prov_affil_id"),
        coalesce($"t.network_paid_status_id", $"tly.network_paid_status_id").as("network_paid_status_id"),
        $"nps.network_paid_status_desc",
        coalesce($"t.provider_id", $"tly.provider_id").as("servicing_provider"),
        $"ser.provider_name".as("servicing_provider_name"),
        $"ser.prov_npi".as("servicing_provider_npi"),
        $"ds.sp3_id",
        $"ds.sp3",
        coalesce($"t.prv_sp_4", $"tly.prv_sp_4").cast(LongType).as("prv_sp_4"),
        $"ds.sp4",
        coalesce($"t.provider_status_id", $"tly.provider_status_id").as("provider_status_id"),
        $"mps.provider_status_desc",
        when($"mps.par_status" === lit(1), lit("Y")).otherwise("N").as("par_status"),
        coalesce($"t.custom_tos", $"tly.custom_tos").cast(LongType).as("custom_tos"),
        $"dct.tos_custom_desc",
        coalesce($"t.contract_id", $"tly.contract_id").as("contract_id"),
        $"mc.contract_desc",
        $"mc.contract",
        coalesce($"t.product_id", $"tly.product_id").as("product_id"),
        $"mp.product_desc",
        $"mp.product",
        coalesce($"t.admit_source", $"tly.admit_source").as("admit_source"),
        $"das.admit_source_desc",
        coalesce($"t.year_mth_id", $"tly.year_mth_id").as("year_mth_id"),
        $"mdr.mth_year_label2".as("year_mth_desc"),
        $"mdr.prior_mth_year_desc".as("prior_year_mth_desc"),
        $"tos.tos1_id",
        $"tos1.tos1",
        $"mdrg.mdc",
        $"mdc.mdc_desc",
        $"mpa.prov_affil_lv2_id",
        $"mpa.prov_affil_lv2_desc",
        $"mpa.prov_affil_desc",
        $"t.amt_paid",
        $"t.encounters",
        $"t.admits",
        $"t.amt_allowed",
        $"t.amt_normalized",
        $"tly.amt_paid_ly",
        $"tly.encounters_ly",
        $"tly.admits_ly",
        $"tly.amt_allowed_ly",
        $"tly.amt_normalized_ly",
        $"tt.amt_paid_tot",
        $"tt.encounters_tot",
        $"tt.admits_tot",
        $"tt.amt_allowed_tot",
        $"tt.amt_normalized_tot",
        $"ttly.amt_paid_tot_ly",
        $"ttly.encounters_tot_ly",
        $"ttly.admits_tot_ly",
        $"ttly.amt_allowed_tot_ly",
        $"ttly.amt_normalized_tot_ly"
      )

    l5FactLeakage
  }
}
