package com.optum.df.opa.L5

import com.optum.df.opa.models.L5.l5_ii_map_product
import com.optum.oap.sparkdataloader.{RuntimeVariables, UserDefinedFunctionForDataLoader}
import org.apache.spark.sql.types.ShortType
import org.apache.spark.sql.functions.lit
import org.apache.spark.sql.{DataFrame, SparkSession}

object L5_II_MAP_PRODUCT extends L5TableInfo[l5_ii_map_product]{
  override def name: String = "L5_II_MAP_PRODUCT"

  override def dependsOn: Set[String] = Set("L2_II_MAP_PRODUCT")

  def createDataFrameWithoutDDL(sparkSession: SparkSession, loadedDependencies: Map[String, DataFrame], udfMap: Map[String, UserDefinedFunctionForDataLoader], runtimeVariables: RuntimeVariables): DataFrame = {
    import sparkSession.implicits._

    val l2IiMapProduct = loadedDependencies("L2_II_MAP_PRODUCT")
    val defaultRow = Seq(("UNK", "Unspecified", "Unspecified", "Unspecified$UNK", "Unspecified LV1", "Unspecified", "Unspecified LV1", "Unspecified LV2", "Unspecified", "Unspecified LV1#Unspecified LV2", 3, 1.toShort)).toDF()


    val tempL5IiMapProduct = l2IiMapProduct.select(
      $"map_srce_e",
      $"product",
      $"product_desc",
      $"product_id",
      $"product_lv1",
      $"product_lv1_desc",
      $"product_lv1_id",
      $"product_lv2",
      $"product_lv2_desc",
      $"product_lv2_id",
      $"product_num_id",
      $"riflag".cast(ShortType))

    val unspecifiedIdExists: Boolean = tempL5IiMapProduct.where($"product_id" === lit("Unspecified$UNK")).count > 0

    val l5IiMapProduct = if (unspecifiedIdExists) tempL5IiMapProduct else tempL5IiMapProduct.union(defaultRow)

    l5IiMapProduct
  }
}
