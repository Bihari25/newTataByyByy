package com.optum.df.opa.L5

import com.optum.df.opa.models.L5.l5_ii_ocu_member_bmrk_contract
import com.optum.oap.sparkdataloader.{RuntimeVariables, UserDefinedFunctionForDataLoader}
import org.apache.spark.sql.functions._
import org.apache.spark.sql.types.{DecimalType, IntegerType, ShortType}
import org.apache.spark.sql.{DataFrame, SparkSession}

object L5_II_OCU_MEMBER_BMRK_CONTRACT extends L5TableInfo[l5_ii_ocu_member_bmrk_contract] {
  override def name: String = "L5_II_OCU_MEMBER_BMRK_CONTRACT"

  override def dependsOn: Set[String] = Set("L2_II_OCU_MEMBER_CONTRACT", "L2_II_MAP_DATE_RANGE", "L2_II_MEM_ATTR")

  def createDataFrameWithoutDDL(sparkSession: SparkSession, loadedDependencies: Map[String, DataFrame], udfMap: Map[String, UserDefinedFunctionForDataLoader], runtimeVariables: RuntimeVariables): DataFrame = {
    import sparkSession.implicits._

    val l2IiOcuMemberContract = loadedDependencies("L2_II_OCU_MEMBER_CONTRACT")
    val l2IiMapDateRange = loadedDependencies("L2_II_MAP_DATE_RANGE")
    val l2IiMemAttr = loadedDependencies("L2_II_MEM_ATTR")

    val max_date = l2IiMapDateRange.agg(max("ia_time").as("ia_time")).first().getAs[Integer]("ia_time")
    val time_frame =
      l2IiMapDateRange
      .where($"ia_time" === lit(max_date))
      .select(
        $"year_mth_id",
        $"ia_time"
      )

    l2IiOcuMemberContract.as("om")
      .join(time_frame.as("tf"), $"om.year_mth_id" === $"tf.year_mth_id")
      .join(l2IiMemAttr.as("ma"), $"om.mem_attr_id" === $"ma.member_attr_id")
      .groupBy(
        $"ma.age_cat2".cast(ShortType).as("age_cat2"),
        when($"ma.sex" === lit(true), 1).otherwise(lit(0)).cast(ShortType).as("sex"),
        $"ma.mpg_def_id",
        $"ma.coverage_status_id",
        $"ma.industry".cast(ShortType).as("industry"),
        $"ma.cat_status_cost3".cast(ShortType).as("cat_status_cost3"),
        $"tf.ia_time".cast(ShortType).as("ia_time"),
        $"om.contract_id",
        $"primary_payer_ind".cast(ShortType).as("primary_payer_ind")
      )
      .agg(
        sum($"om.mm").cast(IntegerType).as("mm"),
        sum($"om.mm_rx").cast(IntegerType).as("mm_rx"),
        sum($"om.subscr_months").as("subscr_months"),
        sum($"om.age_tot").as("age_tot"),
        sum($"om.rrisk").as("rrisk"),
        sum($"om.prisk").as("prisk"),
        sum($"om.premium_tot").as("premium_tot"),
        sum($"om.mm_den").cast(IntegerType).as("mm_den"),
        lit("Y").as("dummy_email"),
        sum($"om.contract_prisk").cast(DecimalType(10, 4)).as("contract_prisk"),
        sum($"om.contract_rrisk").cast(DecimalType(10, 4)).as("contract_rrisk")
      )
      .select(
        $"age_cat2",
        $"sex",
        $"mpg_def_id",
        $"coverage_status_id",
        $"industry",
        $"cat_status_cost3",
        $"ia_time",
        $"mm",
        $"mm_rx",
        $"subscr_months".cast(DecimalType(19, 2)),
        $"age_tot",
        $"rrisk".cast(DecimalType(10, 4)),
        $"prisk".cast(DecimalType(10, 4)),
        $"premium_tot".cast(DecimalType(19, 2)),
        $"mm_den",
        $"dummy_email",
        $"contract_id",
        $"contract_prisk",
        $"contract_rrisk",
        $"primary_payer_ind"
      )
  }
}
