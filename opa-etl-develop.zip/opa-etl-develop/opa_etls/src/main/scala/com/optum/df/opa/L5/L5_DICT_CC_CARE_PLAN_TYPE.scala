package com.optum.df.opa.L5

import com.optum.df.opa.models.L5.l5_dict_cc_care_plan_type
import com.optum.oap.sparkdataloader.{RuntimeVariables, UserDefinedFunctionForDataLoader}
import org.apache.spark.sql.{DataFrame, SparkSession}

object L5_DICT_CC_CARE_PLAN_TYPE extends L5TableInfo[l5_dict_cc_care_plan_type] {
  override def name: String = "L5_DICT_CC_CARE_PLAN_TYPE"
  override def dependsOn: Set[String] = Set("L1_DICT_CC_CARE_PLAN_TYPE")

  def createDataFrameWithoutDDL(sparkSession: SparkSession, loadedDependencies: Map[String, DataFrame], udfMap: Map[String, UserDefinedFunctionForDataLoader], runtimeVariables: RuntimeVariables): DataFrame = {
    import sparkSession.implicits._

    val l1DictCcCarePlanType = loadedDependencies("L1_DICT_CC_CARE_PLAN_TYPE")
    val defaults = Seq(("Unspecified$UNK", "Unspecified")).toDF()

    l1DictCcCarePlanType.select(
      $"care_plan_type",
      $"care_plan_type_nm"
      ).distinct().union(defaults)
  }
}
