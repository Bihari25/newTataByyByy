package com.optum.df.opa.L5

import com.optum.df.opa.models.L5.l5_dict_cc_user
import com.optum.oap.sparkdataloader.{RuntimeVariables, UserDefinedFunctionForDataLoader}
import org.apache.spark.sql.functions._
import org.apache.spark.sql.{DataFrame, SparkSession}

object L5_DICT_CC_USER extends L5TableInfo[l5_dict_cc_user] {
  override def name: String = "L5_DICT_CC_USER"
  override def dependsOn: Set[String] = Set("L1_CC_USER", "L5_CC_CASE")

  def createDataFrameWithoutDDL(sparkSession: SparkSession, loadedDependencies: Map[String, DataFrame], udfMap: Map[String, UserDefinedFunctionForDataLoader], runtimeVariables: RuntimeVariables): DataFrame = {
    import sparkSession.implicits._

    val l1CcUser = loadedDependencies("L1_CC_USER")
    val l5CcCase = loadedDependencies("L5_CC_CASE")

    l5CcCase.as("c")
      .join(l1CcUser.as("u"), $"c.case_owner_id" === $"u.user_id", "left")
      .select(
        $"c.case_owner_id".as("user_id"),
        coalesce($"u.user_nm", $"c.case_owner_id").as("user_nm")
      ).distinct()
  }
}
