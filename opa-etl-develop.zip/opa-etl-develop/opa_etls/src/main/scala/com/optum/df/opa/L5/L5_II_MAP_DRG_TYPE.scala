package com.optum.df.opa.L5

import com.optum.df.opa.models.L5.l5_ii_map_drg_type
import com.optum.oap.sparkdataloader.{RuntimeVariables, UserDefinedFunctionForDataLoader}
import org.apache.spark.sql.functions.{lit, when}
import org.apache.spark.sql.{DataFrame, SparkSession}


object L5_II_MAP_DRG_TYPE extends L5TableInfo[l5_ii_map_drg_type] {
  override def name: String = "L5_II_MAP_DRG_TYPE"

  override def dependsOn: Set[String] = Set("L2_II_MAP_DRG_TYPE")

  def createDataFrameWithoutDDL(sparkSession: SparkSession, loadedDependencies: Map[String, DataFrame], udfMap: Map[String, UserDefinedFunctionForDataLoader], runtimeVariables: RuntimeVariables): DataFrame = {
    import sparkSession.implicits._

    val l2IiMapDrgType = loadedDependencies("L2_II_MAP_DRG_TYPE")

    l2IiMapDrgType
      .select(
        when($"drg_admittyp" === lit("NB"),lit("OB"))
          .otherwise($"drg_admittyp")
          .as("drg_admittyp"),
        when($"drg_admittyp" === lit("UNK"),lit("Other"))
          .when($"drg_admittyp".isin(lit("NB"), lit("OB")), lit("Maternity"))
          .otherwise($"drg_type_desc")
          .as("drg_type_desc")
      ).distinct()
  }
}