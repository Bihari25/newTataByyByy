package com.optum.df.opa.L5

import com.optum.df.opa.models.L5.l5_ii_dict_proc_srv
import com.optum.oap.sparkdataloader.{RuntimeVariables, UserDefinedFunctionForDataLoader}
import org.apache.spark.sql.functions.max
import org.apache.spark.sql.{DataFrame, SparkSession}

object L5_II_DICT_PROC_SRV extends L5TableInfo[l5_ii_dict_proc_srv] {
  override def name: String = "L5_II_DICT_PROC_SRV"

  override def dependsOn: Set[String] = Set("L2_II_QL_CLAIMS")

  def createDataFrameWithoutDDL(sparkSession: SparkSession, loadedDependencies: Map[String, DataFrame], udfMap: Map[String, UserDefinedFunctionForDataLoader], runtimeVariables: RuntimeVariables): DataFrame = {
    import sparkSession.implicits._

    val l2IIQlClaims = loadedDependencies("L2_II_QL_CLAIMS")
    val defaultRow = Seq(l5_ii_dict_proc_srv(proc_srv = "0", proc_srv_desc = "Unknown Proc Srv")).toDF()

    l2IIQlClaims.where($"proc_srv".notEqual("0")).
      groupBy($"proc_srv")
      .agg(max($"proc_srv_desc").as("proc_srv_desc"))
      .select(
      $"proc_srv",
      $"proc_srv_desc")
      .union(defaultRow)
  }

}
