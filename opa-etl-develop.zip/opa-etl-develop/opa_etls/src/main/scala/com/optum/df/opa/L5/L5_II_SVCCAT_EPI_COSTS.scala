package com.optum.df.opa.L5

import com.optum.df.opa.models.L5.l5_ii_svccat_epi_costs
import com.optum.oap.sparkdataloader.{RuntimeVariables, UserDefinedFunctionForDataLoader}
import org.apache.spark.sql.functions._
import org.apache.spark.sql.types.{DecimalType, ShortType}
import org.apache.spark.sql.{DataFrame, SparkSession}

object L5_II_SVCCAT_EPI_COSTS extends L5TableInfo[l5_ii_svccat_epi_costs] {
    override def name: String = "L5_II_SVCCAT_EPI_COSTS"
    override def dependsOn: Set[String] = Set("L2_II_EPI_COSTS", "L2_II_MAP_ETG" )


    def createDataFrameWithoutDDL(sparkSession: SparkSession, loadedDependencies: Map[String, DataFrame], udfMap: Map[String, UserDefinedFunctionForDataLoader], runtimeVariables: RuntimeVariables): DataFrame = {
        import sparkSession.implicits._


        val l2IiEpiCosts = loadedDependencies("L2_II_EPI_COSTS")
        val l2IiMapEtg = loadedDependencies("L2_II_MAP_ETG")

        l2IiEpiCosts.as("epc")
          .join(l2IiMapEtg.as("met"), $"epc.etg_id" === $"met.etg_id", "left_outer")
          .groupBy(
              $"epc.etg_id",
              $"met.family",
              $"epc.ia_time",
              $"met.mpc",
              $"epc.peer_def_id",
              $"epc.provider_id",
              $"epc.sev_level",
              $"epc.psc_cat1_id",
              $"epc.util_spec_cat_cd"
              )
          .agg(
              sum($"epc.cost_act_tot").cast(DecimalType(38, 18)).as("cost_act_tot"),
              sum($"epc.cost2_act_tot").cast(DecimalType(38, 18)).as("cost2_act_tot"),
              sum($"epc.cost3_act_tot").cast(DecimalType(38, 18)).as("cost3_act_tot"),
              sum($"epc.enc_act_tot").cast(DecimalType(38, 18)).as("enc_act_tot"),
              sum($"epc.cost_peer_tot").cast(DecimalType(38, 18)).as("cost_peer_tot"),
              sum($"epc.cost2_peer_tot").cast(DecimalType(38, 18)).as("cost2_peer_tot"),
              sum($"epc.cost3_peer_tot").cast(DecimalType(38, 18)).as("cost3_peer_tot"),
              sum($"epc.enc_peer_tot").cast(DecimalType(38, 18)).as("enc_peer_tot")
              )
          .select(
             $"epc.ia_time",
             coalesce($"epc.provider_id",lit("Unspecified$UNK")).as("provider_id"),
             coalesce($"epc.etg_id",lit(0)).as("etg_id"),
             coalesce($"epc.sev_level",lit(0)).cast(ShortType).as("sev_level"),
             coalesce($"met.family",lit(0)).as("family"),
             coalesce($"met.mpc",lit(0)).as("mpc"),
             $"epc.peer_def_id",
             $"epc.psc_cat1_id",
             $"epc.util_spec_cat_cd",
             $"cost_act_tot",
             $"cost2_act_tot",
             $"cost3_act_tot",
             $"enc_act_tot",
             $"cost_peer_tot",
             $"cost2_peer_tot",
             $"cost3_peer_tot",
             $"enc_peer_tot"
             )
    }
}
