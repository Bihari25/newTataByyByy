package com.optum.df.opa.L5

import com.optum.df.opa.models.L5.l5_ii_map_biz_segment
import com.optum.oap.sparkdataloader.{RuntimeVariables, UserDefinedFunctionForDataLoader}
import com.optum.oadw.oadwModels.l2_ii_map_biz_segment
import org.apache.spark.sql.functions.{coalesce, when}
import org.apache.spark.sql.types.ShortType
import org.apache.spark.sql.{DataFrame, SparkSession}

object L5_II_MAP_BIZ_SEGMENT extends L5TableInfo[l5_ii_map_biz_segment]{
  override def name: String = "L5_II_MAP_BIZ_SEGMENT"

  override def dependsOn: Set[String] = Set("L2_II_MAP_BIZ_SEGMENT")

  def createDataFrameWithoutDDL(sparkSession: SparkSession, loadedDependencies: Map[String, DataFrame], udfMap: Map[String, UserDefinedFunctionForDataLoader], runtimeVariables: RuntimeVariables): DataFrame = {
    import sparkSession.implicits._

    val l2IIMapBizSegment = loadedDependencies("L2_II_MAP_BIZ_SEGMENT")

    l2IIMapBizSegment.select(
      $"biz_segment_id",
      $"biz_segment",
      $"biz_segment_desc",
      when($"biz_segment_lv2_id".isNull, $"biz_segment_id")
        .otherwise($"biz_segment_lv2_id").as("biz_segment_lv2_id"),
      coalesce($"biz_segment_lv2", $"biz_segment").as("biz_segment_lv2"),
      when($"biz_segment_lv2_desc".isNull, $"biz_segment_desc")
        .otherwise($"biz_segment_lv2_desc").as("biz_segment_lv2_desc"),
      coalesce($"biz_segment_lv1_id", $"biz_segment_lv2_id", $"biz_segment_id").as("biz_segment_lv1_id"),
      coalesce($"biz_segment_lv1", $"biz_segment_lv2", $"biz_segment").as("biz_segment_lv1"),
      coalesce($"biz_segment_lv1_desc", $"biz_segment_lv2_desc", $"biz_segment_desc").as("biz_segment_lv1_desc"),
      $"map_srce_e",
      $"riflag".cast(ShortType),
      $"biz_segment_num_id"
    )
  }
}
