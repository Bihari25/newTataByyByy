package com.optum.df.opa.L5

import com.optum.df.opa.models.L5.l5_ii_dict_risk_stat_lv2
import com.optum.oap.sparkdataloader.{RuntimeVariables, UserDefinedFunctionForDataLoader}
import org.apache.spark.sql.functions._
import org.apache.spark.sql.{DataFrame, SparkSession}


object L5_II_DICT_RISK_STAT_LV2 extends L5TableInfo[l5_ii_dict_risk_stat_lv2] {

  override def name: String = "L5_II_DICT_RISK_STAT_LV2"

  override def dependsOn: Set[String] = Set("L2_II_MAP_AT_RISK_STATUS")

  def createDataFrameWithoutDDL(sparkSession: SparkSession, loadedDependencies: Map[String, DataFrame], udfMap: Map[String, UserDefinedFunctionForDataLoader], runtimeVariables: RuntimeVariables): DataFrame = {

    import sparkSession.implicits._

    val l2IIMapAtRiskStatus = loadedDependencies("L2_II_MAP_AT_RISK_STATUS")
    val defaultRow = Seq(("Unspecified LV1#Unspecified LV2", "Unspecified", "Unspecified LV1")).toDF()

    val tempL5IiDictRiskStatLv2 = l2IIMapAtRiskStatus.select(
      coalesce($"at_risk_status_lv2_id", $"at_risk_status_id").as("at_risk_status_lv2_id"),
      coalesce($"at_risk_status_lv2_desc", $"at_risk_status_desc").as("at_risk_status_lv2_desc"),
      coalesce($"at_risk_status_lv1_id", $"at_risk_status_lv2_id", $"at_risk_status_id").as("at_risk_status_lv1_id")
    ).distinct()

    val unspecifiedIdExists: Boolean = tempL5IiDictRiskStatLv2.where($"at_risk_status_lv2_id" === lit("Unspecified LV1#Unspecified LV2")).count > 0

    val l5IiDictRiskStatLv2 = if (unspecifiedIdExists) tempL5IiDictRiskStatLv2 else tempL5IiDictRiskStatLv2.union(defaultRow)

    l5IiDictRiskStatLv2
  }
}