package com.optum.df.opa.L5

import com.optum.df.opa.models.L5.{l5_clinical_event_dates}
import com.optum.oap.sparkdataloader.{RuntimeVariables, UserDefinedFunctionForDataLoader}
import org.apache.spark.sql.functions._
import org.apache.spark.sql.{DataFrame, SparkSession}


object L5_CLINICAL_EVENT_DATES extends L5TableInfo[l5_clinical_event_dates] {
  override def name: String = "L5_CLINICAL_EVENT_DATES"

  override def dependsOn: Set[String] = Set("L5_CLINICAL_EVENT", "L4_MAP_CDS_GRP")

  def createDataFrameWithoutDDL(sparkSession: SparkSession, loadedDependencies: Map[String, DataFrame], udfMap: Map[String, UserDefinedFunctionForDataLoader], runtimeVariables: RuntimeVariables): DataFrame = {
    import sparkSession.implicits._

    val l5ClinicalEvent = loadedDependencies("L5_CLINICAL_EVENT")
    val l4MapCdsGrp = loadedDependencies("L4_MAP_CDS_GRP")

    l5ClinicalEvent.alias("ce")
      .join(broadcast(l4MapCdsGrp).as("mcg"), $"ce.client_id" === $"mcg.client_id" && $"ce.cds_grp" === $"mcg.cds_grp")
      .groupBy(
        $"ce.client_id",
        $"mcg.client_ds_id"
      )
      .agg(
        min($"ce.evt_start_dtm").as("clinical_evt_min_dt"),
        max($"ce.evt_start_dtm").as("clinical_evt_max_dt")
      ).
      select(
        $"client_id",
        $"client_ds_id",
        $"clinical_evt_min_dt",
        $"clinical_evt_max_dt"
      )
  }
}