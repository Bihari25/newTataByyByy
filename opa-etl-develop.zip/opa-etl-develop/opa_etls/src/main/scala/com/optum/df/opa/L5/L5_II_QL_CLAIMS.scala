package com.optum.df.opa.L5

import com.optum.df.opa.models.L5.l5_ii_ql_claims
import com.optum.oap.sparkdataloader.{RuntimeVariables, UserDefinedFunctionForDataLoader}
import org.apache.spark.sql.{DataFrame, SparkSession}
import org.apache.spark.sql.functions._


object L5_II_QL_CLAIMS extends L5TableInfo[l5_ii_ql_claims] {
  override def name: String = "L5_II_QL_CLAIMS"
  override def dependsOn: Set[String] = Set("L2_II_QL_CLAIMS", "L2_II_MAP_DATE_RANGE", "L2_II_MEM_ATTR_MEMBER_EXT", "L2_II_MEM_ENROLL", "L2_II_SUBSCRIBER")

    def createDataFrameWithoutDDL(sparkSession: SparkSession, loadedDependencies: Map[String, DataFrame], udfMap: Map[String, UserDefinedFunctionForDataLoader], runtimeVariables: RuntimeVariables): DataFrame = {
        import sparkSession.implicits._

        val l2IiQlClaims = loadedDependencies("L2_II_QL_CLAIMS")
        val l2IiMapDateRange = loadedDependencies("L2_II_MAP_DATE_RANGE")
        val l2IiMemAttrMemberExt = loadedDependencies("L2_II_MEM_ATTR_MEMBER_EXT")
        val l2IiMemEnroll = loadedDependencies("L2_II_MEM_ENROLL")
        val l2IiSubscriber = loadedDependencies("L2_II_SUBSCRIBER")

        l2IiQlClaims.as("qc")
          .join(l2IiMapDateRange.as("mdr"), date_format($"qc.from_dt", "yyyyMM") === $"mdr.yr_month".cast("String"), "inner")
          .join(l2IiMemAttrMemberExt.as("me"), $"qc.member" === $"me.member" && $"mdr.year_mth_id" === $"me.year_mth_id", "left")
          .join(l2IiMemEnroll.as("men"), $"qc.member" === $"men.member", "left")
          .join(l2IiSubscriber.as ("sub"), $"men.subscriber_id" === $"sub.subscriber_id", "left")
          .where($"qc.from_dt".between ($"men.eff_dt", $"men.end_dt") && $"qc.from_dt".between($"sub.eff_dt", $"sub.end_dt"))
          .select(
              $"qc.qlc_id",
              coalesce($"qc.claim_id",lit("0")).as("claim_id"),
              $"qc.member",
              coalesce($"qc.conf_num",lit(0)).as("conf_num"),
              $"qc.from_dt",
              $"qc.to_dt",
              coalesce($"qc.svc_qty",lit(0)).as("svc_qty"),
              coalesce($"qc.provider_id",lit("0")).as("provider_id"),
              coalesce($"me.pcp_assign",lit("0")).as("pcp_assign"),
              coalesce($"qc.diag1",lit("0")).as("diag1"),
              $"qc.diag2",
              $"qc.diag3",
              $"qc.diag4",
              $"qc.diag5",
              $"qc.diag6",
              $"qc.diag7",
              $"qc.diag8",
              $"qc.diag9",
              $"qc.diag10",
              coalesce($"qc.proc_srv",lit("0")).as("proc_srv"),
              coalesce($"qc.poa",lit("U")).as("poa"),
              $"qc.mod_n",
              $"qc.pay_dt",
              $"qc.tos_i_5",
              coalesce($"qc.pos_i",lit(0)).as("pos_i"),
              $"qc.prv_sp_4",
              $"qc.episode_id",
              coalesce($"qc.etg_id",lit(0)).as("etg_id"),
              coalesce($"qc.sev_level",lit(0)).as("sev_level"),
              coalesce($"qc.clm_id_n",lit("0")).as("clm_id_n"),
              coalesce($"qc.line_nat",lit("0")).as("line_nat"),
              $"qc.clm_type",
              $"qc.clm_exclude",
              when($"qc.proc_srv".isNull || $"qc.proc_srv" === lit("0"), lit("Unknown Proc Srv")).otherwise($"qc.proc_srv_desc").as("proc_srv_desc"),
              $"qc.product_id",
              $"qc.account_id",
              coalesce($"qc.at_risk_status_id",lit("Unspecified$UNK")).as("at_risk_status_id"),
              $"qc.mem_userdef_1_id",
              $"qc.mem_userdef_2_id",
              $"qc.cat_status",
              $"qc.cat_status_cost3",
              $"qc.sex",
              $"qc.age",
              $"qc.zip",
              $"qc.network_status",
              $"qc.cost1",
              $"qc.cost2",
              $"qc.cost3",
              $"qc.cost4",
              $"qc.cost5",
              $"qc.cost6",
              $"qc.encounter",
              $"qc.amt_req",
              $"qc.map_srce_n",
              $"qc.ia_time",
              coalesce($"qc.icd_version",lit(0)).as("icd_version"),
              $"qc.contract_id",
              $"qc.enc_k",
              $"qc.cost1_k",
              $"qc.cost2_k",
              $"qc.cost3_k",
              $"qc.cost4_k",
              $"qc.cost5_k",
              $"qc.cost6_k",
              $"qc.amt_req_k",
              $"qc.network_paid_status_id",
              $"qc.provider_status_id",
              $"qc.svc_grp",
              coalesce($"me.mem_userdef_4_id",lit("Unspecified$UNK")).as("mem_userdef_4_id"),
              coalesce($"men.coverage_status_id",lit("Unspecified$UNK")).as("coverage_status_id"),
              coalesce($"men.employee_type_id",lit("Unspecified$UNK")).as("employee_type_id"),
              coalesce($"sub.benefit_plan_id",lit("Unspecified$UNK")).as("benefit_plan_id")
          )
    }
}
