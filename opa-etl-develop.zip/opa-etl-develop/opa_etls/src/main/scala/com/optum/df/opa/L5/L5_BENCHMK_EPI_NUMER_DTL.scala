package com.optum.df.opa.L5

import com.optum.df.opa.models.L5.l5_benchmk_epi_numer_dtl
import com.optum.oap.sparkdataloader.{RuntimeVariables, UserDefinedFunctionForDataLoader}
import org.apache.spark.sql.types.{DecimalType, ShortType}
import org.apache.spark.sql.{DataFrame, SparkSession}


/**
  * Source query:
  * https://som-bb.humedica.net/projects/OAP/repos/oap-mstr-db-interface/browse/src/main/resources/src/build/L5/etl/OPA/L5_benchmk_epi_numer_dtl_insert.sql
  *
  * Redshift Schema: opa_util/src/main/resources/OPADDL/L5/tables/L5_BENCHMK_EPI_NUMER_DTL.sql
  */
object L5_BENCHMK_EPI_NUMER_DTL extends L5TableInfo[l5_benchmk_epi_numer_dtl] {
  override def name: String = "L5_BENCHMK_EPI_NUMER_DTL"

  override def dependsOn: Set[String] = Set("L2_BMK_EPI_NUM_DETAIL", "L2_II_MAP_ETG")

  def createDataFrameWithoutDDL(sparkSession: SparkSession, loadedDependencies: Map[String, DataFrame], udfMap: Map[String, UserDefinedFunctionForDataLoader], runtimeVariables: RuntimeVariables): DataFrame = {
    import org.apache.spark.sql.functions._
    import sparkSession.implicits._

    val l2BmkEpiNumDetail = loadedDependencies("L2_BMK_EPI_NUM_DETAIL")
    val l2IiMapEtg = loadedDependencies("L2_II_MAP_ETG")

    l2BmkEpiNumDetail.as("en")
      .join(l2IiMapEtg.as("me"), $"en.etg_id" === $"me.etg_id")
      .groupBy($"year", $"age_cat2", $"sex", $"cens_reg", $"en.etg_id", $"me.family".as("etg_family"), $"me.mpc".as("etg_mpc"), $"sev_level", $"tos1_id")
      .agg(
        round(sum($"amt_np"), 2).as("amt_np"),
        round(sum($"encounters"), 2).as("encounters"),
        lit("Y").as("dummy_email")
      )
      .select(
        $"year".cast(ShortType),
        $"age_cat2".cast(ShortType).as("age_cat2"),
        $"sex".cast(ShortType),
        $"cens_reg".cast(ShortType).as("cens_reg"),
        $"etg_id",
        $"etg_family",
        $"etg_mpc",
        $"sev_level",
        $"tos1_id",
        $"amt_np".cast(DecimalType(19, 2)).as("amt_np"),
        $"encounters".cast(DecimalType(19, 2)).as("encounters"),
        $"dummy_email"
      )
  }
}
