package com.optum.df.opa.L5

import com.optum.df.opa.models.L5.l5_dict_pct_band
import com.optum.oap.sparkdataloader.{RuntimeVariables, TableInfo, UserDefinedFunctionForDataLoader}
import org.apache.spark.sql.{DataFrame, SparkSession}

object L5_DICT_PCT_BAND extends L5TableInfo[l5_dict_pct_band]{
  override def name: String = "L5_DICT_PCT_BAND"

  override def dependsOn: Set[String] = Set.empty

  def createDataFrameWithoutDDL(sparkSession: SparkSession, loadedDependencies: Map[String, DataFrame], udfMap: Map[String, UserDefinedFunctionForDataLoader], runtimeVariables: RuntimeVariables): DataFrame = {
    import sparkSession.implicits._

        Seq(l5_dict_pct_band((-1).toShort, "Unknown", null, null),
          l5_dict_pct_band(0.toShort, "Less than 10%", 0.toShort, 9.toShort),
          l5_dict_pct_band(1.toShort, "10% to 19%", 10.toShort, 19.toShort),
          l5_dict_pct_band(2.toShort, "20% to 29%", 20.toShort, 29.toShort),
          l5_dict_pct_band(3.toShort, "30% to 39%", 30.toShort, 39.toShort),
          l5_dict_pct_band(4.toShort, "40% to 49%", 40.toShort, 49.toShort),
          l5_dict_pct_band(5.toShort, "50% to 59%", 50.toShort, 59.toShort),
          l5_dict_pct_band(6.toShort, "60% to 69%", 60.toShort, 69.toShort),
          l5_dict_pct_band(7.toShort, "70% to 79%", 70.toShort, 79.toShort),
          l5_dict_pct_band(8.toShort, "80% to 89%", 80.toShort, 89.toShort),
          l5_dict_pct_band(9.toShort, "90% or more", 90.toShort, 999.toShort))
          .toDF("pct_band_id", "pct_band_desc", "pct_band_min", "pct_band_max")
  }
}
