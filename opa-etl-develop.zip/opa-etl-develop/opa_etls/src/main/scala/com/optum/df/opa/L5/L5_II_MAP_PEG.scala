package com.optum.df.opa.L5

import com.optum.df.opa.models.L5.l5_ii_map_peg
import com.optum.oap.sparkdataloader.{RuntimeVariables, UserDefinedFunctionForDataLoader}
import org.apache.spark.sql.{DataFrame, SparkSession}
import org.apache.spark.sql.types.{ShortType}

object L5_II_MAP_PEG extends L5TableInfo[l5_ii_map_peg] {
  override def name: String = "L5_II_MAP_PEG"
  override def dependsOn: Set[String] = Set("L2_II_MAP_PEG")

  def createDataFrameWithoutDDL(sparkSession: SparkSession, loadedDependencies: Map[String, DataFrame], udfMap: Map[String, UserDefinedFunctionForDataLoader], runtimeVariables: RuntimeVariables): DataFrame = {
    import sparkSession.implicits._

    val l2IiMapPeg = loadedDependencies("L2_II_MAP_PEG")

    l2IiMapPeg
      .select($"peg_cat_desc",
        $"peg_cat_id",
        $"peg_ppc".cast(ShortType),
        $"sensitive_cat_id".cast(ShortType),
        $"sensitive_ind".cast(ShortType)
      )
  }
}
