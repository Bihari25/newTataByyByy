package com.optum.df.opa.L5

import com.optum.df.opa.models.L5.l5_ii_ocu_pop_phm_costs_pp
import com.optum.oap.sparkdataloader.{RuntimeVariables, UserDefinedFunctionForDataLoader}
import org.apache.spark.sql.functions._
import org.apache.spark.sql.types.ShortType
import org.apache.spark.sql.{DataFrame, SparkSession}


/**
  *
  * REDSHIFT Schema: opa-rep/src/main/resources/OPADDL/rep/L5/tables/L5_II_OCU_POP_PHM_COSTS_PP.sql IN opa_rep
  *
  */
object L5_II_OCU_POP_PHM_COSTS_PP extends L5TableInfo[l5_ii_ocu_pop_phm_costs_pp]{

  override def name: String = "L5_II_OCU_POP_PHM_COSTS_PP"

  override def dependsOn: Set[String] = Set("L2_II_OCU_POP_PHM_COSTS", "L2_II_MAP_TOS", "L4_MAP_TOS5_CUSTOM", "L2_II_MEM_ATTR", "L2_II_MAP_DATE_RANGE", "L2_II_MAP_ACCOUNT", "L2_II_MAP_AT_RISK_STATUS", "L2_II_MAP_CONTRACT", "L2_II_MAP_COUNTY", "L2_II_MAP_PRODUCT", "L2_II_PROVINFO", "L2_II_MAP_PROV_AFFIL")
  def createDataFrameWithoutDDL(sparkSession: SparkSession, loadedDependencies: Map[String, DataFrame], udfMap: Map[String, UserDefinedFunctionForDataLoader], runtimeVariables: RuntimeVariables): DataFrame = {
    import sparkSession.implicits._

    val l2IiOcuPopPhmCosts = loadedDependencies("L2_II_OCU_POP_PHM_COSTS")
    val l2IiMapTos = loadedDependencies("L2_II_MAP_TOS")
    val l4MapTos5Custom = loadedDependencies("L4_MAP_TOS5_CUSTOM")
    val l2IiMemAttr = loadedDependencies("L2_II_MEM_ATTR")
    val l2IiMapDateRange = loadedDependencies("L2_II_MAP_DATE_RANGE")
    val l2IiMapAccount = loadedDependencies("L2_II_MAP_ACCOUNT")
    val l2IiMapAtRiskStatus = loadedDependencies("L2_II_MAP_AT_RISK_STATUS")
    val l2IiMapContract = loadedDependencies("L2_II_MAP_CONTRACT")
    val l2IiMapCounty = loadedDependencies("L2_II_MAP_COUNTY")
    val l2IiMapProduct = loadedDependencies("L2_II_MAP_PRODUCT")
    val l2IiProvInfo = loadedDependencies("L2_II_PROVINFO")
    val l2IiMapProvAffil = loadedDependencies("L2_II_MAP_PROV_AFFIL")


    val tosCustomTemp = l2IiMapTos.as("mp")
      .join(broadcast(l4MapTos5Custom).as("ct"), $"ct.tos_i_5" === $"mp.tos_i_5", "left_outer")
      .select(
        $"mp.tos_i_5",
        $"mp.tos1_id",
        $"mp.tos2_id",
        $"mp.tos3_id",
        $"mp.tos_i_4",
        $"mp.tos_i_5",
        $"ct.tos_custom_id"
      )

    l2IiOcuPopPhmCosts.as("pc")
      .join(l2IiMemAttr.as("ma"), $"pc.mem_attr_id" === $"ma.member_attr_id", "left")
      .join(broadcast(tosCustomTemp).as("tc"), $"pc.tos_i_5" === $"tc.tos_i_5", "left")
      .join(broadcast(l2IiMapDateRange).as("mad"), $"pc.year_mth_id" === $"mad.year_mth_id", "left")
      .join(l2IiMapAccount.as("mac"), Seq("account_id"), "left")
      .join(broadcast(l2IiMapAtRiskStatus).as("mars"), $"ma.at_risk_status_id" === $"mars.at_risk_status_id", "left")
      .join(broadcast(l2IiMapContract).as("mcon"), $"ma.contract_id" === $"mcon.contract_id", "left")
      .join(broadcast(l2IiMapCounty).as("coun"), $"ma.county_id" === $"coun.county_id", "left")
      .join(broadcast(l2IiMapProduct).as("mapr"), $"ma.product_id" === $"mapr.product_id", "left")
      .join(l2IiProvInfo.as("pri"), $"pc.pres_prv_i" === $"pri.provider_id", "left")
      .join(l2IiMapProvAffil.as("mpaf"), $"pri.affil_id" === $"mpaf.affil_id", "left")
      .select(
        coalesce($"mac.account_lv1_id",$"mac.account_lv2_id", $"ma.account_id").as("account_lv1_id"),
        coalesce($"mac.account_lv2_id", $"ma.account_id").as("account_lv2_id"),
        $"ma.account_id",
        $"mars.at_risk_status_id",
        coalesce($"mars.at_risk_status_lv1_id", $"mars.at_risk_status_lv2_id", $"mars.at_risk_status_id").as("at_risk_status_lv1_id"),
        coalesce($"mars.at_risk_status_lv2_id", $"mars.at_risk_status_id").as("at_risk_status_lv2_id"),
        $"ma.cat_status_cost3",
        $"ma.cat_status",
        $"ma.contract_id",
        $"ma.contract_type_id",
        coalesce($"mcon.contract_lv1_id", $"mcon.contract_lv2_id", $"mcon.contract_id").as("contract_lv1_id"),
        when($"mcon.contract_lv2_id".isNull, $"mcon.contract_id").otherwise($"mcon.contract_lv2_id").as("contract_lv2_id"),
        $"ma.county_id",
        $"coun.cens_reg",
        $"coun.state",
        when($"ma.sex" === lit(true), 1).otherwise(lit(0)).cast(ShortType).as("sex"),
        $"pc.channel",
        $"ma.product_id",
        coalesce($"mpaf.prov_affil_lv1_id",lit("Unspecified LV1")).as("prov_affil_lv1_id"),
        coalesce($"mpaf.prov_affil_lv2_id",lit("Unspecified LV2")).as("prov_affil_lv2_id"),
        coalesce($"pri.affil_id",lit("Unspecified$UNK")).as("affil_id"),
        $"ma.coverage_status_id",
        $"ma.benefit_plan_id",
        $"ma.biz_segment_id",
        $"ma.age_cat2",
        $"ma.industry",
        $"ma.mem_userdef_1_id",
        $"ma.mem_userdef_2_id",
        $"ma.mem_userdef_3_id",
        $"ma.mem_userdef_4_id",
        $"pc.mem_attr_id",
        $"ma.mpg_def_id",
        coalesce($"pc.etg_id", lit(0)).as("etg_id"),
        $"pc.formulary",
        $"pc.gbo",
        $"pc.generic",
        $"mad.ia_time",
        $"pc.iatime_lag",
        when($"pc.lag_ind" === lit(true), 1).otherwise(lit(0)).cast(ShortType).as("lag_ind"),
        $"pc.lag_months",
        coalesce($"pc.ndc", lit("0")).as("ndc"),
        when($"pc.network_status" === lit(true), 1).otherwise(lit(0)).cast(ShortType).as("network_status"),
        coalesce($"pc.pcp_assign", lit("0")).as("pcp_assign"),
        coalesce($"pc.pcp_imp", lit("0")).as("pcp_imp"),
        $"pc.pres_prv_i",
        $"pc.script_gen",
        $"pc.script",
        $"pc.script_adj",
        coalesce($"pc.sev_level", lit(0)).as("sev_level"),
        $"pc.year_mth_id",
        $"pc.year_mth_pd",
        $"tc.tos1_id",
        $"tc.tos2_id",
        $"tc.tos3_id",
        $"tc.tos_i_4",
        $"tc.tos_i_5",
        $"tc.tos_custom_id",
        $"pc.amt_eqv_adj",
        $"pc.amt_liab",
        $"pc.amt_pay_adj",
        $"pc.amt_req",
        $"pc.cost1",
        $"pc.cost2",
        $"pc.cost3",
        $"pc.cost4",
        $"pc.cost5",
        $"pc.cost6",
        $"pc.days_sup",
        $"pc.encounter",
        $"ma.employee_type_id",
        $"ma.risk_type_id",
        when($"ma.den" === lit(true), 1).otherwise(lit(0)).cast(ShortType).as("den"),
        $"pc.pcp_affil_id",
        coalesce($"pc.daw", lit(0)).cast(ShortType).as("daw"),
        $"pc.spec_rx_n_id",
        $"pc.amt_cob",
        $"pc.amt_disp",
        $"pc.amt_ingr",
        $"pc.amt_not_covered",
        $"pc.amt_other_carrier_pay",
        $"pc.amt_admin_fee",
        $"pc.amt_sales_tax",
        coalesce($"pc.covid_flag".cast(ShortType), lit(-1.toShort)).as("covid_flag")
)
  }
}