package com.optum.df.opa.L5

import com.optum.df.opa.models.L5.l5_dict_condition
import com.optum.oap.sparkdataloader.{RuntimeVariables, UserDefinedFunctionForDataLoader}
import org.apache.spark.sql.types.ShortType
import org.apache.spark.sql.{DataFrame, SparkSession}


object L5_DICT_CONDITION extends L5TableInfo[l5_dict_condition] {
  override def name: String = "L5_DICT_CONDITION"

  override def dependsOn: Set[String] = Set("L4_DICT_CONDITION")
  def createDataFrameWithoutDDL(sparkSession: SparkSession, loadedDependencies: Map[String, DataFrame], udfMap: Map[String, UserDefinedFunctionForDataLoader], runtimeVariables: RuntimeVariables): DataFrame = {
    import sparkSession.implicits._

    val l4DictCondition = loadedDependencies("L4_DICT_CONDITION")

    l4DictCondition
      .select(
        $"condition_id",
        $"condition_set_name",
        $"condition_desc",
        $"chronic_ind".cast(ShortType),
        $"sensitive_ind".cast(ShortType),
        $"active_ind".cast(ShortType),
        $"inferred_months"
    )
  }
}