package com.optum.df.opa.L5

import com.optum.df.opa.models.L5.l5_dict_data_source
import com.optum.oap.sparkdataloader.{RuntimeVariables, UserDefinedFunctionForDataLoader}
import org.apache.spark.sql.{DataFrame, SparkSession}


object L5_DICT_DATA_SOURCE extends L5TableInfo[l5_dict_data_source] {
  override def name: String = "L5_DICT_DATA_SOURCE"

  override def dependsOn: Set[String] = Set("L2_MAP_CDS_FLG")

  def createDataFrameWithoutDDL(sparkSession: SparkSession, loadedDependencies: Map[String, DataFrame], udfMap: Map[String, UserDefinedFunctionForDataLoader], runtimeVariables: RuntimeVariables): DataFrame = {
    import sparkSession.implicits._

    val l2MapCdsFlg = loadedDependencies("L2_MAP_CDS_FLG")

    l2MapCdsFlg.as("mcf")
      .select(
          $"mcf.client_ds_id",
          $"mcf.client_ds_name"
      ).distinct()
  }
}