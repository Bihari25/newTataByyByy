package com.optum.df.opa.L5

import com.optum.df.opa.models.L5.l5_dict_score_qual
import com.optum.oap.sparkdataloader.{RuntimeVariables, UserDefinedFunctionForDataLoader}
import org.apache.spark.sql.functions.lit
import org.apache.spark.sql.{DataFrame, SparkSession}


class L5_DICT_SCORE_QUAL(val tableName: String, val scoreFamilyName: String) extends L5TableInfo[l5_dict_score_qual] {
  override def name: String = tableName

  override def dependsOn: Set[String] = Set("L4_MAP_SCORE_QUAL", "L4_DICT_SCORE_QUAL", "L4_DICT_SCORE", "L4_DICT_SCORE_FAMILY")

  def createDataFrameWithoutDDL(sparkSession: SparkSession, loadedDependencies: Map[String, DataFrame], udfMap: Map[String, UserDefinedFunctionForDataLoader], runtimeVariables: RuntimeVariables): DataFrame = {
    import sparkSession.implicits._

    val l4MapScoreQual = loadedDependencies("L4_MAP_SCORE_QUAL")
    val l4DictScore = loadedDependencies("L4_DICT_SCORE")
    val l4DictScoreFamily = loadedDependencies("L4_DICT_SCORE_FAMILY")
    val l4DictScoreQual = loadedDependencies("L4_DICT_SCORE_QUAL")

    l4DictScoreQual.as("dsq")
      .join(l4MapScoreQual.as("msq"), $"dsq.score_qual_id" === $"msq.score_qual_id", "inner")
      .join(l4DictScore.as("ds"), $"ds.score_id" === $"msq.score_id", "inner")
      .join(l4DictScoreFamily.as("dsf"), $"ds.score_family_id" === $"dsf.score_family_id", "inner")
      .where($"dsf.score_family_name" === lit(scoreFamilyName))
      .select(
        $"dsq.score_qual_id".as("score_qual_id"),
        $"dsq.score_qual_name".as("score_qual_name"),
        $"dsq.score_qual_desc".as("score_qual_desc")
      ).distinct()
  }
}

object L5_DICT_SCORE_QUAL_SDOH extends L5_DICT_SCORE_QUAL("L5_DICT_SCORE_QUAL_SDOH", "SDOH")