"""
Drop staging schema(if exists), create l2-l5 entities in staging schema,
load data into staging schema, swap staging schema with reporting schema
"""

import time
import argparse
import os
import glob
from pathlib import Path
from collections import defaultdict
import logging
import redshift_database_setup_utility
import logging_utils as logutils


logger_name = os.path.splitext(os.path.basename(__file__))[0]
logger = logging.getLogger(logger_name)
logger.setLevel(logging.INFO)
db_utils = redshift_database_setup_utility.RedshiftDatabaseSetupUtility(logger)


def swap_staging_with_reporting_schema(staging_schema, target_schema):
    logger.info(f"Renaming {target_schema} schema to {target_schema}_old")
    db_utils.rename_schema(target_schema, target_schema + '_old')
    logger.info(f"Renaming {staging_schema} schema to {target_schema}")
    db_utils.rename_schema(staging_schema, target_schema)


def execute_copy_commands(bucket, file_prefix, iam_role, schema):
    tables_list = db_utils.get_all_tables_in_a_given_schema(schema)
    logger.info(f"Executing copy command for {len(tables_list)} tables present in {schema} schema")
    counter = 0
    for table in tables_list:
        counter += 1
        logger.info(f"Loading table {str(table).upper()} ({counter}/{len(tables_list)})")
        db_utils.execute_copy_command(str(table).upper(), bucket, file_prefix, iam_role, schema)
    logger.info(f"Copy command executed successfully for all the tables present in {schema} schema")


def create_l2_to_l5_tables(schema, ddl_base_path):
    l2_to_l4_tables_ddl_list = glob.glob(f'{ddl_base_path}/L234/*.sql', recursive=True)
    l5_tables_ddl_list = glob.glob(f'{ddl_base_path}/L5/tables/*.sql', recursive=True)
    logger.info(f"Creating L2 - L5 tables for {schema} schema")
    logger.info(f"Total no of sql files in l2_to_l4_tables_ddl_list: {len(l2_to_l4_tables_ddl_list)}")
    db_utils.execute_ddl(l2_to_l4_tables_ddl_list, schema)
    logger.info(f"Total no of sql files in l5_tables_ddl_list: {len(l5_tables_ddl_list)}")
    db_utils.execute_ddl(l5_tables_ddl_list, schema)
    logger.info(f"Created L2 - L5 tables for {schema} schema")


def create_views(schema, ddl_base_path):
    l5_views_list = glob.glob(f'{ddl_base_path}/L5/views/*.sql', recursive=True)
    logger.info(f"Creating views in {schema} schema")
    logger.info(f"Total no of sql files in l5_views_list: {len(l5_views_list)}")
    db_utils.execute_ddl(sorted(l5_views_list, key=lambda file_name: os.path.splitext(os.path.basename(file_name))[0]),
                         schema)
    logger.info(f"Created views in {schema} schema")


def create_base_entities(ddl_base_path, staging_schema, target_schema):
    # Drop and create staging schema
    db_utils.drop_schema(staging_schema)
    db_utils.create_schema(staging_schema)

    # Create reporting schema if not exists
    db_utils.create_schema(target_schema)

    create_l2_to_l5_tables(staging_schema, ddl_base_path + '/' + target_schema)


def drop_schema(schemas_to_be_dropped):
    logger.info(f"Dropping old schemas")
    db_utils.drop_schema(schemas_to_be_dropped)


def create_and_load_target_tables(db_conn, args, table_info):
    db_conn.autocommit = False  # setting to false to execute a transaction
    try:
        for i in range(0, len(table_info["table_name"])):
            # declaring variables for readability
            table_name = table_info['table_name'][i]
            schema_name = table_info['schema_name'][i]
            file_path = table_info['file_path'][i]

            logger.info(f"loading table {table_name}")

            # Drop table if already exists
            db_utils.drop_table_if_exists(table_name, schema_name)

            # create table
            db_utils.execute_ddl(file_path.split(), schema_name)

            # load table
            db_utils.execute_copy_command(table_name.upper(), args.bucket, args.file_prefix,
                                                            args.iam_role, schema_name)

        db_conn.commit()

    except Exception as e:
        db_conn.rollback()
        raise e

    finally:
        db_conn.autocommit = True


def refresh_target_tables(args, db_conn, target_tables, target_schema, eoadw_target_schema):
    table_info = defaultdict(list)
    for target_table in target_tables:
        for path in Path(args.ddl_base_path).rglob(f"{target_table.upper()}.sql"):
            table_info['file_path'].append(str(path))
            table_info['schema_name'].append(eoadw_target_schema if eoadw_target_schema in str(path) else target_schema)
            table_info['table_name'].append(target_table)
            break

        if target_table not in table_info['table_name']:
            logger.error(f"Unable to find DDL for target table {target_table}")
            raise RuntimeError(f"Unable to find DDL for target table {target_table}")

    create_and_load_target_tables(db_conn, args, table_info)
    create_views(target_schema, args.ddl_base_path + '/' + target_schema)
    create_views(eoadw_target_schema, args.ddl_base_path + '/' + eoadw_target_schema)


def main():
    parser = argparse.ArgumentParser(
        description="Creates l2-l5 entities, load data into staging schema & swap with rep schema")
    try:
        parser.add_argument('--host_name', type=str, help='redshift instance host name', required=True)
        parser.add_argument('--db_name', type=str, help='database name in which data needs to be loaded', required=True)
        parser.add_argument('--port', type=int, help='port in which database needs to be connected', required=True)
        parser.add_argument('--user_name', type=str, help='user name to connect redshift', required=True)
        parser.add_argument('--bucket', type=str, help='s3 bucket name in which the parquet files are uploaded',
                            required=True)
        parser.add_argument('--file_prefix', type=str, help='expected prefix for the parquet files', required=True)
        parser.add_argument('--iam_role', type=str, help='iam_role to execute copy commands', required=True)
        parser.add_argument('--ddl_base_path', type=str, help='Base path for ddl files', required=True)
        parser.add_argument('--mstr_db_user_name', type=str, help='mstr db user to connect redshift')
        parser.add_argument('--dataload_type', type=str, help='monthly dataload or daily dataload', required=True)
        parser.add_argument('--target_tables', type=str, help='list of tables to load into redshift', required=False)

        logutils.add_correlation_args(parser)
        args, unknown = parser.parse_known_args()
        logutils.add_handler(logger, args)

        start_time = time.time()

        if not args.mstr_db_user_name:
            args.mstr_db_user_name = args.db_name + '_user'
        db_name = args.db_name.lower()
        client_id = db_name.split('_')[0]
        expected_s3_prefix = db_name + '/' + db_name + '_'
        logger.info(f'Expected S3 prefix formed using db name: {expected_s3_prefix}')

        if not args.file_prefix.lower().startswith(expected_s3_prefix):
            logger.error(f"ClientId {client_id} in db name does not match with the clientId in s3 file prefix {args.file_prefix}. Please verify!")
            raise RuntimeError(f"ClientId {client_id} in db name does not match with the clientId in s3 file prefix {args.file_prefix}. Please verify!")

        # Create Database Connection
        db_utils.create_db_connection(args)

        staging_schema = 'staging'
        target_schema = 'rep'
        current_session_search_path = 'daily_staging,staging,rw'
        group_name = f'{client_id}_opa_developers'

        eoadw_staging_schema = 'daily_staging'
        eoadw_target_schema = 'daily_rep'
        eoadw_current_session_search_path = 'daily_staging,rep,rw'
        logger.info(f"Redshift data load started for clientId: {client_id}")

        if args.target_tables:
            target_tables = "".join(args.target_tables.split()).lower().split(",")
            refresh_target_tables(args, db_utils.db_conn, target_tables, target_schema, eoadw_target_schema)

        else:
            # Refresh monthly and EOADW (daily) data
            if (args.dataload_type == 'monthly'):
                # Create monthly and daily entities
                create_base_entities(args.ddl_base_path, staging_schema, target_schema)
                create_base_entities(args.ddl_base_path, eoadw_staging_schema, eoadw_target_schema)

                # Create monthly and daily views
                db_utils.change_search_path(current_session_search_path)
                create_views(staging_schema, args.ddl_base_path + '/' + target_schema)
                create_views(eoadw_staging_schema, args.ddl_base_path + '/' + eoadw_target_schema)

                # Load data in staging and daily_staging schema
                execute_copy_commands(args.bucket, args.file_prefix, args.iam_role, staging_schema)
                execute_copy_commands(args.bucket, args.file_prefix, args.iam_role, eoadw_staging_schema)

                # Swap staging schemas with reporting schemas
                swap_staging_with_reporting_schema(staging_schema, target_schema)
                swap_staging_with_reporting_schema(eoadw_staging_schema, eoadw_target_schema)

            # Refresh EOADW (daily) data
            else:
                create_base_entities(args.ddl_base_path, eoadw_staging_schema, eoadw_target_schema)
                db_utils.change_search_path(eoadw_current_session_search_path)
                create_views(eoadw_staging_schema, args.ddl_base_path + '/' + eoadw_target_schema)
                execute_copy_commands(args.bucket, args.file_prefix, args.iam_role, eoadw_staging_schema)
                swap_staging_with_reporting_schema(eoadw_staging_schema, eoadw_target_schema)

        schemas_used_in_mstr = 'rep, daily_rep, rw'

        logger.info(f'Grant privileges for mstr db user:{args.mstr_db_user_name}')
        db_utils.grant_privileges_to_mstr_db_user(schemas_used_in_mstr, args.mstr_db_user_name,
                                                                client_id)

        # Create group if not exist and Grant privileges to user_group
        logger.info(f'Create group {group_name} if not exists and Grant privileges on schemas {schemas_used_in_mstr} for group')
        db_utils.create_and_grant_privileges_to_group(schemas_used_in_mstr, group_name)

        schemas_to_be_dropped = 'rep_old, daily_rep_old'
        drop_schema(schemas_to_be_dropped)

        elapsed_time = int(time.time() - start_time)
        logger.info(f"Redshift data load completed for clientId: {client_id}. Total elapsed time: %d hrs %d mins %d secs" % (
            elapsed_time / 3600, elapsed_time % 3600 / 60, elapsed_time % 60))
    except Exception as e:
        logger.exception(e)
        raise e


if __name__ == '__main__':
    main()
