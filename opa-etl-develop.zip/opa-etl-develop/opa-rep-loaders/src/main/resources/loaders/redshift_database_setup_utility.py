"""
Database related utility functions used to set up /load data into redshift
"""
import re
from string import Template

import boto3
import psycopg2
import time


class RedshiftDatabaseSetupUtility:
    db_conn = None

    def __init__(self, logger):
        self.logger = logger

    def create_db_connection(self, args):
        if self.db_conn is not None:
            self.logger.info(f"Closing the existing connection.")
            self.db_conn.close()

        # Infer region from redshift host name
        aws_region = args.region if hasattr(args, "region") else self.get_aws_region(args.host_name)
        cluster_identifier = args.db_cluster if hasattr(args, "db_cluster") else args.host_name.split('.')[0]
        cluster_credentials = self.get_cluster_credentials(args.user_name, cluster_identifier, aws_region)

        # Connect to database in redshift specified by the user
        self.logger.info(f'Connecting to {args.db_name} database.')
        self.set_db_connection_handle(args.host_name, args.db_name, args.port,
                                      cluster_credentials['DbUser'], cluster_credentials['DbPassword'])
        self.logger.info(f'Connection to {args.db_name} database established.')

    def create_schema(self, schema_name):
        CREATE_SCHEMA_QUERY = "CREATE SCHEMA IF NOT EXISTS $schema_name;"
        with self.db_conn.cursor() as cursor:
            cursor.execute(Template(CREATE_SCHEMA_QUERY).substitute(schema_name=schema_name))

    def drop_schema(self, schema_name):
        DROP_SCHEMA_QUERY = "DROP SCHEMA IF EXISTS $schema_name CASCADE;"
        with self.db_conn.cursor() as cursor:
            cursor.execute(Template(DROP_SCHEMA_QUERY).substitute(schema_name=schema_name))

    def rename_schema(self, source_schema, destination_schema):
        RENAME_SCHEMA_QUERY = "ALTER SCHEMA $source_schema RENAME TO $destination_schema"
        with self.db_conn.cursor() as cursor:
            cursor.execute(
                Template(RENAME_SCHEMA_QUERY).substitute(source_schema=source_schema,
                                                         destination_schema=destination_schema))

    def change_search_path(self, schema_name):
        UPDATE_SEARCH_PATH_QUERY = "SET search_path to $schema_name;"
        with self.db_conn.cursor() as cursor:
            cursor.execute(Template(UPDATE_SEARCH_PATH_QUERY).substitute(schema_name=schema_name))

    def get_all_tables_in_a_given_schema(self, schema_name):
        RETRIEVE_TABLE_LIST_QUERY = """SELECT DISTINCT tablename FROM pg_tables
                                    WHERE schemaname = '$schema_name'
                                    ORDER BY 1;"""
        with self.db_conn.cursor() as cursor:
            cursor.execute(Template(RETRIEVE_TABLE_LIST_QUERY).substitute(schema_name=schema_name))
            tables_list = [val[0] for val in cursor.fetchall()]

        return tables_list

    def execute_copy_command(self, table_name, bucket, file_prefix, iam_role, schema):
        GET_COPY_COMMAND_LOG = "SELECT MESSAGE FROM svl_s3log WHERE query = pg_last_copy_id();"
        GET_COPY_COMMAND_ROW_COUNT = "SELECT pg_last_copy_count();"
        COPY_COMMAND_QUERY = """COPY $table_name
                              FROM 's3://$bucket/$file_prefix/$table_name/'
                              IAM_ROLE '$iam_role' FORMAT AS PARQUET;"""

        with self.db_conn.cursor() as cursor:
            copy_command = Template(COPY_COMMAND_QUERY).substitute(table_name=table_name,
                                                                   bucket=bucket, file_prefix=file_prefix,
                                                                   iam_role=iam_role)
            start_time = time.time()
            cursor.execute(copy_command)
            cursor.execute(GET_COPY_COMMAND_LOG)
            result = cursor.fetchone()

            if result is not None and "It is either empty or not properly configured in the external catalog" in result[0]:
                raise Exception(f"Invalid S3 file path for {table_name}, path : s3://{bucket}/{file_prefix}/{table_name}/. Data load will not continue. ")

            cursor.execute(GET_COPY_COMMAND_ROW_COUNT)
            row_count = cursor.fetchone()[0]
            elapsed_time = int(time.time() - start_time)
            self.logger.info(f"Schema: {schema}, Table: {table_name} loaded successfully via COPY command. \n"
                             f"Stats: Row Count: {row_count}, Elapsed Time: %d mins %d secs" % (elapsed_time / 60, elapsed_time % 60))

    def grant_privileges_to_mstr_db_user(self, schemas, mstr_db_user_name, client_id):
        CHECK_USER_EXISTS = "SELECT 1 FROM pg_user WHERE usename = '$user_name' AND usesysid > 1;"
        GRANT_ALL_PRIVILEGES_QUERY = "GRANT ALL ON SCHEMA $schemas TO $user"
        GRANT_SELECT_PRIVILEGES_QUERY = "GRANT SELECT ON ALL TABLES IN SCHEMA $schemas TO $user"
        deidentified_client_id = 'h000166'
        with self.db_conn.cursor() as cursor:
            cursor.execute(Template(CHECK_USER_EXISTS).substitute(user_name=mstr_db_user_name))
            result = cursor.fetchone()
            if client_id != deidentified_client_id or result is not None:
                cursor.execute(Template(GRANT_ALL_PRIVILEGES_QUERY).substitute(user=mstr_db_user_name, schemas=schemas))
                cursor.execute(
                    Template(GRANT_SELECT_PRIVILEGES_QUERY).substitute(user=mstr_db_user_name, schemas=schemas))
            else:
                self.logger.info(f"{mstr_db_user_name} user does not exist")

    # Create client specific group if not exist and Grant privileges to all the tables in necessary schemas to
    # user_group in dev environment only.
    def create_and_grant_privileges_to_group(self, schemas, group_name):
        CREATE_GROUP_QUERY = "CREATE GROUP $group_name"
        CHECK_GROUP_EXISTS = "SELECT 1 FROM pg_group WHERE groname = '$group_name';"
        GRANT_USAGE_PRIVILEGE_TO_GROUP = "GRANT USAGE ON SCHEMA $schemas TO GROUP $user_group;"
        GRANT_SELECT_PRIVILEGE_TO_GROUP = "GRANT SELECT ON ALL TABLES IN SCHEMA $schemas TO GROUP $user_group;"
        with self.db_conn.cursor() as cursor:
            cursor.execute(Template(CHECK_GROUP_EXISTS).substitute(group_name=group_name))
            result = cursor.fetchone()
            if result is None:
                self.logger.info(f"Creating group {group_name}")
                cursor.execute(Template(CREATE_GROUP_QUERY).substitute(group_name=group_name))
            self.logger.info(f"Granting privileges to user group {group_name}")
            cursor.execute(Template(GRANT_USAGE_PRIVILEGE_TO_GROUP).substitute(user_group=group_name, schemas=schemas))
            cursor.execute(Template(GRANT_SELECT_PRIVILEGE_TO_GROUP).substitute(user_group=group_name, schemas=schemas))

    def drop_table_if_exists(self, table_name, schema_name):
        DROP_TABLE = "DROP TABLE IF EXISTS ${schema_name}.${table_name} CASCADE"
        with self.db_conn.cursor() as cursor:
            cursor.execute(Template(DROP_TABLE).substitute(table_name=table_name, schema_name=schema_name))

    @staticmethod
    def get_cluster_credentials(db_user, cluster_identifier, aws_region):
        client = boto3.client('redshift', region_name=aws_region)
        cluster_credentials = client.get_cluster_credentials(DbUser=db_user, ClusterIdentifier=cluster_identifier)
        return cluster_credentials

    def set_db_connection_handle(self, host, database, port, user_name, password):
        self.db_conn = psycopg2.connect(
            host=host,
            port=port,
            database=database,
            user=user_name,
            password=password,
            sslmode='require'
        )
        self.db_conn.autocommit = True

    @staticmethod
    def get_aws_region(redshift_host):
        match = re.search("(\.)(?P<region>us-(east|west)-[1-2]{1})(\.)", redshift_host, re.IGNORECASE)
        if match:
            aws_region = match.group("region")
        else:
            raise Exception(f"Cannot infer aws region from redshift host: {redshift_host}. Please verify.")

        return aws_region

    def execute_ddl(self, list_of_files, schema_name):
        with self.db_conn.cursor() as cursor:
            replace_pattern = re.compile('{schemaname}', re.IGNORECASE)
            for file in list_of_files:
                with open(file, 'r') as fh:
                    lines = replace_pattern.sub(schema_name, fh.read())
                cursor.execute(lines)

    def execute_sql(self, query, args=None):
        with self.db_conn.cursor() as cursor:
            cursor.execute(query, args)
            return cursor.fetchall()

    def __del__(self):
        if (self.db_conn is not None):
            self.db_conn.close()
            self.logger.info(f'Database connection closed.')
