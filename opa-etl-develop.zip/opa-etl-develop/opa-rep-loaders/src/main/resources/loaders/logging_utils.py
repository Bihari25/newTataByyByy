# pylint: disable=import-error
import argparse
import logging
import sys

from pythonjsonlogger import jsonlogger


class CorrelationFilter(logging.Filter):
    def __init__(self, args):
        # call super with empty string which allows all events in
        super().__init__("")
        self.function_arn = args.function_arn
        self.aws_request_id = args.aws_request_id
        self.client_id = args.client_id
        self.env_id = args.env_id
        self.execution_id = args.execution_id
        self.correlation_id = args.correlation_id

    def filter(self, record):
        record.function_arn = self.standardize(self.function_arn)
        record.aws_request_id = self.standardize(self.aws_request_id)
        record.client_id = self.standardize(self.client_id)
        record.env_id = self.standardize(self.env_id)
        record.execution_id = self.standardize(self.execution_id)
        record.correlation_id = self.standardize(self.correlation_id)

        return True

    def standardize(self, value):
        return None if not value else value


def add_handler(logger, args):
    # NOTE: if we're running "ci" tests, don't make any changes to logging
    if "ci" in logging.root.manager.loggerDict:
        return

    custom_handler = logging.StreamHandler(sys.stdout)
    formatter = jsonlogger.JsonFormatter(
        fmt="asctime=%(asctime)s levelname=%(levelname)s client_id=%(client_id)s env_id=%(env_id)s function_arn=%(function_arn)s aws_request_id=%(aws_request_id)s execution_id=%(execution_id)s correlation_id=%(correlation_id)s name=%(name)s\n%(message)s"
    )
    custom_handler.setFormatter(formatter)
    logger.addHandler(custom_handler)

    # also add our own filter so we get access to execution/correlation id's to log
    filter = CorrelationFilter(args)
    logger.addFilter(filter)


def add_correlation_args(parser):
    parser.add_argument(
        "--function_arn",
        type=str,
        help="ARN of lambda function calling this script",
        required=False,
        default="",
    )
    parser.add_argument(
        "--aws_request_id",
        type=str,
        help="AWS request id of lambda function calling this script",
        required=False,
        default="",
    )
    parser.add_argument(
        "--client_id",
        type=str,
        help="Client id if available",
        required=False,
        default="",
    )
    parser.add_argument(
        "--env_id",
        type=str,
        help="MSTR environment id if available",
        required=False,
        default="",
    )
    parser.add_argument(
        "--execution_id",
        type=str,
        help="Execution id of SFN calling this script via lambda",
        required=False,
        default="",
    )
    parser.add_argument(
        "--correlation_id",
        type=str,
        help="Correlation id of SFN calling this script via lambda",
        required=False,
        default="",
    )
