### integration test for redshift_dataloader - can be run locally if you have creds for right AWS role
## TODO: integrate into CI build
##

import os
import pytest
import sys
from unittest.mock import patch

from botocore.exceptions import ClientError

currentdir = os.path.dirname(os.path.realpath(__file__))
parentdir = os.path.dirname(currentdir)
sys.path.append(parentdir + "/main/resources/loaders")

import redshift_dataloader

def test_fail_wrong_client():
    testargs = [
        "redshift_dataloader",
        "--host_name", "opadevredshift-1-redshift-cluster.clxtymtfekvn.us-east-1.redshift.amazonaws.com", 
        # TODO: setup/tear down unique DB
        "--db_name", "h000166", 
        "--port", "5439",
        "--user_name", "test",
        "--bucket", "760182235631-opa-client-data",
        "--file_prefix", "unit/unit_fake_prefix", # don't load any actual data so test is fast
        "--iam_role", "arn:aws:iam::760182235631:role/redshift-service-access-role",
        "--ddl_base_path", "./OPADDL",
        "--dataload_type", "monthly"
    ]
    with patch.object(sys, 'argv', testargs):
        with pytest.raises(Exception):
            redshift_dataloader.main()

def test_main():
    testargs = [
        "redshift_dataloader",
        "--host_name", "opadevredshift-1-redshift-cluster.clxtymtfekvn.us-east-1.redshift.amazonaws.com", 
        # TODO: setup/tear down unique DB
        "--db_name", "unit_test", 
        "--port", "5439",
        "--user_name", "test",
        "--bucket", "760182235631-opa-client-data",
        "--file_prefix", "unit/unit_fake_prefix", # don't load any actual data so test is fast
        "--iam_role", "arn:aws:iam::760182235631:role/redshift-service-access-role",
        "--ddl_base_path", "./OPADDL", # fake DDL folder with no tables so it runs fast
        "--dataload_type", "daily" 
    ]
    with patch.object(sys, 'argv', testargs):
        redshift_dataloader.main()
        # TODO: assert that tables are correctly created; don't care about actual data here, focus on process

def test_task_token():
    testargs = [
        "redshift_dataloader",
        "--host_name", "opadevredshift-1-redshift-cluster.clxtymtfekvn.us-east-1.redshift.amazonaws.com", 
        # TODO: setup/tear down unique DB
        "--db_name", "unit_test", 
        "--port", "5439",
        "--user_name", "test",
        "--bucket", "760182235631-opa-client-data",
        "--file_prefix", "unit/unit_fake_prefix", # don't load any actual data so test is fast
        "--iam_role", "arn:aws:iam::760182235631:role/redshift-service-access-role",
        "--ddl_base_path", "./OPADDL",# fake DDL folder with no tables so it runs fast
        "--dataload_type", "daily",
        "--task-token", "zxcvzxcv" # junk
    ]
    with patch.object(sys, 'argv', testargs):
        with pytest.raises(ClientError) as e:
            redshift_dataloader.main()
            assert e.response['Error']['Code'] == 'InvalidToken' # at least reached point of success