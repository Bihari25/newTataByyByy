package com.optum.spark
import org.junit.Test
import org.scalatest.Assertions

import scala.collection.mutable

class StackSuiteTest extends Assertions {

  @Test def stackShouldPopValuesIinLastInFirstOutOrder() {
    val stack = new mutable.ArrayStack[Int]
    stack.push(1)
    stack.push(2)
    assert(stack.pop() === 2)
    assert(stack.pop() === 1)
  }

}
