package com.optum.spark

object Logger {
  @transient lazy val log = org.apache.log4j.LogManager.getLogger("CDWProcessLogger")
}
