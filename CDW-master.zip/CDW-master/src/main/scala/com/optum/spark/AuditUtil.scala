package com.optum.spark

import java.sql.{Connection, DriverManager}
import java.util.Properties

import org.apache.spark.sql.SparkSession

import scala.io.Source

object AuditUtil {
  val url = getClass.getResource("/source.properties")
  val properties: Properties = new Properties()
  val source = Source.fromURL(url)
  properties.load(source.bufferedReader())
  
  val connection: Connection =  DriverManager.getConnection(properties.getProperty("azureUrl"), properties.getProperty("azureUser"), properties.getProperty("azurePassword"))
  val statement = connection.createStatement()
  
  val spark = DriverClass.spark
  
  def CheckFileType(FileImportId: Int, LoadType: String,ZipFileName:String): Unit ={
    val df1=Sources.Raw_M25SUM(ZipFileName)
    df1.createOrReplaceGlobalTempView("RAW_M25SUM")
    val FileType=spark.sql("SELECT CASE RTRIM(LTRIM(DataorComment)) \n\t\t\tWHEN 'T' THEN 'F'\n\t\t\tWHEN 'U' THEN 'I'\n\t\t    ELSE RTRIM(LTRIM(DataorComment)) END \nFROM\tglobal_temp.RAW_M25SUM \nWHERE\tRecordType = 'CFT' AND \n\t\tSequenceNumber = '020' AND\n\t\tFileImportID  = '"+FileImportId+"'").head.get(0)
    var IsMatch=0
    if(FileType==LoadType)
    {
      IsMatch=1
    }
    val q1="UPDATE\t"+"medispan.Audit_Medispan_Load_History"+" SET IsTypeMatched = "+IsMatch+",\nLoadType = '"+LoadType+"'\nWHERE\tFileImportID = '"+FileImportId+"'"

    val rs1=statement.executeUpdate(q1)
  }
  def CheckProductIssue(FileImportID: Int, LoadType: String): Unit ={
    println(FileImportID)
    val stmt=connection.createStatement()
    val q11="SELECT VolumeNo,SupplementNo FROM "+"medispan.Audit_Medispan_Load_History"+" WHERE FileImportID = "+FileImportID
    println(q11)
    val rs11=stmt.executeQuery(q11)
    println(rs11)
    var CurrentIssueVolumeNo=0
    var CurrentSupplementNo=0
    while(rs11.next()){
      CurrentIssueVolumeNo=rs11.getInt(1)
      CurrentSupplementNo=rs11.getInt(2)}

    val q2="SELECT  VolumeNo \n\t\tFROM\t"+"medispan.Audit_Medispan_Load_History"+" WHERE FileImportID = (SELECT MAX(FileImportID) FROM medispan.Audit_Medispan_Load_History WHERE FileImportID < "+FileImportID+" AND   IsDeleted = 0  )"
    val rs2=stmt.executeQuery(q2)
    var PreviousIssueVolumeNo=0
    while(rs2.next()) {
      PreviousIssueVolumeNo = rs2.getInt(1)
    }
    var IssueCheckCode=0
    if(CurrentIssueVolumeNo==PreviousIssueVolumeNo & CurrentSupplementNo==0)
    {
      IssueCheckCode=1
    }
    else if(CurrentIssueVolumeNo-1!=PreviousIssueVolumeNo){
      IssueCheckCode=2
    }
    println(IssueCheckCode)
    val q3="UPDATE "+"medispan.Audit_Medispan_Load_History"+" SET IssueCheckCode = "+IssueCheckCode+" WHERE\tFileImportID  = '"+FileImportID+"'"
    val rs3=stmt.executeUpdate(q3)
  }

  def CheckRawBalance(FileImportID: Int): Unit = {
    val q21="SELECT CASE WHEN M25Num - ISNULL(M25RawNum, 0) = 0 THEN 1 ELSE 0 END, CASE WHEN M25VALNum - ISNULL(M25VALRawNum, 0) = 0 THEN 1 ELSE 0 END,  CASE WHEN M25DICTNum - ISNULL(M25DICTRawNum, 0) = 0 THEN 1 ELSE 0 END, CASE WHEN M25GPPCNum - ISNULL(M25GPPCRawNum, 0) = 0 THEN 1 ELSE 0 END,  CASE WHEN M25GPRRNum - ISNULL(M25GPRRRawNum, 0) = 0 THEN 1 ELSE 0 END,CASE WHEN M25TCRFNum - ISNULL(M25TCRFRawNum,0) = 0 THEN 1 ELSE 0 END, CASE WHEN M25MODNum - ISNULL(M25MODRawNum, 0) = 0 THEN 1 ELSE 0 END, CASE WHEN M25NMODNum - ISNULL(M25NMODRawNum, 0) = 0 THEN 1 ELSE 0 END FROM "+"medispan.Audit_Medispan_Load_History"+" WHERE\tFileImportID ="+ FileImportID
    val rs21=statement.executeQuery(q21)
    var IsM25Balance =0
    var IsM25VALBalance =0
    var IsM25DICTBalance=0
    var IsM25GPPCBalance=0
    var IsM25GPRRBalance=0
    var IsM25TCRFBalance=0
    var IsM25MODBalance=0
    var IsM25NMODBalance=0
    while(rs21.next())
    {
      IsM25Balance =rs21.getInt(1)
      IsM25VALBalance =rs21.getInt(2)
      IsM25DICTBalance=rs21.getInt(3)
      IsM25GPPCBalance=rs21.getInt(4)
      IsM25GPRRBalance=rs21.getInt(5)
      IsM25TCRFBalance=rs21.getInt(6)
      IsM25MODBalance=rs21.getInt(7)
      IsM25NMODBalance=rs21.getInt(8)
    }
    var IsBalance=0
    if( IsM25Balance *  IsM25VALBalance *  IsM25DICTBalance  *  IsM25GPPCBalance * IsM25GPRRBalance *  IsM25TCRFBalance *  IsM25MODBalance *  IsM25NMODBalance ==1){
      IsBalance=1
    }

    val q22="UPDATE\t"+"medispan.Audit_Medispan_Load_History"+" SET IsBalanced = "+IsBalance+"\nWHERE\tFileImportID="+FileImportID
    val rs22=statement.executeUpdate(q22)
  }

  def RecordLoadedRowCount(FileImportID: Int, FileType: String, RecordCount: Int): Unit ={

    if(FileType=="M25"){
      val q="UPDATE "+"medispan.Audit_Medispan_Load_History"+" SET M25RawNum ="+RecordCount+"  WHERE FileImportID = "+FileImportID
      val rs=statement.executeUpdate(q)
    }
    else if(FileType=="M25DICT"){
      val q="UPDATE "+"medispan.Audit_Medispan_Load_History"+" SET M25DICTRawNum ="+RecordCount+"  WHERE FileImportID = "+FileImportID
      val rs=statement.executeUpdate(q)
    }
    else if(FileType=="M25VAL"){
      val q="UPDATE "+"medispan.Audit_Medispan_Load_History"+" SET M25VALRawNum ="+RecordCount+"  WHERE FileImportID = "+FileImportID
      val rs=statement.executeUpdate(q)
    }
    else if(FileType=="M25TCRF"){
      val q="UPDATE "+"medispan.Audit_Medispan_Load_History"+" SET M25TCRFRawNum ="+RecordCount+"  WHERE FileImportID = "+FileImportID
      val rs=statement.executeUpdate(q)
    }
    else if(FileType=="M25GPPC"){
      val q="UPDATE "+"medispan.Audit_Medispan_Load_History"+" SET M25GPPCRawNum ="+RecordCount+"  WHERE FileImportID = "+FileImportID
      val rs=statement.executeUpdate(q)
    }
    else if(FileType=="M25GPRR"){
      val q="UPDATE "+"medispan.Audit_Medispan_Load_History"+" SET M25GPRRRawNum ="+RecordCount+"  WHERE FileImportID = "+FileImportID
      val rs=statement.executeUpdate(q)
    }
    else if(FileType=="M25MOD"){
      val q="UPDATE "+"medispan.Audit_Medispan_Load_History"+" SET M25MODRawNum ="+RecordCount+"  WHERE FileImportID = "+FileImportID
      val rs=statement.executeUpdate(q)
    }
    else if(FileType=="M25NMOD"){
      val q="UPDATE "+"medispan.Audit_Medispan_Load_History"+" SET M25NMODRawNum ="+RecordCount+"  WHERE FileImportID = "+FileImportID
      val rs=statement.executeUpdate(q)
    }
  }

  def CheckETLLoadType(ETLRunID: Int, IsIncremental: Int): Unit ={
    var LoadType=""
    if(IsIncremental==1)
    {
      LoadType="I"
    }
    else {
      LoadType="F"
    }
    val q1="SELECT (CASE WHEN LoadType= '"+LoadType+"' THEN 1 ELSE 0 END ) FROM "+"medispan.Audit_Medispan_Load_History"+" WHERE ETLRunID = "+ETLRunID
    val rs1=statement.executeQuery(q1)
    var IsLoadTypeMatch=0
    while(rs1.next())
    {
      IsLoadTypeMatch=rs1.getInt(1)
    }
    println(IsLoadTypeMatch)
    val q2="UPDATE "+"medispan.Audit_Medispan_Load_History"+" SET ETLLoadType = '"+LoadType+"',  IsETLTypeMatched = "+IsLoadTypeMatch+" WHERE ETLRunID = "+ETLRunID
    println(q2)
    val rs2=statement.executeUpdate(q2)
  }

  def LoadETLCDCSummaryToHistory(ETLRunID: Int, LoadDimType: String, RowsInserted: Int, RowsUpdated: Int, RowsDeleted: Int, RowsIgnored: Int, RowsInfered: Int): Unit ={
    val d="UPDATE "+"medispan.Audit_Medispan_Load_History"+"SET  DrugIngredientCDCRowsInserted = 0,DrugIngredientCDCRowsUpdated = 0,DrugIngredientCDCRowsDeleted = 0,DrugIngredientCDCRowsIgnored = 0,DrugIngredientCDCRowsInfered = 0 WHERE ETLRunID = "+ETLRunID
    //    val ds=statement.executeUpdate(d)
    if(LoadDimType=="DrugItem"){
      val q="UPDATE "+"medispan.Audit_Medispan_Load_History"+" SET  DrugItemCDCRowsInserted = "+RowsInserted+",DrugItemCDCRowsUpdated = "+RowsUpdated+", DrugItemCDCRowsDeleted = "+RowsDeleted+", DrugItemCDCRowsIgnored = "+RowsIgnored+", DrugItemCDCRowsInfered = "+RowsInfered+" WHERE ETLRunID = "+ETLRunID
      val rs=statement.executeUpdate(q)
    }
    else if(LoadDimType=="DrugPricing"){
      val q="UPDATE "+"medispan.Audit_Medispan_Load_History"+" SET  DrugPriceCDCRowsInserted = "+RowsInserted+",DrugPriceCDCRowsUpdated = "+RowsUpdated+", DrugPriceCDCRowsDeleted = "+RowsDeleted+", DrugPriceCDCRowsIgnored = "+RowsIgnored+", DrugPriceCDCRowsInfered = "+RowsInfered+" WHERE ETLRunID = "+ETLRunID
      val rs=statement.executeUpdate(q)
    }
  }
  def LoadSumToHistory(MaxFileImport:Int, ZipFileName:String): Unit = {
    val FileImportID=MaxFileImport
    val df1=Sources.Raw_M25SUM(ZipFileName)
    df1.createOrReplaceGlobalTempView("RAW_M25SUM")
    //Q1
    val FileType=DriverClass.spark.sql("SELECT LTRIM(RTRIM(DataorComment)) FROM global_temp.RAW_M25SUM  WHERE RecordType = 'CFT' and SequenceNumber = '020' ").head.get(0)
    val q1="UPDATE  medispan.Audit_Medispan_Load_History  SET FileType ='"+FileType+"'  WHERE FileImportID ="+FileImportID
    val rs1 = statement.executeUpdate(q1)
    //Q2
    val df2=DriverClass.spark.sql("SELECT CAST(SUBSTRING(RTRIM(LTRIM(DataorComment)), 1, instr( RTRIM(LTRIM(DataorComment)),' ') - 1) AS INT),   CAST(SUBSTRING(RTRIM(LTRIM(DataorComment)), instr(RTRIM(LTRIM(DataorComment)),' ') + 1, LENGTH(RTRIM(LTRIM(DataorComment)))) AS INT) FROM global_temp.RAW_M25SUM where   RecordType = 'CVL' AND   SequenceNumber = '030'")
    val VolumeNo=df2.head.get(0)
    val SupplementNo=df2.head.get(1)
    val q2="UPDATE medispan.Audit_Medispan_Load_History    SET  VolumeNo = "+VolumeNo+",    SupplementNo = "+SupplementNo+"  WHERE FileImportID = "+FileImportID
    val rs2=statement.executeUpdate(q2)

    //Q3
    val ExpirationDate=DriverClass.spark.sql("SELECT to_timestamp(DataOrComment,\" yyyyMMdd\") FROM global_temp.RAW_M25SUM WHERE RecordType = 'CDE' AND SequenceNumber = '020'").head.get(0)
    val q3="UPDATE  medispan.Audit_Medispan_Load_History  SET ExpirationDate ='"+ExpirationDate+"'  WHERE FileImportID ="+FileImportID
    val rs3=statement.executeUpdate(q3)

    //Q4
    val IssueDate=DriverClass.spark.sql("SELECT to_timestamp(DataOrComment,\" yyyyMMdd\") FROM global_temp.RAW_M25SUM WHERE RecordType = 'CDI' AND SequenceNumber = '020'").head.get(0)
    val q4="UPDATE  medispan.Audit_Medispan_Load_History  SET IssueDate ='"+IssueDate+"'  WHERE FileImportID ="+FileImportID
    val rs4=statement.executeUpdate(q4)

    //Q5
    val KillDate=DriverClass.spark.sql("SELECT to_timestamp(DataOrComment,\" yyyyMMdd\") FROM global_temp.RAW_M25SUM WHERE RecordType = 'CDK' AND SequenceNumber = '020'").head.get(0)
    val q5="UPDATE  medispan.Audit_Medispan_Load_History  SET KillDate ='"+KillDate+"'  WHERE FileImportID ="+FileImportID
    val rs5=statement.executeUpdate(q5)

    //Q6
    val M25DICTNum=DriverClass.spark.sql("SELECT CAST(SUBSTRING(RTRIM(LTRIM(DataOrComment)), LENGTH(RTRIM(LTRIM(DataOrComment))) - 6, 7 ) AS INT) FROM global_temp.RAW_M25SUM WHERE RecordType = 'TOC' AND SequenceNumber = '140' ").head.get(0)
    val q6="UPDATE  medispan.Audit_Medispan_Load_History  SET M25DICTNum ='"+M25DICTNum+"'  WHERE FileImportID ="+FileImportID
    val rs6=statement.executeUpdate(q6)

    //Q7
    val M25VALNum=DriverClass.spark.sql("SELECT CAST(SUBSTRING(RTRIM(LTRIM(DataOrComment)), LENGTH(RTRIM(LTRIM(DataOrComment))) - 6, 7 ) AS INT) FROM global_temp.RAW_M25SUM WHERE RecordType = 'TOC' AND SequenceNumber = '150' ").head.get(0)
    val q7="UPDATE  medispan.Audit_Medispan_Load_History  SET M25VALNum ='"+M25VALNum+"'  WHERE FileImportID ="+FileImportID
    val rs7=statement.executeUpdate(q7)

    //Q8
    val M25Num=DriverClass.spark.sql("SELECT CAST(SUBSTRING(RTRIM(LTRIM(DataOrComment)), LENGTH(RTRIM(LTRIM(DataOrComment))) - 6, 7 ) AS INT) FROM global_temp.RAW_M25SUM WHERE RecordType = 'TOC' AND SequenceNumber = '160' ").head.get(0)
    val q8="UPDATE  medispan.Audit_Medispan_Load_History  SET M25Num ='"+M25Num+"'  WHERE FileImportID ="+FileImportID
    val rs8=statement.executeUpdate(q8)

    //Q9
    val M25GPPCNum=DriverClass.spark.sql("SELECT CAST(SUBSTRING(RTRIM(LTRIM(DataOrComment)), LENGTH(RTRIM(LTRIM(DataOrComment))) - 6, 7 ) AS INT) FROM global_temp.RAW_M25SUM WHERE RecordType = 'TOC' AND SequenceNumber = '180' ").head.get(0)
    val q9="UPDATE  medispan.Audit_Medispan_Load_History  SET M25GPPCNum ='"+M25GPPCNum+"'  WHERE FileImportID ="+FileImportID
    val rs9=statement.executeUpdate(q9)

    //Q10
    val M25GPRRNum=DriverClass.spark.sql("SELECT CAST(SUBSTRING(RTRIM(LTRIM(DataOrComment)), LENGTH(RTRIM(LTRIM(DataOrComment))) - 6, 7 ) AS INT) FROM global_temp.RAW_M25SUM WHERE RecordType = 'TOC' AND SequenceNumber = '200' ").head.get(0)
    val q10="UPDATE  medispan.Audit_Medispan_Load_History  SET M25GPRRNum ='"+M25GPRRNum+"'  WHERE FileImportID ="+FileImportID
    val rs10=statement.executeUpdate(q10)

    //Q11
    val M25TCRFNum=DriverClass.spark.sql("SELECT CAST(SUBSTRING(RTRIM(LTRIM(DataOrComment)), LENGTH(RTRIM(LTRIM(DataOrComment))) - 6, 7 ) AS INT) FROM global_temp.RAW_M25SUM WHERE RecordType = 'TOC' AND SequenceNumber = '210' ").head.get(0)
    val q11="UPDATE  medispan.Audit_Medispan_Load_History  SET M25TCRFNum ='"+M25TCRFNum+"'  WHERE FileImportID ="+FileImportID
    val rs11=statement.executeUpdate(q11)

    //Q12
    val M25MODNum=DriverClass.spark.sql("SELECT CAST(SUBSTRING(RTRIM(LTRIM(DataOrComment)), LENGTH(RTRIM(LTRIM(DataOrComment))) - 6, 7 ) AS INT) FROM global_temp.RAW_M25SUM WHERE RecordType = 'TOC' AND SequenceNumber = '170' ").head.get(0)
    val q12="UPDATE  medispan.Audit_Medispan_Load_History  SET M25MODNum ='"+M25MODNum+"'  WHERE FileImportID ="+FileImportID
    val rs12=statement.executeUpdate(q12)

    //Q13
    val M25NMODNum=DriverClass.spark.sql("SELECT CAST(SUBSTRING(RTRIM(LTRIM(DataOrComment)), LENGTH(RTRIM(LTRIM(DataOrComment))) - 6, 7 ) AS INT) FROM global_temp.RAW_M25SUM WHERE RecordType = 'TOC' AND SequenceNumber = '190' ").head.get(0)
    val q13="UPDATE  medispan.Audit_Medispan_Load_History  SET M25NMODNum ='"+M25NMODNum+"'  WHERE FileImportID ="+FileImportID
    val rs13=statement.executeUpdate(q13)

  }
}
