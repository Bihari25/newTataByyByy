package com.optum.spark

import java.sql.{Connection, DriverManager}
import java.util.Properties

import org.apache.spark.sql.SaveMode
import org.apache.spark.sql.functions._

import scala.io.Source

object DrugItem {

  val url = getClass.getResource("/source.properties")
  val properties: Properties = new Properties()
  val source = Source.fromURL(url)
  properties.load(source.bufferedReader())
  def Implementation(ZipFileName:String,ETLRunID:Int,IsIncremental:Int)= {
    val spark=DriverClass.spark

  
//    val log = LogManager.getLogger(this.getClass.getName)

    val df = Sources.Raw_M25TCRF(ZipFileName)
    df.cache()
    println(df.count())
    if(IsIncremental==1)
    {
      var DrugGPIClassification=df
      DrugGPIClassification=DrugGPIClassification.withColumn("ETLRunID",lit(ETLRunID))
      val date = current_date()

      DrugGPIClassification=DrugGPIClassification.filter(col("TransactionCode").isin("A","D","C")).filter(col("ZipFileName")===ZipFileName)
      DrugGPIClassification=DrugGPIClassification.drop("Reserve01","Reserve02")//,"LastChangeDate","ETLStatus","ETLErrorCount","FileImportID")
      DrugGPIClassification=DrugGPIClassification.withColumn("RowStartDate",lit(to_timestamp(col("LastChangeDate"),"yyDDD")))
      DrugGPIClassification=DrugGPIClassification.withColumn("RowEndDate",lit("2078-12-31 00:00:00"))
      DrugGPIClassification=DrugGPIClassification.withColumn("IsRowCurrent",lit(1))

      var Dtemp=DrugGPIClassification.filter(col("TransactionCode")==="D")
      DrugGPIClassification=DrugGPIClassification.filter(col("TransactionCode")=!="D")
      Dtemp.withColumn("RowEndDate",date_sub(col("RowEndDate"), 1))
      DrugGPIClassification=DrugGPIClassification.union(Dtemp)

      var STG=DrugGPIClassification

      DrugGPIClassification.createOrReplaceGlobalTempView("DrugGPIClassification")


      var Dim_DrugGPIClassification=LoadUtil.readJDBC("Dim_DrugGPIClassification")

      Dim_DrugGPIClassification.createOrReplaceGlobalTempView("Dim_DrugGPIClassification")

      val dgpi = DrugGPIClassification.select("TherapeuticClassificationCode","RecordTypeCode","TransactionCode","TherapeuticClassificationName","ZipFileName","RowStartDate","RowEndDate","IsRowCurrent","ETLRunID")

      LoadUtil.writeJDBC(dgpi, "STG_DrugGPIClassification", SaveMode.Overwrite)

      println("\nSTG_DrugGPIClassification loaded! \n")

      var tempAC=spark.sql("Select A.* from global_temp.Dim_DrugGPIClassification A INNER JOIN global_temp.DrugGPIClassification B    ON A.TherapeuticClassificationCode = B.TherapeuticClassificationCode AND      A.IsRowCurrent = 1 AND B.TransactionCode in ('A', 'C')")
      tempAC=tempAC.where(col("IsRowCurrent")===1).withColumn("IsRowCurrent",lit(0)).withColumn("RowEndDate",col("RowStartDate"))
      tempAC=tempAC.select("TherapeuticClassificationCode","RecordTypeCode","TherapeuticClassificationName","ETLRunID","RowStartDate","RowEndDate","IsRowSkeleton","ZipFileName")
      tempAC=tempAC.withColumn("ETLRunID",lit(ETLRunID))
      tempAC.createOrReplaceGlobalTempView("tempAC")

      var tempD=spark.sql("Select A.* from global_temp.Dim_DrugGPIClassification A INNER JOIN global_temp.DrugGPIClassification B    ON A.TherapeuticClassificationCode = B.TherapeuticClassificationCode AND      A.IsRowCurrent = 1 AND B.TransactionCode in ('D')")
      tempD=tempD.where(col("IsRowCurrent")===1).withColumn("IsRowCurrent",lit(0))
      tempD=tempD.select("TherapeuticClassificationCode","RecordTypeCode","TherapeuticClassificationName","ETLRunID","RowStartDate","RowEndDate","IsRowSkeleton","ZipFileName")
      tempD=tempD.withColumn("ETLRunID",lit(ETLRunID))
      tempD.createOrReplaceGlobalTempView("tempD")

      var tempNone=spark.sql("Select A.* from global_temp.Dim_DrugGPIClassification A INNER JOIN global_temp.DrugGPIClassification B    ON A.TherapeuticClassificationCode = B.TherapeuticClassificationCode AND      A.IsRowCurrent = 1")
      tempNone=tempNone.withColumn("ETLRunID",lit(ETLRunID))
      tempNone=tempNone.select("TherapeuticClassificationCode","RecordTypeCode","TherapeuticClassificationName","ETLRunID","RowStartDate","RowEndDate","IsRowSkeleton","ZipFileName")
      tempNone.createOrReplaceGlobalTempView("tempN")
      tempNone=spark.sql("Select * from global_temp.tempN where TherapeuticClassificationCode not in (select TherapeuticClassificationCode from global_temp.tempD)")

      Dim_DrugGPIClassification=tempAC.union(tempD)
      Dim_DrugGPIClassification=Dim_DrugGPIClassification.union(tempNone)
      Dim_DrugGPIClassification=Dim_DrugGPIClassification.withColumn("IsRowSkeleton",lit(0))
      Dim_DrugGPIClassification=Dim_DrugGPIClassification.withColumn("ETLRunID",lit(ETLRunID))
      Dim_DrugGPIClassification.show()


      var connection:Connection = null

      Class.forName(properties.getProperty("azureDriver"))
      connection = DriverManager.getConnection(properties.getProperty("azureUrl"), properties.getProperty("azureUser"), properties.getProperty("azurePassword"))
      val q="select TherapeuticClassificationCode, RecordTypeCode, TherapeuticClassificationName, ETLRunID, RowStartDate, RowEndDate, IsRowCurrent, 0, ZipFileName from "+"medispan.STG_DrugGPIClassification"

      val MergeQuery1="insert into "+"medispan.Dim_DrugGPIClassification"+" ( TherapeuticClassificationCode, RecordTypeCode, TherapeuticClassificationName, ETLRunID, RowStartDate, RowEndDate, IsRowCurrent, IsRowSkeleton, ZipFileName ) select  TherapeuticClassificationCode, RecordTypeCode, TherapeuticClassificationName, ETLRunID, RowStartDate, RowEndDate, IsRowCurrent, 0, ZipFileName from "+"medispan.STG_DrugGPIClassification"

      val statement = connection.createStatement()
      var resultSet = statement.execute(MergeQuery1)
      println("\nDim_DrugGPIClassification loaded! \n")

    }
    else {
      var DrugGPIClassification=df

      val date=current_date()

      DrugGPIClassification=DrugGPIClassification.filter(col("TransactionCode").isin("A","D","C")).filter(col("ZipFileName")===ZipFileName)
      DrugGPIClassification=DrugGPIClassification.drop("Reserve01","Reserve02")//,"LastChangeDate","ETLStatus","ETLErrorCount","FileImportID")
      DrugGPIClassification=DrugGPIClassification.withColumn("RowStartDate",lit(unix_timestamp()))
      DrugGPIClassification=DrugGPIClassification.withColumn("RowEndDate",lit("2078-12-31"))
      DrugGPIClassification=DrugGPIClassification.withColumn("IsRowCurrent",lit(1))
      DrugGPIClassification=DrugGPIClassification.withColumn("IsRowSkeleton",lit(0))
      DrugGPIClassification=DrugGPIClassification.withColumn("ETLRunID",lit(ETLRunID))

      DrugGPIClassification.createOrReplaceGlobalTempView("DrugGPIClassification")
      var  Dim_DrugGPIClassification=DrugGPIClassification

    }

//    log.info("LoadDrugGPIClassification Executed")

    val DrugClass=Views.Drug_Class()
    DrugClass.createOrReplaceGlobalTempView("DrugClass")

    val DrugGroup=Views.Drug_Group()
    DrugGroup.createOrReplaceGlobalTempView("DrugGroup")

    val DrugName=Views.Drug_Name()
    DrugName.createOrReplaceGlobalTempView("DrugName")

    val DrugSubClass=Views.Drug_SubClass()
    DrugSubClass.createOrReplaceGlobalTempView("DrugSubClass")

    val DrugCategory=LoadUtil.readJDBC("DrugCategory")
    DrugCategory.createOrReplaceGlobalTempView("DrugCategory")

    val Raw=Raw_DrugItem.defination(DriverClass.zipFileName)
    Raw.cache()
    println("Raw_DrugItem: "+Raw.count())
    Raw.createOrReplaceGlobalTempView("RAW_DRUGITEM")

    var t_item1=spark.sql("Select A.*,C0.DrugCategory,C2.DrugClass,C3.DrugSubclass,C1.DrugGroup,C4.DrugName from global_temp.RAW_DRUGITEM A  " +
      "LEFT OUTER JOIN  global_temp.DrugCategory AS C0 ON (SUBSTRING(A.GenericProductID, 2) = C0.Code) " +
      "LEFT OUTER JOIN global_temp.DrugGroup AS C1 ON (SUBSTRING(A.GenericProductID, 2) = SUBSTRING(C1.GPISubset, 2))  " +
      "LEFT OUTER JOIN global_temp.DrugClass AS C2 ON (SUBSTRING(A.GenericProductID, 4) = SUBSTRING(C2.GPISubset, 4))   " +
      "LEFT OUTER JOIN global_temp.DrugSubclass AS C3 ON (SUBSTRING(A.GenericProductID, 6) = SUBSTRING(C3.GPISubset, 6))   " +
      "LEFT OUTER JOIN global_temp.DrugName AS C4 ON (SUBSTRING(A.GenericProductID, 10) = SUBSTRING(C4.GPISubset, 10))")

    var t_item=spark.sql("Select A.*,C0.DrugCategory,C2.DrugClass,C3.DrugSubclass,C1.DrugGroup,C4.DrugName from global_temp.RAW_DRUGITEM A  " +
      "LEFT OUTER JOIN  global_temp.DrugCategory AS C0 ON (SUBSTRING(A.GenericProductID,0, 2) = C0.Code) " +
      "LEFT OUTER JOIN global_temp.DrugGroup AS C1 ON (SUBSTRING(A.GenericProductID,0, 2) = SUBSTRING(C1.GPISubset,0, 2))  " +
      "LEFT OUTER JOIN global_temp.DrugClass AS C2 ON (SUBSTRING(A.GenericProductID,0, 4) = SUBSTRING(C2.GPISubset,0, 4))   " +
      "LEFT OUTER JOIN global_temp.DrugSubclass AS C3 ON (SUBSTRING(A.GenericProductID,0, 6) = SUBSTRING(C3.GPISubset,0, 6))   " +
      "LEFT OUTER JOIN global_temp.DrugName AS C4 ON (SUBSTRING(A.GenericProductID,0, 10) = SUBSTRING(C4.GPISubset,0, 10)) where A.ZipFileName='"+ZipFileName+"'")

    var temp1=spark.sql("Select PRODUCTID from global_temp.RAW_DRUGITEM A ")//  LEFT OUTER JOIN  global_temp.DrugCategory AS C0 ON (substring(A.GenericProductID,0, 2) = C0.Code)")

    if(IsIncremental==1)
    {
      t_item=t_item.withColumnRenamed("LastChangeDate","RowStartDate")

      var DrugItem=t_item

      DrugItem=DrugItem.withColumn("RowStatus",lit(-1))
      DrugItem=DrugItem.withColumn("IsRowCurrent",lit(1))
      DrugItem=DrugItem.withColumn("ZipFileName",lit(ZipFileName))
      DrugItem=DrugItem.withColumn("ETLRunID",lit(ETLRunID))
      DrugItem=DrugItem.withColumn("RowEndDate",lit("2078-12-31" ))

      println("DrugItem:"+DrugItem.count())


      val DrugItemA3=DrugItem.filter(col("ChangeCode").startsWith("A3")).withColumn("RowStatus",lit(3)).withColumn("RowEndDate",col("RowStartDate"))
      println("A3:"+DrugItemA3.count())

      val DrugItemA1=DrugItem.where(col("ChangeCode").startsWith("A1")).withColumn("RowStatus",lit(1))
      println("A1:"+DrugItemA1.count())
      //println("A1:"+DrugItemA1.count())
      //DrugItemA1.show()
      val DrugItemA2=DrugItem.where(col("ChangeCode").like("A%2%")).withColumn("RowStatus",lit(2))
      println("A2:"+DrugItemA2.count())
      //println("A2:"+DrugItemA2.count())
      //DrugItemA2.show()
      val DrugItemA0=DrugItem.where(col("ChangeCode").equalTo("A0C0E0G0J0L0M0")).withColumn("RowStatus",lit(0)).withColumn("OldProductID",lit(null))
        .withColumn("OldEffectiveDate",lit(null))
        .withColumn("NewProductID",lit(null))
        .withColumn("NewEffectiveDate",lit(null))

      println("A0:"+DrugItemA0.count())

      DrugItem=DrugItemA0.union(DrugItemA1)//,DrugItemA2,DrugItemA3)
      DrugItem=DrugItem.union(DrugItemA2)
      DrugItem=DrugItem.union(DrugItemA3)
      DrugItem=DrugItem.withColumn("ZipFileName",lit(ZipFileName))

      println("Updated DrugItem:"+DrugItem.count())

      var STG_DrugItem=DrugItem
      STG_DrugItem=STG_DrugItem.filter(col("RowStatus")=!=(-1)).drop()
      STG_DrugItem.createOrReplaceGlobalTempView("STGDrugItem")
    }

    else
    {
      var STG_DrugItem=t_item

      var Dim_DrugItem=LoadUtil.readJDBC("Dim_DrugItem")
      Dim_DrugItem.filter(col("ZipFilename")===ZipFileName).createOrReplaceGlobalTempView("DimDrugItem")
      Dim_DrugItem.cache()

      var temp_STG_DrugItem=spark.sql("select A.* from global_temp.STGDrugItem AS A left JOIN global_temp.DimDrugItem B ON A.ProductID= B.ProductID AND A.IsRowCurrent = B.IsRowCurrent WHERE A.RowStatus = 1 AND B.IsRowCurrent = 1 AND B.IsRowSkeleton = 1")
      temp_STG_DrugItem=temp_STG_DrugItem.withColumn("RowStatus",lit(4))
      temp_STG_DrugItem=temp_STG_DrugItem.withColumn("IsRowCurrent",lit(1))
      temp_STG_DrugItem=temp_STG_DrugItem.withColumn("ZipFileName",lit(ZipFileName))
      temp_STG_DrugItem=temp_STG_DrugItem.withColumn("ETLRunID",lit(ETLRunID))

//      log.info("STG DrugItem:"+temp_STG_DrugItem.count())

    }
    var Dim_DrugItem=LoadUtil.readJDBC("Dim_DrugItem")
    Dim_DrugItem.filter(col("ZipFilename")===ZipFileName).createOrReplaceGlobalTempView("DimDrugItemZip")

    var temp_STG_DrugItem=spark.sql("select A.* from global_temp.STGDrugItem AS A left JOIN global_temp.DimDrugItemZip B ON A.ProductID = B.ProductID AND A.IsRowCurrent = B.IsRowCurrent WHERE A.RowStatus = 1 AND B.IsRowCurrent = 1 AND B.IsRowSkeleton = 1")
    temp_STG_DrugItem=temp_STG_DrugItem.withColumn("RowStatus",lit(4))
    temp_STG_DrugItem.createOrReplaceGlobalTempView("TempView")
//    log.info("Inter STG DrugItem:"+temp_STG_DrugItem.count())

    var STG=spark.sql("select A.* from global_temp.STGDrugItem A where A.PRODUCTID NOT IN (SELECT PRODUCTID FROM global_temp.TempView)")
    STG=STG.union(temp_STG_DrugItem)
    STG=STG.withColumnRenamed("PackageCode","UnitOfUsePackageCode")
    STG=STG.withColumnRenamed("LastChangeDate","RowStartDate")
    STG=STG.select("PRODUCTID","RowStartDate","RowEndDate","ProductIDFormatCode","ProductName","AllergyPatternCode","PPGIndicatorCode","HFPGIndicatorCode","LabelerTypeCode","PricingSpreadCode","SequenceCode","LabelerCode","ManufacturerName","ManufacturerAbbreviatedName","GenericIDTypeCode","GenericIDNumber","DEAClassCode","AHFSTherapeuticClassCode","ItemStatusFlag","LocalSystemicFlag","TEECode","FormattedIDNumber","RXOTCIndicatorCode","ThirdPartyRestrictionCode","MaintenanceDrugCode","DispensingUnitCode","UnitOfUsePackageCode","RouteofAdministration","FormTypeCode","DollarRankCode","RxRankCode","NumberSystemCharacter","SecondaryIDFormatCode","SecondaryIDNumber","MultiSourceCode","BrandNameCode","ReimbursementIndicator","InternalExternalCode","SingleCombinationCode","StorageConditionCode","LimitedStabilityCode","ProductDescriptionAbbreviation","DrugNameCode","GenericProductID","GenericProductName","GenericProductPackagingCode","DosageForm","PackageSize","UnitOfMeasure","PackageQuantity","RepackageCode","TotalPackageQuantity","DESICode","PackageDescription","NextSmallerNDCSuffixNumber","NextLargerNDCSuffixNumber","InnerpackCode","ClinicPackCode","MetricStrength","StrengthUnitofMeasure","LimitedDistributionCode","ExtendedAHFSTherapeuticClassCode","InactiveDate","OldProductID","OldEffectiveDate","NewProductID","NewEffectiveDate","TransactionCode","ETLRunID","RowStatus","IsRowCurrent","ZipFileName","DrugCategory","DrugGroup","DrugClass","DrugSubclass","DrugName")
    println("\n Final staging reached! \n")
    var rows=spark.read.option("header",true).csv(properties.getProperty("rootPath")+"STGUpdatedRows.csv")

    var seq= rows.collect().toList

    for(i <- 0 to rows.count().toInt-1){
      STG=STG.withColumn(seq(i)(0).toString, col(seq(i)(0).toString).cast(seq(i)(1).toString))
    }

    LoadUtil.writeJDBC(STG, "STG_DrugItem", SaveMode.Overwrite)

    println("\nSTG_DrugItem loaded! \n")

    STG.createOrReplaceGlobalTempView("STGDI")

  }
}
