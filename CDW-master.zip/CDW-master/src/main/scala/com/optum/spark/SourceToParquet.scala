package com.optum.spark


import scala.sys.process._
import java.util.Properties
import scala.io.Source
import com.databricks.dbutils_v1.DBUtilsHolder.dbutils

object SourceToParquet {
  val url = getClass.getResource("/source.properties")
  val properties: Properties = new Properties()
  val source = Source.fromURL(url)
  properties.load(source.bufferedReader())

  def runProcess(ZipFileName:String, MaxFileImportID: Int): (Int,Int,Int,Int,Int,Int,Int,Int,Int,Int,String) = {

//    val srcPath = properties.getProperty("rootPath") + ZipFileName
//
//    val dstnPath  = properties.getProperty("sourcePath") + ZipFileName
//
//    dbutils.notebook.run("notebook-name", 0, Map("argument" -> "data", "argument2" -> "data2"))

    //
//    val zip = Seq("unzip", srcPath, "-d", dstnPath).!

    var t1=ExtractProcess.runProcess(ZipFileName,"P_M25", MaxFileImportID)
    var t2=ExtractProcess.runProcess(ZipFileName,"P_M25DICT", MaxFileImportID)
    var t3=ExtractProcess.runProcess(ZipFileName,"P_M25GPPC", MaxFileImportID)
    var t4=ExtractProcess.runProcess(ZipFileName,"P_M25ERR", MaxFileImportID)
    var t5=ExtractProcess.runProcess(ZipFileName,"P_M25GPRR", MaxFileImportID)
    var t6=ExtractProcess.runProcess(ZipFileName,"P_M25MOD", MaxFileImportID)
    var t7=ExtractProcess.runProcess(ZipFileName,"P_M25NMOD", MaxFileImportID)
    var t8=ExtractProcess.runProcess(ZipFileName,"P_M25SUM", MaxFileImportID)
    var t9=ExtractProcess.runProcess(ZipFileName,"P_M25TCRF", MaxFileImportID)
    var t10=ExtractProcess.runProcess(ZipFileName,"P_M25VAL", MaxFileImportID)
    return (t1._1,t2._1,t3._1,t4._1,t5._1,t6._1,t7._1,t8._1,t9._1,t10._1,t10._2)
  }
}
