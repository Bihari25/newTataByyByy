package com.optum.spark

import java.sql.{Connection, DriverManager}
import java.util.Properties

import scala.io.Source

object Backup {
  def runProcess(): Unit = {
    val url = getClass.getResource("/source.properties")
    val properties: Properties = new Properties()
    val source = Source.fromURL(url)

    Class.forName(properties.getProperty("azureDriver"))
    var connection: Connection = null
    connection = DriverManager.getConnection(properties.getProperty("azureUrl"), properties.getProperty("azureUser"), properties.getProperty("azurePassword"))
    val statement = connection.createStatement()

    val r1 = statement.execute("drop table medispan.Dim_DrugPricing_Backup")
    connection.commit()
    val r2 = statement.executeQuery("INSERT INTO  medispan.Dim_DrugPricing_Backup SELECT * FROM medispan.Dim_DrugPricing")
  }

}
