package com.optum.spark

import java.util.Properties
import com.microsoft.azure.sqldb.spark.config.Config
import com.microsoft.azure.sqldb.spark.connect._
import com.microsoft.azure.sqldb.spark.query._
import org.apache.spark.sql.{DataFrame, SaveMode}

import scala.io.Source

object LoadUtil {
  val spark = DriverClass.spark

  val url = getClass.getResource("/source.properties")
  val properties: Properties = new Properties()
  val source = Source.fromURL(url)
  properties.load(source.bufferedReader())



  def readJDBC(table_name: String): DataFrame ={
      val df = spark.read
        .format("jdbc")
        .option("driver", properties.getProperty("azureDriver"))
        .option("url", properties.getProperty("azureUrl"))
        .option("dbtable", properties.getProperty("azureTable") + table_name)
        .option("user", properties.getProperty("azureUser"))
        .option("password", properties.getProperty("azurePassword"))
        .load()

//    val config = Config(Map(
//      "url"            -> properties.getProperty("azureURL"),
//      "databaseName"   -> properties.getProperty("azureDb"),
//      "dbTable"        -> (properties.getProperty("azureTable") + table_name),
//      "user"           -> properties.getProperty("azureUser"),
//      "password"       -> properties.getProperty("azurePassword"),
//      "connectTimeout" -> "600", //seconds
//      "queryTimeout"   -> "600"  //seconds
//    ))
//    val df = spark.sqlContext.read.sqlDB(config)
      return df
  }

  def writeJDBC(df: DataFrame, tableName: String, saveMode: SaveMode): Unit ={
    df.write
      .format("jdbc")
      .option("driver",properties.getProperty("azureDriver"))
      .option("url", properties.getProperty("azureUrl"))
      .option("dbtable",properties.getProperty("azureTable")+tableName)
      .option("user", properties.getProperty("azureUser"))
      .option("password", properties.getProperty("azurePassword"))
      .mode(saveMode)
      .save()

//    val config = Config(Map(
//      "url"            -> properties.getProperty("azureURL"),
//      "databaseName"   -> properties.getProperty("azureDb"),
//      "dbTable"        -> (properties.getProperty("azureTable") + tableName),
//      "user"           -> properties.getProperty("azureUser"),
//      "password"       -> properties.getProperty("azurePassword"),
//      "connectTimeout" -> "600", //seconds
//      "queryTimeout"   -> "600"  //seconds
//    ))
//    df.write.mode(saveMode).sqlDB(config)
  }

//  def runQuery(query: String): Unit ={
//    val qry = query.stripMargin
//
//    val config = Config(Map(
//      "url"          -> properties.getProperty("azureURL"),
//      "databaseName"   -> properties.getProperty("azureDb"),
//      "user"         -> properties.getProperty("azureUser"),
//      "password"     -> properties.getProperty("azurePassword"),
//      "queryCustom"  -> qry
//    ))
//
//    spark.sqlContext.sqlDBQuery(config)
//  }

}
