package com.optum.spark
import org.apache.spark.sql.SaveMode
import org.apache.spark.sql.functions._
object DrugPricingWAC {
  def run(ETLRunID:Int,ZipFileName:String,IsIncremental:Int): Unit = {
    var dfM25 = Sources.Raw_M25(ZipFileName)
    dfM25.createOrReplaceGlobalTempView("M25")
    var i=Views.M25Q()

    var q_df=DriverClass.spark.sql(i)
    q_df.createOrReplaceGlobalTempView("Raw_M25Q")
    i=Views.M25A()
    var df=DriverClass.spark.sql(i)
    df.createOrReplaceGlobalTempView("Raw_M25A")
    q_df=q_df.withColumn("CostTypeCode", lit("WAC"))

    var Raw1=q_df.filter(col("WACPackagePrice").isNotNull)
    var t1 = Raw1.filter(col("RecordCode") === "Q01").withColumn("RecordCode", lit(1))
    var t2 = Raw1.filter(col("RecordCode") === "Q02").withColumn("RecordCode", lit(3))
    var t3 = Raw1.filter(col("RecordCode") === "Q03").withColumn("RecordCode", lit(5))

    Raw1 = t1.union(t2)
    Raw1 = Raw1.union(t3)
    Raw1 = Raw1.withColumn("RowEndDate", lit("2078-12-31"))
    Raw1 = Raw1.withColumn("IsRowCurrent", lit(1))
    Raw1 = Raw1.withColumn("RowStartDate", col("LastChangeDate"))
    Raw1 = Raw1.withColumn("RowStatus", lit(0))
    Raw1 = Raw1.withColumnRenamed("WACEffectiveDate", "EffectiveDate")
    Raw1 = Raw1.withColumnRenamed("WACPackagePrice", "PackagePrice")
    Raw1 = Raw1.withColumnRenamed("WACUnitPrice", "UnitPrice")
    Raw1 = Raw1.drop("ProductIDFormatCode", "RecordData", "OlderWACPackagePrice", "OlderWACUnitPrice", "OlderWACEffectiveDate")
    Raw1= Raw1.select("PRODUCTID","RecordCode","CostTypeCode","TransactionCode","EffectiveDate","PackagePrice","UnitPrice","RowStartDate","RowEndDate","IsRowCurrent","RowStatus","LastChangeDate")

    var Raw2=q_df.filter(col("OlderWACUnitPrice").isNotNull)
    t1 = Raw2.filter(col("RecordCode") === "Q01").withColumn("RecordCode", lit(2))
    t2 = Raw2.filter(col("RecordCode") === "Q02").withColumn("RecordCode", lit(4))
    t3 = Raw2.filter(col("RecordCode") === "Q03").withColumn("RecordCode", lit(6))

    Raw2 = t1.union(t2)
    Raw2 = Raw2.union(t3)
    Raw2 = Raw2.withColumn("RowEndDate", lit("2078-12-31"))
    Raw2 = Raw2.withColumn("IsRowCurrent", lit(1))
    Raw2 = Raw2.withColumn("RowStartDate", col("LastChangeDate"))
    Raw2 = Raw2.withColumnRenamed("OlderWACEffectiveDate", "EffectiveDate")
    Raw2 = Raw2.withColumnRenamed("OlderWACPackagePrice", "PackagePrice")
    Raw2 = Raw2.withColumnRenamed("OlderWACUnitPrice", "UnitPrice")
    Raw2 = Raw2.withColumn("RowStatus", lit(0))
    Raw2 = Raw2.drop("ProductIDFormatCode", "RecordData","WACPackagePrice", "WACUnitPrice", "WACEffectiveDate")
    Raw2=Raw2.select("PRODUCTID","RecordCode","CostTypeCode","TransactionCode","EffectiveDate","PackagePrice","UnitPrice","RowStartDate","RowEndDate","IsRowCurrent","RowStatus","LastChangeDate")

    var DrugPricing=Raw1.union(Raw2)

    if(IsIncremental==1)
    {
      t1 = DriverClass.spark.sql("Select A.PRODUCTID,A.LastChangeDate as EffectiveDate,A.LastChangeDate as RowStartDate,A.LastChangeDate,A.LastChangeDate as RowEndDate,A.ZipFileName from global_temp.Raw_M25A A left join global_temp.Raw_M25Q B ON A.ProductID = B.ProductID AND A.LastChangeDate = B.LastChangeDate WHERE  A.TransactionCode = 'D' AND  B.RecordCode IS NULL  AND A.ProductID IN (SELECT ProductID FROM global_temp.DimDP WHERE IsRowCurrent = 1 AND CostTypeCode = 'WAC')")
      t1 = t1.withColumn("RecordCode", lit("1"))
      t1 = t1.withColumn("CostTypeCode", lit("WAC"))
      t1 = t1.withColumn("TransactionCode", lit("X"))
      t1 = t1.withColumn("PackagePrice", lit(0))
      t1 = t1.withColumn("UnitPrice", lit(0))
      t1 = t1.withColumn("IsRowCurrent", lit(1))
      t1 = t1.withColumn("RowStatus", lit(3))
      t1 = t1.withColumn("ETLRunID", lit(ETLRunID))
      val aa=t1
      t1=t1.select("ProductID","RecordCode","CostTypeCode","TransactionCode","EffectiveDate","PackagePrice","UnitPrice","ETLRunID","RowStartDate","RowEndDate","IsRowCurrent","RowStatus","LastChangeDate","ZipFileName")

      var t2=DriverClass.spark.sql("Select A.PRODUCTID,A.LastChangeDate as EffectiveDate,A.LastChangeDate as RowStartDate,A.LastChangeDate,A.ZipFileName from global_temp.Raw_M25A A left join global_temp.Raw_M25Q B ON A.ProductID = B.ProductID AND A.LastChangeDate = B.LastChangeDate WHERE  A.TransactionCode IN ('C', '') AND  B.RecordCode IS NULL AND  A.ProductID IN (SELECT ProductID  FROM global_temp.DimDP WHERE IsRowCurrent = 1 AND  CostTypeCode = 'DP') AND  A.ProductID NOT IN (SELECT ProductID  FROM global_temp.DimDP WHERE IsRowCurrent = 1 AND  RowEndDate = '12-31-2039' AND CostTypeCode = 'WAC')")
      t2 = t2.withColumn("RowEndDate", lit("2039-12-31"))
      t2 = t2.withColumn("RecordCode", lit("1"))
      t2 = t2.withColumn("CostTypeCode", lit("WAC"))
      t2 = t2.withColumn("TransactionCode", lit("X"))
      t2 = t2.withColumn("PackagePrice", lit(0))
      t2 = t2.withColumn("UnitPrice", lit(0))
      t2 = t2.withColumn("IsRowCurrent", lit(1))
      t2 = t2.withColumn("RowStatus", lit(5))
      t2=t2.withColumn("ETLRunID", lit(ETLRunID))
      val bb=t2
      t2=t2.select("ProductID","RecordCode","CostTypeCode","TransactionCode","EffectiveDate","PackagePrice","UnitPrice","ETLRunID","RowStartDate","RowEndDate","IsRowCurrent","RowStatus","LastChangeDate","ZipFileName")

      var t12=aa.union(bb)
      DrugPricing=DrugPricing.drop("ETLStatus","ETLErrorCount","FileImportID")
      DrugPricing=DrugPricing.withColumn("ZipFileName",lit(ZipFileName))
      DrugPricing=DrugPricing.withColumn("ETLRunID",lit(ETLRunID))
      DrugPricing=DrugPricing.select("ProductID","RecordCode","CostTypeCode","TransactionCode","EffectiveDate","PackagePrice","UnitPrice","ETLRunID","RowStartDate","RowEndDate","IsRowCurrent","RowStatus","LastChangeDate","ZipFileName")
      DrugPricing=DrugPricing.union(t1)
      DrugPricing=DrugPricing.union(t2)

      var drugPricingChangeStatus=DrugPricing.filter(col("TransactionCode")=!="X").select("PRODUCTID","RecordCode","TransactionCode")

      var t=drugPricingChangeStatus.filter(col("TransactionCode")===" ")
      t=t.withColumn("TransactionCode",lit("N"))
      drugPricingChangeStatus=drugPricingChangeStatus.filter(col("TransactionCode")=!=" ")
      drugPricingChangeStatus=drugPricingChangeStatus.union(t)
      var e="concat(LTRIM(RTRIM(RecordCode)),TransactionCode)"
      drugPricingChangeStatus= drugPricingChangeStatus.withColumn("ChangeCode",expr(e))

      DrugPricing.createOrReplaceGlobalTempView("DP")
      drugPricingChangeStatus.dropDuplicates("PRODUCTID","RecordCode").createOrReplaceGlobalTempView("DPChangeStatus")

      var temp1=DriverClass.spark.sql("select A.* from global_temp.DP A where A.PRODUCTID in( select B.PRODUCTID from global_temp.DPChangeStatus B  WHERE B.ChangeCode LIKE '%D%')")
      temp1=temp1.withColumn("RowStatus",lit(3))
      temp1=temp1.withColumn("RowEndDate",lit(col("RowStartDate")))

      var temp2=DriverClass.spark.sql("select A.* from global_temp.DP A where A.PRODUCTID in( select B.PRODUCTID from global_temp.DPChangeStatus B  WHERE B.ChangeCode LIKE '%A%')")
      temp2=temp2.withColumn("RowStatus",lit(1))

      var temp3=DriverClass.spark.sql("select A.* from global_temp.DP A where A.PRODUCTID in( select B.PRODUCTID from global_temp.DPChangeStatus B  WHERE B.ChangeCode LIKE '%C%')")
      temp3=temp3.withColumn("RowStatus",lit(2))

      var temp4=DriverClass.spark.sql("select A.* from global_temp.DP A where A.PRODUCTID in( select B.PRODUCTID from global_temp.DPChangeStatus B  WHERE B.ChangeCode LIKE '%N%') AND A.PRODUCTID NOT IN (select B.PRODUCTID from global_temp.DPChangeStatus B  WHERE B.ChangeCode LIKE '%C%' )")
      temp4=temp4.withColumn("RowStatus",lit(0))

      DrugPricing=temp1.union(temp2)
      DrugPricing=DrugPricing.union(temp3)
      DrugPricing=DrugPricing.union(temp4)
      DrugPricing.createOrReplaceGlobalTempView("DrugPricing")
      print("Initial DP:"+DrugPricing.count())
      var CTE_DrugPricing=DrugPricing.filter(col("RowStatus")===2).groupBy("CostTypeCode","PRODUCTID").agg({"EffectiveDate"->"min"}).withColumnRenamed("min(EffectiveDate)","MinEffectiveDate")
      CTE_DrugPricing.createOrReplaceGlobalTempView("CTEDP")

      var STG_DrugPricing=DriverClass.spark.sql("select B.DrugPricingDimKey from global_temp.CTEDP A INNER JOIN global_temp.DimDP B\n ON  A.ProductID = B.ProductID AND\n   A.CostTypeCode = B.CostTypeCode AND \n   A.MinEffectiveDate > B.EffectiveDate WHERE B.CostTypeCode = 'WAC' AND\n   B.IsRowCurrent = 1 ")
      STG_DrugPricing=STG_DrugPricing.withColumn("RowStatus",lit(7))

      t1=DriverClass.spark.sql("select A.ProductID, A.RecordCode, A.CostTypeCode, A.TransactionCode, A.EffectiveDate, A.PackagePrice, A.UnitPrice, A.ETLRunID, A.RowStartDate, A.RowEndDate, A.IsRowCurrent, A.RowStatus, A.LastChangeDate, B.ZipFileName from global_temp.DrugPricing A INNER JOIN global_temp.DimDP B\n ON  A.ProductID = B.ProductID and A.IsRowCurrent = B.IsRowCurrent AND\n   A.CostTypeCode = B.CostTypeCode WHERE A.PackagePrice = B.PackagePrice AND \n   A.UnitPrice = B.UnitPrice AND \n   A.EffectiveDate = B.EffectiveDate  AND \n    (A.RowStatus=1 OR A.RowStatus =2)")
      t1=t1.withColumn("RowStatus",lit(6))

      STG_DrugPricing.cache()
      DrugPricing.cache()
      STG_DrugPricing=t1.orderBy("PRODUCTID","CostTypeCode","RecordCode")
      STG_DrugPricing=STG_DrugPricing.union(DrugPricing)
      STG_DrugPricing.createOrReplaceGlobalTempView("STGDPWAC")
      print("Initial stg wac:"+STG_DrugPricing.count())
      var update=DriverClass.spark.sql("select A.* from global_temp.STGDPWAC A \n  INNER JOIN global_temp.DimDP B\n   ON A.ProductID = B.ProductID AND \n    A.IsRowCurrent = B.IsRowCurrent AND\n    A.CostTypeCode = B.costTypeCode WHERE A.RowStatus = 1 AND\n  B.IsRowSkeleton = 1 AND A.RecordCode = 1 AND\n     B.CostTypeCode = 'DP'").withColumn("RowStatus",lit(4))
      update=update.select("ProductID","RecordCode","CostTypeCode","TransactionCode","EffectiveDate","PackagePrice","UnitPrice","ETLRunID","RowStartDate","RowEndDate","IsRowCurrent","RowStatus","LastChangeDate","ZipFileName")
      update.createOrReplaceGlobalTempView("UpdatedRows")

      STG_DrugPricing=DriverClass.spark.sql("select A.* from global_temp.STGDPWAC A where A.PRODUCTID NOT IN (Select B.PRODUCTID FROM global_temp.UpdatedRows B)")// A.ProductID=B.ProductID  and
      STG_DrugPricing.createOrReplaceGlobalTempView("STG_DrugPricing")
      STG_DrugPricing=DriverClass.spark.sql("select a.*,null as AWPIndicatorCode from global_temp.STG_DrugPricing a union select b.*,null as AWPIndicatorCode from global_temp.UpdatedRows b")
      STG_DrugPricing=STG_DrugPricing.select("PRODUCTID","CostTypeCode","RecordCode","PackagePrice","UnitPrice","AWPIndicatorCode","EffectiveDate","ETLRunID","RowStartDate","RowEndDate","RowStatus","ZipFileName","IsRowCurrent")
      t12=t12.withColumn("AWPIndicatorCode",lit(null).cast("string"))
      STG_DrugPricing=STG_DrugPricing.withColumn("AWPIndicatorCode",lit(null).cast("string"))
      t12=t12.withColumn("TransactionCode",lit("X"))
      STG_DrugPricing=STG_DrugPricing.withColumn("RecordCode",col("RecordCode").cast("int"))
      STG_DrugPricing=STG_DrugPricing.withColumn("EffectiveDate",col("EffectiveDate").cast("timestamp"))
      STG_DrugPricing=STG_DrugPricing.withColumn("PackagePrice",col("PackagePrice").cast("decimal(10,2)"))
      STG_DrugPricing=STG_DrugPricing.withColumn("UnitPrice",col("UnitPrice").cast("decimal(13,5)"))
      STG_DrugPricing=STG_DrugPricing.withColumn("IsRowCurrent",col("IsRowCurrent").cast("boolean"))
      STG_DrugPricing=STG_DrugPricing.select("PRODUCTID","RecordCode","CostTypeCode","TransactionCode","AWPIndicatorCode","EffectiveDate","PackagePrice","UnitPrice","ETLRunID","RowStartDate","RowEndDate","IsRowCurrent","RowStatus","LastChangeDate","ZipFileName")

      //t12=t12.select("PRODUCTID","CostTypeCode","RecordCode","PackagePrice","UnitPrice","AWPIndicatorCode","EffectiveDate","ETLRunID","RowStartDate","RowEndDate","RowStatus","ZipFileName","IsRowCurrent")
      STG_DrugPricing=STG_DrugPricing.withColumn("RowEndDate",to_timestamp(col("RowEndDate")))
      t12=t12.withColumn("TransactionCode",lit("X"))
      t12=t12.withColumn("RecordCode",col("RecordCode").cast("int"))
      t12=t12.withColumn("PackagePrice",col("PackagePrice").cast("decimal(10,2)"))
      t12=t12.withColumn("UnitPrice",col("UnitPrice").cast("decimal(13,5)"))
      t12=t12.withColumn("ETLRunID",col("ETLRunID").cast("int"))
      t12=t12.withColumn("IsRowCurrent",col("IsRowCurrent").cast("boolean"))
      //      t12.printSchema()
      t12=t12.select("PRODUCTID","RecordCode","CostTypeCode","TransactionCode","AWPIndicatorCode","EffectiveDate","PackagePrice","UnitPrice","ETLRunID","RowStartDate","RowEndDate","IsRowCurrent","RowStatus","LastChangeDate","ZipFileName")
      STG_DrugPricing.printSchema()
      t12.printSchema()
      STG_DrugPricing=STG_DrugPricing.union(t12)
      STG_DrugPricing=STG_DrugPricing.withColumn("RowStartDate",col("RowStartDate").cast("string"))
      STG_DrugPricing=STG_DrugPricing.withColumn("AWPIndicatorCode",lit(null).cast("string"))
      STG_DrugPricing.cache()
      STG_DrugPricing=STG_DrugPricing.withColumn("DrugPricingDimKey", lit(0))
      STG_DrugPricing=STG_DrugPricing.withColumn("DrugPricingDimKey", col("DrugPricingDimKey").cast("int"))
      print("Final stg wac:"+STG_DrugPricing.count())
      LoadUtil.writeJDBC(STG_DrugPricing, "STG_DrugPricing", SaveMode.Append)
      STG_DrugPricing.createOrReplaceGlobalTempView("STGDPWAC")
    }
    else {
      var STG_DrugPricing=DrugPricing.orderBy("PRODUCTID","CostTypeCode","RecordCode")
      STG_DrugPricing.createOrReplaceGlobalTempView("STGDPWAC")
      t1=DriverClass.spark.sql("select A.* from global_temp.STGDPWAC A \n  INNER JOIN global_temp.DimDP B\n   ON A.ProductID = B.ProductID AND \n    A.IsRowCurrent = B.IsRowCurrent AND\n    A.CostTypeCode = B.costTypeCode WHERE A.RowStatus = 1 AND\n  B.IsRowSkeleton = 1 AND A.RecordCode = 1 AND\n     B.CostTypeCode = 'WAC' ")
      t1 = t1.filter(col("RowStatus").isNotNull)
      t1=t1.drop("RowStatus")
      t1=t1.withColumn("RowStatus",lit(4))

      t2=STG_DrugPricing.intersect(t1)
      t2=t2.withColumn("RowStatus",lit(4))
      STG_DrugPricing=STG_DrugPricing.union(t1).except(t2)
      STG_DrugPricing=STG_DrugPricing.union(t2)
      STG_DrugPricing.cache()
      STG_DrugPricing.createOrReplaceGlobalTempView("STGDPWAC")
    }
  }
}
