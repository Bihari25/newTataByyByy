package com.optum.spark
import java.util.Properties

import org.apache.spark.sql.DataFrame

import scala.io.Source
object Sources {
  val url = getClass.getResource("/source.properties")
  val properties: Properties = new Properties()
  val source = Source.fromURL(url)
  properties.load(source.bufferedReader())

  def Raw_M25(zipFileName: String): DataFrame = {
    var df = DriverClass.spark.read.option("header", true).parquet(properties.getProperty("targetPath")+zipFileName+"/RAW_M25")
    //println(zipFileName)
    df.createOrReplaceGlobalTempView("M25")
    df
  }
  def Raw_M25SUM(zipFileName: String): DataFrame = {
    var df = DriverClass.spark.read.option("header", true).parquet(properties.getProperty("targetPath")+zipFileName+"/RAW_M25SUM/")
    df.createOrReplaceGlobalTempView("Raw_M25SUM")
    return df
  }
  def Raw_M25TCRF(zipFileName: String): DataFrame = {
    var df = DriverClass.spark.read.option("header", true).parquet(properties.getProperty("targetPath")+zipFileName+"/RAW_M25TCRF/")
    df.createOrReplaceGlobalTempView("Raw_M25TCRF")
    return df
  }
  def Raw_M25DICT(zipFileName: String): DataFrame = {
    var df = DriverClass.spark.read.option("header", true).parquet(properties.getProperty("targetPath")+zipFileName+"/RAW_M25DICT/")
    df.createOrReplaceGlobalTempView("Raw_M25DICT")
    return df
  }
  def Raw_M25ERR(zipFileName: String): DataFrame = {
    var df = DriverClass.spark.read.option("header", true).parquet(properties.getProperty("targetPath")+zipFileName+"/RAW_M25ERR/")
    df.createOrReplaceGlobalTempView("Raw_M25ERR")
    return df
  }
  def Raw_M25GPPC(zipFileName: String): DataFrame = {
    var df = DriverClass.spark.read.option("header", true).parquet(properties.getProperty("targetPath")+zipFileName+"/RAW_M25GPPC/")
    df.createOrReplaceGlobalTempView("Raw_M25GPPC")
    return df
  }
  def Raw_M25GPRR(zipFileName: String): DataFrame = {
    var df = DriverClass.spark.read.option("header", true).parquet(properties.getProperty("targetPath")+zipFileName+"/RAW_M25GPRR/")
    df.createOrReplaceGlobalTempView("Raw_M25GPPR")
    return df
  }
  def Raw_M25MOD(zipFileName: String): DataFrame = {
    var df = DriverClass.spark.read.option("header", true).parquet(properties.getProperty("targetPath")+zipFileName+"/RAW_M25MOD/")
    df.createOrReplaceGlobalTempView("Raw_M25MOD")
    return df
  }
  def Raw_M25NMOD(zipFileName: String): DataFrame = {
    var df = DriverClass.spark.read.option("header", true).parquet(properties.getProperty("targetPath")+zipFileName+"/RAW_M25NMOD/")
    df.createOrReplaceGlobalTempView("Raw_M25NMOD")
    return df
  }
  def Raw_M25VAL(zipFileName: String): DataFrame = {
    var df = DriverClass.spark.read.option("header", true).parquet(properties.getProperty("targetPath")+zipFileName+"/RAW_M25VAL/")
    df.createOrReplaceGlobalTempView("Raw_M25VAL")
    return df
  }
}
