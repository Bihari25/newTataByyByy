package com.optum.spark

import org.apache.spark.sql.SaveMode
import org.apache.spark.sql.functions._
object DrugPricingAWP {

  def run(ETLRunID:Int,ZipFileName:String,IsIncremental:Int): Unit = {

    var dfM25 = Sources.Raw_M25(ZipFileName)
    dfM25.createOrReplaceGlobalTempView("M25")
    var i1 = Views.M25A()
    var df=DriverClass.spark.sql(i1)
    df.createOrReplaceGlobalTempView("M25A")

    var i=Views.M25R()
    var R_df=DriverClass.spark.sql(i)
    R_df = R_df.drop("RecordData")

    R_df.createOrReplaceGlobalTempView("M25R")

    //Step 2
    var R_dfAWP = R_df.filter(col("AWPPackagePrice").isNotNull)
    var t1=R_dfAWP.filter(col("RecordCode")==="R01").withColumn("RecordCode",lit(1))
    var t2=R_dfAWP.filter(col("RecordCode")==="R02").withColumn("RecordCode",lit(3))
    var t3=R_dfAWP.filter(col("RecordCode")==="R03").withColumn("RecordCode",lit(5))
    R_dfAWP=t1.union(t2)
    R_dfAWP=R_dfAWP.union(t3)
    R_dfAWP=R_dfAWP.withColumn("CostTypeCode",lit("AWP"))
    R_dfAWP=R_dfAWP.withColumn("RowStartDate",col("LastChangeDate"))
    R_dfAWP=R_dfAWP.withColumn("RowEndDate",lit("2078-12-31"))
    R_dfAWP=R_dfAWP.withColumn("IsRowCurrent",lit("1"))
    R_dfAWP=R_dfAWP.withColumn("RowStatus",lit(""))
    R_dfAWP=R_dfAWP.drop("OlderAWPPackagePrice","OlderAWPUnitPrice","OlderAWPEffectiveDate","ProductIDFormatCode")
    R_dfAWP=R_dfAWP.withColumnRenamed("AWPPackagePrice","PackagePrice").withColumnRenamed("AWPUnitPrice","UnitPrice").withColumnRenamed("AWPEffectiveDate","EffectiveDate")


    //step 3
    var R_dfAWPOld = R_df.filter(col("OlderAWPUnitPrice")=!="NULL")
    t1=R_dfAWPOld.filter(col("RecordCode")==="R01").withColumn("RecordCode",lit(2))
    t2=R_dfAWPOld.filter(col("RecordCode")==="R02").withColumn("RecordCode",lit(4))
    t3=R_dfAWPOld.filter(col("RecordCode")==="R03").withColumn("RecordCode",lit(6))
    R_dfAWPOld=t1.union(t2)
    R_dfAWPOld=R_dfAWPOld.union(t3)
    R_dfAWPOld=R_dfAWPOld.withColumn("CostTypeCode",lit("AWP"))
    R_dfAWPOld=R_dfAWPOld.withColumn("RowStartDate",col("LastChangeDate"))
    R_dfAWPOld=R_dfAWPOld.withColumn("RowEndDate",lit("2078-12-31"))
    R_dfAWPOld=R_dfAWPOld.withColumn("IsRowCurrent",lit("1"))
    R_dfAWPOld=R_dfAWPOld.withColumn("RowStatus",lit(0))
    R_dfAWPOld=R_dfAWPOld.drop("AWPPackagePrice","AWPUnitPrice","AWPEffectiveDate","ProductIDFormatCode")
    R_dfAWPOld=R_dfAWPOld.withColumnRenamed("OlderAWPPackagePrice","PackagePrice").withColumnRenamed("OlderAWPUnitPrice","UnitPrice").withColumnRenamed("OlderAWPEffectiveDate","EffectiveDate")
    var DrugPricing=DriverClass.spark.sqlContext.emptyDataFrame
    DrugPricing=R_dfAWP.union(R_dfAWPOld)

    if(IsIncremental==1)
    {
      t1=DriverClass.spark.sql("Select distinct A.PRODUCTID,A.LastChangeDate AS EffectiveDate,A.LastChangeDate AS RowStartDate,A.LastChangeDate AS RowEndDate,A.LastChangeDate,A.ZipFileName as ZipFileName  from global_temp.M25A A LEFT JOIN global_temp.M25R B ON A.ProductID = B.ProductID AND A.LastChangeDate = B.LastChangeDate WHERE A.TransactionCode = 'D' AND B.RecordCode IS NULL AND\n    A.ProductID IN (SELECT ProductID \n        FROM global_temp.DimDP\n        WHERE IsRowCurrent = 1 AND CostTypeCode = 'AWP') ")
      t1=t1.withColumn("RecordCode",lit("1"))
      t1=t1.withColumn("CostTypeCode",lit("AWP"))
      t1=t1.withColumn("TransactionCode",lit("X"))
      t1=t1.withColumn("ETLRunID",lit(ETLRunID))
      t1=t1.withColumn("AWPIndicatorCode",lit("A"))
      t1=t1.withColumn("PackagePrice",lit(0))
      t1=t1.withColumn("UnitPrice",lit(0))
      t1=t1.withColumn("IsRowCurrent",lit(1))
      t1=t1.withColumn("RowStatus",lit(3))
      val aa=t1
      t1=t1.select("ProductID","RecordCode","CostTypeCode","TransactionCode","AWPIndicatorCode","EffectiveDate","PackagePrice","UnitPrice","ETLRunID","RowStartDate","RowEndDate","IsRowCurrent","RowStatus","LastChangeDate","ZipFileName")

      t2=DriverClass.spark.sql("Select distinct A.PRODUCTID,A.LastChangeDate AS EffectiveDate,A.LastChangeDate AS RowStartDate,A.LastChangeDate AS RowEndDate,A.LastChangeDate AS LastChangeDate,A.ZipFileName as ZipFileName from global_temp.M25A A LEFT JOIN global_temp.M25R B ON A.ProductID = B.ProductID AND A.LastChangeDate = B.LastChangeDate WHERE  A.TransactionCode IN ('C', '') AND B.RecordCode IS NULL AND   A.ProductID IN (SELECT ProductID       FROM global_temp.DimDP       WHERE IsRowCurrent = 1 AND CostTypeCode = 'AWP') ")
      t2=t2.withColumn("RecordCode",lit("1"))
      t2=t2.withColumn("CostTypeCode",lit("AWP"))
      t2=t2.withColumn("TransactionCode",lit("X"))
      t2=t2.withColumn("AWPIndicatorCode",lit("A"))
      t2=t2.withColumn("ETLRunID",lit(ETLRunID))
      t2=t2.withColumn("PackagePrice",lit(0))
      t2=t2.withColumn("UnitPrice",lit(0))
      t2=t2.withColumn("IsRowCurrent",lit(1))
      t2=t2.withColumn("RowStatus",lit(5))
      val bb=t2
      t2=t2.select("ProductID","RecordCode","CostTypeCode","TransactionCode","AWPIndicatorCode","EffectiveDate","PackagePrice","UnitPrice","ETLRunID","RowStartDate","RowEndDate","IsRowCurrent","RowStatus","LastChangeDate","ZipFileName")

      var t12=aa.union(bb)
      DrugPricing=DrugPricing.drop("ETLStatus","ETLErrorCount","FileImportID")
      DrugPricing=DrugPricing.withColumn("ZipFileName",lit(ZipFileName))
      DrugPricing=DrugPricing.withColumn("ETLRunID",lit(ETLRunID))
      DrugPricing=DrugPricing.select("ProductID","RecordCode","CostTypeCode","TransactionCode","AWPIndicatorCode","EffectiveDate","PackagePrice","UnitPrice","ETLRunID","RowStartDate","RowEndDate","IsRowCurrent","RowStatus","LastChangeDate","ZipFileName")

      DrugPricing=DrugPricing.union(t1)
      DrugPricing=DrugPricing.union(t2)
      DrugPricing.createOrReplaceGlobalTempView("OldDP")

      var drugPricingChangeStatus = DriverClass.spark.sqlContext.emptyDataFrame
      drugPricingChangeStatus=DrugPricing.filter(col("TransactionCode")=!="X").select("PRODUCTID","RecordCode","TransactionCode")
      var t=drugPricingChangeStatus.filter(col("TransactionCode")===" ")
      t=t.withColumn("TransactionCode",lit("N"))//\"\"
      drugPricingChangeStatus=drugPricingChangeStatus.filter(col("TransactionCode")=!=" ")
      drugPricingChangeStatus=drugPricingChangeStatus.union(t)

      var e="concat(LTRIM(RTRIM(RecordCode)),TransactionCode)"
      drugPricingChangeStatus= drugPricingChangeStatus.withColumn("ChangeCode",expr(e))
      drugPricingChangeStatus.createOrReplaceGlobalTempView("DrugPricingChangeStatus")

      DrugPricing.createOrReplaceGlobalTempView("DrugPricing")

      var temp1=DriverClass.spark.sql("select A.* from global_temp.DrugPricing A where A.PRODUCTID in( select B.PRODUCTID from global_temp.DrugPricingChangeStatus B  WHERE B.ChangeCode LIKE '%D%')")
      temp1=temp1.withColumn("RowStatus",lit(3))
      temp1=temp1.withColumn("RowEndDate",col("RowStartDate"))

      var temp2=DriverClass.spark.sql("select A.* from global_temp.DrugPricing A where A.PRODUCTID in( select B.PRODUCTID from global_temp.DrugPricingChangeStatus B WHERE B.ChangeCode LIKE '%A%')")
      temp2=temp2.withColumn("RowStatus",lit("1"))

      var temp3=DriverClass.spark.sql("select A.* from global_temp.DrugPricing A where A.PRODUCTID in( select B.PRODUCTID from global_temp.DrugPricingChangeStatus B WHERE B.ChangeCode LIKE '%C%')")
      temp3=temp3.withColumn("RowStatus",lit("2"))

      var temp4=DriverClass.spark.sql("select A.* from global_temp.DrugPricing A where A.PRODUCTID in( select B.PRODUCTID from global_temp.DrugPricingChangeStatus B  WHERE B.ChangeCode LIKE '%N%') AND A.PRODUCTID NOT IN (select B.PRODUCTID from global_temp.DrugPricingChangeStatus B  WHERE B.ChangeCode LIKE '%C%' )")
      temp4=temp4.withColumn("RowStatus",lit("0"))

      DrugPricing=temp1.union(temp2)
      DrugPricing=DrugPricing.union(temp3)
      DrugPricing=DrugPricing.union(temp4)
      DrugPricing.createOrReplaceGlobalTempView("DrugPricing")

      var CTE_DrugPricing=DrugPricing.filter(col("RowStatus")===2).groupBy("CostTypeCode","PRODUCTID").agg({"EffectiveDate"->"min"}).withColumnRenamed("min(EffectiveDate)","MinEffectiveDate")

      var ex ="concat(substring(MinEffectiveDate,0,4),\"-\",substring(MinEffectiveDate,5,2),\"-\",substring(MinEffectiveDate,7,2))"
      CTE_DrugPricing=CTE_DrugPricing.withColumn("MinEffectiveDate",expr(ex))
      CTE_DrugPricing=CTE_DrugPricing.withColumn("MinEffectiveDate",col("MinEffectiveDate").cast("timestamp").cast("date"))
      CTE_DrugPricing.createOrReplaceGlobalTempView("CTEDP")

      var STG_DrugPricing=DriverClass.spark.sql("select A.*,B.* from global_temp.CTEDP A JOIN global_temp.DimDP B ON  TRIM(A.PRODUCTID) = TRIM(B.PRODUCTID) AND  TRIM(A.CostTypeCode) = TRIM(B.CostTypeCode)  AND  DATE(A.MinEffectiveDate) > DATE(B.EffectiveDate) WHERE B.CostTypeCode = 'AWP' AND  B.IsRowCurrent = 1 ")//HERE B.CostTypeCode = 'AWP' AND  B.IsRowCurrent = 1 ")// AND  DATE(A.MinEffectiveDate) > DATE(B.EffectiveDate)
      STG_DrugPricing=STG_DrugPricing.withColumn("RowStatus",lit(7))
      STG_DrugPricing=STG_DrugPricing.select("A.PRODUCTID","A.CostTypeCode","B.EffectiveDate","PackagePrice","UnitPrice","ETLRunID","RowStartDate","RowEndDate","IsRowCurrent","RowStatus","ZipFileName")
      STG_DrugPricing.createOrReplaceGlobalTempView("Temp")
      STG_DrugPricing=DriverClass.spark.sql("Select A.*,B.RecordCode,B.TransactionCode,DATE(B.LastChangeDate) from global_temp.Temp A left join global_temp.OldDP B where A.PRODUCTID=B.PRODUCTID " )
      STG_DrugPricing=STG_DrugPricing.select("PRODUCTID","RecordCode","CostTypeCode","TransactionCode","EffectiveDate","PackagePrice","UnitPrice","ETLRunID","RowStartDate","RowEndDate","IsRowCurrent","RowStatus","LastChangeDate","ZipFileName")

      DrugPricing=DrugPricing.withColumn("EffectiveDate",to_timestamp(col("EffectiveDate"),"yyyyMMdd"))
      DrugPricing=DrugPricing.withColumn("UnitPrice",col("UnitPrice").cast("decimal(13,5)"))
      DrugPricing=DrugPricing.withColumn("PackagePrice",col("PackagePrice").cast("decimal(10,2)"))
      DrugPricing=DrugPricing.withColumn("IsRowCurrent",col("IsRowCurrent").cast("boolean"))
      DrugPricing=DrugPricing.withColumn("RecordCode",col("RecordCode").cast("int"))

      t1=DriverClass.spark.sql("select A.ProductID, A.RecordCode, A.CostTypeCode, A.TransactionCode, A.AWPIndicatorCode, A.EffectiveDate, A.PackagePrice, A.UnitPrice, A.ETLRunID, A.RowStartDate, A.RowEndDate, A.IsRowCurrent, A.RowStatus, A.LastChangeDate, B.ZipFileName from global_temp.DrugPricing A INNER JOIN global_temp.DimDP B ON  TRIM(A.ProductID) = TRIM(B.ProductID) and TRIM(A.IsRowCurrent) = TRIM(B.IsRowCurrent) AND TRIM(A.CostTypeCode) = TRIM(B.CostTypeCode) WHERE (A.PackagePrice) = (B.PackagePrice) AND (A.UnitPrice) = (B.UnitPrice) AND  DATE(A.EffectiveDate) = DATE(B.EffectiveDate) ")
      t1=t1.withColumn("RowStatus",lit(6))
      t1.createOrReplaceGlobalTempView("t1")

      STG_DrugPricing=t1.orderBy("PRODUCTID","CostTypeCode","RecordCode")
      STG_DrugPricing=STG_DrugPricing.withColumn("EffectiveDate",to_timestamp(col("EffectiveDate"),"yyyyMMdd"))
      STG_DrugPricing=STG_DrugPricing.withColumn("UnitPrice",col("UnitPrice").cast("decimal(13,5)"))
      STG_DrugPricing=STG_DrugPricing.withColumn("PackagePrice",col("PackagePrice").cast("decimal(10,2)"))
      STG_DrugPricing=STG_DrugPricing.withColumn("IsRowCurrent",col("IsRowCurrent").cast("boolean"))
      STG_DrugPricing=STG_DrugPricing.withColumn("RecordCode",col("RecordCode").cast("int"))

      DrugPricing=DrugPricing.withColumn("RowStatus",col("RowStatus").cast("int"))

      STG_DrugPricing=STG_DrugPricing.union(DrugPricing)
      STG_DrugPricing=STG_DrugPricing.withColumn("RowEndDate",to_timestamp(col("RowEndDate")))
      t12=t12.withColumn("TransactionCode",lit("X"))
      t12=t12.withColumn("RecordCode",col("RecordCode").cast("int"))
      t12=t12.withColumn("PackagePrice",col("PackagePrice").cast("decimal(10,2)"))
      t12=t12.withColumn("UnitPrice",col("UnitPrice").cast("decimal(13,5)"))
      t12=t12.withColumn("ETLRunID",col("ETLRunID").cast("int"))
      t12=t12.withColumn("IsRowCurrent",col("IsRowCurrent").cast("boolean"))
      //      t12.printSchema()
      t12=t12.select("PRODUCTID","RecordCode","CostTypeCode","TransactionCode","AWPIndicatorCode","EffectiveDate","PackagePrice","UnitPrice","ETLRunID","RowStartDate","RowEndDate","IsRowCurrent","RowStatus","LastChangeDate","ZipFileName")
      STG_DrugPricing.printSchema()
      t12.printSchema()
      STG_DrugPricing=STG_DrugPricing.union(t12)
      STG_DrugPricing=STG_DrugPricing.withColumn("RowStatus",col("RowStatus").cast("int"))
      STG_DrugPricing=STG_DrugPricing.withColumn("IsRowCurrent",col("IsRowCurrent").cast("int"))
      STG_DrugPricing=STG_DrugPricing.select("PRODUCTID","CostTypeCode","RecordCode","PackagePrice","UnitPrice","AWPIndicatorCode","EffectiveDate","ETLRunID","RowStartDate","RowEndDate","RowStatus","ZipFileName","IsRowCurrent")
      STG_DrugPricing.cache()
      STG_DrugPricing=STG_DrugPricing.withColumn("DrugPricingDimKey", lit(0))
      STG_DrugPricing=STG_DrugPricing.withColumn("DrugPricingDimKey", col("DrugPricingDimKey").cast("int"))

      LoadUtil.writeJDBC(STG_DrugPricing, "STG_DrugPricing", SaveMode.Overwrite)

      STG_DrugPricing.createOrReplaceGlobalTempView("STGDPAWP")
    }
    else
    {
      var STG_DrugPricing=DrugPricing.orderBy("PRODUCTID","CostTypeCode","RecordCode")
      STG_DrugPricing.createOrReplaceGlobalTempView("STGDPAWP")
      t1=DriverClass.spark.sql("select A.* from global_temp.STGDPAWP A  INNER JOIN global_temp.DimDP B  ON A.ProductID = B.ProductID AND \n    A.IsRowCurrent = B.IsRowCurrent AND\n    A.CostTypeCode = B.costTypeCode WHERE A.RowStatus = 1 AND\n  B.IsRowSkeleton = 1 AND A.RecordCode = 1 AND\n     B.CostTypeCode = 'AWP' ")
      t1 = t1.filter(col("RowStatus").isNotNull)
      t1=t1.drop("RowStatus")
      t1=t1.withColumn("RowStatus",lit(4))

      t2=STG_DrugPricing.intersect(t1)
      t2=t2.withColumn("RowStatus",lit(4))

      STG_DrugPricing=STG_DrugPricing.union(t1).except(t2)
      STG_DrugPricing=STG_DrugPricing.union(t2)
      STG_DrugPricing=STG_DrugPricing.drop("AWPIndicatorCode")
      STG_DrugPricing.createOrReplaceGlobalTempView("STGDPAWP")
    }
  }
}
