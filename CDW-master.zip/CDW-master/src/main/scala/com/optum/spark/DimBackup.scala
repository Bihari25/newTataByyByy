package com.optum.spark

import java.util.Calendar

import org.apache.spark.sql.SaveMode

object DimBackup {
  def runProcess(): Unit = {
    val Dim_DrugGPIClassification = LoadUtil.readJDBC("Dim_DrugGPIClassification")
    LoadUtil.writeJDBC(Dim_DrugGPIClassification, "Dim_DrugGPIClassification_backup", SaveMode.Overwrite)

    val Dim_DrugItem = LoadUtil.readJDBC("Dim_DrugItem")
    LoadUtil.writeJDBC(Dim_DrugItem, "Dim_DrugItem_backup", SaveMode.Overwrite)

    val Dim_DrugPricing = LoadUtil.readJDBC("Dim_DrugPricing")
    LoadUtil.writeJDBC(Dim_DrugPricing, "Dim_DrugPricing_backup", SaveMode.Overwrite)

    val Dim_Drug = LoadUtil.readJDBC("Dim_Drug")
    LoadUtil.writeJDBC(Dim_Drug, "Dim_Drug_bkp", SaveMode.Overwrite)

    DriverClass.log.info("Dim Tables Backup process completed at "+Calendar.getInstance().getTime())
  }


}
