package com.optum.spark
import java.util.Properties

import org.apache.spark.sql._
import org.apache.spark.sql.functions._

import scala.io.Source
object DrugPricingAAWP {
  def run(ETLRunID:Int,ZipFileName:String,IsIncremental:Int): Unit = {
    var dfM25 = Sources.Raw_M25(ZipFileName)
    dfM25.createOrReplaceGlobalTempView("M25")
    val url = getClass.getResource("/source.properties")
    val properties: Properties = new Properties()
    val source = Source.fromURL(url)
    properties.load(source.bufferedReader())
    var i = Views.M25A()
    var df = DriverClass.spark.sql(i)
    df.createOrReplaceGlobalTempView("Raw_M25A")
    var ChangeDatedf = df.select("LastChangeDate").agg({
      "LastChangeDate" -> "max"
    }).withColumnRenamed("max(LastChangeDate)", "MaxLastChangeDate")

    var Dim_DP = LoadUtil.readJDBC("Dim_DrugPricing")

    Dim_DP=Dim_DP.withColumn("RowStatus",lit(0))
    Dim_DP.createOrReplaceGlobalTempView("DimDP")

    var ChangeDate = ChangeDatedf.head.get(0).toString

    var Dim_DrugItem=LoadUtil.readJDBC("Dim_DrugItem")

    //    var Dim_DrugItemPartial=LoadUtil.readJDBC("(SELECT * FROM Dim_DrugItem WHERE IsRowCurrent = 1 AND GenericProductName NOT LIKE '%*%' AND (RepackageCode <> 'X' or RepackageCode IS NULL) AND  (ClinicPackCode <> 'Y' or ClinicPackCode IS NULL) and ItemStatusFlag = 'A'  and  OldProductID IS NOT NULL) temp")
    var Dim_DrugItemPartial=DriverClass.spark.read
      .format("jdbc")
      .option("driver", properties.getProperty("azureDriver"))
      .option("url", properties.getProperty("azureUrl"))
      .option("user", properties.getProperty("azureUser"))
      .option("dbtable", "(SELECT * FROM medispan.Dim_DrugItem WHERE IsRowCurrent = 1 AND GenericProductName NOT LIKE '%*%' AND (RepackageCode <> 'X' or RepackageCode IS NULL) AND  (ClinicPackCode <> 'Y' or ClinicPackCode IS NULL) and ItemStatusFlag = 'A'  and  OldProductID IS NOT NULL) temp")
      .option("password", properties.getProperty("azurePassword"))
      .load()
    Dim_DrugItem.cache()
    Dim_DrugItem.createOrReplaceGlobalTempView("DimDrugItem")
    Dim_DrugItemPartial.createOrReplaceGlobalTempView("Dim_DrugItemPartial")

    var OldNDC = DriverClass.spark.read
      .format("jdbc")
      .option("driver",properties.getProperty("azureDriver"))
      .option("url", properties.getProperty("azureUrl"))
      .option("user", properties.getProperty("azureUser"))
      .option("dbtable", "(SELECT distinct OldProductID FROM medispan.Dim_DrugItem WHERE IsRowCurrent = 1 AND GenericProductName NOT LIKE '%*%' AND (RepackageCode <> 'X' or RepackageCode IS NULL) AND  (ClinicPackCode <> 'Y' or ClinicPackCode IS NULL) and ItemStatusFlag = 'A' and  OldProductID IS NOT NULL) temp")
      .option("password", properties.getProperty("azurePassword"))
      .load()
      .select("OldProductID").distinct()
    OldNDC.cache()
    OldNDC.createOrReplaceGlobalTempView("OldNDC")

    var M25gprr=Sources.Raw_M25GPRR(ZipFileName)
    M25gprr.cache()
    M25gprr.createOrReplaceGlobalTempView("Raw_M25GPRR")

    var GPI=DriverClass.spark.sql("SELECT GenericProductID, COUNT(*) AS Count, 1 AS Included from  global_temp.DimDrugItem WHERE MultiSourceCode = 'Y' AND IsRowCurrent = 1 GROUP BY GenericProductID HAVING  COUNT(*) > 1")
    GPI.cache()
    GPI=GPI.filter(!col("GenericProductID").like("9[4678]%")&& col("GenericProductID").like("970510%")|| !col("GenericProductID").like("%*%"))

    var t=GPI.filter(col("GenericProductID").like("9[4678]%")&& !col("GenericProductID").like("970510%")|| col("GenericProductID").like("%*%"))
    t=t.withColumn("Included",lit(0))
    GPI=GPI.union(t)
    GPI.createOrReplaceGlobalTempView("gpi")
    //TRIM(A.ProductID) NOT IN (SELECT TRIM(O.OldProductID) FROM global_temp.OldNDC O) AND

    var temp=DriverClass.spark.sql("Select A.PRODUCTID,gprr.TransactionCode,gprr.GPPCEffectiveDate as EffectiveDate,gprr.GPPCUnitPrice,gprr.ZipFileName from global_temp.Dim_DrugItemPartial A JOIN global_temp.Raw_M25GPRR gprr ON A.GenericProductPackagingCode=gprr.GenericProductPackagingCode AND gprr.GPPCPriceCode = 1 WHERE  TRIM(A.GenericProductID) IN (SELECT TRIM(G.GenericProductID) FROM global_temp.gpi G where Included=1) ")
    temp=temp.withColumn("RecordCode",lit(1))
    temp=temp.withColumn("CostTypeCode",lit("AAWP"))
    temp=temp.withColumn("ZipFileName",lit(ZipFileName))
    temp=temp.withColumn("PackagePrice",lit(0))
    temp=temp.withColumn("IsRowCurrent",lit(1))
    temp=temp.withColumn("RowStatus",lit(1))
    temp=temp.withColumn("RowStartDate",lit(ChangeDate))
    temp=temp.withColumn("LastChangeDate",lit(ChangeDate))
    temp=temp.withColumn("RowEndDate",lit("2078-12-31"))
    temp=temp.withColumn("ETLRunID",lit(ETLRunID))
    var e="concat(substring(GPPCUnitPrice,1,8),\".\",substring(GPPCUnitPrice,9,5))"
    temp=temp.withColumn("UnitPrice",expr(e))
    temp=temp.drop("GPPCUnitPrice")
    temp=temp.select("ProductID","RecordCode","CostTypeCode","TransactionCode","EffectiveDate","PackagePrice","UnitPrice","ETLRunID","RowStartDate","RowEndDate","IsRowCurrent","RowStatus","LastChangeDate","ZipFileName")

    var DrugPricing=temp
    DrugPricing.select("TransactionCode").distinct().show()
    var STG_DrugPricing=DriverClass.spark.sqlContext.emptyDataFrame
    if(IsIncremental==1)
    {
      var t1=DrugPricing.filter(col("TransactionCode").like("%D%"))
      t1=t1.withColumn("RowEndDate",col("RowStartDate"))
      t1=t1.withColumn("RowStatus",lit(3))
      var t2=DrugPricing.filter(col("TransactionCode").like("%A%"))
      t2=t2.withColumn("RowStatus",lit(1))
      var t3=DrugPricing.filter(col("TransactionCode").like("%C%"))
      //t3.show()
      t3=t3.withColumn("RowStatus",lit(2))
      var t4=DrugPricing.filter(col("TransactionCode").like(" "))
      t4=t4.withColumn("RowStatus",lit(0))
      DrugPricing=t1.union(t2)
      DrugPricing=DrugPricing.union(t3)
      DrugPricing=DrugPricing.union(t4)

      STG_DrugPricing=DrugPricing.orderBy("PRODUCTID","CostTypeCode","RecordCode")
    }
    else
    {
      DrugPricing=DrugPricing.withColumn("RowStatus",lit(1))
      STG_DrugPricing=DrugPricing.orderBy("PRODUCTID","CostTypeCode","RecordCode")
    }
    STG_DrugPricing.createOrReplaceGlobalTempView("STGDPAAWP")
    STG_DrugPricing.cache()
    var update=DriverClass.spark.sql("select A.* from global_temp.STGDPAAWP A \n  INNER JOIN global_temp.DimDP B\n   ON A.ProductID = B.ProductID AND \n    A.IsRowCurrent = B.IsRowCurrent AND\n    A.CostTypeCode = B.costTypeCode WHERE A.RowStatus = 1 AND\n  B.IsRowSkeleton = 1 AND A.RecordCode = 1 AND\n     B.CostTypeCode = 'DP'").withColumn("RowStatus",lit(4))
    update=update.select("ProductID","RecordCode","CostTypeCode","TransactionCode","EffectiveDate","PackagePrice","UnitPrice","ETLRunID","RowStartDate","RowEndDate","IsRowCurrent","RowStatus","LastChangeDate","ZipFileName")
    update.cache()
    update.createOrReplaceGlobalTempView("UpdatedRows")
    STG_DrugPricing=DriverClass.spark.sql("select A.* from global_temp.STGDPAAWP A where A.PRODUCTID NOT IN (Select B.PRODUCTID FROM global_temp.UpdatedRows B)")// A.ProductID=B.ProductID  and
    STG_DrugPricing=STG_DrugPricing.union(update)
    STG_DrugPricing=STG_DrugPricing.withColumn("AWPIndicatorCode",lit(null).cast("string"))
    STG_DrugPricing=STG_DrugPricing.withColumn("RecordCode",col("RecordCode").cast("string"))
    STG_DrugPricing=STG_DrugPricing.withColumn("PackagePrice",col("PackagePrice").cast("string"))
    STG_DrugPricing=STG_DrugPricing.select("PRODUCTID","CostTypeCode","RecordCode","PackagePrice","UnitPrice","AWPIndicatorCode","EffectiveDate","ETLRunID","RowStartDate","RowEndDate","RowStatus","ZipFileName","IsRowCurrent")
    STG_DrugPricing=STG_DrugPricing.withColumn("DrugPricingDimKey", lit(0))
    STG_DrugPricing=STG_DrugPricing.withColumn("DrugPricingDimKey", col("DrugPricingDimKey").cast("int"))

    LoadUtil.writeJDBC(STG_DrugPricing, "STG_DrugPricing", SaveMode.Append)
  }
}