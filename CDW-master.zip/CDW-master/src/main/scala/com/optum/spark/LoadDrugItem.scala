package com.optum.spark

import java.io.FileWriter
import java.util.Properties

import org.apache.logging.log4j.LogManager

import scala.io.Source
object LoadDrugItem {

  val spark = DriverClass.spark

  val url = getClass.getResource("/source.properties")
  val properties: Properties = new Properties()
  val source = Source.fromURL(url)
  properties.load(source.bufferedReader())

  val df = spark.read.option("header", true).csv(properties.getProperty("rootPath") +"ETLRunId.txt")
  val ETLRunID = df.select("PreviousID").head().get(0).toString.toInt + 1

//  val log = LogManager.getLogger(this.getClass.getName)

  def runProcess(ZipFileName: String): Unit = {

    DrugItem.Implementation(ZipFileName,ETLRunID,1)
  }
}

