package com.optum.spark
import java.sql.{Connection, DriverManager}
import java.util.Properties

import scala.io.Source
object DbScalaDrugItem {

  val url = getClass.getResource("/source.properties")
  val properties: Properties = new Properties()
  val source = Source.fromURL(url)
  properties.load(source.bufferedReader())
    def runQueries() :(Int,Int,Int,Int,Int) = {

      var connection:Connection = null
      var  Inserted=0
      var  Updated=0
      var  Deleted=0
      var  Ignored=0
      var  Infered=0

      try {

        Class.forName(properties.getProperty("azureDriver"))
        connection = DriverManager.getConnection(properties.getProperty("azureUrl"), properties.getProperty("azureUser"), properties.getProperty("azurePassword"))

        val MergeQuery1="update " +"medispan.Dim_DrugItem"+" SET  RowEndDate = DATEADD(day, -1, s.RowStartDate),  IsRowCurrent = 0, NotCurrentReason = 'C' FROM " +"medispan.Dim_DrugItem"+" d join "+"medispan.STG_DrugItem"+" s on d.PRODUCTID = s.PRODUCTID WHERE   d.IsRowCurrent = 1 AND   s.rowstatus in (1,2)   "
        val MergeQuery2="update  " +"medispan.Dim_DrugItem"+" set ProductIDFormatCode = s.ProductIDFormatCode, ProductName = s.ProductName, AllergyPatternCode = s.AllergyPatternCode, PPGIndicatorCode = s.PPGIndicatorCode, HFPGIndicatorCode = s.HFPGIndicatorCode, LabelerTypeCode = s.LabelerTypeCode, PricingSpreadCode = s.PricingSpreadCode, SequenceCode = s.SequenceCode, ManufacturerName = s.ManufacturerName, ManufacturerAbbreviatedName = s.ManufacturerAbbreviatedName, GenericIDTypeCode = s.GenericIDTypeCode, GenericIDNumber = s.GenericIDNumber, DEAClassCode = s.DEAClassCode, AHFSTherapeuticClassCode = s.AHFSTherapeuticClassCode, ItemStatusFlag = s.ItemStatusFlag, LocalSystemicFlag = s.LocalSystemicFlag, TEECode = s.TEECode, FormattedIDNumber = s.FormattedIDNumber, RXOTCIndicatorCode = s.RXOTCIndicatorCode, ThirdPartyRestrictionCode = s.ThirdPartyRestrictionCode, MaintenanceDrugCode = s.MaintenanceDrugCode, DispensingUnitCode = s.DispensingUnitCode, PackageCode = s.UnitOfUsePackageCode, RouteofAdministration = s.RouteofAdministration, FormTypeCode = s.FormTypeCode, DollarRankCode = s.DollarRankCode, RxRankCode = s.RxRankCode, NumberSystemCharacter = s.NumberSystemCharacter, SecondaryIDNumber = s.SecondaryIDNumber, MultiSourceCode = s.MultiSourceCode, BrandNameCode = s.BrandNameCode, ReimbursementIndicator = s.ReimbursementIndicator, InternalExternalCode = s.InternalExternalCode, SingleCombinationCode = s.SingleCombinationCode, StorageConditionCode = s.StorageConditionCode, LimitedStabilityCode = s.LimitedStabilityCode, ProductDescriptionAbbreviation = s.ProductDescriptionAbbreviation, DrugNameCode = s.DrugNameCode, GenericProductID = s.GenericProductID, GenericProductName = s.GenericProductName, GenericProductPackagingCode = s.GenericProductPackagingCode, DosageForm = s.DosageForm, PackageSize = s.PackageSize, UnitOfMeasure = s.UnitOfMeasure, PackageQuantity = s.PackageQuantity, RepackageCode = s.RepackageCode, TotalPackageQuantity = s.TotalPackageQuantity, DESICode = s.DESICode, PackageDescription = s.PackageDescription, NextSmallerNDCSuffixNumber = s.NextSmallerNDCSuffixNumber, NextLargerNDCSuffixNumber = s.NextLargerNDCSuffixNumber, InnerpackCode = s.InnerpackCode, ClinicPackCode = s.ClinicPackCode, MetricStrength = s.MetricStrength, StrengthUnitofMeasure = s.StrengthUnitofMeasure, LimitedDistributionCode = s.LimitedDistributionCode, ExtendedAHFSTherapeuticClassCode = s.ExtendedAHFSTherapeuticClassCode, InactiveDate = s.InactiveDate, OldProductID = s.OldProductID, OldEffectiveDate = s.OldEffectiveDate, NewProductID = s.NewProductID, NewEffectiveDate = s.NewEffectiveDate, ETLRunID = s.ETLRunID, RowStartDate = s.RowStartDate, RowEndDate = s.RowEndDate, ZipFileName = s.ZipFileName, DrugCategory = s.DrugCategory, DrugGroup = s.DrugGroup, DrugClass = s.DrugClass, DrugSubclass = s.DrugSubclass, DrugName  = s.DrugName , LabelerCode = s.LabelerCode, SecondaryIDFormatCode = s.SecondaryIDFormatCode, IsRowSkeleton = 0 from  " +"medispan.Dim_DrugItem"+" d join  "+"medispan.STG_DrugItem"+"   s on d.productid = s.productid  where    d.IsRowCurrent = 1 AND   s.rowstatus in (4)"
        val MergeQuery3="update  " +"medispan.Dim_DrugItem"+" SET  RowEndDate = s.RowEndDate,  IsRowCurrent = 0,     NotCurrentReason = 'D' FROM  " +"medispan.Dim_DrugItem"+" d join  "+"medispan.STG_DrugItem"+"  s on d.productid = s.productid WHERE   d.IsRowCurrent = 1 AND   s.rowstatus in (3)"
        val MergeQuery4="INSERT INTO  " +"medispan.Dim_DrugItem"+"(PRODUCTID,ProductIDFormatCode,ProductName,AllergyPatternCode,PPGIndicatorCode,HFPGIndicatorCode,LabelerTypeCode,PricingSpreadCode,SequenceCode,LabelerCode,ManufacturerName,ManufacturerAbbreviatedName,GenericIDTypeCode,GenericIDNumber,DEAClassCode,AHFSTherapeuticClassCode,ItemStatusFlag,LocalSystemicFlag,TEECode,FormattedIDNumber,RXOTCIndicatorCode,ThirdPartyRestrictionCode,MaintenanceDrugCode,DispensingUnitCode,PackageCode,RouteofAdministration,FormTypeCode,DollarRankCode,RxRankCode,NumberSystemCharacter,SecondaryIDFormatCode,SecondaryIDNumber,MultiSourceCode,BrandNameCode,ReimbursementIndicator,InternalExternalCode,SingleCombinationCode,StorageConditionCode,LimitedStabilityCode,ProductDescriptionAbbreviation,DrugNameCode,GenericProductID,GenericProductName,GenericProductPackagingCode,DrugCategory,DrugGroup,DrugClass,DrugSubclass,DrugName,DosageForm,PackageSize,UnitOfMeasure,PackageQuantity,RepackageCode,TotalPackageQuantity,DESICode,PackageDescription,NextSmallerNDCSuffixNumber,NextLargerNDCSuffixNumber,InnerpackCode,ClinicPackCode,MetricStrength,StrengthUnitofMeasure,LimitedDistributionCode,ExtendedAHFSTherapeuticClassCode,InactiveDate,OldProductID,OldEffectiveDate,NewProductID,NewEffectiveDate,ETLRunID,RowStartDate,RowEndDate,IsRowCurrent,IsRowSkeleton,NotCurrentReason,ZipFileName) SELECT PRODUCTID,ProductIDFormatCode,ProductName,AllergyPatternCode,PPGIndicatorCode,HFPGIndicatorCode,LabelerTypeCode,PricingSpreadCode,SequenceCode,LabelerCode,ManufacturerName,ManufacturerAbbreviatedName,GenericIDTypeCode,GenericIDNumber,DEAClassCode,AHFSTherapeuticClassCode,ItemStatusFlag,LocalSystemicFlag,TEECode,FormattedIDNumber,RXOTCIndicatorCode,ThirdPartyRestrictionCode,MaintenanceDrugCode,DispensingUnitCode,UnitOfUsePackageCode,RouteofAdministration,FormTypeCode,DollarRankCode,RxRankCode,NumberSystemCharacter,SecondaryIDFormatCode,SecondaryIDNumber,MultiSourceCode,BrandNameCode,ReimbursementIndicator,InternalExternalCode,SingleCombinationCode,StorageConditionCode,LimitedStabilityCode,ProductDescriptionAbbreviation,DrugNameCode,GenericProductID,GenericProductName,GenericProductPackagingCode,DrugCategory,DrugGroup,DrugClass,DrugSubclass,DrugName,DosageForm,PackageSize,UnitOfMeasure,PackageQuantity,RepackageCode,TotalPackageQuantity,DESICode,PackageDescription,NextSmallerNDCSuffixNumber,NextLargerNDCSuffixNumber,InnerpackCode,ClinicPackCode,MetricStrength,StrengthUnitofMeasure,LimitedDistributionCode,ExtendedAHFSTherapeuticClassCode,InactiveDate,OldProductID,OldEffectiveDate,NewProductID,NewEffectiveDate,ETLRunID,RowStartDate,RowEndDate,IsRowCurrent,0,'',ZipFileName FROM "+"medispan.STG_DrugItem"+"  WHERE RowStatus='2' OR RowStatus='1'"

        val statement = connection.createStatement()
        var resultSet = statement.execute(MergeQuery1)
        resultSet = statement.execute(MergeQuery2)
        resultSet = statement.execute(MergeQuery3)
        resultSet = statement.execute(MergeQuery4)
        val  a1="SELECT COUNT (*) FROM "+"medispan.STG_DrugItem"+" WHERE RowStatus=1"
        val  a2="SELECT COUNT (*) FROM "+"medispan.STG_DrugItem"+" WHERE RowStatus=2"
        val  a3="SELECT COUNT (*) FROM "+"medispan.STG_DrugItem"+" WHERE RowStatus=3"
        val  a4="SELECT COUNT (*) FROM "+"medispan.STG_DrugItem"+" WHERE RowStatus=0"
        val  a5="SELECT COUNT (*) FROM "+"medispan.STG_DrugItem"+" WHERE RowStatus=4"


        val  r1=statement.executeQuery(a1)
        while (r1.next()){
          Inserted=r1.getInt(1)
        }
        val  r2=statement.executeQuery(a2)
        while (r2.next()){
          Updated=r2.getInt(1)
        }
        val  r3=statement.executeQuery(a3)
        while (r3.next()){
          Deleted=r3.getInt(1)
        }
        val  r4=statement.executeQuery(a4)
        while (r4.next()){
          Ignored=r4.getInt(1)
        }
        val  r5=statement.executeQuery(a5)
        while (r5.next()){
          Infered=r5.getInt(1)
        }
        println("Inserted:"+Inserted)
        println("Update:"+Updated)
        println("Deleted:"+Deleted)
        println("Ignored:"+Ignored)
        println("Infered:"+Infered)

      } catch {
        case e: Throwable => e.printStackTrace
      }
      connection.close()
      return (Inserted,Updated,Deleted,Ignored,Infered)
    }


}
