package com.optum.spark

import java.sql.{Connection, DriverManager}
import java.util.Properties

import scala.io.Source

object DbScalaDrugPricing {
  def runQueries(): (Int,Int,Int,Int,Int) = {
    val url = getClass.getResource("/source.properties")
    val properties: Properties = new Properties()
    val source = Source.fromURL(url)
    properties.load(source.bufferedReader())

    var i=Views.M25A()
    var df=DriverClass.spark.sql(i)
    df.createOrReplaceGlobalTempView("Raw_M25A")
    var Lastchange="2078-12-31"
    var connection:Connection = null
    var  Inserted=0
    var  Updated=0
    var  Deleted=0
    var  Ignored=0
    var  Infered=0

    try {
      Class.forName(properties.getProperty("azureDriver"))
      connection = DriverManager.getConnection(properties.getProperty("azureUrl"), properties.getProperty("azureUser"), properties.getProperty("azurePassword"))

      val q1="UPDATE  " +"medispan.STG_DrugPricing"+"  SET RowStatus = 4 FROM  " +"medispan.STG_DrugPricing"+"  A    INNER JOIN  " +"medispan.Dim_DrugPricing"+"  B    ON A.ProductID = B.ProductID AND      A.IsRowCurrent = B.IsRowCurrent AND     A.CostTypeCode = B.costTypeCode   WHERE A.RowStatus = 1 AND   B.IsRowSkeleton = 1 AND    A.RecordCode = 1 "
      val q2="UPDATE  " +"medispan.STG_DrugPricing"+"  SET RowStatus = 6, ZipFileName = B.ZipFileName  FROM  " +"medispan.STG_DrugPricing"+"  A INNER JOIN  " +"medispan.Dim_DrugPricing"+"  B  ON  A.ProductID = B.ProductID and A.IsRowCurrent = B.IsRowCurrent AND    A.CostTypeCode = B.CostTypeCode  WHERE A.PackagePrice = B.PackagePrice AND     A.UnitPrice = B.UnitPrice AND  A.EffectiveDate = B.EffectiveDate  AND   A.RowStatus in (1,2) and A.CostTypeCode in ('AWP','CMS','DP','WAC');"
      //      val query="WITH CTE_DrugPricing (ProductID, CostTypeCode, MinEffectiveDate) AS   ( SELECT Distinct ProductID, CostTypeCode, min(EffectiveDate) MinDate     FROM medispan.STG_DrugPricing WHERE RowStatus = 2 AND CostTypeCode in ('AWP','CMS','DP','WAC')    GROUP BY CostTypeCode, ProductID  )  INSERT INTO medispan.STG_DrugPricing (DrugPricingDimKey, RowStartDate, RowStatus)  SELECT B.DrugPricingDimKey,"+Lastchange+" , 7  FROM CTE_DrugPricing A INNER JOIN  " +"medispan.Dim_DrugPricing"+"  B  ON  A.ProductID = B.ProductID AND    A.CostTypeCode = B.CostTypeCode AND     A.MinEffectiveDate > B.EffectiveDate  WHERE B.CostTypeCode in ('AWP','CMS','DP','WAC') AND    B.IsRowCurrent = 1;"
      val query = "WITH CTE_DrugPricing (ProductID, CostTypeCode, MinEffectiveDate) AS   ( SELECT Distinct ProductID, CostTypeCode, min(EffectiveDate) MinDate     FROM  " +"medispan.STG_DrugPricing"+" WHERE RowStatus = 2 AND CostTypeCode in ('AWP','CMS','DP','WAC')    GROUP BY CostTypeCode, ProductID  )  INSERT INTO   " +"medispan.STG_DrugPricing"+" (DrugPricingDimKey, CostTypeCode,RowStartDate, RowStatus,ETLRunID)  SELECT B.DrugPricingDimKey,'TEST','2078-12-31' , 7 ,0 FROM CTE_DrugPricing A INNER JOIN  " +"medispan.Dim_DrugPricing"+"  B  ON  A.ProductID = B.ProductID AND    A.CostTypeCode = B.CostTypeCode AND     A.MinEffectiveDate > B.EffectiveDate  WHERE B.CostTypeCode in ('AWP','CMS','DP','WAC') AND    B.IsRowCurrent = 1;"
      val MergeQuery1="UPDATE  " +"medispan.Dim_DrugPricing"+"  SET RowEndDate = DATEADD(day, -1, s.rowstartdate), IsRowCurrent = 0, InactiveReason = 'C' from  " +"medispan.Dim_DrugPricing"+"  d join  " +"medispan.STG_DrugPricing"+"   s  on d.productid = s.productid  and d.CostTypeCode = s.CostTypeCode  and d.IsRowCurrent = 1 WHERE s.rowstatus in (1,2,6)"
      val MergeQuery2="UPDATE  " +"medispan.Dim_DrugPricing"+"  SET  PackagePrice = s.PackagePrice,  UnitPrice = s.UnitPrice,  EffectiveDate = s.EffectiveDate,  ETLRunID = s.ETLRunID,  RowStartDate = s.RowStartDate,  RowEndDate = s.RowEndDate,  ZipFileName = s.ZipFileName,     IsRowSkeleton = 0 from  " +"medispan.Dim_DrugPricing"+"  d join  " +"medispan.STG_DrugPricing"+"  s on d.productid = s.productid and d.CostTypeCode = s.CostTypeCode AND d.SpanNumber = s.Recordcode AND d.IsRowCurrent = 1 where s.rowstatus in (4);"
      val MergeQuery3="UPDATE  " +"medispan.Dim_DrugPricing"+"  SET  RowEndDate = '2078-12-31',  IsRowCurrent = 1,     InactiveReason = '' from  " +"medispan.Dim_DrugPricing"+"  d join  " +"medispan.STG_DrugPricing"+"  s on d.productid = s.productid and d.CostTypeCode = s.CostTypeCode AND d.PackagePrice = s.PackagePrice AND d.UnitPrice = s.UnitPrice AND d.EffectiveDate = s.EffectiveDate AND d.ZipFileName = s.ZipFileName AND d.IsRowCurrent = 0 WHERE s.rowstatus in (6);"
      val MergeQuery4="UPDATE  " +"medispan.Dim_DrugPricing"+"  SET  RowEndDate = '2078-12-31',  IsRowCurrent = 1,     InactiveReason = '' from  " +"medispan.Dim_DrugPricing"+"  d join  " +"medispan.STG_DrugPricing"+"  s on d.DrugPricingDimKey = s.DrugPricingDimKey and d.IsRowCurrent = 0 WHERE   s.DrugPricingDimKey !=0;"
      val MergeQuery5="Insert into  " +"medispan.Dim_DrugPricing"+" ( PRODUCTID, CostTypeCode, PackagePrice, UnitPrice, EffectiveDate, ETLRunID, RowStartDate, RowEndDate, IsRowCurrent, ZipFileName,IsRowSkeleton,InactiveReason ) select  s.PRODUCTID, s.CostTypeCode, s.PackagePrice, s.UnitPrice, s.EffectiveDate, s.ETLRunID, s.RowStartDate, s.RowEndDate, s.IsRowCurrent, s.ZipFileName,0,'' from  " +"medispan.STG_DrugPricing"+"  s WHERE  s.rowstatus in (1,2,5);"
      val MergeQuery6="WITH CTE_DrugSpanNumber (DrugPricingDimKey, CostTypeCode, SpanNumber) AS (  SELECT DrugPricingDimKey, CostTypeCode, ROW_NUMBER() OVER (PARTITION BY CostTypeCode, ProductID ORDER BY EffectiveDate DESC) AS RowNumber   FROM  " +"medispan.Dim_DrugPricing"+"   WHERE IsRowCurrent = 1 and CostTypeCode not in ('ADJM', 'ADJF')  )  UPDATE  " +"medispan.Dim_DrugPricing"+"  SET SpanNumber = B.SpanNumber  FROM  " +"medispan.Dim_DrugPricing"+"  A INNER JOIN CTE_DrugSpanNumber B  ON A.DrugPricingDimKey = B.DrugPricingDimKey"
      val MergeQuery7="UPDATE  " +"medispan.Dim_DrugPricing"+" \nSET\n\tRowEndDate = s.RowEndDate,\n\tIsRowCurrent = 0,\n    InactiveReason = 'D'\nfrom medispan.Dim_DrugPricing d\njoin medispan.STG_DrugPricing s on d.productid = s.productid and d.CostTypeCode = s.CostTypeCode and d.IsRowCurrent = 1\nWHERE\n\ts.rowstatus in (3);"

      val statement = connection.createStatement()
      var resultSet1 = statement.executeUpdate(query)
      println("inserting null in stg 1:"+resultSet1)
      var resultSet2 = statement.executeUpdate(q1)
      println("Update in stg 1")
      var resultSet3 = statement.executeUpdate(q2)
      println("Update in stg 2")
      var resultSet = statement.executeUpdate(MergeQuery1)
      println("First update")
      resultSet = statement.executeUpdate(MergeQuery2)
      println("Second update")
      resultSet = statement.executeUpdate(MergeQuery3)
      println("third update")
      resultSet = statement.executeUpdate(MergeQuery4)
      println("fourth update")
      resultSet = statement.executeUpdate(MergeQuery5)
      println("fifth insert")
      resultSet = statement.executeUpdate(MergeQuery6)
      println("Recalculate Span 1")
      resultSet = statement.executeUpdate(MergeQuery7)
      println("Recalculate Span 2")
      val  a1="SELECT COUNT(*) FROM "+"medispan.STG_DrugPricing"+" WHERE RowStatus=1"
      val  a2="SELECT COUNT(*) FROM "+"medispan.STG_DrugPricing"+" WHERE RowStatus=2"
      val  a3="SELECT COUNT(*) FROM "+"medispan.STG_DrugPricing"+" WHERE RowStatus=3"
      val  a4="SELECT COUNT(*) FROM "+"medispan.STG_DrugPricing"+" WHERE RowStatus=0"
      val  a5="SELECT COUNT(*) FROM "+"medispan.STG_DrugPricing"+" WHERE RowStatus=4"

      val  r1=statement.executeQuery(a1)
      while (r1.next()){
        Inserted=r1.getInt(1)
      }
      val  r2=statement.executeQuery(a2)
      while (r2.next()){
        Updated=r2.getInt(1)
      }
      val  r3=statement.executeQuery(a3)
      while (r3.next()){
        Deleted=r3.getInt(1)
      }
      val  r4=statement.executeQuery(a4)
      while (r4.next()){
        Ignored=r4.getInt(1)
      }
      val  r5=statement.executeQuery(a5)
      while (r5.next()){
        Infered=r5.getInt(1)
      }
    } catch {
      case e: Throwable => e.printStackTrace
    }
    connection.close()
    return (Inserted,Updated,Deleted,Ignored,Infered)
  }
}