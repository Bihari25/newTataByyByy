package com.optum.spark

import java.io.File
import java.util.Properties

import org.apache.spark.sql.{SaveMode, SparkSession}

import scala.io.Source

object ReadWrite {
  def main(args: Array[String]): Unit = {

    val spark = SparkSession
      .builder()
      .master("local")
      .getOrCreate()

    val df = LoadUtil.readJDBC("Dim_DrugPricing")
    df.show(false)
    println(df.count())
//    val spark = SparkSession.builder
//      .appName("CDW Application")
//      .config("spark.master", "local")
//      .getOrCreate()
//
//    val url = getClass.getResource("/source.properties")
//    val properties: Properties = new Properties()
//    val source = Source.fromURL(url)
//    properties.load(source.bufferedReader())
//    val sc = spark.sparkContext
//    sc.setLogLevel("ERROR")
//
//    val table = "Dim_DrugPricing"
//    val db = "HECLAIMSEDW"
//

    val table = "Dim_DrugGPIClassification_prod_data_09122019"
    val db = "MDDB_REP_DEV"


//    val src = spark.read
//      .format("jdbc")
//      .option("driver","net.sourceforge.jtds.jdbc.Driver")
//      .option("url", "jdbc:jtds:sqlserver://EGVC1W9SQL53.sxc.com;useNTLMv2=true;domain=MS")
//      .option("dbtable", db+".dbo."+table)
//      .option("user", "araghuva")
//      .option("password", "Mandla#11")
//      .load()

//
//    src.show(false)
//    println(src.count())
//    src.coalesce(1).write.parquet("/Users/aredd103/Documents/AWP_Load/"+table)


//    val Src = spark.read
//      .format("jdbc")
//      .option("driver","com.microsoft.sqlserver.jdbc.SQLServerDriver")
//      .option("url", "jdbc:sqlserver://EGVD1W1SQL32.sxc.com;")
//      .option("dbtable", db+".dbo."+table)
//      .option("user", "araghuva")
//      .option("password", "Mandla#11")
//      .load()
//
//    Src.show(false)
//    println(Src.count())
//
//    Src.coalesce(1).write.parquet("/Users/aredd103/Documents/Update_Load/"+table)


//    src.show(false)
//    println(src.count())
    //    src.coalesce(1).write.parquet("/Users/aredd103/Documents/AWP_Load/"+table)


//    var srcRenamed = src
//    srcRenamed.columns.foreach { col =>
//      println(col + " after column replace " + col.replaceAll(" ", ""))
//      srcRenamed = srcRenamed.withColumnRenamed(col, col.replaceAll(" ", "")
//      )
//    }
//    srcRenamed.printSchema()
//    srcRenamed.coalesce(1).write.parquet("/Users/aredd103/Documents/AWP_Load/"+table)
//
//
//    src.write
//      .format("jdbc")
//      .option("driver", "com.microsoft.sqlserver.jdbc.SQLServerDriver")
//      .option("url", "jdbc:sqlserver://EGVD1W1SQL32.sxc.com;")
//      .option("dbtable", "MDDB_REP_DEV.dbo.Audit_Medispan_Load_History")
//      .option("user", "cldmddb")
//      .option("password", "Thn;J{6=7md&B5'W")
//      .mode(SaveMode.Overwrite)
//      .save()


//    src.write
//        .format("jdbc")
//        .option("driver", properties.getProperty("onpremdbDriver"))
//        .option("url", properties.getProperty("onpremdbUrl"))
//        .option("dbtable", properties.getProperty("onpremdbTable")+table)
//        .option("user", properties.getProperty("onpremdbUser"))
//        .option("password", properties.getProperty("onpremdbUser"))
//        .mode(SaveMode.ErrorIfExists)
//        .save()

//def getListOfFiles(dir: String):List[String] = {
//  val d = new File(dir)
//  if (d.exists && d.isDirectory) {
//    d.listFiles.filter(_.isFile).filter(_.getName.startsWith("MDDB")).toList.toString()
//
//  } else {
//    List[String]()
//  }
//}
//    println(getListOfFiles("/Users/aredd103/Downloads/Resources"))

//    val fileName = new File("/Users/aredd103/Downloads/Resources").listFiles.map(_.getName).toList.filter(a=>a.contains("MDDB"))
//   // zipFileName.foreach(a=> println(a))
//    println(fileName(0))

  }
}
