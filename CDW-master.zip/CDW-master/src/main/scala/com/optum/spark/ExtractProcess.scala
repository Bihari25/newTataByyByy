package com.optum.spark

import java.util.Properties

import org.apache.spark.sql.SaveMode
import org.apache.spark.sql.functions._
import org.joda.time.DateTime
import org.joda.time.format.DateTimeFormat

import scala.io.Source

object ExtractProcess {
  val url = getClass.getResource("/source.properties")
  val properties: Properties = new Properties()
  val source = Source.fromURL(url)
  properties.load(source.bufferedReader())
  def runProcess(ZipFileName:String, param:String, MaxFileImportID: Int):(Int,String) = {
    val df = DriverClass.spark.read.option("header", true).csv(properties.getProperty("rootPath") + param + ".csv")
    var c = df.count()
    val NewDf = df.agg("Source" -> "min").head()
    var file = NewDf.get(0)
    var df1 = DriverClass.spark.read.option("header", false).textFile(properties.getProperty("sourcePath")+ZipFileName+"/" + file)
    var i = 1
    var co = c.toInt
    var list = (1 to co).toList
    var df_parquet = df1.toDF("Data")

    def func(i: Int) = {
      var field = df.filter("no==" + i).select("Fields").head().get(0).toString
      var start = df.filter("no==" + i).select("Start").head().get(0).toString.toInt
      var len = df.filter("no==" + i).select("Length").head().get(0).toString.toInt
      df_parquet = df_parquet.withColumn(field, substring(col("Data"), start, len))
    }

    list.foreach(i => func(i))

    df_parquet = df_parquet.drop("Data")
    df_parquet = df_parquet.withColumn("ETLStatus", lit(1))
    df_parquet = df_parquet.withColumn("ETLErrorCount", lit(0))
    df_parquet = df_parquet.withColumn("FileImportID", lit(MaxFileImportID))
    df_parquet = df_parquet.withColumn("ZipFileName", lit(ZipFileName))
    df_parquet.coalesce(1).write.mode(SaveMode.Overwrite).option("header", true).parquet(properties.getProperty("targetPath")+ZipFileName+"/RAW_" + file)
    val count=df_parquet.count().toString.toInt
    val EndDateTime: String = DateTimeFormat.forPattern("yyyy-MM-dd").print(DateTime.now())
    return (count,EndDateTime)
  }
}
