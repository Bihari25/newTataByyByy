package com.optum.spark

import java.sql.{Connection, DriverManager}
import java.util.Properties
import org.joda.time.DateTime

import org.joda.time.format.DateTimeFormat

import scala.io.Source

object SqlETLMasterMediSpanHEClaimsEDW {
  var ZipFileName=ImportMediSpanDrugData.Zip
  def runProcess(): Unit = {
    val url = getClass.getResource("/source.properties")
    val properties: Properties = new Properties()
    val source = Source.fromURL(url)
    properties.load(source.bufferedReader())

    Class.forName(properties.getProperty("azureDriver"))
    var connection: Connection = null
    connection = DriverManager.getConnection(properties.getProperty("azureUrl"), properties.getProperty("azureUser"), properties.getProperty("azurePassword"))
    val statement = connection.createStatement()

    val q33="SELECT     CASE WHEN COUNT(*) > 0 THEN 0 ELSE 1 END AS Is_Daily FROM         medispan.CFG_ETL_Run WHERE     (CFGIsActive = 1) AND TypeOfLoad = 'Drugs' AND FileName = '"+ZipFileName+"'"
    val rs33 = statement.executeQuery(q33)
    var i=1
    while (rs33.next()){
      i=rs33.getInt(1)
    }

    val q34="insert into medispan.CFG_ETL_Run (  FileName,  TypeOfLoad,  CFGIsActive ) values ( '"+ZipFileName+"',  'Drugs',  1 );"
    val rs34 = statement.executeUpdate(q34)
    //
    val q35="SELECT ETLRunCFGID,  FileName FROM medispan.CFG_ETL_Run WHERE CFGIsActive = 1 AND   TypeOfLoad = 'Drugs' AND  FileName = '"+ZipFileName+"' ORDER BY FileName"
    val rs35=statement.executeQuery(q35)
    var j=1
    while (rs35.next()){
      j=rs35.getInt(1)
    }

    val etl="Select max(ETLRunID) from medispan.AUDIT_ETL_Run"
    val runidrs=statement.executeQuery(etl)
    var ETLRunID=1
    while(runidrs.next())
    {
      ETLRunID=runidrs.getInt(1)+ETLRunID
    }

    val updaterunid="update "+"medispan.Audit_Medispan_Load_History"+ " set ETLRunID= "+ETLRunID+" where ZipFileName='"+ZipFileName+"'"
    val etlrun=statement.executeUpdate(updaterunid)

    AuditUtil.CheckETLLoadType(ETLRunID,1)
    LoadDrugItem.runProcess(ZipFileName)
    val DI=DbScalaDrugItem.runQueries()
    AuditUtil.LoadETLCDCSummaryToHistory(ETLRunID,"DrugItem",DI._1,DI._2,DI._3,DI._4,DI._5)
    println("\nDim_DrugItem loaded successfully!\n")
    ProcessChangedDrugClassification.runProcess(ZipFileName)
    LoadDrugPricing.runProcess(ZipFileName)
    val DP=DbScalaDrugPricing.runQueries()
    AuditUtil.LoadETLCDCSummaryToHistory(ETLRunID,"DrugPricing",DP._1,DP._2,DP._3,DP._4,DP._5)
    println("Dim_DrugPricing loaded successfully!")

    DbScalaDrug.runQueries()
    println("Dim_Drug loaded successfully!")

    val q40="update medispan.CFG_ETL_Run\nset CFGIsActive = 10\nwhere ETLRunCFGID = "+j
    val rs40=statement.executeUpdate(q40)

    val date: String = DateTimeFormat.forPattern("yyyy-MM-dd").print(DateTime.now())
    val q15="update medispan.AUDIT_File_Import set FileImportFinishDateTime = "+date+" where FileImportID = "+LoadDrugItem.ETLRunID
    val rs15=statement.executeUpdate(q15)
  }
}