package com.optum.spark

import org.apache.spark.sql.SaveMode

object Raw_DrugItem {
  val spark=DriverClass.spark

  def defination(ZipFileName:String) = {
    var df1 = Sources.Raw_M25(ZipFileName)
    df1.cache()
    println("Raw_M25: "+df1.count())
    df1.createOrReplaceGlobalTempView("M25")

    var i=Views.M25A()

    var df =spark.sql(i)
    df.createOrReplaceGlobalTempView("Raw_M25A")

    i=Views.M25C()

    df =spark.sql(i)
    df.createOrReplaceGlobalTempView("Raw_M25C")

    i=Views.M25E()

    df =spark.sql(i)
    df.createOrReplaceGlobalTempView("Raw_M25E")

    i=Views.M25G()

    df =spark.sql(i)
    df.createOrReplaceGlobalTempView("Raw_M25G")

    i=Views.M25J()

    df =spark.sql(i)
    df.createOrReplaceGlobalTempView("Raw_M25J")

    i=Views.M25L()

    df =spark.sql(i)
    df.createOrReplaceGlobalTempView("Raw_M25L")

    i=Views.M25M()

    df =spark.sql(i)
    df.createOrReplaceGlobalTempView("Raw_M25M")

    var query="SELECT" +
      " A.PRODUCTID, " +
      "A.LastChangeDate ,A.SequenceCode, A.LabelerCode, A.GenericIDTypeCode, A.GenericID as GenericIDNumber, A.DEAClassCode, A.AHFSTherapeuticClassCode, A.ItemStatusFlag, A.LocalSystemicFlag, A.TEECode, A.FormattedProductID as FormattedIDNumber, A.RXOTCIndicatorCode, A.ThirdPartyRestrictionCode, A.MaintenanceDrugCode, A.DispensingUnitCode, A.PackageCode, A.RouteofAdministration, A.FormTypeCode, A.DollarRankCode, A.RxRankCode, A.NumberSystemCharacter, A.SecondaryIDFormatCode, A.SecondaryID as SecondaryIDNumber, A.MultiSourceCode, A.BrandNameCode, A.ReimbursementIndicator, A.InternalExternalCode, A.SingleCombinationCode, A.StorageConditionCode, A.LimitedStabilityCode, A.TransactionCode, A.ZipFileName, " +
      "C.OldProductID, C.OldEffectiveDate, C.NewProductID, C.NewEffectiveDate, " +
      "E.ProductIDFormatCode, LTRIM(RTRIM(CONCAT(E.ProductName,E.ProductNameExtension))) AS ProductName,E.AllergyPatternCode, E.PPGIndicatorCode, E.HFPGIndicatorCode, E.LabelerTypeCode, E.PricingSpreadCode, " +
      "G.GenericProductID, G.GenericName as GenericProductName, " +
      "J.GenericProductPackagingCode, J.ManufacturerName, J.ManufacturerAbbreviatedName, J.ProductDescriptionAbbreviation, J.DrugNameCode, " +
      "L.DosageForm, L.PackageSize, L.UnitOfMeasure, L.PackageQuantity, L.RepackageCode, L.TotalPackageQuantity, L.DESICode, L.PackageDescription, L.NextSmallerNDCSuffixNumber, L.NextLargerNDCSuffixNumber, L.InnerpackCode, L.ClinicPackCode, " +
      "M.MetricStrength, M.StrengthUnitofMeasure, M.LimitedDistributionCode, M.ExtendedAHFSTherapeuticClassCode, M.InactiveDate, CONCAT(CONCAT( 'A', case ltrim(rtrim(ifnull(A.TransactionCode,'')))  WHEN '' THEN '0'  WHEN 'A' THEN '1'  WHEN 'C' THEN '2'  WHEN 'D' THEN '3' END ),CONCAT(  'C' ,case ltrim(rtrim(ifnull(C.TransactionCode,'')))   WHEN '' THEN '0'  WHEN 'A' THEN '1'  WHEN 'C' THEN '2'  WHEN 'D' THEN '3' END) ,CONCAT(  'E', case ltrim(rtrim(ifnull(E.TransactionCode,'')))   WHEN '' THEN '0'  WHEN 'A' THEN '1'  WHEN 'C' THEN '2'  WHEN 'D' THEN '3' END) ,CONCAT(  'G', case ltrim(rtrim(ifnull(G.TransactionCode,'')))  WHEN '' THEN '0'  WHEN 'A' THEN '1'  WHEN 'C' THEN '2'  WHEN 'D' THEN '3' END) ,CONCAT ( 'J', case ltrim(rtrim(ifnull(J.TransactionCode,'')))    WHEN '' THEN '0'  WHEN 'A' THEN '1'  WHEN 'C' THEN '2'  WHEN 'D' THEN '3' END) ,CONCAT(  'L', case ltrim(rtrim(ifnull(L.TransactionCode,'')))  WHEN '' THEN '0'  WHEN 'A' THEN '1'  WHEN 'C' THEN '2'  WHEN 'D' THEN '3' END) ,CONCAT(  'M', case ltrim(rtrim(ifnull(M.TransactionCode,'')))   WHEN '' THEN '0'  WHEN 'A' THEN '1'  WHEN 'C' THEN '2'  WHEN 'D' THEN '3' END)) ChangeCode\n" +
      "FROM global_temp.Raw_M25A AS A LEFT OUTER JOIN " +
      " global_temp.Raw_M25C AS C ON (A.ZipFileName = C.ZipFileName AND A.PRODUCTID = C.PRODUCTID and A.ProductIDFormatCode=C.ProductIDFormatCode) LEFT OUTER JOIN" +
      " global_temp.Raw_M25E AS E ON (A.ZipFileName = E.ZipFileName AND A.PRODUCTID = E.PRODUCTID and A.ProductIDFormatCode=E.ProductIDFormatCode) LEFT OUTER JOIN" +
      " global_temp.Raw_M25G AS G ON (A.ZipFileName = G.ZipFileName AND A.PRODUCTID = G.PRODUCTID and A.ProductIDFormatCode=G.ProductIDFormatCode) LEFT OUTER JOIN" +
      " global_temp.Raw_M25J AS J ON (A.ZipFileName = J.ZipFileName AND A.PRODUCTID = J.PRODUCTID and A.ProductIDFormatCode=J.ProductIDFormatCode) LEFT OUTER JOIN" +
      " global_temp.Raw_M25L AS L ON (A.ZipFileName = L.ZipFileName AND A.PRODUCTID = L.PRODUCTID and A.ProductIDFormatCode=L.ProductIDFormatCode) LEFT OUTER JOIN" +
      " global_temp.Raw_M25M AS M ON (A.ZipFileName = M.ZipFileName AND A.PRODUCTID = M.PRODUCTID and A.ProductIDFormatCode=M.ProductIDFormatCode) " +
      " WHERE (A.TransactionCode IN ('A', ' ', 'C','D'))"

    df=spark.sql(query)
    LoadUtil.writeJDBC(df, "RAW_DI", SaveMode.Overwrite)
    df.createOrReplaceGlobalTempView("Raw_DI")
    df
    /*
  A,C,E,G,J,L,M
     */
  }
}
