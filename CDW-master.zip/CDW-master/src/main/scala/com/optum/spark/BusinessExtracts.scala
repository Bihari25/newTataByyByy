package com.optum.spark

import java.util.Properties

import org.apache.spark.sql.functions._

import scala.io.Source

object BusinessExtracts {
  val url = getClass.getResource("/source.properties")
  val properties: Properties = new Properties()
  val source = Source.fromURL(url)
  properties.load(source.bufferedReader())

  def runProcess(): Unit = {

    val zip=DriverClass.zipFileName

    val DEpath = properties.getProperty("extractPath")+"DrugExtract_"+zip+".csv"
    val DIpath = properties.getProperty("extractPath")+"DrugItemExtract_"+zip+".csv"
    val DPpath = properties.getProperty("extractPath")+"DrugPricingExtract_"+zip+".csv"
    val IDWpath = properties.getProperty("extractPath")+"IDWExtract_"+zip+".csv"

    val DP = LoadUtil.readJDBC("Dim_DrugPricing")

    val dfDP=DP.withColumn("InactiveReason", regexp_replace(col("InactiveReason")," ","null"))
    dfDP.write.option("header",true).option("delimiter","\t").option("nullValue","null").option("emptyValue","").mode("overwrite").csv(DPpath)

    val DI = LoadUtil.readJDBC("Dim_DrugItem")
    DI.write.option("header",true).option("delimiter","\t").option("nullValue","null").option("emptyValue","").mode("overwrite").csv(DIpath)

    val D = LoadUtil.readJDBC("Dim_Drug")
    D.write.option("header",true).option("delimiter","\t").option("nullValue","null").option("emptyValue","").mode("overwrite").csv(DEpath)

    val IDWDim_DrugPricing = "(SELECT ProductID, CostTypeCode as CostTypeCodeSub, 'AWP' as CostTypeCode, PackagePrice, UnitPrice, EffectiveDate\nFROM medispan.Dim_DrugPricing\nWHERE CostTypeCode = 'ADJM' AND IsRowCurrent = 1\nUNION SELECT DISTINCT d1.ProductID, 'AWPHist' as CostTypeCodeSub, 'NonPrimary' as CostTypeCode, d1.PackagePrice, d1.UnitPrice, d1.EffectiveDate\nFROM (\nselect *\nfrom medispan.Dim_DrugPricing\nwhere IsRowCurrent = 1) d1\nJOIN (\nselect *\nfrom medispan.Dim_DrugPricing\nwhere IsRowCurrent = 1) d2 ON d1.ProductID = d2.ProductID\nAND d1.EffectiveDate >= CAST('09/26/2009' AS DATETIME)\nWHERE d1.CostTypeCode = 'AWP' AND d2.CostTypeCode = 'ADJM' UNION SELECT DISTINCT d2.ProductID, 'AWPHist' as CostTypeCodeSub, 'NonPrimary' as CostTypeCode, d2.PackagePrice, d2.UnitPrice, AWPMaxEffDT.ADJMMinEffDT as EffectiveDate\nFROM (\nSELECT d1.ProductID, tblMinADJM.ADJMMinEffDT, MAX(d1.EffectiveDate) AS AWPMaxEffDT\nFROM (\nselect *\nfrom medispan.Dim_DrugPricing\nwhere IsRowCurrent = 1) d1\nJOIN (\nSELECT a.ProductID, MIN(a.EffectiveDate) AS ADJMMinEffDT\nFROM (\nselect *\nfrom medispan.Dim_DrugPricing\nwhere IsRowCurrent = 1\nand CostTypeCode = 'ADJM') a\nGROUP BY ProductID ) tblMinADJM ON d1.ProductID = tblMinADJM.ProductID\nAND d1.EffectiveDate < tblMinADJM.ADJMMinEffDT\nAND d1.CostTypeCode = 'AWP' WHERE d1.ProductID\nNOT IN(\nSELECT DISTINCT compare1.ProductID\nFROM (\nselect *\nfrom medispan.Dim_DrugPricing\nwhere IsRowCurrent = 1) compare1\nJOIN (\nselect *\nfrom medispan.Dim_DrugPricing\nwhere IsRowCurrent = 1) compare2 ON compare1.ProductID = compare2.ProductID\nAND d1.ProductID = compare1.ProductID\nAND compare1.CostTypeCode = 'AWP' AND compare2.CostTypeCode = 'ADJM' WHERE compare1.EffectiveDate = tblMinADJM.ADJMMinEffDT)\nGROUP BY d1.ProductID, tblMinADJM.ADJMMinEffDT ) AWPMaxEffDT\nJOIN (\nselect *\nfrom medispan.Dim_DrugPricing\nwhere IsRowCurrent = 1) d2 ON AWPMaxEffDT.ProductID = d2.ProductID\nAND AWPMaxEffDT.AWPMaxEffDT = d2.EffectiveDate\nAND d2.CostTypeCode = 'AWP' UNION SELECT DISTINCT d1.ProductID, 'AWPHist' as CostTypeCodeSub, d1.CostTypeCode, d1.PackagePrice, d1.UnitPrice, d1.EffectiveDate\nFROM (\nselect *\nfrom medispan.Dim_DrugPricing\nwhere IsRowCurrent = 1) d1\nLEFT JOIN (\nselect *\nfrom medispan.Dim_DrugPricing\nwhere IsRowCurrent = 1) d2 ON d1.ProductID = d2.ProductID\nAND d2.CostTypeCode = 'ADJM' WHERE d1.CostTypeCode = 'AWP' AND d2.ProductID\nIS NULL AND d1.EffectiveDate >= CAST('09/26/2009' AS DATETIME)\nUNION SELECT d1.ProductID, 'AWPHist' as CostTypeCodeSub, d1.CostTypeCode, d1.PackagePrice, d1.UnitPrice, d1.EffectiveDate\nFROM (\nselect *\nfrom medispan.Dim_DrugPricing\nwhere IsRowCurrent = 1) d1\nWHERE d1.CostTypeCode = 'AWP' AND d1.EffectiveDate < CAST('09/26/2009' AS DATETIME)\nUNION SELECT ProductID,\nNull as CostTypeCodeSub, CostTypeCode, PackagePrice, UnitPrice, EffectiveDate\nFROM medispan.Dim_DrugPricing\nWHERE CostTypeCode\nNOT IN('AWP', 'ADJM')\nAND IsRowCurrent = 1) TEMP"
    var IDW=DriverClass.spark.read
      .format("jdbc")
      .option("driver", properties.getProperty("azureDriver"))
      .option("url", properties.getProperty("azureUrl"))
      .option("user", properties.getProperty("azureUser"))
      .option("dbtable", IDWDim_DrugPricing)
      .option("password", properties.getProperty("azurePassword"))
      .load()

    IDW.write.option("header",true).option("delimiter","\t").option("nullValue","null").option("emptyValue","").mode("overwrite").csv(IDWpath)


  }
}
