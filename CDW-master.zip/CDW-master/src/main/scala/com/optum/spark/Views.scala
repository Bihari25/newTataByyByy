package com.optum.spark
import java.util.Properties

import org.apache.spark.sql._
import org.apache.spark.sql.functions._

import scala.io.Source
object Views {

  val url = getClass.getResource("/source.properties")
  val properties: Properties = new Properties()
  val source = Source.fromURL(url)
  properties.load(source.bufferedReader())

  var df = Sources.Raw_M25(DriverClass.zipFileName)
  df.createOrReplaceGlobalTempView("M25")

  val View=DriverClass.spark.read.option("header",true).json(properties.getProperty("rootPath")+"Views.json")

  val DrugGPI=LoadUtil.readJDBC("Dim_DrugGPIClassification")
  DrugGPI.createOrReplaceGlobalTempView("DrugGPI")

  val DP=LoadUtil.readJDBC("Dim_DrugPricing")
  DP.cache()
  DP.createOrReplaceGlobalTempView("Dim_DrugPricing")

  def M25A(): String = {
    val q=View.filter(col("ViewName")==="M25A").select("Query").head().get(0).toString
    q
  }
  def M25C(): String = {
    val q=View.filter(col("ViewName")==="M25C").select("Query").head().get(0).toString
    return q
  }
  def M25E(): String = {
    val q=View.filter(col("ViewName")==="M25E").select("Query").head().get(0).toString
    return q
  }
  def M25T(): String = {
    val q=View.filter(col("ViewName")==="M25T").select("Query").head().get(0).toString
    return q
  }
  def M25R(): String = {
    val q=View.filter(col("ViewName")==="M25R").select("Query").head().get(0).toString
    return q
  }
  def M25G(): String = {
    val q=View.filter(col("ViewName")==="M25G").select("Query").head().get(0).toString
    return q
  }
  def M25J(): String = {
    val q=View.filter(col("ViewName")==="M25J").select("Query").head().get(0).toString
    return q
  }
  def M25L(): String = {
    val q=View.filter(col("ViewName")==="M25L").select("Query").head().get(0).toString
    return q
  }
  def M25M(): String = {
    val q=View.filter(col("ViewName")==="M25M").select("Query").head().get(0).toString
    return q
  }
  def M25Q(): String = {
    val q=View.filter(col("ViewName")==="M25Q").select("Query").head().get(0).toString
    return q
  }
  def M25P(): String = {
    val q=View.filter(col("ViewName")==="M25P").select("Query").head().get(0).toString
    return q
  }
  def M25S(): String = {
    val q=View.filter(col("ViewName")==="M25S").select("Query").head().get(0).toString
    return q
  }
  def Drug_Class(): DataFrame = {
    val df = DriverClass.spark.sql("SELECT TherapeuticClassificationCode AS GPISubset, SubString(TherapeuticClassificationCode, 1, 4) GPI4,REPLACE(TherapeuticClassificationName, '*', '') AS DrugClass, RowStartDate, RowEndDate,ZipFileName, ROW_NUMBER() OVER (PARTITION BY SubString(TherapeuticClassificationCode, 1, 4) ORDER BY ETLRunID DESC) Rank FROM global_temp.DrugGPI WHERE (RecordTypeCode = 2)").filter(col("Rank")===1)
    return df
  }
  def Drug_Group(): DataFrame = {
    val df = DriverClass.spark.sql("SELECT TherapeuticClassificationCode AS GPISubset, SubString(TherapeuticClassificationCode, 1, 2) GPI2,REPLACE(TherapeuticClassificationName, '*', '') AS DrugGroup, RowStartDate, RowEndDate,ZipFileName, ROW_NUMBER() OVER (PARTITION BY SubString(TherapeuticClassificationCode, 1, 2) ORDER BY ETLRunID DESC) Rank FROM global_temp.DrugGPI WHERE (RecordTypeCode = 1)").filter(col("Rank")===1)
    return df
  }
  def Drug_Name(): DataFrame = {
    val df=DriverClass.spark.sql("SELECT TherapeuticClassificationCode AS GPISubset, SubString(TherapeuticClassificationCode, 1, 10) GPI10,REPLACE(TherapeuticClassificationName, '*', '') AS DrugName, RowStartDate, RowEndDate,ZipFileName, ROW_NUMBER() OVER (PARTITION BY SubString(TherapeuticClassificationCode, 1, 10) ORDER BY ETLRunID DESC) Rank FROM global_temp.DrugGPI WHERE (RecordTypeCode = 4)").filter(col("Rank")===1)
    return df
  }
  def Drug_SubClass(): DataFrame = {
    val df=DriverClass.spark.sql("SELECT TherapeuticClassificationCode AS GPISubset, SubString(TherapeuticClassificationCode, 1, 6) GPI6,REPLACE(TherapeuticClassificationName, '*', '') AS DrugSubClass, RowStartDate, RowEndDate,ZipFileName, ROW_NUMBER() OVER (PARTITION BY SubString(TherapeuticClassificationCode, 1, 6) ORDER BY ETLRunID DESC) Rank FROM global_temp.DrugGPI WHERE  (RecordTypeCode = 3)").filter(col("Rank")===1)
    return df
  }
  def Dim_DrugPricingAAWP(): DataFrame={
    val df=DriverClass.spark.sql("SELECT  DrugPricingDimKey,PRODUCTID,CostTypeCode,SpanNumber,PackagePrice,UnitPrice,EffectiveDate,RowStartDate,RowEndDate,ZipFileName FROM global_temp.Dim_DrugPricing WHERE   IsRowCurrent = True AND CostTypeCode = 'AAWP'")
    return df
  }
  def Dim_DrugPricingADJM(): DataFrame={
    val df=DriverClass.spark.sql("SELECT  DrugPricingDimKey,PRODUCTID,CostTypeCode,SpanNumber,PackagePrice,UnitPrice,EffectiveDate,RowStartDate,RowEndDate,ZipFileName FROM global_temp.Dim_DrugPricing WHERE   IsRowCurrent = True AND CostTypeCode = 'ADJM'")
    return df
  }
  def Dim_DrugPricingAWP(): DataFrame={
    val df=DriverClass.spark.sql("SELECT  DrugPricingDimKey,PRODUCTID,CostTypeCode,SpanNumber,PackagePrice,UnitPrice,EffectiveDate,RowStartDate,RowEndDate,ZipFileName FROM global_temp.Dim_DrugPricing WHERE   IsRowCurrent = True AND CostTypeCode = 'AWP'")
    return df
  }
  def Dim_DrugPricingCMS(): DataFrame={
    val df=DriverClass.spark.sql("SELECT  DrugPricingDimKey,PRODUCTID,CostTypeCode,SpanNumber,PackagePrice,UnitPrice,EffectiveDate,RowStartDate,RowEndDate,ZipFileName FROM global_temp.Dim_DrugPricing WHERE   IsRowCurrent = True AND CostTypeCode = 'CMS'")
    return df
  }
  def Dim_DrugPricingDP(): DataFrame={
    val df=DriverClass.spark.sql("SELECT  DrugPricingDimKey,PRODUCTID,CostTypeCode,SpanNumber,PackagePrice,UnitPrice,EffectiveDate,RowStartDate,RowEndDate,ZipFileName FROM global_temp.Dim_DrugPricing WHERE   IsRowCurrent = True AND CostTypeCode = 'DP'")
    return df
  }
  def Dim_DrugPricingGEAP(): DataFrame={
    val df=DriverClass.spark.sql("SELECT  DrugPricingDimKey,PRODUCTID,CostTypeCode,SpanNumber,PackagePrice,UnitPrice,EffectiveDate,RowStartDate,RowEndDate,ZipFileName FROM global_temp.Dim_DrugPricing WHERE   IsRowCurrent = True AND CostTypeCode = 'GEAP'")
    return df
  }
  def Dim_DrugPricingWAC(): DataFrame={
    val df=DriverClass.spark.sql("SELECT  DrugPricingDimKey,PRODUCTID,CostTypeCode,SpanNumber,PackagePrice,UnitPrice,EffectiveDate,RowStartDate,RowEndDate,ZipFileName FROM global_temp.Dim_DrugPricing WHERE   IsRowCurrent = 1 AND CostTypeCode = 'WAC' and SpanNumber=3")
    print("df:"+df.count())
    return df
  }
  def Dim_DrugGPI8():DataFrame={
    //val df=MainClass.spark.sql("SELECT   substring (TherapeuticClassificationCode,  1, 8) as GPI8, REPLACE(TherapeuticClassificationName, '*', '') AS GPI8_Name, RowStartDate, RowEndDate, ZipFileName, ETLRunID \nfrom global_temp.DrugGPI A\nWhere RecordTypeCode = 4 and Substring (TherapeuticClassificationCode,  3, 2) <> '99' and Substring (TherapeuticClassificationCode,  5, 2) <> '99' and\n\tSubstring (TherapeuticClassificationCode,  9, 2) in \n  ( Select min (substring (TherapeuticClassificationCode, 9, 2)) from global_temp.DrugGPI B where \n\tsubstring (A. TherapeuticClassificationCode, 1, 8) = substring (B. TherapeuticClassificationCode, 1, 8)  and B.RecordTypeCode = 4)\n) A\nUnion all \nSelect  substring (TherapeuticClassificationCode,  1, 8) as GPI8, REPLACE(TherapeuticClassificationName, '*', '') AS GPI8_Name, RowStartDate, RowEndDate, ZipFileName , ETLRunID\nfrom global_temp.DrugGPI\nWhere RecordTypeCode = 4 and Substring (TherapeuticClassificationCode,  9, 2) ='00' and \n(Substring (TherapeuticClassificationCode, 3, 2) = '99' or Substring (TherapeuticClassificationCode,  5, 2) = '99')")
    val df=DriverClass.spark.sql("SELECT\t\tGPI8,\n\t\t\tGPI8_Name, RowStartDate, RowEndDate,\n\t\t\tZipFileName, ROW_NUMBER() OVER (PARTITION BY GPI8\n\t\t\t\t\t\tORDER BY ETLRunID DESC) Rank\nFROM  (\nSELECT   substring (TherapeuticClassificationCode,  1, 8) as GPI8, REPLACE(TherapeuticClassificationName, '*', '') AS GPI8_Name, RowStartDate, RowEndDate, ZipFileName, ETLRunID \nfrom global_temp.DrugGPI A\nWhere RecordTypeCode = 4 and Substring (TherapeuticClassificationCode,  3, 2) <> '99' and Substring (TherapeuticClassificationCode,  5, 2) <> '99' and\n\tSubstring (TherapeuticClassificationCode,  9, 2) in \n  ( Select min (substring (TherapeuticClassificationCode, 9, 2)) from global_temp.DrugGPI B where \n\tsubstring (A. TherapeuticClassificationCode, 1, 8) = substring (B. TherapeuticClassificationCode, 1, 8)  and B.RecordTypeCode = 4)\n) A\nUnion all \nSelect  substring (TherapeuticClassificationCode,  1, 8) as GPI8, REPLACE(TherapeuticClassificationName, '*', '') AS GPI8_Name, RowStartDate, RowEndDate, ZipFileName , ETLRunID\nfrom global_temp.DrugGPI\nWhere RecordTypeCode = 4 and Substring (TherapeuticClassificationCode,  9, 2) ='00' and \n(Substring (TherapeuticClassificationCode, 3, 2) = '99' or Substring (TherapeuticClassificationCode,  5, 2) = '99')").filter(col("Rank")===1)
    return df
  }
  def DrugGPITest(): Unit ={
    println("DrugGPI:"+DrugGPI.count())
  }
}
