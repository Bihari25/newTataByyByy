package com.optum.spark

import java.util.Properties

import org.apache.spark.sql.functions._

import scala.io.Source

object LoadDrugPricing {

  def runProcess(ZipFileName:String) {

    val url = getClass.getResource("/source.properties")
    val properties: Properties = new Properties()
    val source = Source.fromURL(url)
    properties.load(source.bufferedReader())

    val spark = DriverClass.spark

    var df = spark.read.option("header",true).csv(properties.getProperty("rootPath")+"ETLRunId.txt")
    var ETLRunID = df.select("PreviousID").head().get(0).toString.toInt+1
    val IsIncremental=1

    var Dim_DP = LoadUtil.readJDBC("Dim_DrugPricing")

    Dim_DP=Dim_DP.withColumn("PackagePrice",col("PackagePrice").cast("decimal(10,2)"))

    Dim_DP.createOrReplaceGlobalTempView("DimDP")

    DrugPricingAWP.run(ETLRunID,ZipFileName,IsIncremental)

    DrugPricingCMS.run(ETLRunID,ZipFileName,IsIncremental)

    DrugPricingDP.run(ETLRunID,ZipFileName,IsIncremental)
    //
    DrugPricingWAC.run(ETLRunID,ZipFileName,IsIncremental)
    //
    DrugPricingAAWP.run(ETLRunID,ZipFileName,IsIncremental)

    DrugPricingGEAP.run(ETLRunID,ZipFileName,IsIncremental)
  }
}