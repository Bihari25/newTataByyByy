package com.optum.spark

import org.apache.spark.sql.SaveMode
import org.apache.spark.sql.functions._
object ProcessChangedDrugClassification {

  def runProcess(ZipFileName:String): Unit = {
    print("ProccessChanged")
    val spark = DriverClass.spark

    var STG_DrugGPIClassification = LoadUtil.readJDBC("STG_DrugGPIClassification")
    STG_DrugGPIClassification.createOrReplaceGlobalTempView("STGDrugGPIClassification")

    var Dim_DrugItem=LoadUtil.readJDBC("DIM_DrugItem")

    Dim_DrugItem.select("GenericProductID").orderBy("GenericProductID").distinct().show(1000,false)
    Dim_DrugItem.createOrReplaceGlobalTempView("DimDrugItem")

    var Product=spark.sqlContext.emptyDataFrame

    val Pro1=spark.sql("Select A.PRODUCTID from global_temp.DimDrugItem A INNER JOIN global_temp.STGDrugGPIClassification B ON LEFT(A.GenericProductID, 2) = LEFT(B.TherapeuticClassificationCode, 2) WHERE B.RecordTypeCode = 1  and B.TransactionCode IN ('A', 'C') and A.IsRowCurrent = 1 AND A.ZipFileName<> '"+ZipFileName+"'")

    val Pro2=spark.sql("Select A.PRODUCTID from global_temp.DimDrugItem A INNER JOIN global_temp.STGDrugGPIClassification B ON LEFT(A.GenericProductID, 4) = LEFT(B.TherapeuticClassificationCode, 4) WHERE B.RecordTypeCode = 2 and  B.TransactionCode IN ('A', 'C') and A.IsRowCurrent = 1 AND A.ZipFileName<>'"+ZipFileName+"'")

    val Pro3=spark.sql("Select A.PRODUCTID from global_temp.DimDrugItem A INNER JOIN global_temp.STGDrugGPIClassification B ON LEFT(A.GenericProductID, 6) = LEFT(B.TherapeuticClassificationCode, 6) WHERE B.RecordTypeCode = 3 and B.TransactionCode IN ('A', 'C') and A.IsRowCurrent = 1 AND A.ZipFileName<> '"+ZipFileName+"'")

    val Pro4=spark.sql("Select A.PRODUCTID from global_temp.DimDrugItem A INNER JOIN global_temp.STGDrugGPIClassification B ON LEFT(A.GenericProductID, 10) = LEFT(B.TherapeuticClassificationCode, 10)WHERE B.RecordTypeCode = 4 and  B.TransactionCode IN ('A', 'C') AND A.IsRowCurrent = 1 AND A.ZipFileName<> '"+ZipFileName+"'")

    Product=Pro1.union(Pro2)
    Product=Product.union(Pro3)
    Product=Product.union(Pro4)

    if(Product.count()>0) {

      var DrugItem = Dim_DrugItem
      //Cond1
      var temp = spark.sql("Select A.*,B.TherapeuticClassificationName from global_temp.DimDrugItem A INNER JOIN global_temp.STGDrugGPIClassification B ON LEFT(A.GenericProductID, 2) = LEFT(B.TherapeuticClassificationCode, 2) WHERE B.RecordTypeCode = 1  and B.TransactionCode IN ('A', 'C') ")
      temp = temp.withColumn("DrugGroup", expr(col("B.TherapeuticClassificationName").toString.replace("*", "")))
      temp = temp.drop("TherapeuticClassificationName")
      DrugItem = DrugItem.union(temp)

      println(DrugItem.count())
      //Cond2
      temp = spark.sql("Select A.*,B.TherapeuticClassificationName from global_temp.DimDrugItem A INNER JOIN global_temp.STGDrugGPIClassification B ON LEFT(A.GenericProductID, 4) = LEFT(B.TherapeuticClassificationCode, 4) WHERE B.RecordTypeCode = 2  and B.TransactionCode IN ('A', 'C') ")
      temp = temp.withColumn("DrugGroup", expr(col("B.TherapeuticClassificationName").toString.replace("*", "")))
      temp = temp.drop("TherapeuticClassificationName")
      DrugItem = DrugItem.union(temp)
      println(DrugItem.count())

      //Cond3
      temp = spark.sql("Select A.*,B.TherapeuticClassificationName from global_temp.DimDrugItem A INNER JOIN global_temp.STGDrugGPIClassification B ON LEFT(A.GenericProductID, 6) = LEFT(B.TherapeuticClassificationCode, 6) WHERE B.RecordTypeCode = 3  and B.TransactionCode IN ('A', 'C') ")
      temp = temp.withColumn("DrugGroup", expr(col("B.TherapeuticClassificationName").toString.replace("*", "")))
      temp = temp.drop("TherapeuticClassificationName")
      DrugItem = DrugItem.union(temp)
      //Cond4
      temp = spark.sql("Select A.*,B.TherapeuticClassificationName from global_temp.DimDrugItem A INNER JOIN global_temp.STGDrugGPIClassification B ON LEFT(A.GenericProductID, 10) = LEFT(B.TherapeuticClassificationCode, 10) WHERE B.RecordTypeCode = 4  and B.TransactionCode IN ('A', 'C') ")
      temp = temp.withColumn("DrugGroup", expr(col("B.TherapeuticClassificationName").toString.replace("*", "")))
      temp = temp.drop("TherapeuticClassificationName")
      DrugItem = DrugItem.union(temp)
      DrugItem.createOrReplaceGlobalTempView("DrugItem")

      temp = spark.sql("Select A.* from global_temp.DimDrugItem A INNER JOIN global_temp.DrugItem B ON A.PRODUCTIDDimKey = B.PRODUCTIDDimKey")
      temp = temp.withColumn("IsRowCurrent", lit(0)).withColumn("NotCurrentReason", lit("G"))
      temp = temp.withColumn("RowEndDate", date_sub(col("RowEndDate"), 1))
      temp.createOrReplaceGlobalTempView("TempView")

      var DIM = spark.sql("Select A.* from global_temp.DimDrugItem A where A.PRODUCTIDDimKey NOT IN (SELECT PRODUCTIDDimKey FROM global_temp.TempView)")
      temp=temp.withColumn("IsRowCurrent",col("IsRowCurrent").cast("boolean"))
      temp=temp.withColumn("IsRowSkeleton",col("IsRowSkeleton").cast("boolean"))
      DIM = DIM.union(temp)
      LoadUtil.writeJDBC(DIM, "Dim_DrugItem", SaveMode.Overwrite)

    }
  }
}
