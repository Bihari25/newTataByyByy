package com.optum.spark

import java.sql.{Connection, DriverManager}
import java.util.Properties

import scala.io.Source
object ImportMediSpanDrugData {
  val url = getClass.getResource("/source.properties")
  val properties: Properties = new Properties()
  val source = Source.fromURL(url)
  properties.load(source.bufferedReader())

  val Zip=DriverClass.zipFileName

  def runProcess(): Unit = {

    var connection: Connection = null
    // make the connection
    Class.forName(properties.getProperty("azureDriver"))
    connection = DriverManager.getConnection(properties.getProperty("azureUrl"), properties.getProperty("azureUser"), properties.getProperty("azurePassword"))

    val q1="SELECT CASE WHEN COUNT(*) > 0 THEN 0 ELSE 1 END AS Is_Daily\nFROM   medispan.CFG_File_Import\nWHERE     (CFGIsActive = 1) AND (DestinationTableName = 'Raw_Drug_Data')"
    val q2="insert into medispan.CFG_File_Import( DestinationTableName, ImportFileName, OverwriteTargetFile, CFGIsActive )values( 'RAW_Drug_Data','"+Zip.toString+"', 0, 1);"
    val q3="select \n\tFileImportCFGID,ImportFileName,\n\tOverwriteTargetFile\nfrom medispan.CFG_File_Import\nwhere CFGIsActive = 1\nAND DestinationTableName = 'Raw_Drug_Data'\n order by FileImportCFGID"
    val statement = connection.createStatement()
    val resultSet1 = statement.executeQuery(q1)
    var i=1
    while (resultSet1.next()){
      i=resultSet1.getInt(1)
    }
    var FileImportCFGID=0
    var resultSet2=statement.executeUpdate(q2)
    if(i==1) {
      resultSet2 = statement.executeUpdate(q2)
      val resultSet3 = statement.executeQuery(q3)
      while (resultSet3.next()) {
        FileImportCFGID = resultSet3.getInt(1)
      }
    }
    else {
      val resultSet3 = statement.executeQuery(q3)
      while (resultSet3.next()) {
        FileImportCFGID = resultSet3.getInt(1)
      }
    }
    val q4="select max(FileImportID) AS Import_ID from medispan.AUDIT_File_Import"
    val rs4=statement.executeQuery(q4)
    var MaxFileImportID=1
    while(rs4.next())
    {
      MaxFileImportID=MaxFileImportID+rs4.getInt(1)
    }
    val qq="insert into medispan.AUDIT_File_Import(FileImportID,MachineName,UserName,FileImportCFGID) values("+MaxFileImportID+",'CDW_Dev_Cluster','CdwAdmin',"+MaxFileImportID+")"
    val rq=statement.executeUpdate(qq)

    val aq1="insert into medispan.Audit_Medispan_Load_History(FileImportCFGID,FileImportID,ZipFileName) values("+FileImportCFGID+","+MaxFileImportID+",'"+Zip.toString+"');"
    val ars1=statement.executeUpdate(aq1)

    var list = SourceToParquet.runProcess(Zip,MaxFileImportID)
    AuditUtil.LoadSumToHistory(MaxFileImportID,Zip)
    AuditUtil.CheckFileType(MaxFileImportID,"I",Zip)
    AuditUtil.CheckProductIssue(MaxFileImportID,"I")
    AuditUtil.CheckRawBalance(MaxFileImportID)
    val q13="update medispan.CFG_File_Import\nset CFGIsActive = 10\nwhere FileImportCFGID = "+FileImportCFGID
    val rs13=statement.executeUpdate(q13)
    AuditUtil.RecordLoadedRowCount(MaxFileImportID,"M25",list._1)
    AuditUtil.RecordLoadedRowCount(MaxFileImportID,"M25DICT",list._2)
    AuditUtil.RecordLoadedRowCount(MaxFileImportID,"M25GPPC",list._3)
    AuditUtil.RecordLoadedRowCount(MaxFileImportID,"M25ERR",list._4)
    AuditUtil.RecordLoadedRowCount(MaxFileImportID,"M25GPRR",list._5)
    AuditUtil.RecordLoadedRowCount(MaxFileImportID,"M25MOD",list._6)
    AuditUtil.RecordLoadedRowCount(MaxFileImportID,"M25NMOD",list._7)
    AuditUtil.RecordLoadedRowCount(MaxFileImportID,"M25SUM",list._8)
    AuditUtil.RecordLoadedRowCount(MaxFileImportID,"M25TCRF",list._9)
    AuditUtil.RecordLoadedRowCount(MaxFileImportID,"M25VAL",list._10)
    val q15="update medispan.AUDIT_File_Import set FileImportFinishDateTime = "+list._11.toString+" where FileImportID = "+MaxFileImportID
    val rs15=statement.executeUpdate(q15)
    println("\nImportMediSpanDrugData finished running!\n")
  }

}