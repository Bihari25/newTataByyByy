package com.optum.spark

import java.sql.{Connection, DriverManager}
import java.util.Properties

import org.joda.time.DateTime
import org.joda.time.format.DateTimeFormat

import scala.io.Source

object SqlAWP {
  val url = getClass.getResource("/source.properties")
  val properties: Properties = new Properties()
  val source = Source.fromURL(url)
  properties.load(source.bufferedReader())


  def runProcess(): Unit = {
    var connection:Connection = null
      // make the connection
      Class.forName(properties.getProperty("azureDriver"))
      connection = DriverManager.getConnection(properties.getProperty("azureUrl"), properties.getProperty("azureUser"), properties.getProperty("azurePassword"))
      val statement = connection.createStatement()

      val date: String = DateTimeFormat.forPattern("yyyy-MM-dd").print(DateTime.now())

      val rt = statement.execute("drop table medispan.STG_AWP_CPO_Weekly_Updates")
      connection.commit()
      val q0="INSERT INTO STG_AWP_CPO_Weekly_Updates SELECT   A.ProductID, A.Product_Type_Code, A.Price_Basis, A.SXC_Price_Factor_MDB,    A.SXC_AWP_Unit_Price_MDB, A.SXC_AWP_Eff_Date_MDB,    A.WAC_Price_Factor_MDB as Calculated_Price_Factor,   A.Vaccines_Toxoids_Flag, A.Total_Excise_Tax, A.Excise_Tax_Perunit,   A.FC_AWP_Unit_Price_1 as old_AWP, A.FC_AWP_Effective_Date_1 as old_AWP_effdate,    A.FC_WAC_Unit_Price_1 as old_WAC, A.FC_WAC_Effective_Date_1 as old_WAC_effdate,   A.DP_Unit_Price_1 as old_DP, A.DP_Effective_Date_1 as old_DP_effdate,   B.FC_AWP_Unit_Price_1 as new_AWP, B.FC_AWP_Effective_Date_1 as new_AWP_effdate,    B.FC_WAC_Unit_Price_1 as new_WAC, B.FC_WAC_Effective_Date_1 as new_WAC_effdate,   B.DP_Unit_Price_1 as new_DP, B.DP_Effective_Date_1 as new_DP_effdate,   CASE WHEN A.Vaccines_Toxoids_Flag = 'N' THEN    CAST(B.FC_WAC_Unit_Price_1 * B.SXC_Price_Factor_MDB AS Decimal(38,10))   WHEN A.Vaccines_Toxoids_Flag = 'Y' THEN    CAST(((B.FC_WAC_Unit_Price_1 - B.Excise_Tax_Perunit) * B.SXC_Price_Factor_MDB) + B.Excise_Tax_Perunit  AS Decimal(38,10))   END as calculated_AWP_Unit_Price,   CASE WHEN B.FC_WAC_Effective_Date_1 < '09/26/2009' THEN '09/26/2009'   ELSE B.FC_WAC_Effective_Date_1   END as calculated_AWP_Effective_Date,"+date.toString+" FROM medispan.AWP_CPO_DrugPricing_Backup A WITH(NOLOCK)   INNER JOIN medispan.AWP_CPO_DrugPricing_Current B WITH(NOLOCK)   ON A.ProductID = B.ProductID  WHERE A.Price_Basis = 'DP' AND A.DP_Checksum <> B.DP_Checksum UNION ALL SELECT   A.ProductID, A.Product_Type_Code, A.Price_Basis, A.SXC_Price_Factor_MDB,    A.SXC_AWP_Unit_Price_MDB, A.SXC_AWP_Eff_Date_MDB,    A.WAC_Price_Factor_MDB as Calculated_Price_Factor,   A.Vaccines_Toxoids_Flag, A.Total_Excise_Tax, A.Excise_Tax_Perunit,   A.FC_AWP_Unit_Price_1 as old_AWP, A.FC_AWP_Effective_Date_1 as old_AWP_effdate,    A.FC_WAC_Unit_Price_1 as old_WAC, A.FC_WAC_Effective_Date_1 as old_WAC_effdate,   A.DP_Unit_Price_1 as old_DP, A.DP_Effective_Date_1 as old_DP_effdate,   B.FC_AWP_Unit_Price_1 as new_AWP, B.FC_AWP_Effective_Date_1 as new_AWP_effdate,    B.FC_WAC_Unit_Price_1 as new_WAC, B.FC_WAC_Effective_Date_1 as new_WAC_effdate,   B.DP_Unit_Price_1 as new_DP, B.DP_Effective_Date_1 as new_DP_effdate,   CASE WHEN A.Vaccines_Toxoids_Flag = 'N' THEN    CAST(B.FC_WAC_Unit_Price_1 * B.SXC_Price_Factor_MDB AS Decimal(38,10))   WHEN A.Vaccines_Toxoids_Flag = 'Y' THEN    CAST(((B.FC_WAC_Unit_Price_1 - B.Excise_Tax_Perunit) * B.SXC_Price_Factor_MDB) + B.Excise_Tax_Perunit  AS Decimal(38,10))   END as calculated_AWP_Unit_Price,   CASE WHEN B.FC_WAC_Effective_Date_1 < '09/26/2009' THEN '09/26/2009'   ELSE B.FC_WAC_Effective_Date_1   END as calculated_AWP_Effective_Date,"+date.toString+"   FROM medispan.AWP_CPO_DrugPricing_Backup A WITH(NOLOCK)   INNER JOIN medispan.AWP_CPO_DrugPricing_Current B WITH(NOLOCK)   ON A.ProductID = B.ProductID  WHERE A.Price_Basis = 'WAC' AND    A.WAC_Checksum <> B.WAC_Checksum "
      var r0 = statement.executeQuery(q0)
      val q1="UPDATE "+"medispan.Dim_DrugPricing"+"  SET isRowCurrent = 0 WHERE costTypeCode = 'ADJM' AND  isRowCurrent = 1 AND  ProductID IN (SELECT ProductID FROM medispan.STG_AWP_CPO_Weekly_Updates A     WHERE calculated_AWP_Effective_Date <= '09/26/2009')"
      val rs1=statement.executeUpdate(q1)

      val q2="INSERT INTO "+"medispan.Dim_DrugPricing"+" (  PRODUCTID, CostTypeCode, SpanNumber, PackagePrice,  UnitPrice, EffectiveDate, ETLRunID, RowStartDate,  RowEndDate, IsRowCurrent, IsRowSkeleton,  InactiveReason, ZipFileName) SELECT ProductID as NDC, 'ADJM' as CostTypeCode, 1 as SpanNumber, 0 as PackagePrice,  [calculated_AWP_Unit_Price] as Basis_Unit_AWP, [calculated_AWP_Effective_Date] as Basis_AWP_Eff_Date,   999 as ETLRunID, getdate() as RowStartDate,  '12/31/2078' as RowEndDate, 1 as IsRowCurrent, 0 as IsRowSkeleton,  '' as InactiveReason, 'CustomFile' + REPLACE(CONVERT(VARCHAR, getdate(), 101), '/', '')+ '.zip' as ZipFileName FROM [medispan.STG_AWP_CPO_Weekly_Updates] A WITH(NOLOCK) WHERE calculated_AWP_Effective_Date <= '09/26/2009'"
      val rs2=statement.execute(q2)

      val q3="UPDATE "+"medispan.Dim_DrugPricing"+" SET spanNumber = spanNumber + 1 WHERE costTypeCode = 'ADJM' AND  isRowCurrent = 1 AND  ProductID IN (SELECT ProductID FROM [medispan.STG_AWP_CPO_Weekly_Updates] A WITH(NOLOCK)    WHERE calculated_AWP_Effective_Date > '09/26/2009')"
      val rs3=statement.executeUpdate(q3)

      val q4="INSERT INTO  "+"medispan.Dim_DrugPricing"+" (  PRODUCTID, CostTypeCode, SpanNumber, PackagePrice,  UnitPrice, EffectiveDate, ETLRunID, RowStartDate,  RowEndDate, IsRowCurrent, IsRowSkeleton,  InactiveReason, ZipFileName) SELECT ProductID as NDC, 'ADJM' as CostTypeCode, 1 as SpanNumber, 0 as PackagePrice,  [calculated_AWP_Unit_Price] as Basis_Unit_AWP, [calculated_AWP_Effective_Date] as Basis_AWP_Eff_Date,   999 as ETLRunID, getdate() as RowStartDate,  '12/31/2078' as RowEndDate, 1 as IsRowCurrent, 0 as IsRowSkeleton,  '' as InactiveReason, 'CustomFile' + REPLACE(CONVERT(VARCHAR, getdate(), 101), '/', '')+ '.zip' as ZipFileName FROM [medispan.STG_AWP_CPO_Weekly_Updates] A WITH(NOLOCK) WHERE calculated_AWP_Effective_Date > '09/26/2009'"
      val rs4=statement.execute(q4)

      val q5="UPDATE "+"medispan.Dim_DrugPricing"+" SET isRowCurrent = 0 WHERE costTypeCode = 'ADJM' AND  isRowCurrent = 1 AND  ProductID IN (SELECT ProductID from [medispan.STG_AWP_CPO_Weekly_Updates]    WHERE calculated_AWP_Unit_Price = 0.00)"
      val rs5=statement.executeUpdate(q5)
  }

}
