package com.optum.spark


import java.util.Properties

import org.apache.commons.logging.LogFactory
import org.apache.log4j.{Level, LogManager}
import org.apache.spark.sql.SparkSession
import com.databricks.dbutils_v1.DBUtilsHolder.dbutils

import scala.io.Source


object DriverClass {

//  When running using Databricks-connect uncomment below code

//  ----------------------------------------------------------------------------------------------------------
//  val spark = SparkSession
//    .builder()
//    .master("local")
//    .getOrCreate()
//
//  val dbutils = com.databricks.service.DBUtils

//  ----------------------------------------------------------------------------------------------------------


//  When running as a jar uncomment below code

//  ----------------------------------------------------------------------------------------------------------
  val spark = SparkSession.builder()
      //    .appName("CDW")
      //    .config("spark.master", "local")
    .getOrCreate()

//  ----------------------------------------------------------------------------------------------------------

  val sc = spark.sparkContext
  sc.setLogLevel("ERROR")

  LogManager.getRootLogger().setLevel(Level.INFO)
  val log = LogFactory.getLog("CdwProcess-LOG:")

  val url = getClass.getResource("/source.properties")
  val properties: Properties = new Properties()
  val source = Source.fromURL(url)
  properties.load(source.bufferedReader())


  val fileList: Seq[String] = dbutils.fs.ls(properties.getProperty("rootPath")).map(_.name).filter(a => a.startsWith("MDDB"))
  val zipFileName: String = fileList.last

  def main(args: Array[String]): Unit = {
//    println(zipFileName)

    DimBackup.runProcess()

//    ImportMediSpanDrugData.runProcess()
    //    log.info("ImportMediSpanDrugData completed at "+Calendar.getInstance().getTime())
//    SqlETLMasterMediSpanHEClaimsEDW.runProcess()
    //    log.info("SqlETLMasterMediSpanHEClaimsEDW completed at "+Calendar.getInstance().getTime())
    //        BusinessExtracts.runProcess()
    //    log.info("BusinessExtracts completed at "+Calendar.getInstance().getTime())
    //
    dbutils.fs.mv(from=properties.getProperty("rootPath")+zipFileName, to=properties.getProperty("archivePath"), recurse = true)
    dbutils.fs.mv(from=properties.getProperty("sourcePath")+zipFileName, to=properties.getProperty("archivePath"), recurse = true)
    dbutils.fs.mv(from=properties.getProperty("targetPath")+zipFileName, to=properties.getProperty("archivePath"), recurse = true)
    //
    //    log.info("End to End process completed at "+Calendar.getInstance().getTime())
  }

}
